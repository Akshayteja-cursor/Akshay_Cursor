# Databricks notebook source
from pyspark.sql import functions as F
from pyspark.sql import types as T
from datetime import datetime, timedelta

# COMMAND ----------

def load_format_fw_table(table_name):
    """
    Loads 'raw fw tables' and formats the columns names and types.
    """

    fw_table = spark.read.table(f'fox_bi_prod.raw_ads.{table_name}')
    
    column_format_info = {
        'Event Date': ['event_date', T.DateType()],
        'Placement ID': ['placement_id', T.LongType()],
        'Creative ID': ['creative_id', T.LongType()],
        'Net Counted Ads': ['net_counted_ads', T.LongType()],
        'Delivered Clicks': ['delivered_clicks', T.LongType()],
    }

    cols_to_be_formated_to_int = [
        'Total Historical Unconstrained Ad Avails',
        'Total Historical Constrained Ad Avails',
        'Historical Unfilled Available',
        'Net Ad Requests',
        'On-Target Net Delivered Impressions',
        'Gross Counted Ads',
        'Net Counted Ads',
        'Delivered Clicks',
        'Measurable Video Ads Quartile Impressions',
        'Video Starts',
        'Video Ads 25% Complete',
        'Video Ads 50% Complete',
        'Video Ads 75% Complete',
        'Video Ads 100% Complete'
    ]

    cols_to_be_formated_to_float = [
        'Run Revenue',
        'eCPM'
    ]

    select_cols = []
    for col in fw_table.columns:
        if col != 'created_at' and col != 'updated_at':
            select_cols.append(column_format_info[col][0])
            if col in cols_to_be_formated_to_int:
                fw_table = fw_table.withColumn(col, F.to_number(F.col(col), F.lit('999,999,999,999,999')))
            if col in cols_to_be_formated_to_float:
                fw_table = fw_table.withColumn(col, F.to_number(F.col(col), F.lit('999,999,999,999,999.99999')))
            fw_table = fw_table.withColumnRenamed(col, column_format_info[col][0])
            if 'date' in column_format_info[col][0]:
                fw_table = fw_table.withColumn(column_format_info[col][0], F.to_date(F.col(column_format_info[col][0]), 'MM/dd/yyyy'))
            else:
                fw_table = fw_table.withColumn(column_format_info[col][0], F.col(column_format_info[col][0]).cast(column_format_info[col][1]))

    return fw_table.select(select_cols)


# COMMAND ----------

if __name__ == '__main__':
    tables = [
        'stg_freewheel_analytics_fox_affiliates_direct_sold_delivery'
    ]

    for table_name in tables:
        fw = load_format_fw_table(table_name)
        if not spark.catalog.tableExists(f"fox_bi_prod.bronze_ads.{table_name.replace('stg_', '')}"): #Add the table name for First time load 
            fw.write.format('delta')\
                .mode('overwrite')\
                .partitionBy('event_date')\
                .option('mergeSchema', 'true')\
                .option('overwriteDynamicPartitions', 'true')\
                .option('delta.enableDeletionVectors', 'false')\
                .option('delta.enableIcebergCompatV2', 'true')\
                .option('delta.universalFormat.enabledFormats', 'iceberg')\
                .option('delta.columnMapping.mode', 'name')\
                .saveAsTable(f"fox_bi_prod.bronze_ads.{table_name.replace('stg_', '')}")
        else:
            fw.write.format('delta')\
                .mode('overwrite')\
                .option('partitionOverwriteMode', 'dynamic')\
                .saveAsTable(f"fox_bi_prod.bronze_ads.{table_name.replace('stg_', '')}")
