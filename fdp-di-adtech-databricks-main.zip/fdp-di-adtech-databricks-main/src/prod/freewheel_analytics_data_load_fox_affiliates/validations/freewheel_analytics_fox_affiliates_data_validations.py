# Databricks notebook source
aws_profile=dbutils.widgets.get('aws_profile')
aws_arn=dbutils.widgets.get('aws_arn')
from_email=dbutils.widgets.get('from_email')

# COMMAND ----------

# make the variable available to shell
import os
os.environ["AWS_PROFILE_VAR"] = aws_profile
os.environ["AWS_ARN"] = aws_arn

# COMMAND ----------

# MAGIC %sh
# MAGIC aws configure set region us-west-2 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set s3.signature_version s3v4 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile $AWS_PROFILE_VAR
# MAGIC aws configure set role_arn $AWS_ARN --profile $AWS_PROFILE_VAR

# COMMAND ----------

import boto3
from datetime import datetime, timedelta
from dataclasses import dataclass
from typing import List, Optional, Any, cast
from datetime import datetime, timedelta
import pandas as pd
import pyspark.sql.types as T
import pyspark.sql.functions as F
import io
from email import encoders
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
import os

# COMMAND ----------

global aws_profile, cpe_s3_bucket
aws_profile = f'{aws_profile}'
cpe_s3_bucket = 'fox-fdp-bi-prod'
report_mount_path = '/mnt/fw_analytics/500763/'

# COMMAND ----------

class ReportMailInfo:
    from_email = f'{from_email}'
    reply_to_address = 'data_adtech@fox.com'
    key = ''
    info = {}
    validation_status = False
    report_mailing_lists = {
        "Freewheel Delivery Fox Affiliates Data Validation Report" : {
            "key_format_string" : "freewheel_analytics/AD Tech Freewheel Fox Affiliates Delivery Data Validation Report_%d%b%Y.csv",
            "human_readable_name" : "ad tech freewheel fox affiliates delivery data validation report",
            "to" : [
                "prajwal.harikishor@fox.com",
                "ashwin.sahay@fox.com",
                "sharath.yalaka@fox.com",
                "Pradeep.Panneerselvam@fox.com",
                "Anitha.Mohanraj@fox.com",
                "akshay.dalvi@fox.com",
                "yogesh.nageswararao@fox.com",
            ],
            "cc" : [
                "alimaafroseshahul.hameed@fox.com",
                "Ramesh.Madepalli@fox.com",
            ]
        }
    }

    def __init__(self, report, validation_status, report_date):
        self.info = self.report_mailing_lists[report]
        self.key = get_latest_report(report_date, self.info['key_format_string'])
        self.validation_status = validation_status

    def get_file_name(self):
        return os.path.basename(self.key)
    
    def get_report_body(self, report_date):
        footer = f'<p>This is an automated email. Please direct any questions or concerns to <a href="mailto: {self.reply_to_address}">{self.reply_to_address}</a>.</p>'
        if self.validation_status:
            body_text = f"""<p>Hello,</p>

<p>The validation status: PASS</p>

<p>Please find attached the {self.info['human_readable_name']}.</p>

{footer}
"""
        else:
            body_text = f"""<p>Hello,</p>

<p>The validation status: FAILED</p>

<p>Please find attached the {self.info['human_readable_name']}.</p>

{footer}
"""
        return MIMEText(body_text, 'html')

    def get_report_attachment(self):
        session = boto3.Session(profile_name=aws_profile)
        s3 = session.client('s3')
        resp = s3.get_object(Bucket=cpe_s3_bucket, Key=self.key)
        return resp['Body'].read()

# COMMAND ----------

def get_latest_report(report_date: datetime, key_format_string: str):
    session = boto3.Session(profile_name=aws_profile)
    s3 = session.client('s3')
    for delta in range(0, -7, -1):
        date = report_date + timedelta(days=delta)
        key = date.strftime(key_format_string)
        try:
            print(f'Trying object s3://{cpe_s3_bucket}/{key}')
            s3.head_object(Bucket=cpe_s3_bucket, Key=key)
            return key
        except s3.exceptions.ClientError as exc:
            if exc.response['Error']['Code'] == '404':
                continue
            raise
    raise RuntimeError('Could not find report')

# COMMAND ----------

def send_mail(report_name, validation_status, report_date):
    
    report = ReportMailInfo(report_name, validation_status, report_date)

    attachment_ready_html = []
    img_id = 0
    mime_images = []

    msg = MIMEMultipart()
    msg['Subject'] = report.info['human_readable_name'].title()
    msg['From'] = report.from_email
    msg['To'] = ", ".join(report.info['to'])
    msg['Cc'] = ", ".join(report.info['cc'])
    msg.attach(report.get_report_body(report_date))

    part = MIMEApplication(
        report.get_report_attachment(),
        Name=report.get_file_name(),
    )
    part['Content-Disposition'] = f'attachment; filename="{report.get_file_name()}"'
    msg.attach(part)

    session = boto3.Session(profile_name = aws_profile)
    ses = session.client('ses', region_name='us-west-2')
    ses.send_raw_email(
        Source=msg['From'],
        Destinations=list(set(report.info['to']).union(set(report.info['cc']))),
        RawMessage={'Data': msg.as_string()}
    )

    print('Email sent')

# COMMAND ----------

def get_validation_status(validation_df):
    variance_column_list = [
        'Net Counted Ads Variance %',
        'Delivered Clicks Variance %'
    ]
    for col in variance_column_list:
        if col in validation_df.columns:
            variance_values = validation_df.select(col).distinct().rdd.flatMap(lambda x: x).collect()
            if len(variance_values) == 1 and variance_values[0] == 0:
                pass
            else:
                print(f'Variance found in column {col}')
                return False
    return True

if __name__ == '__main__':
    try:
        historical = dbutils.widgets.get('historical')
        pattern = dbutils.widgets.get('pattern')
    except:
        historical = 'false'
    
    # Freewheel Fox Affiliates Delivery Data Validation Report
    print('Freewheel Fox Affiliates Delivery Data Validation Report')
    if historical == 'true':
        fox_affiliates_delivery = spark.read.format('csv')\
            .option('header','true')\
            .option('inferSchema','false')\
            .load(f'{report_mount_path}{pattern}*.csv')
        
        fox_affiliates_delivery = fox_affiliates_delivery.withColumn('event_date', F.to_date(F.col('Event Date'), 'MM/dd/yyyy'))
        event_start_date = fox_affiliates_delivery.select(F.min('event_date')).collect()[0]['min(event_date)']
        event_end_date = fox_affiliates_delivery.select(F.max('event_date')).collect()[0]['max(event_date)']
    else:
        event_start_date = datetime.strptime(dbutils.widgets.get('event_start_date'), '%Y-%m-%d')
        event_end_date = datetime.strptime(dbutils.widgets.get('event_end_date'), '%Y-%m-%d')

        fox_affiliates_delivery = spark.read.format('csv')\
            .option('header','true')\
            .option('inferSchema','false')\
            .load(f'{report_mount_path}validations_adtech_ft_fw_Direct_Sold_Delivery_{event_start_date.strftime("%Y-%m-%d")}*-{event_end_date.strftime("%Y-%m-%d")}*.csv')

    fox_affiliates_delivery = fox_affiliates_delivery.withColumn('Event Date', F.to_date(F.col('Event Date'), 'MM/dd/yyyy'))
    fox_affiliates_delivery = fox_affiliates_delivery.withColumn('Net Counted Ads', F.to_number(F.col('Net Counted Ads'), F.lit('999,999,999,999,999')))
    fox_affiliates_delivery = fox_affiliates_delivery.withColumn('Delivered Clicks', F.to_number(F.col('Delivered Clicks'), F.lit('999,999,999,999,999')))

    fox_affiliates_delivery = fox_affiliates_delivery.select(['Event Date', 'Net Counted Ads', 'Delivered Clicks'])

    fox_affiliates_delivery = fox_affiliates_delivery.groupBy('Event Date').agg(
        F.sum('Net Counted Ads').alias('Net Counted Ads'),
        F.sum('Delivered Clicks').alias('Delivered Clicks')
    )

    fox_affiliates_delivery = fox_affiliates_delivery.withColumnRenamed('Event Date', 'event_date')
    fox_affiliates_delivery = fox_affiliates_delivery.withColumnRenamed('Net Counted Ads', 'net_counted_ads_source')
    fox_affiliates_delivery = fox_affiliates_delivery.withColumnRenamed('Delivered Clicks', 'delivered_clicks_source')
    fox_affiliates_delivery = fox_affiliates_delivery.withColumn('net_counted_ads_source', F.col('net_counted_ads_source').cast(T.LongType()))
    fox_affiliates_delivery = fox_affiliates_delivery.withColumn('delivered_clicks_source', F.col('delivered_clicks_source').cast(T.LongType()))

    if not spark.catalog.tableExists(f'fox_bi_prod.silver_ads.ft_freewheel_fox_affiliates_direct_sold_delivery_daily_validation_data'): #Add the table name for First time load 
        fox_affiliates_delivery.write.format('delta')\
            .mode('overwrite')\
            .partitionBy('event_date')\
            .option('mergeSchema', 'true')\
            .option('overwriteDynamicPartitions', 'true')\
            .option('delta.enableDeletionVectors', 'false')\
            .option('delta.enableIcebergCompatV2', 'true')\
            .option('delta.universalFormat.enabledFormats', 'iceberg')\
            .option('delta.columnMapping.mode', 'name')\
            .saveAsTable('fox_bi_prod.silver_ads.ft_freewheel_fox_affiliates_direct_sold_delivery_daily_validation_data')
    else:
        fox_affiliates_delivery.write.format('delta')\
            .mode('overwrite')\
            .option('partitionOverwriteMode', 'dynamic')\
            .saveAsTable('fox_bi_prod.silver_ads.ft_freewheel_fox_affiliates_direct_sold_delivery_daily_validation_data')

    table_query = f"""
        SELECT
            event_date
            , SUM(net_counted_ads) AS net_counted_ads_table
            , SUM(delivered_clicks) AS delivered_clicks_table
        FROM fox_bi_prod.silver_ads.ft_freewheel_fox_affiliates_direct_sold_delivery_daily_data
        WHERE event_date BETWEEN '{event_start_date.strftime('%Y-%m-%d')}' AND '{event_end_date.strftime('%Y-%m-%d')}'
        GROUP BY event_date
    """

    table_df = spark.sql(table_query)

    validation_df = fox_affiliates_delivery.join(table_df, on='event_date', how='left')
    
    fields_to_validate = {
        'Net Counted Ads': ['net_counted_ads_source', 'net_counted_ads_table'],
        'Delivered Clicks': ['delivered_clicks_source', 'delivered_clicks_table']
    }

    for field in fields_to_validate:
        source_col, table_col = fields_to_validate[field][0], fields_to_validate[field][1]
        validation_df = validation_df.withColumn(f'{field} Variance',\
            F.when(F.col(source_col) == 0, F.col(table_col))\
            .otherwise(F.col(source_col) - F.col(table_col))
        )
        validation_df = validation_df.withColumn(f'{field} Variance %',\
            F.when(F.col(source_col) == 0, F.col(table_col))\
            .otherwise(F.round(F.col(f'{field} Variance') / F.col(source_col) * 100, 4))
        )

    validation_df = validation_df.sort('event_date')

    validation_status = get_validation_status(validation_df)

    with io.StringIO() as output:
        validation_df.toPandas().to_csv(output, index=False)
        validation_data = output.getvalue()

    report_name = 'AD Tech Freewheel Fox Affiliates Delivery Data Validation Report_' + datetime.today().strftime('%d%b%Y') + '.csv'
    session = boto3.Session(profile_name=aws_profile)
    s3_client = session.client('s3')
    s3_bucket = cpe_s3_bucket
    s3_key = 'freewheel_analytics/' + report_name
    s3_client.put_object(
        Bucket=s3_bucket,
        Body=validation_data.encode('utf-8'),
        Key=s3_key,
    )

    send_mail('Freewheel Delivery Fox Affiliates Data Validation Report', validation_status, datetime.today())