# Databricks notebook source
# COMMAND ----------

# MAGIC %run "/Workspace/Repos/adtech/fdp-di-adtech-databricks/src/prod/data_reporting_and_operational_processing/core"

# COMMAND ----------

# MAGIC %run "/Workspace/Repos/adtech/fdp-di-adtech-databricks/src/prod/data_reporting_and_operational_processing/alert"

# COMMAND ----------

from datetime import datetime, timedelta
import io
import boto3
import pandas as pd
import numpy as np
import traceback


# COMMAND ----------

def find_staq_file(report_date: datetime) -> str:
    session = boto3.Session(profile_name=aws_profile)
    s3 = session.client('s3')

    staq = 'STAQ_Adjuster_Pacing_YTD_All_Lines_' + report_date.strftime('%Y-%m-%d')

    paginator = s3.get_paginator('list_objects_v2')
    page_iterator = paginator.paginate(Bucket=staq_bucket, Prefix=staq)

    latest_file = None
    latest_modified = None

    for page in page_iterator:
        for obj in page.get('Contents', []):
            if staq in obj['Key']:
                if latest_modified is None or obj['LastModified'] > latest_modified:
                    latest_modified = obj['LastModified']
                    latest_file = obj['Key']

    if latest_file:
        return latest_file

# COMMAND ----------

def apply_pg_billing_news(df: pd.DataFrame, report_date: datetime) -> pd.DataFrame:
    global drop_bucket
    s3_dir = f's3://{drop_bucket}/'
    fw_pg_filename = 'FW_PG_Lifetime_Delivery.parquet'
    fw_pg_file = s3_dir + 'processed/' + fw_pg_filename

    pg_billing = pd.read_parquet(fw_pg_file, storage_options={'profile': aws_profile})

    pg_billing.drop(['Event Date'], axis=1, inplace=True)

    pg_billing = pg_billing.groupby(['Deal ID']).sum()

    pg_billing = pg_billing.rename({'Net Counted Ads': 'PG Impressions'}, axis=1)

    df = pd.merge(df, pg_billing, how='left', left_on='Placement ID', right_on='Deal ID')

    def is_pg_deal(row: pd.Series) -> bool:
        if row['Invoice Organization Name'] in {'FOX News & Business', 'FOX News & Business Programmatic', 'FOX News & Business Programmatic - GAM', 'Outkick', 'TMZ and TooFab'}:
            return True
        return False
    
    def billable_metric(row: pd.Series) -> str:
        if row['is_pg_deal'] and row['Sales Order Name'] is not None and 'evergreen' in row['Sales Order Name'].lower():
            return 'Programmatic Reseller Imps'
        if row['is_pg_deal'] and row['Programmatic Type'] is not None and 'programmatic guaranteed' in row['Programmatic Type'].lower():
            return "Programmatic Guaranteed Imps"
        if row['is_pg_deal'] and row['Invoice Organization Name'] is not None and 'programmatic guaranteed' in row['Invoice Organization Name'].lower():
            return "Programmatic Guaranteed Imps"
        return row['Billable Metric']
    
    df.loc[:, 'is_pg_deal'] = df.apply(is_pg_deal, axis=1)

    df.loc[:, 'Billable Metric'] = df.apply(billable_metric, axis=1)

    pg_df = df[df['is_pg_deal'] == True]

    other_df = df[df['is_pg_deal'] == False]

    pg_df.loc[:, '1P Imps'] = pg_df['PG Impressions']
    pg_df.loc[:, 'Net Counted Ads'] = pg_df['PG Impressions']
    pg_df.loc[:, 'Gross Counted Ads'] = pg_df['PG Impressions']
    pg_df.loc[:, 'No Delivery'] = pg_df['PG Impressions'] == 0
    pg_df.loc[:, 'Billable Quantity'] = pg_df['PG Impressions']
    pg_df.loc[:, 'Pacing %'] = pg_df['Billable Quantity'] / pg_df['Quantity'] / pg_df['Launch Flight %']
    pg_df.loc[:, 'Earned Revenue'] = pg_df['Net Unit Cost'] * pg_df['Billable Quantity']/1000
    pg_df.drop(['Parent Line Item Total', 'Parent Line Item Run Rate', 'Parent Line Item Earned Revenue'], inplace=True, axis=1)
    
    df = pd.concat([other_df, pg_df])

    df.fillna(
        {
            '1P Imps': 0,
            'Billable Quantity': 0,
            'Earned Revenue': 0,
        },
        inplace=True,
    )

    return df

# COMMAND ----------

def osi(row: pd.Series, report_date: datetime, type: str) -> float:
    if type == '1p':
        if row['Ad Server Impressions'] == 0 or row['Contracted Quantity'] == 0:
            return 0
        qty = row['Ad Server Impressions']/row['Contracted Quantity']
    else:
        if row['Impressions (3rd Party)'] == 0 or row['Contracted Quantity'] == 0:
            return 0
        qty = row['Impressions (3rd Party)']/row['Contracted Quantity']
    days_elapsed = report_date - row['Line Item Start Date'] + timedelta(days=1)
    flight = row['Line Item End Date'] - row['Line Item Start Date'] + timedelta(days=1)

    if report_date < row['Line Item End Date']:
        return qty/(days_elapsed/flight)
    else:
        return qty
    
def metrics_calculaition(row: pd.Series, calculation: str) -> float:
    if calculation == 'Total Error Rate':
        if row['Total Impressions'] + row['Total Error Count'] == 0:
            return 0
        return row['Total Error Count']/(row['Total Impressions']+row['Total Error Count'])
    
    if calculation == '3rd Party CTR':
        if row['Impressions (3rd Party)'] == 0:
            return 0
        return row['Clicks (3rd Party)']/row['Impressions (3rd Party)']
    
    if calculation == 'Buffer':
        if row['Contracted Quantity'] == 0:
            return 0
        return (row['Ad Server Booked Impressions']-row['Contracted Quantity'])/row['Contracted Quantity']
    
    if calculation == 'Discrepancy':
        if row['Impressions (3rd Party)'] == 0:
            return 0
        return (row['Impressions (3rd Party)']-row['Ad Server Impressions'])/row['Impressions (3rd Party)']


def calculate_metrics(df: pd.DataFrame, report_date: datetime) -> pd.DataFrame:
    df.loc[:, 'Total Error Rate'] = df.apply(metrics_calculaition, args=('Total Error Rate', ), axis=1)
    df.loc[:, '3rd Party CTR'] = df.apply(metrics_calculaition, args=('3rd Party CTR', ), axis=1)
    df.loc[:, 'Ad Server Booked Impressions'] = df['Quantity']
    df.loc[:, 'Buffer'] = df.apply(metrics_calculaition, args=('Buffer', ), axis=1)
    df.loc[:, 'Discrepancy'] = df.apply(metrics_calculaition, args=('Discrepancy', ), axis=1)
    df.loc[:, 'Current First Party OSI'] = df.apply(osi, args=(report_date, '1p'), axis=1)
    df.loc[:, 'Current Third Party OSI'] = df.apply(osi, args=(report_date, '3p'), axis=1)

    metric_columns = [
        'Total Error Rate',
        '3rd Party CTR',
        'Ad Server Booked Impressions',
        'Buffer',
        'Discrepancy',
        'Current First Party OSI',
        'Current Third Party OSI',
    ]

    df = df.fillna({col:0 for col in metric_columns})

    for col in metric_columns:
        df[col] = df[col].replace([np.inf,  -np.inf], 0)

    return df

def format_news_pacing(df: pd.DataFrame, report_date: datetime) -> pd.DataFrame:
    # Filter the lines for the current year
    df = df[df['Line Item End Date'] >= report_date.replace(month=1, day=1)]
    df = df.loc[:,
                [
                    'Instance',
                    'Advertiser',
                    'Order',
                    'Line Item Name',
                    'Line Item Start Date',
                    'Line Item End Date',
                    'Rate',
                    'Goal Quantity',
                    'Contracted Quantity',
                    'Delivery Indicator',
                    'Primary Salesperson Full Name',
                    'Ad Server Impressions',
                    'Impressions (3rd Party)',
                    'Clicks (3rd Party)',
                    '3rd Party CTR',
                    'Buffer',
                    'Discrepancy',
                    'Current First Party OSI',
                    'Current Third Party OSI',
                    'Total Error Count',
                    'Total Error Rate',
                ]]
    
    df = df.dropna(subset=['Line Item Name'])
    df = df.rename(columns={'Primary Salesperson Full Name': 'Salesperson'})

    return df
    
def news_lifetime_delivery(ad_juster_pacing_news: str, report_date: datetime) -> pd.DataFrame:
    global drop_bucket
    s3_dir = f's3://{drop_bucket}/'
    operative_filename = 'Operative_OMS.parquet'
    operative = s3_dir + 'processed/' + operative_filename
    gam_file_name = 'GAM_Lifetime_Delivery.parquet'
    sports_gam_file_name = 'Sports_GAM_Lifetime_Delivery.parquet'
    gam_file = s3_dir + 'processed/' + gam_file_name
    sports_gam_file = s3_dir + 'processed/' + sports_gam_file_name
    adops_lifetime_filename = 'AdOps_Reporting_Lifetime_Delivery.parquet'
    adops_lifetime = s3_dir + 'processed/' + adops_lifetime_filename

    op_oms = pd.read_parquet(operative, storage_options={'profile': aws_profile})
    op_fw_adj = pd.read_parquet(adops_lifetime, storage_options={'profile': aws_profile})
    gam = read_gam_lifetime(gam_file, sports_gam_file, op_oms)
    adjuster_news = read_adjuster_news(ad_juster_pacing_news, op_oms, skiprows=0)

    # Append PG freewheel data
    op_fw_adj = apply_pg_billing_news(op_fw_adj.drop(columns=['PG Impressions'], axis=1), report_date)

    ###########################################################################
    # Write the processed into its own year file
    with io.BytesIO() as output:
        adjuster_news.to_parquet(output, index=False)
        adjuster_news_data = output.getvalue()

    session = boto3.Session(profile_name=aws_profile)
    s3_client = session.client('s3')
    s3_bucket = drop_bucket
    s3_key = 'processed/' + f'adjuster_news_data_{report_date.year}.parquet'
    s3_client.put_object(Bucket=s3_bucket, Body=adjuster_news_data, Key=s3_key,)
    ###########################################################################

    op_gam_fw_adj = merge_news_delivery_data(op_oms, gam, adjuster_news, op_fw_adj)

    op_gam_fw_adj = calculate_metrics(op_gam_fw_adj, report_date)

    return op_gam_fw_adj

def export_news_lifetime_delivery(op_gam_fw_adj: pd.DataFrame, report_date: datetime) -> str:
    with io.BytesIO() as output:
        op_gam_fw_adj.to_parquet(output, index=False)
        op_gam_fw_adj_data = output.getvalue()

    session = boto3.Session(profile_name=aws_profile)
    s3_client = session.client('s3')
    global drop_bucket
    s3_bucket = drop_bucket
    s3_key = 'processed/' + f'AdOps_News_Reporting_Lifetime_Delivery_{report_date.year}.parquet'
    s3_client.put_object(
        Bucket=s3_bucket,
        Body=op_gam_fw_adj_data,
        Key=s3_key,
    )

    return s3_key

def export_news_pacing_report(op_gam_fw_adj: pd.DataFrame, report_date: datetime) -> str:
    news_pacing_report_filename = 'News_Pacing_Report_' + report_date.strftime('%Y%m%d')
    global drop_bucket
    op_gam_fw_adj = format_news_pacing(op_gam_fw_adj, report_date)

    news_report = op_gam_fw_adj[op_gam_fw_adj['Instance'] == 'News'].drop(columns=['Instance'])
    sports_report = op_gam_fw_adj[op_gam_fw_adj['Instance'] == 'Sports'].drop(columns=['Instance'])
    # gam_pg_report = op_gam_fw_adj[op_gam_fw_adj['Instance'] == 'GAM PG'].drop(columns=['Instance'])
    fw_pg_report = op_gam_fw_adj[op_gam_fw_adj['Instance'] == 'FW PG'].drop(columns=['Instance'])

    with io.BytesIO() as output:
        with pd.ExcelWriter(
            output,
            datetime_format='MM/dd/yyyy',
            engine='xlsxwriter',
            options={'strings_to_numbers': True},
        ) as writer:
            workbook = writer.book
            pct_fmt = workbook.add_format({'num_format': '0.00%'})
            report_pct_cols = ['3rd Party CTR', 'Buffer', 'Discrepancy', 'Current First Party OSI', 'Current Third Party OSI']

            news_report.to_excel(writer, sheet_name='News GAM Pacing Report', index=False)
            worksheet = writer.sheets['News GAM Pacing Report']
            set_col_fmt(
                pct_fmt,
                worksheet,
                news_report,
                report_pct_cols
            )

            sports_report.to_excel(writer, sheet_name='Sports GAM Pacing Report', index=False)
            worksheet = writer.sheets['Sports GAM Pacing Report']
            set_col_fmt(
                pct_fmt,
                worksheet,
                news_report,
                report_pct_cols
            )

            # gam_pg_report.to_excel(writer, sheet_name='GAM PG Pacing Report', index=False)
            # worksheet = writer.sheets['GAM PG Pacing Report']
            # set_col_fmt(
            #     pct_fmt,
            #     worksheet,
            #     gam_pg_report,
            #     report_pct_cols
            # )

            fw_pg_report.to_excel(writer, sheet_name='FW PG Pacing Report', index=False)
            worksheet = writer.sheets['FW PG Pacing Report']
            set_col_fmt(
                pct_fmt,
                worksheet,
                fw_pg_report,
                report_pct_cols
            )
        news_pacing_report_data = output.getvalue()

    session = boto3.Session(profile_name=aws_profile)
    s3_client = session.client('s3')
    s3_bucket = drop_bucket
    s3_key = 'reports/' + news_pacing_report_filename + '.xlsx'
    s3_client.put_object(
        Bucket=s3_bucket,
        Body=news_pacing_report_data,
        Key=s3_key,
    )

    return s3_key

# COMMAND ----------

def adops_news_lifetime_delivery(date: datetime, staq_file: str) -> None:
    global drop_bucket
    data_dir = f's3://{staq_bucket}/'
    ad_juster_pacing_news = data_dir + staq_file
    report_date = datetime.combine(date, datetime.min.time())
    news_lifetime_delivery_data = news_lifetime_delivery(ad_juster_pacing_news, report_date)
    export_news_lifetime_delivery(news_lifetime_delivery_data, report_date)
    out = export_news_pacing_report(news_lifetime_delivery_data, report_date)
    write_xcom_value('AdOps News Lifetime Delivery', str(out))

# COMMAND ----------

if __name__ == '__main__':
    date = dbutils.widgets.get('date')
    global drop_bucket, aws_profile
    drop_bucket = dbutils.widgets.get('drop_bucket')
    aws_profile = dbutils.widgets.get('aws_profile')
    staq_bucket = dbutils.widgets.get('staq_bucket')

    def parse_date(date: str) -> bool:
        format = "%Y-%m-%d"
        try:
            res = bool(datetime.strptime(date, format))
        except ValueError:
            res = False
        return res

    assert parse_date(date), "Invalid date format, should be in YYYY-MM-DD format"

    report_date = datetime.strptime(date, "%Y-%m-%d")

    staq_file = find_staq_file(report_date)
    print(staq_file)

    try:
        adops_news_lifetime_delivery(report_date, staq_file)
    except Exception as error:
        alert = Alert()
        alert.send('AdOps News Lifetime Delivery', f'{type(error).__name__}: {error}')
        #dbutils.notebook.exit(f'ERROR!!! - {error}')
        error_details = traceback.format_exc()
        dbutils.notebook.exit(error_details)