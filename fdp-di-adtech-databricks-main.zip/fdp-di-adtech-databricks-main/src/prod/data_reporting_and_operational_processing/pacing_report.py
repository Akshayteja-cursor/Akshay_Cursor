# Databricks notebook source
# COMMAND ----------

# MAGIC %run "/Workspace/Repos/adtech/fdp-di-adtech-databricks/src/prod/data_reporting_and_operational_processing/core"

# COMMAND ----------

# MAGIC %run "/Workspace/Repos/adtech/fdp-di-adtech-databricks/src/prod/data_reporting_and_operational_processing/alert"

# COMMAND ----------

from typing import Any, List, Optional, Tuple
import re
import io
import math
from datetime import datetime, timedelta, date
import pandas as pd
import boto3

# COMMAND ----------

def replace_boc(row: pd.Series) -> Any:
    if row['Billable Metric'] == 'Bill on Contract':
        return row['Implied Billable Metric']
    return row['Billable Metric']


def demo_imp_goal(row: pd.Series) -> Any:
    if row['Is CTV Placement']:
        return row['Impression Goal']
    return row['Booked On-Target Impression Goal']


def gross_imp_goal(row: pd.Series) -> Any:
    if row['Is CTV Placement']:
        return row['Demo Impression Goal'] + (row['Demo Impression Goal'] * row['Over delivery %'])
    return row['Impression Goal']


def demo_imps_1p_car(row: pd.Series) -> Any:
    if row['Is CTV Placement']:
        return row['Gross Counted Ads'] * row['Demo Comp']
    return row['On-Target Net Delivered Impressions']


def comp_generated(row: pd.Series) -> Any:
    if row['Is CTV Placement']:
        return 'NA'
    if (
        math.isnan(row['On-Target Net Delivered Impressions'])
        or row['On-Target Net Delivered Impressions'] == 0
    ) and row['Gross Counted Ads'] != 0:
        return False
    return True


def demo_over_delivery(row: pd.Series) -> Any:
    if row['Is CTV Placement']:
        if row['Demo Comp'] == 0:
            return 0
        return (1/row['Demo Comp'])-1
    return 'NA'


def view_over_delivery(row: pd.Series) -> Any:
    if row['Is Viewability Placement']:
        return (1/row['Viewability'])-1
    return 'NA'


def format_pacing(df: pd.DataFrame, report_date: datetime) -> pd.DataFrame:
    quarter_start = pd.to_datetime(report_date.replace(day=15) - pd.tseries.offsets.QuarterBegin(startingMonth=1)).date()
    in_first_week_of_quarter = (report_date.date() - quarter_start) < timedelta(days=7)

    if in_first_week_of_quarter:
        prev_quarter_start = pd.to_datetime(report_date.replace(day=15) - 2 * pd.tseries.offsets.QuarterBegin(startingMonth=1)).date()
        placement_filter_date = datetime.combine(
            prev_quarter_start - timedelta(days=1),
            datetime.min.time(),
        )
        end_of_period_date = report_date + timedelta(weeks=13)
    else:
        placement_filter_date = datetime.combine(
            quarter_start - timedelta(days=1),
            datetime.min.time(),
        )
        end_of_period_date = report_date + timedelta(weeks=12)

    op_fw_adj = filter_op_orders(df, end_of_period_date, placement_filter_date, remove_non_ad_served=True)

    op_fw_adj['Demo Band'] = op_fw_adj.apply(calc_demo_band, axis=1)

    pacing_report = op_fw_adj.loc[:,
          [
              'Operative Agency',
              'Property Deal Rollup',
              'Days in Flight',
              'Daily Budget',
              'Pending Message Name',
              'Advertiser Name',
              'Campaign ID',
              'Campaign Name',
              'Sales Order ID',
              'Sales Order Name',
              'Sales Order Start Date',
              'Sales Order End Date',
              'Parent Sales Line Item ID',
              'Parent Sales Line Item Name',
              'Parent Line Item Total',
              'Parent Line Item Revenue at Risk',
              'Sales Line Item ID',
              'Placement ID',
              'Sales Line Item Name',
              'Sales Line Item Start Date',
              'Sales Line Item End Date',
              'Net Unit Cost',
              'Quantity',
              'Push Quantity',
              'Net Cost',
              '1P Imps',
              '3P Imps',
              '1P vs 3P Var',
              'Billable Third Party Server',
              'Billable Metric',
              'Implied Billable Metric',
              'Billable Quantity',
              'Earned Revenue',
              'Delivered %',
              'Sales Line Item Run Rate (Capped)',
              'Sales Line Item Revenue at Risk',
              'Demo Band',
              'Demo Comp',
              'Viewability',
              'FFDR (%)',
              'Marketplace Type',
              'Product Name',
              'Placement Property',
              'Sales Line Item Type',
              'Primary Salesperson Full Name',
              'Order Owner Full Name',
              'Trafficker/Campaign Manager',
              'Sales Line Item Risk Category',
              'Launch Date',
              'Invoice Organization Name',
              'Planned Demo Comp',
              'Deal ID',
              'Is Non-Ad Served',
              'is_magnite_deal',
          ],
          ]

    pacing_report = pacing_report.loc[
        ~pacing_report['Sales Line Item Name'].str.contains(
            '.*CANCEL.*',
            regex=True,
            flags=re.IGNORECASE,
            na=False,
        ),
        :,
    ]

    pacing_report = pacing_report.loc[
        ~pacing_report['Sales Order Name'].str.contains(
            '.*CANCEL.*',
            regex=True,
            flags=re.IGNORECASE,
            na=False,
        ),
        :,
    ]

    pacing_report.rename(
        {
            'Advertiser Name': 'Advertiser',
            'Campaign Name': 'Campaign',
            'Sales Order Name': 'Sales Order',
            'Parent Sales Line Item ID': 'Parent Line Item ID',
            'Parent Sales Line Item Name': 'Parent Line Item',
            'Placement ID': 'PS Line Item ID',
            'Sales Line Item Name': 'Sales Line Item',
            'Launch Date': 'Sales Line Item Launch Date',
            'Product Name': 'Product',
            'Primary Salesperson Full Name': 'Primary Salesperson',
            'Order Owner Full Name': 'Order Owner',
            'Earned Revenue': 'Earned Revenue (Uncapped)',
        },
        axis=1,
        inplace=True,
    )

    pacing_report.fillna(
        {
            'Campaign ID': pacing_report['Sales Order ID'],
            'Campaign': pacing_report['Sales Order'],
            '1P vs 3P Var': 0,
            'Demo Comp': 0,
            'Viewability': 1,
            'Delivered %': 0,
            'FFDR (%)': 0,
            'Earned Revenue (Uncapped)': 0,
            'Sales Line Item Run Rate': 0,
        },
        inplace=True,
    )

    pacing_report = pacing_report.astype(
        {
            'Campaign ID': 'int64',
        },
    )

    return pacing_report


def has_cov(rbp: Optional[List[Tuple[str, str]]]) -> bool:
    if rbp is None:
        return False
    return any(pair[0] == 'FW - Apply Co-Viewing' and pair[1] == 'Yes' for pair in rbp)


def apply_formating(df: pd.DataFrame, report_date: datetime) -> pd.DataFrame:
    df.loc[:, 'FFDR (%)'] = df['FFDR (%)'] / 100
    df.loc[:, 'Parent Line Item Total'] = df['Parent Line Item Total'].apply(format_currency)
    df.loc[:, 'Parent Line Item Revenue at Risk'] = df['Parent Line Item Revenue at Risk'].apply(format_currency)
    df.loc[:, 'Net Unit Cost'] = df['Net Unit Cost'].apply(format_currency)
    df.loc[:, 'Net Cost'] = df['Net Cost'].apply(format_currency)
    df.loc[:, 'Earned Revenue (Uncapped)'] = df['Earned Revenue (Uncapped)'].apply(format_currency)
    df.loc[:, 'Sales Line Item Run Rate (Capped)'] = df['Sales Line Item Run Rate (Capped)'].apply(format_currency)
    df.loc[:, 'Sales Line Item Revenue at Risk'] = df['Sales Line Item Revenue at Risk'].apply(format_currency)
    df.loc[:, 'Report Date'] = report_date

    columns_to_drop = [
        'Property Deal Rollup',
        'Implied Billable Metric',
        'Daily Budget',
        'Pending Message Name',
        'Deal ID',
        'Is Non-Ad Served',
        'is_magnite_deal',
    ]

    if environment == '':
        columns_to_drop.append('Days in Flight')

    df.drop(columns_to_drop, axis=1, inplace=True)
    return df


def export_pacing(df: pd.DataFrame, report_date: datetime, output_date: date) -> str:
    df['Invoice Organization Name'] = df['Invoice Organization Name'].fillna('').astype('object')
    pacing_report_filename = 'Pacing_Report' + output_date.strftime('_%Y%m%d')
    df.rename({'Agency Name': 'Operative Agency'}, axis=1, inplace=True)
    pacing_report = format_pacing(df, report_date)

    magnite_report = pacing_report[pacing_report['is_magnite_deal'] == True]
    magnite_report.loc[:, 'Magnite Deal ID'] = magnite_report['Deal ID']
    pacing_report = pacing_report[~pacing_report['Invoice Organization Name'].isin(['Outkick', 'TMZ and TooFab', 'FOX News & Business', 'FOX News & Business Programmatic', 'FOX News & Business Programmatic - GAM'])]
    pacing_report = pacing_report[~pacing_report['Is Non-Ad Served']]
    pacing_report = pacing_report[~pacing_report['Sales Order'].str.contains('Evergreen')]
    btn_report = pacing_report[pacing_report['Placement Property'].isin(['BTN - Digital'])]
    pacing_report = pacing_report[~pacing_report['Placement Property'].isin(['BTN - Digital'])]
    one_fox_report = pacing_report[pacing_report['Product'].str.contains('1F')]
    pacing_report = pacing_report[~pacing_report['Product'].str.contains('1F')]
    programmatic_report = pacing_report[pacing_report['Invoice Organization Name'].str.contains('Programmatic') & (~pacing_report['is_magnite_deal'] == True)]
    pacing_report = pacing_report[~pacing_report['Invoice Organization Name'].str.contains('Programmatic')]

    # Set the Prop Deal Roll up for OneFox lines to OneFox
    one_fox_report.loc[:, 'Property Deal Rollup'] = 'OneFox'

    # List of placement properties to exclude if Invoice Org is blank
    placements_to_exclude = [
        "FOXNews.com",
        "FoxWeather.com",
        "Outkick",
        "RON - News",
        "YouTube - FNM",
        "FOXBusiness.com"
    ]

    # Filter out combos of placement + blank invoice org
    pacing_report = pacing_report[
        ~(
            pacing_report['Placement Property'].isin(placements_to_exclude) &
            (pacing_report['Invoice Organization Name'].str.strip() == "")
        )
    ]

    # Pacing Report filter non adserved Product
    pacing_report = pacing_report[~pacing_report['Product'].isin(['DIO - AUD - FS - Pre/Mid - ROS Podcast',"Custom Sponsorship - FOX Ent - Placeholder"])]

    combined_df = pd.concat([pacing_report, btn_report])
    underpacing_report = combined_df.loc[((combined_df['Invoice Organization Name'].isin({'FOX Sports & Entertainment', 'FOX Sports & Entertainment Fluidity'}) | combined_df['Placement Property'].isin(['BTN - Digital'])) & (
        combined_df['Sales Order End Date'] >= report_date) & (combined_df['Parent Line Item Revenue at Risk'] > 0)), :]
    underpacing_report = pd.concat([underpacing_report, one_fox_report.loc[((one_fox_report['Sales Order End Date'] >= report_date) & (one_fox_report['Parent Line Item Revenue at Risk'] > 0)), :]])

    inactive_report = combined_df.loc[(combined_df['Invoice Organization Name'].isin({'FOX Sports & Entertainment Fluidity', 'FOX Sports & Entertainment'}) | combined_df['Placement Property'].isin(['BTN - Digital'])) & (
        combined_df['Sales Line Item Risk Category'] == 'Inactive, Late Creative'), :]
    inactive_report = pd.concat([inactive_report, one_fox_report.loc[(one_fox_report['Sales Line Item Risk Category'] == 'Inactive, Late Creative'), :]])

    underpacing_summary_df = combined_df.loc[(combined_df['Invoice Organization Name'].isin({'FOX Sports & Entertainment Fluidity', 'FOX Sports & Entertainment'}) | combined_df['Placement Property'].isin(['BTN - Digital'])), :]
    underpacing_summary_df = pd.concat([underpacing_summary_df, one_fox_report])

    underpacing_summary = underpacing_summary_df.groupby('Property Deal Rollup').agg(
        {
            'Parent Line Item Total': 'sum',
            'Parent Line Item Revenue at Risk': 'sum',
        },
    )

    underpacing_summary.loc['Grand Total'] = underpacing_summary.sum()
    underpacing_summary.loc[:, '% of Booked Revenue at Risk'] = underpacing_summary[
        'Parent Line Item Revenue at Risk'] / underpacing_summary['Parent Line Item Total']
    underpacing_summary.loc[:, '% of Total Revenue at Risk'] = underpacing_summary['Parent Line Item Revenue at Risk'] / \
        underpacing_summary.iloc[:-1, :].sum()['Parent Line Item Revenue at Risk']

    underpacing_report.loc[:, '% of Booked Revenue at Risk'] = underpacing_report[
        'Parent Line Item Revenue at Risk'] / underpacing_report['Parent Line Item Total']

    underpacing_report = underpacing_report.reindex(
        [
            'Operative Agency',
            'Property Deal Rollup',
            'Advertiser',
            'Sales Order ID',
            'Sales Order',
            'Sales Order Start Date',
            'Sales Order End Date',
            'Parent Line Item Total',
            'Parent Line Item Revenue at Risk',
            'Parent Line Item ID',
            'Parent Line Item',
            'Primary Salesperson',
            'Trafficker/Campaign Manager',
            '% of Booked Revenue at Risk',
            'Notes',
        ],
        axis=1,
    )

    underpacing_report.sort_values(
        'Parent Line Item Revenue at Risk',
        ascending=False,
        inplace=True,
    )

    underpacing_report.rename(
        {
            'Trafficker/Campaign Manager': 'CM',
        },
        axis=1,
        inplace=True,
    )

    inactive_report = inactive_report.reindex(
        [
            'Operative Agency',
            'Sales Order ID',
            'PS Line Item ID',
            'Sales Line Item ID',
            'Sales Line Item',
            'Sales Line Item Start Date',
            'Sales Line Item End Date',
            'Pending Message Name',
            'Trafficker/Campaign Manager',
            'Days in Flight',
            'Daily Budget',
            'Sales Line Item Revenue at Risk',
            'Sales Line Item Risk Category',
            'Notes',
        ],
        axis=1,
    ).reset_index(drop=True)

    inactive_report = inactive_report.rename(
        {
            'PS Line Item ID': 'PS Line Item IDs (FW Placement ID)',
            'Sales Line Item': 'Sales Line Item Name',
            'Sales Line Item Start Date': 'Start Date',
            'Sales Line Item End Date': 'End Date',
            'Trafficker/Campaign Manager': 'Trafficker',
            'Days in Flight': 'Total Days in Flight',
            'Sales Line Item Risk Category': 'Risk Category',
        },
        axis=1,
    )

    inactive_report.loc[:, 'Sales Line Item Revenue at Risk'] = inactive_report['Sales Line Item Revenue at Risk'].apply(format_currency)
    inactive_report.loc[:, 'Daily Budget'] = inactive_report['Daily Budget'].apply(format_currency)

    underpacing_summary.loc[:, 'Parent Line Item Revenue at Risk'] = underpacing_summary['Parent Line Item Revenue at Risk'].apply(format_currency)
    underpacing_summary.loc[:, 'Parent Line Item Total'] = underpacing_summary['Parent Line Item Total'].apply(format_currency)

    underpacing_report.loc[:, 'Parent Line Item Revenue at Risk'] = underpacing_report['Parent Line Item Revenue at Risk'].apply(format_currency)
    underpacing_report.loc[:, 'Parent Line Item Total'] = underpacing_report['Parent Line Item Total'].apply(format_currency)

    pacing_report = apply_formating(pacing_report, report_date)
    programmatic_report = apply_formating(programmatic_report, report_date)
    magnite_report = apply_formating(magnite_report, report_date)
    one_fox_report = apply_formating(one_fox_report, report_date)
    btn_report = apply_formating(btn_report, report_date)

    df = df.loc[df['Sales Line Item End Date'] >= report_date, :]
    df['Has CoV?'] = df['FW - RBP Advanced'].apply(has_cov)

    comp_adj = df[
        (df['Is Demo Placement'] | df['Is Viewability Placement'] | df['Has CoV?'])
        & (~df['Is Future Start'])
        & (~df['No Delivery'])
        & (~df['Invoice Organization Name'].str.contains('Programmatic')) #(~df['is_pg_deal'])
    ].loc[
        :,
        [
            'Operative Agency',
            'Trafficker/Campaign Manager',
            'Sales Order ID',
            'Sales Order Name',
            'Sales Line Item ID',
            'Placement ID',
            'Sales Line Item Name',
            'Sales Line Item Start Date',
            'Sales Line Item End Date',
            'Placement Property',
            'Demographic Data Source',
            'Booked On-Target Impression Goal',
            'Impression Goal',
            'Forced Over Delivery Percent (%)',
            'On-Target Net Delivered Impressions',
            'Gross Counted Ads',
            'Demo Band',
            'Demo Comp',
            'Is CTV Placement',
            'Is Viewability Placement',
            'Viewability',
            'Has CoV?',
            'Planned Demo Comp',
            'Gross Counted Ads (Demo)',
        ],
    ]

    comp_adj['Has CoV?'] = comp_adj['Has CoV?'].map({True: 'Y', False: 'N'})
    df = df.drop(columns=['Has CoV?'])

    comp_adj = comp_adj.loc[
        ~comp_adj['Sales Line Item Name'].str.contains(
            '.*CANCEL.*',
            regex=True,
            flags=re.IGNORECASE,
            na=False,
        ),
        :,
    ]

    if not comp_adj.empty:
        comp_adj.loc[:, 'Over delivery %'] = comp_adj.loc[:, 'Forced Over Delivery Percent (%)'].fillna(10).astype('float64') / 100
        comp_adj.loc[:, 'Demo Impression Goal'] = comp_adj.apply(demo_imp_goal, axis=1).fillna(0).astype('int64')
        comp_adj.loc[:, 'Gross Impression Goal'] = comp_adj.apply(gross_imp_goal, axis=1).fillna(0).astype('int64')
        comp_adj.loc[:, '1P Demo Impressions'] = comp_adj.apply(demo_imps_1p_car, axis=1).fillna(0).astype('int64')
        comp_adj.loc[:, '1P Gross Counted Ads'] = comp_adj.loc[:, 'Gross Counted Ads (Demo)'].fillna(0).astype('int64')
        comp_adj.loc[:, 'Booked Comp'] = comp_adj['Demo Impression Goal'] / comp_adj['Gross Impression Goal']
        comp_adj.loc[:, 'Demo Comp Difference'] = comp_adj['Demo Comp'] - comp_adj['Booked Comp']
        comp_adj.loc[:, 'New Gross Impression Goal (RBP Placements Only)'] = ((1/comp_adj['Demo Comp']) * comp_adj['Demo Impression Goal']).fillna(0).astype('int64', errors='ignore')
        comp_adj.loc[:, 'New Demo Over-delivery % (CTV Only Placements)'] = comp_adj.apply(demo_over_delivery, axis=1)
        comp_adj.loc[:, 'Comp Generated?'] = comp_adj.apply(comp_generated, axis=1)
        comp_adj.loc[:, 'New Viewability Over-delivery %'] = comp_adj.apply(view_over_delivery, axis=1)

    comp_adj_report = comp_adj.reindex(
        [
            'Operative Agency',
            'Trafficker/Campaign Manager',
            'Sales Order ID',
            'Sales Order Name',
            'Sales Line Item ID',
            'Placement ID',
            'Sales Line Item Name',
            'Sales Line Item Start Date',
            'Sales Line Item End Date',
            'Placement Property',
            'Demographic Data Source',
            'Demo Impression Goal',
            'Gross Impression Goal',
            'Over delivery %',
            '1P Demo Impressions',
            '1P Gross Counted Ads',
            'Booked Comp',
            'Demo Comp',
            'Demo Comp Difference',
            'New Gross Impression Goal (RBP Placements Only)',
            'New Demo Over-delivery % (CTV Only Placements)',
            'Demo Band',
            'Comp Generated?',
            'Viewability',
            'New Viewability Over-delivery %',
            'Has CoV?',
            'Planned Demo Comp',
        ],
        axis=1,
    )

    df.loc[:, 'Billable Metric'] = df.apply(replace_boc, axis=1)

    pacing_money_cols = [
        'Parent Line Item Total',
        'Parent Line Item Revenue at Risk',
        'Net Unit Cost',
        'Net Cost',
        'Earned Revenue (Uncapped)',
        'Sales Line Item Run Rate (Capped)',
        'Sales Line Item Revenue at Risk',
    ]
    pacing_pct_cols = [
        '1P vs 3P Var',
        'Delivered %',
        'Demo Comp',
        'Viewability',
        'FFDR (%)',
    ]
    inactive_money_cols = [
        'Daily Budget',
        'Sales Line Item Revenue at Risk',
    ]
    risk_sum_money_cols = [
        'Parent Line Item Total',
        'Parent Line Item Revenue at Risk',
    ]
    risk_sum_pct_cols = [
        '% of Booked Revenue at Risk',
        '% of Total Revenue at Risk',
    ]
    underpacing_money_cols = [
        'Parent Line Item Total',
        'Parent Line Item Revenue at Risk',
    ]
    underpacing_pct_cols = [
        '% of Booked Revenue at Risk',
    ]

    comp_adj_pct_cols = [
        'Over delivery %',
        'Booked Comp',
        'Demo Comp',
        'Demo Comp Difference',
        'New Demo Over-delivery % (CTV Only Placements)',
        'Viewability',
        'New Viewability Over-delivery %',
    ]

    with io.BytesIO() as output:
        with pd.ExcelWriter(
            output,
            datetime_format='MM/dd/yyyy',
            engine='xlsxwriter',
            options={'strings_to_numbers': True},
            # engine_kwargs={"options": {'strings_to_numbers': True}},
        ) as writer:
            workbook = writer.book
            money_fmt = workbook.add_format({'num_format': '$#,##0.00'})
            pct_fmt = workbook.add_format({'num_format': '0%'})

            pacing_report.to_excel(writer, sheet_name='Pacing Report', index=False)
            programmatic_report.to_excel(writer, sheet_name='FW PG', index=False)
            magnite_report.to_excel(writer, sheet_name='Magnite', index=False)
            btn_report.to_excel(writer, sheet_name='BTN', index=False)
            one_fox_report.to_excel(writer, sheet_name='OneFox', index=False)
            comp_adj_report.to_excel(writer, sheet_name='Comp Adjustment', index=False)
            inactive_report.to_excel(writer, sheet_name='Inactive, Late Creative', index=False)
            underpacing_summary.to_excel(writer, sheet_name='Rev at Risk Summary', index_label=' ')
            worksheet = writer.sheets['Inactive, Late Creative']
            set_col_fmt(
                money_fmt,
                worksheet,
                inactive_report,
                inactive_money_cols,
            )
            for prop_deal in list(underpacing_report['Property Deal Rollup'].unique()):
                if prop_deal == 'Placement Property not mapped':
                    continue
                underpacing_tab = underpacing_report.loc[underpacing_report.loc[:, 'Property Deal Rollup'] == prop_deal, :].drop(
                    ['Property Deal Rollup'],
                    axis=1,
                )
                if underpacing_tab.shape[0] > 0:
                    rev_sheet_name = 'Rev at Risk ' + prop_deal
                    if len(rev_sheet_name) > 31:
                        rev_sheet_name = rev_sheet_name[:29] + '...'
                    underpacing_tab.to_excel(
                        writer,
                        sheet_name=rev_sheet_name,
                        index=False,
                    )
                    worksheet = writer.sheets[rev_sheet_name]
                set_col_fmt(
                    money_fmt,
                    worksheet,
                    underpacing_tab,
                    underpacing_money_cols,
                )
                set_col_fmt(
                    pct_fmt,
                    worksheet,
                    underpacing_tab,
                    underpacing_pct_cols,
                )
            for ws, wsdf in {'Pacing Report':pacing_report, 'FW PG':programmatic_report, 'Magnite':magnite_report, 'BTN': btn_report, 'OneFox':one_fox_report}.items():
                worksheet = writer.sheets[ws]
                data = wsdf
                set_col_fmt(
                    money_fmt,
                    worksheet,
                    data,
                    pacing_money_cols,
                )
                set_col_fmt(
                    pct_fmt,
                    worksheet,
                    data,
                    pacing_pct_cols,
                )
            worksheet = writer.sheets['Comp Adjustment']
            set_col_fmt(
                pct_fmt,
                worksheet,
                comp_adj_report,
                comp_adj_pct_cols,
            )
            worksheet = writer.sheets['Rev at Risk Summary']
            set_col_fmt(
                money_fmt,
                worksheet,
                underpacing_summary,
                risk_sum_money_cols,
                offset=1,
            )
            set_col_fmt(
                pct_fmt,
                worksheet,
                underpacing_summary,
                risk_sum_pct_cols,
                offset=1,
            )
        pacing_file_data = output.getvalue()


    global drop_bucket
    session = boto3.Session(profile_name=aws_profile)
    s3_client = session.client('s3')
    s3_bucket = drop_bucket
    report_dir = 'reports/'
    s3_key = report_dir + pacing_report_filename + '.xlsx'
    s3_client.put_object(
        Bucket=s3_bucket,
        Body=pacing_file_data,
        Key=s3_key,
    )

    return s3_key

# COMMAND ----------

def pacing_report(output_date: datetime) -> None:
    global drop_bucket
    data_dir = f's3://{drop_bucket}/processed/'
    data_filename = 'AdOps_Reporting_Lifetime_Delivery.parquet'
    op_fw_adj = pd.read_parquet(data_dir + data_filename, storage_options={'profile': aws_profile})
    op_fw_adj = op_fw_adj[~op_fw_adj['Sales Order ID'].isin(WHITELISTED_TEST_ORDERS)]
    report_date = datetime.today()
    output_file = export_pacing(op_fw_adj, report_date, output_date)
    write_xcom_value('Pacing Report', output_file)

# COMMAND ----------

if __name__ == '__main__':
    report_date = dbutils.widgets.get('date')
    global drop_bucket, aws_profile, environment
    drop_bucket = dbutils.widgets.get('drop_bucket')
    aws_profile = dbutils.widgets.get('aws_profile')
    environment = ''

    def parse_date(date: str) -> bool:
        format = "%Y-%m-%d"
        try:
            res = bool(datetime.strptime(date, format))
        except ValueError:
            res = False
        return res

    assert parse_date(report_date), "Invalid date format, should be in YYYY-MM-DD format"

    try:
        pacing_report(datetime.strptime(report_date, "%Y-%m-%d"))
    except Exception as error:
        alert = Alert()
        alert.send('Pacing Report', f'{type(error).__name__}: {error}')
        dbutils.notebook.exit(f'ERROR!!! - {error}')