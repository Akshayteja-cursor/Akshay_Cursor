# Databricks notebook source

catalog_name = dbutils.widgets.get('catalog_name')
raw_schema_name = dbutils.widgets.get('raw_schema_name')
aws_arn = dbutils.widgets.get('aws_arn')
aws_profile = dbutils.widgets.get('aws_profile')

# COMMAND ----------

import os
os.environ["AWS_PROFILE_VAR"] = aws_profile
os.environ["AWS_ARN"] = aws_arn

# COMMAND ----------

# MAGIC %sh
# MAGIC aws configure set region us-west-2 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set s3.signature_version s3v4 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile $AWS_PROFILE_VAR
# MAGIC aws configure set role_arn $AWS_ARN --profile $AWS_PROFILE_VAR

# COMMAND ----------

from typing import Any, List
import json
import time
from datetime import datetime
from dataclasses import dataclass
import requests
import boto3
import pyspark.sql.functions as F

# COMMAND ----------

@dataclass
class AdjusterCredentials:
    public_key: str
    private_key: str

    @classmethod
    def from_secret(cls, secret_arn: str) -> 'AdjusterCredentials':
        try:
            session = boto3.Session(profile_name=aws_profile)
            resp = session.client('secretsmanager').get_secret_value(SecretId=secret_arn)
            secret = json.loads(resp['SecretString'])
            ajuster_creds_cls = cls(public_key=secret['public_key'], private_key=secret['private_key'])
            return ajuster_creds_cls
        except:
            raise Exception(f'Could not load Adjuster credentials from secret {secret_arn}')

# COMMAND ----------

def manual_download_reports_to_s3(adjuster_credentials: AdjusterCredentials, report_name: str, report_date: datetime, report_run_ids: list) -> List[str]:
    # Download reports
    reports_to_key = {
        #'megaphone_1p_3p': 'Megaphone_1P_3P_Daily',
        #'megaphone_amperware': 'Megaphone_Amperware_Daily',
        '3rd_party_aggregrate': '3rd_Party_Aggregate_Daily',
        'campaign_delivery': 'Campaign_Delivery_Daily',
    }
    report_s3_pfx = 'adtech/adjuster/'
    report_name_base = reports_to_key[report_name]

    session = boto3.Session(profile_name=aws_profile)
    s3_client = session.client('s3')

    s3_keys = []
    for report_run_id in report_run_ids:
        report_dl = f'https://pub.doubleverify.com/campaign-delivery/adjuster-api/reports/download/{report_run_id}'
        report_dl_r = requests.get(report_dl, auth=(adjuster_credentials.public_key, adjuster_credentials.private_key))

        s3_key = report_s3_pfx + report_name_base + report_date.strftime('_%Y%m%d') + str(report_run_id) + '.csv.gz'

        s3_client.put_object(
            Bucket=s3_bucket,
            Body=report_dl_r.content,
            Key=s3_key,
        )
        s3_keys.append(s3_key)
        print('File downloaded. File path: ', s3_key)

    return s3_keys

# COMMAND ----------

if __name__ == '__main__':
    date = dbutils.widgets.get('date')
    global s3_bucket, aws_profile
    s3_bucket = dbutils.widgets.get('s3_bucket')
    aws_profile = dbutils.widgets.get('aws_profile')
    adjuster_credentials_secret_arn = dbutils.widgets.get('adjuster_credentials_secret_arn')
    report_run_ids = dbutils.widgets.get('report_run_ids').split(',')
    # report_run_ids = [2123686,2123688,2123687,2123689,2123683,2123685,2123682,2123684,2123681,2123680,2123678,2123677,2123679,2123676,2123674,2123675,2123671,2123672,2123673,2123669,2123668,2123670]

    REPORT_CHOICES = [
        #'megaphone_1p_3p',
        #'megaphone_amperware',
        '3rd_party_aggregrate',
        'campaign_delivery',
    ]

    try:
        assert dbutils.widgets.get('report') in REPORT_CHOICES, "Invalid report, should be one of {}".format(REPORT_CHOICES)
        reports = [dbutils.widgets.get('report')]
    except:
        reports = ['3rd_party_aggregrate', 'campaign_delivery']

    def parse_date(date: str) -> bool:
        format = "%Y-%m-%d"
        try:
            res = bool(datetime.strptime(date, format))
        except ValueError:
            res = False
        return res

    assert parse_date(date), "Invalid date format, should be in YYYY-MM-DD format"
    assert adjuster_credentials_secret_arn != '', "Invalid adjuster_credentials_secret_arn"

    # Fetch Adjuster API Credentials
    adjuster_credentials = AdjusterCredentials.from_secret(adjuster_credentials_secret_arn)

    # Run report via api and download to s3
    for report in reports:
        s3_keys = manual_download_reports_to_s3(adjuster_credentials, report, datetime.strptime(date, "%Y-%m-%d"), report_run_ids)
        print(f'Total {len(s3_keys)} downloaded')

        # Incremental Load to raw table
        report_to_table ={
            #'megaphone_1p_3p': f'{catalog_name}.{raw_schema_name}.third_party_campaign_reporting_megaphone',
            #'megaphone_amperware': f'{catalog_name}.{raw_schema_name}.megaphone_amperwave_campaign_reporting_delivery',
            '3rd_party_aggregrate': f'{catalog_name}.{raw_schema_name}.third_party_campaign_reporting_aggregate',
            'campaign_delivery': f'{catalog_name}.{raw_schema_name}.third_party_campaign_reporting_delivery',
        }
        table_name = report_to_table[report]
        mount_path = f'/mnt/{s3_bucket}/'
        for s3_key in s3_keys:
            df = spark.read.format('csv').option('header', 'true').option('inferSchema', 'false').option('multiLine', 'true').load(f'{mount_path}/{s3_key}', skipRows=8, quote='"', escape='"')

            df = df.withColumn('event_date', F.to_date(F.col('Report End Date'), 'MM/dd/yyyy'))
            df = df.withColumn('created_timestamp', F.current_timestamp())

            if df.count() != 0:
                if not spark.catalog.tableExists(table_name):
                    print('Table does not exist. Creating table')
                    df.write.format('delta')\
                        .mode('overwrite')\
                        .partitionBy('event_date')\
                        .option('mergeSchema', 'true')\
                        .option('overwriteDynamicPartitions', 'true')\
                        .option('delta.enableDeletionVectors', 'false')\
                        .option('delta.enableIcebergCompatV2', 'true')\
                        .option('delta.universalFormat.enabledFormats', 'iceberg')\
                        .option('delta.columnMapping.mode', 'name')\
                        .saveAsTable(table_name)
                else:
                    print('Table exists. Appending data')
                    df.write.format('delta')\
                        .mode('overwrite')\
                        .option('partitionOverwriteMode', 'dynamic')\
                        .saveAsTable(table_name)