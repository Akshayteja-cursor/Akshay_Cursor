# Databricks notebook source
import os
from datetime import datetime, timedelta
import pandas as pd
import boto3
from typing import Any
import csv
from pyspark.sql import DataFrame
from pyspark.sql.functions import to_date

# COMMAND ----------

env = dbutils.widgets.get('env')
aws_arn = dbutils.widgets.get('aws_arn')
aws_profile = dbutils.widgets.get('aws_profile')

os.environ["AWS_PROFILE_VAR"] = aws_profile
os.environ["AWS_ARN"] = aws_arn

staq_bucket = dbutils.widgets.get('staq_bucket')

process_start_date = dbutils.widgets.get('process_start_date')
process_end_date = dbutils.widgets.get('process_end_date')
manual_file_name = dbutils.widgets.get('manual_file_name')

if env == 'dev':
  catalog_name = 'fox_bi_dev'
  raw_schema_name = 'raw_ads'
elif env == 'prod':
  catalog_name = 'fox_bi_prod'
  raw_schema_name = 'raw_ads'

# COMMAND ----------

# MAGIC %sh
# MAGIC aws configure set region us-west-2 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set s3.signature_version s3v4 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile $AWS_PROFILE_VAR
# MAGIC aws configure set role_arn $AWS_ARN --profile $AWS_PROFILE_VAR

# COMMAND ----------

def find_staq_file(report_date: datetime) -> str:
    session = boto3.Session(profile_name=aws_profile)
    s3 = session.client('s3')

    staq = 'STAQ_Megaphone_Amperwave_L7_Days_' + report_date.strftime('%Y-%m-%d')
    megaphone_prefix = 'megaphone/'

    paginator = s3.get_paginator('list_objects_v2')
    page_iterator = paginator.paginate(Bucket=staq_bucket, Prefix=megaphone_prefix)

    for page in page_iterator:
        for obj in page.get('Contents', []):
            if staq in obj['Key']:
                return obj['Key']

def generate_dates(process_start_date: str, process_end_date: str):
    dates = pd.date_range(datetime.strptime(process_start_date, '%Y-%m-%d'), datetime.strptime(process_end_date,  '%Y-%m-%d'), freq='D')
    return dates

def update_daily_breakouts(file_path: str) -> None:
    last_n = pd.read_csv(
        f's3://{staq_bucket}/{file_path}',
        parse_dates=['Date'],
        encoding='utf-8',
        storage_options={'profile': aws_profile},
        quotechar='"',
        doublequote=True,
        quoting=csv.QUOTE_MINIMAL
    )
    return last_n

# COMMAND ----------

def write_to_table(df):
  if not spark.catalog.tableExists(f'{catalog_name}.{raw_schema_name}.megaphone_amperwave_campaign_reporting_delivery'):
    df.write.format('delta')\
        .mode('overwrite')\
        .partitionBy('event_date')\
        .option('mergeSchema', 'true')\
        .option('overwriteDynamicPartitions', 'true')\
        .option('delta.enableDeletionVectors', 'false')\
        .option('delta.enableIcebergCompatV2', 'true')\
        .option('delta.universalFormat.enabledFormats', 'iceberg')\
        .option('delta.columnMapping.mode', 'name')\
        .saveAsTable(f"{catalog_name}.{raw_schema_name}.megaphone_amperwave_campaign_reporting_delivery")
  else:
      df.write.format('delta')\
          .mode('overwrite')\
          .option('partitionOverwriteMode', 'dynamic')\
          .saveAsTable(f"{catalog_name}.{raw_schema_name}.megaphone_amperwave_campaign_reporting_delivery")

# COMMAND ----------

if __name__ == '__main__':
    def parse_date(date: str) -> bool:
        format = "%Y-%m-%d"
        try:
            res = bool(datetime.strptime(date, format))
        except ValueError:
            res = False
        return res

    # If a manual file name is provided, process that file alone irrespective of dates
    if str(manual_file_name) not in ('None', ''):
        print(f"Processing manual file: {manual_file_name}")

        res = update_daily_breakouts('megaphone/'+manual_file_name.strip())
        df = spark.createDataFrame(res)

        if spark.catalog.tableExists(f"{catalog_name}.{raw_schema_name}.megaphone_amperwave_campaign_reporting_delivery"):
            df = df.withColumn('event_date', to_date(df['Date']))
            table_schema = spark.table(f"{catalog_name}.{raw_schema_name}.megaphone_amperwave_campaign_reporting_delivery").schema
        else:
            df = df.withColumn('event_date', to_date(df['Date']))
            table_schema = df.schema

        df = spark.createDataFrame(df.rdd, schema=table_schema)
        write_to_table(df)
    else:
        assert parse_date(process_start_date), "Invalid date format, should be in YYYY-MM-DD format"
        assert parse_date(process_end_date), "Invalid date format, should be in YYYY-MM-DD format"
        assert datetime.strptime(process_start_date, "%Y-%m-%d") <= datetime.strptime(process_end_date, "%Y-%m-%d"), "process_start_date should be less than or equal to process_end_date"

        if process_start_date != process_end_date:
            dates_to_process = generate_dates(process_start_date, process_end_date)
            print(dates_to_process)
            for processing_date in dates_to_process:
                staq = find_staq_file(processing_date)
                print(staq)
                if staq is not None:
                    res = update_daily_breakouts(staq)
                    df = spark.createDataFrame(res)

                    if spark.catalog.tableExists(f"{catalog_name}.{raw_schema_name}.megaphone_amperwave_campaign_reporting_delivery"):
                        df = df.withColumn('event_date', to_date(df['Date']))
                        table_schema = spark.table(f"{catalog_name}.{raw_schema_name}.megaphone_amperwave_campaign_reporting_delivery").schema
                    else:
                        df = df.withColumn('event_date', to_date(df['Date']))
                        table_schema = df.schema
                    
                    df = spark.createDataFrame(df.rdd, schema=table_schema)
                    write_to_table(df)
        else:
            report_date = process_start_date
            print("Processing date: ", report_date)
            staq = find_staq_file(datetime.strptime(report_date, '%Y-%m-%d'))
            print(staq)
            if staq is not None:
                res = update_daily_breakouts(staq)
                df = spark.createDataFrame(res)

                if spark.catalog.tableExists(f"{catalog_name}.{raw_schema_name}.megaphone_amperwave_campaign_reporting_delivery"):
                    df = df.withColumn('event_date', to_date(df['Date']))
                    table_schema = spark.table(f"{catalog_name}.{raw_schema_name}.megaphone_amperwave_campaign_reporting_delivery").schema
                else:
                    df = df.withColumn('event_date', to_date(df['Date']))
                    table_schema = df.schema

                df = spark.createDataFrame(df.rdd, schema=table_schema)
                write_to_table(df)
