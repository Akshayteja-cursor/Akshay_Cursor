# Databricks notebook source
spark.conf.set(
    "spark.databricks.remoteFiltering.blockSelfJoins",
    "false"
)
spark.conf.set(
    "spark.sql.execution.arrow.pyspark.enabled",
    "false"
)
spark.conf.set("spark.sql.ansi.enabled", "false") 
# Adaptive query execution + Delta write tuning for the large multi-source unions/joins
spark.conf.set("spark.sql.adaptive.enabled", "true")
spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled", "true")
spark.conf.set("spark.sql.adaptive.localShuffleReader.enabled", "true")
spark.conf.set("spark.databricks.delta.optimizeWrite.enabled", "true")
spark.conf.set("spark.databricks.delta.autoCompact.enabled", "true")

# COMMAND ----------

global aws_profile, APPLICATION_NAME, NETWORK_CODE, cpe_s3_bucket

# COMMAND ----------

aws_profile=dbutils.widgets.get('aws_profile')
aws_arn=dbutils.widgets.get('aws_arn')
from_email=dbutils.widgets.get('from_email')

# COMMAND ----------

# make the variable available to shell
import os
os.environ["AWS_PROFILE_VAR"] = aws_profile
os.environ["AWS_ARN"] = aws_arn

# COMMAND ----------

# MAGIC %sh
# MAGIC aws configure set region us-west-2 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set s3.signature_version s3v4 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile $AWS_PROFILE_VAR
# MAGIC aws configure set role_arn $AWS_ARN --profile $AWS_PROFILE_VAR
# MAGIC
# MAGIC aws configure set region us-west-2 --profile databricks-fng-prod
# MAGIC aws configure set s3.signature_version s3v4 --profile databricks-fng-prod
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile databricks-fng-prod
# MAGIC aws configure set role_arn arn:aws:iam::640862407089:role/fng-dmo-prod-databricks-ec2-role --profile databricks-fng-prod

# COMMAND ----------


from googleads import ad_manager, oauth2, errors
import boto3
import os
from datetime import datetime, timedelta
from dataclasses import dataclass
from typing import List, Optional, Any, cast
import json
import tempfile
from datetime import datetime, date,timedelta
import pytz
import time
import pandas as pd
from pyspark.sql import SparkSession
import pyspark.sql.types as T
import pyspark.sql.functions as F
from pyspark import SparkFiles
import io
from email import encoders
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests

# COMMAND ----------

aws_profile = f'{aws_profile}'
APPLICATION_NAME = 'Campaign Pacing - Validations'
NETWORK_CODE = 4145

spark = SparkSession.builder.appName('Campaign Pacing - Validations').getOrCreate()
spark.conf.set("spark.sql.session.timeZone", "UTC")

# COMMAND ----------

def get_ad_manager_client(secret_arn: str) -> Any:
    session = boto3.Session(profile_name=aws_profile)
    resp = session.client('secretsmanager').get_secret_value(SecretId=secret_arn)
    secret = json.loads(resp['SecretString'])

    with tempfile.NamedTemporaryFile(mode='w', delete=False) as secret_file:
        json.dump(secret, secret_file, indent=2)
        secret_file.close()

    oauth2_client = oauth2.GoogleServiceAccountClient(secret_file.name, oauth2.GetAPIScope('ad_manager'))
    os.unlink(secret_file.name)
    ad_manager_client = ad_manager.AdManagerClient(oauth2_client, APPLICATION_NAME, NETWORK_CODE)

    return ad_manager_client

# COMMAND ----------

def format_datetime_to_obj(datetime_obj: Any) -> Any:
    obj = {}
    obj['year'] = datetime_obj.year
    obj['month'] = datetime_obj.month
    obj['day'] = datetime_obj.day
    return obj

def generate_processing_dates(start_date: datetime, end_date: datetime, step_size: int) -> list:
    processing_dates = []

    batch_start_date = start_date
    while batch_start_date <= end_date:
        batch_end_date = batch_start_date + timedelta(days=step_size - 1)
        if batch_end_date <= end_date:
            processing_dates.append((batch_start_date, batch_end_date))
        else:
            processing_dates.append((batch_start_date, end_date))
            break
        batch_start_date += timedelta(days=step_size)

    return processing_dates

def build_report_query(dimensions: list, columns: list, dimensionAttributes: list, start_date: datetime, end_date: datetime, filter: dict = None) -> Any:
    baseReportQuery = {
        'dimensions': [],
        'adUnitView': 'FLAT',
        'columns': [],
        'dimensionAttributes': [],
        'customFieldIds': [],
        'cmsMetadataKeyIds': [],
        'customDimensionKeyIds': [],
        'startDate': {},
        'endDate': {},
        'dateRangeType': 'CUSTOM_DATE',
        'statement': None,
        'reportCurrency': 'USD',
        'timeZoneType': 'PUBLISHER'
    }

    report_query = baseReportQuery
    report_query['dimensions'] = dimensions
    report_query['columns'] = columns
    report_query['dimensionAttributes'] = dimensionAttributes
    report_query['startDate'] = format_datetime_to_obj(start_date)
    report_query['endDate'] = format_datetime_to_obj(end_date)

    if filter:
        filter_field = next(iter(filter))
        filter_values = filter[filter_field]
        placeholders = [f':lin{i}' for i in range(len(filter_values))]
        report_query['statement'] = {
            'query': f'WHERE {filter_field} IN ({",".join(placeholders)})',
            'values': [
                {'key': f'lin{i}', 'value': {'xsi_type': 'TextValue', 'value': name}}
                for i, name in enumerate(filter_values)
            ]
        }

    return report_query


# COMMAND ----------

def format_report(report_data: Any, report_type: str) -> Any:
    if report_type == 'GAM Campaign Pacing Data Validation Report':
        format_columns = {
            'Dimension.ORDER_ID': ('order_id', T.LongType()),
            'Dimension.ORDER_NAME': ('order_name', T.StringType()),
            'Dimension.LINE_ITEM_ID': ('line_item_id', T.LongType()),
            'Dimension.LINE_ITEM_TYPE': ('line_item_type', T.StringType()),
            'Dimension.ADVERTISER_NAME': ('advertiser_name', T.StringType()),
            'Dimension.DATE': ('date', T.TimestampType()),
            'DimensionAttribute.ORDER_END_DATE_TIME': ('order_end_date', T.TimestampType()),
            'DimensionAttribute.LINE_ITEM_START_DATE_TIME': ('line_item_start_date', T.TimestampType()),
            'DimensionAttribute.LINE_ITEM_END_DATE_TIME': ('line_item_end_date', T.TimestampType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS': ('total_impressions', T.LongType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_CLICKS': ('total_clicks', T.LongType()),
            'Column.VIDEO_VIEWERSHIP_START': ('video_views', T.LongType()),
            'Column.VIDEO_VIEWERSHIP_COMPLETE': ('video_completes', T.LongType())
        }
        select_cols = [
            'order_id',
            'order_name',
            'line_item_id',
            'line_item_type',
            'advertiser_name',
            'date',
            'order_end_date',
            'line_item_start_date',
            'line_item_end_date',
            'total_impressions',
            'total_clicks',
            'video_views',
            'video_completes'
        ]

    for k, v in format_columns.items():
        report_data = report_data.withColumnRenamed(k, v[0])
        report_data = report_data.withColumn(v[0], F.col(v[0]).try_cast(v[1]))

    report_data = report_data.select(select_cols).dropDuplicates()

    return report_data

# COMMAND ----------

class NotebookData:
    #to run the notebooks in parallel 
    def __init__(self, path, timeout, parameters=None, retry=0):
        self.path = path
        self.timeout = timeout
        self.parameters = parameters
        self.retry = retry


    def submitNotebook(notebook):
        try:
            if (notebook.parameters):
                return dbutils.notebook.run(notebook.path, notebook.timeout, notebook.parameters)
            else:
                return dbutils.notebook.run(notebook.path, notebook.timeout)
        except Exception:
            raise SystemExit("Failed!")

#this function is to run noteboks in parallel
def parallelNotebooks(notebooks, numInParallel):
    with ThreadPoolExecutor(max_workers=numInParallel) as ec:
        return [ec.submit(NotebookData.submitNotebook, notebook) for notebook in notebooks]

# COMMAND ----------

def get_validation_status(validation_df):
    return True

# COMMAND ----------

columnMapping = {
    'Ad_Server' : 'ad_server_view',
    'AOS_Deal_ID' : 'aos_deal_id_view',
    'AOS_Deal_Line_Item_ID' : 'aos_deal_line_item_id_view',
    'AOS_Deal_Line_Item_Name' : 'aos_deal_line_item_name_view',
    'AOS_Deal_Name' : 'aos_deal_name_view',
    'Campaign_ID' : 'campaign_id',
    'Campaign_Status' : 'campaign_status_view',
    'Day_of_Campaign_End_Date' : 'day_of_campaign_end_date_view',
    'Day_of_Campaign_Start_Date' : 'day_of_campaign_start_date_view',
    'Demand_Type' : 'demand_type_view',
    'Demo_Band' : 'demo_band_view',
    'Line_Item_or_Placement_End_Date' : 'line_item_or_placement_end_date_view',
    'Line_Item_or_Placement_ID' : 'placement_id',
    'Line_Item_or_Placement_Name' : 'line_item_or_placement_name_view',
    'Line_Item_or_Placement_Start_Date' : 'line_item_or_placement_start_date_view',
    'Out_of_Flight_Flag' : 'out_of_flight_flag_view',
    'Package_Name' : 'package_name_view',
    'Placement_Avg_User_Frequency' : 'placement_avg_user_frequency_view',
    '1P_Click_Thru' : 'first_party_click_thru_view',
    '1P_Clicks' : 'first_party_delivered_clicks_view',
    '1P_Impressions' : 'first_party_delivered_impressions_view',
    '1P_Pacing_%' : 'first_party_pacing_pct_view',
    '1P_Revenue' : 'first_party_delivered_revenue_view',
    '1P_VCR' : 'first_party_vcr_view',
    '3P_Click_Thru' : 'third_party_click_thru_view',
    '3P_Clicks' : 'third_party_clicks_view',
    '3P_Impressions' : 'third_party_impressions_view',
    '3P_Pacing_%' : 'third_party_pacing_pct_view',
    '3P_Revenue' : 'third_party_revenue_view',
    '3P_VCR' : 'third_party_vcr_view',
    '3P_Video_Completes' : 'third_party_video_completes_view',
    'Billable_Revenue' : 'billable_revenue_view',
    'Campaign_Billable_Impressions' : 'campaign_billable_impressions_view',
    'Campaign_Delivered_%' : 'campaign_del_pct_view',
    'Campaign_Pacing_%' : 'campaign_pacing_pct_view',
    'Cov' : 'cov_view',
    'campaign_days' : 'campaign_days_view',
    'days_to_date' : 'days_to_date_view',
    'daily_impression_goal' : 'daily_impression_goal_view',
    'impression_goal_to_date' : 'impression_goal_to_date_view',
    'Guaranteed_impressions' : 'guaranteed_impressions_view',
    'Guaranteed_Revenue' : 'guaranteed_revenue_view',
    'Net_Unit_Cost' : 'net_unit_cost_view',
    'Out_of_Flight_Impressions' : 'out_of_flight_impressions_view',
    'Pacing_Discrepency' : 'pacing_discrepency_view',
    'Reach' : 'reach_view',
    'Risk' : 'risk_view',
    'Under_vs_Over_Delivery' : 'under_vs_over_delivery_view',
    'Video_Completes' : 'video_completes_view',
    'Video_Starts' : 'video_starts_view',
}

# COMMAND ----------

if __name__ == '__main__':
    gam_service_account_creds_secret_arn = dbutils.widgets.get('gam_service_account_creds_secret_arn')
    gam_api_version = dbutils.widgets.get('gam_api_version')

    client = get_ad_manager_client(secret_arn=gam_service_account_creds_secret_arn)
    timezone = pytz.timezone("UTC")
    event_start_date = datetime.strptime('2024-01-01', '%Y-%m-%d').replace(tzinfo=timezone)
    event_end_date = datetime.today().replace(tzinfo=timezone) - timedelta(days=2)

    process_days = (event_end_date - event_start_date).days
    processing_dates = generate_processing_dates(event_start_date, event_end_date, 120)

    dev_catalog_name = dbutils.widgets.get('dev_catalog_name')
    qa_catalog_name = dbutils.widgets.get('qa_catalog_name')
    prod_catalog_name = dbutils.widgets.get('prod_catalog_name')
    cpe_s3_bucket = dbutils.widgets.get('cpe_s3_bucket')

    num_workers = int(dbutils.widgets.get('num_workers'))
    # GAM Campaign Pacing Data Validation Report
    print('Fetching GAM Campaign Pacing Source Data')
    for i, batch in enumerate(processing_dates):
        start_date, end_date = batch
        print(f"Processing {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}, batch - {i}", end=' ')
        report_service = client.GetService('ReportService', version=gam_api_version)
        report_query = build_report_query(
            dimensions=[
                'ORDER_ID',
                'ORDER_NAME',
                'LINE_ITEM_ID',
                'LINE_ITEM_TYPE',
                'ADVERTISER_NAME',
                'DATE'
            ],
            columns=[
                'TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS',
                'TOTAL_LINE_ITEM_LEVEL_CLICKS',
                'VIDEO_VIEWERSHIP_START',
                'VIDEO_VIEWERSHIP_COMPLETE'
            ],
            dimensionAttributes=[
                'ORDER_END_DATE_TIME',
                'LINE_ITEM_START_DATE_TIME',
                'LINE_ITEM_END_DATE_TIME'
            ],
            start_date=start_date,
            end_date=end_date
            # ,filter={
            #     'LINE_ITEM_TYPE': ['SPONSORSHIP', 'STANDARD', 'BULK']
            # }
        )
        report_job = report_service.runReportJob({'reportQuery': report_query})

        while True:
            status = report_service.getReportJobStatus(report_job['id'])
            if status == 'COMPLETED':
                break
            elif status == 'FAILED':
                break
            else:
                time.sleep(7)

        if status == 'COMPLETED':
            print('Downloading...', end=' ')
            report_download_url = report_service.getReportDownloadURL(report_job['id'], 'CSV_DUMP')
            report_data = spark.createDataFrame(pd.read_csv(report_download_url, compression='gzip'))
            if i == 0:
                gam_source_data_df = format_report(report_data, 'GAM Campaign Pacing Data Validation Report')
            else:
                gam_source_data_df = gam_source_data_df.union(
                    format_report(report_data, 'GAM Campaign Pacing Data Validation Report')
                )
            print('Completed')
        else:
            raise Exception('Report job failed')

    oms_source_query = f"""
        SELECT DISTINCT
            TRY_CAST(ps_line_item_id AS BIGINT) AS external_ad_id,
            TRY_CAST(sales_order_id AS BIGINT) AS aos_deal_id,
            NVL(CASE
                WHEN billable_third_party_descr = 'DCM' THEN 'FOX DCM'
                WHEN billable_third_party_descr = 'Doubleverify' THEN 'FOX Doubleverify'
                WHEN billable_third_party_descr = 'Innovid' THEN 'FOX Innovid'
                WHEN billable_third_party_descr = 'Flashtalking' THEN 'FOX Flashtalking'
                WHEN billable_third_party_descr = 'Extreme Reach' THEN 'FOX Extreme Reach'
                WHEN billable_third_party_descr = 'Sizmek' THEN 'FOX Sizmek'
                WHEN billable_third_party_descr = '1st Party' THEN 'FOX 1st Party'
                ELSE billable_third_party_descr
            END, 'N/A') billable_third_party_server,
            unit_type,
            cost_method_name,
            product_name,
            agency_name,
            fw_rbp_advanced,
            order_end_dt AS deal_end_date,
            order_start_dt AS deal_start_date,
            net_unit_cost_amt AS net_unit_cost,
            sales_order_line_items_qty as guaranteed_impressions,
            net_cost_amt AS guaranteed_revenue
        FROM {prod_catalog_name}.gold_ad_sales.ft_digital_operative_line_date_allocation
    """
    oms_source_df = spark.sql(oms_source_query)

    gam_source_df = gam_source_data_df.join(
        oms_source_df,
        (gam_source_data_df.line_item_id == oms_source_df.external_ad_id),
        how='left'
    )

    gam_source_df = gam_source_df.fillna(0, subset=[
        'total_impressions',
        'total_clicks',
        'video_views',
        'video_completes',
        'net_unit_cost'
    ])

    gam_source_df = gam_source_df.fillna(-1, subset=[
        'aos_deal_id'
    ])

    gam_source_df.createOrReplaceTempView('gam_source_df')

    filtered_agg_gam_df_query = """ 
        WITH ft_pacing_with_day_flags AS (
            SELECT
                *,
                MAX(CASE WHEN total_impressions > 0 THEN 1 ELSE 0 END)
                    OVER (PARTITION BY Line_Item_ID, aos_deal_id, date) AS _is_day_live,
                ROW_NUMBER()
                    OVER (PARTITION BY Line_Item_ID, aos_deal_id, date
                        ORDER BY date) AS _rn_per_day
            FROM gam_source_df
            where (
        CASE
            WHEN ((LOWER(advertiser_name) LIKE '%promo%') OR (LOWER(advertiser_name) LIKE '% test%')) THEN FALSE
            WHEN ((LOWER(order_name) LIKE '%promo%') OR (LOWER(order_name) LIKE '% test%')) THEN FALSE
            WHEN ((LOWER(agency_name) LIKE '%promo%') OR (LOWER(agency_name) LIKE '% test%')) THEN FALSE
            ELSE TRUE
        END
    )            )
    ,agg_metrics AS (
            SELECT
                order_id,
                order_name,
                date,
                line_item_id,
                line_item_type,
                line_item_start_date,
                line_item_end_date,
                billable_third_party_server,
                unit_type,
                cost_method_name,
                product_name,
                fw_rbp_advanced,
                MAX(date::date) OVER (PARTITION BY Line_Item_ID, aos_deal_id) AS max_event_date,
                SUM(total_impressions) AS total_impressions,
                SUM(total_clicks) AS total_clicks,
                SUM(video_views) AS video_views,
                SUM(video_completes) AS video_completes,
                CASE
                    WHEN line_item_type = 'SPONSORSHIP' 
                        THEN net_unit_cost
                    ELSE (SUM(total_impressions) * net_unit_cost) / 1000
                END AS total_revenue,
                external_ad_id,
                aos_deal_id,
                deal_start_date,
                deal_end_date,
                net_unit_cost,
                guaranteed_impressions,
                guaranteed_revenue,
                CASE 
                    WHEN MAX(date) OVER (PARTITION BY Line_Item_ID, aos_deal_id) < COALESCE(Line_Item_End_Date::date, deal_end_date::date) 
                        THEN (date_diff(
                                MAX(date) OVER (PARTITION BY Line_Item_ID, aos_deal_ID),
                                COALESCE(Line_Item_Start_Date::date, deal_Start_Date::date)
                            ) + 1) / (
                                date_diff(
                                    COALESCE(Line_Item_End_Date::date, deal_End_Date::date),
                                    COALESCE(Line_Item_Start_Date::date, deal_Start_Date::date)
                                ) + 1
                            )
                    ELSE 1
                END AS OSI_TOTAL
            FROM ft_pacing_with_day_flags
            GROUP BY Line_Item_ID, aos_deal_id, date, order_id, order_name, line_item_id, line_item_type, line_item_start_date, line_item_end_date, external_ad_id, billable_third_party_server, unit_type, cost_method_name, product_name, fw_rbp_advanced, deal_start_date, deal_end_date, net_unit_cost, guaranteed_impressions, guaranteed_revenue, _rn_per_day, _is_day_live
        )
        SELECT
            'GAM' AS data_source,
            aos_deal_id,
            external_ad_id,
            deal_start_date,
            deal_end_date,
            CASE 
                WHEN deal_end_date > current_timestamp() - INTERVAL 1 DAY 
                    THEN 'Active'
                ELSE 'Closed'
            END AS campaign_status,
            billable_third_party_server,
            unit_type,
            cost_method_name,
            product_name,
            fw_rbp_advanced,
            max_event_date,
            net_unit_cost,
            guaranteed_impressions,
            guaranteed_revenue,
            line_item_id,
            line_item_type,
            line_item_start_date,
            line_item_end_date,
            MIN(osi_total) AS osi_total,
            date AS event_date,
            SUM(total_impressions) AS total_impressions,
            SUM(total_clicks) AS total_clicks,
            SUM(video_views) AS video_views,
            SUM(video_completes) AS video_completes,
            SUM(total_revenue) AS total_revenue
        FROM agg_metrics
        GROUP BY ALL
    """

    filtered_agg_gam_df = spark.sql(filtered_agg_gam_df_query)

    spark.sql(f"DROP TABLE IF EXISTS {prod_catalog_name}.bronze_ads.source_first_party_data_pacing_gam")
    filtered_agg_gam_df.write.format('delta') \
        .mode('overwrite') \
        .partitionBy('data_source') \
        .option('mergeSchema', 'true') \
        .option('overwriteDynamicPartitions', 'true') \
        .option('delta.enableDeletionVectors', 'false') \
        .option('delta.enableIcebergCompatV2', 'true') \
        .option('delta.universalFormat.enabledFormats', 'iceberg') \
        .option('delta.columnMapping.mode', 'name') \
        .saveAsTable(f'{prod_catalog_name}.bronze_ads.source_first_party_data_pacing_gam')

    # Freewheel Campaign Pacing Data
    print('Fetching Freewheel Campaign Pacing Source Data')
    freewheel_source_first_party_data_query = """
    WITH fw_del AS (
    SELECT
        *,
        COALESCE(placement_id, deal_id, mrm_rule_id, sold_order_id, exchange_listing_id, Campaign_ID) AS fw_id,
        COALESCE(placement_name, deal_name, mrm_rule_name, sold_order_name, exchange_listing_name, Campaign_Name) AS fw_name,
        COALESCE(
            placement_start_timestamp_est::date,
            deal_start_timestamp_est::date,
            mrm_rule_start_timestamp_est::date,
            sold_order_start_timestamp_est::date,
            exchange_listing_start_timestamp_est::date,
            campaign_start_timestamp_est::date
        ) AS fw_start_date,
        COALESCE(
            placement_end_timestamp_est::date,
            deal_end_timestamp_est::date,
            mrm_rule_end_timestamp_est::date,
            sold_order_end_timestamp_est::date,
            exchange_listing_end_timestamp_est::date,
            campaign_end_timestamp_est::date
        ) AS fw_end_date,
        MAX(CASE WHEN net_counted_ads > 0 THEN 1 ELSE 0 END)
            OVER (
                PARTITION BY placement_id, deal_id, mrm_rule_id, sold_order_id, exchange_listing_id, Campaign_ID, Event_Date
            ) AS _is_day_live,
        ROW_NUMBER()
            OVER (
                PARTITION BY placement_id, deal_id, mrm_rule_id, sold_order_id, exchange_listing_id, Campaign_ID, Event_Date
                ORDER BY Event_Date
            ) AS _rn_per_day
    FROM fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily
    ),
    fw_on_tar_imps_base AS (
        SELECT
            camp.event_date AS event_date,
            COALESCE(camp.Campaign_ID, deal_id, mrm_rule_id, sold_order_id, exchange_listing_id) AS campaign_id,
            Campaign_Name,
            COALESCE(campaign_start_timestamp_est::date, deal_start_timestamp_est::date) AS campaign_start_date,
            COALESCE(campaign_end_timestamp_est::date, deal_end_timestamp_est::date) AS campaign_end_date,
            camp.placement_id,
            camp.ps_line_item_id AS external_ad_id,
            Placement_Name,
            placement_start_timestamp_est::date AS placement_start_date,
            placement_end_timestamp_est::date AS placement_end_date,
            NVL(CASE
                WHEN billable_third_party_description = 'DCM' THEN 'FOX DCM'
                WHEN billable_third_party_description = 'Doubleverify' THEN 'FOX Doubleverify'
                WHEN billable_third_party_description = 'Innovid' THEN 'FOX Innovid'
                WHEN billable_third_party_description = 'Flashtalking' THEN 'FOX Flashtalking'
                WHEN billable_third_party_description = 'Extreme Reach' THEN 'FOX Extreme Reach'
                WHEN billable_third_party_description = 'Sizmek' THEN 'FOX Sizmek'
                WHEN billable_third_party_description = '1st Party' THEN 'FOX 1st Party'
                ELSE billable_third_party_description
            END, 'N/A') AS billable_third_party_server,
            CASE
                WHEN COALESCE(
                    COALESCE(campaign_start_timestamp_est::date, deal_start_timestamp_est::date),
                    COALESCE(campaign_end_timestamp_est::date, deal_end_timestamp_est::date)
                ) > current_timestamp() - INTERVAL 1 DAY
                THEN 'Active'
                ELSE 'Closed'
            END AS campaign_status,
            CASE
                WHEN camp.event_date NOT BETWEEN COALESCE(campaign_start_timestamp_est::date, deal_start_timestamp_est::date)
                    AND COALESCE(campaign_end_timestamp_est::date, deal_end_timestamp_est::date)
                THEN net_counted_ads
                ELSE 0
            END AS out_of_flight_impressions,
            placement_avg_user_frequency,
            sales_channel_type AS demand_type,
            budget_model,
            Demo_Band,
            unit_type,
            cost_method_name,
            product_name,
            fw_rbp_advanced,
            dc.booked_on_target_impression_goal,
            dc.impression_goal,
            placement_delivered_demo_comp AS demo_comp,
            Delivered_Clicks,
            net_counted_ads AS delivered_impressions,
            0 AS video_completes,
            0 AS video_starts,
            run_revenue_amount AS delivered_revenue,
            MIN(on_target_net_delivered_impressions_quantity) OVER (
                PARTITION BY camp.placement_id, camp.event_date
            ) AS min_on_target_net_delivered_impressions
        FROM fw_del camp
        LEFT JOIN (
            SELECT
                event_date,
                placement_id,
                campaign_id,
                advertiser_name,
                agency_name,
                insertion_order_id,
                placement_booked_on_target_impression_goal booked_on_target_impression_goal ,
                impression_goal_quantity impression_goal, 
                SUM(on_target_net_delivered_impressions_quantity) AS on_target_net_delivered_impressions_quantity
            FROM fox_bi_prod.gold_ad_sales.ft_freewheel_demo_comp_daily
            WHERE event_date::date >= '2024-01-01'
            GROUP BY ALL
        ) dc
            ON dc.placement_id = camp.placement_id
            AND dc.campaign_id = camp.campaign_id
            AND dc.advertiser_name = camp.advertiser_name
            AND dc.agency_name = camp.agency_name
            AND dc.insertion_order_id = camp.insertion_order_id
            AND dc.event_date = camp.event_date
        WHERE camp.event_date >= '2024-01-01'::date
    ),
    min_fw_on_tar_imps_data AS (
        SELECT
            event_date,
            campaign_id,
            campaign_start_date,
            campaign_end_date,
            placement_id,
            external_ad_id,
            placement_start_date,
            placement_end_date,
            billable_third_party_server,
            campaign_status,
            out_of_flight_impressions,
            placement_avg_user_frequency,
            demand_type,
            budget_model,
            demo_band,
            unit_type,
            cost_method_name,
            product_name,
            fw_rbp_advanced,
            booked_on_target_impression_goal,
            impression_goal,
            demo_comp,
            SUM(delivered_clicks) AS del_clicks,
            SUM(delivered_impressions) AS del_imps,
            SUM(delivered_revenue) AS del_rev,
            SUM(video_completes) AS video_completes,
            SUM(video_starts) AS video_starts,
            COALESCE(MIN(min_on_target_net_delivered_impressions), 0) AS on_tar_imps
        FROM fw_on_tar_imps_base
        GROUP BY ALL
    ),
    op1 AS (
        SELECT
            TRY_CAST(ps_line_item_id AS BIGINT) AS line_item_id,
            TRY_CAST(sales_order_id AS BIGINT) AS aos_deal_id,
            net_cost_amt AS guaranteed_revenue,
            net_unit_cost_amt,
            sales_order_line_items_qty AS guaranteed_impressions
        FROM fox_bi_prod.gold_ad_sales.ft_digital_operative_line_date_allocation
        WHERE ps_line_item_id NOT IN (
            237823, 237818, 272555, 237817, 237812, 237822, 237816, 272554, 237821, 237813, 237814, 237811, 237824, 237819
        )
        GROUP BY ALL
    )
    SELECT
        'FREEWHEEL' AS data_source,
        aos_deal_id,
        external_ad_id,
        campaign_id,
        campaign_start_date,
        campaign_end_date,
        campaign_status,
        COALESCE(placement_id, -1) AS placement_id,
        placement_start_date,
        placement_end_date,
        billable_third_party_server,
        unit_type,
        cost_method_name,
        product_name,
        fw_rbp_advanced,
        UPPER(demand_type) AS demand_type,
        budget_model,
        placement_avg_user_frequency,
        demo_band,
        demo_comp,
        booked_on_target_impression_goal,
        impression_goal,
        MAX(guaranteed_impressions) AS guaranteed_impressions,
        MAX(guaranteed_revenue) AS guaranteed_revenue,
        MAX(net_unit_cost_amt) AS net_unit_cost,
        0 AS OSI_total,
        event_date,
        SUM(del_clicks) AS first_party_delivered_clicks,
        SUM(del_imps) AS first_party_delivered_impressions,
        SUM(del_rev) AS first_party_delivered_revenue,
        SUM(DISTINCT on_tar_imps) AS on_target_net_delivered_impressions,
        SUM(video_completes) AS video_completes,
        SUM(video_starts) AS video_starts
    FROM min_fw_on_tar_imps_data fw_data
    LEFT JOIN op1
        ON COALESCE(fw_data.placement_id, campaign_id) = op1.line_item_id
    GROUP BY
        aos_deal_id,
        external_ad_id,
        campaign_id,
        campaign_start_date,
        campaign_end_date,
        campaign_status,
        placement_id,
        placement_start_date,
        placement_end_date,
        billable_third_party_server,
        unit_type,
        cost_method_name,
        product_name,
        fw_rbp_advanced,
        demand_type,
        budget_model,
        placement_avg_user_frequency,
        demo_band,
        demo_comp,
        booked_on_target_impression_goal,
        impression_goal,
        event_date
    """

    freewheel_source_df = spark.sql(freewheel_source_first_party_data_query)
    freewheel_source_df = freewheel_source_df.withColumn('data_source', F.lit('FREEWHEEL').cast(T.StringType()))

    spark.sql(f"DROP TABLE IF EXISTS {prod_catalog_name}.bronze_ads.source_first_party_data_pacing_fw")
    freewheel_source_df.write.format('delta')\
        .mode('overwrite')\
        .partitionBy('data_source')\
        .option('mergeSchema', 'true')\
        .option('overwriteDynamicPartitions', 'true')\
        .option('delta.enableDeletionVectors', 'false')\
        .option('delta.enableIcebergCompatV2', 'true')\
        .option('delta.universalFormat.enabledFormats', 'iceberg')\
        .option('delta.columnMapping.mode', 'name')\
        .saveAsTable(f'{prod_catalog_name}.bronze_ads.source_first_party_data_pacing_fw')
    
    # Third Party Campaign Pacing Data
    print('Fetching Third Party Campaign Pacing Source Data')
    third_party_df_query = f"""
        WITH op_line_detail AS (
            SELECT
                sales_order_id AS aos_deal_id,
                TRY_CAST(ps_line_item_id AS BIGINT) AS line_item_id,
                CASE
                    WHEN billable_third_party_descr = 'DCM' THEN 'FOX DCM'
                    WHEN billable_third_party_descr = 'Doubleverify' THEN 'FOX Doubleverify'
                    WHEN billable_third_party_descr = 'Innovid' THEN 'FOX Innovid'
                    WHEN billable_third_party_descr = 'Flashtalking' THEN 'FOX Flashtalking'
                    WHEN billable_third_party_descr = 'Extreme Reach' THEN 'FOX Extreme Reach'
                    WHEN billable_third_party_descr = 'Sizmek' THEN 'FOX Sizmek'
                    WHEN billable_third_party_descr = '1st Party' THEN 'FOX 1st Party'
                    ELSE billable_third_party_descr
                END AS billable_third_party_server,
                net_unit_cost_amt AS net_unit_cost,
                net_cost_amt AS guaranteed_revenue
            FROM fox_bi_prod.gold_ad_sales.ft_digital_operative_line_date_allocation
            WHERE 1 = 1 
            AND ps_line_item_id IS NOT NULL
            GROUP BY ALL
        ),
        third_party_delivery AS (
            SELECT
                event_date,
                creative_id,
                ad_unit_id,
                campaign_id line_item_id,
                SUM(third_party_billable_impressions) AS third_party_impressions,
                SUM(third_party_revenue) AS third_party_revenue,
                SUM(clicks_third_party) AS third_party_clicks,
                SUM(third_party_video_views) AS third_party_video_views,
                sum(third_party_video_100_percent_complete) AS third_party_video_completes,
                CASE
                    WHEN third_party_billable_server = 'Moat' THEN 'Moat'
                    WHEN third_party_billable_server IN ('DFA by Google', 'Dart Report Reader', 'Dart Report Reader, DFA by Google', 'DFP by Google') THEN 'FOX DCM'
                    WHEN third_party_billable_server = 'DoubleVerify' THEN 'FOX Doubleverify'
                    WHEN third_party_billable_server = 'Innovid 3rd Party' THEN 'FOX Innovid'
                    WHEN third_party_billable_server IN ('FlashTalking', 'FlashTalking Email Reader') THEN 'FOX Flashtalking'
                    WHEN third_party_billable_server IN ('Extreme Reach Email', 'ExtremeReachAPI') THEN 'FOX Extreme Reach'
                    WHEN third_party_billable_server IN ('MediaMind', 'MediaMind Report Reader', 'Sizmek SAS Report Reader','MediaMind Report Reader, Sizmek SAS Report Reader', 'Sizmek SAS Report Reader, MediaMind Report Reader') THEN 'FOX Sizmek'
                    WHEN third_party_billable_server = 'TubeMogul' THEN 'TubeMogul'
                    ELSE 'FOX 1st Party'
                END AS billable_third_party_server
            FROM {prod_catalog_name}.bronze_ads.third_party_campaign_reporting_delivery
            WHERE event_date BETWEEN '2024-01-01' AND  current_date()
            GROUP BY ALL
        ),
        third_party_agg_data AS (
            SELECT
                3p.event_date,
                3p.line_item_id,
                3p.creative_id,
                3p.ad_unit_id,
                SUM(3p.third_party_impressions) AS third_party_impressions,
                SUM(3p.third_party_revenue) AS third_party_revenue,
                SUM(3p.third_party_clicks) AS third_party_clicks,
                SUM(3p.third_party_video_views) AS third_party_video_views,
                SUM(3p.third_party_video_completes) as third_party_video_completes,
                3p.billable_third_party_server
            FROM third_party_delivery 3p
            LEFT JOIN op_line_detail op
            ON 3p.line_item_id = op.line_item_id
            AND 3p.billable_third_party_server = op.billable_third_party_server
            GROUP BY ALL
        ),
        gam_data AS (
            SELECT DISTINCT
                ad_date,
                line_item_id,
                line_item_type
            FROM {prod_catalog_name}.silver_ads.ft_gam_summary_daily_data
            WHERE ad_date BETWEEN '2024-01-01' AND current_date()
            -- AND line_item_type IN ('SPONSORSHIP', 'STANDARD', 'BULK')
            AND line_item_id <> -1
        ),
        freewheel_data AS (
            SELECT DISTINCT
                event_date,
                placement_id,
                ad_unit_id,
                global_ad_unit_position,
                creative_id
            FROM fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily
            WHERE event_date BETWEEN '2024-01-01' AND current_date()
            -- AND sales_channel_type in ('Direct Sold')
            -- AND COALESCE(campaign_name,'N/A') NOT ILIKE '%promo%'
            -- AND COALESCE(agency_name,'N/A') NOT IN ('FNG IN-HOUSE MARKETING & PROMOTIONS')
            -- AND COALESCE(advertiser_name,'N/A') NOT ILIKE '%promo%'
            -- AND COALESCE(advertiser_name,'N/A') NOT IN ('Placeholder Advertiser')
            -- AND COALESCE(agency_name,'N/A') NOT IN ('Placeholder Agency')
            -- AND COALESCE(TRY_CAST(ps_line_item_id AS BIGINT),-1) <> -1
            -- AND COALESCE(sales_order_line_item_name,'N/A') NOT ILIKE '%cancelled%'
        ),
        freewheel_3p AS (
            SELECT
                op.aos_deal_id,3p.line_item_id,
                fw.placement_id AS placement_or_line_item_id,
                fw.creative_id,
                fw.event_date,
                fw.global_ad_unit_position,
                3p.line_item_id,
                fw.ad_unit_id,
                coalesce(op.billable_third_party_server, 'N/A') billable_third_party_server,
                MAX(3p.third_party_impressions) AS third_party_impressions,
                CASE
                    WHEN 3p.line_item_id is not null AND MAX(3p.third_party_impressions) > 0 THEN MAX(3p.third_party_revenue)
                    ELSE 0
                END AS third_party_revenue,
                MAX(3p.third_party_clicks) AS third_party_clicks,
                MAX(3p.third_party_video_views) AS third_party_video_views,
                MAX(3p.third_party_video_completes) as third_party_video_completes
            FROM freewheel_data fw
            LEFT JOIN op_line_detail op
            ON fw.placement_id = op.line_item_id
            LEFT JOIN third_party_agg_data 3p
            ON fw.creative_id = TRY_CAST(split_part(3p.creative_id,'-', 1) AS BIGINT)
            AND fw.ad_unit_id = 3p.ad_unit_id
            AND fw.event_date = 3p.event_date
            and coalesce(op.billable_third_party_server, 'N/A') = 3p.billable_third_party_server
            GROUP BY ALL
        ),
        gam_3p AS (
            SELECT
                op.aos_deal_id,
                COALESCE(gam.line_item_id, 3p.line_item_id) AS placement_or_line_item_id,
                SUM(3p.third_party_impressions) AS third_party_impressions,
                CASE WHEN 3p.line_item_id is not null AND SUM(3p.third_party_impressions) > 0 THEN case 
                    WHEN MAX(gam.line_item_type) = 'SPONSORSHIP' THEN MAX(guaranteed_revenue)
                    ELSE (SUM(3p.third_party_impressions) * MAX(net_unit_cost)) / 1000
                END else 0 end AS third_party_revenue,
                SUM(3p.third_party_clicks) AS third_party_clicks,
                SUM(3p.third_party_video_views) AS third_party_video_views,
                SUM(3p.third_party_video_completes) as third_party_video_completes
            FROM gam_data gam
            LEFT JOIN op_line_detail op
            ON gam.line_item_id = op.line_item_id
            LEFT JOIN third_party_agg_data AS 3p
            ON gam.ad_date = 3p.event_date
            AND gam.line_item_id = 3p.line_item_id
            and op.billable_third_party_server = 3p.billable_third_party_server
            GROUP BY op.aos_deal_id, gam.line_item_id, 3p.line_item_id
        )
        ,unified AS (
            SELECT
                aos_deal_id,
                placement_or_line_item_id,
                third_party_impressions,
                third_party_revenue,
                third_party_clicks,
                third_party_video_views,
                third_party_video_completes
            FROM freewheel_3p

            UNION ALL

            SELECT
                *
            FROM gam_3p)
            ,oms_3p_data AS (
            Select
                sales_order_id aos_deal_id,
                sales_order_line_item_id placement_or_line_item_id,
                case when  (oms.delivery_source ilike '%mercury%'
                            or oms.delivery_source ilike '%Megaphone%' 
                            or oms.delivery_source ilike '%Social%'
                            or oms.delivery_source ilike '%Amper%')
                            and oms.unit_type ilike 'Impressions'
                    then oms.third_party_delivery_imps
                    else 0 
                end as third_party_impressions,
                case when  (oms.delivery_source ilike '%mercury%'
                            or oms.delivery_source ilike '%Megaphone%' 
                            or oms.delivery_source ilike '%Social%'
                            or oms.delivery_source ilike '%Amper%')
                            and oms.unit_type ilike 'Impressions'
                    then (oms.third_party_delivery_imps/1000) * oms.net_unit_cost_amt
                    else 0
                end as third_party_revenue,
                case when  (oms.delivery_source ilike '%mercury%'
                            or oms.delivery_source ilike '%Megaphone%' 
                            or oms.delivery_source ilike '%Social%'
                            or oms.delivery_source ilike '%Amper%')
                            and oms.unit_type ilike 'Clicks'
                    then oms.third_party_delivery_imps
                    else 0 
                end as third_party_clicks,
                0 as third_party_video_views,
                0 as third_party_video_completes
            FROM fox_bi_prod.gold_ad_sales.ft_digital_operative_line_date_allocation oms
            WHERE oms.ps_line_item_id IS NOT NULL
             AND case when oms.delivery_source ilike '%mercury%'
                        then 'Mercury'
                        when oms.delivery_source ilike '%Megaphone%' 
                        then 'Megaphone'
                        when oms.delivery_source ilike '%Social%'
                        then 'Social Media'
                        when oms.delivery_source ilike '%Amper%'
                        then 'AmperWave'
                        else 'Non Ad Served' 
                    end <> 'Non Ad Served'
        ) 
        SELECT
            aos_deal_id,
            placement_or_line_item_id,
            SUM(third_party_impressions) AS total_third_party_impressions,
            SUM(third_party_revenue) AS total_third_party_revenue,
            SUM(third_party_clicks) AS total_third_party_clicks,
            SUM(third_party_video_views) AS total_third_party_video_views,
            SUM(third_party_video_completes) as total_third_party_video_completes
        FROM unified
        WHERE 1 = 1
        GROUP BY ALL
    """
    third_party_df = spark.sql(third_party_df_query)

    spark.sql(f"DROP TABLE IF EXISTS {prod_catalog_name}.bronze_ads.source_third_party_data_pacing")
    third_party_df.write.format('delta')\
        .mode('overwrite')\
        .option('mergeSchema', 'true')\
        .option('overwriteDynamicPartitions', 'true')\
        .option('delta.enableDeletionVectors', 'false')\
        .option('delta.enableIcebergCompatV2', 'true')\
        .option('delta.universalFormat.enabledFormats', 'iceberg')\
        .option('delta.columnMapping.mode', 'name')\
        .saveAsTable(f'{prod_catalog_name}.bronze_ads.source_third_party_data_pacing')
    # Emplifi Data
    print('Fetching Emplifi Source Data')

    emplifi_source_query = """
    with emplifi_source as (
        select date,platform,video_view_count,total_impressions,engagements,post_labels_id, EXPLODE(
                    CASE 
                        WHEN FILTER(
                    SPLIT(REPLACE(post_labels_name, " ", ""), "_"),
                    x -> x RLIKE '^[0-9]+$'
                ) IS NULL OR SIZE(FILTER(
                    SPLIT(REPLACE(post_labels_name, " ", ""), "_"),
                    x -> x RLIKE '^[0-9]+$'
                )) = 0  
                        THEN ARRAY(NULL)         
                        ELSE FILTER(
                    SPLIT(REPLACE(post_labels_name, " ", ""), "_"),
                    x -> x RLIKE '^[0-9]+$'
                ) 
                    END
                ) AS deal_line_id 
                from fox_bi_prod.bronze_ad_sales.social_engagement_sports
                
            union all
        select date,platform,video_view_count,total_impressions,engagements,post_labels_id, EXPLODE(
                    CASE 
                        WHEN FILTER(
                    SPLIT(REPLACE(post_labels_name, " ", ""), "_"),
                    x -> x RLIKE '^[0-9]+$'
                ) IS NULL OR SIZE(FILTER(
                    SPLIT(REPLACE(post_labels_name, " ", ""), "_"),
                    x -> x RLIKE '^[0-9]+$'
                )) = 0  
                        THEN ARRAY(NULL)         
                        ELSE FILTER(
                    SPLIT(REPLACE(post_labels_name, " ", ""), "_"),
                    x -> x RLIKE '^[0-9]+$'
                ) 
                    END
                ) AS deal_line_id 
                from fox_bi_prod.bronze_ad_sales.social_engagement_btn
        ),
        aos_metrics as (
            select distinct 
                    aos.sales_order_id as aos_deal_id
                    ,UPPER(aos.sales_order_name) as aos_deal_name
                    ,UPPER(aos.sales_order_line_item_name) as aos_deal_line_item_name
                    ,aos.sales_order_line_item_id as aos_deal_line_item_id
                    ,date(aos.order_start_dt) as aos_Deal_start_date
                    ,date(aos.order_end_dt) as aos_Deal_end_date
                    ,date(aos.sales_order_line_item_start_dt) as aos_deal_line_item_start_date
                    ,date(aos.sales_order_line_item_end_dt) as aos_deal_line_item_end_date
                    ,UPPER(nvl(aos.advertiser_name,'N/A')) as aos_advertiser_name
                    ,UPPER(nvl(aos.agency_name,'N/A')) as aos_agency_name
                    ,nvl(aos.demo_band,'N/A') as demo_band
                    ,aos.net_unit_cost_amt as net_unit_cost
                    ,aos.sales_order_line_items_qty as guaranteed_impressions
                    ,aos.contracted_amount_net_lifetime as guaranteed_revenue
                    ,UPPER(nvl(aos.owner_name,'N/A')) as account_manager
                    ,UPPER(nvl(aos.package_name,'N/A'))  as package_name
                    ,UPPER(nvl(aos.account_coordinator,'N/A')) as account_coordinator
                    ,UPPER(nvl(aos.primary_salesperson_name,'N/A')) as account_executive
                    ,nvl(aos.billable_third_party_descr,'N/A') as billable_third_party_server
                    ,UPPER(nvl(aos.primary_property,'N/A')) as primary_property
                    ,UPPER(nvl(aos.opportunity_unique_id,'N/A')) as pitch_id
                    ,UPPER(nvl(aos.unit_type,'N/A')) as unit_type
                    ,UPPER(nvl(aos.cost_method_name,'N/A')) as cost_method_name
                    ,UPPER(nvl(aos.product_name,'N/A')) as product_name
                    ,UPPER(nvl(aos.fw_rbp_advanced,'N/A')) as fw_rbp_advanced
                    ,UPPER(nvl(aos.parent_line_item_name,'N/A')) as parent_line_item_name
                from
                fox_bi_prod.gold_ad_sales.ft_digital_operative_line_date_allocation aos
                where upper(aos.source) = 'AOS'
        )
        select 
        'EMPLIFI' as data_source,
        aos_deal_id,
        cast(null as string) as external_ad_id,
        aos_deal_id campaign_id,
        aos_deal_start_date campaign_start_date,
        aos_deal_end_date campaign_end_date,
        cast(null as string) campaign_status,
        concat(post_labels_id::string,'_',emp.deal_line_id::string)   as placement_id,
        emp.deal_line_id,
        billable_third_party_server,
        unit_type,
        cost_method_name,
        product_name,
        fw_rbp_advanced,
        aos_deal_line_item_start_date placement_start_date,
        aos_deal_line_item_end_date placement_end_date,
        'DIRECT SOLD' demand_type,
        0 placement_avg_user_frequency,
        demo_band,
        1 as demo_comp,
        guaranteed_impressions,
        guaranteed_revenue,
        net_unit_cost,
        0 AS OSI_total,
        emp.date AS event_date,
        0 as first_party_delivered_clicks,
        SUM(total_impressions) AS first_party_delivered_impressions,
        0 as first_party_delivered_revenue,
        0 as on_target_net_delivered_impressions,
        0 as video_completes,
        SUM(video_view_count) as video_starts,
        SUM(engagements) AS total_engagements
        from emplifi_source emp
                left join
                    aos_metrics aos
                    on emp.deal_line_id = CAST(aos.aos_deal_line_item_id AS STRING)
        where aos_deal_id is not null
        group by all
    """
    emplifi_source_df = spark.sql(emplifi_source_query)

    spark.sql(f"DROP TABLE IF EXISTS {prod_catalog_name}.bronze_ads.source_emplifi_data_pacing")
    emplifi_source_df.write.format('delta') \
        .mode('overwrite') \
        .option('mergeSchema', 'true') \
        .option('overwriteDynamicPartitions', 'true') \
        .option('delta.enableDeletionVectors', 'false') \
        .option('delta.enableIcebergCompatV2', 'true') \
        .option('delta.universalFormat.enabledFormats', 'iceberg') \
        .option('delta.columnMapping.mode', 'name') \
        .saveAsTable(f'{prod_catalog_name}.bronze_ads.source_emplifi_data_pacing')
    
    # GAM Sports Data
    print('Fetching GAM Sports Source Data')

    gam_sports_source_query = """
    with raw_gam_sports_data AS (
	 select
	 'GAM' as `Data_Source`,
	 event_date as `Event_Date`,
	 Order_ID as `Order_ID`,
	 Order_Name as `Order_Name`,
     advertiser_id,
	 Advertiser_Name as `Advertiser_Name`,
	 Business_Unit as `Business_Unit`,
	 Line_Item_ID as `Line_Item_or_Placement_ID`,
	 Line_Item_Name `Line_Item_or_Placement_Name`,
	 Line_Item_Type `Demand_Type`,
	 line_item_start_timestamp::date as `Line_Item_or_Placement_Start_Date`,
	 line_item_end_timestamp::date as `Line_Item_or_Placement_End_Date`,
     sum(total_impressions) `Delivered_Impressions`,
	 sum(total_cpm_and_cpc_revenue_usd)/1000000 `Delivered_Revenue`,
	 etl_created_at_timestamp_utc `Create_Timestamp`,
	 etl_updated_at_timestamp_utc `Modified_Timestamp`
    from fox_bi_prod.silver_ads.ft_sports_gam_ad_delivery_and_capacity cmp
    where line_item_id <> -1
    group by all)
    ,op1_data AS (
        SELECT
            source,
            date,
            sales_order_line_item_id AS AOS_Deal_Line_Item_ID,
            sales_order_line_item_name AS AOS_Deal_Line_Item_name,
            sales_order_line_item_start_dt::date AS AOS_Deal_Line_Item_start_date,
            sales_order_line_item_end_dt::date AS AOS_Deal_line_item_end_date,
            sales_order_id campaign_id,
            sales_order_name campaign_name,
            order_start_dt AS  Campaign_Start_Date,
            order_end_dt AS Campaign_End_Date,
            agency_name,
            advertiser_name,
            owner_name Account_Manager,
            primary_salesperson_name ,
            account_coordinator,
            package_name,
            ps_line_item_id External_AD_ID,
            parent_line_item_name,
            demo_band,
            CASE
                WHEN billable_third_party_descr = 'DCM' THEN 'FOX DCM'
                WHEN billable_third_party_descr = 'Doubleverify' THEN 'FOX Doubleverify'
                WHEN billable_third_party_descr = 'Innovid' THEN 'FOX Innovid'
                WHEN billable_third_party_descr = 'Flashtalking' THEN 'FOX Flashtalking'
                WHEN billable_third_party_descr = 'Extreme Reach' THEN 'FOX Extreme Reach'
                WHEN billable_third_party_descr = 'Sizmek' THEN 'FOX Sizmek'
                WHEN billable_third_party_descr = '1st Party' THEN 'FOX 1st Party'
                ELSE billable_third_party_descr
            END AS billable_third_party_server,
            primary_property,
            unit_type,
            cost_method_name,
            product_name,
            fw_rbp_advanced,
            opportunity_unique_id as pitch_id,
            net_unit_cost_amt AS net_unit_cost,
            net_cost_amt Guaranteed_Revenue,
            sales_order_line_items_qty AS Guaranteed_Impressions,
            CASE WHEN unit_type ilike 'Impressions' then  third_party_delivery_imps else 0 end third_party_delivery_imps,
            CASE WHEN unit_type ilike 'Impressions' then  ((third_party_delivery_imps/1000) * net_unit_cost_amt)  else 0 end as third_party_delivery_revenue,
            CASE WHEN unit_type ilike 'Clicks'then  third_party_delivery_imps else 0 end third_party_delivery_clicks
        FROM fox_bi_prod.gold_ad_sales.ft_digital_operative_line_date_allocation oms
        WHERE ps_line_item_id IS NOT NULL
        AND oms.date BETWEEN oms.sales_order_line_item_start_dt and oms.sales_order_line_item_end_dt
        GROUP BY ALL)
     ,ft_pacing_with_day_flags AS (
    SELECT
        *,
        MAX(CASE WHEN Delivered_Impressions > 0 THEN 1 ELSE 0 END)
            OVER (PARTITION BY Line_Item_or_Placement_ID, Campaign_ID, Event_Date) AS _is_day_live,
        ROW_NUMBER()
            OVER (PARTITION BY Line_Item_or_Placement_ID, Campaign_ID, Event_Date
                  ORDER BY Event_Date) AS _rn_per_day
    FROM raw_gam_sports_data gam
    left join op1_data oms
        ON oms.External_AD_ID = gam.line_item_or_placement_id
        AND oms.date = gam.event_date
    WHERE (
        CASE
            WHEN ((LOWER(gam.advertiser_name) LIKE '%promo%') OR (LOWER(gam.advertiser_name) LIKE '% test%')) THEN FALSE
            WHEN ((LOWER(gam.order_name) LIKE '%promo%') OR (LOWER(gam.order_name) LIKE '% test%')) THEN FALSE
            WHEN ((LOWER(oms.agency_name) LIKE '%promo%') OR (LOWER(oms.agency_name) LIKE '% test%')) THEN FALSE
            ELSE TRUE
        END
        )
     )
    ,final_gam_sports_data AS (
        select *,CASE 
        WHEN MAX(event_date) OVER (PARTITION BY Line_Item_or_Placement_ID, campaign_id) < COALESCE(Line_Item_or_Placement_End_Date::date, Campaign_End_Date::date) 
            THEN (date_diff(
                    MAX(event_date) OVER (PARTITION BY Line_Item_or_Placement_ID, campaign_id),
                    COALESCE(Line_Item_or_Placement_Start_Date::date, Campaign_Start_Date::date)
                ) + 1) / (
                    date_diff(
                        COALESCE(Line_Item_or_Placement_End_Date::date, Campaign_End_Date::date),
                        COALESCE(Line_Item_or_Placement_Start_Date::date, Campaign_Start_Date::date)
                    ) + 1
                )
        ELSE 1
    END OSI_total
    from ft_pacing_with_day_flags
    )
	 select
	 'GAM Sports' as `Data_Source`,
	 campaign_id AS `AOS_Deal_ID`,
	 External_AD_ID `External_AD_ID`,
     Campaign_ID as `Campaign_ID`,
	 Campaign_Start_Date::date as `Campaign_Start_Date`,
	 Campaign_End_Date::date as `Campaign_End_Date`,
	 case
        when Campaign_End_Date > current_timestamp() - INTERVAL 1 DAY then 'Active'
        else 'Closed' 
     end as `Campaign_Status`,
     OSI_Total ,
     event_date,
	 Line_Item_or_Placement_ID as `Placement_ID`,
	 Line_Item_or_Placement_Start_Date::date as `Placement_Start_Date`,
	 Line_Item_or_Placement_End_Date::date as `Placement_End_Date`,
     billable_third_party_server,
     unit_type,
     cost_method_name,
     product_name,
     fw_rbp_advanced,
	 demand_type `Demand_Type`,
     0 as `Placement_Avg_User_Frequency`,
	 demo_band `Demo_Band`,
     1 as demo_comp,
     guaranteed_impressions,
     guaranteed_revenue,
     net_unit_cost,
     MAX(event_date) max_event_date,
     sum(Delivered_Impressions) first_party_delivered_impressions,
     sum(delivered_revenue) first_party_delivered_revenue,
     sum(third_party_delivery_imps) third_party_billable_impressions,
     sum(third_party_delivery_clicks) third_party_clicks,
     sum(third_party_delivery_revenue) third_party_revenue,
	 Create_Timestamp `Create_Timestamp`,
	 Modified_Timestamp `Modified_Timestamp`
    from final_gam_sports_data
    group by all
    """
    gam_sports_source_df = spark.sql(gam_sports_source_query)

    spark.sql(f"DROP TABLE IF EXISTS {prod_catalog_name}.bronze_ads.source_gam_sports_data_pacing")
    gam_sports_source_df.write.format('delta') \
        .mode('overwrite') \
        .option('mergeSchema', 'true') \
        .option('overwriteDynamicPartitions', 'true') \
        .option('delta.enableDeletionVectors', 'false') \
        .option('delta.enableIcebergCompatV2', 'true') \
        .option('delta.universalFormat.enabledFormats', 'iceberg') \
        .option('delta.columnMapping.mode', 'name') \
        .saveAsTable(f'{prod_catalog_name}.bronze_ads.source_gam_sports_data_pacing')

    # Tubi Log Data
    print('Fetching Tubi Log Source Data')

    tubi_log_source_query = """
    WITH tb AS (
        SELECT
            ds,
            line_item_id,
            regexp_extract(line_item_name, '^([0-9]+)', 1) AS line_item_id_extracted,
            line_item_name,
            MAX(CASE WHEN campaign_id IS NOT NULL THEN campaign_name END) AS campaign_name,
            MAX(campaign_id) AS campaign_id,
            advertiser_id,
            advertiser_name,
            SUM(revenue) AS revenue,
            SUM(impressions) AS impressions
        FROM adrise_share_prod.ads_curated.v_ads_net_revenue_daily
        GROUP BY ALL
    ),
    oms AS (
        SELECT DISTINCT
            sales_order_id AS aos_deal_id,
            ps_line_item_id AS external_ad_id,
            order_start_dt::date AS campaign_start_date,
            order_end_dt::date AS campaign_end_date,
            sales_order_line_item_start_dt::date AS line_item_start_date,
            sales_order_line_item_end_dt::date AS line_item_end_date,
            NVL(CASE
                WHEN billable_third_party_descr = 'DCM' THEN 'FOX DCM'
                WHEN billable_third_party_descr = 'Doubleverify' THEN 'FOX Doubleverify'
                WHEN billable_third_party_descr = 'Innovid' THEN 'FOX Innovid'
                WHEN billable_third_party_descr = 'Flashtalking' THEN 'FOX Flashtalking'
                WHEN billable_third_party_descr = 'Extreme Reach' THEN 'FOX Extreme Reach'
                WHEN billable_third_party_descr = 'Sizmek' THEN 'FOX Sizmek'
                WHEN billable_third_party_descr = '1st Party' THEN 'FOX 1st Party'
                ELSE billable_third_party_descr
            END, 'N/A') AS billable_third_party_server,
            UPPER(NVL(unit_type, 'N/A')) AS unit_type,
            UPPER(NVL(cost_method_name, 'N/A')) AS cost_method_name,
            UPPER(NVL(product_name, 'N/A')) AS product_name,
            UPPER(NVL(fw_rbp_advanced, 'N/A')) AS fw_rbp_advanced,
            NVL(demo_band, 'N/A') AS demo_band,
            net_unit_cost_amt AS net_unit_cost,
            sales_order_line_items_qty AS guaranteed_impressions,
            net_cost_amt AS guaranteed_revenue
        FROM fox_bi_prod.gold_ad_sales.ft_digital_operative_line_date_allocation
        WHERE source <> 'OP1'
            AND ps_line_item_id IS NOT NULL
    )
    SELECT
        'Mercury' AS data_source,
        oms.aos_deal_id,
        oms.external_ad_id,
        tb.campaign_id,
        oms.campaign_start_date,
        oms.campaign_end_date,
        CASE WHEN oms.campaign_end_date > current_timestamp() - INTERVAL 1 DAY THEN 'Active' ELSE 'Closed' END AS campaign_status,
        tb.line_item_id AS placement_id,
        oms.line_item_start_date AS placement_start_date,
        oms.line_item_end_date AS placement_end_date,
        oms.billable_third_party_server,
        oms.unit_type,
        oms.cost_method_name,
        oms.product_name,
        oms.fw_rbp_advanced,
        'N/A' AS demand_type,
        'N/A' AS budget_model,
        'N/A' AS placement_avg_user_frequency,
        oms.demo_band,
        1 AS demo_comp,
        0 AS booked_on_target_impression_goal,
        0 AS impression_goal,
        oms.guaranteed_impressions,
        oms.guaranteed_revenue,
        oms.net_unit_cost,
        0 AS OSI_total,
        tb.ds::date AS event_date,
        0 AS first_party_delivered_clicks,
        tb.impressions AS first_party_delivered_impressions,
        tb.revenue AS first_party_delivered_revenue,
        0 AS on_target_net_delivered_impressions,
        0 AS video_completes,
        0 AS video_starts
    FROM tb
    LEFT JOIN oms
        ON tb.line_item_id_extracted = oms.external_ad_id
    WHERE tb.line_item_id_extracted IN (SELECT DISTINCT external_ad_id FROM oms)
    """
    tubi_log_source_df = spark.sql(tubi_log_source_query)

    spark.sql(f"DROP TABLE IF EXISTS {prod_catalog_name}.bronze_ads.source_tubi_log_data_pacing")
    tubi_log_source_df.write.format('delta') \
        .mode('overwrite') \
        .option('mergeSchema', 'true') \
        .option('overwriteDynamicPartitions', 'true') \
        .option('delta.enableDeletionVectors', 'false') \
        .option('delta.enableIcebergCompatV2', 'true') \
        .option('delta.universalFormat.enabledFormats', 'iceberg') \
        .option('delta.columnMapping.mode', 'name') \
        .saveAsTable(f'{prod_catalog_name}.bronze_ads.source_tubi_log_data_pacing')

    # Validate the source deal level data with the campaign Pacing unified deal level data
    print('Validating the source deal level data with the campaign Pacing unified deal level data')
    source_df_query = f"""
        
        WITH unified_data AS (
            SELECT 
                data_source,
                aos_deal_id,
                external_ad_id,
                campaign_id,
                campaign_start_date,
                campaign_end_date,
                campaign_status,
                placement_id,
                placement_start_date,
                placement_end_date,
                billable_third_party_server,
                unit_type,
                cost_method_name,
                product_name,
                fw_rbp_advanced,
                demand_type,
                budget_model,
                placement_avg_user_frequency,
                demo_band,
                demo_comp,
                booked_on_target_impression_goal,
                impression_goal,
                guaranteed_impressions,
                guaranteed_revenue,
                net_unit_cost,
                OSI_total,
                event_date,
                first_party_delivered_clicks,
                first_party_delivered_impressions,
                first_party_delivered_revenue,
                on_target_net_delivered_impressions,
                video_completes,
                video_starts
                --0 as total_engagements
            FROM {prod_catalog_name}.bronze_ads.source_first_party_data_pacing_fw
            
            UNION ALL
            
            SELECT 
                data_source,
                aos_deal_id,
                external_ad_id,
                aos_deal_id AS campaign_id,
                deal_start_date,
                deal_end_date,
                campaign_status,
                line_item_id,
                line_item_start_date,
                line_item_end_date,
                billable_third_party_server,
                unit_type,
                cost_method_name,
                product_name,
                fw_rbp_advanced,
                line_item_type,
                'N/A' AS budget_model,
                'N/A' AS placement_avg_user_frequency,
                'N/A' AS demo_band,
                1 AS demo_comp,
                0 as booked_on_target_impression_goal,
                0 as impression_goal,
                guaranteed_impressions,
                guaranteed_revenue,
                net_unit_cost,
                osi_total AS OSI_total,
                event_date,
                total_clicks,
                total_impressions,
                total_revenue,
                0 AS on_target,
                video_completes,
                video_views
                -- 0 as total_engagements
            FROM {prod_catalog_name}.bronze_ads.source_first_party_data_pacing_gam
            UNION ALL
             select 
                  data_source, 
                  aos_deal_id, 
                  external_ad_id, 
                  campaign_id, 
                  campaign_start_date, 
                  campaign_end_date, 
                  campaign_status, 
                  placement_id, 
                  placement_start_date, 
                  placement_end_date, 
                  billable_third_party_server,
                  unit_type,
                  cost_method_name,
                  product_name,
                  fw_rbp_advanced,
                  demand_type, 
                  'N/A' AS budget_model,
                  'N/A' placement_avg_user_frequency, 
                  demo_band, 
                  demo_comp,
                  0 as booked_on_target_impression_goal,
                  0 as impression_goal, 
                  guaranteed_impressions, 
                  guaranteed_revenue, 
                  net_unit_cost, 
                  OSI_total, 
                  event_date, 
                  first_party_delivered_clicks, 
                  first_party_delivered_impressions, 
                  first_party_delivered_revenue, 
                  on_target_net_delivered_impressions, 
                  video_completes, 
                  video_starts 
                  --total_engagements
                from 
                  {prod_catalog_name}.bronze_ads.source_emplifi_data_pacing
            UNION ALL
             select 
                  data_source, 
                  aos_deal_id, 
                  external_ad_id, 
                  campaign_id, 
                  campaign_start_date, 
                  campaign_end_date, 
                  campaign_status, 
                  placement_id, 
                  placement_start_date, 
                  placement_end_date, 
                  billable_third_party_server,
                  unit_type,
                  cost_method_name,
                  product_name,
                  fw_rbp_advanced,
                  demand_type, 
                  'N/A' AS budget_model,
                  'N/A' placement_avg_user_frequency, 
                  demo_band, 
                  demo_comp, 
                  0 as booked_on_target_impression_goal,
                  0 as impression_goal,
                  guaranteed_impressions, 
                  guaranteed_revenue, 
                  net_unit_cost, 
                  OSI_total, 
                  event_date, 
                  0 first_party_delivered_clicks, 
                  first_party_delivered_impressions, 
                  first_party_delivered_revenue, 
                  0 as on_target_net_delivered_impressions, 
                  0 as video_completes, 
                  0 as video_starts 
                  --total_engagements
                from 
                  {prod_catalog_name}.bronze_ads.source_gam_sports_data_pacing

            UNION ALL

            SELECT
                data_source,
                aos_deal_id,
                external_ad_id,
                campaign_id,
                campaign_start_date,
                campaign_end_date,
                campaign_status,
                placement_id,
                placement_start_date,
                placement_end_date,
                billable_third_party_server,
                unit_type,
                cost_method_name,
                product_name,
                fw_rbp_advanced,
                demand_type,
                budget_model,
                placement_avg_user_frequency,
                demo_band,
                demo_comp,
                booked_on_target_impression_goal,
                impression_goal,
                guaranteed_impressions,
                guaranteed_revenue,
                net_unit_cost,
                OSI_total,
                event_date,
                first_party_delivered_clicks,
                first_party_delivered_impressions,
                first_party_delivered_revenue,
                on_target_net_delivered_impressions,
                video_completes,
                video_starts
            FROM {prod_catalog_name}.bronze_ads.source_tubi_log_data_pacing

        ),
        oms_data AS (
            SELECT 
                case when oms.delivery_source ilike '%mercury%'
                    then 'Mercury'
                    when oms.delivery_source ilike '%Megaphone%' 
                    then 'Megaphone'
                    when oms.delivery_source ilike '%Social%'
                    then 'Social Media'
                    when oms.delivery_source ilike '%Amper%'
                    then 'AmperWave'
                    else 'Non Ad Served' 
                end AS data_source,
                sales_order_id AS aos_deal_id,
                ps_line_item_id AS external_ad_id,
                sales_order_id AS campaign_id,
                order_start_dt AS deal_start_date,
                order_end_dt AS deal_end_date,
                CASE 
                    WHEN deal_end_date > current_timestamp() - INTERVAL 1 DAY THEN 'Active'
                    ELSE 'Closed'
                END AS campaign_status,
                sales_order_line_item_id AS line_item_id,
                sales_order_line_item_start_dt AS line_item_start_date,
                sales_order_line_item_end_dt AS line_item_end_date,
                NVL(CASE
                WHEN billable_third_party_descr = 'DCM' THEN 'FOX DCM'
                WHEN billable_third_party_descr = 'Doubleverify' THEN 'FOX Doubleverify'
                WHEN billable_third_party_descr = 'Innovid' THEN 'FOX Innovid'
                WHEN billable_third_party_descr = 'Flashtalking' THEN 'FOX Flashtalking'
                WHEN billable_third_party_descr = 'Extreme Reach' THEN 'FOX Extreme Reach'
                WHEN billable_third_party_descr = 'Sizmek' THEN 'FOX Sizmek'
                WHEN billable_third_party_descr = '1st Party' THEN 'FOX 1st Party'
                ELSE billable_third_party_descr
            END, 'N/A') billable_third_party_server,
                oms.unit_type,
                oms.cost_method_name,
                oms.product_name,
                oms.fw_rbp_advanced,
                'N/A' AS line_item_type,
                'N/A' AS budget_model,
                'N/A' AS placement_avg_user_frequency,
                'N/A' AS demo_band,
                1 AS demo_comp,
                0 as booked_on_target_impression_goal,
                0 as impression_goal,
                sales_order_line_items_qty AS guaranteed_impressions,
                net_cost_amt AS guaranteed_revenue,
                net_unit_cost_amt AS net_unit_cost,
                0 AS OSI_total,
                date AS event_date,
                case when  (oms.delivery_source ilike '%mercury%'
                            or oms.delivery_source ilike '%Megaphone%' 
                            or oms.delivery_source ilike '%Social%'
                            or oms.delivery_source ilike '%Amper%')
                            and oms.unit_type ilike 'Clicks'
                    then oms.primary_delivery_imps
                    else 0 
                end AS total_clicks,
                case when  (oms.delivery_source ilike '%mercury%'
                            or oms.delivery_source ilike '%Megaphone%' 
                            or oms.delivery_source ilike '%Social%'
                            or oms.delivery_source ilike '%Amper%')
                            and oms.unit_type ilike 'Impressions'
                    then oms.primary_delivery_imps
                    else 0 
                end AS total_impressions,
                case when  (oms.delivery_source ilike '%mercury%'
                            or oms.delivery_source ilike '%Megaphone%' 
                            or oms.delivery_source ilike '%Social%'
                            or oms.delivery_source ilike '%Amper%')
                            and oms.unit_type ilike 'Impressions'
                    then (oms.primary_delivery_imps/1000) * oms.net_unit_cost_amt
                    else 0
                end AS total_revenue,
                0 AS on_target,
                0 AS video_completes,
                0 AS video_views
                --0 AS total_engagements
            FROM fox_bi_prod.gold_ad_sales.ft_digital_operative_line_date_allocation oms
            LEFT JOIN unified_data
                ON unified_data.external_ad_id = oms.ps_line_item_id
            WHERE 1 = 1
                AND unified_data.external_ad_id IS NULL
                AND sales_order_line_item_id NOT IN (
                    SELECT DISTINCT parent_line_item_id 
                    FROM fox_bi_prod.gold_ad_sales.ft_digital_operative_line_date_allocation 
                    WHERE parent_line_item_id IS NOT NULL
                )
                AND oms.sales_order_id IN (
                    SELECT DISTINCT aos_deal_id 
                    FROM unified_data
                )
                AND oms.sales_order_line_item_id NOT IN (
                    SELECT DISTINCT deal_line_id 
                    FROM {prod_catalog_name}.bronze_ads.source_emplifi_data_pacing
                )
                AND CASE 
                    WHEN (
                        CASE 
                            WHEN oms.delivery_source ilike '%mercury%' THEN 'Mercury'
                            WHEN oms.delivery_source ilike '%Megaphone%' THEN 'Megaphone'
                            WHEN oms.delivery_source ilike '%Social%' THEN 'Social Media'
                            WHEN oms.delivery_source ilike '%Amper%' THEN 'AmperWave'
                            ELSE 'Non Ad Served' 
                         END
                    ) = 'Non Ad Served'
                    THEN true
                    when date < current_date() 
                    THEN true 
                    ELSE false 
                 END
        ),
        all_daily AS (
            SELECT * FROM unified_data
            UNION ALL
            SELECT * FROM oms_data
        ),
        plc_lvl_flg AS (
            SELECT
                placement_id,
                campaign_id,
                SUM(is_live_day) AS live_days,
                SUM(is_dark_day) AS dark_days,
                MAX(rm_days) AS rm_days,
                SUM(is_live_day) + MAX(rm_days) AS campaign_days,
                SUM(is_live_day) AS days_to_date
            FROM (
                SELECT
                    placement_id,
                    campaign_id,
                    flight_start_date,
                    flight_end_date,
                    CASE WHEN event_date BETWEEN flight_start_date AND flight_end_date AND delivered_impressions > 0 THEN 1 ELSE 0 END AS is_live_day,
                    CASE WHEN event_date BETWEEN flight_start_date AND flight_end_date AND delivered_impressions > 0 THEN 0 ELSE 1 END AS is_dark_day,
                    CASE WHEN MAX(event_date) OVER (PARTITION BY placement_id, campaign_id) NOT BETWEEN flight_start_date AND flight_end_date THEN 0
                         WHEN current_date() >= flight_end_date THEN 0
                         ELSE GREATEST(DATEDIFF(flight_end_date, LEAST(MAX(event_date) OVER (PARTITION BY placement_id, campaign_id), flight_end_date)), 0) END AS rm_days
                FROM (
                    SELECT
                        placement_id,
                        campaign_id,
                        event_date,
                        COALESCE(placement_start_date, campaign_start_date) AS flight_start_date,
                        COALESCE(placement_end_date, campaign_end_date) AS flight_end_date,
                        SUM(first_party_delivered_impressions) AS delivered_impressions
                    FROM all_daily
                    GROUP BY placement_id, campaign_id, event_date,
                        COALESCE(placement_start_date, campaign_start_date),
                        COALESCE(placement_end_date, campaign_end_date)
                )
            )
            GROUP BY placement_id, campaign_id
        ),
        pac AS (
            SELECT
                ad.data_source,
                ad.campaign_id,
                ad.placement_id,
                ad.campaign_end_date,
                ad.billable_third_party_server,
                ad.unit_type,
                ad.cost_method_name,
                ad.product_name,
                ad.fw_rbp_advanced,
                ad.demand_type,
                ad.budget_model,
                ad.placement_avg_user_frequency,
                ad.demo_band,
                ad.demo_comp,
                ad.booked_on_target_impression_goal,
                ad.impression_goal,
                ad.guaranteed_impressions,
                ad.guaranteed_revenue,
                ad.net_unit_cost,
                ad.OSI_total,
                flg.campaign_days,
                flg.days_to_date,
                ad.guaranteed_impressions / NULLIF(flg.campaign_days, 0) AS daily_impression_goal,
                (ad.guaranteed_impressions / NULLIF(flg.campaign_days, 0)) * flg.days_to_date AS impression_goal_to_date,
                SUM(ad.first_party_delivered_clicks) AS first_party_delivered_clicks,
                SUM(ad.first_party_delivered_impressions) AS first_party_delivered_impressions,
                SUM(ad.first_party_delivered_revenue) AS first_party_delivered_revenue,
                SUM(ad.on_target_net_delivered_impressions) AS on_target_net_delivered_impressions,
                SUM(ad.video_completes) AS video_completes,
                SUM(ad.video_starts) AS video_starts
            FROM all_daily ad
            LEFT JOIN plc_lvl_flg flg
                ON ad.placement_id = flg.placement_id
                AND ad.campaign_id = flg.campaign_id
            GROUP BY
                ad.data_source,
                ad.campaign_id,
                ad.placement_id,
                ad.campaign_end_date,
                ad.billable_third_party_server,
                ad.unit_type,
                ad.cost_method_name,
                ad.product_name,
                ad.fw_rbp_advanced,
                ad.demand_type,
                ad.budget_model,
                ad.placement_avg_user_frequency,
                ad.demo_band,
                ad.demo_comp,
                ad.booked_on_target_impression_goal,
                ad.impression_goal,
                ad.guaranteed_impressions,
                ad.guaranteed_revenue,
                ad.net_unit_cost,
                ad.OSI_total,
                flg.campaign_days,
                flg.days_to_date
        )
        SELECT 
            pac.data_source,
            COALESCE(pac.campaign_id,-1) campaign_id,
            pac.placement_id,
            SUM(DISTINCT on_target_net_delivered_impressions) AS freewheel_on_target_net_delivered_impressions_source,
            SUM(pac.first_party_delivered_impressions) AS first_party_delivered_impressions_source,
            SUM(pac.first_party_delivered_clicks) AS first_party_delivered_clicks_source,
            CASE
                WHEN pac.data_source IN ('GAM', 'GAM Sports') THEN
                    CASE
                        WHEN pac.demand_type = 'SPONSORSHIP' THEN MAX(pac.guaranteed_revenue)
                        ELSE (SUM(pac.first_party_delivered_impressions) * MAX(pac.net_unit_cost)) / 1000
                    END
                ELSE SUM(pac.first_party_delivered_revenue)
            END AS first_party_delivered_revenue_source,
            SUM(pac.video_completes) AS video_completes_source,
            SUM(pac.video_starts) AS video_starts_source,
            MAX(pac.guaranteed_impressions) AS guaranteed_impressions_source,
            MAX(pac.guaranteed_revenue) AS guaranteed_revenue_source,
            MAX(pac.net_unit_cost) AS net_unit_cost_source,
            campaign_days as campaign_days_source,
            days_to_date as days_to_date_source, 
            CASE
            WHEN pac.data_source = 'FREEWHEEL'
            THEN (
                CASE
                    WHEN UPPER(pac.product_name) ILIKE '%ABSOLUTE A%' THEN 1.2
                    WHEN SUM(pac.first_party_delivered_impressions) = 0
                         AND (
                             pac.budget_model = 'Demographic Impression Target'
                             OR pac.fw_rbp_advanced ILIKE '%FW - APPLY CO-VIEWING=YES%'
                         )
                    THEN (
                        CASE
                            WHEN MAX(pac.booked_on_target_impression_goal) = 0 THEN NULL
                            ELSE MAX(pac.booked_on_target_impression_goal) / MAX(pac.impression_goal)
                        END
                    )
                    ELSE SUM(DISTINCT on_target_net_delivered_impressions) / (SUM(pac.first_party_delivered_impressions))
                END
            )
            ELSE NULL
        END::decimal(7,2) as cov_source,
            (CASE WHEN pac.Billable_Third_Party_Server = 'FOX 1st Party' 
                    AND budget_model='Demographic Impression Target' THEN 
                    sum(pac.first_party_delivered_impressions) * CoV_source
                WHEN pac.Billable_Third_Party_Server = 'FOX 1st Party' 
                    AND budget_model='Impression Target' THEN sum(pac.first_party_delivered_impressions)
                WHEN pac.Billable_Third_Party_Server != 'FOX 1st Party' 
                    AND budget_model='Impression Target' then 
                    case when COALESCE(MIN(total_third_party_impressions), SUM(third_party_billable_impressions))> 0 then COALESCE(MIN(total_third_party_impressions), SUM(third_party_billable_impressions)) else sum(pac.first_party_delivered_impressions)  end
                WHEN pac.Billable_Third_Party_Server != 'FOX 1st Party' 
                    AND budget_model='Demographic Impression Target' then 
                    case when COALESCE(MIN(total_third_party_impressions), SUM(third_party_billable_impressions)) > 0 then COALESCE(MIN(total_third_party_impressions), SUM(third_party_billable_impressions)) else sum(pac.first_party_delivered_impressions) end * CoV_source 
                WHEN UPPER(pac.unit_type) = 'DAYS' THEN campaign_days_source
                WHEN UPPER(pac.cost_method_name) ILIKE '%FLAT%' THEN
                    CASE WHEN MAX(pac.guaranteed_impressions) > 1 THEN case when COALESCE(MIN(total_third_party_impressions), SUM(third_party_billable_impressions)) > 0 then COALESCE(MIN(total_third_party_impressions), SUM(third_party_billable_impressions)) else sum(pac.first_party_delivered_impressions) end
                         WHEN MAX(pac.guaranteed_impressions) = 1 THEN 1 END
                ELSE case when COALESCE(MIN(total_third_party_impressions), SUM(third_party_billable_impressions)) > 0 then COALESCE(MIN(total_third_party_impressions), SUM(third_party_billable_impressions)) else sum(pac.first_party_delivered_impressions) end
                end ) AS campaign_billable_impressions_source,
            (campaign_billable_impressions_source / pac.guaranteed_impressions )::DECIMAL(7,2) AS campaign_del_pct_source,
            (CASE 
                WHEN MAX(pac.guaranteed_impressions) = 1 THEN NULL
                WHEN pac.data_source = 'FREEWHEEL' AND pac.demand_type = 'PROGRAMMATIC GUARANTEED' THEN 
                    SUM(pac.first_party_delivered_impressions) / MAX(pac.impression_goal_to_date)
                WHEN pac.data_source = 'FREEWHEEL' AND pac.demand_type = 'DIRECT SOLD' THEN 
                    CASE 
                        WHEN pac.demo_band = 'Audience Target' THEN SUM(pac.first_party_delivered_impressions) / MAX(pac.impression_goal_to_date)
                        WHEN pac.demo_band = 'P2+' THEN 
                            (SUM(pac.first_party_delivered_impressions) * CASE 
                                WHEN SUM(DISTINCT on_target_net_delivered_impressions) = 0 THEN 1.2 
                                ELSE COALESCE(SUM(DISTINCT on_target_net_delivered_impressions) / SUM(pac.first_party_delivered_impressions), 1.2) 
                            END::DECIMAL(7, 2)) / MAX(pac.impression_goal_to_date)
                        WHEN pac.demo_band = 'N/A' THEN NULL
                        ELSE SUM(pac.first_party_delivered_impressions * pac.demo_comp) / MAX(pac.impression_goal_to_date)
                    END
                WHEN pac.data_source in ('GAM', 'GAM Sports') THEN 
                    (SUM(pac.first_party_delivered_impressions) / MAX(pac.guaranteed_impressions)) * MAX(pac.OSI_total)
            END)::DECIMAL(7, 2) AS first_party_pacing_pct_source,
            (CASE 
                WHEN pac.data_source = 'FREEWHEEL' AND pac.demand_type NOT IN ('PROGRAMMATIC GUARANTEED', 'MARKETPLACE PLATFORM PRIVATE', 'MARKETPLACE PLATFORM EXCHANGE') THEN 
                    CASE 
                        WHEN pac.demo_band = 'Audience Target' THEN COALESCE(MIN(total_third_party_impressions), SUM(third_party_billable_impressions)) / MAX(pac.impression_goal_to_date)
                        WHEN pac.demo_band = 'P2+' THEN 
                            (COALESCE(MIN(total_third_party_impressions), SUM(third_party_billable_impressions)) * CASE 
                                WHEN SUM(DISTINCT on_target_net_delivered_impressions) = 0 THEN 1.2 
                                ELSE COALESCE(SUM(DISTINCT on_target_net_delivered_impressions) / SUM(pac.first_party_delivered_impressions), 1.2) 
                            END::DECIMAL(7, 2)) / MAX(pac.impression_goal_to_date)
                        WHEN pac.demo_band = 'N/A' THEN NULL
                        ELSE COALESCE(MIN(total_third_party_impressions), SUM(third_party_billable_impressions))* pac.demo_comp / MAX(pac.impression_goal_to_date)
                    END
                WHEN pac.data_source in ('GAM', 'GAM Sports') THEN 
                    (COALESCE(MIN(total_third_party_impressions), SUM(third_party_billable_impressions)) / MAX(pac.guaranteed_impressions)) * MAX(pac.impression_goal_to_date)
            END)::DECIMAL(7, 2) AS third_party_pacing_pct_source,
            campaign_billable_impressions_source / max(pac.impression_goal_to_date) AS campaign_pacing_pct_source,
            COALESCE(first_party_pacing_pct_source, 0) - COALESCE(third_party_pacing_pct_source, 0) AS pacing_discrepency_source,
            CASE WHEN UPPER(pac.unit_type) = 'DAYS' OR (UPPER(pac.cost_method_name) ILIKE '%FLAT%' AND MAX(pac.guaranteed_impressions) = 1)
                 THEN campaign_billable_impressions_source * pac.net_unit_cost 
                 ELSE ((campaign_billable_impressions_source/1000) * pac.net_unit_cost) END AS billable_revenue_source,
            case 
                when pac.campaign_end_date <= current_date() 
                then billable_revenue_source - pac.guaranteed_revenue
                else NULL
            end AS under_vs_over_delivery_source,
            campaign_billable_impressions_source / (MAX(pac.daily_impression_goal) * days_to_date) AS risk_source,
            SUM(pac.first_party_delivered_impressions) / MAX(pac.placement_avg_user_frequency) AS reach_source,
            COALESCE(MIN(total_third_party_impressions), SUM(third_party_billable_impressions)) AS third_party_impressions_source,
            COALESCE(MIN(total_third_party_revenue), SUM(third_party_revenue)) AS third_party_revenue_source,
            COALESCE(MIN(total_third_party_clicks), SUM(third_party_clicks)) AS third_party_clicks_source,
            MIN(total_third_party_video_completes) AS third_party_video_completes_source,
            MIN(total_third_party_video_views) AS third_party_video_views_source,
            (SUM(video_completes) / SUM(video_starts)) AS first_party_vcr_source,
            (MIN(total_third_party_video_completes) / COALESCE(MIN(total_third_party_impressions), SUM(third_party_billable_impressions))) AS third_party_vcr_source,
            (SUM(first_party_delivered_clicks) / SUM(pac.first_party_delivered_impressions)) AS first_party_click_thru_source,
            (COALESCE(MIN(total_third_party_clicks), SUM(third_party_clicks)) / COALESCE(MIN(total_third_party_impressions), SUM(third_party_billable_impressions))) AS third_party_click_thru_source
            --sum(total_engagements) as total_engagements_source
        FROM pac
        LEFT JOIN {prod_catalog_name}.bronze_ads.source_third_party_data_pacing tp
            ON pac.placement_id = cast(tp.placement_or_line_item_id as string)
        left join (
            SELECT
                placement_id,
                SUM(third_party_billable_impressions) AS third_party_billable_impressions,
                SUM(third_party_clicks) AS third_party_clicks,
                SUM(third_party_revenue) AS third_party_revenue
            FROM {prod_catalog_name}.bronze_ads.source_gam_sports_data_pacing
            GROUP BY placement_id
        ) gsd
            ON pac.placement_id = cast(gsd.placement_id as string)

        GROUP BY 
            pac.data_source,
            COALESCE(pac.campaign_id,-1),
            pac.placement_id,
            pac.guaranteed_impressions,
            pac.demand_type,
            pac.demo_band,
            pac.guaranteed_revenue,campaign_days,days_to_date,budget_model,pac.billable_third_party_server,pac.demo_comp,pac.net_unit_cost,pac.campaign_end_date,
            pac.booked_on_target_impression_goal,pac.impression_goal,pac.unit_type,pac.cost_method_name
            ,pac.product_name
            ,pac.fw_rbp_advanced
    """

    source_df = spark.sql(source_df_query)
    source_df = source_df.fillna(0, subset=[
      'net_unit_cost_source'
    , 'guaranteed_impressions_source'
    , 'guaranteed_revenue_source'
    , 'third_party_impressions_source'
    , 'third_party_revenue_source'
    , 'third_party_clicks_source'
    , 'third_party_video_completes_source'
    , 'third_party_video_views_source'
    , 'freewheel_on_target_net_delivered_impressions_source'
    , 'first_party_delivered_impressions_source'
    , 'first_party_delivered_clicks_source'
    , 'first_party_delivered_revenue_source'
    , 'video_completes_source'
    , 'video_starts_source'
    , 'cov_source'
    , 'campaign_billable_impressions_source'
    , 'campaign_del_pct_source'
    , 'first_party_pacing_pct_source'
    , 'third_party_pacing_pct_source'
    , 'campaign_pacing_pct_source'
    , 'pacing_discrepency_source'
    , 'billable_revenue_source'
    , 'under_vs_over_delivery_source'
    , 'risk_source'
    , 'reach_source'
    , 'first_party_vcr_source'
    , 'third_party_vcr_source'
    , 'first_party_click_thru_source'
    , 'third_party_click_thru_source'
    ])
    
    tab_query = f'''select * from {prod_catalog_name}.bronze_ads.foxai_unified_camping_pacing_delivery'''
    tab_unified_pacing =  spark.sql(tab_query)
    
    for key, val in columnMapping.items():
        tab_unified_pacing = tab_unified_pacing.withColumnRenamed(key,val)

    validation_df = source_df.join(tab_unified_pacing, on=['campaign_id','placement_id'], how='full_outer')
    # src = source_df.alias("src")
    # tgt = tab_unified_pacing.alias("tgt")
    #
    # validation_df = src.join(
    # tgt,
    # (
    #         (
    #                 (F.col("src.data_source") == "EMPLIFI") &
    #                 (F.col("tgt.ad_server_view") == "EMPLIFI") &
    #                 (F.col("src.campaign_id") == F.col("tgt.campaign_id")) &
    #                 (F.col("src.placement_id") == F.col("tgt.aos_deal_line_item_id_view"))
    #         )
    #         |
    #         (
    #                 (F.col("src.data_source") != "EMPLIFI") &
    #                 (F.col("src.campaign_id") == F.col("tgt.campaign_id")) &
    #                 (F.col("src.placement_id") == F.col("tgt.placement_id"))
    #         )
    # ),
    # how="full_outer"
    #     ).select(
    #         F.col("src.campaign_id").alias("campaign_id"),
    #         F.col("src.placement_id").alias("placement_id"),
    #         F.col("src.data_source").alias("data_source"),
    #
    #         *[
    #             F.col(f"src.{c}")
    #             for c in src.columns
    #             if c not in ["campaign_id", "placement_id", "data_source"]
    #         ],
    #
    #         *[
    #             F.col(f"tgt.{c}")
    #             for c in tgt.columns
    #             if c not in ["campaign_id", "placement_id"]
    #         ]
    #     )

    pairs = [
                ('first_party_delivered_impressions_source', 'first_party_delivered_impressions_view', 'first_party_delivered_impressions_variance'),
                ('first_party_delivered_clicks_source' , 'first_party_delivered_clicks_view','first_party_delivered_clicks_variance'),
                ('first_party_delivered_revenue_source' , 'first_party_delivered_revenue_view','first_party_delivered_revenue_variance'),
                ('video_completes_source' , 'video_completes_view','video_completes_variance'),
                ('video_starts_source' , 'video_starts_view','video_starts_variance'),
                ('guaranteed_impressions_source' , 'guaranteed_impressions_view','guaranteed_impressions_variance'),
                ('guaranteed_revenue_source' , 'guaranteed_revenue_view','guaranteed_revenue_variance'),
                ('net_unit_cost_source' , 'net_unit_cost_view','net_unit_cost_variance'),
                ('cov_source' , 'cov_view','cov_variance'),
                ('campaign_billable_impressions_source' , 'campaign_billable_impressions_view','campaign_billable_impressions_variance'),
                ('campaign_del_pct_source' , 'campaign_del_pct_view','campaign_del_pct_variance'),
                ('first_party_pacing_pct_source' , 'first_party_pacing_pct_view','first_party_pacing_pct_variance'),
                ('third_party_pacing_pct_source' , 'third_party_pacing_pct_view','third_party_pacing_pct_variance'),
                ('campaign_pacing_pct_source' , 'campaign_pacing_pct_view','campaign_pacing_pct_variance'),
                ('pacing_discrepency_source' , 'pacing_discrepency_view','pacing_discrepency_variance'),
                ('billable_revenue_source' , 'billable_revenue_view','billable_revenue_variance'),
                ('under_vs_over_delivery_source' , 'under_vs_over_delivery_view','under_vs_over_delivery_variance'),
                ('risk_source' , 'risk_view','risk_variance'),
                ('reach_source' , 'reach_view','reach_variance'),
                ('third_party_impressions_source' , 'third_party_impressions_view','third_party_impressions_variance'),
                ('third_party_revenue_source' , 'third_party_revenue_view','third_party_revenue_variance'),
                ('third_party_clicks_source' , 'third_party_clicks_view','third_party_clicks_variance'),
                ('third_party_video_completes_source' , 'third_party_video_completes_view','third_party_video_completes_variance'),
                ('first_party_vcr_source' , 'first_party_vcr_view','first_party_vcr_variance'),
                ('third_party_vcr_source' , 'third_party_vcr_view','third_party_vcr_variance'),
                ('first_party_click_thru_source' , 'first_party_click_thru_view','first_party_clicks_thru_variance'),
                ('third_party_click_thru_source' , 'third_party_click_thru_view','third_party_clicks_thru_variance')
    ]

    print('Performing campaign pacing source vs view validtions')

    for source_col, view_col, out_col in pairs:
        validation_df = validation_df.withColumn(out_col,\
            F.when(F.col(source_col) == 0, F.col(view_col))\
            .otherwise(F.round((F.col(source_col) - F.col(view_col))/F.col(source_col)*100, 3))
)

    validation_df = validation_df.select([
    'placement_id', 'campaign_id', 'data_source', 'ad_server_view',
    'billable_revenue_source', 'billable_revenue_view', 'billable_revenue_variance',
    'campaign_billable_impressions_source', 'campaign_billable_impressions_view', 'campaign_billable_impressions_variance',
    'campaign_del_pct_source', 'campaign_del_pct_view', 'campaign_del_pct_variance',
    'campaign_pacing_pct_source', 'campaign_pacing_pct_view', 'campaign_pacing_pct_variance',
    'cov_source', 'cov_view', 'cov_variance',
    'first_party_click_thru_source', 'first_party_click_thru_view', 'first_party_clicks_thru_variance',
    'first_party_delivered_clicks_source', 'first_party_delivered_clicks_view', 'first_party_delivered_clicks_variance',
    'first_party_delivered_impressions_source', 'first_party_delivered_impressions_view', 'first_party_delivered_impressions_variance',
    'first_party_delivered_revenue_source', 'first_party_delivered_revenue_view', 'first_party_delivered_revenue_variance',
    'first_party_pacing_pct_source', 'first_party_pacing_pct_view', 'first_party_pacing_pct_variance',
    'first_party_vcr_source', 'first_party_vcr_view', 'first_party_vcr_variance',
    'guaranteed_impressions_source', 'guaranteed_impressions_view', 'guaranteed_impressions_variance',
    'guaranteed_revenue_source', 'guaranteed_revenue_view', 'guaranteed_revenue_variance',
    'net_unit_cost_source', 'net_unit_cost_view', 'net_unit_cost_variance',
    'pacing_discrepency_source', 'pacing_discrepency_view', 'pacing_discrepency_variance',
    'reach_source', 'reach_view', 'reach_variance',
    'risk_source', 'risk_view', 'risk_variance',
    'third_party_clicks_source', 'third_party_clicks_view', 'third_party_clicks_variance',
    'third_party_click_thru_source', 'third_party_click_thru_view', 'third_party_clicks_thru_variance',
    'third_party_impressions_source', 'third_party_impressions_view', 'third_party_impressions_variance',
    'third_party_revenue_source', 'third_party_revenue_view', 'third_party_revenue_variance',
    'third_party_vcr_source', 'third_party_vcr_view', 'third_party_vcr_variance',
    'third_party_video_completes_source', 'third_party_video_completes_view', 'third_party_video_completes_variance',
    'third_party_pacing_pct_source', 'third_party_pacing_pct_view', 'third_party_pacing_pct_variance',
    'under_vs_over_delivery_source', 'under_vs_over_delivery_view', 'under_vs_over_delivery_variance',
    'video_completes_source', 'video_completes_view', 'video_completes_variance',
    'video_starts_source', 'video_starts_view', 'video_starts_variance',
])
    validation_df = validation_df.withColumn('updated_timestamp', F.lit(F.current_timestamp()))
    
    # Rename all _view columns to _target
    for col in validation_df.columns:
        if col.endswith('_view'):
            validation_df = validation_df.withColumnRenamed(col, col.replace('_view', '_target'))
        from pyspark.sql.types import DoubleType

    for col_name in validation_df.columns:
        if col_name.endswith('_variance'):
            validation_df = validation_df.withColumn(col_name, F.col(col_name).cast(DoubleType()))
    print('Campaign summary validtions completed')

    # Materialize once: validation_df feeds the table write, the alerts filter, and the CSV export
    validation_df = validation_df.cache()

    spark.sql(f"DROP TABLE IF EXISTS {prod_catalog_name}.bronze_ads.campaign_pacing_validations")
    validation_df.write.format('delta')\
        .mode('overwrite')\
        .option('mergeSchema', 'true')\
        .option('overwriteDynamicPartitions', 'true')\
        .option('delta.enableDeletionVectors', 'false')\
        .option('delta.enableIcebergCompatV2', 'true')\
        .option('delta.universalFormat.enabledFormats', 'iceberg')\
        .option('delta.columnMapping.mode', 'name')\
        .saveAsTable(f'{prod_catalog_name}.bronze_ads.campaign_pacing_validations')

    validation_status = get_validation_status(validation_df)
    dbutils.jobs.taskValues.set(key = "validation_status", value = str(validation_status))

    pacing_alerts_df = validation_df.filter((F.col("campaign_pacing_pct_target") > 110) | (F.col("campaign_pacing_pct_source") > 110) | (F.col("campaign_del_pct_target") > 110) |(F.col("campaign_del_pct_source") > 110) | (F.col("third_party_pacing_pct_target") > 110) | (F.col("third_party_pacing_pct_source") > 110) | (F.col("first_party_pacing_pct_target") > 110) | (F.col("first_party_pacing_pct_source") > 110) | (F.when(F.col("first_party_delivered_impressions_source") == 0, 0).otherwise(F.round((F.col("first_party_delivered_impressions_source")/F.col("guaranteed_impressions_source"))*100, 3)) > 100) | (F.when(F.col("first_party_delivered_impressions_target") == 0, 0).otherwise(F.round((F.col("first_party_delivered_impressions_target")/F.col("guaranteed_impressions_target"))*100, 3)) > 100) | (F.when(F.col("first_party_delivered_revenue_source") == 0, 0).otherwise(F.round((F.col("first_party_delivered_revenue_source")/F.col("guaranteed_revenue_source"))*100, 3)) > 100) | (F.when(F.col("first_party_delivered_revenue_target") == 0, 0).otherwise(F.round((F.col("first_party_delivered_revenue_target")/F.col("guaranteed_revenue_target"))*100, 3)) > 100) | (F.when(F.col("third_party_impressions_source") == 0, 0).otherwise(F.round((F.col("third_party_impressions_source")/F.col("guaranteed_impressions_source"))*100, 3)) > 100) | (F.when(F.col("third_party_impressions_target") == 0, 0).otherwise(F.round((F.col("third_party_impressions_target")/F.col("guaranteed_impressions_target"))*100, 3)) > 100) | (F.when(F.col("third_party_revenue_source") == 0, 0).otherwise(F.round((F.col("third_party_revenue_source")/F.col("guaranteed_revenue_source"))*100, 3)) > 100) | (F.when(F.col("third_party_revenue_target") == 0, 0).otherwise(F.round((F.col("third_party_revenue_target")/F.col("guaranteed_revenue_target"))*100, 3)) > 100) 
                                           )
    
    spark.sql(f"DROP TABLE IF EXISTS {prod_catalog_name}.bronze_ads.campaign_pacing_validations_alerts")
    pacing_alerts_df.write.format('delta')\
        .mode('overwrite')\
        .option('mergeSchema', 'true')\
        .option('overwriteDynamicPartitions', 'true')\
        .option('delta.enableDeletionVectors', 'false')\
        .option('delta.enableIcebergCompatV2', 'true')\
        .option('delta.universalFormat.enabledFormats', 'iceberg')\
        .option('delta.columnMapping.mode', 'name')\
        .saveAsTable(f'{prod_catalog_name}.bronze_ads.campaign_pacing_validations_alerts')


# COMMAND ----------

class ReportMailInfo:
    from_email = 'adtech.prod@data.fox'
    reply_to_address = 'prajwal.harikishor@fox.com'
    key = ''
    info = {}
    report_mailing_lists = {
        "campaign_reporting_pacing_validation" : {
            "key_format_string" : "campaign_reporting/Campaign_Reporting_Pacing_Validations_%Y%m%d.xlsx",
            "human_readable_name" : "prod - campaign reporiting pacing validations",
            "to" : [
                "prajwal.harikishor@fox.com",
                "alimaafroseshahul.hameed@fox.com",
                "Pradeep.Panneerselvam@fox.com",
                "Anitha.Mohanraj@fox.com",
                "yogesh.nageswararao@fox.com",
            ],
            "cc" : []
        }
    }

    def __init__(self, report, report_date):
        self.info = self.report_mailing_lists[report]
        self.key = get_latest_report(report_date, self.info['key_format_string'])

    def get_file_name(self):
        return os.path.basename(self.key)
    
    def get_report_body(self, report_date):
        footer = f'<p>This is an automated email. Please direct any questions or concerns to <a href="mailto: {self.reply_to_address}">{self.reply_to_address}</a>.</p>'
        body_text = f"""<p>Hello,</p>

<p>Please find attached the {self.info['human_readable_name']}.</p>

{footer}
"""
        return MIMEText(body_text, 'html')

    def get_report_attachment(self):
        global drop_bucket
        session = boto3.Session(profile_name=aws_profile)
        s3 = session.client('s3')
        resp = s3.get_object(Bucket=drop_bucket, Key=self.key)
        return resp['Body'].read()

# COMMAND ----------

def get_latest_report(report_date: datetime, key_format_string: str):
    session = boto3.Session(profile_name=aws_profile)
    s3 = session.client('s3')
    for delta in range(0, -7, -1):
        date = report_date + timedelta(days=delta)
        key = date.strftime(key_format_string)
        try:
            print(f'Trying object s3://{cpe_s3_bucket}/{key}')
            s3.head_object(Bucket=cpe_s3_bucket, Key=key)
            return key
        except s3.exceptions.ClientError as exc:
            if exc.response['Error']['Code'] == '404':
                continue
            raise
    raise RuntimeError('Could not find report')

# COMMAND ----------

validations_df = spark.table(f"{prod_catalog_name}.bronze_ads.campaign_pacing_validations")

# Write the file to dbfs
file_path = "/Workspace/Shared/Prod/PACING/" + "Campaign_Reporting_Pacing_Validations_" + datetime.today().strftime('%d%b%Y') + ".xlsx"
validations_df.toPandas().to_excel(file_path, index=False)

with io.StringIO() as output:
    validation_df.toPandas().to_csv(output, index=False)
    validation_data = output.getvalue()