# Databricks notebook source
# %pip install --upgrade typing_extensions
# import tableauserverclient as TSC
from pyspark.sql import SparkSession
from functools import reduce, partial
from pyspark.sql import DataFrame
from pyspark.sql.functions import *
from email.utils import COMMASPACE, formatdate
from datetime import datetime, date, timedelta
import os
import zipfile
import sys
from os.path import basename
from concurrent.futures import ThreadPoolExecutor, as_completed
from pyspark.sql.types import StructType, StructField, StringType, ArrayType, IntegerType, DoubleType, BooleanType, LongType
import pandas as pd
import argparse
import requests
import json
import logging
import time



st_time = datetime.now()

# COMMAND ----------

# dbutils.widgets.text("env", "")

env = dbutils.widgets.get("env")

# env = 'dev'

if env == 'dev' or env == 'qa':
    print(f"Running in the {env} environment")

elif env == 'prod':
    print("Running in the prod environment")

else:
    print(f"Running in an unknown environment: {env}")


# COMMAND ----------

if env == 'dev':
  catalog_name = 'fox_bi_qa'
  adtech_catalog_name = 'fox_bi_dev'
  #report_name = 'Unified Pacing Validation Report - QA'
  luid = '395718de-86f4-47d3-8180-366402295b33'
elif env == 'prod':
  catalog_name = 'fox_bi_prod'
  adtech_catalog_name = 'fox_bi_prod'
  #report_name = 'Unified Pacing Validation Report'
  luid = 'c1bc0200-cd27-46d0-8cb1-6aea463b4024'

# COMMAND ----------

# MAGIC %sh
# MAGIC aws --version
# MAGIC aws configure set region us-west-2 --profile databricks-fng-prod
# MAGIC aws configure set s3.signature_version s3v4 --profile databricks-fng-prod
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile databricks-fng-prod
# MAGIC aws configure set role_arn arn:aws:iam::640862407089:role/fng-dmo-prod-databricks-ec2-role --profile databricks-fng-prod

# COMMAND ----------

class cls_ssm(object):
    def __init__(self, aws_profile="default"):
        import boto3

        try:
            session = boto3.Session(profile_name=aws_profile)
            client = session.client("ssm")

            self.client = client
            self.aws_profile = aws_profile

        except Exception as e:
            raise Exception("ERROR: " + str(e))

    def get_ssm_param_by_path(
        self, path, full_path_dict_key=False, next_token=" ", keyvalue_dict={}
    ):
        # Get all values for all keys from SSM Path as Dictionary
        try:
            # -----------------------------------------------------------------------------------------------------------
            # To reset the keyvalue_dict we need to have below code , if we remove it is having trace of previous calls
            # -----------------------------------------------------------------------------------------------------------
            if next_token == " ":
                keyvalue_dict = {}
                response = self.client.get_parameters_by_path(
                    Path=path, WithDecryption=True, Recursive=True
                )
            else:
                response = self.client.get_parameters_by_path(
                    Path=path, NextToken=next_token, WithDecryption=True, Recursive=True
                )

            for parameter in response["Parameters"]:
                if full_path_dict_key:
                    key = parameter["Name"]
                else:
                    key = parameter["Name"].split("/")[-1]

                keyvalue_dict[key] = parameter["Value"]
            # ---------------------------------------------------------------------------------------------------------------
            # if there is more than 10 param in same path we need to paginate through next sets using next token from response
            # --------------------------------------------------------------------------------------------------------------
            if "NextToken" in response.keys():
                next_token = response["NextToken"]
                keyvalue_dict = self.get_ssm_param_by_path(
                    path, full_path_dict_key, next_token, keyvalue_dict
                )

            if keyvalue_dict == {}:
                value = self.client.get_parameter(Name=path, WithDecryption=True)[
                    "Parameter"
                ]["Value"]

                if full_path_dict_key:
                    key = path
                else:
                    key = path.split("/")[-1]

                keyvalue_dict[key] = value

            # print(keyvalue_dict)
            return keyvalue_dict
        except Exception as e:
            raise Exception("ERROR: " + str(e))

# COMMAND ----------

ssm_obj = cls_ssm('databricks-fng-prod')
cred_dict = ssm_obj.get_ssm_param_by_path( '/fox/stg/aos/prod/portal/', full_path_dict_key=False, next_token=' ', keyvalue_dict={})
usr=cred_dict['username']
ps=cred_dict['password']
api=cred_dict['apikey']

# COMMAND ----------

# Tableau Cloud

def retrieve_tableau_cloud_pat():
    ssm_obj = cls_ssm('databricks-fng-prod')
    cred_dict = ssm_obj.get_ssm_param_by_path('/fox/prod/tableau_cloud/', full_path_dict_key=False, next_token=' ', keyvalue_dict={})
    return cred_dict['patpassword']

def establish_tableau_cloud_connection(
        server_name="us-west-2b.online.tableau.com",
        version="3.22",
        site_url_id="foxanalytics",
        personal_access_token_name="Adsales_Jobs"):
    pat = retrieve_tableau_cloud_pat()
    signin_url = "https://{server}/api/{version}/auth/signin".format(server=server_name, version=version)
    payload = {
        "credentials":
            {
                "personalAccessTokenName": personal_access_token_name,
                "personalAccessTokenSecret": pat,
                "site": {
                    "contentUrl": site_url_id
                }
            }
    }
    headers = {
        'accept': 'application/json',
        'content-type': 'application/json'
    }
    print(f"Trying to establish connection to Tableau Cloud. SIGNIN_URL: {signin_url}")
    req = requests.post(signin_url, json=payload, headers=headers)
    req.raise_for_status()

    print(f"Successfully established connection to Tableau Cloud. SIGNIN_URL: {signin_url}")
    response = json.loads(req.content)
    token = response["credentials"]["token"]
    site_id = response["credentials"]["site"]["id"]
    headers['X-tableau-auth'] = token
    return headers, token, site_id

  
def download_tableau_view_as_csv(
        view_luid,
        csv_file_path,
        server_name="us-west-2b.online.tableau.com",
        version="3.22",
        headers=None):
    if not headers:
        headers, token, site_id = establish_tableau_cloud_connection()
    # Add filter for AOS Deal ID <> -1 and not null
    # filter_query = "vf_Status=All&vf_Event%20Date=Previous%20year"
    filter_query = ''
    url = f"https://{server_name}/api/{version}/sites/{site_id}/views/{view_luid}/data"
    
    headers = {
        'X-Tableau-Auth': token
    }

    response = requests.get(url, headers=headers)
    response.raise_for_status()
    print("Successfully downloaded tableau view contents.")

    if os.path.isfile(csv_file_path):
        print(f"{csv_file_path} file exists. Deleting currently existing file on file system")
        os.remove(csv_file_path)
        print(f"Successfully removed old file: {csv_file_path}")
    print(f"Dumping tableau view contents into a csv file: {csv_file_path}.")
    with open(csv_file_path, 'wb') as file:
        global chunk
        for chunk in response.iter_content(chunk_size=1024):
            if chunk:
                file.write(chunk)
    print(f"Successfully dumped tableau view contents into a csv file: {csv_file_path}")

    # Sign out from Tableau Cloud
    url = f"https://{server_name}/api/{version}/auth/signout"
    print("Signing out of Tableau Cloud.")
    response = requests.post(url, headers=headers)
    #response.raise_for_status()
    logging.info("Successfully signed out of Tableau Cloud.")

today = date.today()
current_directory = "/dbfs"
relative_path = 'Tableau_output/pacing_vs_foxai_validation/'
PREVIEW_FOLDER_LOCATION = os.path.join(current_directory, relative_path)

if not os.path.exists(PREVIEW_FOLDER_LOCATION):
    os.makedirs(PREVIEW_FOLDER_LOCATION)

csv_file_path = None
PREVIEW_FILE_EXTENSION = '.csv'
csv_file_path = (PREVIEW_FOLDER_LOCATION+'Sheet 1'+PREVIEW_FILE_EXTENSION)

download_tableau_view_as_csv(view_luid=luid, csv_file_path=csv_file_path)

print(csv_file_path)
# fox_ai_df = spark.read.options(header='true', inferSchema='true').csv(csv_file_path)
# display(fox_ai_df)

# COMMAND ----------


fox_ai_df = spark.read.csv(f"file://{csv_file_path}", header=True, inferSchema=True)

dff = fox_ai_df.withColumn(
    'Day of Campaign Start Date',
    to_date(trim(col('Day of Campaign Start Date')), 'MMMM d, yyyy')
).withColumn(
    'Day of Campaign End Date',
    to_date(trim(col('Day of Campaign End Date')), 'MMMM d, yyyy')
).withColumn(
    'Line Item or Placement Start Date',
    to_date(trim(col('Line Item or Placement Start Date')), 'M/d/yyyy')
).withColumn(
    'Line Item or Placement End Date',
    to_date(trim(col('Line Item or Placement End Date')), 'M/d/yyyy')
)

dff_transposed = dff.groupBy([c for c in dff.columns if c not in ['Measure Names', 'Measure Values']]) \
    .pivot('Measure Names') \
    .agg(first('Measure Values'))

for col_name in dff_transposed.columns:
    dff_transposed = dff_transposed.withColumnRenamed(col_name, col_name.replace(" ", "_"))

dff_transposed = dff_transposed.filter(col("AOS_Deal_ID") != 'All')

# Conversion logic
conversion_exprs = [
    ("Placement_Avg_User_Frequency", "double"),
    ("1P_Click_Thru", "double"),
    ("1P_Clicks", "double"),
    ("1P_Impressions", "bigint"),
    ("1P_Pacing_%", "double"),
    ("1P_VCR", "double"),
    ("1p_Revenue", "double"),
    ("3P_Click_Thru", "double"),
    ("3P_Clicks", "double"),
    ("3P_Impressions", "bigint"),
    ("3P_Pacing_%", "double"),
    ("3P_VCR", "double"),
    ("3p_Revenue", "double"),
    ("3P_Video_Completes", "double"),
    ("Billable_Revenue", "double"),
    ("Campaign_Billable_Impressions", "double"),
    ("Campaign_Days", "double"),
    ("Campaign_Delivered_%", "double"),
    ("Campaign_Pacing_%", "double"),
    ("Cov", "double"),
    ("Days_to_Date", "double"),
    ("Guaranteed_impressions", "double"),
    ("Guaranteed_Revenue", "double"),
    ("Net_Unit_Cost", "double"),
    ("Out_of_Flight_Impressions", "double"),
    ("Pacing_Discrepency", "double"),
    ("Reach", "double"),
    ("Risk", "double"),
    ("Under_vs_Over_Delivery", "double"),
    ("Video_Completes", "double"),
    ("Video_Starts", "double")
]

for col_name, dtype in conversion_exprs:
    if dtype == "double":
        dff_transposed = dff_transposed.withColumn(
            col_name,
            regexp_replace(col(col_name), ",", "")
        )
        dff_transposed = dff_transposed.withColumn(
            col_name,
            when(col(col_name).rlike("^[+-]?\\d+(\\.\\d+)?[eE][+-]?\\d+$"), col(col_name).cast("double").cast("string"))
            .otherwise(regexp_replace(col(col_name), ",", ""))
        )
        dff_transposed = dff_transposed.withColumn(
            col_name,
            col(col_name).cast("double")
        )
    elif dtype == "bigint":
        dff_transposed = dff_transposed.withColumn(
            col_name,
            regexp_replace(col(col_name), ",", "")
        )
        dff_transposed = dff_transposed.withColumn(
            col_name,
            col(col_name).cast("bigint")
        )

display(dff_transposed)
dff_transposed.write.format('delta')\
        .mode('overwrite')\
        .option('mergeSchema', 'true')\
        .saveAsTable(f"{adtech_catalog_name}.bronze_ads.foxai_unified_camping_pacing_delivery")
