# Databricks notebook source
# MAGIC %md
# MAGIC # Consolidate PACING Validation Report & Email
# MAGIC
# MAGIC This notebook:
# MAGIC 1. Reads PACING validation tables from Databricks
# MAGIC 2. Filters only discrepancy records
# MAGIC 3. Writes an Excel workbook with conditional red highlighting
# MAGIC 4. Builds a summary of findings
# MAGIC 5. Emails the workbook and summary

# COMMAND ----------

pip install boto3==1.40.49 awscli s3fs openpyxl

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %sh
# MAGIC aws configure set region us-west-2 --profile databricks-cpe-prod
# MAGIC aws configure set s3.signature_version s3v4 --profile databricks-cpe-prod
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile databricks-cpe-prod
# MAGIC aws configure set role_arn arn:aws:iam::501246562447:role/data-infra-astro-bi-adtech-prod --profile databricks-cpe-prod

# COMMAND ----------

# MAGIC %md
# MAGIC ## Parameters

# COMMAND ----------

dbutils.widgets.text("catalog_name", "fox_bi_prod")
dbutils.widgets.text("schema_name", "bronze_ads")
dbutils.widgets.text("aos_table_name", "aos_pacing_unified_campaign_validations")
dbutils.widgets.text("campaign_table_name", "campaign_pacing_validations")
dbutils.widgets.text("output_root_path", "/Workspace/Shared/Prod/PACING")
dbutils.widgets.text("output_file_prefix", "pacing_validation_report")
dbutils.widgets.text("email_to", "yogesh.nageswararao@fox.com")
dbutils.widgets.text("email_cc", "")
dbutils.widgets.text("email_from", "adtech.prod@data.fox")
dbutils.widgets.text("variance_threshold", "0.1")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Imports and configuration

# COMMAND ----------

import os
import smtplib
from datetime import datetime
from decimal import Decimal
from email.message import EmailMessage
from typing import Dict, List, Tuple

import pandas as pd
from openpyxl.styles import PatternFill, Font, Alignment
from openpyxl.utils import get_column_letter
from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import BooleanType, NumericType
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import boto3
from email import encoders

# COMMAND ----------

catalog_name = dbutils.widgets.get("catalog_name").strip()
schema_name = dbutils.widgets.get("schema_name").strip()
aos_table_name = dbutils.widgets.get("aos_table_name").strip()
campaign_table_name = dbutils.widgets.get("campaign_table_name").strip()
output_root_path = dbutils.widgets.get("output_root_path").strip()
output_file_prefix = dbutils.widgets.get("output_file_prefix").strip()
email_to = dbutils.widgets.get("email_to").strip().split(",")
email_cc = dbutils.widgets.get("email_cc").strip().split(",")
email_from = dbutils.widgets.get("email_from").strip()
variance_threshold = float(dbutils.widgets.get("variance_threshold").strip())

run_ts = datetime.now()
run_ts_str = run_ts.strftime("%Y%m%d_%H%M%S")
output_file_name = f"{output_file_prefix}_{run_ts_str}.xlsx"
output_file_path = os.path.join(output_root_path, output_file_name)

aos_fqn = f"{catalog_name}.{schema_name}.{aos_table_name}"
campaign_fqn = f"{catalog_name}.{schema_name}.{campaign_table_name}"

RED_FILL = PatternFill(fill_type="solid", fgColor="FFC7CE")
HEADER_FILL = PatternFill(fill_type="solid", fgColor="D9EAF7")
HEADER_FONT = Font(bold=True)
CENTER_ALIGN = Alignment(vertical="top")

print(f"AOS source table       : {aos_fqn}")
print(f"Campaign source table  : {campaign_fqn}")
print(f"Output workbook        : {output_file_path}")
print(f"Variance threshold     : {variance_threshold}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Helper functions

# COMMAND ----------

def get_secret_or_blank(scope: str, key: str) -> str:
    if not scope or not key:
        return ""
    return dbutils.secrets.get(scope=scope, key=key)


def build_aos_discrepancy_filter(df: DataFrame, threshold: float) -> Tuple[F.Column, List[str], List[str]]:
    mismatch_cols = [c for c in df.columns if "mismatch_" in c.lower()]
    variance_cols = [
        c for c in df.columns
        if c.lower().startswith("variance_") and c.lower().endswith("_percentage")
    ]

    predicates = []

    for c in mismatch_cols:
        predicates.append(F.coalesce(F.col(c).cast("boolean"), F.lit(False)) == F.lit(False))

    for c in variance_cols:
        predicates.append(F.abs(F.coalesce(F.col(c).cast("double"), F.lit(0.0))) > F.lit(threshold))

    if not predicates:
        return F.lit(False), mismatch_cols, variance_cols

    combined = predicates[0]
    for p in predicates[1:]:
        combined = combined | p

    return combined, mismatch_cols, variance_cols


def build_campaign_discrepancy_filter(df: DataFrame, threshold: float) -> Tuple[F.Column, List[str]]:
    variance_cols = [c for c in df.columns if "_variance" in c.lower()]

    predicates = [
        F.abs(F.coalesce(F.col(c).cast("double"), F.lit(0.0))) > F.lit(threshold)
        for c in variance_cols
    ]

    if not predicates:
        return F.lit(False), variance_cols

    combined = predicates[0]
    for p in predicates[1:]:
        combined = combined | p

    return combined, variance_cols


def get_triggered_counts(df: DataFrame, rules: Dict[str, str], threshold: float) -> Dict[str, int]:
    counts = {}
    for col_name, rule_type in rules.items():
        if rule_type == "mismatch_false":
            condition = F.coalesce(F.col(col_name).cast("boolean"), F.lit(False)) == F.lit(False)
        elif rule_type == "variance_gt_threshold":
            condition = F.abs(F.coalesce(F.col(col_name).cast("double"), F.lit(0.0))) > F.lit(threshold)
        else:
            continue

        counts[col_name] = df.filter(condition).count()
    return counts


def rename_campaign_variance_columns(pdf: pd.DataFrame) -> pd.DataFrame:
    renamed_columns = []
    for c in pdf.columns:
        if "_variance" in c.lower():
            renamed_columns.append(c.replace("_variance", "_variance_percentage"))
        else:
            renamed_columns.append(c)
    pdf.columns = renamed_columns
    return pdf


def autosize_worksheet(ws, min_width: int = 12, max_width: int = 60) -> None:
    for col_idx, column_cells in enumerate(ws.columns, start=1):
        lengths = []
        for cell in column_cells:
            value = "" if cell.value is None else str(cell.value)
            lengths.append(len(value))
            cell.alignment = CENTER_ALIGN
        adjusted = max(lengths + [min_width]) + 2
        ws.column_dimensions[get_column_letter(col_idx)].width = min(adjusted, max_width)


def style_header(ws) -> None:
    ws.freeze_panes = "A2"
    for cell in ws[1]:
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = CENTER_ALIGN


def apply_aos_conditional_formatting(ws, headers: List[str], threshold: float) -> None:
    header_index = {h: idx + 1 for idx, h in enumerate(headers)}

    mismatch_cols = [h for h in headers if "mismatch_" in h.lower()]
    variance_cols = [h for h in headers if h.lower().startswith("variance_") and h.lower().endswith("_percentage")]

    for row_idx in range(2, ws.max_row + 1):
        for col_name in mismatch_cols:
            cell = ws.cell(row=row_idx, column=header_index[col_name])
            value = cell.value
            if value in (False, "False", "false", 0, "0", None, ""):
                cell.fill = RED_FILL

        for col_name in variance_cols:
            cell = ws.cell(row=row_idx, column=header_index[col_name])
            try:
                numeric_value = abs(float(cell.value)) if cell.value is not None else 0.0
            except Exception:
                numeric_value = 0.0
            if numeric_value > threshold:
                cell.fill = RED_FILL


def apply_campaign_conditional_formatting(ws, headers: List[str], threshold: float) -> None:
    header_index = {h: idx + 1 for idx, h in enumerate(headers)}
    variance_cols = [h for h in headers if "_variance_percentage" in h.lower()]

    for row_idx in range(2, ws.max_row + 1):
        for col_name in variance_cols:
            cell = ws.cell(row=row_idx, column=header_index[col_name])
            try:
                numeric_value = abs(float(cell.value)) if cell.value is not None else 0.0
            except Exception:
                numeric_value = 0.0
            if numeric_value > threshold:
                cell.fill = RED_FILL


def build_summary_section(title: str, record_count: int, triggered_counts: Dict[str, int], no_issue_text: str, issue_text: str) -> str:
    if record_count == 0:
        return f"<li><b>{title}</b>: {no_issue_text}</li>"

    top_findings = sorted(
        [(k, v) for k, v in triggered_counts.items() if v > 0],
        key=lambda x: x[1],
        reverse=True
    )[:10]

    findings_text = ""
    if top_findings:
        findings_text = " Top columns with discrepancies: " + ", ".join([f"{k} ({v})" for k, v in top_findings]) + "."

    return f"<li><b>{title}</b>: {issue_text.format(record_count=record_count)}{findings_text}</li>"


def send_email(subject, html_body, to_addresses, cc_addresses, from_address,
               attachment_path=None,
               aws_profile='databricks-cpe-prod',
               aws_region='us-west-2'):

    msg = MIMEMultipart()
    msg['Subject'] = subject
    msg['From'] = from_address
    msg['To'] = ",".join(to_addresses)
    msg['Cc'] = ",".join(cc_addresses)

    # Add HTML body
    msg.attach(MIMEText(html_body, 'html'))

    # Attach file if provided
    if attachment_path:
        with open(attachment_path, "rb") as f:
            part = MIMEBase("application", "vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            part.set_payload(f.read())
        encoders.encode_base64(part)
        part.add_header(
            "Content-Disposition",
            f'attachment; filename="{attachment_path.split("/")[-1]}"'
        )
        msg.attach(part)

    # Send email via SES
    session = boto3.Session(profile_name=aws_profile)
    ses = session.client('sesv2', region_name=aws_region)

    # ses.send_raw_email(
    #     Source=from_address,
    #     Destinations=to_addresses + cc_addresses,
    #     RawMessage={'Data': msg.as_string()}
    # )

    raw_bytes = msg.as_bytes()
    ses.send_email(
    FromEmailAddress=from_address,
        Destination={
            "ToAddresses": to_addresses,
            "CcAddresses": cc_addresses or [],
        },
        Content={
            "Raw": {
                "Data": raw_bytes
            }
        }
    )

    print("Email sent successfully")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Read and filter source tables

# COMMAND ----------

aos_df = spark.table(aos_fqn)
campaign_df = spark.table(campaign_fqn)

aos_filter_expr, aos_mismatch_cols, aos_variance_cols = build_aos_discrepancy_filter(aos_df, variance_threshold)
campaign_filter_expr, campaign_variance_cols = build_campaign_discrepancy_filter(campaign_df, variance_threshold)

aos_discrepancy_df = aos_df.filter(aos_filter_expr)
campaign_discrepancy_df = campaign_df.filter(campaign_filter_expr)

aos_record_count = aos_discrepancy_df.count()
campaign_record_count = campaign_discrepancy_df.count()

print(f"AOS discrepancy records      : {aos_record_count}")
print(f"Campaign discrepancy records : {campaign_record_count}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Summarise findings by rule column

# COMMAND ----------

aos_rules = {**{c: "mismatch_false" for c in aos_mismatch_cols}, **{c: "variance_gt_threshold" for c in aos_variance_cols}}
campaign_rules = {c: "variance_gt_threshold" for c in campaign_variance_cols}

aos_triggered_counts = get_triggered_counts(aos_discrepancy_df, aos_rules, variance_threshold)
campaign_triggered_counts = get_triggered_counts(campaign_discrepancy_df, campaign_rules, variance_threshold)

print("AOS triggered columns:")
for k, v in sorted(aos_triggered_counts.items(), key=lambda x: x[1], reverse=True):
    if v > 0:
        print(f"  {k}: {v}")

print("Campaign triggered columns:")
for k, v in sorted(campaign_triggered_counts.items(), key=lambda x: x[1], reverse=True):
    if v > 0:
        print(f"  {k}: {v}")

# COMMAND ----------

note_text = """
Campaign PACING Validation Report – User Guide
This validation report provides a comprehensive view of data quality and consistency for campaign pacing datasets. It is designed to help users assess how accurately the final Gold datasets align with upstream source systems and intermediate transformations.



Purpose of this Report

The primary objective of this report is to:
Validate campaign pacing data across multiple data sources - AOS (Guaranteed), Freehweel (1st party), GAM (1st party), DVPS (3rd party)
Identify discrepancies between FOXAI datasets and source systems
Provide visibility into data completeness, accuracy, and consistency
Support analysis of campaign performance with trusted data
Identify any data gaps between the sources and the destination Tableau report. 



Data Sources Covered

The validation compares FOXAI Gold datasets against the following sources:
AOS (Ad Operations System)
First-party systems (e.g., GAM, Freewheel)
Third-party systems (e.g., DVPS)



Report Structure - 

The report is organized into two tabs, each representing a specific validation area or dataset section:

1. README:
A complete guide and overview on how to read this excel sheet validation report, and in-depth information on how to interpret the two different tabs.

2. aos_validations Tab:
This particular tab displays the comparison report between the Tableau report downloaded and the AOS directly with respect to all the guaranteed metrics and dimensions such as - agency, adv names, start and end dates of the deal, gtd revenue, gtd impressions, demos etc and provides the mismatches if any in the cells displayed in red color formatting. 
The level of detail is the aos_deal_id & line_item_id. This tab will be containing a record if and only if there is a discrapency at the line level with any of the AOS mertics. If a line is not having gaps then it would not be appearing here. 
This tab has the source values from AOS and the destination tableau report's values and if thre are any differences then the "mismatch_*" fields provides the boolean value TRUE is there isn't a mismatch and FALSE with red color formatted cells if there is any variance observed. 

3. campaign_validations Tab:
This tab should be read in triplets - "*_source", "*_target", "*_variance_percentage" for each of the metric present in the tableau report per line item.
The "*_source" fields contain the source values for that metric for a deal_id, line_item_id and similarly, the "*_target" fields contain the destination values for that metric for a deal_id, line_item_id prsent on Tableau report. The "*_variance_percentage" fields shows the percentage difference between source and the target fields which should be looked into by the developers and OPS. 


How to Use This Report:
  1. Start with Summary Tabs
    Review overall variance and mismatch indicators to quickly assess data health.
  2. Drill Down into Mismatch Tabs
    Investigate specific discrepancies and understand the root cause at a granular level.
  3. Review Missing Data Tabs
    Identify gaps that may impact reporting completeness or downstream analysis.
  4. Validate Section-wise Tabs
    Ensure each component of the WRAP campaign report aligns with source data expectations.


Key Indicators:
  1. Variance Metrics
    Highlight differences between FOXAI and source systems
  2. Conditional Formatting (e.g., Red Cells)
    Indicates records where variance exceeds acceptable thresholds
  3. Counts and Aggregates
    Provide quick comparison of totals across systems


Important Notes:
  1. This report reflects data at the time of validation execution
  2. Discrepancies may arise due to:
      A. Data latency between systems
      B. Upstream data changes
      C. Transformation logic differences
  3. Users should interpret mismatches in the context of data freshness and business rules
"""

# COMMAND ----------

# MAGIC %md
# MAGIC ## Convert to pandas and write Excel workbook

# COMMAND ----------

os.makedirs(output_root_path, exist_ok=True)

aos_pdf = aos_discrepancy_df.toPandas()
campaign_pdf = campaign_discrepancy_df.toPandas()
campaign_pdf = rename_campaign_variance_columns(campaign_pdf)

with pd.ExcelWriter(output_file_path, engine="openpyxl") as writer:

    # -----------------------------------
    # 1. WRITE README SHEET
    # -----------------------------------
    readme_sheet_name = "README"

    # Convert note string into DataFrame (line by line)
    readme_df = pd.DataFrame({"WRAP Campaign Validation Report": note_text.split("\n")})

    readme_df.to_excel(writer, index=False, sheet_name=readme_sheet_name)

    # -----------------------------------
    # 2. WRITE DATA SHEETS
    # -----------------------------------
    aos_sheet_name = "aos_validations"
    campaign_sheet_name = "campaign_validations"

    aos_pdf.to_excel(writer, index=False, sheet_name=aos_sheet_name)
    campaign_pdf.to_excel(writer, index=False, sheet_name=campaign_sheet_name)

    # -----------------------------------
    # 3. WORKBOOK STYLING
    # -----------------------------------
    wb = writer.book

    readme_ws = wb[readme_sheet_name]
    aos_ws = wb[aos_sheet_name]
    campaign_ws = wb[campaign_sheet_name]

    # Style headers
    style_header(aos_ws)
    style_header(campaign_ws)

    # Optional: style README header (first row bold)
    for cell in readme_ws[1]:
        cell.font = cell.font.copy(bold=True)

    # Conditional formatting
    apply_aos_conditional_formatting(aos_ws, list(aos_pdf.columns), variance_threshold)
    apply_campaign_conditional_formatting(campaign_ws, list(campaign_pdf.columns), variance_threshold)

    # Autosize
    autosize_worksheet(aos_ws)
    autosize_worksheet(campaign_ws)
    autosize_worksheet(readme_ws)

print(f"Excel workbook written to: {output_file_path}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Build email summary

# COMMAND ----------

aos_summary_text = (
    f"Discrepancies found in AOS vs FOXai PACING Tableau validation, and the number of records with differences are {aos_record_count}."
    if aos_record_count > 0
    else "No discrepancies found in AOS vs FOXai PACING Tableau validation."
)

campaign_summary_text = (
    f"Discrepancies found in campaign_pacing_validations, and the number of records with differences are {campaign_record_count}."
    if campaign_record_count > 0
    else "No discrepancies found in campaign_pacing_validations."
)

email_subject = f"PACING Validation Report - {run_ts.strftime('%Y-%m-%d %H:%M:%S')} - Prod"
email_body_html = f"""
<html>
  <body>
    <p>Hello,</p>
    <p>Please find the PACING validation summary below.</p>
    <ul>
      {build_summary_section(
          title="AOS vs FOXai PACING Tableau validation",
          record_count=aos_record_count,
          triggered_counts=aos_triggered_counts,
          no_issue_text="No discrepancies found.",
          issue_text="Discrepancies found in AOS vs FOXai PACING Tableau validation, and the number of records with differences are {record_count}."
      )}
      {build_summary_section(
          title="campaign_pacing_validations",
          record_count=campaign_record_count,
          triggered_counts=campaign_triggered_counts,
          no_issue_text="No discrepancies found.",
          issue_text="Discrepancies found in campaign_pacing_validations, and the number of records with differences are {record_count}."
      )}
    </ul>
    <p><b>Workbook path:</b> {output_file_path}</p>
    <p>Regards,<br/>Databricks PACING Validation Job</p>
  </body>
</html>
"""

print(aos_summary_text)
print(campaign_summary_text)
print(email_subject)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Optional email send

# COMMAND ----------

email_status = "SKIPPED"
email_error = ""



if not email_to:
    raise ValueError("Parameter 'email_to' is required when send_email=true.")
if not email_from:
    raise ValueError("Parameter 'email_from' is required when send_email=true.")

send_email(
    subject=email_subject,
    html_body=email_body_html,
    to_addresses=email_to,
    cc_addresses=email_cc,
    from_address=email_from
    ,attachment_path=output_file_path
)

print("Email sent successfully.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Job output

# COMMAND ----------

job_output = {
    "aos_table": aos_fqn,
    "campaign_table": campaign_fqn,
    "output_file_path": output_file_path,
    "aos_discrepancy_record_count": aos_record_count,
    "campaign_discrepancy_record_count": campaign_record_count,
    "aos_summary": aos_summary_text,
    "campaign_summary": campaign_summary_text,
    "email_status": email_status,
    "email_error": email_error,
}

for key, value in job_output.items():
    print(f"{key}: {value}")

# Optionally expose values to downstream workflow tasks
for key, value in job_output.items():
    try:
        dbutils.jobs.taskValues.set(key=key, value=str(value))
    except Exception:
        pass

# COMMAND ----------

