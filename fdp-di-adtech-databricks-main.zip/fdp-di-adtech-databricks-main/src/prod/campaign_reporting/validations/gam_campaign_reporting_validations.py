# Databricks notebook source
# COMMAND ----------

spark.conf.set(
    "spark.databricks.remoteFiltering.blockSelfJoins",
    "false"
)

# COMMAND ----------

aws_profile=dbutils.widgets.get('aws_profile')
aws_arn=dbutils.widgets.get('aws_arn')
from_email=dbutils.widgets.get('from_email')

# COMMAND ----------

# make the variable available to shell
import os
os.environ["AWS_PROFILE_VAR"] = aws_profile
os.environ["AWS_ARN"] = aws_arn

# COMMAND ----------

# MAGIC %sh
# MAGIC aws configure set region us-west-2 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set s3.signature_version s3v4 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile $AWS_PROFILE_VAR
# MAGIC aws configure set role_arn $AWS_ARN --profile $AWS_PROFILE_VAR

# COMMAND ----------

from googleads import ad_manager, oauth2, errors
import boto3
import os
from datetime import datetime, timedelta
from dataclasses import dataclass
from typing import List, Optional, Any, cast
import json
import tempfile
from datetime import datetime, timedelta
import pytz
import time
import pandas as pd
from pyspark.sql import SparkSession
import pyspark.sql.types as T
import pyspark.sql.functions as F
from pyspark import SparkFiles
import io
from email import encoders
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication

# COMMAND ----------

global aws_profile, APPLICATION_NAME, NETWORK_CODE, cpe_s3_bucket
aws_profile = f'{aws_profile}'
APPLICATION_NAME = 'AdSales - GAM Data Ingestion'
NETWORK_CODE = 4145
spark = SparkSession.builder.appName('GAM Report Data Load').getOrCreate()
spark.conf.set("spark.sql.session.timeZone", "UTC")

# COMMAND ----------

def get_ad_manager_client(secret_arn: str) -> Any:
    session = boto3.Session(profile_name=aws_profile)
    resp = session.client('secretsmanager').get_secret_value(SecretId=secret_arn)
    secret = json.loads(resp['SecretString'])

    with tempfile.NamedTemporaryFile(mode='w', delete=False) as secret_file:
        json.dump(secret, secret_file, indent=2)
        secret_file.close()

    oauth2_client = oauth2.GoogleServiceAccountClient(secret_file.name, oauth2.GetAPIScope('ad_manager'))
    os.unlink(secret_file.name)
    ad_manager_client = ad_manager.AdManagerClient(oauth2_client, APPLICATION_NAME, NETWORK_CODE)

    return ad_manager_client

# COMMAND ----------

def format_to_datetime(date_dict: Any) -> datetime:
    return datetime(
        date_dict['date']['year'],
        date_dict['date']['month'],
        date_dict['date']['day'],
        date_dict['hour'],
        date_dict['minute'],
        date_dict['second'],
        tzinfo=pytz.timezone(date_dict['timeZoneId'])
    )

def format_datetime_to_obj(datetime_obj: Any) -> Any:
    obj = {}
    obj['year'] = datetime_obj.year
    obj['month'] = datetime_obj.month
    obj['day'] = datetime_obj.day
    return obj

def generate_processing_dates(start_date: datetime, end_date: datetime, step_size: int) -> list:
    processing_dates = []

    batch_start_date = start_date
    while batch_start_date <= end_date:
        batch_end_date = batch_start_date + timedelta(days=step_size - 1)
        if batch_end_date <= end_date:
            processing_dates.append((batch_start_date, batch_end_date))
        else:
            processing_dates.append((batch_start_date, end_date))
            break
        batch_start_date += timedelta(days=step_size)

    return processing_dates

def build_report_query(dimensions: list, columns: list, dimensionAttributes: list, start_date: datetime, end_date: datetime, filter: dict = None) -> Any:
    baseReportQuery = {
        'dimensions': [],
        'adUnitView': 'FLAT',
        'columns': [],
        'dimensionAttributes': [],
        'customFieldIds': [],
        'cmsMetadataKeyIds': [],
        'customDimensionKeyIds': [],
        'startDate': {},
        'endDate': {},
        'dateRangeType': 'CUSTOM_DATE',
        'statement': None,
        'reportCurrency': 'USD',
        'timeZoneType': 'PUBLISHER'
    }

    report_query = baseReportQuery
    report_query['dimensions'] = dimensions
    report_query['columns'] = columns
    report_query['dimensionAttributes'] = dimensionAttributes
    report_query['startDate'] = format_datetime_to_obj(start_date)
    report_query['endDate'] = format_datetime_to_obj(end_date)

    if filter:
        filter_field = next(iter(filter))
        filter_values = filter[filter_field]
        placeholders = [f':lin{i}' for i in range(len(filter_values))]
        report_query['statement'] = {
            'query': f'WHERE {filter_field} IN ({",".join(placeholders)})',
            'values': [
                {'key': f'lin{i}', 'value': {'xsi_type': 'TextValue', 'value': name}}
                for i, name in enumerate(filter_values)
            ]
        }

    return report_query


# COMMAND ----------

def format_report(report_data: Any, report_type: str) -> Any:
    if report_type == 'GAM Campaign Reporting Data Validation Report':
        format_columns = {
            'Dimension.DATE': ('event_date', T.DateType()),
            'Dimension.LINE_ITEM_ID': ('line_item_id', T.LongType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS': ('total_impressions_source', T.LongType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_CPM_AND_CPC_REVENUE': ('total_revenue_source', T.LongType()),
        }
        select_cols = [
            'event_date',
            'line_item_id',
            'total_impressions_source',
            'total_revenue_source'
        ]

    for k, v in format_columns.items():
        report_data = report_data.withColumnRenamed(k, v[0])
        report_data = report_data.withColumn(v[0], F.col(v[0]).cast(v[1]))

    report_data = report_data.select(select_cols)

    return report_data

# COMMAND ----------

def get_validation_status(validation_df):
    variance_column_list = [
        'Impressions Variance %',
        'Revennue Variance %',
        'Third Party Impressions Variance %',
        'Third Party Revennue Variance %',
        'Guaranteed Impressions Variance',
        'Guaranteed Revenue Variance'
    ]
    for col in variance_column_list:
        if col in validation_df.columns:
            variance_values = validation_df.select(col).distinct().rdd.flatMap(lambda x: x).collect()
            if len(variance_values) == 1 and variance_values[0] == 0:
                pass
            else:
                print(f'Variance found in column {col}')
                return False
    return True

# COMMAND ----------

class ReportMailInfo:
    from_email = f'{from_email}'
    reply_to_address = 'data_adtech@fox.com'
    key = ''
    info = {}
    validation_status = False
    report_mailing_lists = {
        "GAM Campaign Delivery Data Validation Report" : {
            "key_format_string" : "campaign_reporting/GAM Campaign Delivery Data Validation Report_%d%b%Y.csv",
            "human_readable_name" : "GAM campaign delivery data validation report",
            "to" : [
                "prajwal.harikishor@fox.com",
                # "alex.lehman@fox.com",
                # "Pradeep.Panneerselvam@fox.com",
                # "Anitha.Mohanraj@fox.com",
                # "akshay.dalvi@fox.com",
                # "yogesh.nageswararao@fox.com",
            ],
            "cc" : [
                # "alimaafroseshahul.hameed@fox.com",
                # "Ramesh.Madepalli@fox.com",
            ]
        }
    }

    def __init__(self, report, validation_status, report_date):
        self.info = self.report_mailing_lists[report]
        self.key = get_latest_report(report_date, self.info['key_format_string'])
        self.validation_status = validation_status

    def get_file_name(self):
        return os.path.basename(self.key)
    
    def get_report_body(self, report_date):
        footer = f'<p>This is an automated email. Please direct any questions or concerns to <a href="mailto: {self.reply_to_address}">{self.reply_to_address}</a>.</p>'
        if self.validation_status:
            body_text = f"""<p>Hello,</p>

<p>The validation status: PASS</p>

<p>Please find attached the {self.info['human_readable_name']}.</p>

{footer}
"""
        else:
            body_text = f"""<p>Hello,</p>

<p>The validation status: FAILED</p>

<p>Please find attached the {self.info['human_readable_name']}.</p>

{footer}
"""
        return MIMEText(body_text, 'html')

    def get_report_attachment(self):
        session = boto3.Session(profile_name=aws_profile)
        s3 = session.client('s3')
        resp = s3.get_object(Bucket=cpe_s3_bucket, Key=self.key)
        return resp['Body'].read()


def get_latest_report(report_date: datetime, key_format_string: str):
    session = boto3.Session(profile_name=aws_profile)
    s3 = session.client('s3')
    for delta in range(0, -7, -1):
        date = report_date + timedelta(days=delta)
        key = date.strftime(key_format_string)
        try:
            print(f'Trying object s3://{cpe_s3_bucket}/{key}')
            s3.head_object(Bucket=cpe_s3_bucket, Key=key)
            return key
        except s3.exceptions.ClientError as exc:
            if exc.response['Error']['Code'] == '404':
                continue
            raise
    raise RuntimeError('Could not find report')


def send_mail(report_name, validation_status, report_date):
    
    report = ReportMailInfo(report_name, validation_status, report_date)

    attachment_ready_html = []
    img_id = 0
    mime_images = []

    msg = MIMEMultipart()
    msg['Subject'] = report.info['human_readable_name'].title()
    msg['From'] = report.from_email
    msg['To'] = ", ".join(report.info['to'])
    msg['Cc'] = ", ".join(report.info['cc'])
    msg.attach(report.get_report_body(report_date))

    part = MIMEApplication(
        report.get_report_attachment(),
        Name=report.get_file_name(),
    )
    part['Content-Disposition'] = f'attachment; filename="{report.get_file_name()}"'
    msg.attach(part)

    session = boto3.Session(profile_name = aws_profile)
    ses = session.client('ses', region_name='us-west-2')
    ses.send_raw_email(
        Source=msg['From'],
        Destinations=list(set(report.info['to']).union(set(report.info['cc']))),
        RawMessage={'Data': msg.as_string()}
    )

    print('Email sent')

# COMMAND ----------

if __name__ == '__main__':
    gam_service_account_creds_secret_arn = dbutils.widgets.get('gam_service_account_creds_secret_arn')
    gam_api_version = dbutils.widgets.get('gam_api_version')

    client = get_ad_manager_client(secret_arn=gam_service_account_creds_secret_arn)
    timezone = pytz.timezone("UTC")
    event_start_date = datetime.strptime(dbutils.widgets.get('event_start_date'), '%Y-%m-%d').replace(tzinfo=timezone)
    event_end_date = datetime.strptime(dbutils.widgets.get('event_end_date'), '%Y-%m-%d').replace(tzinfo=timezone) - timedelta(days=0)

    process_days = (event_end_date-event_start_date).days
    processing_dates = generate_processing_dates(event_start_date, event_end_date, 15)

    dev_catalog_name = dbutils.widgets.get('dev_catalog_name')
    qa_catalog_name = dbutils.widgets.get('qa_catalog_name')
    prod_catalog_name = dbutils.widgets.get('prod_catalog_name')
    cpe_s3_bucket = dbutils.widgets.get('cpe_s3_bucket')

    # GAM API Daily Data Validation Report
    print('GAM API Daily Data Validation Report')
    for i, batch in enumerate(processing_dates):
        start_date, end_date = batch
        print(f"Processing {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}, batch - {i}", end=' ')
        report_service = client.GetService('ReportService', version=gam_api_version)
        report_query = build_report_query(
            dimensions = [
                'DATE',
                'LINE_ITEM_ID',
            ],
            columns = [
                'TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS',
                'TOTAL_LINE_ITEM_LEVEL_CPM_AND_CPC_REVENUE'
            ],
            dimensionAttributes = [],
            start_date = start_date,
            end_date = end_date,
            filter = {
                'LINE_ITEM_TYPE': ['SPONSORSHIP', 'STANDARD', 'BULK']
            }
        )
        report_job = report_service.runReportJob({'reportQuery': report_query})

        while True:
            status = report_service.getReportJobStatus(report_job['id'])
            if status == 'COMPLETED':
                break
            elif status == 'FAILED':
                break
            else:
                time.sleep(10)

        if status == 'COMPLETED':
            print('Downloading...', end=' ')
            report_download_url = report_service.getReportDownloadURL(report_job['id'], 'CSV_DUMP')
            report_data = spark.createDataFrame(pd.read_csv(report_download_url, compression='gzip'))
            if i == 0:
                source_df = format_report(report_data, 'GAM Campaign Reporting Data Validation Report')
            else:
                source_df = source_df.union(format_report(report_data, 'GAM Campaign Reporting Data Validation Report'))
            print('Completed')
        else:
            raise Exception('Report job failed')

    third_party_source_query = f"""
        WITH op_line_detail AS (
            SELECT
                ps_line_item_id as line_item_id
                , CASE
                    WHEN billable_third_party_descr = 'DCM' THEN 'FOX DCM'
                    WHEN billable_third_party_descr = 'Doubleverify' THEN 'FOX Doubleverify'
                    WHEN billable_third_party_descr = 'Innovid' THEN 'FOX Innovid'
                    WHEN billable_third_party_descr = 'Flashtalking' THEN 'FOX Flashtalking'
                    WHEN billable_third_party_descr = 'Extreme Reach' THEN 'FOX Extreme Reach'
                    WHEN billable_third_party_descr = 'Sizmek' THEN 'FOX Sizmek'
                    WHEN billable_third_party_descr = '1st Party' THEN 'FOX 1st Party'
                    ELSE billable_third_party_descr
                END AS billable_third_party_server
            FROM {prod_catalog_name}.gold_ad_sales.ft_digital_operative_line_date_allocation
            GROUP BY ALL
        ),
        third_party_delivery AS (
            SELECT
                event_date
                , campaign_id AS line_item_id
                , SUM(third_party_billable_impressions) AS impressions_third_party_source
                , SUM(third_party_revenue) AS third_party_revenue_source
                , CASE
                    WHEN third_party_billable_server = 'Moat' THEN 'Moat'
                    WHEN third_party_billable_server in ('DFA by Google', 'Dart Report Reader', 'Dart Report Reader, DFA by Google', 'DFP by Google') THEN 'FOX DCM'
                    WHEN third_party_billable_server = 'DoubleVerify' THEN 'FOX Doubleverify'
                    WHEN third_party_billable_server = 'Innovid 3rd Party' THEN 'FOX Innovid'
                    WHEN third_party_billable_server in ('FlashTalking', 'FlashTalking Email Reader') THEN 'FOX Flashtalking'
                    WHEN third_party_billable_server in ('Extreme Reach Email', 'ExtremeReachAPI') THEN 'FOX Extreme Reach'
                    WHEN third_party_billable_server in ('MediaMind', 'MediaMind Report Reader', 'Sizmek SAS Report Reader', 'MediaMind Report Reader, Sizmek SAS Report Reader', 'Sizmek SAS Report Reader, MediaMind Report Reader') THEN 'FOX Sizmek'
                    WHEN third_party_billable_server = 'TubeMogul' THEN 'TubeMogul'
                    ELSE 'FOX 1st Party'
                END AS billable_third_party_server
            FROM {dev_catalog_name}.bronze_ads.third_party_campaign_reporting_delivery
            WHERE event_date BETWEEN '{event_start_date}' AND '{event_end_date}'
            GROUP BY ALL
        )

        SELECT
            3p.event_date
            , 3p.line_item_id
            , 3p.impressions_third_party_source
            , 3p.third_party_revenue_source
        FROM third_party_delivery as 3p
        INNER JOIN op_line_detail as op
        ON op.line_item_id = 3p.line_item_id
        AND 3p.billable_third_party_server = op.billable_third_party_server
    """
    third_party_source_df = spark.sql(third_party_source_query)

    source_df = source_df.join(third_party_source_df, on=['event_date', 'line_item_id'], how='outer')

    oms_source_query = f"""
        SELECT
            ps_line_item_id AS line_item_id
            , COALESCE(sales_order_line_items_qty, 0) AS guaranteed_impressions_source
            , COALESCE(ROUND(net_cost, 2), 0) AS guaranteed_revenue_source
        FROM {prod_catalog_name}.gold_ad_sales.ft_digital_operative_line_date_allocation
        GROUP BY ALL
    """
    oms_source_df = spark.sql(oms_source_query)

    source_df = source_df.join(oms_source_df, on=['line_item_id'], how='left')

    table_query = f"""
        SELECT
            `Event Date` AS event_date
            , `Line Item ID` AS line_item_id
            , SUM(`Delivered Impressions`) AS total_impressions_view
            , SUM(`Delivered Revenue`) AS total_revenue_view
            , `Third Party Billable Impressions` AS third_party_billable_impressions_view
            , `Third Party Revenue` AS third_party_revenue_view
            , `Guaranteed Impressions` AS guaranteed_impressions_view
            , ROUND(`Guaranteed Revenue`, 2) AS guaranteed_revenue_view
        FROM {qa_catalog_name}.gold_ad_sales.v_ft_gam_campaign_delivery
        WHERE `Event Date` BETWEEN '{event_start_date}' AND '{event_end_date}'
        AND ((`Delivered Impressions` != 0 AND `Delivered Impressions` IS NOT NULL) OR (`Third Party Billable Impressions` != 0 AND `Third Party Billable Impressions` IS NOT NULL))
        GROUP BY ALL
    """
    table_df = spark.sql(table_query)
    
    validation_df = table_df.join(source_df, on=['event_date', 'line_item_id'], how='left')
    validation_df = validation_df.fillna(0, subset=[
        'total_impressions_source',
        'total_impressions_view',
        'total_revenue_source',
        'total_revenue_view',
        'third_party_billable_impressions_view',
        'impressions_third_party_source',
        'third_party_revenue_view',
        'third_party_revenue_source'
    ])
    validation_df = validation_df.withColumn('Impressions Variance %',\
        F.when(F.col('total_impressions_source') == 0, F.col('total_impressions_view'))\
        .otherwise(F.round((F.col('total_impressions_view') - F.col('total_impressions_source'))/F.col('total_impressions_source')*100, 3))
    )
    validation_df = validation_df.withColumn('Revennue Variance %',\
        F.when(F.col('total_revenue_source') == 0, F.col('total_revenue_view'))\
        .otherwise(F.round((F.col('total_revenue_view') - F.col('total_revenue_source'))/F.col('total_revenue_source')*100, 3))
    )
    validation_df = validation_df.withColumn('Third Party Impressions Variance %',\
        F.when(F.col('impressions_third_party_source') == 0, F.col('third_party_billable_impressions_view'))\
        .otherwise(F.round((F.col('third_party_billable_impressions_view') - F.col('impressions_third_party_source'))/F.col('impressions_third_party_source')*100, 3))
    )
    validation_df = validation_df.withColumn('Third Party Revennue Variance %',\
        F.when(F.col('third_party_revenue_source') == 0, F.col('third_party_revenue_view'))\
        .otherwise(F.round((F.col('third_party_revenue_view') - F.col('third_party_revenue_source'))/F.col('third_party_revenue_source')*100, 3))
    )
    validation_df = validation_df.withColumn('Guaranteed Impressions Variance',\
        F.when(F.col('guaranteed_impressions_source') == 0, F.col('guaranteed_impressions_view'))\
        .otherwise(F.col('guaranteed_impressions_view') - F.col('guaranteed_impressions_source'))
    )
    validation_df = validation_df.withColumn('Guaranteed Revenue Variance',\
        F.when(F.col('guaranteed_revenue_source') == 0, F.col('guaranteed_revenue_view'))\
        .otherwise(F.col('guaranteed_revenue_view') - F.col('guaranteed_revenue_source'))
    )

    validation_df = validation_df.sort('event_date')

    validation_df = validation_df.select([
        'event_date',
        'line_item_id',
        'total_impressions_source',
        'total_impressions_view',
        'total_revenue_source',
        'total_revenue_view',
        'impressions_third_party_source',
        'third_party_billable_impressions_view',
        'third_party_revenue_source',
        'third_party_revenue_view',
        'guaranteed_impressions_source',
        'guaranteed_impressions_view',
        'guaranteed_revenue_source',
        'guaranteed_revenue_view',
        'Impressions Variance %',
        'Revennue Variance %',
        'Third Party Impressions Variance %',
        'Third Party Revennue Variance %',
        'Guaranteed Impressions Variance',
        'Guaranteed Revenue Variance'
    ])

    validation_status = get_validation_status(validation_df)

    with io.StringIO() as output:
        validation_df.toPandas().to_csv(output, index=False)
        validation_data = output.getvalue()

    report_name = 'GAM Campaign Delivery Data Validation Report_' + datetime.today().strftime('%d%b%Y') + '.csv'
    session = boto3.Session(profile_name=aws_profile)
    s3_client = session.client('s3')
    s3_bucket = cpe_s3_bucket
    s3_key = 'campaign_reporting/' + report_name
    s3_client.put_object(
        Bucket=s3_bucket,
        Body=validation_data.encode('utf-8'),
        Key=s3_key,
    )

    send_mail('GAM Campaign Delivery Data Validation Report', validation_status, datetime.today())