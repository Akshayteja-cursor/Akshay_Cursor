%sql
CREATE OR REPLACE MATERIALIZED VIEW `fox_bi_prod`.`gold_ad_sales`.`mv_ft_unified_campaign_show_delivery`
  (
Data_Source	string,
event_date	date,
campaign_id	bigint,
campaign_name	string,
campaign_start_date	timestamp,
campaign_end_date	timestamp,
order_id	bigint,
order_name	string,
advertiser_name	string,
agency_name	string,
Line_Item_or_Placement_ID	bigint,
Line_Item_or_Placement_Name	string,
Demand_Type	string,
Line_Item_or_Placement_Start_Date	timestamp,
Line_Item_or_Placement_End_Date	timestamp,
show_name	string,
Multiple_Ad_Servers	boolean,
Multiple_Ad_Server_ID	string,
Delivered_Impressions	bigint,
Delivered_Clicks	bigint,
Create_Timestamp	timestamp,
modified_timestamp	timestamp

  ) AS


select
  *
from
    fox_bi_prod.gold_ad_sales.ft_unified_campaign_show_delivery
CLUSTER BY campaign_id, event_date