# Databricks notebook source
from datetime import datetime, timedelta

# COMMAND ----------

spark.conf.set(
    "spark.databricks.remoteFiltering.blockSelfJoins",
    "false"
)

# COMMAND ----------

# spark.sparkContext.setCheckpointDir("dbfs:/checkpoints/ft_gam_campaign_pacing")

# COMMAND ----------

# Reduce shuffle partitions
spark.conf.set("spark.sql.shuffle.partitions", "200")

# COMMAND ----------

# Adaptive query execution
spark.conf.set("spark.sql.adaptive.enabled",                    "true")
spark.conf.set("spark.sql.adaptive.localShuffleReader.enabled", "true")
spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled", "true")

# COMMAND ----------

# Delta optimized write
spark.conf.set("spark.databricks.delta.optimizeWrite.enabled", "true")
spark.conf.set("spark.databricks.delta.autoCompact.enabled",   "true")

# COMMAND ----------

query = """
    WITH gam_daily AS (
        SELECT
            ad_date,
            order_id,
            order_name,
            CASE 
                WHEN platform_group ILIKE '%other%' THEN 'N/A'
                ELSE platform_group
            END AS platform_group,
            advertiser_name,
            advertiser_id,
            business_unit,
            ad_format_name,
            requested_ad_sizes,
            line_item_id,
            line_item_name,
            line_item_type,
            line_item_start_timestamp,
            line_item_end_timestamp,
            SUM(total_cpm_and_cpc_revenue) AS total_cpm_and_cpc_revenue,
            SUM(total_impressions) AS total_impressions,
            SUM(video_viewership_complete) AS video_viewership_complete,
            SUM(video_viewership_start) AS video_viewership_start,
            SUM(total_clicks) AS total_clicks,
            etl_load_timestamp_utc
        FROM fox_bi_prod.silver_ads.ft_gam_summary_daily_data
        WHERE ad_date >= '2024-01-01'
        AND line_item_id <> -1
        GROUP BY ALL
    ),
    third_party_delivery AS (
        SELECT
            event_date,
            campaign_id,
            campaign_name,
            third_party_billable_server,
            CASE
                WHEN third_party_billable_server = 'Moat' THEN 'Moat'
                WHEN third_party_billable_server in ('DFA by Google', 'Dart Report Reader', 'Dart Report Reader, DFA by Google', 'DFP by Google') THEN 'FOX DCM'
                WHEN third_party_billable_server = 'DoubleVerify' THEN 'FOX Doubleverify'
                WHEN third_party_billable_server = 'Innovid 3rd Party' THEN 'FOX Innovid'
                WHEN third_party_billable_server in ('FlashTalking', 'FlashTalking Email Reader') THEN 'FOX Flashtalking'
                WHEN third_party_billable_server in ('Extreme Reach Email', 'ExtremeReachAPI') THEN 'FOX Extreme Reach'
                WHEN third_party_billable_server in ('MediaMind', 'MediaMind Report Reader', 'Sizmek SAS Report Reader', 'MediaMind Report Reader, Sizmek SAS Report Reader', 'Sizmek SAS Report Reader, MediaMind Report Reader') THEN 'FOX Sizmek'
                WHEN third_party_billable_server = 'TubeMogul' THEN 'TubeMogul'
                ELSE 'FOX 1st Party'
            END AS billable_third_party_server,
            SUM(third_party_video_completes) AS third_party_video_completes,
            SUM(third_party_video_views) AS third_party_video_views,
            SUM(third_party_billable_impressions) AS third_party_billable_impressions,
            SUM(third_party_clicks) AS third_party_clicks,
            SUM(third_party_revenue) AS third_party_revenue
        FROM fox_bi_prod.silver_ads.ft_third_party_campaign_delivery_daily_data
        WHERE event_date >= '2024-01-01'
        GROUP BY ALL
    ),
    op_line_detail AS (
        SELECT
            source,
            sales_order_line_item_id AS sales_line_item_id,
            sales_order_line_item_name AS sales_line_item_name,
            sales_order_line_item_start_dt::date AS sales_line_item_start_date,
            sales_order_line_item_end_dt::date AS sales_line_item_end_date,
            sales_order_id,
            sales_order_name,
            order_start_dt AS sales_order_start_date,
            order_end_dt AS sales_order_end_date,
            agency_name,
            advertiser_name,
            owner_name,
            primary_salesperson_name,
            account_coordinator,
            package_name,
            ps_line_item_id,
            parent_line_item_name,
            demo_band,
            CASE
                WHEN billable_third_party_descr = 'DCM' THEN 'FOX DCM'
                WHEN billable_third_party_descr = 'Doubleverify' THEN 'FOX Doubleverify'
                WHEN billable_third_party_descr = 'Innovid' THEN 'FOX Innovid'
                WHEN billable_third_party_descr = 'Flashtalking' THEN 'FOX Flashtalking'
                WHEN billable_third_party_descr = 'Extreme Reach' THEN 'FOX Extreme Reach'
                WHEN billable_third_party_descr = 'Sizmek' THEN 'FOX Sizmek'
                WHEN billable_third_party_descr = '1st Party' THEN 'FOX 1st Party'
                ELSE billable_third_party_descr
            END AS billable_third_party_server,
            primary_property,
            opportunity_unique_id as pitch_id,
            cost_method_name,
            unit_type,
            UPPER(product_name) product_name,
            UPPER(fw_rbp_advanced) fw_rbp_advanced,
            net_unit_cost_amt AS net_unit_cost,
            net_cost_amt,
            sales_order_line_items_qty AS quantity
        FROM fox_bi_prod.gold_ad_sales.ft_digital_operative_line_date_allocation oms
        INNER JOIN (
            SELECT DISTINCT line_item_id FROM fox_bi_prod.silver_ads.ft_gam_summary_daily_data
            WHERE ad_date >= '2024-01-01'
            AND line_item_id <> -1
        ) gam
        ON oms.ps_line_item_id = gam.line_item_id
        WHERE ps_line_item_id IS NOT NULL
        AND oms.date BETWEEN oms.sales_order_line_item_start_dt and oms.sales_order_line_item_end_dt
        GROUP BY ALL
    )
    SELECT
        /*+ BROADCAST(li) */
        op_line_detail.sales_order_id,
        gam_daily.ad_date AS Event_Date,
        CAST(COALESCE(op_line_detail.sales_line_item_id, -1) AS BIGINT) AS AOS_Deal_Line_Item_ID,
        UPPER(COALESCE(op_line_detail.sales_line_item_name, 'N/A')) AS AOS_Deal_Line_Item_Name,
        op_line_detail.sales_line_item_start_date AS AOS_Deal_Line_Item_Start_Date,
        op_line_detail.sales_line_item_end_date AS AOS_Deal_Line_Item_End_Date,
        COALESCE(op_line_detail.sales_order_id, -1) AS Campaign_ID,
        UPPER(COALESCE(op_line_detail.sales_order_name, 'N/A')) AS Campaign_Name,
        COALESCE(op_line_detail.sales_order_start_date, or.order_start_timestamp) AS Campaign_Start_Date,
        COALESCE(op_line_detail.sales_order_end_date, or.order_end_timestamp) AS Campaign_End_Date,
        CASE
            WHEN op_line_detail.sales_order_end_date < CURRENT_TIMESTAMP() THEN 'Closed'
            ELSE 'Active'
        END AS Campaign_Status,
        MAX(
            CASE
                WHEN gam_daily.ad_date NOT BETWEEN COALESCE(op_line_detail.sales_order_start_date, or.order_start_timestamp)::DATE AND COALESCE(op_line_detail.sales_order_end_date, or.order_end_timestamp)::DATE THEN 1
                ELSE 0
            END
        ) OVER (PARTITION BY COALESCE(op_line_detail.sales_order_id, gam_daily.order_id))::BOOLEAN AS Out_Of_Flight_Flag,
        SUM(
            CASE
                WHEN gam_daily.ad_date NOT BETWEEN COALESCE(op_line_detail.sales_order_start_date, or.order_start_timestamp)::DATE AND COALESCE(op_line_detail.sales_order_end_date, or.order_end_timestamp)::DATE THEN gam_daily.total_impressions
                ELSE 0
            END
        ) as Out_Of_Flight_Impressions,
        gam_daily.order_id AS Order_ID,
        UPPER(COALESCE(gam_daily.order_name, 'N/A')) AS Order_Name,
        gam_daily.platform_group AS Device,
        UPPER(COALESCE(gam_daily.advertiser_name, 'N/A')) AS Advertiser_Name,
        gam_daily.advertiser_id AS Advertiser_ID,
        UPPER(COALESCE(gam_daily.business_unit, 'N/A')) AS Business_Unit,
        gam_daily.ad_format_name AS Ad_Unit_Format,
        gam_daily.requested_ad_sizes AS Ad_Unit_Size,
        gam_daily.line_item_id AS Line_Item_ID,
        UPPER(COALESCE(gam_daily.line_item_name, 'N/A')) AS Line_Item_Name,
        UPPER(COALESCE(gam_daily.line_item_type, 'N/A')) AS Line_Item_Type,
        TO_DATE(gam_daily.line_item_start_timestamp) AS Line_Item_Start_Date,
        TO_DATE(gam_daily.line_item_end_timestamp) AS Line_Item_End_Date,
        li.delivery_indicator_actual_delivery_percentage AS Actual_Delivery_Indicator,
        CAST(SUM(gam_daily.total_cpm_and_cpc_revenue) AS DOUBLE) AS Delivered_Revenue,
        SUM(gam_daily.total_impressions) AS Delivered_Impressions,
        SUM(gam_daily.video_viewership_complete) AS Video_Completes,
        SUM(gam_daily.video_viewership_start) AS Video_Starts,
        SUM(gam_daily.total_clicks) AS Delivered_Clicks,
        UPPER(COALESCE(op_line_detail.agency_name, 'N/A')) AS Agency_Name,
        UPPER(COALESCE(op_line_detail.advertiser_name, 'N/A')) AS Advertiser_OMS,
        UPPER(COALESCE(op_line_detail.owner_name, 'N/A')) AS Account_Manager,
        UPPER(COALESCE(op_line_detail.primary_salesperson_name, 'N/A')) AS Primary_Salesperson_Name,
        UPPER(COALESCE(op_line_detail.account_coordinator, 'N/A')) AS Account_Coordinator,
        ROUND(COALESCE(op_line_detail.net_unit_cost, 0), 2) AS Net_Unit_Cost,
        ROUND(COALESCE(op_line_detail.net_cost_amt, 0), 2) AS Guaranteed_Revenue,
        COALESCE(op_line_detail.quantity, 0) AS Guaranteed_Impressions,
        COALESCE(op_line_detail.ps_line_item_id, '-1') AS External_AD_ID,
        UPPER(COALESCE(op_line_detail.parent_line_item_name, 'N/A')) AS Parent_Line_Item_Name,
        COALESCE(op_line_detail.sales_order_id, -1) AS AOS_Deal_ID,
        UPPER(COALESCE(op_line_detail.sales_order_name, 'N/A')) as AOS_Deal_Name,
        DATE(op_line_detail.sales_order_start_date) AS AOS_Deal_Start_Date,
        DATE(op_line_detail.sales_order_end_date) AS AOS_Deal_End_Date,
        COALESCE(op_line_detail.demo_band, 'N/A') AS Demo_Band,
        UPPER(COALESCE(op_line_detail.package_name, 'N/A')) AS Package_Name,
        op_line_detail.billable_third_party_server AS Billable_Third_Party_Server,
        UPPER(COALESCE(op_line_detail.primary_property, 'N/A')) AS primary_property, 
        UPPER(COALESCE(op_line_detail.pitch_id, 'N/A')) AS pitch_id, 
        UPPER(COALESCE(op_line_detail.cost_method_name, 'N/A')) AS cost_method_name,
        UPPER(COALESCE(op_line_detail.unit_type, 'N/A')) AS unit_type,
        UPPER(COALESCE(op_line_detail.product_name, 'N/A')) AS product_name,
        UPPER(COALESCE(op_line_detail.fw_rbp_advanced, 'N/A')) AS fw_rbp_advanced,
        third_party_delivery.campaign_id AS Third_Party_Line_Item_ID,
        SUM(third_party_delivery.third_party_video_completes) AS Third_Party_Video_Completes,
        SUM(third_party_delivery.third_party_video_views) AS Third_Party_Video_Views,
        SUM(third_party_delivery.third_party_billable_impressions) AS Third_Party_Billable_Impressions,
        SUM(third_party_delivery.third_party_clicks) AS Third_Party_Clicks,
        ROUND(SUM(third_party_delivery.third_party_revenue), 2) AS Third_Party_Revenue,
        gam_daily.etl_load_timestamp_utc AS Create_Timestamp,
        gam_daily.etl_load_timestamp_utc AS Modified_Timestamp
    FROM gam_daily
    LEFT JOIN fox_bi_prod.silver_ads.dim_line_item li
    ON gam_daily.line_item_id = li.line_item_id
    LEFT JOIN fox_bi_prod.silver_ads.dim_orders or
    ON gam_daily.order_id = or.order_id
    LEFT JOIN op_line_detail
    ON gam_daily.line_item_id = op_line_detail.ps_line_item_id
    LEFT JOIN third_party_delivery
    ON gam_daily.ad_date = third_party_delivery.event_date
    AND gam_daily.line_item_id = third_party_delivery.campaign_id
    AND op_line_detail.billable_third_party_server = third_party_delivery.billable_third_party_server
    WHERE (
        CASE
            WHEN ((LOWER(gam_daily.advertiser_name) LIKE '%promo%') OR (LOWER(gam_daily.advertiser_name) LIKE '% test%')) THEN FALSE
            WHEN ((LOWER(gam_daily.order_name) LIKE '%promo%') OR (LOWER(gam_daily.order_name) LIKE '% test%')) THEN FALSE
            WHEN ((LOWER(op_line_detail.agency_name) LIKE '%promo%') OR (LOWER(op_line_detail.agency_name) LIKE '% test%')) THEN FALSE
            ELSE TRUE
        END
    )
    GROUP BY ALL
"""

gam_campaign_pacing = spark.sql(query)

gam_campaign_pacing = gam_campaign_pacing.select([
    'Event_Date',
    'AOS_Deal_Line_Item_ID',
    'AOS_Deal_Line_Item_Name',
    'AOS_Deal_Line_Item_Start_Date',
    'AOS_Deal_Line_Item_End_Date',
    'Campaign_ID',
    'Campaign_Name',
    'Campaign_Start_Date',
    'Campaign_End_Date',
    'Campaign_Status',
    'Out_Of_Flight_Flag',
    'Out_Of_Flight_Impressions',
    'Order_ID',
    'Order_Name',
    'Device',
    'Advertiser_Name',
    'Advertiser_ID',
    'Business_Unit',
    'Ad_Unit_Format',
    'Ad_Unit_Size',
    'Line_Item_ID',
    'Line_Item_Name',
    'Line_Item_Type',
    'Line_Item_Start_Date',
    'Line_Item_End_Date',
    'Actual_Delivery_Indicator',
    'Delivered_Revenue',
    'Delivered_Impressions',
    'Video_Completes',
    'Video_Starts',
    'Delivered_Clicks',
    'Agency_Name',
    'Advertiser_OMS',
    'Account_Manager',
    'Primary_Salesperson_Name',
    'Account_Coordinator',
    'Net_Unit_Cost',
    'Guaranteed_Revenue',
    'Guaranteed_Impressions',
    'External_AD_ID',
    'Parent_Line_Item_Name',
    'AOS_Deal_ID',
    'AOS_Deal_Name',
    'AOS_Deal_Start_Date',
    'AOS_Deal_End_Date',
    'Demo_Band',
    'Package_Name',
    'Billable_Third_Party_Server',
    'primary_property',
    'pitch_id',
    'Cost_Method_Name',
    'Unit_Type',
    'Product_Name',
    'fw_rbp_advanced',
    'Third_Party_Line_Item_ID',
    'Third_Party_Video_Completes',
    'Third_Party_Video_Views',
    'Third_Party_Billable_Impressions',
    'Third_Party_Clicks',
    'Third_Party_Revenue',
    'Create_Timestamp',
    'Modified_Timestamp'
])

gam_campaign_pacing.createOrReplaceTempView('gam_campaign_pacing')

gam_campaign_pacing_with_dark_days_query = """
    WITH base AS (
        SELECT
            Event_Date,
            Line_Item_ID,
            -- Dimensions (keep as-is here; we will "unique-ify" per Line_Item_ID later)
            AOS_Deal_Line_Item_ID,
            AOS_Deal_Line_Item_Name,
            AOS_Deal_Line_Item_Start_Date::date,
            AOS_Deal_Line_Item_End_Date::date,
            Campaign_ID,
            Campaign_Name,
            Campaign_Start_Date,
            Campaign_End_Date,
            Campaign_Status,
            Out_Of_Flight_Flag,
            Out_Of_Flight_Impressions,
            Order_ID,
            Order_Name,
            Advertiser_ID,
            Advertiser_Name,
            Line_Item_Name,
            Line_Item_Type,
            Line_Item_Start_Date,
            Line_Item_End_Date,
            Actual_Delivery_Indicator,
            Agency_Name,
            Advertiser_OMS,
            Account_Manager,
            Primary_Salesperson_Name,
            Account_Coordinator,
            Net_Unit_Cost,
            Guaranteed_Revenue,
            Guaranteed_Impressions,
            External_AD_ID,
            Parent_Line_Item_Name,
            AOS_Deal_ID,
            AOS_Deal_Name,
            AOS_Deal_Start_Date,
            AOS_Deal_End_Date,
            Demo_Band,
            Package_Name,
            Billable_Third_Party_Server,  
            primary_property,        
            pitch_id,  
            cost_method_name,
            unit_type,
            Product_Name,
            fw_rbp_advanced,
            Third_Party_Line_Item_ID,
            -- Fields that should become 'N/A' on densified rows
            Device,
            Business_Unit,
            Ad_Unit_Format,
            Ad_Unit_Size,
            -- Metrics
            Delivered_Revenue,
            Delivered_Impressions,
            Video_Completes,
            Video_Starts,
            Delivered_Clicks,
            Third_Party_Video_Completes,
            Third_Party_Video_Views,
            Third_Party_Billable_Impressions,
            Third_Party_Clicks,
            Third_Party_Revenue
        FROM gam_campaign_pacing
    ),
    -- 1) Get a single "canonical" set of dimension values per Line_Item_ID
    --    If you truly have exactly one unique value per Line_Item_ID, MAX() is fine.
    --    If not, pick a deterministic row with ROW_NUMBER (see note below).
    dims AS (
        SELECT
            Line_Item_ID,
            MAX(AOS_Deal_Line_Item_ID)            AS AOS_Deal_Line_Item_ID,
            MAX(AOS_Deal_Line_Item_Name)          AS AOS_Deal_Line_Item_Name,
            MAX(AOS_Deal_Line_Item_Start_Date)    AS AOS_Deal_Line_Item_Start_Date,
            MAX(AOS_Deal_Line_Item_End_Date)      AS AOS_Deal_Line_Item_End_Date,
            MAX(Campaign_ID)                      AS Campaign_ID,
            MAX(Campaign_Name)                    AS Campaign_Name,
            MIN(Campaign_Start_Date)              AS Campaign_Start_Date,
            MAX(Campaign_End_Date)                AS Campaign_End_Date,
            MAX(Campaign_Status)                  AS Campaign_Status,
            MAX(Out_Of_Flight_Flag)               AS Out_Of_Flight_Flag,
            MAX(Order_ID)                         AS Order_ID,
            MAX(Order_Name)                       AS Order_Name,
            MAX(Advertiser_ID)                    AS Advertiser_ID,
            MAX(Advertiser_Name)                  AS Advertiser_Name,
            MAX(Line_Item_Name)                   AS Line_Item_Name,
            MAX(Line_Item_Type)                   AS Line_Item_Type,
            MIN(Line_Item_Start_Date)             AS Line_Item_Start_Date,
            MAX(Line_Item_End_Date)               AS Line_Item_End_Date,
            MAX(Actual_Delivery_Indicator)        AS Actual_Delivery_Indicator,
            MAX(Agency_Name)                      AS Agency_Name,
            MAX(Advertiser_OMS)                   AS Advertiser_OMS,
            MAX(Account_Manager)                  AS Account_Manager,
            MAX(Primary_Salesperson_Name)         AS Primary_Salesperson_Name,
            MAX(Account_Coordinator)              AS Account_Coordinator,
            MAX(Net_Unit_Cost)                    AS Net_Unit_Cost,
            MAX(Guaranteed_Revenue)               AS Guaranteed_Revenue,
            MAX(Guaranteed_Impressions)           AS Guaranteed_Impressions,
            MAX(External_AD_ID)                   AS External_AD_ID,
            MAX(Parent_Line_Item_Name)            AS Parent_Line_Item_Name,
            MAX(AOS_Deal_ID)                      AS AOS_Deal_ID,
            MAX(AOS_Deal_Name)                    AS AOS_Deal_Name,
            MAX(AOS_Deal_Start_Date)              AS AOS_Deal_Start_Date,
            MAX(AOS_Deal_End_Date)                AS AOS_Deal_End_Date,
            MAX(Demo_Band)                        AS Demo_Band,
            MAX(Package_Name)                     AS Package_Name,
            MAX(Billable_Third_Party_Server)      AS Billable_Third_Party_Server,
            MAX(primary_property)                 AS primary_property,
            MAX(pitch_id)                         AS pitch_id,
            MAX(cost_method_name)                 AS cost_method_name,
            MAX(unit_type)                        AS unit_type,
            MAX(Product_Name)                     AS Product_Name,
            MAX(fw_rbp_advanced)                  AS fw_rbp_advanced,
            MAX(Third_Party_Line_Item_ID)         AS Third_Party_Line_Item_ID
        FROM base
        GROUP BY Line_Item_ID
    ),
    -- 2) Build the date spine per Line_Item_ID using Campaign_Start_Date/End_Date
    spine AS (
        SELECT
            d.Line_Item_ID,
            explode(
                sequence(
                    to_date(COALESCE(d.line_item_start_date, d.Campaign_Start_Date)),
                    to_date(COALESCE(d.line_item_end_date, d.campaign_end_date)),
                    interval 1 day
                )
            ) AS Event_Date
        FROM dims d
    ),
    -- 3) Left join actuals onto the spine
    joined AS (
        SELECT
            COALESCE(b.Event_Date, s.Event_Date) AS Event_Date,
            COALESCE(b.AOS_Deal_Line_Item_ID, d.AOS_Deal_Line_Item_ID) AS AOS_Deal_Line_Item_ID,
            COALESCE(b.AOS_Deal_Line_Item_Name, d.AOS_Deal_Line_Item_Name) AS AOS_Deal_Line_Item_Name,
            COALESCE(b.AOS_Deal_Line_Item_Start_Date, d.AOS_Deal_Line_Item_Start_Date) AS AOS_Deal_Line_Item_Start_Date,
            COALESCE(b.AOS_Deal_Line_Item_End_Date, d.AOS_Deal_Line_Item_End_Date) AS AOS_Deal_Line_Item_End_Date,
            COALESCE(b.Campaign_ID, d.Campaign_ID) AS Campaign_ID,
            COALESCE(b.Campaign_Name, d.Campaign_Name) AS Campaign_Name,
            COALESCE(b.Campaign_Start_Date, d.Campaign_Start_Date) AS Campaign_Start_Date,
            COALESCE(b.Campaign_End_Date, d.Campaign_End_Date) AS Campaign_End_Date,
            COALESCE(b.Campaign_Status, d.Campaign_Status) AS Campaign_Status,
            COALESCE(b.Out_Of_Flight_Flag, d.Out_Of_Flight_Flag) AS Out_Of_Flight_Flag,
            COALESCE(b.Out_Of_Flight_Impressions, 0) AS Out_Of_Flight_Impressions,
            COALESCE(b.Order_ID, d.Order_ID) AS Order_ID,
            COALESCE(b.Order_Name, d.Order_Name) AS Order_Name,
            COALESCE(b.Device, 'N/A') AS Device,
            COALESCE(b.Advertiser_Name, d.Advertiser_Name) AS Advertiser_Name,
            COALESCE(b.Advertiser_ID, d.Advertiser_ID) AS Advertiser_ID,
            COALESCE(b.Business_Unit, 'N/A')  AS Business_Unit,
            COALESCE(b.Ad_Unit_Format, 'N/A') AS Ad_Unit_Format,
            COALESCE(b.Ad_Unit_Size, 'N/A')   AS Ad_Unit_Size,
            COALESCE(b.Line_Item_ID, s.Line_Item_ID) AS Line_Item_ID,
            COALESCE(b.Line_Item_Name, d.Line_Item_Name) AS Line_Item_Name,
            COALESCE(b.Line_Item_Type, d.Line_Item_Type) AS Line_Item_Type,
            COALESCE(b.Line_Item_Start_Date, d.Line_Item_Start_Date) AS Line_Item_Start_Date,
            COALESCE(b.Line_Item_End_Date, d.Line_Item_End_Date) AS Line_Item_End_Date,
            COALESCE(b.Actual_Delivery_Indicator, d.Actual_Delivery_Indicator) AS Actual_Delivery_Indicator,
            CAST(COALESCE(b.Delivered_Revenue, 0) AS DOUBLE) AS Delivered_Revenue,
            COALESCE(b.Delivered_Impressions, 0) AS Delivered_Impressions,
            COALESCE(b.Video_Completes, 0) AS Video_Completes,
            COALESCE(b.Video_Starts, 0) AS Video_Starts,
            COALESCE(b.Delivered_Clicks, 0) AS Delivered_Clicks,
            COALESCE(b.Agency_Name, d.Agency_Name) AS Agency_Name,
            COALESCE(b.Advertiser_OMS, d.Advertiser_OMS) AS Advertiser_OMS,
            COALESCE(b.Account_Manager, d.Account_Manager) AS Account_Manager,
            COALESCE(b.Primary_Salesperson_Name, d.Primary_Salesperson_Name) AS Primary_Salesperson_Name,
            COALESCE(b.Account_Coordinator, d.Account_Coordinator) AS Account_Coordinator,
            COALESCE(b.Net_Unit_Cost, d.Net_Unit_Cost) AS Net_Unit_Cost,
            COALESCE(b.Guaranteed_Revenue, d.Guaranteed_Revenue) AS Guaranteed_Revenue,
            COALESCE(b.Guaranteed_Impressions, d.Guaranteed_Impressions) AS Guaranteed_Impressions,
            COALESCE(b.External_AD_ID, d.External_AD_ID) AS External_AD_ID,
            COALESCE(b.Parent_Line_Item_Name, d.Parent_Line_Item_Name) AS Parent_Line_Item_Name,
            COALESCE(b.AOS_Deal_ID, d.AOS_Deal_ID) AS AOS_Deal_ID,
            COALESCE(b.AOS_Deal_Name, d.AOS_Deal_Name) AS AOS_Deal_Name,
            COALESCE(b.AOS_Deal_Start_Date, d.AOS_Deal_Start_Date) AS AOS_Deal_Start_Date,
            COALESCE(b.AOS_Deal_End_Date, d.AOS_Deal_End_Date) AS AOS_Deal_End_Date,
            COALESCE(b.Demo_Band, d.Demo_Band) AS Demo_Band,
            COALESCE(b.Package_Name, d.Package_Name) AS Package_Name,
            COALESCE(b.Billable_Third_Party_Server, d.Billable_Third_Party_Server) AS Billable_Third_Party_Server,
            COALESCE(b.primary_property, d.primary_property) AS primary_property,
            COALESCE(b.pitch_id, d.pitch_id) AS pitch_id,
            COALESCE(b.cost_method_name, d.cost_method_name) AS cost_method_name,
            COALESCE(b.unit_type, d.unit_type) AS unit_type,
            COALESCE(b.Product_Name, d.Product_Name) AS Product_Name,
            COALESCE(b.fw_rbp_advanced, d.fw_rbp_advanced) AS fw_rbp_advanced,
            COALESCE(b.Third_Party_Line_Item_ID, d.Third_Party_Line_Item_ID) AS Third_Party_Line_Item_ID,
            COALESCE(b.Third_Party_Video_Completes, 0) AS Third_Party_Video_Completes,
            COALESCE(b.Third_Party_Video_Views, 0) AS Third_Party_Video_Views,
            COALESCE(b.Third_Party_Billable_Impressions, 0) AS Third_Party_Billable_Impressions,
            COALESCE(b.Third_Party_Clicks, 0) AS Third_Party_Clicks,
            COALESCE(b.Third_Party_Revenue, 0) AS Third_Party_Revenue,
            CURRENT_TIMESTAMP() AS Create_Timestamp,
            CURRENT_TIMESTAMP() AS Modified_Timestamp
        FROM spine s
        JOIN dims d
        ON s.Line_Item_ID = d.Line_Item_ID
        FULL OUTER JOIN base b
        ON b.Line_Item_ID = s.Line_Item_ID
        AND b.Event_Date = s.Event_Date
    )
    SELECT *
    FROM joined
    WHERE Event_Date between '2024-01-01' AND current_date()
"""

gam_campaign_pacing_with_dark_days = spark.sql(gam_campaign_pacing_with_dark_days_query)

# COMMAND ----------

# gam_campaign_pacing_with_dark_days = gam_campaign_pacing_with_dark_days.checkpoint()

# COMMAND ----------

gam_campaign_pacing_with_dark_days.write.format('delta')\
    .mode('overwrite')\
    .partitionBy('Event_Date')\
    .option('mergeSchema', 'true')\
    .option("optimizeWrite", "true") \
    .option('overwriteDynamicPartitions', 'true')\
    .option('delta.enableDeletionVectors', 'false')\
    .option('delta.enableIcebergCompatV2', 'true')\
    .option('delta.universalFormat.enabledFormats', 'iceberg')\
    .option('delta.columnMapping.mode', 'name')\
    .saveAsTable('fox_bi_prod.gold_ad_sales.ft_gam_campaign_pacing')

# COMMAND ----------

# Fix multiple Agency Name and Campaign period
orders_with_multiple_agency_and_campaign_periods_query = """
    SELECT
        Order_ID,
        COUNT(*)
    FROM (
        SELECT
            Order_ID,
            UPPER(Agency_Name) as Agency_Name,
            Campaign_Start_Date,
            Campaign_End_Date
        FROM fox_bi_prod.gold_ad_sales.ft_gam_campaign_pacing
        GROUP BY ALL
    )
    GROUP BY ALL
    HAVING COUNT(*) > 1;
"""

orders = spark.sql(orders_with_multiple_agency_and_campaign_periods_query)

orders_to_be_fixed = [order['Order_ID'] for order in orders.select('Order_ID').collect()]

if len(orders_to_be_fixed) > 0:
    # Get unique agency name for each order in orders_to_be_fixed
    unique_agency_query = """
        SELECT
            Order_ID,
            MAX(UPPER(Agency_Name)) AS Agency_Name
        FROM fox_bi_prod.gold_ad_sales.ft_gam_campaign_pacing
        WHERE Order_ID in {}
        AND Agency_Name != 'N/A'
        GROUP BY ALL
    """.format(tuple(orders_to_be_fixed) if len(orders_to_be_fixed) > 1 else f'({orders_to_be_fixed[0]})')

    spark.sql(unique_agency_query).createOrReplaceTempView('unique_agency_names')

    agency_fix_query = """
        MERGE INTO fox_bi_prod.gold_ad_sales.ft_gam_campaign_pacing AS tgt
            USING (
                SELECT
                    Order_ID,
                    Agency_Name
                FROM unique_agency_names
                GROUP BY ALL
            ) AS src
            ON COALESCE(src.Order_ID, -1) = COALESCE(tgt.Order_ID, -1)
            WHEN MATCHED AND (
                UPPER(COALESCE(src.Agency_Name, 'N/A')) != UPPER(COALESCE(tgt.Agency_Name, 'N/A'))
            ) THEN UPDATE SET
                tgt.Agency_Name = src.Agency_Name
    """

    spark.sql(agency_fix_query)

    # Get unique campaign period for each order in orders_to_be_fixed
    unique_campaign_period_query = """
        SELECT
            Order_ID,
            MIN(Campaign_Start_Date) AS Campaign_Start_Date,
            MAX(Campaign_End_Date) AS Campaign_End_Date
        FROM fox_bi_prod.gold_ad_sales.ft_gam_campaign_pacing
        WHERE Order_ID in {}
        GROUP BY ALL
    """.format(tuple(orders_to_be_fixed) if len(orders_to_be_fixed) > 1 else f'({orders_to_be_fixed[0]})')

    spark.sql(unique_campaign_period_query).createOrReplaceTempView('unique_campaign_period')

    campaign_period_fix_query = """
        MERGE INTO fox_bi_prod.gold_ad_sales.ft_gam_campaign_pacing AS tgt
            USING (
                SELECT
                    Order_ID,
                    Campaign_Start_Date,
                    Campaign_End_Date
                FROM unique_campaign_period
                GROUP BY ALL
            ) AS src
            ON COALESCE(src.Order_ID, -1) = COALESCE(tgt.Order_ID, -1)
            WHEN MATCHED AND (
                COALESCE(src.Campaign_Start_Date, 'N/A') != COALESCE(tgt.Campaign_Start_Date, 'N/A')
                OR COALESCE(src.Campaign_End_Date, 'N/A') != COALESCE(tgt.Campaign_End_Date, 'N/A')
            ) THEN UPDATE SET
                tgt.Campaign_Start_Date = src.Campaign_Start_Date
                , tgt.Campaign_End_Date = src.Campaign_End_Date
    """

    spark.sql(campaign_period_fix_query)

# COMMAND ----------

# Fix multiple Deal ID, Deal Name and Advertiser
orders_with_multiple_deal_and_advertiser_query = """
    SELECT
        Order_ID,
        COUNT(*)
    FROM (
        SELECT
            Order_ID,
            Advertiser_OMS,
            AOS_Deal_ID,
            AOS_Deal_Name,
            AOS_Deal_Start_Date,
            AOS_Deal_End_Date,
            Account_Manager,
            Primary_Salesperson_Name,
            Account_Coordinator
        FROM fox_bi_prod.gold_ad_sales.ft_gam_campaign_pacing
        GROUP BY ALL
    )
    GROUP BY ALL
    HAVING COUNT(*) > 1;
"""

orders = spark.sql(orders_with_multiple_deal_and_advertiser_query)

orders_to_be_fixed = [order['Order_ID'] for order in orders.select('Order_ID').collect()]

if len(orders_to_be_fixed) > 0:
    # Get unique advertiser name for each order in orders_to_be_fixed
    unique_advertiser_query = """
        SELECT
            Order_ID,
            MAX(UPPER(Advertiser_OMS)) AS Advertiser_OMS
        FROM fox_bi_prod.gold_ad_sales.ft_gam_campaign_pacing
        WHERE Order_ID in {}
        AND Advertiser_OMS != 'N/A'
        GROUP BY ALL
    """.format(tuple(orders_to_be_fixed) if len(orders_to_be_fixed) > 1 else f'({orders_to_be_fixed[0]})')

    spark.sql(unique_advertiser_query).createOrReplaceTempView('unique_advertiser_names')

    advertiser_fix_query = """
        MERGE INTO fox_bi_prod.gold_ad_sales.ft_gam_campaign_pacing AS tgt
            USING (
                SELECT
                    Order_ID,
                    Advertiser_OMS
                FROM unique_advertiser_names
                GROUP BY ALL
            ) AS src
            ON COALESCE(src.Order_ID, -1) = COALESCE(tgt.Order_ID, -1)
            WHEN MATCHED AND (
                UPPER(COALESCE(src.Advertiser_OMS, 'N/A')) != UPPER(COALESCE(tgt.Advertiser_OMS, 'N/A'))
            ) THEN UPDATE SET
                tgt.Advertiser_OMS = src.Advertiser_OMS
    """

    spark.sql(advertiser_fix_query)

    # Get unique deal is, name for each order in orders_to_be_fixed
    unique_deal_query = """
        SELECT
            Order_ID,
            AOS_Deal_ID,
            UPPER(AOS_Deal_Name) AS AOS_Deal_Name,
            AOS_Deal_Start_Date,
            AOS_Deal_End_Date,
            UPPER(Account_Manager) AS Account_Manager,
            UPPER(Primary_Salesperson_Name) AS Primary_Salesperson_Name,
            UPPER(Account_Coordinator) AS Account_Coordinator
        FROM fox_bi_prod.gold_ad_sales.ft_gam_campaign_pacing
        WHERE Order_ID in {}
        AND AOS_Deal_ID != -1
        GROUP BY ALL
    """.format(tuple(orders_to_be_fixed) if len(orders_to_be_fixed) > 1 else f'({orders_to_be_fixed[0]})')

    spark.sql(unique_deal_query).createOrReplaceTempView('unique_deal')

    deal_fix_query = """
        MERGE INTO fox_bi_prod.gold_ad_sales.ft_gam_campaign_pacing AS tgt
            USING (
                SELECT
                    Order_ID,
                    AOS_Deal_ID,
                    AOS_Deal_Name,
                    AOS_Deal_Start_Date,
                    AOS_Deal_End_Date,
                    Account_Manager,
                    Primary_Salesperson_Name,
                    Account_Coordinator
                FROM unique_deal
                GROUP BY ALL
            ) AS src
            ON COALESCE(src.Order_ID, -1) = COALESCE(tgt.Order_ID, -1)
            WHEN MATCHED AND (
                COALESCE(src.AOS_Deal_ID, -1) != COALESCE(tgt.AOS_Deal_ID, -1)
                OR UPPER(COALESCE(src.AOS_Deal_Name, 'N/A')) != UPPER(COALESCE(tgt.AOS_Deal_Name, 'N/A'))
                OR COALESCE(src.AOS_Deal_Start_Date, TO_DATE('1900-01-01')) != COALESCE(tgt.AOS_Deal_Start_Date, TO_DATE('1900-01-01'))
                OR COALESCE(src.AOS_Deal_End_Date, TO_DATE('2099-12-31')) != COALESCE(tgt.AOS_Deal_End_Date, TO_DATE('2099-12-31'))
                OR UPPER(COALESCE(src.Account_Manager, 'N/A')) != UPPER(COALESCE(tgt.Account_Manager, 'N/A'))
                OR UPPER(COALESCE(src.Primary_Salesperson_Name, 'N/A')) != UPPER(COALESCE(tgt.Primary_Salesperson_Name, 'N/A'))
                OR UPPER(COALESCE(src.Account_Coordinator, 'N/A')) != UPPER(COALESCE(tgt.Account_Coordinator, 'N/A'))
            ) THEN UPDATE SET
                tgt.AOS_Deal_ID = src.AOS_Deal_ID
                , tgt.AOS_Deal_Name = src.AOS_Deal_Name
                , tgt.AOS_Deal_Start_Date = src.AOS_Deal_Start_Date
                , tgt.AOS_Deal_End_Date = src.AOS_Deal_End_Date
                , tgt.Account_Manager = src.Account_Manager
                , tgt.Primary_Salesperson_Name = src.Primary_Salesperson_Name
                , tgt.Account_Coordinator = src.Account_Coordinator
    """

    spark.sql(deal_fix_query)