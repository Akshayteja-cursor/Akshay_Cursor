CREATE OR REPLACE MATERIALIZED VIEW `fox_bi_prod`.`gold_ad_sales`.`mv_ft_freewheel_campaign_delivery_geo_data` (
    Event_Date DATE,
    Campaign_ID BIGINT,
    Campaign_Name STRING,
    Campaign_Start_Date TIMESTAMP,
    Campaign_End_Date TIMESTAMP,
    Placement_ID BIGINT,
    Placement_Name STRING,
    Advertiser_Name STRING,
    Agency_Name STRING,
    Account_Manager STRING,
    AOS_Deal_ID BIGINT,
    Device STRING,
    Country_Name STRING,
    `State/Province_Name` STRING,
    Dma_Name STRING,
    City_Name STRING,
    Zip_Postal_Code STRING,
    Delivered_Impressions BIGINT,
    Delivered_Clicks BIGINT,
    `Video_Ads_25%_Complete` BIGINT,
    `Video_Ads_50%_Complete` BIGINT,
    `Video_Ads_75%_Complete` BIGINT,
    `Video_Ads_100%_Complete` BIGINT,
    Measurable_Video_Ads_Quartile_Impressions BIGINT,
    Event_Month STRING,
    Event_Quarter STRING,
    Event_Year STRING,
    Create_Timestamp TIMESTAMP,
    Modified_Timestamp TIMESTAMP,
    Insertion_Order_Id BIGINT,
    Insertion_Order_Name STRING,
    Insertion_Order_Start_Date TIMESTAMP,
    Insertion_Order_End_Date TIMESTAMP,
    Placement_Start_Date TIMESTAMP,
    Placement_End_Date TIMESTAMP
  ) AS
(
  select
    event_date as `Event_Date`,
    campaign_id as `Campaign_ID`,
    campaign_name as `Campaign_Name`,
    campaign_start_timestamp_est as `Campaign_Start_Date`,
    campaign_end_timestamp_est as `Campaign_End_Date`,
    placement_id as `Placement_ID`,
    placement_name as `Placement_Name`,
    advertiser_name as `Advertiser_Name`,
    agency_name as `Agency_Name`,
    account_manager as `Account_Manager`,
    AOS_Deal_ID as `AOS_Deal_ID`,
    delivered_device as `Device`,
    delivered_country_name as `Country_Name`,
    delivered_state_province_name as `State/Province_Name`,
    delivered_dma_name as `Dma_Name`,
    delivered_city_name as `City_Name`,
    delivered_zip_postal_code as `Zip_Postal_Code`,
    net_counted_ads as `Delivered_Impressions`,
    delivered_clicks as `Delivered_Clicks`,
    video_ads_25_complete as `Video_Ads_25%_Complete`,
    video_ads_50_complete as `Video_Ads_50%_Complete`,
    video_ads_75_complete as `Video_Ads_75%_Complete`,
    video_ads_100_complete as `Video_Ads_100%_Complete`,
    measurable_video_ads_quartile_impressions as `Measurable_Video_Ads_Quartile_Impressions`,
    event_month as `Event_Month`,
    event_quarter as `Event_Quarter`,
    event_year as `Event_Year`,
    etl_load_timestamp `Create_Timestamp`,
    etl_load_timestamp `Modified_Timestamp`,
    insertion_order_id `Insertion_Order_Id`,
    insertion_order_name `Insertion_Order_Name`,
    insertion_order_start_timestamp_est `Insertion_Order_Start_Date`,
    insertion_order_end_timestamp_est `Insertion_Order_End_Date`,
    placement_start_timestamp_est `Placement_Start_Date`,
    placement_end_timestamp_est `Placement_End_Date`
  from
    fox_bi_prod.silver_ads.ft_freewheel_geo_daily_data geo
      left join (
        select
          ps_line_item_id,
          owner_name account_manager,
          sales_order_ID::bigint as AOS_Deal_ID
        from
          fox_bi_prod.gold_ad_sales.ft_digital_operative_line_detail
        group by
          all
      ) oms
        on oms.ps_line_item_id = geo.placement_id
  CLUSTER BY
    campaign_id,
    event_date
)