# Databricks notebook source
from datetime import datetime, timedelta

# COMMAND ----------

spark.conf.set(
    "spark.databricks.remoteFiltering.blockSelfJoins",
    "false"
)


# COMMAND ----------

# spark.sparkContext.setCheckpointDir("dbfs:/checkpoints/agg_unified_campaign_pacing")


# COMMAND ----------

# Reduce shuffle partitions
spark.conf.set("spark.sql.shuffle.partitions", "200")

# COMMAND ----------

# Adaptive query execution
spark.conf.set("spark.sql.adaptive.enabled",                    "true")
spark.conf.set("spark.sql.adaptive.localShuffleReader.enabled", "true")
spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled", "true")

# COMMAND ----------

# Delta optimized write
spark.conf.set("spark.databricks.delta.optimizeWrite.enabled", "true")
spark.conf.set("spark.databricks.delta.autoCompact.enabled",   "true")

# COMMAND ----------

query = """

WITH fw_base AS (
    SELECT
        Event_date AS event_date
        , Data_Source
        , Campaign_ID
        , Campaign_Name
        , Campaign_Start_Date
        , Campaign_End_Date
        , AOS_Deal_Name
        , AOS_Deal_ID
        , AOS_Deal_start_date
        , AOS_Deal_end_date
        , AOS_Deal_Line_Item_ID
        , AOS_Deal_Line_Item_Name
        , AOS_Deal_Line_Item_Start_Date
        , AOS_Deal_Line_Item_end_Date
        , parent_line_item_name
        , AOS_Advertiser_Name
        , AOS_Agency_Name
        , advertiser_Name
        , agency_Name
        , Package_Name
        , Account_Manager
        , Account_Executive
        , Account_Coordinator
        , Billable_Third_Party_Server
        , Primary_Property
        , Pitch_ID
        , cost_method_name
        , unit_type
        , UPPER(product_name) AS product_name
        , UPPER(fw_rbp_advanced) AS fw_rbp_advanced
        , External_AD_ID
        , Line_Item_or_Placement_ID
        , Line_Item_or_Placement_Name
        , Line_Item_or_Placement_Start_Date
        , Line_Item_or_Placement_End_Date
        , budget_model
        , Campaign_Status
        , out_of_flight_flag
        , out_of_flight_impressions
        , placement_avg_user_frequency
        , booked_on_target_impression_goal
        , Impression_Goal
        , Demand_Type
        , Demo_Band
        , demo_comp
        , Delivered_Clicks
        , Delivered_Impressions AS delivered_impressions
        , Video_Completes
        , Video_Starts
        , total_engagements
        , Delivered_Revenue
        , Guaranteed_Impressions
        , Guaranteed_Revenue
        , Net_Unit_Cost
        , campaign_days::double
        , days_to_date
        -- impressions per LIVE day across the line item's flight) AS campaign_days,
        -- impressions per LIVE day across the line item's flight.
        -- denominator = total live days expected over the full flight
        --             = live days observed in flight
        --               + remaining calendar days after the latest observed day (assumed live)
        -- _rn_per_day = 1 ensures each calendar day is counted at most once
        -- (replaces the unsupported COUNT(DISTINCT event_date) OVER (...) pattern)
        , Guaranteed_Impressions / campaign_days AS daily_impression_goal
        -- expected impressions delivered through the latest observed live day (Freewheel only)
        -- = daily_impression_goal (per-live-day rate) * live days elapsed in flight
        , daily_impression_goal * live_days AS impression_goal_to_date
        , CASE
            WHEN data_source IN ('GAM', 'GAM Sports')
            THEN CASE
                     WHEN MAX(event_date) OVER (PARTITION BY Line_Item_or_Placement_ID, Campaign_ID)
                          < COALESCE(Line_Item_or_Placement_End_Date::date, Campaign_End_Date::date)
                     THEN (
                              DATE_DIFF(
                                  MAX(event_date) OVER (PARTITION BY Line_Item_or_Placement_ID, Campaign_ID),
                                  COALESCE(Line_Item_or_Placement_Start_Date::date, Campaign_Start_Date::date)
                              ) + 1
                          ) / (
                              DATE_DIFF(
                                  COALESCE(Line_Item_or_Placement_End_Date::date, Campaign_End_Date::date),
                                  COALESCE(Line_Item_or_Placement_Start_Date::date, Campaign_Start_Date::date)
                              ) + 1
                          )
                     ELSE 1
                 END
        END AS OSI_total
        , MIN(Freewheel_On_Target_Net_Delivered_Impressions) OVER (
            PARTITION BY Line_Item_or_Placement_ID, Event_Date
        ) AS min_on_target_net_delivered_impressions
        , Modified_Timestamp
    FROM fox_bi_prod.gold_ad_sales.ft_unified_campaign_pacing
    --WHERE NVL(AOS_Deal_ID, -1) <> -1
    --  AND NVL(AOS_Deal_Line_Item_ID, -1) <> -1--  AND nvl(AOS_Deal_Line_Item_Name,'N/A') not ilike 'cancelled%'
    --   and nvl(AOS_deal_id,-1) in (252732,16188,18484)
    -- GROUP BY ALL
)
, agg_fw_data AS (
    SELECT
          Data_Source
        , Campaign_ID
        , Campaign_Name
        , Campaign_Start_Date
        , Campaign_End_Date
        , AOS_Deal_Name
        , AOS_Deal_ID
        , AOS_Deal_start_date
        , AOS_Deal_end_date
        , AOS_Deal_Line_Item_ID
        , AOS_Deal_Line_Item_Name
        , AOS_Deal_Line_Item_Start_Date
        , AOS_Deal_Line_Item_end_Date
        , Line_Item_or_Placement_ID
        , Line_Item_or_Placement_Name
        , Line_Item_or_Placement_Start_Date
        , Line_Item_or_Placement_End_Date
        , budget_model
        , parent_line_item_name
        , AOS_Advertiser_Name
        , AOS_Agency_Name
        , advertiser_Name
        , agency_Name
        , Package_Name
        , Account_Manager
        , Account_Executive
        , Account_Coordinator
        , Billable_Third_Party_Server
        , Primary_Property
        , Pitch_ID
        , cost_method_name
        , unit_type
        , product_name
        , fw_rbp_advanced
        , External_AD_ID
        , Campaign_Status
        , out_of_flight_flag
        , out_of_flight_impressions
        , placement_avg_user_frequency
        , booked_on_target_impression_goal
        , Impression_Goal
        , Demand_Type
        , Demo_Band
        , demo_comp
        , daily_impression_goal
        , impression_goal_to_date
        , campaign_days
        , days_to_date
        , OSI_total
        , Guaranteed_Impressions
        , Guaranteed_Revenue
        , Net_Unit_Cost
        , SUM(delivered_clicks) AS del_clicks
        , SUM(Delivered_Impressions) AS del_imps
        , SUM(delivered_revenue) AS del_rev
        , SUM(Video_Completes) AS Video_Completes
        , SUM(Video_Starts) AS Video_Starts
        , SUM(total_engagements) AS total_engagements
        -- , NVL(MIN(min_on_target_net_delivered_impressions), 0) AS on_tar
        , MAX(Modified_Timestamp) AS Modified_Timestamp
    FROM fw_base
    GROUP BY ALL
)
,fw_on_tar_imps_data as 
(select 
  placement_id, 
  sum(on_target_net_delivered_impressions_quantity) as on_tar 
from (
  select 
    Line_Item_or_Placement_ID as placement_id,
    event_date,
    Freewheel_On_Target_Net_Delivered_Impressions as on_target_net_delivered_impressions_quantity 
  from fox_bi_prod.gold_ad_sales.ft_unified_campaign_pacing
  -- where Line_Item_or_Placement_ID = 78416372 
  group by all
)
group by all)
, third_party_data AS (
    SELECT
        aos_deal_id
        , line_item_or_placement_id
        , aos_deal_line_item_id
        , SUM(
            CASE
                WHEN NVL(third_party_line_item_id, '-1') = '-1' THEN 0
                WHEN NVL(third_party_impressions, 0) = 0 THEN 0
                WHEN data_source IN ('GAM')
                THEN CASE
                         WHEN Demand_Type = 'SPONSORSHIP' THEN Guaranteed_Revenue
                         ELSE ((third_party_impressions) * net_unit_cost) / 1000
                     END
                ELSE (third_party_revenue)
            END
        ) AS third_party_revenue
        , SUM(third_party_impressions) AS third_party_impressions
        , SUM(third_party_clicks) AS third_party_clicks
        , SUM(third_party_video_completes) AS third_party_video_completes
        , SUM(third_party_video_views) AS third_party_video_views
    FROM (
        SELECT
            pl.AOS_Deal_ID
            , line_item_or_placement_id
            , aos_deal_line_item_id
            , demand_type
            , third_party_line_item_id
            , Data_Source
            , Net_Unit_Cost
            , guaranteed_impressions
            , guaranteed_revenue
            , SUM(third_party_impressions) AS third_party_impressions
            , SUM(third_party_revenue) AS third_party_revenue
            , SUM(third_party_clicks) AS third_party_clicks
            , SUM(third_party_video_completes) AS third_party_video_completes
            , SUM(third_party_video_views) AS third_party_video_views
        FROM (
            SELECT DISTINCT
                AOS_Deal_ID
                , Line_Item_or_Placement_ID
                , Third_Party_Line_Item_ID
                , Demand_Type
                , AOS_Deal_Line_Item_ID
                , Creative_ID
                , Event_Date
                , Ad_Unit_Position
                , Data_Source
                , Net_Unit_Cost
                , guaranteed_impressions
                , guaranteed_revenue
                , MIN(Third_Party_Billable_Impressions) AS third_party_impressions
                , MIN(Third_Party_Revenue) AS third_party_revenue
                , MIN(third_party_clicks) AS third_party_clicks
                , MIN(third_party_video_completes) AS third_party_video_completes
                , MIN(third_party_video_views) AS third_party_video_views
            FROM fox_bi_prod.gold_ad_sales.ft_unified_campaign_pacing
            WHERE UPPER(Data_Source) IN ('FREEWHEEL', 'GAM')
            -- WHERE `AOS_Deal_ID` = 16188
            GROUP BY ALL
        ) AS pl
        GROUP BY ALL
    )
    GROUP BY ALL
    UNION ALL
    SELECT DISTINCT
        AOS_Deal_ID
        , Line_Item_or_Placement_ID
        , AOS_Deal_Line_Item_ID
        , SUM(Third_Party_Revenue) AS third_party_revenue
        , SUM(Third_Party_Billable_Impressions) AS third_party_impressions
        , SUM(third_party_clicks) AS third_party_clicks
        , SUM(third_party_video_completes) AS third_party_video_completes
        , SUM(third_party_video_views) AS third_party_video_views
    FROM fox_bi_prod.gold_ad_sales.ft_unified_campaign_pacing
    WHERE UPPER(Data_Source) NOT IN ('FREEWHEEL', 'GAM')
    -- WHERE `AOS_Deal_ID` = 16188
    GROUP BY ALL
)

----------------------------------------------
, calculated_metrics_data AS (
    SELECT
        Data_Source
        , Campaign_ID
        , Campaign_Name
        , Campaign_Start_Date::date AS Campaign_Start_Date
        , Campaign_End_Date::date AS Campaign_End_Date
        , AOS_Deal_Name
        , cov_data.AOS_Deal_ID
        , AOS_Deal_start_date::date AS AOS_Deal_start_date
        , AOS_Deal_end_date::date AS AOS_Deal_end_date
        , cov_data.AOS_Deal_Line_Item_ID
        , AOS_Deal_Line_Item_Name
        , AOS_Deal_Line_Item_Start_Date::date AS AOS_Deal_Line_Item_Start_Date
        , AOS_Deal_Line_Item_end_Date::date AS AOS_Deal_Line_Item_end_Date
        , cov_data.Line_Item_or_Placement_ID
        , Line_Item_or_Placement_Name
        , Line_Item_or_Placement_Start_Date::date AS Line_Item_or_Placement_Start_Date
        , Line_Item_or_Placement_End_Date::date AS Line_Item_or_Placement_End_Date
        , budget_model
        , parent_line_item_name
        , UPPER(AOS_Advertiser_Name) AS AOS_Advertiser_Name
        , UPPER(AOS_Agency_Name) AS AOS_Agency_Name
        , UPPER(advertiser_Name) AS advertiser_Name
        , UPPER(agency_Name) AS agency_Name
        , UPPER(Package_Name) AS Package_Name
        , UPPER(Account_Manager) AS Account_Manager
        , UPPER(Account_Executive) AS Account_Executive
        , UPPER(Account_Coordinator) AS Account_Coordinator
        , Billable_Third_Party_Server
        , Primary_Property
        , Pitch_ID
        , External_AD_ID
        , Campaign_Status
        , out_of_flight_flag
        , SUM(out_of_flight_impressions) AS out_of_flight_impressions
        , placement_avg_user_frequency
        , Demand_Type
        , Demo_Band
        , daily_impression_goal
        , impression_goal_to_date
        , campaign_days
        , days_to_date
        , Guaranteed_Impressions
        , Guaranteed_Revenue
        , Net_Unit_Cost
        , SUM(DISTINCT on_tar) AS Freewheel_On_Target_Net_Delivered_Impressions
        , SUM(del_imps) AS first_party_delivered_impressions
        , SUM(del_clicks) AS first_party_delivered_clicks
        , CASE
            WHEN data_source IN ('GAM', 'GAM Sports')
            THEN CASE
                     WHEN Demand_Type = 'SPONSORSHIP' THEN Guaranteed_Revenue
                     ELSE (SUM(del_imps) * MAX(net_unit_cost)) / 1000
                 END
            ELSE SUM(del_rev)
        END AS first_party_delivered_revenue
        , SUM(Video_Completes) AS Video_Completes
        , SUM(Video_Starts) AS Video_Starts
        , SUM(total_engagements) AS total_engagements
        , CASE
            WHEN data_source = 'Freewheel'
            THEN (
                CASE
                    WHEN Product_Name ILIKE '%ABSOLUTE A%' THEN 1.2
                    WHEN SUM(del_imps) = 0
                         AND (
                             budget_model = 'Demographic Impression Target'
                             OR fw_rbp_advanced ILIKE '%FW - APPLY CO-VIEWING=YES%'
                         )
                    THEN (
                        CASE
                            WHEN MAX(booked_on_target_impression_goal) = 0 THEN NULL
                            ELSE MAX(booked_on_target_impression_goal) / MAX(Impression_Goal)
                        END
                    )
                    ELSE SUM(DISTINCT on_tar) / (SUM(del_imps))
                END
            )
            ELSE NULL
        END::decimal(7,2) AS cov
        , CASE
            WHEN Billable_Third_Party_Server = 'FOX 1st Party'
                 AND budget_model = 'Demographic Impression Target'
            THEN SUM(del_imps) * CoV
            WHEN Billable_Third_Party_Server = 'FOX 1st Party'
                 AND budget_model = 'Impression Target'
            THEN SUM(del_imps)
            WHEN Billable_Third_Party_Server != 'FOX 1st Party'
                 AND budget_model = 'Impression Target'
            THEN CASE WHEN MIN(third_party_impressions) > 0 THEN MIN(third_party_impressions) ELSE SUM(del_imps) END
            WHEN Billable_Third_Party_Server != 'FOX 1st Party'
                 AND budget_model = 'Demographic Impression Target'
            THEN CASE WHEN MIN(third_party_impressions) > 0 THEN MIN(third_party_impressions) ELSE SUM(del_imps) END * CoV
            WHEN UPPER(unit_type) = 'DAYS' THEN campaign_days
            WHEN UPPER(cost_method_name) ILIKE '%FLAT%'
            THEN CASE
                     WHEN MAX(guaranteed_impressions) > 1 THEN CASE WHEN MIN(third_party_impressions) > 0 THEN MIN(third_party_impressions) ELSE SUM(del_imps) END
                     WHEN MAX(guaranteed_impressions) = 1 THEN 1
                 END
            ELSE CASE WHEN MIN(third_party_impressions) > 0 THEN MIN(third_party_impressions) ELSE SUM(del_imps) END
        END AS campaign_billable_impressions
        , ((campaign_billable_impressions / guaranteed_impressions))::decimal(7,2) AS campaign_del_pct
        , (
            CASE
                WHEN MAX(guaranteed_impressions) = 1 THEN NULL
                WHEN data_source = 'Freewheel' AND demand_type = 'PROGRAMMATIC GUARANTEED'
                THEN SUM(del_imps) / MAX(impression_goal_to_date)
                WHEN data_source = 'Freewheel' AND demand_type = 'DIRECT SOLD'
                THEN CASE
                         WHEN Demo_Band = 'Audience Target' THEN SUM(del_imps) / MAX(impression_goal_to_date)
                         WHEN Demo_Band = 'P2+' THEN (SUM(del_imps) * (CASE WHEN SUM(DISTINCT on_tar) = 0 THEN 1.2 ELSE NVL(SUM(DISTINCT on_tar) / SUM(del_imps), 1.2) END::decimal(7,2))) / MAX(impression_goal_to_date)
                         WHEN Demo_Band = 'N/A' THEN NULL
                         ELSE SUM(del_imps * demo_comp) / MAX(impression_goal_to_date)
                     END
                WHEN data_source IN ('GAM', 'GAM Sports') THEN (SUM(del_imps) / MAX(guaranteed_impressions)) * MAX(OSI_total)
            END
        )::decimal(7,2) AS first_party_pacing_pct
        , (
            CASE
                WHEN data_source = 'Freewheel' AND demand_type NOT IN ('PROGRAMMATIC GUARANTEED', 'MARKETPLACE PLATFORM PRIVATE', 'MARKETPLACE PLATFORM EXCHANGE')
                THEN CASE
                         WHEN Demo_Band = 'Audience Target' THEN MIN(third_party_impressions) / MAX(impression_goal_to_date)
                         WHEN Demo_Band = 'P2+' THEN (MIN(third_party_impressions) * (CASE WHEN SUM(DISTINCT on_tar) = 0 THEN 1.2 ELSE NVL(SUM(DISTINCT on_tar) / SUM(del_imps), 1.2) END::decimal(7,2))) / MAX(impression_goal_to_date)
                         WHEN Demo_Band = 'N/A' THEN NULL
                         ELSE MIN(third_party_impressions) * MIN(demo_comp) / MAX(impression_goal_to_date)
                     END
                WHEN data_source IN ('GAM', 'GAM Sports') THEN (MIN(third_party_impressions) / MAX(guaranteed_impressions)) * MAX(impression_goal_to_date)
            END
        )::decimal(7,2) AS third_party_pacing_pct
        , campaign_billable_impressions / MAX(impression_goal_to_date) AS campaign_pacing_pct
        , (NVL(first_party_pacing_pct, 0) - NVL(third_party_pacing_pct, 0)) as  pacing_discrepency
        , CASE
            WHEN UPPER(unit_type) = 'DAYS' OR (UPPER(cost_method_name) ILIKE '%FLAT%' AND MAX(guaranteed_impressions) = 1)
            THEN campaign_billable_impressions * net_unit_cost
            ELSE ((campaign_billable_impressions / 1000) * net_unit_cost)
        END AS billable_revenue
        , CASE
            WHEN campaign_end_date <= CURRENT_DATE()
            THEN billable_revenue - guaranteed_revenue
            ELSE NULL
        END AS under_vs_over_delivery
        , campaign_billable_impressions  / (daily_impression_goal * days_to_date) AS risk
        , SUM(del_imps) / MAX(placement_avg_user_frequency) AS reach
        , MIN(third_party_impressions) AS third_party_impressions
        , MIN(third_party_revenue) AS third_party_revenue
        , MIN(third_party_clicks) AS third_party_clicks
        , MIN(third_party_video_completes) AS third_party_video_completes
        , MIN(third_party_video_views) AS third_party_video_views
        , (SUM(Video_Completes) / SUM(Video_Starts)) AS first_party_vcr
        , (MIN(third_party_video_completes) / MIN(third_party_impressions)) AS third_party_vcr
        , (SUM(del_clicks) / SUM(del_imps)) AS first_party_clicks_thru
        , (MIN(third_party_clicks) / MIN(third_party_impressions)) AS third_party_clicks_thru
        , MAX(Modified_Timestamp) AS Modified_Timestamp
    FROM agg_fw_data AS cov_data
    LEFT JOIN fw_on_tar_imps_data otnd
        ON cov_data.line_item_or_placement_id = otnd.placement_id
    LEFT JOIN third_party_data AS tpd
        ON cov_data.aos_deal_id = tpd.aos_deal_id
        AND cov_data.aos_deal_line_item_id = tpd.aos_deal_line_item_id
        AND cov_data.line_item_or_placement_id = tpd.line_item_or_placement_id
    -- where cov_data.aos_deal_id in (252732,16188,18484)
    GROUP BY
        Data_Source
        , Campaign_ID
        , Campaign_Name
        , Campaign_Start_Date
        , Campaign_End_Date
        , AOS_Deal_Name
        , cov_data.AOS_Deal_ID
        , AOS_Deal_start_date
        , AOS_Deal_end_date
        , cov_data.AOS_Deal_Line_Item_ID
        , AOS_Deal_Line_Item_Name
        , AOS_Deal_Line_Item_Start_Date
        , AOS_Deal_Line_Item_end_Date
        , cov_data.Line_Item_or_Placement_ID
        , Line_Item_or_Placement_Name
        , Line_Item_or_Placement_Start_Date
        , Line_Item_or_Placement_End_Date
        , budget_model
        , parent_line_item_name
        , AOS_Advertiser_Name
        , AOS_Agency_Name
        , advertiser_Name
        , agency_Name
        , Package_Name
        , Account_Manager
        , Account_Executive
        , Account_Coordinator
        , Billable_Third_Party_Server
        , Primary_Property
        , Pitch_ID
        , cost_method_name
        , unit_type
        , External_AD_ID
        , Campaign_Status
        , out_of_flight_flag
        , placement_avg_user_frequency
        , Demand_Type
        , Demo_Band
        , daily_impression_goal
        , impression_goal_to_date
        , campaign_days
        , days_to_date
        , Guaranteed_Impressions
        , Guaranteed_Revenue
        , Net_Unit_Cost
        , product_name
        , fw_rbp_advanced
)

SELECT Data_Source::string
,Campaign_ID::bigint
,Campaign_Name::string
,Campaign_Start_Date::date
,Campaign_End_Date::date
,AOS_Deal_Name::string
,AOS_Deal_ID::bigint
,AOS_Deal_start_date::date
,AOS_Deal_end_date::date
,AOS_Deal_Line_Item_ID::bigint
,AOS_Deal_Line_Item_Name::string
,AOS_Deal_Line_Item_Start_Date::date
,AOS_Deal_Line_Item_end_Date::date
,Line_Item_or_Placement_ID::string
,Line_Item_or_Placement_Name::string
,Line_Item_or_Placement_Start_Date::date
,Line_Item_or_Placement_End_Date::date
,budget_model::string
,parent_line_item_name::string
,AOS_Advertiser_Name::string
,AOS_Agency_Name::string
,advertiser_Name::string
,agency_Name::string
,Package_Name::string
,Account_Manager::string
,Account_Executive::string
,Account_Coordinator::string
,Billable_Third_Party_Server::string
,Primary_Property::string
,Pitch_ID::string
,External_AD_ID::string
,Campaign_Status::string
,out_of_flight_flag::boolean
,out_of_flight_impressions::bigint
,placement_avg_user_frequency::string
,Demand_Type::string
,Demo_Band::string
,daily_impression_goal::double
,impression_goal_to_date::double
,campaign_days::double
,days_to_date::double
,Guaranteed_Impressions::bigint
,Guaranteed_Revenue::double
,Net_Unit_Cost::double
,Freewheel_On_Target_Net_Delivered_Impressions::bigint
,first_party_delivered_impressions::bigint
,first_party_delivered_clicks::bigint
,first_party_delivered_revenue::double
,Video_Completes::bigint
,Video_Starts::bigint
,total_engagements::bigint
,cov::decimal(7,2)
,campaign_billable_impressions::decimal(28,2)
,campaign_pacing_pct::double
,campaign_del_pct::decimal(7,2)
,first_party_pacing_pct::decimal(7,2)
,third_party_pacing_pct::decimal(7,2)
,pacing_discrepency::decimal(8,2)
,billable_revenue::double
,under_vs_over_delivery::double
,risk::double
,reach::double
,third_party_impressions::bigint
,third_party_revenue::double
,third_party_clicks::bigint
,third_party_video_completes::bigint
,third_party_video_views::bigint
,first_party_vcr::double
,third_party_vcr::double
,first_party_clicks_thru::double
,third_party_clicks_thru::double
,Modified_Timestamp::timestamp FROM calculated_metrics_data
"""


unified_campaign_delivery = spark.sql(query)

# COMMAND ----------

# unified_campaign_delivery = unified_campaign_delivery.checkpoint()   # ← materializes before shuffle

# COMMAND ----------

unified_campaign_delivery.write.format('delta')\
    .mode('overwrite')\
    .partitionBy('Campaign_ID')\
    .option('mergeSchema', 'true')\
    .option("optimizeWrite", "true")\
    .option('overwriteDynamicPartitions', 'true')\
    .option('delta.enableDeletionVectors', 'false')\
    .option('delta.enableIcebergCompatV2', 'true')\
    .option('delta.universalFormat.enabledFormats', 'iceberg')\
    .option('delta.columnMapping.mode', 'name')\
    .saveAsTable('fox_bi_prod.gold_ad_sales.agg_unified_campaign_pacing')