# Databricks notebook source
from pyspark.sql.functions import col
from datetime import datetime, timedelta
from pyspark.sql.types import LongType, DoubleType

# COMMAND ----------

spark.conf.set(
    "spark.databricks.remoteFiltering.blockSelfJoins",
    "false"
)

# COMMAND ----------

# spark.sparkContext.setCheckpointDir("dbfs:/checkpoints/your-job-name")

# COMMAND ----------

# Reduce shuffle partitions
spark.conf.set("spark.sql.shuffle.partitions", "200")

# COMMAND ----------

# Adaptive query execution
spark.conf.set("spark.sql.adaptive.enabled",                    "true")
spark.conf.set("spark.sql.adaptive.localShuffleReader.enabled", "true")
spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled", "true")

# COMMAND ----------

# Delta optimized write
spark.conf.set("spark.databricks.delta.optimizeWrite.enabled", "true")
spark.conf.set("spark.databricks.delta.autoCompact.enabled",   "true")


# COMMAND ----------

query = """ 
    
    with raw_fw_data as 
	(
	 select
	 'Freewheel' as `Data_Source`,
	 event_date as `Event_Date`,  
	 COALESCE(Campaign_ID, Deal_ID) as `Campaign_ID`,
	 COALESCE(Campaign_Name, Deal_Name) as `Campaign_Name`,
	 COALESCE(campaign_start_timestamp_est::date, Deal_Start_Date::date) as `Campaign_Start_Date`,
	 COALESCE(campaign_end_timestamp_est::date, Deal_End_Date::date) as `Campaign_End_Date`,
     campaign_avg_user_frequency as `Campaign_Avg_User_Frequency`,
	 Campaign_Name_Derived,
     case
        when COALESCE(placement_end_date::date, Deal_End_Date::date) > current_timestamp() - INTERVAL 1 DAY then 'Active'
        else 'Closed' 
     end as `Campaign_Status`,     
	 Insertion_Order_ID as `Order_ID`,
	 Insertion_Order_Name as `Order_Name`,
	 device_name as `Device`,
     advertiser_id,
	 Advertiser_Name as `Advertiser_Name`,
	 Agency_Name as `Agency_Name`,
	 AOS_advertiser_name as `AOS_Advertiser_Name`,
     AOS_agency_name as `AOS_Agency_Name`,
	 Business_Unit as `Business_Unit`,
     Third_Party_Line_Item_ID as `Third_Party_Line_Item_ID`, 
	 placement_id as `Line_Item_or_Placement_ID`,
	 placement_name `Line_Item_or_Placement_Name`,
	 case
	   when sales_channel_type = 'PROGRAMMATIC' then deal_type
	   else sales_channel_type
	 end `Demand_Type`,
	 placement_start_date::date as `Line_Item_or_Placement_Start_Date`,
	 placement_end_date::date as `Line_Item_or_Placement_End_Date`,
     budget_model,
	 placement_avg_user_frequency,
	 External_AD_ID `External_AD_ID`,
	 aos_deal_id AS `AOS_Deal_ID`,
	 AOS_deal_name `AOS_Deal_Name`,
	 AOS_Deal_Start_Date::date as `AOS_Deal_Start_Date`,
	 AOS_Deal_End_Date::date as `AOS_Deal_End_Date`,
	 sales_order_line_item_id as `AOS_Deal_Line_Item_ID`,
	 sales_order_line_item_name as `AOS_Deal_Line_Item_Name`,
     sales_order_line_item_start_date as `AOS_Deal_Line_Item_Start_Date`,
     sales_order_line_item_end_date as `AOS_Deal_Line_Item_end_Date`,
	 package_name `Package_Name`,
     parent_line_item_name,
     account_coordinator,
     primary_salesperson_name `Account_Executive`,
	 owner_name `Account_Manager`,
	 demo_band `Demo_Band`,
	 billable_third_part_server `Billable_Third_Party_Server`,
     primary_property `Primary_Property`,
     pitch_id `Pitch_ID` ,
     cost_method_name,
     unit_type,
     product_name,
     fw_rbp_advanced,
   creative_id,
   creative_name,
   creative_duration_secs,
   demo_comp,
   planned_demo_comp,
   fw_audience_segment,
   fw_video_group,
   global_ad_unit_category as `ad_unit_format`,
   global_ad_unit_position as `Ad_Unit_Position`,
   series_name,
   show_name,
   video_id,
   video_name,
	 CASE
	   WHEN regexp_substr(`Insertion_Order_Name`, '^\\\d+[^-|_| ]*') in (
	 	  select distinct regexp_substr(`Order_Name`, '^\\\d+[^-|_| ]*')
	 	  from fox_bi_prod.gold_ad_sales.ft_gam_campaign_pacing)
	   THEN True
	   ELSE False
	 END Multiple_Ad_Servers,
	 regexp_substr(`Insertion_Order_Name`, '^\\\d+[^-|_| ]*') `Multiple_Ad_Server_ID`,
	 net_unit_cost `Net_Unit_Cost`,
	 Guaranteed_Impressions `Guaranteed_Impressions`,
	 Guaranteed_Revenue `Guaranteed_Revenue`,
   gross_counted_ads `Gross_Counted_Ads`,
   booked_on_target_impression_goal `Booked_On_Target_Impression_Goal`,
   impression_goal `Impression_Goal`,
   delivered_impressions `Delivered_Impressions`,
	 Delivered_Revenue `Delivered_Revenue`,
	 null `Video_Completes`,
	 null as `Video_Starts`,
	 delivered_clicks `Delivered_Clicks`,
	 on_target_net_delivered_impressions_quantity `Freewheel_On_Target_Net_Delivered_Impressions`,
   out_of_flight_flag,
   out_of_flight_impressions,
   third_party_video_completes, 
   third_party_video_views,
   third_party_billable_impressions,
   third_party_clicks,
   third_party_revenue,
    0 as total_engagements,
	 Create_Timestamp `Create_Timestamp`,
	 Modified_Timestamp `Modified_Timestamp`
  from
	fox_bi_prod.gold_ad_sales.ft_freewheel_campaign_pacing cmp
	-- where 1 = 1
  -- and campaign_id = 74403146
  -- and third_party_billable_impressions > 0
  -- and event_date = '2024-03-15'
  -- and placement_id = '86295416' 
	-- and business_unit = 'Entertainment' and device_name = 'DT'
  -- group by all
	 )

 ,raw_gam_data AS (
	 select
	 'GAM' as `Data_Source`,
	 event_date as `Event_Date`,  
	 Campaign_ID as `Campaign_ID`,
	 Campaign_Name as `Campaign_Name`,
	 Campaign_Start_Date::date as `Campaign_Start_Date`,
	 Campaign_End_Date::date as `Campaign_End_Date`,
   0 as `Campaign_Avg_User_Frequency`,
	 advertiser_name ||' - '|| campaign_start_date::date || ' - '|| campaign_end_date::date as `Campaign_Name_Derived`,
	 case
        when Campaign_End_Date > current_timestamp() - INTERVAL 1 DAY then 'Active'
        else 'Closed' 
     end as `Campaign_Status`,
	 Order_ID as `Order_ID`,
	 Order_Name as `Order_Name`,
	 device as `Device`,
   advertiser_id,
	 Advertiser_Name as `Advertiser_Name`,
	 Agency_Name as `Agency_Name`,
	 Advertiser_OMS as `AOS_Advertiser_Name`,
   agency_name as `AOS_Agency_Name`,
	 Business_Unit as `Business_Unit`,
   Third_Party_Line_Item_ID as `Third_Party_Line_Item_ID`,
	 Line_Item_ID as `Line_Item_or_Placement_ID`,
	 Line_Item_Name `Line_Item_or_Placement_Name`,
	 Line_Item_Type `Demand_Type`,
	 Line_Item_Start_Date::date as `Line_Item_or_Placement_Start_Date`,
	 Line_Item_End_Date::date as `Line_Item_or_Placement_End_Date`,
     'N/A' as budget_model,
	 0 placement_avg_user_frequency,
	 External_AD_ID `External_AD_ID`,
	 aos_deal_id AS `AOS_Deal_ID`,
	 AOS_deal_name `AOS_Deal_Name`,
	 AOS_Deal_Start_Date::date as `AOS_Deal_Start_Date`,
	 AOS_Deal_End_Date::date as `AOS_Deal_End_Date`,
	 AOS_Deal_Line_Item_ID as `AOS_Deal_Line_Item_ID`,
	 AOS_Deal_Line_Item_Name as `AOS_Deal_Line_Item_Name`,
	 AOS_Deal_Line_Item_start_date as `AOS_Deal_Line_Item_Start_Date`,
	 AOS_Deal_Line_Item_end_date as `AOS_Deal_Line_Item_End_Date`,
	 package_name `Package_Name`,
   parent_line_item_name,
   account_coordinator,
   primary_salesperson_name as `Account_Executive`,
	 Account_Manager `Account_Manager`,
	 demo_band `Demo_Band`,
	 `Billable_Third_Party_Server`,
     primary_property `Primary_Property`,
     pitch_id `Pitch_ID` ,
     cost_method_name `Cost_Method_Name`,
     unit_type `Unit_Type`,
     product_name `Product_Name`,
     fw_rbp_advanced `fw_rbp_advanced`,
   -1	 creative_id,
   'N/A' creative_name,
   0 creative_duration_secs,
   1 demo_comp,
   'N/A' planned_demo_comp,
   'N/A' fw_audience_segment,
   'N/A' fw_video_group,
   `ad_unit_format`,
   'N/A' as `Ad_Unit_Position`,
   'N/A'series_name,
   'N/A' show_name,
   -1 video_id,
   'N/A' video_name,
	 CASE
        WHEN regexp_substr(Order_Name, '^\\\d+[^-|_| ]*') IN (
            SELECT DISTINCT regexp_substr(`Insertion_Order_Name`, '^\\\d+[^-|_| ]*')
            FROM fox_bi_prod.gold_ad_sales.ft_freewheel_campaign_pacing
        ) THEN True
        ELSE False
     END Multiple_Ad_Servers,
	 regexp_substr(`Order_Name`, '^\\\d+[^-|_| ]*') `Multiple_Ad_Server_ID`,
	 net_unit_cost `Net_Unit_Cost`,
	 Guaranteed_Impressions `Guaranteed_Impressions`,
	 Guaranteed_Revenue `Guaranteed_Revenue`,
   Delivered_Impressions `Gross_Counted_Ads`,
   0 `Booked_On_Target_Impression_Goal`,
   0 `Impression_Goal`,
   delivered_impressions `Delivered_Impressions`,
	 Delivered_Revenue `Delivered_Revenue`,
	 video_completes `Video_Completes`,
	 video_starts as `Video_Starts`,
	 delivered_clicks `Delivered_Clicks`,
	 0 `Freewheel_On_Target_Net_Delivered_Impressions`,
   out_of_flight_flag,
   out_of_flight_impressions,
   third_party_video_completes, 
   third_party_video_views,
   third_party_billable_impressions,
   third_party_clicks,
   third_party_revenue,
   0 as total_engagements,
	 Create_Timestamp `Create_Timestamp`,
	 Modified_Timestamp `Modified_Timestamp`
  from
	fox_bi_prod.gold_ad_sales.ft_gam_campaign_pacing cmp
	where 1 = 1
  -- and campaign_id = 74403146
  -- and third_party_billable_impressions > 0
  -- and event_date = '2024-03-15'
  -- and placement_id = '86295416' and cmp.event_date = '2025-09-02'
	-- and business_unit = 'Entertainment' and device_name = 'DT'
  -- group by all
)
 ,raw_gam_sports_data AS (
	 select
	 'GAM' as `Data_Source`,
	 event_date as `Event_Date`,
	 Order_ID as `Order_ID`,
	 Order_Name as `Order_Name`,
   advertiser_id,
	 Advertiser_Name as `Advertiser_Name`,
	 Business_Unit as `Business_Unit`,
	 Line_Item_ID as `Line_Item_or_Placement_ID`,
	 Line_Item_Name `Line_Item_or_Placement_Name`,
	 Line_Item_Type `Demand_Type`,
	 line_item_start_timestamp::date as `Line_Item_or_Placement_Start_Date`,
	 line_item_end_timestamp::date as `Line_Item_or_Placement_End_Date`,
   sum(total_impressions) `Delivered_Impressions`,
	 sum(total_cpm_and_cpc_revenue_usd)/1000000 `Delivered_Revenue`,
	 etl_created_at_timestamp_utc `Create_Timestamp`,
	 etl_updated_at_timestamp_utc `Modified_Timestamp`
  from fox_bi_prod.silver_ads.ft_sports_gam_ad_delivery_and_capacity cmp
  where line_item_id <> -1
  group by all)

 ,op1_data AS (
        SELECT
            source,
            date,
            sales_order_line_item_id AS AOS_Deal_Line_Item_ID,
            sales_order_line_item_name AS AOS_Deal_Line_Item_name,
            sales_order_line_item_start_dt::date AS AOS_Deal_Line_Item_start_date,
            sales_order_line_item_end_dt::date AS AOS_Deal_line_item_end_date,
            sales_order_id campaign_id,
            sales_order_name campaign_name,
            order_start_dt AS  Campaign_Start_Date,
            order_end_dt AS Campaign_End_Date,
            agency_name,
            advertiser_name,
            owner_name Account_Manager,
            primary_salesperson_name ,
            account_coordinator,
            package_name,
            ps_line_item_id External_AD_ID,
            parent_line_item_name,
            demo_band,
            CASE
                WHEN billable_third_party_descr = 'DCM' THEN 'FOX DCM'
                WHEN billable_third_party_descr = 'Doubleverify' THEN 'FOX Doubleverify'
                WHEN billable_third_party_descr = 'Innovid' THEN 'FOX Innovid'
                WHEN billable_third_party_descr = 'Flashtalking' THEN 'FOX Flashtalking'
                WHEN billable_third_party_descr = 'Extreme Reach' THEN 'FOX Extreme Reach'
                WHEN billable_third_party_descr = 'Sizmek' THEN 'FOX Sizmek'
                WHEN billable_third_party_descr = '1st Party' THEN 'FOX 1st Party'
                ELSE billable_third_party_descr
            END AS billable_third_party_server,
            primary_property,
            opportunity_unique_id as pitch_id,
            cost_method_name `Cost_Method_Name`,
            unit_type `Unit_Type`,
            product_name `Product_Name`,
            fw_rbp_advanced `fw_rbp_advanced`,
            est_demo_comp_vpvh as planned_demo_comp,
            fw_audience_segment,
            fw_video_group,
            delivery_source,
            net_unit_cost_amt AS net_unit_cost,
            net_cost_amt Guaranteed_Revenue,
            sales_order_line_items_qty AS Guaranteed_Impressions,
            primary_delivery_imps,
            CASE WHEN unit_type ilike 'Impressions' then  third_party_delivery_imps else 0 end third_party_delivery_imps,
            CASE WHEN unit_type ilike 'Impressions' then  ((third_party_delivery_imps/1000) * net_unit_cost_amt)  else 0 end as third_party_delivery_revenue,
            CASE WHEN unit_type ilike 'Clicks'then  third_party_delivery_imps else 0 end third_party_delivery_clicks,
            create_timestamp_sli as create_timestamp,
            update_timestamp_sli as modified_timestamp
        FROM fox_bi_prod.gold_ad_sales.ft_digital_operative_line_date_allocation oms
        WHERE ps_line_item_id IS NOT NULL
        AND oms.date BETWEEN oms.sales_order_line_item_start_dt and oms.sales_order_line_item_end_dt
        GROUP BY ALL)

 ,final_gam_sports_data AS (
	 select
	 'GAM Sports' as `Data_Source`,
	 event_date as `Event_Date`,  
	 Campaign_ID as `Campaign_ID`,
	 UPPER(Campaign_Name) as `Campaign_Name`,
	 Campaign_Start_Date::date as `Campaign_Start_Date`,
	 Campaign_End_Date::date as `Campaign_End_Date`,
   0 as `Campaign_Avg_User_Frequency`,
	 UPPER(oms.advertiser_name) ||' - '|| campaign_start_date::date || ' - '|| campaign_end_date::date as `Campaign_Name_Derived`,
	 case
        when Campaign_End_Date > current_timestamp() - INTERVAL 1 DAY then 'Active'
        else 'Closed' 
     end as `Campaign_Status`,
	 Order_ID as `Order_ID`,
	 UPPER(Order_Name) as `Order_Name`,
	 'N/A' as `Device`,
     advertiser_id,
	 UPPER(gam.Advertiser_Name) as `Advertiser_Name`,
	 UPPER(Agency_Name) as `Agency_Name`,
	 UPPER(oms.Advertiser_Name) as `AOS_Advertiser_Name`,
     UPPER(agency_name) as `AOS_Agency_Name`,
	 UPPER(Business_Unit) as `Business_Unit`,
     -1  as `Third_Party_Line_Item_ID`,
	 Line_Item_or_Placement_ID as `Line_Item_or_Placement_ID`,
	 UPPER(line_item_or_placement_name) as `Line_Item_or_Placement_Name`,
	 UPPER(demand_type) as `Demand_Type`,
	 Line_Item_or_Placement_Start_Date::date as `Line_Item_or_Placement_Start_Date`,
	 Line_Item_or_Placement_End_Date::date as `Line_Item_or_Placement_End_Date`,
     'N/A' as budget_model,
	 0 placement_avg_user_frequency,
	 External_AD_ID `External_AD_ID`,
	 campaign_id AS `AOS_Deal_ID`,
     UPPER(campaign_name) `AOS_Deal_Name`,
	 campaign_start_date::date as `AOS_Deal_Start_Date`,
	 campaign_end_date::date as `AOS_Deal_End_Date`,
	 AOS_Deal_Line_Item_ID as `AOS_Deal_Line_Item_ID`,
	 UPPER(AOS_Deal_Line_Item_Name) as `AOS_Deal_Line_Item_Name`,
	 AOS_Deal_Line_Item_start_date as `AOS_Deal_Line_Item_Start_Date`,
	 AOS_Deal_Line_Item_end_date as `AOS_Deal_Line_Item_End_Date`,
	 UPPER(package_name) as `Package_Name`,
     UPPER(parent_line_item_name) as `Parent_Line_Item_Name`,
     UPPER(account_coordinator) as `Account_Coordinator`,
     UPPER(primary_salesperson_name) as `Account_Executive`,
	 UPPER(Account_Manager) as `Account_Manager`,
	 UPPER(demo_band) as `Demo_Band`,
	 UPPER(`Billable_Third_Party_Server`) as `Billable_Third_Party_Server`,
     UPPER(primary_property) as `Primary_Property`,
     UPPER(pitch_id) as `Pitch_ID` ,
     UPPER(cost_method_name) as `Cost_Method_Name`,
     UPPER(unit_type) as `Unit_Type`,
     UPPER(product_name) as `Product_Name`,
     UPPER(fw_rbp_advanced) as `fw_rbp_advanced`,
     -1	 creative_id,
     'N/A' creative_name,
     0 creative_duration_secs,
     1 demo_comp,
     'N/A' planned_demo_comp,
     'N/A' fw_audience_segment,
     'N/A' fw_video_group,
     'N/A' `ad_unit_format`,
     'N/A' as `Ad_Unit_Position`,
     'N/A'series_name,
     'N/A' show_name,
     -1 video_id,
     'N/A' video_name,
	 CASE
        WHEN regexp_substr(Order_Name, '^\\\d+[^-|_| ]*') IN (
            SELECT DISTINCT regexp_substr(`Insertion_Order_Name`, '^\\\d+[^-|_| ]*')
            FROM fox_bi_prod.gold_ad_sales.ft_freewheel_campaign_pacing
            UNION 
            select distinct regexp_substr(`Order_Name`, '^\\\d+[^-|_| ]*')
            from fox_bi_prod.gold_ad_sales.ft_gam_campaign_pacing
        ) THEN True
        ELSE False
     END Multiple_Ad_Servers,
	 regexp_substr(`Order_Name`, '^\\\d+[^-|_| ]*') `Multiple_Ad_Server_ID`,
	 net_unit_cost `Net_Unit_Cost`,
	 Guaranteed_Impressions `Guaranteed_Impressions`,
	 Guaranteed_Revenue `Guaranteed_Revenue`,
     Delivered_Impressions `Gross_Counted_Ads`,
    0 `Booked_On_Target_Impression_Goal`,
    0 `Impression_Goal`,
     Delivered_Impressions `Delivered_Impressions`,
	 Delivered_Revenue `Delivered_Revenue`,
	 0 `Video_Completes`,
	 0 as `Video_Starts`,
	 0 `Delivered_Clicks`,
	 0 `Freewheel_On_Target_Net_Delivered_Impressions`,
     NULL out_of_flight_flag,
     0 out_of_flight_impressions,
     0 as third_party_video_completes, 
     0 as third_party_video_views,
     third_party_delivery_imps third_party_billable_impressions,
     third_party_delivery_clicks third_party_clicks,
     third_party_delivery_revenue third_party_revenue,
     0 as total_engagements,
	 gam.Create_Timestamp `Create_Timestamp`,
	 gam.Modified_Timestamp `Modified_Timestamp`
    from raw_gam_sports_data gam
    left join op1_data oms
        ON oms.External_AD_ID = gam.line_item_or_placement_id
        AND oms.date = gam.event_date
    WHERE (
        CASE
            WHEN ((LOWER(gam.advertiser_name) LIKE '%promo%') OR (LOWER(gam.advertiser_name) LIKE '% test%')) THEN FALSE
            WHEN ((LOWER(gam.order_name) LIKE '%promo%') OR (LOWER(gam.order_name) LIKE '% test%')) THEN FALSE
            WHEN ((LOWER(oms.agency_name) LIKE '%promo%') OR (LOWER(oms.agency_name) LIKE '% test%')) THEN FALSE
            ELSE TRUE
        END
    )
)

,raw_tubi_log_data (
    SELECT 
    'Mercury'  AS Data_Source
    ,tb.ds as Event_Date
    ,tb.campaign_id
    ,tb.campaign_name
    ,oms.Campaign_Start_Date
    ,oms.Campaign_End_Date
    ,0 AS Campaign_Avg_User_Frequency
    ,UPPER(oms.advertiser_name) ||' - '|| oms.Campaign_Start_Date::date || ' - '|| oms.Campaign_End_Date::date as `Campaign_Name_Derived`
    ,case
        when Campaign_End_Date > current_timestamp() - INTERVAL 1 DAY then 'Active'
        else 'Closed' 
    end as `Campaign_Status`
    ,oms.campaign_id order_id
    ,UPPER(oms.campaign_name) order_name
    ,'N/A' device
    ,tb.advertiser_id
    ,UPPER(nvl(tb.advertiser_name,'N/A')) advertiser_name
    ,UPPER(nvl(oms.agency_name,'N/A')) agency_name
    ,UPPER(nvl(oms.advertiser_name,'N/A')) aos_advertiser_name
    ,UPPER(nvl(oms.agency_name,'N/A')) aos_agency_name
    ,'N/A' business_unit
    ,-1 third_party_line_item_id
    ,tb.line_item_id line_item_or_placement_id
    ,UPPER(tb.line_item_name) line_item_or_placement_name
    ,'N/A' demand_type
    ,oms.AOS_Deal_Line_Item_start_date::date line_item_or_placement_start_date
    ,oms.AOS_Deal_Line_Item_end_date::date line_item_or_placement_end_date
    ,'N/A' as budget_model
    ,0 placement_avg_user_frequency
    ,oms.external_ad_id
    ,oms.campaign_id aos_deal_id
    ,UPPER(oms.campaign_name) aos_deal_name
    ,oms.Campaign_Start_Date::date aos_deal_start_date
    ,oms.Campaign_end_Date::Date aos_deal_end_date
    ,oms.AOS_Deal_Line_Item_ID aos_deal_line_item_id
    ,UPPER(oms.AOS_Deal_Line_Item_name) aos_deal_line_item_name
    ,oms.AOS_Deal_Line_Item_start_date::date aos_deal_line_item_start_date
    ,oms.AOS_Deal_Line_Item_end_date::date aos_deal_line_item_end_date
    ,UPPER(nvl(oms.package_name,'N/A')) package_name
    ,UPPER(nvl(oms.parent_line_item_name,'N/A')) parent_line_item_name
    ,UPPER(nvl(oms.account_coordinator,'N/A')) account_coordinator
    ,UPPER(nvl(oms.primary_salesperson_name,'N/A')) primary_salesperson_name
    ,UPPER(nvl(oms.Account_Manager,'N/A'))  account_manager
    ,nvl(oms.demo_band,'N/A') demo_band
    ,nvl(oms.billable_third_party_server,'N/A') billable_third_party_server
    ,UPPER(nvl(oms.primary_property,'N/A')) primary_property
    ,UPPER(nvl(oms.pitch_id,'N/A')) pitch_id
    ,UPPER(nvl(oms.cost_method_name,'N/A')) cost_method_name
    ,UPPER(nvl(oms.unit_type,'N/A')) unit_type
    ,UPPER(nvl(oms.product_name,'N/A')) product_name
    ,UPPER(nvl(oms.fw_rbp_advanced,'N/A')) fw_rbp_advanced
    ,-1	 creative_id 
    ,'N/A' creative_name
    ,0 creative_duration_secs
    ,1 demo_comp
    ,oms.planned_demo_comp
    ,UPPER(case when oms.fw_audience_segment = '' then 'N/A' else nvl(oms.fw_audience_segment,'N/A') end) as fw_audience_segment
    ,UPPER(case when oms.fw_video_group = '' then 'N/A' else nvl(oms.fw_video_group,'N/A') end) as fw_video_group
    ,'N/A' as `ad_unit_format`
    ,'N/A' as `Ad_Unit_Position`
    ,'N/A' as series_name
    ,'N/A' as show_name
    ,-1 as video_id
    ,'N/A' as video_name
    ,FALSE AS Multiple_Ad_Servers
    ,NULL AS Multiple_Ad_Server_ID
    ,oms.net_unit_cost
    ,oms.guaranteed_impressions
    ,oms.guaranteed_revenue
    ,0 as gross_counted_ads
    ,0 as booked_on_target_impression_goal
    ,0 as impression_goal
    ,tb.impressions as Delivered_Impressions
    ,tb.revenue as Delivered_Revenue
    ,0 Video_Completes
    ,0 Video_Starts
    ,0 as Delivered_Clicks
    ,0 Freewheel_On_Target_Net_Delivered_Impressions
    ,False out_of_flight_flag
    ,0 out_of_flight_impressions
    ,0 Third_Party_Video_Completes
    ,0 Third_Party_Video_Views
    ,0 Third_Party_Billable_Impressions
    ,0 as Third_Party_Clicks
    ,0 as Third_Party_Revenue
    ,0 as total_engagements
    ,oms.create_timestamp
    ,oms.modified_timestamp
    from (
    SELECT
        ds,
        line_item_id,
        regexp_extract(line_item_name, '^(\\\d+)', 1) as line_item_id_extracted,
        line_item_name,
        MAX(CASE WHEN campaign_id IS NOT NULL THEN campaign_name END) AS campaign_name,
        MAX(campaign_id) AS campaign_id,
        advertiser_id,
        advertiser_name,
        SUM(revenue) AS revenue,
        sum(impressions) as impressions
    FROM adrise_share_prod.ads_curated.v_ads_net_revenue_daily
    GROUP BY ALL ) tb
    LEFT JOIN 
    (select  distinct
    Campaign_Start_Date
    ,Campaign_End_Date
    ,advertiser_name
    ,agency_name
    ,AOS_Deal_Line_Item_start_date
    ,AOS_Deal_Line_Item_end_date
    ,external_ad_id
    ,campaign_id
    ,campaign_name
    ,AOS_Deal_Line_Item_ID
    ,AOS_Deal_Line_Item_name
    ,package_name
    ,parent_line_item_name
    ,account_coordinator
    ,primary_salesperson_name
    ,Account_Manager
    ,demo_band
    ,billable_third_party_server
    ,primary_property
    ,pitch_id
    ,cost_method_name
    ,unit_type
    ,product_name
    ,fw_rbp_advanced
    ,planned_demo_comp
    ,fw_audience_segment
    ,fw_video_group
    ,net_unit_cost
    ,guaranteed_impressions
    ,guaranteed_revenue
    ,delivery_source
    ,create_timestamp
    ,modified_timestamp
    from op1_data where source <> 'OP1'  ) oms
    on tb.line_item_id_extracted = oms.External_AD_ID
    --and oms.date::date = tb.ds::date
    WHERE tb.line_item_id_extracted in (select distinct External_AD_ID from op1_data where source <> 'OP1')
)

,raw_emplifi_data as (
  
SELECT
    'EMPLIFI' AS `Data_Source`, 
    post_date AS `Event_Date`,
    aos_deal_id AS `Campaign_ID`,
    aos_deal_name AS `Campaign_Name`,
    aos_deal_start_date AS `Campaign_Start_Date`,
    aos_deal_end_date AS `Campaign_End_Date`,
    0 AS `Campaign_Avg_User_Frequency`,
    'N/A' as  `Campaign_Name_Derived`,
    case
        when aos_deal_end_date > current_timestamp() - INTERVAL 1 DAY then 'Active'
        else 'Closed' 
    end AS `Campaign_Status`,
    -1 AS `Order_ID`,
    'N/A' AS `Order_Name`,
    'N/A' AS `Device`,
    -1 AS advertiser_id,
    aos_advertiser_name AS `Advertiser_Name`,
    aos_agency_name AS `Agency_Name`,
    aos_advertiser_name AS `AOS_Advertiser_Name`,
    aos_agency_name AS `AOS_Agency_Name`,
    business_unit AS `Business_Unit`,
    NULL AS `Third_Party_Line_Item_ID`,
    concat(post_labels_id::string,'_',aos_deal_line_item_id::string) AS `Line_Item_or_Placement_ID`,
    regexp_replace(
    post_labels_name,
    '( *_ *[0-9]+)+$',
    ''
        ) AS `Line_Item_or_Placement_Name`,
    'DIRECT SOLD' AS `Demand_Type`,
    aos_deal_line_item_start_date AS `Line_Item_or_Placement_Start_Date`,
    aos_deal_line_item_end_date AS `Line_Item_or_Placement_End_Date`,
    'N/A' as budget_model,
    0 AS placement_avg_user_frequency,
    NULL AS `External_AD_ID`,
    aos_deal_id AS `AOS_Deal_ID`,
    aos_deal_name AS `AOS_Deal_Name`,
    aos_deal_start_date AS `AOS_Deal_Start_Date`,
    aos_deal_end_date AS `AOS_Deal_End_Date`,
    aos_deal_line_item_id AS `AOS_Deal_Line_Item_ID`,
    aos_deal_line_item_name AS `AOS_Deal_Line_Item_Name`,
    aos_deal_line_item_start_date AS `AOS_Deal_Line_Item_Start_Date`,
    aos_deal_line_item_end_date AS `AOS_Deal_Line_Item_End_Date`,
    package_name AS `Package_Name`,
    parent_line_item_name AS parent_line_item_name,
    account_coordinator AS account_coordinator,
    account_executive AS `Account_Executive`,
    account_manager AS `Account_Manager`,
    demo_band AS `Demo_Band`,
    billable_third_party_server AS `Billable_Third_Party_Server`,
    primary_property AS `Primary_Property`,
    pitch_id AS `Pitch_ID`,
    cost_method_name AS `Cost_Method_Name`,
    unit_type AS `Unit_Type`,
    'N/A' AS `Product_Name`,
    'N/A' AS `fw_rbp_advanced`,
    -1 AS creative_id,
    'N/A' AS creative_name,
    0 AS creative_duration_secs,
    1 AS demo_comp,
    'N/A' AS planned_demo_comp,
    'N/A' AS fw_audience_segment,
    'N/A' AS fw_video_group,
    'N/A' AS `ad_unit_format`,
    'N/A' AS `Ad_Unit_Position`,
    'N/A' AS series_name,
    'N/A' AS show_name,
    -1 AS video_id,
    'N/A' AS video_name,
    FALSE AS Multiple_Ad_Servers,
    NULL AS `Multiple_Ad_Server_ID`,
    net_unit_cost AS `Net_Unit_Cost`,
    guaranteed_impressions AS `Guaranteed_Impressions`,
    guaranteed_revenue AS `Guaranteed_Revenue`,
    0 as Gross_Counted_Ads,
    0 as Booked_On_Target_Impression_Goal,              
    0 as Impression_Goal,
    SUM(
        COALESCE(tiktok_impressions,0) +
        COALESCE(facebook_impressions,0) +
        COALESCE(instagram_impressions,0) +
        COALESCE(youtube_impressions,0)
    ) as Delivered_Impressions ,
   0 as Delivered_Revenue,
   0 `Video_Completes`,
   SUM(
        COALESCE(tiktok_views,0) +
        COALESCE(facebook_views,0) +
        COALESCE(instagram_views,0) +
        COALESCE(youtube_views,0)
    ) as `Video_Starts`,
   0 `Delivered_Clicks`,
   0 AS `Freewheel_On_Target_Net_Delivered_Impressions`,
    NULL AS out_of_flight_flag,
    0 AS out_of_flight_impressions,
    0 AS third_party_video_completes,
    0 AS third_party_video_views,
    0 AS third_party_billable_impressions,
    0 AS third_party_clicks,
    0 AS third_party_revenue,
	SUM(
        COALESCE(tiktok_engagements,0) +
        COALESCE(facebook_engagements,0) +
        COALESCE(instagram_engagements,0) +
        COALESCE(youtube_engagements,0)
    ) AS `total_engagements`,
    create_timestamp AS `Create_Timestamp`,
    modified_timestamp AS `Modified_Timestamp`
FROM fox_bi_prod.gold_ad_sales.ft_social_engagement_campaign_delivery
where aos_Deal_Id is not null
GROUP BY
    all
    
)
,unified_base_data as
(
    SELECT * FROM raw_fw_data
    UNION ALL
    SELECT * FROM raw_gam_data
    UNION ALL
    select * from final_gam_sports_data
    UNION ALL
    SELECT * FROM raw_emplifi_data
    UNION ALL 
    SELECT * FROM raw_tubi_log_data
)

,oms_data as
(
    select 
         case when oms.delivery_source ilike '%mercury%'
             then 'Mercury'
             when oms.delivery_source ilike '%Megaphone%' 
             then 'Megaphone'
             when oms.delivery_source ilike '%Social%'
             then 'Social Media'
             when oms.delivery_source ilike '%Amper%'
             then 'AmperWave'
             else 'Non Ad Served' 
        end as data_source
        ,`date`::date event_date
        ,oms.sales_order_id campaign_id
        ,UPPER(oms.sales_order_name) campaign_name
        ,oms.order_start_dt campaign_start_date
        ,oms.order_end_dt campaign_end_date
        ,0 Campaign_Avg_User_Frequency
        ,UPPER(oms.advertiser_name) ||' - '|| oms.order_start_dt::date || ' - '|| oms.order_end_dt::date as `Campaign_Name_Derived`
        ,case
            when order_end_dt > current_timestamp() - INTERVAL 1 DAY then 'Active'
            else 'Closed' 
        end as `Campaign_Status`
        ,oms.sales_order_id order_id
        ,UPPER(oms.sales_order_name) order_name
        ,'N/A' device
        ,-1 advertiser_id
        ,UPPER(nvl(oms.advertiser_name,'N/A')) advertiser_name
        ,UPPER(nvl(oms.agency_name,'N/A')) agency_name
        ,UPPER(nvl(oms.advertiser_name,'N/A')) aos_advertiser_name
        ,UPPER(nvl(oms.agency_name,'N/A')) aos_agency_name
        ,'N/A' business_unit
        ,-1 third_party_line_item_id
        ,oms.sales_order_line_item_id line_item_or_placement_id
        ,UPPER(oms.sales_order_line_item_name) line_item_or_placement_name
        ,'N/A' demand_type
        ,oms.sales_order_line_item_start_dt::date line_item_or_placement_start_date
        ,oms.sales_order_line_item_end_dt::date line_item_or_placement_end_date
        ,'N/A' as budget_model
        ,0 placement_avg_user_frequency
        ,oms.ps_line_item_id external_ad_id
        ,oms.sales_order_id aos_deal_id
        ,UPPER(oms.sales_order_name) aos_deal_name
        ,oms.order_start_dt::date aos_deal_start_date
        ,oms.order_end_dt::Date aos_deal_end_date
        ,oms.sales_order_line_item_id aos_deal_line_item_id
        ,UPPER(oms.sales_order_line_item_name) aos_deal_line_item_name
        ,oms.sales_order_line_item_start_dt::date aos_deal_line_item_start_date
        ,oms.sales_order_line_item_end_dt::date aos_deal_line_item_end_date
        ,UPPER(nvl(oms.package_name,'N/A')) package_name
        ,UPPER(nvl(oms.parent_line_item_name,'N/A')) parent_line_item_name
        ,UPPER(nvl(oms.account_coordinator,'N/A')) account_coordinator
        ,UPPER(nvl(oms.primary_salesperson_name,'N/A')) primary_salesperson_name
        ,UPPER(nvl(oms.owner_name,'N/A'))  account_manager
        ,nvl(oms.demo_band,'N/A') demo_band
        ,nvl(oms.billable_third_party_descr,'N/A') billable_third_party_server
        ,UPPER(nvl(oms.primary_property,'N/A')) primary_property
        ,UPPER(nvl(oms.opportunity_unique_id,'N/A')) pitch_id
        ,UPPER(nvl(oms.cost_method_name,'N/A')) cost_method_name
        ,UPPER(nvl(oms.unit_type,'N/A')) unit_type
        ,UPPER(nvl(oms.product_name,'N/A')) product_name
        ,UPPER(nvl(oms.fw_rbp_advanced,'N/A')) fw_rbp_advanced
        ,-1	 creative_id 
        ,'N/A' creative_name
        ,0 creative_duration_secs
        ,1 demo_comp
        ,est_demo_comp_vpvh planned_demo_comp
        ,UPPER(case when oms.fw_audience_segment = '' then 'N/A' else nvl(oms.fw_audience_segment,'N/A') end) as fw_audience_segment
        ,UPPER(case when oms.fw_video_group = '' then 'N/A' else nvl(oms.fw_video_group,'N/A') end) as fw_video_group
        ,'N/A' as `ad_unit_format`
        ,'N/A' as `Ad_Unit_Position`
        ,'N/A' as series_name
        ,'N/A' as show_name
        ,-1 as video_id
        ,'N/A' as video_name
        ,ad_servers.multiple_ad_servers
        ,ad_servers.multiple_ad_server_id
        ,oms.net_unit_cost_amt net_unit_cost
        ,oms.sales_order_line_items_qty guaranteed_impressions
        ,oms.contracted_amount_net_lifetime guaranteed_revenue
        ,0 as gross_counted_ads
        ,0 as booked_on_target_impression_goal
        ,0 as impression_goal
        ,coalesce(case when  (oms.delivery_source ilike '%mercury%'
                    or oms.delivery_source ilike '%Megaphone%' 
                    or oms.delivery_source ilike '%Social%'
                    or oms.delivery_source ilike '%Amper%')
                    and oms.unit_type ilike 'Impressions'
              then oms.primary_delivery_imps
              else 0 
        end, 0) as Delivered_Impressions
        ,case when  (oms.delivery_source ilike '%mercury%'
                    or oms.delivery_source ilike '%Megaphone%' 
                    or oms.delivery_source ilike '%Social%'
                    or oms.delivery_source ilike '%Amper%')
                    and oms.unit_type ilike 'Impressions'
              then (oms.primary_delivery_imps/1000) * oms.net_unit_cost_amt
              else 0
        end as Delivered_Revenue
        ,0 Video_Completes
        ,0 Video_Starts
        ,case when  (oms.delivery_source ilike '%mercury%'
                    or oms.delivery_source ilike '%Megaphone%' 
                    or oms.delivery_source ilike '%Social%'
                    or oms.delivery_source ilike '%Amper%')
                    and oms.unit_type ilike 'Clicks'
              then oms.primary_delivery_imps
              else 0 
        end as Delivered_Clicks
        ,0 Freewheel_On_Target_Net_Delivered_Impressions
        ,False out_of_flight_flag
        ,0 out_of_flight_impressions
        ,0 Third_Party_Video_Completes
        ,0 Third_Party_Video_Views
        ,case when  (oms.delivery_source ilike '%mercury%'
                    or oms.delivery_source ilike '%Megaphone%' 
                    or oms.delivery_source ilike '%Social%'
                    or oms.delivery_source ilike '%Amper%')
                    and oms.unit_type ilike 'Impressions'
              then oms.third_party_delivery_imps
              else 0 
        end as Third_Party_Billable_Impressions
        ,case when  (oms.delivery_source ilike '%mercury%'
                    or oms.delivery_source ilike '%Megaphone%' 
                    or oms.delivery_source ilike '%Social%'
                    or oms.delivery_source ilike '%Amper%')
                    and oms.unit_type ilike 'Clicks'
              then oms.third_party_delivery_imps
              else 0 
        end as Third_Party_Clicks
        ,case when  (oms.delivery_source ilike '%mercury%'
                    or oms.delivery_source ilike '%Megaphone%' 
                    or oms.delivery_source ilike '%Social%'
                    or oms.delivery_source ilike '%Amper%')
                    and oms.unit_type ilike 'Impressions'
              then (oms.third_party_delivery_imps/1000) * oms.net_unit_cost_amt
              else 0
        end as Third_Party_Revenue
        ,0 as total_engagements
        ,create_timestamp_sli create_timestamp
        ,update_timestamp_sli modified_timestamp
    from fox_bi_prod.gold_ad_sales.ft_digital_operative_line_date_allocation oms 
        left join unified_base_data
            on unified_base_data.external_ad_id = oms.ps_line_item_id
        left join (SELECT aos_deal_id,  bool_or(multiple_ad_servers) AS multiple_ad_servers,
                  concat_ws(',', array_distinct(collect_list(multiple_ad_server_id))) AS multiple_ad_server_id
                  FROM unified_base_data GROUP BY aos_deal_id) ad_servers
            on ad_servers.aos_deal_id = oms.sales_order_id
        where 1 = 1
            and unified_base_data.external_ad_id is null
            and sales_order_line_item_id not in (select distinct parent_line_item_id from fox_bi_prod.gold_ad_sales.ft_digital_operative_line_date_allocation where parent_line_item_id is not null)
            and oms.sales_order_id in (select distinct aos_deal_id from unified_base_data)
            and oms.sales_order_line_item_id not in (select distinct aos_deal_line_item_id from raw_emplifi_data)
            and oms.sales_order_line_item_id not in (select distinct aos_deal_line_item_id from raw_tubi_log_data)
            and CASE 
                    WHEN (
                        CASE 
                            WHEN oms.delivery_source ilike '%mercury%' THEN 'Mercury'
                            WHEN oms.delivery_source ilike '%Megaphone%' THEN 'Megaphone'
                            WHEN oms.delivery_source ilike '%Social%' THEN 'Social Media'
                            WHEN oms.delivery_source ilike '%Amper%' THEN 'AmperWave'
                            ELSE 'Non Ad Served' 
                         END
                    ) = 'Non Ad Served'
                    THEN true
                    when date < current_date() 
                    THEN true 
                    ELSE false 
                 END
            -- and oms.sales_order_line_item_name not ilike '%cancelled%'
)
,unified_data as (
select * from unified_base_data
union all
select * from oms_data
)
,plc_lvl_data as (
select  Event_Date,Line_Item_or_Placement_ID,Campaign_ID,AOS_Deal_Line_Item_ID,Line_Item_or_Placement_Start_Date,campaign_start_date,aos_deal_line_item_start_date,
line_item_or_placement_end_date,campaign_end_date,aos_deal_line_item_end_date
,sum(delivered_impressions) delivered_impressions
from unified_data
group by all)
,plc_lvl_flg_data as (
select Event_Date,Line_Item_or_Placement_ID,Campaign_ID,AOS_Deal_Line_Item_ID
,Line_Item_or_Placement_Start_Date,campaign_start_date,aos_deal_line_item_start_date,
line_item_or_placement_end_date,campaign_end_date,aos_deal_line_item_end_date
,CASE 
    WHEN event_date NOT BETWEEN coalesce(line_item_or_placement_start_date,campaign_start_date,aos_deal_line_item_start_date) AND coalesce(line_item_or_placement_end_date,campaign_end_date,aos_deal_line_item_end_date)
    THEN 1
    WHEN SUM(delivered_impressions) over (partition by Event_Date,Line_Item_or_Placement_ID,Campaign_ID,AOS_Deal_Line_Item_ID) = 0
    THEN 1 ELSE 0 
 END as is_dark_day
,CASE 
    WHEN event_date NOT BETWEEN coalesce(line_item_or_placement_start_date,campaign_start_date,aos_deal_line_item_start_date) AND coalesce(line_item_or_placement_end_date,campaign_end_date,aos_deal_line_item_end_date)
    THEN 0
    WHEN SUM(delivered_impressions) over (partition by Event_Date,Line_Item_or_Placement_ID,Campaign_ID,AOS_Deal_Line_Item_ID)
    = 0
    THEN 0 ELSE 1 
 END as is_live_day
 ,sum(CASE 
    WHEN event_date NOT BETWEEN coalesce(line_item_or_placement_start_date,campaign_start_date,aos_deal_line_item_start_date) AND coalesce(line_item_or_placement_end_date,campaign_end_date,aos_deal_line_item_end_date)
    THEN 0
    WHEN SUM(delivered_impressions)  over (partition by Event_Date,Line_Item_or_Placement_ID,Campaign_ID,AOS_Deal_Line_Item_ID)
     = 0
    THEN 0 ELSE 1 
 END) OVER (partition by Line_Item_or_Placement_ID,Campaign_ID,AOS_Deal_Line_Item_ID) 
 live_days
,sum(CASE 
    WHEN event_date NOT BETWEEN coalesce(line_item_or_placement_start_date,campaign_start_date,aos_deal_line_item_start_date) AND coalesce(line_item_or_placement_end_date,campaign_end_date,aos_deal_line_item_end_date)
    THEN 1
    WHEN SUM(delivered_impressions) over (partition by Event_Date,Line_Item_or_Placement_ID,Campaign_ID,AOS_Deal_Line_Item_ID)
     = 0
    THEN 1 ELSE 0 
 END) OVER (partition by Line_Item_or_Placement_ID,Campaign_ID,AOS_Deal_Line_Item_ID) 
dark_days
,CASE WHEN MAX(event_date) OVER (PARTITION BY Line_Item_or_Placement_ID, campaign_id) NOT BETWEEN
                COALESCE(Line_Item_or_Placement_Start_Date::date, Campaign_Start_Date::date) AND COALESCE(Line_Item_or_Placement_End_Date::date,   Campaign_End_Date::date) THEN 0
                ELSE GREATEST(
                DATEDIFF(
                    COALESCE(Line_Item_or_Placement_End_Date::date, Campaign_End_Date::date),
                    LEAST(
                        MAX(event_date) OVER (PARTITION BY Line_Item_or_Placement_ID, campaign_id),
                        COALESCE(Line_Item_or_Placement_End_Date::date, Campaign_End_Date::date)
                    )
                ),
                0
            ) END rm_days
            ,live_days + rm_days campaign_days
            ,live_days AS days_to_date
from plc_lvl_data
)

select
     ud.Data_Source::string as `Data_Source`
    ,ud.Event_Date::date as `Event_Date`
    ,ud.Campaign_ID::bigint as `Campaign_ID`
    ,ud.Campaign_Name::string as `Campaign_Name`
    ,ud.Campaign_Start_Date::timestamp as `Campaign_Start_Date`
    ,ud.Campaign_End_Date::timestamp as `Campaign_End_Date`
    ,ud.Campaign_Avg_User_Frequency::string as `Campaign_Avg_User_Frequency`
    ,ud.Campaign_Name_Derived::string as `Campaign_Name_Derived`
    ,ud.Campaign_Status::string as `Campaign_Status`
    ,ud.Order_ID::bigint as `Order_ID`
    ,ud.Order_Name::string as `Order_Name`
    ,ud.Device::string as `Device`
    ,ud.advertiser_id::bigint as `advertiser_id`
    ,ud.Advertiser_Name::string as `Advertiser_Name`
    ,ud.Agency_Name::string as `Agency_Name`
    ,ud.AOS_Advertiser_Name::string as `AOS_Advertiser_Name`
    ,ud.AOS_Agency_Name::string as `AOS_Agency_Name`
    ,ud.Business_Unit::string as `Business_Unit`
    ,ud.Third_Party_Line_Item_ID::string as `Third_Party_Line_Item_ID`
    ,ud.Line_Item_or_Placement_ID::string as `Line_Item_or_Placement_ID`
    ,ud.Line_Item_or_Placement_Name::string as `Line_Item_or_Placement_Name`
    ,ud.Demand_Type::string as `Demand_Type`
    ,ud.Line_Item_or_Placement_Start_Date::date as `Line_Item_or_Placement_Start_Date`
    ,ud.Line_Item_or_Placement_End_Date::date as `Line_Item_or_Placement_End_Date`
    ,ud.budget_model::string as `budget_model`
    ,ud.placement_avg_user_frequency::string as `placement_avg_user_frequency`
    ,ud.External_AD_ID::string as `External_AD_ID`
    ,ud.AOS_Deal_ID::bigint as `AOS_Deal_ID`
    ,ud.AOS_Deal_Name::string as `AOS_Deal_Name`
    ,ud.AOS_Deal_Start_Date::date as `AOS_Deal_Start_Date`
    ,ud.AOS_Deal_End_Date::date as `AOS_Deal_End_Date`
    ,ud.AOS_Deal_Line_Item_ID::bigint as `AOS_Deal_Line_Item_ID`
    ,ud.AOS_Deal_Line_Item_Name::string as `AOS_Deal_Line_Item_Name`
    ,ud.AOS_Deal_Line_Item_Start_Date::date as `AOS_Deal_Line_Item_Start_Date`
    ,ud.AOS_Deal_Line_Item_end_Date::date as `AOS_Deal_Line_Item_end_Date`
    ,ud.Package_Name::string as `Package_Name`
    ,ud.parent_line_item_name::string as `parent_line_item_name`
    ,ud.account_coordinator::string as `account_coordinator`
    ,ud.Account_Executive::string as `Account_Executive`
    ,ud.Account_Manager::string as `Account_Manager`
    ,ud.Demo_Band::string as `Demo_Band`
    ,ud.Billable_Third_Party_Server::string as `Billable_Third_Party_Server`
    ,ud.Primary_Property::string as `Primary_Property`
    ,ud.Pitch_ID::string as `Pitch_ID`
    ,ud.cost_method_name::string as `cost_method_name`
    ,ud.unit_type::string as `unit_type`
    ,ud.product_name::string as `product_name`
    ,ud.fw_rbp_advanced::string as `fw_rbp_advanced`
    ,ud.creative_id::bigint as `creative_id`
    ,ud.creative_name::string as `creative_name`
    ,ud.creative_duration_secs::double as `creative_duration_secs`
    ,ud.demo_comp::decimal(30,2) as `demo_comp`
    ,ud.planned_demo_comp::string as `planned_demo_comp`
    ,ud.fw_audience_segment::string as `fw_audience_segment`
    ,ud.fw_video_group::string as `fw_video_group`
    ,ud.ad_unit_format::string as `ad_unit_format`
    ,ud.Ad_Unit_Position::string as `Ad_Unit_Position`
    ,ud.series_name::string as `series_name`
    ,ud.show_name::string as `show_name`
    ,ud.video_id::bigint as `video_id`
    ,ud.video_name::string as `video_name`
    ,ud.Multiple_Ad_Servers::boolean as `Multiple_Ad_Servers`
    ,ud.Multiple_Ad_Server_ID::string as `Multiple_Ad_Server_ID`
    ,ud.Net_Unit_Cost::double as `Net_Unit_Cost`
    ,ud.Guaranteed_Impressions::bigint as `Guaranteed_Impressions`
    ,ud.Guaranteed_Revenue::double as `Guaranteed_Revenue`
    ,ud.Gross_Counted_Ads::bigint as `Gross_Counted_Ads`
    ,ud.Booked_On_Target_Impression_Goal::bigint as `Booked_On_Target_Impression_Goal`
    ,ud.Impression_Goal::bigint as `Impression_Goal`
    ,ud.Delivered_Impressions::bigint as `Delivered_Impressions`
    ,ud.Delivered_Revenue::double as `Delivered_Revenue`
    ,ud.Video_Completes::bigint as `Video_Completes`
    ,ud.Video_Starts::bigint as `Video_Starts`
    ,ud.Delivered_Clicks::bigint as `Delivered_Clicks`
    ,ud.Freewheel_On_Target_Net_Delivered_Impressions::bigint as `Freewheel_On_Target_Net_Delivered_Impressions`
    ,ud.out_of_flight_flag::boolean as `out_of_flight_flag`
    ,ud.out_of_flight_impressions::bigint as `out_of_flight_impressions`
    ,ud.third_party_video_completes::bigint as `third_party_video_completes`
    ,ud.third_party_video_views::bigint as `third_party_video_views`
    ,ud.third_party_billable_impressions::bigint as `third_party_billable_impressions`
    ,ud.third_party_clicks::bigint as `third_party_clicks`
    ,ud.third_party_revenue::double as `third_party_revenue`
    ,ud.total_engagements::bigint as `total_engagements`
    ,ud.Create_Timestamp::timestamp as `Create_Timestamp`
    ,ud.Modified_Timestamp::timestamp as `Modified_Timestamp`
    ,is_dark_day::int as `is_dark_day`
    ,is_live_day::int as `is_live_day`
    ,live_days::bigint as `live_days`
    ,dark_days::bigint as `dark_days`
    ,rm_days::int as `rm_days`
    ,campaign_days::bigint as `campaign_days`
    ,days_to_date::double as `days_to_date`
from unified_data ud
left join plc_lvl_flg_data ldd
on ud.event_date = ldd.event_date
and coalesce(ud.Line_Item_or_Placement_ID,-1) = coalesce(ldd.Line_Item_or_Placement_ID,-1)
and coalesce(ud.campaign_id,-1) = coalesce(ldd.campaign_id,-1)
and coalesce(ud.aos_deal_line_item_id,-1) = coalesce(ldd.aos_deal_line_item_id,-1)
"""

unified_campaign_delivery = spark.sql(query)

unified_campaign_delivery = unified_campaign_delivery \
    .withColumn('Delivered_Impressions', col('Delivered_Impressions').cast(LongType())) \
    .withColumn('days_to_date', col('days_to_date').cast(DoubleType()))

# COMMAND ----------

# unified_campaign_delivery = unified_campaign_delivery.checkpoint()   # ← materializes before shuffle

# COMMAND ----------

unified_campaign_delivery.write.format('delta') \
    .mode('overwrite') \
    .partitionBy('Campaign_ID') \
    .option('mergeSchema', 'true') \
    .option("optimizeWrite", "true") \
    .option('overwriteDynamicPartitions', 'true') \
    .option('delta.enableDeletionVectors', 'false') \
    .option('delta.enableIcebergCompatV2', 'true') \
    .option('delta.universalFormat.enabledFormats', 'iceberg') \
    .option('delta.columnMapping.mode', 'name') \
    .saveAsTable('fox_bi_prod.gold_ad_sales.ft_unified_campaign_pacing')