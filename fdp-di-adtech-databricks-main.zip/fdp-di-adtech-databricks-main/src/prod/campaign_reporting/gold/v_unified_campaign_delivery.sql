  create or replace view fox_bi_prod.gold_ad_sales.v_unified_campaign_delivery as
  (
    select
    data_source `Data Source`
  ,event_date `Event Date`
  ,nvl(campaign_id, -1) `Campaign ID`
  ,nvl(campaign_name, 'N/A') `Campaign Name`
  ,campaign_start_date `Campaign Start Date`
  ,campaign_end_date `Campaign End Date`
  ,nvl(order_name,'N/A') `Order Name`
  ,nvl(order_id,-1) `Order ID`
  ,nvl(device,'N/A') `Device`
  ,nvl(advertiser_name,'N/A') `Advertiser Name`
  ,nvl(agency_name,'N/A') `Agency Name`
  ,nvl(aos_advertiser_name,'N/A') `AOS Advertiser Name`
  ,nvl(AOS_agency_name,'N/A') `AOS Agency Name`
  ,nvl(advertiser_id,-1) `Advertiser ID`
  ,nvl(business_unit,'N/A') `Business Unit`
  ,nvl(Ad_Unit_Format,'N/A') `Ad Unit Format`
  ,nvl(line_item_or_placement_id,-1) `Line Item or Placement ID`
  ,nvl(line_item_or_placement_name,'N/A') `Line Item or Placement Name`
  ,nvl(demand_type,'N/A') `Demand Type`
  ,line_item_or_placement_start_date `Line Item or Placement Start Date`
  ,line_item_or_placement_end_date `Line Item or Placement End Date`
  ,nvl(Delivered_Impressions,0) `Delivered Impressions`
  ,nvl(Delivered_Revenue,0) `Delivered Revenue`
  ,nvl(Video_Completes,0) `Video Completes`
  ,nvl(Video_Starts,0) `Video Starts`
  ,nvl(Delivered_Clicks,0) `Delivered Clicks`
  ,nvl(Freewheel_On_Target_Net_Delivered_Impressions,0) `Freewheel On-Target Net Delivered Impressions`
  ,nvl(campaign_name_derived,'N/A') `Campaign Name Derived`
  ,nvl(account_manager,'N/A') `Account Manager`
  ,nvl(package_name,'N/A') `Package Name`
  ,nvl(net_unit_cost,0)::decimal(22, 2) `Net Unit Cost`
  ,nvl(guaranteed_impressions,0) `Guaranteed Impressions`
  ,nvl(guaranteed_revenue,0)::decimal(22, 2) `Guaranteed Revenue`
  ,nvl(external_ad_id, -1) `External AD ID`
  ,nvl(Parent_Line_Item_Name, 'N/A') `Parent Line Item Name`
  ,demo_comp `Demo Comp`
  ,nvl(aos_deal_id, -1) `AOS Deal ID`
  ,nvl(aos_deal_name, 'N/A') `AOS Deal Name`
  ,aos_deal_start_date `AOS Deal Start Date`
  ,aos_deal_end_date `AOS Deal End Date`
  ,nvl(aos_deal_line_item_name,'N/A') `AOS Deal Line Item Name`
  ,nvl(aos_deal_line_item_id,-1) `AOS Deal Line Item ID`
  ,nvl(demo_band,'N/A') `Demo Band`
  ,nvl(billable_third_party_server,'N/A') `Billable Third Party Server`
  ,nvl(third_party_line_item_id, -1) `Third Party Line Item ID`
  ,multiple_ad_servers `Multiple_Ad_Servers`
  ,multiple_ad_server_id `Multiple Ad Server ID`
  ,nvl(fw_audience_segment,'N/A') `FW Audience Segment`
  ,nvl(fw_video_group,'N/A') `FW Video Group`
  ,nvl(Third_Party_Video_Completes,0) `Third Party Video Completes`
  ,nvl(Third_Party_Video_Views,0) `Third Party Video Views`
  ,nvl(Third_Party_Billable_Impressions,0) `Third Party Billable Impressions`
  ,nvl(Third_Party_Clicks,0) `Third Party Clicks`
  ,nvl(Third_Party_Revenue,0)::decimal(22, 2) `Third Party Revenue`
  ,create_timestamp `Create Timestamp`
  ,modified_timestamp `Modified Timestamp`
 from
    fox_bi_prod.gold_ad_sales.mv_ft_unified_campaign_delivery
  )