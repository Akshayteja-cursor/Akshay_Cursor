# Databricks notebook source
from datetime import datetime, timedelta

# COMMAND ----------

# spark.sparkContext.setCheckpointDir("dbfs:/checkpoints/ft_freewheel_campaign_pacing")


# COMMAND ----------

# Reduce shuffle partitions
spark.conf.set("spark.sql.shuffle.partitions", "200")

# COMMAND ----------

# Adaptive query execution
spark.conf.set("spark.sql.adaptive.enabled",                    "true")
spark.conf.set("spark.sql.adaptive.localShuffleReader.enabled", "true")
spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled", "true")

# COMMAND ----------

# Delta optimized write
spark.conf.set("spark.databricks.delta.optimizeWrite.enabled", "true")
spark.conf.set("spark.databricks.delta.autoCompact.enabled",   "true")

# COMMAND ----------

#date = dbutils.widgets.get('date')

# COMMAND ----------

query = """

WITH campaign_delivery AS (
    SELECT
        /*+ BROADCAST(dim_plc, dim_camp) */
        camp.event_date,
        coalesce(
            camp.campaign_id,
            camp.deal_id,
            camp.mrm_rule_id,
            camp.exchange_listing_id,
            camp.sold_order_id
        ) AS campaign_id1,
        coalesce(
            camp.campaign_name,
            camp.deal_name,
            camp.mrm_rule_name,
            camp.exchange_listing_name,
            camp.sold_order_name
        ) AS campaign_name1,
        camp.campaign_id,
        UPPER(camp.campaign_name) AS campaign_name,
        camp.campaign_start_timestamp_est,
        camp.campaign_end_timestamp_est,
        coalesce(
            camp.campaign_start_timestamp_est::date,
            camp.deal_start_timestamp_est::date,
            camp.mrm_rule_start_timestamp_est::date,
            camp.sold_order_start_timestamp_est::date,
            camp.exchange_listing_start_timestamp_est::date
        ) AS campaign_start_date,
        coalesce(
            camp.campaign_end_timestamp_est::date,
            camp.deal_end_timestamp_est::date,
            camp.mrm_rule_end_timestamp_est::date,
            camp.sold_order_end_timestamp_est::date,
            camp.exchange_listing_end_timestamp_est::date
        ) AS campaign_end_date,
        camp.advertiser_id,
        UPPER(camp.advertiser_name) AS advertiser_name,
        UPPER(camp.agency_name) AS agency_name,
        camp.placement_id,
        UPPER(placement_name) AS placement_name,
        placement_start_timestamp_est::date AS placement_start_date,
        placement_end_timestamp_est::date AS placement_end_date,
        budget_model,
        global_ad_unit_position,
        global_ad_unit_category,
        UPPER(series_name) AS series_name,
        UPPER(show_name) AS show_name,
        UPPER(video_vertical) AS video_vertical,
        UPPER(video_vertical) AS business_unit,
        UPPER(
            CASE
                WHEN device_name LIKE 'CTV' THEN 'CTV'
                WHEN device_name LIKE 'STB' THEN 'STB'
                WHEN device_name LIKE 'MB/TB' THEN 'Mobile/Tablet Web'
                WHEN device_name LIKE 'DT' THEN 'Desktop Web'
                ELSE 'N/A'
            END
        ) AS device_name,
        dim_plc.placement_avg_user_frequency,
        dim_camp.campaign_avg_user_frequency,
        video_id,
        UPPER(video_name) AS video_name,
        camp.insertion_order_id,
        UPPER(camp.insertion_order_name) AS insertion_order_name,
        camp.insertion_order_start_timestamp_est::DATE AS insertion_order_start_date,
        camp.insertion_order_end_timestamp_est::DATE AS insertion_order_end_date,
        deal_id,
        UPPER(deal_name) AS deal_name,
        deal_start_timestamp_est::date AS deal_start_date,
        deal_end_timestamp_est::date AS deal_end_date,
        UPPER(deal_type) AS deal_type,
        external_deal_id,
        programmatic_ad_id,
        programmatic_creative_duration,
        deal_ad_units,
        dsp_name,
        CASE
            WHEN platform_group = 'Tubi' THEN 'FOX on Tubi'
            WHEN video_vertical = 'Entertainment' THEN
                CASE
                    WHEN platform_group = 'Hulu' THEN 'FOX on Hulu'
                    WHEN platform_group = 'STB VOD' THEN 'STB VOD'
                    ELSE 'FOX'
                END
            ELSE video_vertical
        END AS Property,
        camp.creative_id,
        camp.creative_name,
        creative_duration_secs,
        video_duration,
        stream_type,
        UPPER(camp.sales_channel_type) AS sales_channel_type,
        camp.demo_band ,
        MAX(CASE WHEN camp.event_date not between coalesce(
            camp.campaign_start_timestamp_est::date,
            camp.deal_start_timestamp_est::date,
            camp.mrm_rule_start_timestamp_est::date,
            camp.sold_order_start_timestamp_est::date,
            camp.exchange_listing_start_timestamp_est::date
        ) and coalesce(
            camp.campaign_end_timestamp_est::date,
            camp.deal_end_timestamp_est::date,
            camp.mrm_rule_end_timestamp_est::date,
            camp.sold_order_end_timestamp_est::date,
            camp.exchange_listing_end_timestamp_est::date
        ) THEN 1 ELSE 0 END) OVER (PARTITION BY coalesce(camp.campaign_id,deal_id))::boolean AS out_of_flight_flag,
        SUM(CASE WHEN camp.event_date not between coalesce(
            camp.campaign_start_timestamp_est::date,
            camp.deal_start_timestamp_est::date,
            camp.mrm_rule_start_timestamp_est::date,
            camp.sold_order_start_timestamp_est::date,
            camp.exchange_listing_start_timestamp_est::date
        ) and coalesce(
            camp.campaign_end_timestamp_est::date,
            camp.deal_end_timestamp_est::date,
            camp.mrm_rule_end_timestamp_est::date,
            camp.sold_order_end_timestamp_est::date,
            camp.exchange_listing_end_timestamp_est::date
        ) THEN net_counted_ads ELSE 0 END) as out_of_flight_impressions,
        on_target_net_delivered_impressions_quantity,
        booked_on_target_impression_goal,
        impression_goal,
        SUM(gross_counted_ads) AS gross_counted_ads,
        SUM(net_counted_ads) AS delivered_impressions,
        SUM(run_revenue_amount) AS Delivered_Revenue,
        SUM(delivered_clicks) AS delivered_clicks,
        camp.AOS_deal_id,
        UPPER(camp.AOS_deal_name) AS AOS_deal_name,
        camp.AOS_Deal_start_date,
        camp.AOS_Deal_end_date,
        sales_order_line_item_id,
        UPPER(camp.sales_order_line_item_name) AS sales_order_line_item_name,
        sales_order_line_item_start_date,
        sales_order_line_item_end_date,
        UPPER(camp.AOS_advertiser_name) AS AOS_advertiser_name,
        UPPER(camp.foxipedia_agency_name) AS AOS_agency_name,
        UPPER(camp.Campaign_Name_Derived) AS Campaign_Name_Derived,
        UPPER(camp.package_name) AS package_name,
        UPPER(camp.owner_name) AS owner_name,
        camp.net_unit_cost,
        camp.placement_delivered_demo_comp AS demo_comp,
        camp.estimated_demo_comp_vpvh AS planned_demo_comp,
        guaranteed_qty AS Guaranteed_Impressions,
        camp.guaranteed_revenue AS Guaranteed_Revenue,
        ps_line_item_id::BIGINT AS External_AD_ID,
        UPPER(camp.parent_line_item_name) AS parent_line_item_name,
        UPPER(camp.primary_salesperson_name) AS primary_salesperson_name,
        UPPER(camp.account_coordinator) AS account_coordinator,
        UPPER(camp.fw_audience_segment) AS fw_audience_segment,
        UPPER(camp.product_name) AS product_name,
        UPPER(camp.fw_rbp_advanced) fw_rbp_advanced,
        UPPER(array_join(array_sort(split(camp.fw_video_group, ', ')),', ')) AS fw_video_group,
        NVL(
            CASE
                WHEN billable_third_party_description = 'DCM' THEN 'FOX DCM'
                WHEN billable_third_party_description = 'Doubleverify' THEN 'FOX Doubleverify'
                WHEN billable_third_party_description = 'Innovid' THEN 'FOX Innovid'
                WHEN billable_third_party_description = 'Flashtalking' THEN 'FOX Flashtalking'
                WHEN billable_third_party_description = 'Extreme Reach' THEN 'FOX Extreme Reach'
                WHEN billable_third_party_description = 'Sizmek' THEN 'FOX Sizmek'
                WHEN billable_third_party_description = '1st Party' THEN 'FOX 1st Party'
                ELSE billable_third_party_description
            END,
            'N/A'
        ) AS billable_third_part_server,
        camp.primary_property,
        camp.pitch_id,
        camp.cost_method_name,
        camp.unit_type,
        camp.etl_load_timestamp AS Create_Timestamp,
        camp.etl_load_timestamp AS Modified_Timestamp
    FROM fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily camp
    LEFT JOIN (
        SELECT
            event_date,
            placement_id,
            campaign_id,
            advertiser_name,
            agency_name,
            insertion_order_id,
            SUM(on_target_net_delivered_impressions_quantity) AS on_target_net_delivered_impressions_quantity
        FROM fox_bi_prod.gold_ad_sales.ft_freewheel_demo_comp_daily
        WHERE event_date::date >= '2024-01-01'
        GROUP BY ALL
    ) dc
        ON dc.placement_id = camp.placement_id
        AND dc.campaign_id = camp.campaign_id
        AND dc.advertiser_name = camp.advertiser_name
        AND dc.agency_name = camp.agency_name
        AND dc.insertion_order_id = camp.insertion_order_id
        AND dc.event_date = camp.event_date
    LEFT JOIN ( 
            SELECT DISTINCT 
                Placement_ID,
                placement_avg_user_frequency
            FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_placement
        ) dim_plc
            ON dim_plc.Placement_ID = camp.Placement_ID
        LEFT JOIN ( 
            SELECT DISTINCT 
                Campaign_ID,
                campaign_avg_user_frequency
            FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_campaign
        ) dim_camp
            ON dim_camp.Campaign_ID = camp.Campaign_ID
    WHERE 1 = 1
        AND camp.event_date::date >= '2024-01-01'
    GROUP BY ALL
),
tpcd AS (
    SELECT
        camp.event_date,
        camp.creative_id,
        placement_id,
        global_ad_unit_position,
        billable_third_part_server,
        MAX(tpcd.Third_Party_Line_Item_ID) AS Third_Party_Line_Item_ID,
        SUM(tpcd.third_party_video_completes) AS third_party_video_completes,
        SUM(tpcd.third_party_video_views) AS third_party_video_views,
        SUM(tpcd.third_party_billable_impressions) AS third_party_billable_impressions,
        SUM(tpcd.third_party_clicks) AS third_party_clicks,
        SUM(tpcd.third_party_revenue) AS third_party_revenue
    FROM (
        SELECT DISTINCT
            event_date,
            ad_unit_id,
            placement_id,
            global_ad_unit_position,
            creative_id,
            NVL(
                CASE
                    WHEN billable_third_party_description = 'DCM' THEN 'FOX DCM'
                    WHEN billable_third_party_description = 'Doubleverify' THEN 'FOX Doubleverify'
                    WHEN billable_third_party_description = 'Innovid' THEN 'FOX Innovid'
                    WHEN billable_third_party_description = 'Flashtalking' THEN 'FOX Flashtalking'
                    WHEN billable_third_party_description = 'Extreme Reach' THEN 'FOX Extreme Reach'
                    WHEN billable_third_party_description = 'Sizmek' THEN 'FOX Sizmek'
                    WHEN billable_third_party_description = '1st Party' THEN 'FOX 1st Party'
                    ELSE billable_third_party_description
                END,
                'N/A'
            ) AS billable_third_part_server
        FROM fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily
    ) camp
    LEFT JOIN (
        SELECT
            event_date,
            ad_unit_id,
            split_part(creative_id, '-', 1) AS creative_id,
            campaign_id AS Third_Party_Line_Item_ID,
            SUM(third_party_video_completes) AS third_party_video_completes,
            SUM(third_party_video_views) AS third_party_video_views,
            SUM(third_party_billable_impressions) AS third_party_billable_impressions,
            SUM(third_party_clicks) AS third_party_clicks,
            SUM(third_party_revenue) AS third_party_revenue,
            CASE
                WHEN third_party_billable_server = 'Moat' THEN 'Moat'
                WHEN third_party_billable_server IN (
                    'DFA by Google',
                    'Dart Report Reader',
                    'Dart Report Reader, DFA by Google',
                    'DFP by Google'
                ) THEN 'FOX DCM'
                WHEN third_party_billable_server = 'DoubleVerify' THEN 'FOX Doubleverify'
                WHEN third_party_billable_server = 'Innovid 3rd Party' THEN 'FOX Innovid'
                WHEN third_party_billable_server IN (
                    'FlashTalking',
                    'FlashTalking Email Reader'
                ) THEN 'FOX Flashtalking'
                WHEN third_party_billable_server IN (
                    'Extreme Reach Email',
                    'ExtremeReachAPI'
                ) THEN 'FOX Extreme Reach'
                WHEN third_party_billable_server IN (
                    'MediaMind',
                    'MediaMind Report Reader',
                    'Sizmek SAS Report Reader',
                    'MediaMind Report Reader, Sizmek SAS Report Reader',
                    'Sizmek SAS Report Reader, MediaMind Report Reader'
                ) THEN 'FOX Sizmek'
                WHEN third_party_billable_server = 'TubeMogul' THEN 'TubeMogul'
                ELSE 'FOX 1st Party'
            END AS billable_third_party_server
        FROM fox_bi_prod.silver_ads.ft_third_party_campaign_delivery_daily_data
        WHERE ad_unit_id <> '-1'
            AND event_date::date >= '2024-01-01'
        GROUP BY ALL
    ) tpcd
        ON split_part(tpcd.creative_id, '-', 1) = camp.creative_id
        AND tpcd.ad_unit_id = camp.ad_unit_id
        AND tpcd.event_date = camp.event_date
        AND camp.billable_third_part_server = tpcd.billable_third_party_server

    GROUP BY ALL
),
campaign_base AS (
    SELECT
        camp.*,
        third_party_line_item_id,
        third_party_billable_impressions,
        third_party_clicks,
        third_party_revenue,
        third_party_video_completes,
        third_party_video_views
    FROM campaign_delivery camp
    LEFT JOIN tpcd
        ON tpcd.creative_id = camp.creative_id
        AND tpcd.event_date = camp.event_date
        AND tpcd.billable_third_part_server = camp.billable_third_part_server
        AND tpcd.global_ad_unit_position = camp.global_ad_unit_position
        AND tpcd.placement_id = camp.placement_id
),
campaign_days AS (
    SELECT
        coalesce(campaign_id, deal_id) AS campaign_deal_id,
        coalesce(campaign_name, deal_name) AS campaign_deal_name,
        coalesce(campaign_start_timestamp_est, deal_start_date) AS campaign_deal_start_date,
        coalesce(campaign_end_timestamp_est, deal_end_date) AS campaign_deal_end_date,
        campaign_id,
        campaign_name,
        campaign_start_timestamp_est,
        campaign_end_timestamp_est,
        campaign_avg_user_frequency,
        advertiser_name,
        agency_name,
        out_of_flight_flag,
        deal_id,
        deal_name,
        deal_type,
        deal_start_date,
        deal_end_date,
        placement_id,
        placement_name,
        placement_start_date,
        placement_end_date,
        budget_model,
        booked_on_target_impression_goal,
        impression_goal,
        placement_avg_user_frequency,
        Guaranteed_Impressions,
        Guaranteed_Revenue,
        net_unit_cost,
        AOS_deal_id,
        AOS_deal_name,
        AOS_Deal_start_date,
        AOS_Deal_end_date,
        sales_order_line_item_id,
        sales_order_line_item_name,
        sales_order_line_item_start_date,
        sales_order_line_item_end_date,
        package_name,
        owner_name,
        AOS_advertiser_name,
        AOS_agency_name,
        External_AD_ID::BIGINT,
        parent_line_item_name,
        primary_salesperson_name,
        account_coordinator,
        billable_third_part_server,
        primary_property,
        pitch_id,
        sales_channel_type,
        cost_method_name,
        unit_type,
        fw_audience_segment,
        fw_video_group,
        fw_rbp_advanced,
        product_name,
        demo_band,
        explode(
            sequence(
                coalesce(placement_start_date::date, deal_start_date),
                coalesce(placement_end_date::date, deal_end_date),
                interval 1 day
            )
        ) AS full_date
    FROM campaign_base
    GROUP BY ALL
    ORDER BY ALL
)
,final as (
SELECT
    coalesce(camp.event_date, d.full_date) AS event_date,
    coalesce(camp.campaign_id, d.campaign_id, camp.campaign_id1,d.campaign_deal_id) AS campaign_id,
    UPPER(coalesce(camp.campaign_name, d.campaign_name, camp.campaign_name1,d.campaign_deal_name)) AS campaign_name,
    coalesce(
        camp.campaign_start_timestamp_est,
        d.campaign_start_timestamp_est,
        camp.campaign_start_date,
        d.campaign_deal_start_date
    ) AS campaign_start_timestamp_est,
    coalesce(
        camp.campaign_end_timestamp_est,
        d.campaign_end_timestamp_est,
        camp.campaign_end_date,
        d.campaign_deal_end_date
    ) AS campaign_end_timestamp_est,
    coalesce(camp.advertiser_id, -1) AS advertiser_id,
    UPPER(coalesce(camp.advertiser_name, d.advertiser_name)) AS advertiser_name,
    UPPER(coalesce(camp.agency_name, d.agency_name)) AS agency_name,
    coalesce(camp.placement_id, d.placement_id) AS placement_id,
    UPPER(coalesce(camp.placement_name, d.placement_name)) AS placement_name,
    coalesce(camp.placement_start_date, d.placement_start_date) AS placement_start_date,
    coalesce(camp.placement_end_date, d.placement_end_date) AS placement_end_date,
    coalesce(camp.budget_model, d.budget_model) AS budget_model,
    coalesce(camp.global_ad_unit_position, 'N/A') AS global_ad_unit_position,
    coalesce(camp.global_ad_unit_category, 'N/A') AS global_ad_unit_category,
    UPPER(coalesce(camp.series_name, 'N/A')) AS series_name,
    UPPER(coalesce(camp.show_name, 'N/A')) AS show_name,
    UPPER(coalesce(camp.video_vertical, 'N/A')) AS video_vertical,
    UPPER(coalesce(camp.business_unit, 'N/A')) AS business_unit,
    UPPER(coalesce(camp.device_name, 'N/A')) AS device_name,
    coalesce(camp.placement_avg_user_frequency, d.placement_avg_user_frequency) AS placement_avg_user_frequency,
    coalesce(camp.campaign_avg_user_frequency, d.campaign_avg_user_frequency) AS campaign_avg_user_frequency,
    coalesce(camp.video_id, -1) AS video_id,
    UPPER(coalesce(camp.video_name, 'N/A')) AS video_name,
    coalesce(camp.insertion_order_id, -1) AS insertion_order_id,
    UPPER(coalesce(camp.insertion_order_name, 'N/A')) AS insertion_order_name,
    insertion_order_start_date,
    insertion_order_end_date,
    coalesce(camp.deal_id, d.deal_id) AS deal_id,
    UPPER(coalesce(camp.deal_name, d.deal_name)) AS deal_name,
    coalesce(camp.deal_start_date, d.deal_start_date) AS deal_start_date,
    coalesce(camp.deal_end_date, d.deal_end_date) AS deal_end_date,
    UPPER(coalesce(camp.deal_type, d.deal_type)) AS deal_type,
    coalesce(camp.external_deal_id, -1) AS external_deal_id,
    coalesce(camp.programmatic_ad_id, -1) AS programmatic_ad_id,
    coalesce(camp.programmatic_creative_duration, 'N/A') AS programmatic_creative_duration,
    coalesce(camp.deal_ad_units, 'N/A') AS deal_ad_units,
    coalesce(camp.dsp_name, 'N/A') AS dsp_name,
    coalesce(camp.Property, 'N/A') AS Property,
    coalesce(camp.creative_id, -1) AS creative_id,
    UPPER(coalesce(camp.creative_name, 'N/A')) AS creative_name,
    coalesce(camp.creative_duration_secs, 0) AS creative_duration_secs,
    coalesce(camp.video_duration, 0) AS video_duration,
    coalesce(camp.stream_type, 'N/A') AS stream_type,
    UPPER(coalesce(camp.sales_channel_type, d.sales_channel_type)) AS sales_channel_type,
    coalesce(camp.demo_band, d.demo_band) AS demo_band,
    coalesce(camp.out_of_flight_flag, d.out_of_flight_flag) AS out_of_flight_flag,
    coalesce(camp.out_of_flight_impressions, 0) AS out_of_flight_impressions,
    camp.on_target_net_delivered_impressions_quantity AS on_target_net_delivered_impressions_quantity,
    coalesce(camp.booked_on_target_impression_goal,d.booked_on_target_impression_goal) AS booked_on_target_impression_goal,
    coalesce(camp.impression_goal,d.impression_goal) AS impression_goal,
    coalesce(camp.gross_counted_ads, 0) AS gross_counted_ads,
    coalesce(camp.delivered_impressions, 0) AS delivered_impressions,
    coalesce(camp.Delivered_Revenue, 0) AS Delivered_Revenue,
    coalesce(camp.delivered_clicks, 0) AS delivered_clicks,
    coalesce(camp.AOS_deal_id, d.AOS_deal_id) AS AOS_deal_id,
    UPPER(coalesce(camp.AOS_deal_name, d.AOS_deal_name)) AS AOS_deal_name,
    coalesce(camp.AOS_Deal_start_date, d.AOS_Deal_start_date) AS AOS_Deal_start_date,
    coalesce(camp.AOS_Deal_end_date, d.AOS_Deal_end_date) AS AOS_Deal_end_date,
    coalesce(camp.sales_order_line_item_id, d.sales_order_line_item_id) AS sales_order_line_item_id,
    UPPER(coalesce(camp.sales_order_line_item_name, d.sales_order_line_item_name)) AS sales_order_line_item_name,
    coalesce(camp.sales_order_line_item_start_date, d.sales_order_line_item_start_date)::Date AS sales_order_line_item_start_date,
    coalesce(camp.sales_order_line_item_end_date, d.sales_order_line_item_end_date)::Date AS sales_order_line_item_end_date,
    UPPER(coalesce(camp.AOS_advertiser_name, d.AOS_advertiser_name)) AS AOS_advertiser_name,
    UPPER(coalesce(camp.AOS_agency_name, d.AOS_agency_name)) AS AOS_agency_name,
    UPPER(coalesce(camp.Campaign_Name_Derived, 'N/A')) AS Campaign_Name_Derived,
    UPPER(coalesce(camp.package_name, d.package_name)) AS package_name,
    UPPER(coalesce(camp.owner_name, d.owner_name)) AS owner_name,
    coalesce(camp.net_unit_cost, d.net_unit_cost) AS net_unit_cost,
    coalesce(camp.demo_comp, 0) AS demo_comp,
    coalesce(camp.planned_demo_comp, 'N/A') AS planned_demo_comp,
    coalesce(camp.Guaranteed_Impressions, d.Guaranteed_Impressions) AS Guaranteed_Impressions,
    coalesce(camp.Guaranteed_Revenue, d.Guaranteed_Revenue) AS Guaranteed_Revenue,
    coalesce(camp.External_AD_ID, d.External_AD_ID)::BIGINT AS External_AD_ID,
    UPPER(coalesce(camp.parent_line_item_name, d.parent_line_item_name)) AS parent_line_item_name,
    UPPER(coalesce(camp.primary_salesperson_name, d.primary_salesperson_name)) AS primary_salesperson_name,
    UPPER(coalesce(camp.account_coordinator, d.account_coordinator)) AS account_coordinator,
    UPPER(coalesce(camp.fw_audience_segment, d.fw_audience_segment)) AS fw_audience_segment,
    UPPER(coalesce(camp.fw_video_group, d.fw_video_group)) AS fw_video_group,
    UPPER(coalesce(camp.fw_rbp_advanced, d.fw_rbp_advanced)) AS fw_rbp_advanced,
    UPPER(coalesce(camp.product_name, d.product_name)) AS product_name,
    coalesce(camp.billable_third_part_server, d.billable_third_part_server) AS billable_third_part_server,
    UPPER(coalesce(camp.primary_property, d.primary_property)) AS primary_property,
    UPPER(coalesce(camp.cost_method_name, d.cost_method_name)) AS cost_method_name,
    UPPER(coalesce(camp.unit_type, d.unit_type)) AS unit_type,
    UPPER(coalesce(camp.pitch_id, d.pitch_id)) AS pitch_id,
    camp.Third_Party_Line_Item_ID AS Third_Party_Line_Item_ID,
    coalesce(camp.third_party_video_completes, 0) AS third_party_video_completes,
    coalesce(camp.third_party_video_views, 0) AS third_party_video_views,
    coalesce(camp.third_party_billable_impressions, 0) AS third_party_billable_impressions,
    coalesce(camp.third_party_clicks, 0) AS third_party_clicks,
    coalesce(camp.third_party_revenue, 0) AS third_party_revenue,
    Create_Timestamp,
    Modified_Timestamp
FROM campaign_base camp
FULL OUTER JOIN (
    SELECT *
    FROM campaign_days
    WHERE full_date BETWEEN '2024-01-01' AND current_date() - 1
) d
    ON coalesce(d.campaign_id, -1) = coalesce(camp.campaign_id, -1)
    AND coalesce(d.placement_id, d.deal_id) = coalesce(camp.placement_id, camp.deal_id)
    AND d.full_date = camp.event_date
ORDER BY coalesce(camp.event_date, d.full_date)
)
SELECT * FROM final
"""

# if datetime.strptime(date, '%Y-%m-%d').day < 5:
#     date = (datetime.strptime(date, '%Y-%m-%d') - timedelta(days=5)).replace(day=1).strftime('%Y-%m-%d')
# else:
#     date = datetime.strptime(date, '%Y-%m-%d').replace(day=1).strftime('%Y-%m-%d')

fw_campaign_pacing = spark.sql(query)

# COMMAND ----------

# tmp_path = "/tmp/fw_campaign_pacing_checkpoint"
# fw_campaign_pacing = fw_campaign_pacing.checkpoint()   # ← materializes before shuffle
# fw_campaign_pacing.write.format("delta").mode("overwrite").option("optimizeWrite", "true").save(tmp_path)
# fw_campaign_pacing = spark.read.format("delta").load(tmp_path)
#
# fw_campaign_pacing = fw_campaign_pacing.checkpoint()
if not spark.catalog.tableExists(f'fox_bi_prod.gold_ad_sales.ft_freewheel_campaign_pacing'): #Add the table name for First time load 
    fw_campaign_pacing.write.format('delta')\
        .mode('overwrite')\
        .partitionBy('Event_Date')\
        .option('mergeSchema', 'true')\
        .option("optimizeWrite", "true")\
        .option('overwriteDynamicPartitions', 'true')\
        .option('delta.enableDeletionVectors', 'false')\
        .option('delta.enableIcebergCompatV2', 'true')\
        .option('delta.universalFormat.enabledFormats', 'iceberg')\
        .option('delta.columnMapping.mode', 'name')\
        .saveAsTable('fox_bi_prod.gold_ad_sales.ft_freewheel_campaign_pacing')
else:
    fw_campaign_pacing.write.format('delta')\
        .mode('overwrite')\
        .option("optimizeWrite", "true")\
        .option('partitionOverwriteMode', 'dynamic')\
        .option('mergeSchema', 'true')\
        .saveAsTable('fox_bi_prod.gold_ad_sales.ft_freewheel_campaign_pacing')
    