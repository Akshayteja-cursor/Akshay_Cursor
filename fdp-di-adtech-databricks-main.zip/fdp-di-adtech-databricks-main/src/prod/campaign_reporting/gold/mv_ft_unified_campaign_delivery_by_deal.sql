CREATE OR REPLACE MATERIALIZED VIEW fox_bi_prod.gold_ad_sales.mv_ft_unified_campaign_delivery_by_deal
  (
  AOS_Deal_ID	bigint
,AOS_Deal_Name	string
,AOS_Deal_Start_Date	date
,AOS_Deal_End_Date	date
,Advertiser_Name	string
,Targeted_Demos	array<string>
,Agency_Name	string
,Sales_Channels	array<string>
,Show_Names	array<string>
,Multiple_Ad_Servers_Flag	boolean
,Budget	double
,Spend	double
,Overall_Performance	string
,Targeted_Devices	array<string>
,CPM	decimal(5,1)
,CTR	decimal(5,1)
,Total_Views	double
,Total_Delivered_Clicks	bigint
,Total_Delivered_Revenue	double
,Total_First_Party_Delivered_Revenue	double
,Total_Third_Party_Revenue	double
,Impression_Pacing	double
,Third_Party_Impression_Pacing	double
,First_Party_Impression_Pacing	double
,Revenue_Pacing	double
,First_Party_Revenue_Pacing	double
,Third_Party_Revenue_Pacing	double
,Total_Guaranteed_Impressions	bigint
,Total_Delivered_Impressions	bigint
,Total_First_Party_Delivered_Impressions	bigint
,Total_Third_Party_Impressions	bigint
,Create_Timestamp	timestamp
,Modified_Timestamp	timestamp
,FW_Audience_Segment	array<string>
,FW_Video_Group	array<string>
,total_creatives bigint
,total_placements bigint
,total_shows bigint
,Total_Countries bigint
,Total_States bigint
,Total_Geo_Ads bigint
) AS
SELECT
    *
FROM fox_bi_prod.gold_ad_sales.ft_unified_campaign_delivery_by_deal
CLUSTER BY AOS_Deal_ID