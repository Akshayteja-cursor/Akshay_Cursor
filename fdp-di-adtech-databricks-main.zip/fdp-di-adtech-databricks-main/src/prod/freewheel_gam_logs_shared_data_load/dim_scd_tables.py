# Databricks notebook source
# MAGIC %md
# MAGIC dim_content_scd

# COMMAND ----------

from pyspark.sql.functions import col, lit, coalesce, max as spark_max, current_timestamp

# Step 1: Get max WRITE versions
# history_gam = spark.sql("DESCRIBE HISTORY fox_bi_prod.raw_ads.gam_content") \
#     .filter(col("operation") == "WRITE") \
#     .select(spark_max("version").alias("max_version")) \
#     .withColumn("table_name", lit("gam_content"))

# history_fts = spark.sql("DESCRIBE HISTORY fox_bi_prod.raw_ads.fts_gam_content") \
#     .filter(col("operation") == "WRITE") \
#     .select(spark_max("version").alias("max_version")) \
#     .withColumn("table_name", lit("fts_gam_content"))

# current_versions = history_fts #history_gam.unionByName(history_fts)
# control_versions = spark.table("fox_bi_prod.bronze_ads.scd_version_tracker")

# Step 2: Combine with control table
# version_info = current_versions.alias("v").join(
#     control_versions.alias("c"),
#     col("v.table_name") == col("c.table_name"),
#     how="left"
# ).select(
#     col("v.table_name"),
#     coalesce(col("c.last_processed_version"), col("v.max_version")).alias("from_version"),
#     col("v.max_version").alias("to_version")
# )

# Step 3: Extract as Python vars
# rows = version_info.collect()
# version_map = {row["table_name"]: {"from": row["from_version"], "to": row["to_version"]} for row in rows}

# gam_from_version = version_map["gam_content"]["from"]
# fts_from_version = version_map["fts_gam_content"]["from"]
# gam_to_version = version_map["gam_content"]["to"]
# fts_to_version = version_map["fts_gam_content"]["to"]

# print("gam:", gam_from_version, "→", gam_to_version)
# print("fts:", fts_from_version, "→", fts_to_version)

# COMMAND ----------

# GAM changes
# cdc_gam = spark.sql(f"""
#   SELECT * FROM table_changes('fox_bi_prod.raw_ads.gam_content', {gam_from_version}, {gam_to_version})
#   WHERE _change_type = 'insert'
# """)
# cdc_gam.createOrReplaceTempView("cdc_gam_content")

# FTS changes
# cdc_fts = spark.sql(f"""
#   SELECT * FROM table_changes('fox_bi_prod.raw_ads.fts_gam_content', {fts_from_version}, {fts_to_version})
#   WHERE _change_type = 'insert'
# """)
# cdc_fts.createOrReplaceTempView("cdc_fts_gam_content")


# COMMAND ----------

# MAGIC %sql
# MAGIC -- STEP 1: Source changes (deduped)
# MAGIC -- CREATE OR REPLACE TEMP VIEW source_changes AS
# MAGIC -- SELECT
# MAGIC --     'gam' AS authority_code,
# MAGIC --     4145 AS network_group_id,
# MAGIC --     COALESCE(dimension_content_id, -1) AS content_id,
# MAGIC --     COALESCE(dimension_content_name, 'N/A') AS content_name,
# MAGIC --     xxhash64(concat_ws('||', cast(COALESCE(dimension_content_id, -1) AS string), cast(4145 AS string))) AS content_key_hash,
# MAGIC --     CURRENT_TIMESTAMP() AS etl_created_at_timestamp_utc,
# MAGIC --     CURRENT_TIMESTAMP() AS etl_updated_at_timestamp_utc
# MAGIC -- FROM cdc_gam_content
# MAGIC -- QUALIFY ROW_NUMBER() OVER (PARTITION BY dimension_content_id ORDER BY _fivetran_synced DESC) = 1
# MAGIC
# MAGIC -- UNION ALL
# MAGIC
# MAGIC -- SELECT
# MAGIC --     'gam' AS authority_code,
# MAGIC --     63790564 AS network_group_id,
# MAGIC --     COALESCE(dimension_content_id, -1) AS content_id,
# MAGIC --     COALESCE(dimension_content_name, 'N/A') AS content_name,
# MAGIC --     xxhash64(concat_ws('||', cast(COALESCE(dimension_content_id, -1) AS string), cast(63790564 AS string))) AS content_key_hash,
# MAGIC --     CURRENT_TIMESTAMP() AS etl_created_at_timestamp_utc,
# MAGIC --     CURRENT_TIMESTAMP() AS etl_updated_at_timestamp_utc
# MAGIC -- FROM cdc_fts_gam_content
# MAGIC -- QUALIFY ROW_NUMBER() OVER (PARTITION BY dimension_content_id ORDER BY _fivetran_synced DESC) = 1
# MAGIC
# MAGIC -- ;

# COMMAND ----------

# from pyspark.sql.functions import col, lit, current_timestamp

# # Step 1: Load source_changes
# source_changes_df = spark.table("source_changes")

# # Step 2: Load current SCD snapshot
# scd_df = spark.table("fox_bi_prod.bronze_ads.gam_content_id_name_history").filter("is_current = TRUE")

# # Step 3: Identify changed records
# changed_df = source_changes_df.alias("src").join(
#     scd_df.alias("tgt"),
#     on="content_key_hash"
# ).filter(
#     (col("src.content_name") != col("tgt.content_name")) &
#     (col("tgt.is_current") == True)
# ).select("src.*").cache()

# changed_count = changed_df.count()
# print(f"🔁 Changed records (to expire + insert new version): {changed_count}")
# if changed_count > 0:
#     display(changed_df)

# # Step 4: Identify new records
# new_df = source_changes_df.alias("src").join(
#     scd_df.alias("tgt"),
#     on="content_key_hash",
#     how="left_anti"
# ).select("src.*").cache()

# new_count = new_df.count()
# print(f"✨ New records to insert: {new_count}")


# # Step 5: Expire existing (UPDATE is_current = FALSE)
# changed_df.createOrReplaceTempView("changed_records_snapshot")
# spark.sql("""
# MERGE INTO fox_bi_prod.bronze_ads.gam_content_id_name_history AS tgt
# USING changed_records_snapshot AS src
# ON tgt.content_key_hash = src.content_key_hash AND tgt.is_current = TRUE
# WHEN MATCHED THEN UPDATE SET
#   is_current = FALSE,
#   effective_end_timestamp_utc = CURRENT_TIMESTAMP() - INTERVAL 1 second,
#   etl_updated_at_timestamp_utc = CURRENT_TIMESTAMP()
# """)

# # Step 6: Prepare new versions to insert
# final_inserts_df = (
#     changed_df.unionByName(new_df)
#     .withColumn("effective_start_timestamp_utc", current_timestamp())
#     .withColumn("effective_end_timestamp_utc", lit("9999-12-31 23:59:59").cast("timestamp"))
#     .withColumn("is_current", lit(True))
#     .withColumn("network_group_id", col("network_group_id").cast("bigint"))  # ✅ Enforce schema match
# )

# # Step 7: Reorder columns to match target table
# final_inserts_df = final_inserts_df.select(
#     "authority_code",
#     "network_group_id",
#     "content_id",
#     "content_name",
#     "content_key_hash",
#     "effective_start_timestamp_utc",
#     "effective_end_timestamp_utc",
#     "is_current",
#     "etl_created_at_timestamp_utc",
#     "etl_updated_at_timestamp_utc"
# )

# # Step 8: Write to the target table
# final_inserts_count = final_inserts_df.count()
# print(f"✅ Final rows to insert into SCD table: {final_inserts_count}")

# final_inserts_df.write.mode("append").saveAsTable("fox_bi_prod.bronze_ads.gam_content_id_name_history")

# COMMAND ----------

# version_update_df = spark.createDataFrame([
#     ("gam_content", gam_to_version),
#     ("fts_gam_content", fts_to_version)
# ], ["table_name", "last_processed_version"]).withColumn("updated_at", current_timestamp())

# version_update_df.createOrReplaceTempView("version_updates")

# spark.sql("""
# MERGE INTO fox_bi_prod.bronze_ads.scd_version_tracker AS tgt
# USING version_updates AS src
# ON tgt.table_name = src.table_name

# WHEN MATCHED THEN UPDATE SET
#   tgt.last_processed_version = src.last_processed_version,
#   tgt.updated_at = src.updated_at

# WHEN NOT MATCHED THEN INSERT (
#   table_name,
#   last_processed_version,
#   updated_at
# )
# VALUES (
#   src.table_name,
#   src.last_processed_version,
#   src.updated_at
# )
# """)

# COMMAND ----------

# MAGIC %md
# MAGIC DIM LINEITEM SCD

# COMMAND ----------

# from pyspark.sql.functions import col, lit, coalesce, max as spark_max, current_timestamp

# # Step 1: Get max WRITE versions
# history_gam = spark.sql("DESCRIBE HISTORY fox_bi_prod.raw_ads.gam_line_item") \
#     .filter(col("operation") == "WRITE") \
#     .select(spark_max("version").alias("max_version")) \
#     .withColumn("table_name", lit("gam_line_item"))

# current_versions = history_gam
# control_versions = spark.table("fox_bi_prod.bronze_ads.scd_version_tracker")

# # Step 2: Combine with control table
# version_info = current_versions.alias("v").join(
#     control_versions.alias("c"),
#     col("v.table_name") == col("c.table_name"),
#     how="left"
# ).select(
#     col("v.table_name"),
#     coalesce(col("c.last_processed_version"), col("v.max_version")).alias("from_version"),
#     col("v.max_version").alias("to_version")
# )

# # Step 3: Extract as Python vars
# rows = version_info.collect()
# version_map = {row["table_name"]: {"from": row["from_version"], "to": row["to_version"]} for row in rows}

# gam_line_item_from_version = version_map["gam_line_item"]["from"]
# gam_line_item_to_version = version_map["gam_line_item"]["to"]


# print("gam:", gam_line_item_from_version, "→", gam_line_item_to_version)

# COMMAND ----------

# # GAM changes
# cdc_gam_line_item = spark.sql(f"""
#   SELECT * FROM table_changes('fox_bi_prod.raw_ads.gam_line_item', {gam_line_item_from_version}, {gam_line_item_to_version})
#   WHERE _change_type = 'insert'
# """)
# cdc_gam_line_item.createOrReplaceTempView("cdc_gam_line_item")

# COMMAND ----------

# %sql
# -- STEP 1: Source changes (deduped)
# CREATE OR REPLACE TEMP VIEW source_changes AS
# SELECT
#     'gam' AS authority_code,
#     4145 AS network_group_id,
#     CAST(COALESCE(line_item_id, '-1') AS LONG) AS line_item_id,
#     CAST(COALESCE(line_item_name, 'N/A') AS STRING) AS line_item_name,
#     xxhash64(concat_ws('||', cast(COALESCE(line_item_id, '-1') AS string), cast(4145 AS string))) AS line_item_key_hash,
#     CURRENT_TIMESTAMP() AS etl_created_at_timestamp_utc,
#     CURRENT_TIMESTAMP() AS etl_updated_at_timestamp_utc
# FROM cdc_gam_line_item
# QUALIFY ROW_NUMBER() OVER (PARTITION BY line_item_id ORDER BY etl_updated_timestamp DESC) = 1;

# COMMAND ----------

# from pyspark.sql.functions import col, lit, current_timestamp

# # Step 1: Load source_changes
# source_changes_df = spark.table("source_changes")

# # Step 2: Load current SCD snapshot
# scd_df = spark.table("fox_bi_prod.bronze_ads.gam_line_item_id_name_history").filter("is_current = TRUE")

# # Step 3: Identify changed records
# changed_df = source_changes_df.alias("src").join(
#     scd_df.alias("tgt"),
#     on="line_item_key_hash"
# ).filter(
#     (col("src.line_item_name") != col("tgt.line_item_name")) &
#     (col("tgt.is_current") == True)
# ).select("src.*").cache()

# changed_count = changed_df.count()
# print(f"🔁 Changed records (to expire + insert new version): {changed_count}")
# if changed_count > 0:
#     display(changed_df)

# # Step 4: Identify new records
# new_df = source_changes_df.alias("src").join(
#     scd_df.alias("tgt"),
#     on="line_item_key_hash",
#     how="left_anti"
# ).select("src.*").cache()

# new_count = new_df.count()
# print(f"✨ New records to insert: {new_count}")


# # Step 5: Expire existing (UPDATE is_current = FALSE)
# changed_df.createOrReplaceTempView("changed_records_snapshot")
# spark.sql("""
# MERGE INTO fox_bi_prod.bronze_ads.gam_line_item_id_name_history AS tgt
# USING changed_records_snapshot AS src
# ON tgt.line_item_key_hash = src.line_item_key_hash AND tgt.is_current = TRUE
# WHEN MATCHED THEN UPDATE SET
#   is_current = FALSE,
#   effective_end_timestamp_utc = CURRENT_TIMESTAMP() - INTERVAL 1 second,
#   etl_updated_at_timestamp_utc = CURRENT_TIMESTAMP()
# """)

# # Step 6: Prepare new versions to insert
# final_inserts_df = (
#     changed_df.unionByName(new_df)
#     .withColumn("effective_start_timestamp_utc", current_timestamp())
#     .withColumn("effective_end_timestamp_utc", lit("9999-12-31 23:59:59").cast("timestamp"))
#     .withColumn("is_current", lit(True))
#     .withColumn("network_group_id", col("network_group_id").cast("bigint"))
# )

# # Step 7: Reorder columns to match target table
# final_inserts_df = final_inserts_df.select(
#     "authority_code",
#     "network_group_id",
#     "line_item_id",
#     "line_item_name",
#     "line_item_key_hash",
#     "effective_start_timestamp_utc",
#     "effective_end_timestamp_utc",
#     "is_current",
#     "etl_created_at_timestamp_utc",
#     "etl_updated_at_timestamp_utc"
# )

# # Step 8: Write to the target table
# final_inserts_count = final_inserts_df.count()
# print(f"✅ Final rows to insert into SCD table: {final_inserts_count}")

# final_inserts_df.write.mode("append").saveAsTable("fox_bi_prod.bronze_ads.gam_line_item_id_name_history")

# COMMAND ----------

# #UPDATE CONTROL TABLE
# version_update_df = spark.createDataFrame([
#     ("gam_line_item", gam_line_item_to_version),
# ], ["table_name", "last_processed_version"]).withColumn("updated_at", current_timestamp())

# version_update_df.createOrReplaceTempView("version_updates")

# spark.sql("""
# MERGE INTO fox_bi_prod.bronze_ads.scd_version_tracker AS tgt
# USING version_updates AS src
# ON tgt.table_name = src.table_name

# WHEN MATCHED THEN UPDATE SET
#   tgt.last_processed_version = src.last_processed_version,
#   tgt.updated_at = src.updated_at

# WHEN NOT MATCHED THEN INSERT (
#   table_name,
#   last_processed_version,
#   updated_at
# )
# VALUES (
#   src.table_name,
#   src.last_processed_version,
#   src.updated_at
# )
# """)

# COMMAND ----------

# MAGIC %md
# MAGIC dim_site_section_scd

# COMMAND ----------

from pyspark.sql.functions import col, lit, coalesce, max as spark_max, current_timestamp

# Step 1: Get max WRITE versions
history_ss_500763 = spark.sql("DESCRIBE HISTORY fox_bi_prod.raw_ads.freewheel_s3_companion_site_section_500763_fox_affiliates") \
    .filter(col("operation") == "STREAMING UPDATE") \
    .select(spark_max("version").alias("max_version")) \
    .withColumn("table_name", lit("freewheel_s3_companion_site_section_500763_fox_affiliates"))


# history_ss_516429 = spark.sql("DESCRIBE HISTORY fox_bi_prod.raw_ads.freewheel_s3_companion_site_section_516429_fox_corp") \
#     .filter(col("operation") == "STREAMING UPDATE") \
#     .select(spark_max("version").alias("max_version")) \
#     .withColumn("table_name", lit("freewheel_s3_companion_site_section_516429_fox_corp"))




current_versions = history_ss_500763 #.union(history_ss_516429)
control_versions = spark.table("fox_bi_prod.bronze_ads.scd_version_tracker")

# Step 2: Combine with control table
version_info = current_versions.alias("v").join(
    control_versions.alias("c"),
    col("v.table_name") == col("c.table_name"),
    how="left"
).select(
    col("v.table_name"),
    coalesce(col("c.last_processed_version"), col("v.max_version")).alias("from_version"),
    col("v.max_version").alias("to_version")
)

# Step 3: Extract as Python vars
rows = version_info.collect()
version_map = {row["table_name"]: {"from": row["from_version"], "to": row["to_version"]} for row in rows}

print(version_map)

freewheel_ss_500763_from_version = version_map["freewheel_s3_companion_site_section_500763_fox_affiliates"]["from"]
freewheel_ss_500763_to_version = version_map["freewheel_s3_companion_site_section_500763_fox_affiliates"]["to"]

# freewheel_ss_516429_from_version = version_map["freewheel_s3_companion_site_section_516429_fox_corp"]["from"]
# freewheel_ss_516429_to_version = version_map["freewheel_s3_companion_site_section_516429_fox_corp"]["to"]


print("freewheel_ss_500763:", freewheel_ss_500763_from_version, "→", freewheel_ss_500763_to_version)
# print("freewheel_ss_516429:", freewheel_ss_516429_from_version, "→", freewheel_ss_516429_to_version)

# COMMAND ----------

# FREEWHEEL changes
cdc_freewheel_ss_500763 = spark.sql(f"""
  SELECT * FROM table_changes('fox_bi_prod.raw_ads.freewheel_s3_companion_site_section_500763_fox_affiliates', {freewheel_ss_500763_from_version}, {freewheel_ss_500763_to_version})
  WHERE _change_type = 'insert'
""")
cdc_freewheel_ss_500763.createOrReplaceTempView("cdc_freewheel_ss_500763")


# cdc_freewheel_ss_516429 = spark.sql(f"""
#   SELECT * FROM table_changes('fox_bi_prod.raw_ads.freewheel_s3_companion_site_section_516429_fox_corp', {freewheel_ss_516429_from_version}, {freewheel_ss_516429_to_version})
#   WHERE _change_type = 'insert'
# """)
# cdc_freewheel_ss_516429.createOrReplaceTempView("cdc_freewheel_ss_516429")

# COMMAND ----------

# MAGIC %sql
# MAGIC -- STEP 1: Source changes (deduped)
# MAGIC CREATE OR REPLACE TEMP VIEW source_changes AS
# MAGIC SELECT
# MAGIC     'freewheel' AS authority_code,
# MAGIC     500763 AS network_group_id,
# MAGIC     CAST(COALESCE(id,'-1') AS LONG) AS site_section_id,
# MAGIC     COALESCE(name,'N/A') AS site_section_name,
# MAGIC     xxhash64(concat_ws('||', COALESCE(id,'-1'), cast(500763 AS string))) AS site_section_key_hash,
# MAGIC     CURRENT_TIMESTAMP() AS etl_created_at_timestamp_utc,
# MAGIC     CURRENT_TIMESTAMP() AS etl_updated_at_timestamp_utc
# MAGIC FROM cdc_freewheel_ss_500763
# MAGIC QUALIFY ROW_NUMBER() OVER (PARTITION BY id ORDER BY updated_at DESC) = 1
# MAGIC
# MAGIC -- UNION ALL
# MAGIC
# MAGIC -- SELECT
# MAGIC --     'freewheel' AS authority_code,
# MAGIC --     516429 AS network_group_id,
# MAGIC --     CAST(COALESCE(id,'-1') AS LONG) AS site_section_id,
# MAGIC --     COALESCE(name,'N/A') AS site_section_name,
# MAGIC --     xxhash64(concat_ws('||', COALESCE(id,'-1'), cast(516429 AS string))) AS site_section_key_hash,
# MAGIC --     CURRENT_TIMESTAMP() AS etl_created_at_timestamp_utc,
# MAGIC --     CURRENT_TIMESTAMP() AS etl_updated_at_timestamp_utc
# MAGIC -- FROM cdc_freewheel_ss_516429
# MAGIC -- QUALIFY ROW_NUMBER() OVER (PARTITION BY id ORDER BY updated_at DESC) = 1
# MAGIC ;

# COMMAND ----------

from pyspark.sql.functions import col, lit, current_timestamp

# Step 1: Load source_changes
source_changes_df = spark.table("source_changes")

# Step 2: Load current SCD snapshot
scd_df = spark.table("fox_bi_prod.bronze_ads.freewheel_site_section_id_name_history").filter("is_current = TRUE")

# Step 3: Identify changed records
changed_df = source_changes_df.alias("src").join(
    scd_df.alias("tgt"),
    on="site_section_key_hash"
).filter(
    (col("src.site_section_name") != col("tgt.site_section_name")) &
    (col("tgt.is_current") == True)
).select("src.*").cache()

changed_count = changed_df.count()
print(f"🔁 Changed records (to expire + insert new version): {changed_count}")
if changed_count > 0:
    display(changed_df)

# Step 4: Identify new records
new_df = source_changes_df.alias("src").join(
    scd_df.alias("tgt"),
    on="site_section_key_hash",
    how="left_anti"
).select("src.*").cache()

new_count = new_df.count()
print(f"✨ New records to insert: {new_count}")


# Step 5: Expire existing (UPDATE is_current = FALSE)
changed_df.createOrReplaceTempView("changed_records_snapshot")
spark.sql("""
MERGE INTO fox_bi_prod.bronze_ads.freewheel_site_section_id_name_history AS tgt
USING changed_records_snapshot AS src
ON tgt.site_section_key_hash = src.site_section_key_hash AND tgt.is_current = TRUE
WHEN MATCHED THEN UPDATE SET
  is_current = FALSE,
  effective_end_timestamp_utc = CURRENT_TIMESTAMP() - INTERVAL 1 second,
  etl_updated_at_timestamp_utc = CURRENT_TIMESTAMP()
""")

# Step 6: Prepare new versions to insert
final_inserts_df = (
    changed_df.unionByName(new_df)
    .withColumn("effective_start_timestamp_utc", current_timestamp())
    .withColumn("effective_end_timestamp_utc", lit("9999-12-31 23:59:59").cast("timestamp"))
    .withColumn("is_current", lit(True))
    .withColumn("network_group_id", col("network_group_id").cast("bigint"))
)

# Step 7: Reorder columns to match target table
final_inserts_df = final_inserts_df.select(
    "authority_code",
    "network_group_id",
    "site_section_id",
    "site_section_name",
    "site_section_key_hash",
    "effective_start_timestamp_utc",
    "effective_end_timestamp_utc",
    "is_current",
    "etl_created_at_timestamp_utc",
    "etl_updated_at_timestamp_utc"
)

# Step 8: Write to the target table
final_inserts_count = final_inserts_df.count()
print(f"✅ Final rows to insert into SCD table: {final_inserts_count}")

final_inserts_df.write.mode("append").saveAsTable("fox_bi_prod.bronze_ads.freewheel_site_section_id_name_history")

# COMMAND ----------

#UPDATE CONTROL TABLE
version_update_df = spark.createDataFrame([
    ("freewheel_s3_companion_site_section_500763_fox_affiliates", freewheel_ss_500763_to_version)
    # ("freewheel_s3_companion_site_section_516429_fox_corp", freewheel_ss_516429_to_version),
], ["table_name", "last_processed_version"]).withColumn("updated_at", current_timestamp())

version_update_df.createOrReplaceTempView("version_updates")

spark.sql("""
MERGE INTO fox_bi_prod.bronze_ads.scd_version_tracker AS tgt
USING version_updates AS src
ON tgt.table_name = src.table_name

WHEN MATCHED THEN UPDATE SET
  tgt.last_processed_version = src.last_processed_version,
  tgt.updated_at = src.updated_at

WHEN NOT MATCHED THEN INSERT (
  table_name,
  last_processed_version,
  updated_at
)
VALUES (
  src.table_name,
  src.last_processed_version,
  src.updated_at
)
""")

# COMMAND ----------

# MAGIC %md
# MAGIC DIM_VIDEO_SERIES

# COMMAND ----------

from pyspark.sql.functions import col, lit, coalesce, max as spark_max, current_timestamp

# Step 1: Get max WRITE versions
history_vs_500763 = spark.sql("DESCRIBE HISTORY fox_bi_prod.raw_ads.freewheel_s3_companion_video_series_group_500763_fox_affiliates") \
    .filter(col("operation") == "STREAMING UPDATE") \
    .select(spark_max("version").alias("max_version")) \
    .withColumn("table_name", lit("freewheel_s3_companion_video_series_group_500763_fox_affiliates"))


# history_vs_516429 = spark.sql("DESCRIBE HISTORY fox_bi_prod.raw_ads.freewheel_s3_companion_video_series_group_516429_fox_corp") \
#     .filter(col("operation") == "STREAMING UPDATE") \
#     .select(spark_max("version").alias("max_version")) \
#     .withColumn("table_name", lit("freewheel_s3_companion_video_series_group_516429_fox_corp"))




current_versions = history_vs_500763 #.union(history_vs_516429)
control_versions = spark.table("fox_bi_prod.bronze_ads.scd_version_tracker")

# Step 2: Combine with control table
version_info = current_versions.alias("v").join(
    control_versions.alias("c"),
    col("v.table_name") == col("c.table_name"),
    how="left"
).select(
    col("v.table_name"),
    coalesce(col("c.last_processed_version"), col("v.max_version")).alias("from_version"),
    col("v.max_version").alias("to_version")
)

# Step 3: Extract as Python vars
rows = version_info.collect()
version_map = {row["table_name"]: {"from": row["from_version"], "to": row["to_version"]} for row in rows}

print(version_map)

freewheel_vs_500763_from_version = version_map["freewheel_s3_companion_video_series_group_500763_fox_affiliates"]["from"]
freewheel_vs_500763_to_version = version_map["freewheel_s3_companion_video_series_group_500763_fox_affiliates"]["to"]

# freewheel_vs_516429_from_version = version_map["freewheel_s3_companion_video_series_group_516429_fox_corp"]["from"]
# freewheel_vs_516429_to_version = version_map["freewheel_s3_companion_video_series_group_516429_fox_corp"]["to"]


print("freewheel_vs_500763:", freewheel_vs_500763_from_version, "→", freewheel_vs_500763_to_version)
# print("freewheel_vs_516429:", freewheel_vs_516429_from_version, "→", freewheel_vs_516429_to_version)

# COMMAND ----------

# FREEWHEEL changes
cdc_freewheel_vs_500763 = spark.sql(f"""
  SELECT * FROM table_changes('fox_bi_prod.raw_ads.freewheel_s3_companion_video_series_group_500763_fox_affiliates', {freewheel_vs_500763_from_version}, {freewheel_vs_500763_to_version})
  WHERE _change_type = 'insert'
""")
cdc_freewheel_vs_500763.createOrReplaceTempView("cdc_freewheel_vs_500763")


# cdc_freewheel_vs_516429 = spark.sql(f"""
#   SELECT * FROM table_changes('fox_bi_prod.raw_ads.freewheel_s3_companion_video_series_group_516429_fox_corp', {freewheel_vs_516429_from_version}, {freewheel_vs_516429_to_version})
#   WHERE _change_type = 'insert'
# """)
# cdc_freewheel_vs_516429.createOrReplaceTempView("cdc_freewheel_vs_516429")

# COMMAND ----------

# MAGIC %sql
# MAGIC -- STEP 1: Source changes (deduped)
# MAGIC CREATE OR REPLACE TEMP VIEW source_changes AS
# MAGIC SELECT
# MAGIC     'freewheel' AS authority_code,
# MAGIC     500763 AS network_group_id,
# MAGIC     CAST(COALESCE(id,'-1') AS LONG) AS series_id,
# MAGIC     COALESCE(name,'N/A') AS series_name,
# MAGIC     xxhash64(concat_ws('||', COALESCE(id,'-1'), cast(500763 AS string))) AS series_key_hash,
# MAGIC     CURRENT_TIMESTAMP() AS etl_created_at_timestamp_utc,
# MAGIC     CURRENT_TIMESTAMP() AS etl_updated_at_timestamp_utc
# MAGIC FROM cdc_freewheel_vs_500763
# MAGIC QUALIFY ROW_NUMBER() OVER (PARTITION BY id ORDER BY updated_at DESC) = 1
# MAGIC
# MAGIC -- UNION ALL
# MAGIC
# MAGIC -- SELECT
# MAGIC --     'freewheel' AS authority_code,
# MAGIC --     516429 AS network_group_id,
# MAGIC --     CAST(COALESCE(id,'-1') AS LONG) AS series_id,
# MAGIC --     COALESCE(name,'N/A') AS series_name,
# MAGIC --     xxhash64(concat_ws('||', COALESCE(id,'-1'), cast(516429 AS string))) AS series_key_hash,
# MAGIC --     CURRENT_TIMESTAMP() AS etl_created_at_timestamp_utc,
# MAGIC --     CURRENT_TIMESTAMP() AS etl_updated_at_timestamp_utc
# MAGIC -- FROM cdc_freewheel_vs_516429
# MAGIC -- QUALIFY ROW_NUMBER() OVER (PARTITION BY id ORDER BY updated_at DESC) = 1
# MAGIC ;

# COMMAND ----------

from pyspark.sql.functions import col, lit, current_timestamp

# Step 1: Load source_changes
source_changes_df = spark.table("source_changes")

# Step 2: Load current SCD snapshot
scd_df = spark.table("fox_bi_prod.bronze_ads.freewheel_video_series_id_name_history").filter("is_current = TRUE")

# Step 3: Identify changed records
changed_df = source_changes_df.alias("src").join(
    scd_df.alias("tgt"),
    on="series_key_hash"
).filter(
    (col("src.series_name") != col("tgt.series_name")) &
    (col("tgt.is_current") == True)
).select("src.*").cache()

changed_count = changed_df.count()
print(f"🔁 Changed records (to expire + insert new version): {changed_count}")
if changed_count > 0:
    display(changed_df)

# Step 4: Identify new records
new_df = source_changes_df.alias("src").join(
    scd_df.alias("tgt"),
    on="series_key_hash",
    how="left_anti"
).select("src.*").cache()

new_count = new_df.count()
print(f"✨ New records to insert: {new_count}")


# Step 5: Expire existing (UPDATE is_current = FALSE)
changed_df.createOrReplaceTempView("changed_records_snapshot")
spark.sql("""
MERGE INTO fox_bi_prod.bronze_ads.freewheel_video_series_id_name_history AS tgt
USING changed_records_snapshot AS src
ON tgt.series_key_hash = src.series_key_hash AND tgt.is_current = TRUE
WHEN MATCHED THEN UPDATE SET
  is_current = FALSE,
  effective_end_timestamp_utc = CURRENT_TIMESTAMP() - INTERVAL 1 second,
  etl_updated_at_timestamp_utc = CURRENT_TIMESTAMP()
""")

# Step 6: Prepare new versions to insert
final_inserts_df = (
    changed_df.unionByName(new_df)
    .withColumn("effective_start_timestamp_utc", current_timestamp())
    .withColumn("effective_end_timestamp_utc", lit("9999-12-31 23:59:59").cast("timestamp"))
    .withColumn("is_current", lit(True))
    .withColumn("network_group_id", col("network_group_id").cast("bigint"))
)

# Step 7: Reorder columns to match target table
final_inserts_df = final_inserts_df.select(
    "authority_code",
    "network_group_id",
    "series_id",
    "series_name",
    "series_key_hash",
    "effective_start_timestamp_utc",
    "effective_end_timestamp_utc",
    "is_current",
    "etl_created_at_timestamp_utc",
    "etl_updated_at_timestamp_utc"
)

# Step 8: Write to the target table
final_inserts_count = final_inserts_df.count()
print(f"✅ Final rows to insert into SCD table: {final_inserts_count}")

final_inserts_df.write.mode("append").saveAsTable("fox_bi_prod.bronze_ads.freewheel_video_series_id_name_history")

# COMMAND ----------

#UPDATE CONTROL TABLE
version_update_df = spark.createDataFrame([
    ("freewheel_s3_companion_video_series_group_500763_fox_affiliates", freewheel_vs_500763_to_version)
    # ("freewheel_s3_companion_video_series_group_516429_fox_corp", freewheel_vs_516429_to_version),
], ["table_name", "last_processed_version"]).withColumn("updated_at", current_timestamp())

version_update_df.createOrReplaceTempView("version_updates")

spark.sql("""
MERGE INTO fox_bi_prod.bronze_ads.scd_version_tracker AS tgt
USING version_updates AS src
ON tgt.table_name = src.table_name

WHEN MATCHED THEN UPDATE SET
  tgt.last_processed_version = src.last_processed_version,
  tgt.updated_at = src.updated_at

WHEN NOT MATCHED THEN INSERT (
  table_name,
  last_processed_version,
  updated_at
)
VALUES (
  src.table_name,
  src.last_processed_version,
  src.updated_at
)
""")

# COMMAND ----------

# MAGIC %md
# MAGIC DIM_MRM_RULE

# COMMAND ----------

from pyspark.sql.functions import col, lit, coalesce, max as spark_max, current_timestamp

# Step 1: Get max WRITE versions
history_mrm_500763 = spark.sql("DESCRIBE HISTORY fox_bi_prod.raw_ads.freewheel_s3_companion_mrm_500763_fox_affiliates") \
    .filter(col("operation") == "STREAMING UPDATE") \
    .select(spark_max("version").alias("max_version")) \
    .withColumn("table_name", lit("freewheel_s3_companion_mrm_500763_fox_affiliates"))


# history_mrm_516429 = spark.sql("DESCRIBE HISTORY fox_bi_prod.raw_ads.freewheel_s3_companion_mrm_516429_fox_corp") \
#     .filter(col("operation") == "STREAMING UPDATE") \
#     .select(spark_max("version").alias("max_version")) \
#     .withColumn("table_name", lit("freewheel_s3_companion_mrm_516429_fox_corp"))




current_versions = history_mrm_500763 #.union(history_mrm_516429)
control_versions = spark.table("fox_bi_prod.bronze_ads.scd_version_tracker")

# Step 2: Combine with control table
version_info = current_versions.alias("v").join(
    control_versions.alias("c"),
    col("v.table_name") == col("c.table_name"),
    how="left"
).select(
    col("v.table_name"),
    coalesce(col("c.last_processed_version"), col("v.max_version")).alias("from_version"),
    col("v.max_version").alias("to_version")
)

# Step 3: Extract as Python vars
rows = version_info.collect()
version_map = {row["table_name"]: {"from": row["from_version"], "to": row["to_version"]} for row in rows}

print(version_map)

freewheel_mrm_500763_from_version = version_map["freewheel_s3_companion_mrm_500763_fox_affiliates"]["from"]
freewheel_mrm_500763_to_version = version_map["freewheel_s3_companion_mrm_500763_fox_affiliates"]["to"]

# freewheel_mrm_516429_from_version = version_map["freewheel_s3_companion_mrm_516429_fox_corp"]["from"]
# freewheel_mrm_516429_to_version = version_map["freewheel_s3_companion_mrm_516429_fox_corp"]["to"]


print("freewheel_mrm_500763:", freewheel_mrm_500763_from_version, "→", freewheel_mrm_500763_to_version)
# print("freewheel_mrm_516429:", freewheel_mrm_516429_from_version, "→", freewheel_mrm_516429_to_version)

# COMMAND ----------

# FREEWHEEL changes
cdc_freewheel_mrm_500763 = spark.sql(f"""
  SELECT * FROM table_changes('fox_bi_prod.raw_ads.freewheel_s3_companion_mrm_500763_fox_affiliates', {freewheel_mrm_500763_from_version}, {freewheel_mrm_500763_to_version})
  WHERE _change_type = 'insert'
""")
cdc_freewheel_mrm_500763.createOrReplaceTempView("cdc_freewheel_mrm_500763")


# cdc_freewheel_mrm_516429 = spark.sql(f"""
#   SELECT * FROM table_changes('fox_bi_prod.raw_ads.freewheel_s3_companion_mrm_516429_fox_corp', {freewheel_mrm_516429_from_version}, {freewheel_mrm_516429_to_version})
#   WHERE _change_type = 'insert'
# """)
# cdc_freewheel_mrm_516429.createOrReplaceTempView("cdc_freewheel_mrm_516429")

# COMMAND ----------

# MAGIC %sql
# MAGIC -- STEP 1: Source changes (deduped)
# MAGIC CREATE OR REPLACE TEMP VIEW source_changes AS
# MAGIC SELECT
# MAGIC     'freewheel' AS authority_code,
# MAGIC     500763 AS network_group_id,
# MAGIC     CAST(COALESCE(id,'-1') AS LONG) AS mrm_rule_id,
# MAGIC     COALESCE(name,'N/A') AS mrm_rule_name,
# MAGIC     xxhash64(concat_ws('||', COALESCE(id,'-1'), cast(500763 AS string))) AS mrm_key_hash,
# MAGIC     CURRENT_TIMESTAMP() AS etl_created_at_timestamp_utc,
# MAGIC     CURRENT_TIMESTAMP() AS etl_updated_at_timestamp_utc
# MAGIC FROM cdc_freewheel_mrm_500763
# MAGIC QUALIFY ROW_NUMBER() OVER (PARTITION BY id ORDER BY updated_at DESC) = 1
# MAGIC
# MAGIC -- UNION ALL
# MAGIC
# MAGIC -- SELECT
# MAGIC --     'freewheel' AS authority_code,
# MAGIC --     516429 AS network_group_id,
# MAGIC --     CAST(COALESCE(id,'-1') AS LONG) AS mrm_rule_id,
# MAGIC --     COALESCE(name,'N/A') AS mrm_rule_name,
# MAGIC --     xxhash64(concat_ws('||', COALESCE(id,'-1'), cast(516429 AS string))) AS mrm_key_hash,
# MAGIC --     CURRENT_TIMESTAMP() AS etl_created_at_timestamp_utc,
# MAGIC --     CURRENT_TIMESTAMP() AS etl_updated_at_timestamp_utc
# MAGIC -- FROM cdc_freewheel_mrm_516429
# MAGIC -- QUALIFY ROW_NUMBER() OVER (PARTITION BY id ORDER BY updated_at DESC) = 1
# MAGIC ;

# COMMAND ----------

from pyspark.sql.functions import col, lit, current_timestamp

# Step 1: Load source_changes
source_changes_df = spark.table("source_changes")

# Step 2: Load current SCD snapshot
scd_df = spark.table("fox_bi_prod.bronze_ads.freewheel_mrm_id_name_history").filter("is_current = TRUE")

# Step 3: Identify changed records
changed_df = source_changes_df.alias("src").join(
    scd_df.alias("tgt"),
    on="mrm_key_hash"
).filter(
    (col("src.mrm_rule_name") != col("tgt.mrm_rule_name")) &
    (col("tgt.is_current") == True)
).select("src.*").cache()

changed_count = changed_df.count()
print(f"🔁 Changed records (to expire + insert new version): {changed_count}")
if changed_count > 0:
    display(changed_df)

# Step 4: Identify new records
new_df = source_changes_df.alias("src").join(
    scd_df.alias("tgt"),
    on="mrm_key_hash",
    how="left_anti"
).select("src.*").cache()

new_count = new_df.count()
print(f"✨ New records to insert: {new_count}")


# Step 5: Expire existing (UPDATE is_current = FALSE)
changed_df.createOrReplaceTempView("changed_records_snapshot")
spark.sql("""
MERGE INTO fox_bi_prod.bronze_ads.freewheel_mrm_id_name_history AS tgt
USING changed_records_snapshot AS src
ON tgt.mrm_key_hash = src.mrm_key_hash AND tgt.is_current = TRUE
WHEN MATCHED THEN UPDATE SET
  is_current = FALSE,
  effective_end_timestamp_utc = CURRENT_TIMESTAMP() - INTERVAL 1 second,
  etl_updated_at_timestamp_utc = CURRENT_TIMESTAMP()
""")

# Step 6: Prepare new versions to insert
final_inserts_df = (
    changed_df.unionByName(new_df)
    .withColumn("effective_start_timestamp_utc", current_timestamp())
    .withColumn("effective_end_timestamp_utc", lit("9999-12-31 23:59:59").cast("timestamp"))
    .withColumn("is_current", lit(True))
    .withColumn("network_group_id", col("network_group_id").cast("bigint"))
)

# Step 7: Reorder columns to match target table
final_inserts_df = final_inserts_df.select(
    "authority_code",
    "network_group_id",
    "mrm_rule_id",
    "mrm_rule_name",
    "mrm_key_hash",
    "effective_start_timestamp_utc",
    "effective_end_timestamp_utc",
    "is_current",
    "etl_created_at_timestamp_utc",
    "etl_updated_at_timestamp_utc"
)

# Step 8: Write to the target table
final_inserts_count = final_inserts_df.count()
print(f"✅ Final rows to insert into SCD table: {final_inserts_count}")

final_inserts_df.write.mode("append").saveAsTable("fox_bi_prod.bronze_ads.freewheel_mrm_id_name_history")

# COMMAND ----------

#UPDATE CONTROL TABLE
version_update_df = spark.createDataFrame([
    ("freewheel_s3_companion_mrm_500763_fox_affiliates", freewheel_mrm_500763_to_version)
    # ("freewheel_s3_companion_mrm_516429_fox_corp", freewheel_mrm_516429_to_version),
], ["table_name", "last_processed_version"]).withColumn("updated_at", current_timestamp())

version_update_df.createOrReplaceTempView("version_updates")

spark.sql("""
MERGE INTO fox_bi_prod.bronze_ads.scd_version_tracker AS tgt
USING version_updates AS src
ON tgt.table_name = src.table_name

WHEN MATCHED THEN UPDATE SET
  tgt.last_processed_version = src.last_processed_version,
  tgt.updated_at = src.updated_at

WHEN NOT MATCHED THEN INSERT (
  table_name,
  last_processed_version,
  updated_at
)
VALUES (
  src.table_name,
  src.last_processed_version,
  src.updated_at
)
""")