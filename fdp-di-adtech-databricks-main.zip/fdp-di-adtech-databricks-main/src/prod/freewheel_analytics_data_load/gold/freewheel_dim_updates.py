# Databricks notebook source
check_updates_capacity_series_query = """
    SELECT 1
    FROM fox_bi_prod.gold_ad_sales.ft_freewheel_capacity_summary_daily AS tgt
    INNER JOIN (
        SELECT DISTINCT
            series_ID
            , series_name
            , show_name
        FROM fox_bi_prod.silver_ads.ft_freewheel_capacity_summary_daily_data
    ) AS src
    ON tgt.series_ID = src.series_ID
    WHERE COALESCE(src.series_name, 'NA') != COALESCE(tgt.series_name, 'NA')
    OR COALESCE(src.show_name, 'NA') != COALESCE(tgt.show_name, 'NA')
    LIMIT 1
"""

update_series_capacity_query = """
    MERGE INTO fox_bi_prod.gold_ad_sales.ft_freewheel_capacity_summary_daily AS tgt
    USING (
        SELECT DISTINCT
            series_ID
            , series_name
            , show_name
        FROM fox_bi_prod.silver_ads.ft_freewheel_capacity_summary_daily_data
    ) AS src
    ON tgt.series_ID = src.series_ID
    WHEN MATCHED AND (
        COALESCE(src.series_name, 'NA') != COALESCE(tgt.series_name, 'NA')
        OR COALESCE(src.show_name, 'NA') != COALESCE(tgt.show_name, 'NA')
    )
    THEN UPDATE SET
        tgt.series_name = src.series_name
        , tgt.show_name = src.show_name
"""

# COMMAND ----------

check_updates_delivery_series_query = """
    SELECT 1
    FROM fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily AS tgt
    INNER JOIN (
        SELECT DISTINCT
            series_ID
            , series_name
            , show_name
        FROM fox_bi_prod.silver_ads.ft_freewheel_delivery_daily_data
    ) AS src
    ON tgt.series_ID = src.series_ID
    WHERE COALESCE(src.series_name, 'NA') != COALESCE(tgt.series_name, 'NA')
    OR COALESCE(src.show_name, 'NA') != COALESCE(tgt.show_name, 'NA')
    LIMIT 1
"""

update_series_delivery_query = """
    MERGE INTO fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily AS tgt
    USING (
        SELECT DISTINCT
            series_ID
            , series_name
            , show_name
        FROM fox_bi_prod.silver_ads.ft_freewheel_delivery_daily_data
    ) AS src
    ON tgt.series_ID = src.series_ID
    WHEN MATCHED AND (
        COALESCE(src.series_name, 'NA') != COALESCE(tgt.series_name, 'NA')
        OR COALESCE(src.show_name, 'NA') != COALESCE(tgt.show_name, 'NA')
    )
    THEN UPDATE SET
        tgt.series_name = src.series_name
        , tgt.show_name = src.show_name
"""

# COMMAND ----------

check_updates_matched_audience_series_query = """
    SELECT 1
    FROM fox_bi_prod.gold_ad_sales.ft_freewheel_matched_audience_daily AS tgt
    INNER JOIN (
        SELECT DISTINCT
            series_ID
            , series_name
            , show_name
        FROM fox_bi_prod.silver_ads.ft_freewheel_matched_audience_delivery_daily_data
    ) AS src
    ON tgt.series_ID = src.series_ID
    WHERE COALESCE(src.series_name, 'NA') != COALESCE(tgt.series_name, 'NA')
    OR COALESCE(src.show_name, 'NA') != COALESCE(tgt.show_name, 'NA')
    LIMIT 1
"""

update_series_matched_audience_query = """
    MERGE INTO fox_bi_prod.gold_ad_sales.ft_freewheel_matched_audience_daily AS tgt
    USING (
        SELECT DISTINCT
            series_ID
            , series_name
            , show_name
        FROM fox_bi_prod.silver_ads.ft_freewheel_matched_audience_delivery_daily_data
    ) AS src
    ON tgt.series_ID = src.series_ID
    WHEN MATCHED AND (
        COALESCE(src.series_name, 'NA') != COALESCE(tgt.series_name, 'NA')
        OR COALESCE(src.show_name, 'NA') != COALESCE(tgt.show_name, 'NA')
    )
    THEN UPDATE SET
        tgt.series_name = src.series_name
        , tgt.show_name = src.show_name
"""

# COMMAND ----------

check_updates_campaign_delivery_query = """
    SELECT 1
    FROM fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily AS tgt
    INNER JOIN (
        SELECT DISTINCT
            Campaign_Id
            , Campaign_Name
            , Campaign_External_Id
            , campaign_start_timestamp_est
            , campaign_end_timestamp_est
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_campaign
        WHERE etl_updated_at_timestamp_utc >= CURRENT_DATE() - 7
    ) AS src
    ON tgt.Campaign_Id = src.Campaign_Id
    WHERE COALESCE(src.Campaign_Name, 'NA') != COALESCE(tgt.Campaign_Name, 'NA')
    OR COALESCE(src.Campaign_External_Id, 'NA') != COALESCE(tgt.Campaign_External_Id, 'NA')
    OR COALESCE(src.campaign_start_timestamp_est, 'NA') != COALESCE(tgt.campaign_start_timestamp_est, 'NA')
    OR COALESCE(src.campaign_end_timestamp_est, 'NA') != COALESCE(tgt.campaign_end_timestamp_est, 'NA')
    LIMIT 1
"""

update_campaign_delivery_query = """
    MERGE INTO fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily AS tgt
    USING (
        SELECT DISTINCT 
            Campaign_Id
            , Campaign_Name
            , Campaign_External_Id
            , campaign_start_timestamp_est
            , campaign_end_timestamp_est
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_campaign
        WHERE etl_updated_at_timestamp_utc >= current_date() - 7
    ) AS src
    ON tgt.Campaign_Id = src.Campaign_Id
    WHEN MATCHED AND (
        COALESCE(src.Campaign_Name, 'NA') != COALESCE(tgt.Campaign_Name, 'NA')
        OR COALESCE(src.Campaign_External_Id, 'NA') != COALESCE(tgt.Campaign_External_Id, 'NA')
        OR COALESCE(src.campaign_start_timestamp_est, 'NA') != COALESCE(tgt.campaign_start_timestamp_est, 'NA')
        OR COALESCE(src.campaign_end_timestamp_est, 'NA') != COALESCE(tgt.campaign_end_timestamp_est, 'NA')
    ) 
    THEN UPDATE SET
        tgt.Campaign_Name = src.Campaign_Name
        , tgt.Campaign_External_Id = src.Campaign_External_Id
        , tgt.campaign_start_timestamp_est = src.campaign_start_timestamp_est
        , tgt.campaign_end_timestamp_est = src.campaign_end_timestamp_est
"""

# COMMAND ----------

check_updates_placement_delivery_query = """
    SELECT 1
    FROM fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily AS tgt
    INNER JOIN (
        SELECT DISTINCT 
            Placement_ID
            , Placement_External_ID
            , Placement_Name
            , Placement_Budgeted_Impressions
            , placement_start_timestamp_est
            , placement_end_timestamp_est
            , Placement_Industry
            , Placement_Status
            , Placement_Type
            , Unified_Yield_Name
            , placement_booked_on_target_impression_goal AS Booked_On_Target_Impression_Goal
            , placement_budget_model AS Budget_Model
            , placement_demographic_on_target_calculation AS Demographic_On_Target_Calculation
            , placement_demographic_data_source AS Demographic_Data_Source
            , placement_forced_over_delivery_percent AS Forced_Over_Delivery_Percent
            , placement_impression_goal AS Impression_Goal
            , placement_pacing AS Delivery_Pacing
            , placement_priority AS delivery_priority
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_placement
        WHERE etl_updated_at_timestamp_utc >= CURRENT_DATE() - 7
    ) AS src
    ON tgt.placement_id = src.placement_id
    WHERE COALESCE(src.Placement_External_ID, 'NA') != COALESCE(tgt.Placement_External_ID, 'NA')
    OR COALESCE(src.Placement_Name, 'NA') != COALESCE(tgt.Placement_Name, 'NA')
    OR COALESCE(src.Placement_Budgeted_Impressions, 'NA') != COALESCE(tgt.Placement_Budgeted_Impressions, 'NA')
    OR COALESCE(src.placement_start_timestamp_est, 'NA') != COALESCE(tgt.placement_start_timestamp_est, 'NA')
    OR COALESCE(src.placement_end_timestamp_est, 'NA') != COALESCE(tgt.placement_end_timestamp_est, 'NA')
    OR COALESCE(src.Placement_Industry, 'NA') != COALESCE(tgt.Placement_Industry, 'NA')
    OR COALESCE(src.Placement_Status, 'NA') != COALESCE(tgt.Placement_Status, 'NA')
    OR COALESCE(src.Placement_Type, 'NA') != COALESCE(tgt.Placement_Type, 'NA')
    OR COALESCE(src.Unified_Yield_Name, 'NA') != COALESCE(tgt.Unified_Yield_Name, 'NA')
    OR COALESCE(src.Booked_On_Target_Impression_Goal, 'NA') != COALESCE(tgt.Booked_On_Target_Impression_Goal, 'NA')
    OR COALESCE(src.Budget_Model, 'NA') != COALESCE(tgt.Budget_Model, 'NA')
    OR COALESCE(src.Demographic_On_Target_Calculation, 'NA') != COALESCE(tgt.Demographic_On_Target_Calculation, 'NA')
    OR COALESCE(src.Demographic_Data_Source, 'NA') != COALESCE(tgt.Demographic_Data_Source, 'NA')
    OR COALESCE(src.Forced_Over_Delivery_Percent, 'NA') != COALESCE(tgt.Forced_Over_Delivery_Percent, 'NA')
    OR COALESCE(src.Impression_Goal, 'NA') != COALESCE(tgt.Impression_Goal, 'NA')
    OR COALESCE(src.Delivery_Pacing, 'NA') != COALESCE(tgt.Delivery_Pacing, 'NA')
    OR COALESCE(src.delivery_priority, 'NA') != COALESCE(tgt.delivery_priority, 'NA')
    LIMIT 1
"""

update_placement_delivery_query = """
    MERGE INTO fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily AS tgt
    USING (
    SELECT DISTINCT 
        Placement_ID
        , Placement_External_ID
        , Placement_Name
        , Placement_Budgeted_Impressions
        , placement_start_timestamp_est
        , placement_end_timestamp_est
        , Placement_Industry
        , Placement_Status
        , Placement_Type
        , Unified_Yield_Name
        , placement_booked_on_target_impression_goal AS Booked_On_Target_Impression_Goal
        , placement_budget_model AS Budget_Model
        , placement_demographic_on_target_calculation AS Demographic_On_Target_Calculation
        , placement_demographic_data_source AS Demographic_Data_Source
        , placement_forced_over_delivery_percent AS Forced_Over_Delivery_Percent
        , placement_impression_goal AS Impression_Goal
        , placement_pacing AS Delivery_Pacing
        , placement_priority AS delivery_priority
    FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_placement
    WHERE etl_updated_at_timestamp_utc >= current_date() - 7
    ) AS src
    ON tgt.placement_id = src.placement_id
    WHEN MATCHED AND (
        COALESCE(src.Placement_External_ID, 'NA') != COALESCE(tgt.Placement_External_ID, 'NA')
        OR COALESCE(src.Placement_Name, 'NA') != COALESCE(tgt.Placement_Name, 'NA')
        OR COALESCE(src.Placement_Budgeted_Impressions, 'NA') != COALESCE(tgt.Placement_Budgeted_Impressions, 'NA')
        OR COALESCE(src.placement_start_timestamp_est, 'NA') != COALESCE(tgt.placement_start_timestamp_est, 'NA')
        OR COALESCE(src.placement_end_timestamp_est, 'NA') != COALESCE(tgt.placement_end_timestamp_est, 'NA')
        OR COALESCE(src.Placement_Industry, 'NA') != COALESCE(tgt.Placement_Industry, 'NA')
        OR COALESCE(src.Placement_Status, 'NA') != COALESCE(tgt.Placement_Status, 'NA')
        OR COALESCE(src.Placement_Type, 'NA') != COALESCE(tgt.Placement_Type, 'NA')
        OR COALESCE(src.Unified_Yield_Name, 'NA') != COALESCE(tgt.Unified_Yield_Name, 'NA')
        OR COALESCE(src.Booked_On_Target_Impression_Goal, 'NA') != COALESCE(tgt.Booked_On_Target_Impression_Goal, 'NA')
        OR COALESCE(src.Budget_Model, 'NA') != COALESCE(tgt.Budget_Model, 'NA')
        OR COALESCE(src.Demographic_On_Target_Calculation, 'NA') != COALESCE(tgt.Demographic_On_Target_Calculation, 'NA')
        OR COALESCE(src.Demographic_Data_Source, 'NA') != COALESCE(tgt.Demographic_Data_Source, 'NA')
        OR COALESCE(src.Forced_Over_Delivery_Percent, 'NA') != COALESCE(tgt.Forced_Over_Delivery_Percent, 'NA')
        OR COALESCE(src.Impression_Goal, 'NA') != COALESCE(tgt.Impression_Goal, 'NA')
        OR COALESCE(src.Delivery_Pacing, 'NA') != COALESCE(tgt.Delivery_Pacing, 'NA')
        OR COALESCE(src.delivery_priority, 'NA') != COALESCE(tgt.delivery_priority, 'NA')
    ) 
    THEN UPDATE SET
        tgt.Placement_External_ID = src.Placement_External_ID
        , tgt.Placement_Name = src.Placement_Name
        , tgt.Placement_Budgeted_Impressions = src.Placement_Budgeted_Impressions
        , tgt.placement_start_timestamp_est = src.placement_start_timestamp_est
        , tgt.placement_end_timestamp_est = src.placement_end_timestamp_est
        , tgt.Placement_Industry = src.Placement_Industry
        , tgt.Placement_Status = src.Placement_Status
        , tgt.Placement_Type = src.Placement_Type
        , tgt.Unified_Yield_Name = src.Unified_Yield_Name
        , tgt.Booked_On_Target_Impression_Goal = src.Booked_On_Target_Impression_Goal
        , tgt.Budget_Model = src.Budget_Model
        , tgt.Demographic_On_Target_Calculation = src.Demographic_On_Target_Calculation
        , tgt.Demographic_Data_Source = src.Demographic_Data_Source
        , tgt.Forced_Over_Delivery_Percent = src.Forced_Over_Delivery_Percent
        , tgt.Impression_Goal = src.Impression_Goal
        , tgt.Delivery_Pacing = src.Delivery_Pacing
        , tgt.delivery_priority = src.delivery_priority
"""

# COMMAND ----------

check_updates_mrm_rule_delivery_query = """
    SELECT 1
    FROM fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily AS tgt
    INNER JOIN (
        SELECT DISTINCT 
            MRM_Rule_ID
            , MRM_Rule_Name
            , mrm_rule_impression_goal
            , mrm_rule_start_timestamp_est
            , mrm_rule_end_timestamp_est
            , Priority_Setting
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_mrm_rule
        WHERE etl_updated_at_timestamp_utc >= CURRENT_DATE() - 7
    ) AS src
    ON tgt.MRM_Rule_ID = src.MRM_Rule_ID
    WHERE COALESCE(src.MRM_Rule_Name, 'NA') != COALESCE(tgt.MRM_Rule_Name, 'NA')
    OR COALESCE(src.mrm_rule_impression_goal, 'NA') != COALESCE(tgt.mrm_rule_impression_goal, 'NA')
    OR COALESCE(src.mrm_rule_start_timestamp_est, 'NA') != COALESCE(tgt.mrm_rule_start_timestamp_est, 'NA')
    OR COALESCE(src.mrm_rule_end_timestamp_est, 'NA') != COALESCE(tgt.mrm_rule_end_timestamp_est, 'NA')
    OR COALESCE(src.Priority_Setting, 'NA') != COALESCE(tgt.Priority_Setting, 'NA')
    LIMIT 1
"""

update_mrm_rule_delivery_query = """
    MERGE INTO fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily AS tgt
    USING (
        SELECT DISTINCT 
            MRM_Rule_ID
            , MRM_Rule_Name
            , mrm_rule_impression_goal
            , mrm_rule_start_timestamp_est
            , mrm_rule_end_timestamp_est
            , Priority_Setting
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_mrm_rule
        WHERE etl_updated_at_timestamp_utc >= current_date() - 7
    ) AS src
    ON tgt.MRM_Rule_ID = src.MRM_Rule_ID
    WHEN MATCHED AND (
        COALESCE(src.MRM_Rule_Name, 'NA') != COALESCE(tgt.MRM_Rule_Name, 'NA')
        OR COALESCE(src.mrm_rule_impression_goal, 'NA') != COALESCE(tgt.mrm_rule_impression_goal, 'NA')
        OR COALESCE(src.mrm_rule_start_timestamp_est, 'NA') != COALESCE(tgt.mrm_rule_start_timestamp_est, 'NA')
        OR COALESCE(src.mrm_rule_end_timestamp_est, 'NA') != COALESCE(tgt.mrm_rule_end_timestamp_est, 'NA')
        OR COALESCE(src.Priority_Setting, 'NA') != COALESCE(tgt.Priority_Setting, 'NA')
    ) 
    THEN UPDATE SET
        tgt.MRM_Rule_Name = src.MRM_Rule_Name
        , tgt.mrm_rule_impression_goal = src.mrm_rule_impression_goal
        , tgt.mrm_rule_start_timestamp_est = src.mrm_rule_start_timestamp_est
        , tgt.mrm_rule_end_timestamp_est = src.mrm_rule_end_timestamp_est
        , tgt.Priority_Setting = src.Priority_Setting
"""

# COMMAND ----------

check_updates_sold_order_delivery_query = """
    SELECT 1
    FROM fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily AS tgt
    INNER JOIN (
        SELECT DISTINCT
            Sold_Order_ID
            , Sold_Order_Name
            , Sold_Order_Type
            , Sold_Order_Start_Timestamp_Est
            , Sold_Order_End_Timestamp_Est
            , Sold_Order_Pricing_Model
            , Sold_Order_Priority_Type
            , Sold_Order_Goal_Impressions
            , sold_order_cpm_usd
            , sold_order_avails_in_played_slot
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_sold_order
        WHERE etl_updated_at_timestamp_utc >= CURRENT_DATE() - 7
    ) AS src
    ON tgt.Sold_Order_ID = src.Sold_Order_ID
    WHERE COALESCE(src.Sold_Order_Name, 'NA') != COALESCE(tgt.Sold_Order_Name, 'NA')
    OR COALESCE(src.Sold_Order_Type, 'NA') != COALESCE(tgt.Sold_Order_Type, 'NA')
    OR COALESCE(src.Sold_Order_Start_Timestamp_Est,'1900-01-01') != COALESCE(tgt.Sold_Order_Start_Timestamp_Est,'1900-01-01')
    OR COALESCE(src.Sold_Order_End_Timestamp_Est,'1900-01-01') != COALESCE(tgt.Sold_Order_End_Timestamp_Est,'1900-01-01')
    OR COALESCE(src.Sold_Order_Pricing_Model, 'NA') != COALESCE(tgt.Sold_Order_Pricing_Model, 'NA')
    OR COALESCE(src.Sold_Order_Priority_Type, 'NA') != COALESCE(tgt.Sold_Order_Priority_Type, 'NA')
    OR COALESCE(src.Sold_Order_Goal_Impressions, 'NA') != COALESCE(tgt.Sold_Order_Goal_Impressions, 'NA')
    OR COALESCE(src.sold_order_cpm_usd, 'NA') != COALESCE(tgt.sold_order_cpm_usd, 'NA')
    OR COALESCE(src.sold_order_avails_in_played_slot, 'NA') != COALESCE(tgt.sold_order_avails_in_played_slot, 'NA')
    LIMIT 1
"""

update_sold_order_delivery_query = """
    MERGE INTO fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily AS tgt
    USING (
        SELECT DISTINCT
            Sold_Order_ID
            , Sold_Order_Name
            , Sold_Order_Type
            , Sold_Order_Start_Timestamp_Est
            , Sold_Order_End_Timestamp_Est
            , Sold_Order_Pricing_Model
            , Sold_Order_Priority_Type
            , Sold_Order_Goal_Impressions
            , sold_order_cpm_usd
            , sold_order_avails_in_played_slot
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_sold_order
        WHERE etl_updated_at_timestamp_utc >= current_date() - 7
    ) AS src
    ON tgt.Sold_Order_ID = src.Sold_Order_ID
    WHEN MATCHED AND (
        COALESCE(src.Sold_Order_Name, 'NA') != COALESCE(tgt.Sold_Order_Name, 'NA')
        OR COALESCE(src.Sold_Order_Type, 'NA') != COALESCE(tgt.Sold_Order_Type, 'NA')
        OR COALESCE(src.Sold_Order_Start_Timestamp_Est,'1900-01-01') != COALESCE(tgt.Sold_Order_Start_Timestamp_Est,'1900-01-01')
        OR COALESCE(src.Sold_Order_End_Timestamp_Est,'1900-01-01') != COALESCE(tgt.Sold_Order_End_Timestamp_Est,'1900-01-01')
        OR COALESCE(src.Sold_Order_Pricing_Model, 'NA') != COALESCE(tgt.Sold_Order_Pricing_Model, 'NA')
        OR COALESCE(src.Sold_Order_Priority_Type, 'NA') != COALESCE(tgt.Sold_Order_Priority_Type, 'NA')
        OR COALESCE(src.Sold_Order_Goal_Impressions, 'NA') != COALESCE(tgt.Sold_Order_Goal_Impressions, 'NA')
        OR COALESCE(src.sold_order_cpm_usd, 'NA') != COALESCE(tgt.sold_order_cpm_usd, 'NA')
        OR COALESCE(src.sold_order_avails_in_played_slot, 'NA') != COALESCE(tgt.sold_order_avails_in_played_slot, 'NA')
    )
    THEN UPDATE SET
        tgt.Sold_Order_Name = src.Sold_Order_Name
        , tgt.Sold_Order_Type = src.Sold_Order_Type
        , tgt.Sold_Order_Start_Timestamp_Est = src.Sold_Order_Start_Timestamp_Est
        , tgt.Sold_Order_End_Timestamp_Est = src.Sold_Order_End_Timestamp_Est
        , tgt.Sold_Order_Pricing_Model = src.Sold_Order_Pricing_Model
        , tgt.Sold_Order_Priority_Type = src.Sold_Order_Priority_Type
        , tgt.Sold_Order_Goal_Impressions = src.Sold_Order_Goal_Impressions
        , tgt.sold_order_cpm_usd = src.sold_order_cpm_usd
        , tgt.sold_order_avails_in_played_slot = src.sold_order_avails_in_played_slot
"""

# COMMAND ----------

check_updates_exchange_listing_delivery_query = """
    SELECT 1
    FROM fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily AS tgt
    INNER JOIN (
        SELECT DISTINCT
            exchange_listing_id
            , exchange_listing_name
            , exchange_listing_transaction_type
            , exchange_listing_priority
            , exchange_listing_start_timestamp_est
            , exchange_listing_end_timestamp_est
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_exchange_listing
        WHERE etl_updated_at_timestamp_utc >= CURRENT_DATE() - 7
    ) AS src
    ON tgt.exchange_listing_id = src.exchange_listing_id
    WHERE COALESCE(src.exchange_listing_name, 'NA') != COALESCE(tgt.exchange_listing_name, 'NA')
    OR COALESCE(src.exchange_listing_priority, 'NA') != COALESCE(tgt.exchange_listing_priority, 'NA')
    OR COALESCE(src.exchange_listing_transaction_type, 'NA') != COALESCE(tgt.exchange_listing_transaction_type, 'NA')
    OR COALESCE(src.exchange_listing_start_timestamp_est,'1900-01-01') != COALESCE(tgt.exchange_listing_start_timestamp_est,'1900-01-01')
    OR COALESCE(src.exchange_listing_end_timestamp_est,'1900-01-01') != COALESCE(tgt.exchange_listing_end_timestamp_est,'1900-01-01')
    LIMIT 1
"""

update_exchange_listing_delivery_query = """
    MERGE INTO fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily AS tgt
    USING (
    SELECT DISTINCT
        exchange_listing_id
        , exchange_listing_name
        , exchange_listing_transaction_type
        , exchange_listing_priority
        , exchange_listing_start_timestamp_est
        , exchange_listing_end_timestamp_est
    FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_exchange_listing
    WHERE etl_updated_at_timestamp_utc >= current_date() - 7
    ) AS src
    ON tgt.exchange_listing_id = src.exchange_listing_id
    WHEN MATCHED AND (
        COALESCE(src.exchange_listing_name, 'NA') != COALESCE(tgt.exchange_listing_name, 'NA')
        OR COALESCE(src.exchange_listing_priority, 'NA') != COALESCE(tgt.exchange_listing_priority, 'NA')
        OR COALESCE(src.exchange_listing_transaction_type, 'NA') != COALESCE(tgt.exchange_listing_transaction_type, 'NA')
        OR COALESCE(src.exchange_listing_start_timestamp_est,'1900-01-01') != COALESCE(tgt.exchange_listing_start_timestamp_est,'1900-01-01')
        OR COALESCE(src.exchange_listing_end_timestamp_est,'1900-01-01') != COALESCE(tgt.exchange_listing_end_timestamp_est,'1900-01-01')
    )
    THEN UPDATE SET
        tgt.exchange_listing_name = src.exchange_listing_name
        , tgt.exchange_listing_priority = src.exchange_listing_priority
        , tgt.exchange_listing_transaction_type = src.exchange_listing_transaction_type
        , tgt.exchange_listing_start_timestamp_est = src.exchange_listing_start_timestamp_est
        , tgt.exchange_listing_end_timestamp_est = src.exchange_listing_end_timestamp_est
"""

# COMMAND ----------

check_updates_deal_delivery_query = """
    SELECT 1
    FROM fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily AS tgt
    INNER JOIN (
        SELECT DISTINCT 
            Deal_ID
            , External_Deal_ID
            , Deal_Name
            , Deal_Type
            , deal_override_priority
            , Deal_Salesperson
            , deal_ad_units
            , Deal_Impression_Goal
            , deal_start_timestamp_est
            , deal_end_timestamp_est
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_deal
        WHERE etl_updated_at_timestamp_utc >= CURRENT_DATE() - 7
    ) AS src
    ON tgt.Deal_ID = src.Deal_ID
    WHERE COALESCE(src.External_Deal_ID, 'NA') != COALESCE(tgt.External_Deal_ID, 'NA')
    OR COALESCE(src.Deal_Name, 'NA') != COALESCE(tgt.Deal_Name, 'NA')
    OR COALESCE(src.Deal_Type, 'NA') != COALESCE(tgt.Deal_Type, 'NA')
    OR COALESCE(src.Deal_Salesperson, 'NA') != COALESCE(tgt.Deal_Salesperson, 'NA')
    OR COALESCE(src.Deal_Impression_Goal, 'NA') != COALESCE(tgt.Deal_Impression_Goal, 'NA')
    OR COALESCE(src.deal_start_timestamp_est, 'NA') != COALESCE(tgt.deal_start_timestamp_est, 'NA')
    OR COALESCE(src.deal_end_timestamp_est, 'NA') != COALESCE(tgt.deal_end_timestamp_est, 'NA')
    OR COALESCE(src.deal_ad_units, 'NA') != COALESCE(tgt.deal_ad_units, 'NA')
    LIMIT 1
"""

update_deal_delivery_query = """
    MERGE INTO fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily AS tgt
    USING (
    SELECT DISTINCT 
        Deal_ID
        , External_Deal_ID
        , Deal_Name
        , Deal_Type
        , deal_override_priority
        , Deal_Salesperson
        , deal_ad_units
        , Deal_Impression_Goal
        , deal_start_timestamp_est
        , deal_end_timestamp_est
    FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_deal
    WHERE etl_updated_at_timestamp_utc >= current_date() - 7
    ) AS src
    ON tgt.Deal_ID = src.Deal_ID
    WHEN MATCHED AND (
        COALESCE(src.External_Deal_ID, 'NA') != COALESCE(tgt.External_Deal_ID, 'NA')
        OR COALESCE(src.Deal_Name, 'NA') != COALESCE(tgt.Deal_Name, 'NA')
        OR COALESCE(src.Deal_Type, 'NA') != COALESCE(tgt.Deal_Type, 'NA')
        OR COALESCE(src.Deal_Salesperson, 'NA') != COALESCE(tgt.Deal_Salesperson, 'NA')
        OR COALESCE(src.Deal_Impression_Goal, 'NA') != COALESCE(tgt.Deal_Impression_Goal, 'NA')
        OR COALESCE(src.deal_start_timestamp_est, 'NA') != COALESCE(tgt.deal_start_timestamp_est, 'NA')
        OR COALESCE(src.deal_end_timestamp_est, 'NA') != COALESCE(tgt.deal_end_timestamp_est, 'NA')
        OR COALESCE(src.deal_ad_units, 'NA') != COALESCE(tgt.deal_ad_units, 'NA')
    ) 
    THEN UPDATE SET
        tgt.External_Deal_ID = src.External_Deal_ID
        , tgt.Deal_Name = src.Deal_Name
        , tgt.Deal_Type = src.Deal_Type
        , tgt.Deal_Salesperson = src.Deal_Salesperson
        , tgt.Deal_Impression_Goal = src.Deal_Impression_Goal
        , tgt.deal_start_timestamp_est = src.deal_start_timestamp_est
        , tgt.deal_end_timestamp_est = src.deal_end_timestamp_est
        , tgt.deal_ad_units = src.deal_ad_units
"""

# COMMAND ----------

update_matched_titles_capacity_query = """
    MERGE INTO fox_bi_prod.gold_ad_sales.ft_freewheel_capacity_summary_daily AS tgt
    USING (
        SELECT
            source_video_id AS video_asset_id
            , source_video_name
            , fw_1.series_name AS source_series_name
            , foxipedia_episode_name
            , foxipedia_series_id
            , foxipedia_series_name
            , foxipedia_season_number AS foxipedia_season_no
            , foxipedia_episode_number AS foxipedia_episode_no
            , foxipedia_episode_id
            , foxipedia_title_name AS mapped_foxipedia_title_name
            , source_gracenote_id AS gracenote_id
            , is_fuzzy_matched
        FROM fox_bi_prod.silver_ads.dim_matched_titles title
        LEFT JOIN (
            SELECT
                video_id
                , video_name
                , series_name
            FROM fox_bi_prod.gold_ad_sales.ft_freewheel_capacity_summary_daily
            GROUP BY ALL
        ) AS fw_1 
        ON (
            CASE
                WHEN title.source_video_id <> -1 THEN (
                    title.source_video_id = fw_1.video_id 
                    AND LOWER(title.source_video_name) = LOWER(fw_1.video_name)
                ) 
                ELSE LOWER(title.source_series_name) = LOWER(fw_1.series_name)
            END
        )
        WHERE source_type = 'Freewheel'
        AND is_approved = 'Y'
        QUALIFY ROW_NUMBER() OVER (PARTITION BY source_video_id, fw_1.series_name ORDER BY mapped_updated_timestamp_est DESC) = 1
    ) AS src
    ON tgt.video_id = src.video_asset_id
    AND LOWER(tgt.series_name) = LOWER(src.source_series_name)
    WHEN MATCHED AND (
        COALESCE(src.foxipedia_episode_name, 'NA') != COALESCE(tgt.foxipedia_episode_name, 'NA')
        OR COALESCE(src.foxipedia_series_name, 'NA') != COALESCE(tgt.foxipedia_series_name, 'NA')
        OR COALESCE(src.foxipedia_series_id, 'NA') != COALESCE(tgt.foxipedia_series_id, 'NA')
        OR COALESCE(src.foxipedia_season_no, 'NA') != COALESCE(tgt.foxipedia_season_no, 'NA')
        OR COALESCE(src.foxipedia_episode_no, 'NA') != COALESCE(tgt.foxipedia_episode_no, 'NA')
        OR COALESCE(src.foxipedia_episode_id, 'NA') != COALESCE(tgt.foxipedia_episode_id, 'NA')
        OR COALESCE(src.mapped_foxipedia_title_name, 'NA') != COALESCE(tgt.mapped_foxipedia_title_name, 'NA')
        OR COALESCE(src.gracenote_id, 'NA') != COALESCE(tgt.gracenote_id, 'NA')
        OR COALESCE(src.is_fuzzy_matched, 'NA') != COALESCE(tgt.is_fuzzy_matched, 'NA')
    )
    THEN UPDATE SET
        tgt.foxipedia_episode_name = src.foxipedia_episode_name
        , tgt.foxipedia_series_id = src.foxipedia_series_id
        , tgt.foxipedia_series_name = src.foxipedia_series_name
        , tgt.foxipedia_season_no = src.foxipedia_season_no
        , tgt.foxipedia_episode_no = src.foxipedia_episode_no
        , tgt.foxipedia_episode_id = src.foxipedia_episode_id
        , tgt.mapped_foxipedia_title_name = src.mapped_foxipedia_title_name
        , tgt.gracenote_id = src.gracenote_id
        , tgt.is_fuzzy_matched = src.is_fuzzy_matched
"""

# COMMAND ----------

update_matched_titles_delivery_query = """
    MERGE INTO fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily AS tgt
    USING (
        SELECT
            source_video_id AS video_asset_id
            , source_video_name
            , fw_1.series_name AS source_series_name
            , foxipedia_episode_name
            , foxipedia_series_id
            , foxipedia_series_name
            , foxipedia_season_number AS foxipedia_season_no
            , foxipedia_episode_number AS foxipedia_episode_no
            , foxipedia_episode_id
            , foxipedia_title_name AS mapped_foxipedia_title_name
            , source_gracenote_id AS gracenote_id
            , is_fuzzy_matched
        FROM fox_bi_prod.silver_ads.dim_matched_titles title
        LEFT JOIN (
            SELECT
                video_id
                , video_name
                , series_name
            FROM fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily
            GROUP BY ALL
        ) AS fw_1 
        ON (
            CASE
                WHEN title.source_video_id <> -1 THEN (
                    title.source_video_id = fw_1.video_id 
                    AND LOWER(title.source_video_name) = LOWER(fw_1.video_name)
                ) 
                ELSE LOWER(title.source_series_name) = LOWER(fw_1.series_name)
            END
        )
        WHERE source_type = 'Freewheel'
        AND is_approved =  'Y' 
        QUALIFY ROW_NUMBER() OVER (PARTITION BY source_video_id, fw_1.series_name ORDER BY mapped_updated_timestamp_est DESC) = 1
    ) AS src
    ON tgt.video_id = src.video_asset_id
    AND LOWER(tgt.series_name) = LOWER(src.source_series_name)
    WHEN MATCHED AND (
        COALESCE(src.foxipedia_episode_name, 'NA') != COALESCE(tgt.foxipedia_episode_name, 'NA')
        OR COALESCE(src.foxipedia_series_name, 'NA') != COALESCE(tgt.foxipedia_series_name, 'NA')
        OR COALESCE(src.foxipedia_series_id, 'NA') != COALESCE(tgt.foxipedia_series_id, 'NA')
        OR COALESCE(src.foxipedia_season_no, 'NA') != COALESCE(tgt.foxipedia_season_no, 'NA')
        OR COALESCE(src.foxipedia_episode_no, 'NA') != COALESCE(tgt.foxipedia_episode_no, 'NA')
        OR COALESCE(src.foxipedia_episode_id, 'NA') != COALESCE(tgt.foxipedia_episode_id, 'NA')
        OR COALESCE(src.mapped_foxipedia_title_name, 'NA') != COALESCE(tgt.mapped_foxipedia_title_name, 'NA')
        OR COALESCE(src.gracenote_id, 'NA') != COALESCE(tgt.gracenote_id, 'NA')
        OR COALESCE(src.is_fuzzy_matched, 'NA') != COALESCE(tgt.is_fuzzy_matched, 'NA')
    )
    THEN UPDATE SET 
        tgt.foxipedia_episode_name = src.foxipedia_episode_name
        , tgt.foxipedia_series_name = src.foxipedia_series_name
        , tgt.foxipedia_series_id = src.foxipedia_series_id
        , tgt.foxipedia_season_no = src.foxipedia_season_no
        , tgt.foxipedia_episode_no = src.foxipedia_episode_no
        , tgt.foxipedia_episode_id = src.foxipedia_episode_id
        , tgt.mapped_foxipedia_title_name = src.mapped_foxipedia_title_name
        , tgt.gracenote_id = src.gracenote_id
        , tgt.is_fuzzy_matched = src.is_fuzzy_matched
"""

# COMMAND ----------

update_video_vertical_capacity_query = """
    UPDATE fox_bi_prod.gold_ad_sales.ft_freewheel_capacity_summary_daily
        SET video_vertical = 
        CASE
            WHEN UPPER(global_ad_unit_category) = 'DISPLAY ADS' THEN 'Display'
            WHEN LOWER(series_name) LIKE '%deportes%' THEN 'Deportes'
            WHEN primary_video_group_id = '18773867' THEN 'BTN'
            WHEN LOWER(series_name) LIKE '%monarch%' THEN 'Entertainment'
            
            -- Weather Logic
            WHEN LOWER(series_name) LIKE '%fox weather%' 
                OR LOWER(site_section_name) LIKE '%fox weather%' THEN 'Weather'
            
            -- News/Business Logic
            WHEN primary_video_group_id IN ('20474534', '20474467')
                OR LOWER(series_name) LIKE '%vs: news%'
                OR LOWER(series_name) LIKE '%vs: fnc%'
                OR LOWER(series_name) LIKE '%vs: fbn%'
                OR LOWER(series_name) LIKE '%: fnc%'
                OR LOWER(series_name) LIKE '%: fbn%'
                OR LOWER(series_name) LIKE '%: fox business%'
                OR LOWER(site_section_name) LIKE '%fox news app%'
                OR LOWER(site_section_name) LIKE '%fnc%'
                OR LOWER(site_section_name) LIKE '%fbn%'
                OR LOWER(site_section_name) LIKE '%fox business%' THEN 'News/Business'
            
            -- Fox Nation Logic
            WHEN LOWER(series_name) LIKE '%vs: nation%'
                OR LOWER(site_section_name) LIKE '%fox nation%' THEN 'Fox Nation'
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%Nation%' THEN 'Fox Nation'
            
            WHEN LOWER(site_section_name) LIKE '%tmz%' THEN 'TMZ'
            WHEN LOWER(site_section_name) LIKE '%outkick app%' THEN 'Outkick'
            WHEN LOWER(series_name) LIKE '%ultimate tag%' THEN 'Entertainment'
            WHEN primary_video_group_id = '18698796' THEN 'Sports SFV'
            
            WHEN primary_video_group_id = '414462094' OR video_name LIKE '%NIVA%' THEN 'NIVA'
            
            -- Sports LFV Logic
            WHEN primary_video_group_id IN ('18698781', '241987048', '241987474')
                OR UPPER(series_name) LIKE '%WWE%'
                OR UPPER(series_name) LIKE '%SMACKDOWN%'
                OR UPPER(series_name) LIKE '%VS: SPORTS%' THEN 'Sports LFV'
            
            -- Entertainment Logic
            WHEN primary_video_group_id = '18652208'
                OR LOWER(site_section_name) LIKE '%fox ent%'
                OR LOWER(series_name) LIKE '%vs: ent: fox:%' THEN 'Entertainment'
            
            WHEN primary_video_group_id = '18698699' THEN 'Entertainment SFV'
            
            -- Fox One Cross-Sells
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%ENT%' THEN 'Entertainment'
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%Sports%' THEN 'Sports LFV'
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%Weather%' THEN 'Weather'
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%Business%' THEN 'News/Business'
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%News%' THEN 'News/Business'
            
            -- Tubi Specific Logic
            WHEN UPPER(site_section_name) LIKE '%TUBI%' AND series_name = 'Unknown Series' THEN
                CASE 
                    WHEN video_name LIKE '%FOX Entertainment%' THEN 'Entertainment'
                    WHEN LOWER(video_name) LIKE '%gordon ramsay%' THEN 'Entertainment'
                    WHEN LOWER(video_name) LIKE '%masterchef%' THEN 'Entertainment'
                    WHEN LOWER(video_name) LIKE "%hell's kitchen%" THEN 'Entertainment'
                    WHEN LOWER(video_name) LIKE '%masked singer%' THEN 'Entertainment'
                    WHEN video_name LIKE '%FOX Sports%' THEN 'Sports LFV'
                    WHEN video_name LIKE '%FOX News%' THEN 'News/Business'
                    WHEN video_name LIKE '%FOX Weather%' THEN 'Weather'
                    ELSE 'Tubi' -- Default if within Tubi/Unknown but no video match
                END
                
            WHEN series_name = 'Unknown Series' AND LOWER(video_name) LIKE '%masked singer%' THEN 'Entertainment'
            WHEN LOWER(site_section_name) LIKE '%tubi%' THEN 'Tubi'

            ELSE 'Unassigned'
        END
        WHERE CASE
            WHEN UPPER(global_ad_unit_category) = 'DISPLAY ADS' THEN 'Display'
            WHEN LOWER(series_name) LIKE '%deportes%' THEN 'Deportes'
            WHEN primary_video_group_id = '18773867' THEN 'BTN'
            WHEN LOWER(series_name) LIKE '%monarch%' THEN 'Entertainment'
            
            -- Weather Logic
            WHEN LOWER(series_name) LIKE '%fox weather%' 
                OR LOWER(site_section_name) LIKE '%fox weather%' THEN 'Weather'
            
            -- News/Business Logic
            WHEN primary_video_group_id IN ('20474534', '20474467')
                OR LOWER(series_name) LIKE '%vs: news%'
                OR LOWER(series_name) LIKE '%vs: fnc%'
                OR LOWER(series_name) LIKE '%vs: fbn%'
                OR LOWER(series_name) LIKE '%: fnc%'
                OR LOWER(series_name) LIKE '%: fbn%'
                OR LOWER(series_name) LIKE '%: fox business%'
                OR LOWER(site_section_name) LIKE '%fox news app%'
                OR LOWER(site_section_name) LIKE '%fnc%'
                OR LOWER(site_section_name) LIKE '%fbn%'
                OR LOWER(site_section_name) LIKE '%fox business%' THEN 'News/Business'
            
            -- Fox Nation Logic
            WHEN LOWER(series_name) LIKE '%vs: nation%'
                OR LOWER(site_section_name) LIKE '%fox nation%' THEN 'Fox Nation'
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%Nation%' THEN 'Fox Nation'
            
            WHEN LOWER(site_section_name) LIKE '%tmz%' THEN 'TMZ'
            WHEN LOWER(site_section_name) LIKE '%outkick app%' THEN 'Outkick'
            WHEN LOWER(series_name) LIKE '%ultimate tag%' THEN 'Entertainment'
            WHEN primary_video_group_id = '18698796' THEN 'Sports SFV'
            
            WHEN primary_video_group_id = '414462094' OR video_name LIKE '%NIVA%' THEN 'NIVA'
            
            -- Sports LFV Logic
            WHEN primary_video_group_id IN ('18698781', '241987048', '241987474')
                OR UPPER(series_name) LIKE '%WWE%'
                OR UPPER(series_name) LIKE '%SMACKDOWN%'
                OR UPPER(series_name) LIKE '%VS: SPORTS%' THEN 'Sports LFV'
            
            -- Entertainment Logic
            WHEN primary_video_group_id = '18652208'
                OR LOWER(site_section_name) LIKE '%fox ent%'
                OR LOWER(series_name) LIKE '%vs: ent: fox:%' THEN 'Entertainment'
            
            WHEN primary_video_group_id = '18698699' THEN 'Entertainment SFV'
            
            -- Fox One Cross-Sells
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%ENT%' THEN 'Entertainment'
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%Sports%' THEN 'Sports LFV'
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%Weather%' THEN 'Weather'
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%Business%' THEN 'News/Business'
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%News%' THEN 'News/Business'
            
            -- Tubi Specific Logic
            WHEN UPPER(site_section_name) LIKE '%TUBI%' AND series_name = 'Unknown Series' THEN
                CASE 
                    WHEN video_name LIKE '%FOX Entertainment%' THEN 'Entertainment'
                    WHEN LOWER(video_name) LIKE '%gordon ramsay%' THEN 'Entertainment'
                    WHEN LOWER(video_name) LIKE '%masterchef%' THEN 'Entertainment'
                    WHEN LOWER(video_name) LIKE "%hell's kitchen%" THEN 'Entertainment'
                    WHEN LOWER(video_name) LIKE '%masked singer%' THEN 'Entertainment'
                    WHEN video_name LIKE '%FOX Sports%' THEN 'Sports LFV'
                    WHEN video_name LIKE '%FOX News%' THEN 'News/Business'
                    WHEN video_name LIKE '%FOX Weather%' THEN 'Weather'
                    ELSE 'Tubi' -- Default if within Tubi/Unknown but no video match
                END
                
            WHEN series_name = 'Unknown Series' AND LOWER(video_name) LIKE '%masked singer%' THEN 'Entertainment'
            WHEN LOWER(site_section_name) LIKE '%tubi%' THEN 'Tubi'

            ELSE 'Unassigned'
        END <> COALESCE(video_vertical, 'NA')
"""

# COMMAND ----------

update_video_vertical_delivery_query = """
    UPDATE fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily
        SET video_vertical = 
        CASE
            WHEN UPPER(global_ad_unit_category) = 'DISPLAY ADS' THEN 'Display'
            WHEN LOWER(series_name) LIKE '%deportes%' THEN 'Deportes'
            WHEN primary_video_group_id = '18773867' THEN 'BTN'
            WHEN LOWER(series_name) LIKE '%monarch%' THEN 'Entertainment'
            
            -- Weather Logic
            WHEN LOWER(series_name) LIKE '%fox weather%' 
                OR LOWER(site_section_name) LIKE '%fox weather%' THEN 'Weather'
            
            -- News/Business Logic
            WHEN primary_video_group_id IN ('20474534', '20474467')
                OR LOWER(series_name) LIKE '%vs: news%'
                OR LOWER(series_name) LIKE '%vs: fnc%'
                OR LOWER(series_name) LIKE '%vs: fbn%'
                OR LOWER(series_name) LIKE '%: fnc%'
                OR LOWER(series_name) LIKE '%: fbn%'
                OR LOWER(series_name) LIKE '%: fox business%'
                OR LOWER(site_section_name) LIKE '%fox news app%'
                OR LOWER(site_section_name) LIKE '%fnc%'
                OR LOWER(site_section_name) LIKE '%fbn%'
                OR LOWER(site_section_name) LIKE '%fox business%' THEN 'News/Business'
            
            -- Fox Nation Logic
            WHEN LOWER(series_name) LIKE '%vs: nation%'
                OR LOWER(site_section_name) LIKE '%fox nation%' THEN 'Fox Nation'
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%Nation%' THEN 'Fox Nation'
            
            WHEN LOWER(site_section_name) LIKE '%tmz%' THEN 'TMZ'
            WHEN LOWER(site_section_name) LIKE '%outkick app%' THEN 'Outkick'
            WHEN LOWER(series_name) LIKE '%ultimate tag%' THEN 'Entertainment'
            WHEN primary_video_group_id = '18698796' THEN 'Sports SFV'
            
            WHEN primary_video_group_id = '414462094' OR video_name LIKE '%NIVA%' THEN 'NIVA'
            
            -- Sports LFV Logic
            WHEN primary_video_group_id IN ('18698781', '241987048', '241987474')
                OR UPPER(series_name) LIKE '%WWE%'
                OR UPPER(series_name) LIKE '%SMACKDOWN%'
                OR UPPER(series_name) LIKE '%VS: SPORTS%' THEN 'Sports LFV'
            
            -- Entertainment Logic
            WHEN primary_video_group_id = '18652208'
                OR LOWER(site_section_name) LIKE '%fox ent%'
                OR LOWER(series_name) LIKE '%vs: ent: fox:%' THEN 'Entertainment'
            
            WHEN primary_video_group_id = '18698699' THEN 'Entertainment SFV'
            
            -- Fox One Cross-Sells
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%ENT%' THEN 'Entertainment'
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%Sports%' THEN 'Sports LFV'
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%Weather%' THEN 'Weather'
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%Business%' THEN 'News/Business'
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%News%' THEN 'News/Business'
            
            -- Tubi Specific Logic
            WHEN UPPER(site_section_name) LIKE '%TUBI%' AND series_name = 'Unknown Series' THEN
                CASE 
                    WHEN video_name LIKE '%FOX Entertainment%' THEN 'Entertainment'
                    WHEN LOWER(video_name) LIKE '%gordon ramsay%' THEN 'Entertainment'
                    WHEN LOWER(video_name) LIKE '%masterchef%' THEN 'Entertainment'
                    WHEN LOWER(video_name) LIKE "%hell's kitchen%" THEN 'Entertainment'
                    WHEN LOWER(video_name) LIKE '%masked singer%' THEN 'Entertainment'
                    WHEN video_name LIKE '%FOX Sports%' THEN 'Sports LFV'
                    WHEN video_name LIKE '%FOX News%' THEN 'News/Business'
                    WHEN video_name LIKE '%FOX Weather%' THEN 'Weather'
                    ELSE 'Tubi' -- Default if within Tubi/Unknown but no video match
                END
                
            WHEN series_name = 'Unknown Series' AND LOWER(video_name) LIKE '%masked singer%' THEN 'Entertainment'
            WHEN LOWER(site_section_name) LIKE '%tubi%' THEN 'Tubi'

            ELSE 'Unassigned'
        END
        WHERE CASE
            WHEN UPPER(global_ad_unit_category) = 'DISPLAY ADS' THEN 'Display'
            WHEN LOWER(series_name) LIKE '%deportes%' THEN 'Deportes'
            WHEN primary_video_group_id = '18773867' THEN 'BTN'
            WHEN LOWER(series_name) LIKE '%monarch%' THEN 'Entertainment'
            
            -- Weather Logic
            WHEN LOWER(series_name) LIKE '%fox weather%' 
                OR LOWER(site_section_name) LIKE '%fox weather%' THEN 'Weather'
            
            -- News/Business Logic
            WHEN primary_video_group_id IN ('20474534', '20474467')
                OR LOWER(series_name) LIKE '%vs: news%'
                OR LOWER(series_name) LIKE '%vs: fnc%'
                OR LOWER(series_name) LIKE '%vs: fbn%'
                OR LOWER(series_name) LIKE '%: fnc%'
                OR LOWER(series_name) LIKE '%: fbn%'
                OR LOWER(series_name) LIKE '%: fox business%'
                OR LOWER(site_section_name) LIKE '%fox news app%'
                OR LOWER(site_section_name) LIKE '%fnc%'
                OR LOWER(site_section_name) LIKE '%fbn%'
                OR LOWER(site_section_name) LIKE '%fox business%' THEN 'News/Business'
            
            -- Fox Nation Logic
            WHEN LOWER(series_name) LIKE '%vs: nation%'
                OR LOWER(site_section_name) LIKE '%fox nation%' THEN 'Fox Nation'
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%Nation%' THEN 'Fox Nation'
            
            WHEN LOWER(site_section_name) LIKE '%tmz%' THEN 'TMZ'
            WHEN LOWER(site_section_name) LIKE '%outkick app%' THEN 'Outkick'
            WHEN LOWER(series_name) LIKE '%ultimate tag%' THEN 'Entertainment'
            WHEN primary_video_group_id = '18698796' THEN 'Sports SFV'
            
            WHEN primary_video_group_id = '414462094' OR video_name LIKE '%NIVA%' THEN 'NIVA'
            
            -- Sports LFV Logic
            WHEN primary_video_group_id IN ('18698781', '241987048', '241987474')
                OR UPPER(series_name) LIKE '%WWE%'
                OR UPPER(series_name) LIKE '%SMACKDOWN%'
                OR UPPER(series_name) LIKE '%VS: SPORTS%' THEN 'Sports LFV'
            
            -- Entertainment Logic
            WHEN primary_video_group_id = '18652208'
                OR LOWER(site_section_name) LIKE '%fox ent%'
                OR LOWER(series_name) LIKE '%vs: ent: fox:%' THEN 'Entertainment'
            
            WHEN primary_video_group_id = '18698699' THEN 'Entertainment SFV'
            
            -- Fox One Cross-Sells
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%ENT%' THEN 'Entertainment'
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%Sports%' THEN 'Sports LFV'
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%Weather%' THEN 'Weather'
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%Business%' THEN 'News/Business'
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%News%' THEN 'News/Business'
            
            -- Tubi Specific Logic
            WHEN UPPER(site_section_name) LIKE '%TUBI%' AND series_name = 'Unknown Series' THEN
                CASE 
                    WHEN video_name LIKE '%FOX Entertainment%' THEN 'Entertainment'
                    WHEN LOWER(video_name) LIKE '%gordon ramsay%' THEN 'Entertainment'
                    WHEN LOWER(video_name) LIKE '%masterchef%' THEN 'Entertainment'
                    WHEN LOWER(video_name) LIKE "%hell's kitchen%" THEN 'Entertainment'
                    WHEN LOWER(video_name) LIKE '%masked singer%' THEN 'Entertainment'
                    WHEN video_name LIKE '%FOX Sports%' THEN 'Sports LFV'
                    WHEN video_name LIKE '%FOX News%' THEN 'News/Business'
                    WHEN video_name LIKE '%FOX Weather%' THEN 'Weather'
                    ELSE 'Tubi' -- Default if within Tubi/Unknown but no video match
                END
                
            WHEN series_name = 'Unknown Series' AND LOWER(video_name) LIKE '%masked singer%' THEN 'Entertainment'
            WHEN LOWER(site_section_name) LIKE '%tubi%' THEN 'Tubi'

            ELSE 'Unassigned'
        END <> COALESCE(video_vertical, 'NA')
"""

# COMMAND ----------

update_video_vertical_matched_audience_query = """
    UPDATE fox_bi_prod.gold_ad_sales.ft_freewheel_matched_audience_daily
        SET video_vertical = 
        CASE
            WHEN UPPER(global_ad_unit_catagory) = 'DISPLAY ADS' THEN 'Display'
            WHEN LOWER(series_name) LIKE '%deportes%' THEN 'Deportes'
            WHEN primary_video_group_id = '18773867' THEN 'BTN'
            WHEN LOWER(series_name) LIKE '%monarch%' THEN 'Entertainment'
            
            -- Weather Logic
            WHEN LOWER(series_name) LIKE '%fox weather%' 
                OR LOWER(site_section_name) LIKE '%fox weather%' THEN 'Weather'
            
            -- News/Business Logic
            WHEN primary_video_group_id IN ('20474534', '20474467')
                OR LOWER(series_name) LIKE '%vs: news%'
                OR LOWER(series_name) LIKE '%vs: fnc%'
                OR LOWER(series_name) LIKE '%vs: fbn%'
                OR LOWER(series_name) LIKE '%: fnc%'
                OR LOWER(series_name) LIKE '%: fbn%'
                OR LOWER(series_name) LIKE '%: fox business%'
                OR LOWER(site_section_name) LIKE '%fox news app%'
                OR LOWER(site_section_name) LIKE '%fnc%'
                OR LOWER(site_section_name) LIKE '%fbn%'
                OR LOWER(site_section_name) LIKE '%fox business%' THEN 'News/Business'
            
            -- Fox Nation Logic
            WHEN LOWER(series_name) LIKE '%vs: nation%'
                OR LOWER(site_section_name) LIKE '%fox nation%' THEN 'Fox Nation'
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%Nation%' THEN 'Fox Nation'
            
            WHEN LOWER(site_section_name) LIKE '%tmz%' THEN 'TMZ'
            WHEN LOWER(site_section_name) LIKE '%outkick app%' THEN 'Outkick'
            WHEN LOWER(series_name) LIKE '%ultimate tag%' THEN 'Entertainment'
            WHEN primary_video_group_id = '18698796' THEN 'Sports SFV'
            
            WHEN primary_video_group_id = '414462094' OR video_name LIKE '%NIVA%' THEN 'NIVA'
            
            -- Sports LFV Logic
            WHEN primary_video_group_id IN ('18698781', '241987048', '241987474')
                OR UPPER(series_name) LIKE '%WWE%'
                OR UPPER(series_name) LIKE '%SMACKDOWN%'
                OR UPPER(series_name) LIKE '%VS: SPORTS%' THEN 'Sports LFV'
            
            -- Entertainment Logic
            WHEN primary_video_group_id = '18652208'
                OR LOWER(site_section_name) LIKE '%fox ent%'
                OR LOWER(series_name) LIKE '%vs: ent: fox:%' THEN 'Entertainment'
            
            WHEN primary_video_group_id = '18698699' THEN 'Entertainment SFV'
            
            -- Fox One Cross-Sells
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%ENT%' THEN 'Entertainment'
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%Sports%' THEN 'Sports LFV'
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%Weather%' THEN 'Weather'
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%Business%' THEN 'News/Business'
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%News%' THEN 'News/Business'
            
            -- Tubi Specific Logic
            WHEN UPPER(site_section_name) LIKE '%TUBI%' AND series_name = 'Unknown Series' THEN
                CASE 
                    WHEN video_name LIKE '%FOX Entertainment%' THEN 'Entertainment'
                    WHEN LOWER(video_name) LIKE '%gordon ramsay%' THEN 'Entertainment'
                    WHEN LOWER(video_name) LIKE '%masterchef%' THEN 'Entertainment'
                    WHEN LOWER(video_name) LIKE "%hell's kitchen%" THEN 'Entertainment'
                    WHEN LOWER(video_name) LIKE '%masked singer%' THEN 'Entertainment'
                    WHEN video_name LIKE '%FOX Sports%' THEN 'Sports LFV'
                    WHEN video_name LIKE '%FOX News%' THEN 'News/Business'
                    WHEN video_name LIKE '%FOX Weather%' THEN 'Weather'
                    ELSE 'Tubi' -- Default if within Tubi/Unknown but no video match
                END
                
            WHEN series_name = 'Unknown Series' AND LOWER(video_name) LIKE '%masked singer%' THEN 'Entertainment'
            WHEN LOWER(site_section_name) LIKE '%tubi%' THEN 'Tubi'

            ELSE 'Unassigned'
        END 
        WHERE CASE
            WHEN UPPER(global_ad_unit_catagory) = 'DISPLAY ADS' THEN 'Display'
            WHEN LOWER(series_name) LIKE '%deportes%' THEN 'Deportes'
            WHEN primary_video_group_id = '18773867' THEN 'BTN'
            WHEN LOWER(series_name) LIKE '%monarch%' THEN 'Entertainment'
            
            -- Weather Logic
            WHEN LOWER(series_name) LIKE '%fox weather%' 
                OR LOWER(site_section_name) LIKE '%fox weather%' THEN 'Weather'
            
            -- News/Business Logic
            WHEN primary_video_group_id IN ('20474534', '20474467')
                OR LOWER(series_name) LIKE '%vs: news%'
                OR LOWER(series_name) LIKE '%vs: fnc%'
                OR LOWER(series_name) LIKE '%vs: fbn%'
                OR LOWER(series_name) LIKE '%: fnc%'
                OR LOWER(series_name) LIKE '%: fbn%'
                OR LOWER(series_name) LIKE '%: fox business%'
                OR LOWER(site_section_name) LIKE '%fox news app%'
                OR LOWER(site_section_name) LIKE '%fnc%'
                OR LOWER(site_section_name) LIKE '%fbn%'
                OR LOWER(site_section_name) LIKE '%fox business%' THEN 'News/Business'
            
            -- Fox Nation Logic
            WHEN LOWER(series_name) LIKE '%vs: nation%'
                OR LOWER(site_section_name) LIKE '%fox nation%' THEN 'Fox Nation'
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%Nation%' THEN 'Fox Nation'
            
            WHEN LOWER(site_section_name) LIKE '%tmz%' THEN 'TMZ'
            WHEN LOWER(site_section_name) LIKE '%outkick app%' THEN 'Outkick'
            WHEN LOWER(series_name) LIKE '%ultimate tag%' THEN 'Entertainment'
            WHEN primary_video_group_id = '18698796' THEN 'Sports SFV'
            
            WHEN primary_video_group_id = '414462094' OR video_name LIKE '%NIVA%' THEN 'NIVA'
            
            -- Sports LFV Logic
            WHEN primary_video_group_id IN ('18698781', '241987048', '241987474')
                OR UPPER(series_name) LIKE '%WWE%'
                OR UPPER(series_name) LIKE '%SMACKDOWN%'
                OR UPPER(series_name) LIKE '%VS: SPORTS%' THEN 'Sports LFV'
            
            -- Entertainment Logic
            WHEN primary_video_group_id = '18652208'
                OR LOWER(site_section_name) LIKE '%fox ent%'
                OR LOWER(series_name) LIKE '%vs: ent: fox:%' THEN 'Entertainment'
            
            WHEN primary_video_group_id = '18698699' THEN 'Entertainment SFV'
            
            -- Fox One Cross-Sells
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%ENT%' THEN 'Entertainment'
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%Sports%' THEN 'Sports LFV'
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%Weather%' THEN 'Weather'
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%Business%' THEN 'News/Business'
            WHEN site_section_name LIKE '%Fox One%' AND site_section_name LIKE '%News%' THEN 'News/Business'
            
            -- Tubi Specific Logic
            WHEN UPPER(site_section_name) LIKE '%TUBI%' AND series_name = 'Unknown Series' THEN
                CASE 
                    WHEN video_name LIKE '%FOX Entertainment%' THEN 'Entertainment'
                    WHEN LOWER(video_name) LIKE '%gordon ramsay%' THEN 'Entertainment'
                    WHEN LOWER(video_name) LIKE '%masterchef%' THEN 'Entertainment'
                    WHEN LOWER(video_name) LIKE "%hell's kitchen%" THEN 'Entertainment'
                    WHEN LOWER(video_name) LIKE '%masked singer%' THEN 'Entertainment'
                    WHEN video_name LIKE '%FOX Sports%' THEN 'Sports LFV'
                    WHEN video_name LIKE '%FOX News%' THEN 'News/Business'
                    WHEN video_name LIKE '%FOX Weather%' THEN 'Weather'
                    ELSE 'Tubi' -- Default if within Tubi/Unknown but no video match
                END
                
            WHEN series_name = 'Unknown Series' AND LOWER(video_name) LIKE '%masked singer%' THEN 'Entertainment'
            WHEN LOWER(site_section_name) LIKE '%tubi%' THEN 'Tubi'

            ELSE 'Unassigned'
        END <> COALESCE(video_vertical, 'NA')
"""


# COMMAND ----------

update_demo_comp_delivery_query = """
    MERGE INTO fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily AS tgt 
    USING(
        WITH fw_demo_comp_cte AS (
            SELECT
                placement_id
                , SUM(on_target_net_delivered_impressions_quantity) AS on_target_net_delivered_impressions_quantity
            FROM fox_bi_prod.gold_ad_sales.ft_freewheel_demo_comp_daily
            GROUP BY ALL
        )
        , fw_del AS (
            SELECT
                COALESCE(placement_id,deal_id) AS placement_deal_id
                , booked_on_target_impression_goal
                , impression_goal
                , SUM(gross_counted_ads) AS gross_counted_ads
            FROM fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily
            GROUP BY ALL
        )
        SELECT
            placement_deal_id
            , ROUND(
                CASE 
                    WHEN SUM(fw.gross_counted_ads) = 0 THEN 0
                    WHEN SUM(dc.on_target_net_delivered_impressions_quantity)/CAST(SUM(fw.gross_counted_ads) AS DECIMAL(22,7)) > 1.5
                        THEN CAST(SUM(fw.booked_on_target_impression_goal) AS DECIMAL(22,7))/CAST(SUM(fw.impression_goal) AS DECIMAL(22,7))
                    ELSE SUM(dc.on_target_net_delivered_impressions_quantity)/CAST(SUM(fw.gross_counted_ads) AS DECIMAL(22,7))
                END, 2
            ) AS demo_comp
        FROM fw_del fw
        LEFT JOIN fw_demo_comp_cte dc
        ON dc.placement_id = fw.placement_deal_id
        GROUP BY ALL
    ) AS src
    ON tgt.placement_id = src.placement_deal_id
    WHEN MATCHED AND (
        COALESCE(tgt.placement_delivered_demo_comp, 0) != COALESCE(src.demo_comp, 0)
    )
    THEN UPDATE SET
        tgt.placement_delivered_demo_comp = src.demo_comp
"""

# COMMAND ----------

check_updates_agency_name_delivery_query = """
    SELECT 1
    FROM fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily tgt
    INNER JOIN (
        WITH fw_cmp_agn AS (
            SELECT
                campaign_id
            FROM fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily
            GROUP BY campaign_id
            HAVING COUNT(DISTINCT agency_name) > 1
        )
        SELECT
            campaign_id
            , agency_name
            , MIN(event_date) AS first_event
            , MAX(event_date) AS b
        FROM fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily
        WHERE campaign_id IN (
            SELECT
                campaign_id
            FROM fw_cmp_agn
        )
        GROUP BY campaign_id, agency_name
        QUALIFY ROW_NUMBER() OVER (PARTITION BY campaign_id ORDER BY first_event DESC) = 1
    ) AS src
    ON tgt.campaign_id = src.campaign_id
    WHERE COALESCE(tgt.agency_name, 'NA') != COALESCE(src.agency_name, 'NA')
    LIMIT 1
"""

update_agency_name_delivery_query = """
    MERGE INTO fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily AS tgt
    USING (
        WITH fw_cmp_agn AS (
            SELECT
                campaign_id
            FROM fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily
            GROUP BY campaign_id
            HAVING COUNT(DISTINCT agency_name) > 1
        )
        SELECT
            campaign_id
            , agency_name
            , MIN(event_date) AS first_event
            , MAX(event_date) AS b
        FROM fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily
        WHERE campaign_id IN (
            SELECT
                campaign_id
            FROM fw_cmp_agn
        )
        GROUP BY campaign_id, agency_name
        QUALIFY ROW_NUMBER() OVER (PARTITION BY campaign_id ORDER BY first_event DESC) = 1
    ) AS src
    ON tgt.campaign_id = src.campaign_id
    WHEN MATCHED AND (
        COALESCE(tgt.agency_name, 'NA') != COALESCE(src.agency_name, 'NA')
    )
    THEN UPDATE SET
        tgt.agency_name = src.agency_name
"""

# COMMAND ----------

check_updates_advertiser_name_delivery_query = """
    SELECT 1
    FROM fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily tgt
    INNER JOIN (
        WITH fw_cmp_adv AS (
            SELECT 
                campaign_id
            FROM fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily
            GROUP BY campaign_id
            HAVING COUNT(DISTINCT advertiser_name) > 1
        )
        SELECT
            campaign_id
            , advertiser_name
            , MIN(event_date) AS first_event
            , MAX(event_date) AS b
        FROM fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily
        WHERE campaign_id IN (
            SELECT
                campaign_id
            FROM fw_cmp_adv
        )
        GROUP BY campaign_id, advertiser_name
        QUALIFY ROW_NUMBER() OVER (PARTITION BY campaign_id ORDER BY first_event DESC) = 1
    ) AS src
    ON tgt.campaign_id = src.campaign_id
    WHERE COALESCE(tgt.advertiser_name, 'NA') != COALESCE(src.advertiser_name, 'NA')
    LIMIT 1
"""

update_advertiser_name_delivery_query = """
    MERGE INTO fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily AS tgt
    USING (
        WITH fw_cmp_adv AS (
            SELECT 
                campaign_id
            FROM fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily
            GROUP BY campaign_id
            HAVING COUNT(DISTINCT advertiser_name) > 1
        )
        SELECT
            campaign_id
            , advertiser_name
            , MIN(event_date) AS first_event
            , MAX(event_date) AS b
        FROM fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily
        WHERE campaign_id IN (
            SELECT
                campaign_id
            FROM fw_cmp_adv
        )
        GROUP BY campaign_id, advertiser_name
        QUALIFY ROW_NUMBER() OVER (PARTITION BY campaign_id ORDER BY first_event DESC) = 1
    ) AS src
    ON tgt.campaign_id = src.campaign_id
    WHEN MATCHED AND (
        COALESCE(tgt.advertiser_name, 'NA') != COALESCE(src.advertiser_name, 'NA')
    )
    THEN UPDATE SET
        tgt.advertiser_name = src.advertiser_name
"""


# COMMAND ----------

check_updates_site_section_capacity_query = """
    SELECT 1
    FROM fox_bi_prod.gold_ad_sales.ft_freewheel_capacity_summary_daily AS tgt
    INNER JOIN (
        SELECT DISTINCT
            Site_Section_ID
            , Site_Section_Name
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_site
        WHERE etl_updated_at_timestamp_utc >= CURRENT_DATE() - 7
    ) AS src
    ON tgt.Site_Section_ID = src.Site_Section_ID
    WHERE COALESCE(src.Site_Section_Name, 'NA') != COALESCE(tgt.Site_Section_Name, 'NA')
    LIMIT 1
"""

update_site_section_capacity_query = """
    MERGE INTO fox_bi_prod.gold_ad_sales.ft_freewheel_capacity_summary_daily AS tgt
    USING (
        SELECT DISTINCT
            Site_Section_ID
            , Site_Section_Name
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_site
        WHERE etl_updated_at_timestamp_utc >= current_date() - 7
    ) AS src
    ON tgt.Site_Section_ID = src.Site_Section_ID
    WHEN MATCHED AND (
        COALESCE(src.Site_Section_Name, 'NA') != COALESCE(tgt.Site_Section_Name, 'NA')
    )
    THEN UPDATE SET
        tgt.Site_Section_Name = src.Site_Section_Name
"""


# COMMAND ----------

check_updates_video_group_capacity_query = """
    SELECT 1
    FROM fox_bi_prod.gold_ad_sales.ft_freewheel_capacity_summary_daily AS tgt
    INNER JOIN (
        SELECT DISTINCT
            Video_ID
            , Video_Name
            , primary_video_group_id
            , primary_video_group_name
            , secondary_video_group_id
            , secondary_video_group_name
            , season_video_group_id
            , season_video_group_Name
            , prefered_video_group
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_video_group_custom
        WHERE etl_updated_at_timestamp_utc >= CURRENT_DATE() - 7
    ) AS src
    ON tgt.Video_ID = src.Video_ID
    WHERE COALESCE(src.Video_Name, 'NA') != COALESCE(tgt.Video_Name, 'NA')
    OR COALESCE(src.primary_video_group_id, 'NA') != COALESCE(tgt.primary_video_group_id, 'NA')
    OR COALESCE(src.primary_video_group_name, 'NA') != COALESCE(tgt.primary_video_group_name, 'NA')
    OR COALESCE(src.Prefered_Video_Group, 'NA') != COALESCE(tgt.Prefered_Video_Group, 'NA')
    OR COALESCE(src.secondary_video_group_id, 'NA') != COALESCE(tgt.secondary_video_group_id, 'NA')
    OR COALESCE(src.secondary_video_group_name, 'NA') != COALESCE(tgt.secondary_video_group_name, 'NA')
    OR COALESCE(src.season_video_group_id, 'NA') != COALESCE(tgt.season_video_group_id, 'NA')
    OR COALESCE(src.season_video_group_Name, 'NA') != COALESCE(tgt.season_video_group_Name, 'NA')
    LIMIT 1
"""

update_video_group_capacity_query = """
    MERGE INTO fox_bi_prod.gold_ad_sales.ft_freewheel_capacity_summary_daily AS tgt
    USING (
        SELECT DISTINCT
            Video_ID
            , Video_Name
            , primary_video_group_id
            , primary_video_group_name
            , secondary_video_group_id
            , secondary_video_group_name
            , season_video_group_id
            , season_video_group_Name
            , prefered_video_group
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_video_group_custom
        WHERE etl_updated_at_timestamp_utc >= current_date() - 7
    ) AS src
    ON tgt.Video_ID = src.Video_ID
    WHEN MATCHED AND (
        COALESCE(src.Video_Name, 'NA') != COALESCE(tgt.Video_Name, 'NA')
        OR COALESCE(src.primary_video_group_id, 'NA') != COALESCE(tgt.primary_video_group_id, 'NA')
        OR COALESCE(src.primary_video_group_name, 'NA') != COALESCE(tgt.primary_video_group_name, 'NA')
        OR COALESCE(src.Prefered_Video_Group, 'NA') != COALESCE(tgt.Prefered_Video_Group, 'NA')
        OR COALESCE(src.secondary_video_group_id, 'NA') != COALESCE(tgt.secondary_video_group_id, 'NA')
        OR COALESCE(src.secondary_video_group_name, 'NA') != COALESCE(tgt.secondary_video_group_name, 'NA')
        OR COALESCE(src.season_video_group_id, 'NA') != COALESCE(tgt.season_video_group_id, 'NA')
        OR COALESCE(src.season_video_group_Name, 'NA') != COALESCE(tgt.season_video_group_Name, 'NA')
    )
    THEN UPDATE SET
        tgt.Video_Name = src.Video_Name
        , tgt.primary_video_group_id = src.primary_video_group_id
        , tgt.primary_video_group_name = src.primary_video_group_name
        , tgt.Prefered_Video_Group = src.Prefered_Video_Group
        , tgt.secondary_video_group_id = src.secondary_video_group_id
        , tgt.secondary_video_group_name = src.secondary_video_group_name
        , tgt.season_video_group_id = src.season_video_group_id
        , tgt.season_video_group_name = src.season_video_group_name
"""


# COMMAND ----------

check_updates_ad_unit_delivery_query = """
    SELECT 1
    FROM fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily tgt
    INNER JOIN (
        SELECT DISTINCT
            ad_unit_id
            , ad_unit_price
            , ad_unit_external_id
            , ad_unit_position AS global_ad_unit_position
            , ad_unit_class AS global_ad_unit_class
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_ad_unit
        WHERE COALESCE(ad_unit_id,'-1') <> '-1'
        AND etl_updated_at_timestamp_utc >= CURRENT_DATE() - 7
    ) src
    ON tgt.ad_unit_id = src.ad_unit_id
    WHERE COALESCE(src.ad_unit_price, 'NA') != COALESCE(tgt.ad_unit_price, 'NA')
    OR COALESCE(src.ad_unit_external_id, 'NA') != COALESCE(tgt.ad_unit_external_id, 'NA')
    OR COALESCE(src.global_ad_unit_position, 'NA') != COALESCE(tgt.global_ad_unit_position, 'NA')
    OR COALESCE(src.global_ad_unit_class, 'NA') != COALESCE(tgt.global_ad_unit_class, 'NA')
    LIMIT 1
"""

update_ad_unit_delivery_query = """
    MERGE INTO fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily AS tgt
    USING (
    SELECT DISTINCT 
        ad_unit_id
        , ad_unit_price
        , ad_unit_external_id
        , ad_unit_position global_ad_unit_position
        , ad_unit_class global_ad_unit_class
    FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_ad_unit
    WHERE COALESCE(ad_unit_id,'-1') <> '-1'
    AND etl_updated_at_timestamp_utc >= current_date() - 7
    ) AS src
    ON tgt.ad_unit_id = src.ad_unit_id
    WHEN MATCHED AND (
        COALESCE(src.ad_unit_price, 'NA') != COALESCE(tgt.ad_unit_price, 'NA')
        OR COALESCE(src.ad_unit_external_id, 'NA') != COALESCE(tgt.ad_unit_external_id, 'NA')
        OR COALESCE(src.global_ad_unit_position, 'NA') != COALESCE(tgt.global_ad_unit_position, 'NA')
        OR COALESCE(src.global_ad_unit_class, 'NA') != COALESCE(tgt.global_ad_unit_class, 'NA')
    )
    THEN UPDATE SET
        tgt.ad_unit_price = src.ad_unit_price
        , tgt.ad_unit_external_id = src.ad_unit_external_id
        , tgt.global_ad_unit_position = src.global_ad_unit_position
        , tgt.global_ad_unit_class = src.global_ad_unit_class
"""


# COMMAND ----------

check_updates_creative_delivery_query = """
    SELECT 1
    FROM fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily AS tgt
    INNER JOIN (
        SELECT DISTINCT
            Creative_ID
            , creative_duration_secs
            , Creative_Name
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_creative
        WHERE etl_updated_at_timestamp_utc >= CURRENT_DATE() - 7
    ) AS src
    ON tgt.Creative_ID = src.Creative_ID
    WHERE COALESCE(src.creative_duration_secs, 'NA') != COALESCE(tgt.creative_duration_secs, 'NA')
    OR COALESCE(src.Creative_Name, 'NA') != COALESCE(tgt.Creative_Name, 'NA')
    LIMIT 1
"""

update_creative_delivery_query = """
    MERGE INTO fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily AS tgt
    USING (
        SELECT DISTINCT
            Creative_ID
            , creative_duration_secs
            , Creative_Name
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_creative
        WHERE etl_updated_at_timestamp_utc >= current_date() - 7
    ) AS src
    ON tgt.Creative_ID = src.Creative_ID
    WHEN MATCHED AND (
        COALESCE(src.creative_duration_secs, 'NA') != COALESCE(tgt.creative_duration_secs, 'NA')
        OR COALESCE(src.Creative_Name, 'NA') != COALESCE(tgt.Creative_Name, 'NA')
    ) 
    THEN UPDATE SET
        tgt.creative_duration_secs = src.creative_duration_secs
        , tgt.Creative_Name = src.Creative_Name
"""


# COMMAND ----------

check_updates_insertion_order_delivery_query = """
    SELECT 1
    FROM fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily AS tgt
    INNER JOIN (
        SELECT DISTINCT
            Insertion_Order_Id
            , Insertion_Order_Name
            , insertion_order_external_id
            , insertion_order_end_timestamp_est
            , insertion_order_primary_salesperson
            , insertion_order_primary_trafficker
            , insertion_order_start_timestamp_est
            , insertion_order_status
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_insertion_order
        WHERE etl_updated_at_timestamp_utc >= CURRENT_DATE() - 7
    ) AS src
    ON tgt.Insertion_Order_Id = src.Insertion_Order_Id
    WHERE COALESCE(src.Insertion_Order_Name, 'NA') != COALESCE(tgt.Insertion_Order_Name, 'NA')
    OR COALESCE(src.insertion_order_external_id, 'NA') != COALESCE(tgt.insertion_order_external_id, 'NA')
    OR COALESCE(src.insertion_order_end_timestamp_est, 'NA') != COALESCE(tgt.insertion_order_end_timestamp_est, 'NA')
    OR COALESCE(src.insertion_order_primary_salesperson, 'NA') != COALESCE(tgt.insertion_order_primary_salesperson, 'NA')
    OR COALESCE(src.insertion_order_primary_trafficker, 'NA') != COALESCE(tgt.insertion_order_primary_trafficker, 'NA')
    OR COALESCE(src.insertion_order_start_timestamp_est, 'NA') != COALESCE(tgt.insertion_order_start_timestamp_est, 'NA')
    OR COALESCE(src.insertion_order_status, 'NA') != COALESCE(tgt.insertion_order_status, 'NA')
    LIMIT 1
"""

update_insertion_order_delivery_query = """
    MERGE INTO fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily AS tgt
    USING (
        SELECT DISTINCT
            Insertion_Order_Id
            , Insertion_Order_Name
            , insertion_order_external_id
            , insertion_order_end_timestamp_est
            , insertion_order_primary_salesperson
            , insertion_order_primary_trafficker
            , insertion_order_start_timestamp_est
            , insertion_order_status
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_insertion_order
        WHERE etl_updated_at_timestamp_utc >= current_date() - 7
    ) AS src
    ON tgt.Insertion_Order_Id = src.Insertion_Order_Id
    WHEN MATCHED AND (
        COALESCE(src.Insertion_Order_Name, 'NA') != COALESCE(tgt.Insertion_Order_Name, 'NA')
        OR COALESCE(src.insertion_order_external_id, 'NA') != COALESCE(tgt.insertion_order_external_id, 'NA')
        OR COALESCE(src.insertion_order_end_timestamp_est, 'NA') != COALESCE(tgt.insertion_order_end_timestamp_est, 'NA')
        OR COALESCE(src.insertion_order_primary_salesperson, 'NA') != COALESCE(tgt.insertion_order_primary_salesperson, 'NA')
        OR COALESCE(src.insertion_order_primary_trafficker, 'NA') != COALESCE(tgt.insertion_order_primary_trafficker, 'NA')
        OR COALESCE(src.insertion_order_start_timestamp_est, 'NA') != COALESCE(tgt.insertion_order_start_timestamp_est, 'NA')
        OR COALESCE(src.insertion_order_status, 'NA') != COALESCE(tgt.insertion_order_status, 'NA')
        ) 
    THEN UPDATE SET
        tgt.Insertion_Order_Name = src.Insertion_Order_Name
        , tgt.insertion_order_external_id = src.insertion_order_external_id
        , tgt.insertion_order_end_timestamp_est = src.insertion_order_end_timestamp_est
        , tgt.insertion_order_primary_salesperson = src.insertion_order_primary_salesperson
        , tgt.insertion_order_primary_trafficker = src.insertion_order_primary_trafficker
        , tgt.insertion_order_start_timestamp_est = src.insertion_order_start_timestamp_est
        , tgt.insertion_order_status = src.insertion_order_status
"""


# COMMAND ----------

check_updates_programmatic_creative_delivery_query = """
    SELECT 1
    FROM fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily AS tgt
    INNER JOIN (
        SELECT DISTINCT
            Programmatic_Ad_ID
            , Programmatic_Industry_Name
            , Programmatic_Brand_Name
            , programmatic_creative_duration
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_programmatic_creative
        WHERE etl_updated_at_timestamp_utc >= CURRENT_DATE() - 7
    ) AS src
    ON tgt.Programmatic_Ad_ID = src.Programmatic_Ad_ID
    WHERE COALESCE(src.Programmatic_Industry_Name, 'NA') != COALESCE(tgt.Programmatic_Industry_Name, 'NA')
    OR COALESCE(src.Programmatic_Brand_Name, 'NA') != COALESCE(tgt.Programmatic_Brand_Name, 'NA')
    OR COALESCE(src.programmatic_creative_duration, 'NA') != COALESCE(tgt.programmatic_creative_duration, 'NA')
    LIMIT 1
"""

update_programmatic_creative_delivery_query = """
    MERGE INTO fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily AS tgt
    USING (
        SELECT DISTINCT
            Programmatic_Ad_ID
            , Programmatic_Industry_Name
            , Programmatic_Brand_Name
            , programmatic_creative_duration
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_programmatic_creative
        WHERE etl_updated_at_timestamp_utc >= current_date() - 7
    ) AS src
    ON tgt.Programmatic_Ad_ID = src.Programmatic_Ad_ID
    WHEN MATCHED AND (
        COALESCE(src.Programmatic_Industry_Name, 'NA') != COALESCE(tgt.Programmatic_Industry_Name, 'NA')
        OR COALESCE(src.Programmatic_Brand_Name, 'NA') != COALESCE(tgt.Programmatic_Brand_Name, 'NA')
        OR COALESCE(src.programmatic_creative_duration, 'NA') != COALESCE(tgt.programmatic_creative_duration, 'NA')
    ) 
    THEN UPDATE SET
        tgt.Programmatic_Industry_Name = src.Programmatic_Industry_Name
        , tgt.Programmatic_Brand_Name = src.Programmatic_Brand_Name
        , tgt.programmatic_creative_duration = src.programmatic_creative_duration
"""


# COMMAND ----------

check_updates_site_section_delivery_query = """
    SELECT 1
    FROM fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily AS tgt
    INNER JOIN (
        SELECT DISTINCT
            Site_Section_ID
            , Site_Section_Name
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_site
        WHERE etl_updated_at_timestamp_utc >= CURRENT_DATE() - 7
    ) AS src
    ON tgt.Site_Section_ID = src.Site_Section_ID
    WHERE COALESCE(src.Site_Section_Name, 'NA') != COALESCE(tgt.Site_Section_Name, 'NA')
    LIMIT 1
"""

update_site_section_delivery_query = """
    MERGE INTO fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily AS tgt
    USING (
        SELECT DISTINCT
            Site_Section_ID
            , Site_Section_Name
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_site
        WHERE etl_updated_at_timestamp_utc >= current_date() - 7
    ) AS src
    ON tgt.Site_Section_ID = src.Site_Section_ID
    WHEN MATCHED AND (
        COALESCE(src.Site_Section_Name, 'NA') != COALESCE(tgt.Site_Section_Name, 'NA')
    )
    THEN UPDATE SET
        tgt.Site_Section_Name = src.Site_Section_Name
"""


# COMMAND ----------

check_updates_video_group_delivery_query = """
    SELECT 1
    FROM fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily AS tgt
    INNER JOIN (
        SELECT DISTINCT
            Video_ID
            , Video_Name
            , primary_video_group_id
            , primary_video_group_name
            , secondary_video_group_id
            , secondary_video_group_name
            , season_video_group_id
            , season_video_group_Name
            , prefered_video_group
            , video_duration
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_video_group_custom
        WHERE etl_updated_at_timestamp_utc >= CURRENT_DATE() - 7
    ) AS src
    ON tgt.Video_ID = src.Video_ID
    WHERE COALESCE(src.Video_Name, 'NA') != COALESCE(tgt.Video_Name, 'NA')
    OR COALESCE(src.primary_video_group_id, 'NA') != COALESCE(tgt.primary_video_group_id, 'NA')
    OR COALESCE(src.primary_video_group_name, 'NA') != COALESCE(tgt.primary_video_group_name, 'NA')
    OR COALESCE(src.Prefered_Video_Group, 'NA') != COALESCE(tgt.Prefered_Video_Group, 'NA')
    OR COALESCE(src.secondary_video_group_id, 'NA') != COALESCE(tgt.secondary_video_group_id, 'NA')
    OR COALESCE(src.secondary_video_group_name, 'NA') != COALESCE(tgt.secondary_video_group_name, 'NA')
    OR COALESCE(src.season_video_group_id, 'NA') != COALESCE(tgt.season_video_group_id, 'NA')
    OR COALESCE(src.season_video_group_Name, 'NA') != COALESCE(tgt.season_video_group_Name, 'NA')
    OR COALESCE(src.video_duration, 'NA') != COALESCE(tgt.video_duration, 'NA')
    LIMIT 1
"""

update_video_group_delivery_query = """
    MERGE INTO fox_bi_prod.gold_ad_sales.ft_freewheel_delivery_daily AS tgt
    USING (
        SELECT DISTINCT
            Video_ID
            , Video_Name
            , primary_video_group_id
            , primary_video_group_name
            , secondary_video_group_id
            , secondary_video_group_name
            , season_video_group_id
            , season_video_group_Name
            , prefered_video_group
            , video_duration
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_video_group_custom
        WHERE etl_updated_at_timestamp_utc >= current_date() - 7
    ) AS src
    ON tgt.Video_ID = src.Video_ID
    WHEN MATCHED AND (
        COALESCE(src.Video_Name, 'NA') != COALESCE(tgt.Video_Name, 'NA')
        OR COALESCE(src.primary_video_group_id, 'NA') != COALESCE(tgt.primary_video_group_id, 'NA')
        OR COALESCE(src.primary_video_group_name, 'NA') != COALESCE(tgt.primary_video_group_name, 'NA')
        OR COALESCE(src.Prefered_Video_Group, 'NA') != COALESCE(tgt.Prefered_Video_Group, 'NA')
        OR COALESCE(src.secondary_video_group_id, 'NA') != COALESCE(tgt.secondary_video_group_id, 'NA')
        OR COALESCE(src.secondary_video_group_name, 'NA') != COALESCE(tgt.secondary_video_group_name, 'NA')
        OR COALESCE(src.season_video_group_id, 'NA') != COALESCE(tgt.season_video_group_id, 'NA')
        OR COALESCE(src.season_video_group_Name, 'NA') != COALESCE(tgt.season_video_group_Name, 'NA')
        OR COALESCE(src.video_duration, 'NA') != COALESCE(tgt.video_duration, 'NA')
    )
    THEN UPDATE SET
        tgt.Video_Name = src.Video_Name
        , tgt.primary_video_group_id = src.primary_video_group_id
        , tgt.primary_video_group_name = src.primary_video_group_name
        , tgt.Prefered_Video_Group = src.Prefered_Video_Group
        , tgt.secondary_video_group_id = src.secondary_video_group_id
        , tgt.secondary_video_group_name = src.secondary_video_group_name
        , tgt.season_video_group_id = src.season_video_group_id
        , tgt.season_video_group_name = src.season_video_group_name
        , tgt.video_duration = src.video_duration
"""


# COMMAND ----------

check_updates_ad_unit_matched_audience_query = """
    SELECT 1
    FROM fox_bi_prod.gold_ad_sales.ft_freewheel_matched_audience_daily tgt
    INNER JOIN (
        SELECT DISTINCT
            ad_unit_id
            , ad_unit_price
            , ad_unit_external_id
            , ad_unit_position AS global_ad_unit_position
            , ad_unit_class AS global_ad_unit_class
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_ad_unit
        WHERE COALESCE(ad_unit_id, '-1') <> '-1'
        AND etl_updated_at_timestamp_utc >= CURRENT_DATE() - 7
    ) src
    ON tgt.ad_unit_id = src.ad_unit_id
    WHERE COALESCE(src.ad_unit_price, 'NA') != COALESCE(tgt.ad_unit_price, 'NA')
    OR COALESCE(src.ad_unit_external_id, 'NA') != COALESCE(tgt.ad_unit_external_id, 'NA')
    OR COALESCE(src.global_ad_unit_position, 'NA') != COALESCE(tgt.global_ad_unit_position, 'NA')
    OR COALESCE(src.global_ad_unit_class, 'NA') != COALESCE(tgt.global_ad_unit_class, 'NA')
    LIMIT 1
"""

update_ad_unit_matched_audience_query = """
    MERGE INTO fox_bi_prod.gold_ad_sales.ft_freewheel_matched_audience_daily AS tgt
    USING (
        SELECT DISTINCT
            ad_unit_id
            , ad_unit_price
            , ad_unit_external_id
            , ad_unit_position AS global_ad_unit_position
            , ad_unit_class AS global_ad_unit_class
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_ad_unit
        WHERE COALESCE(ad_unit_id, '-1') <> '-1'
        AND etl_updated_at_timestamp_utc >= current_date() - 7
    ) AS src
    ON tgt.ad_unit_id = src.ad_unit_id
    WHEN MATCHED AND (
        COALESCE(src.ad_unit_price, 'NA') != COALESCE(tgt.ad_unit_price, 'NA')
        OR COALESCE(src.ad_unit_external_id, 'NA') != COALESCE(tgt.ad_unit_external_id, 'NA')
        OR COALESCE(src.global_ad_unit_position, 'NA') != COALESCE(tgt.global_ad_unit_position, 'NA')
        OR COALESCE(src.global_ad_unit_class, 'NA') != COALESCE(tgt.global_ad_unit_class, 'NA')
    )
    THEN UPDATE SET
        tgt.ad_unit_price = src.ad_unit_price
        , tgt.ad_unit_external_id = src.ad_unit_external_id
        , tgt.global_ad_unit_position = src.global_ad_unit_position
        , tgt.global_ad_unit_class = src.global_ad_unit_class
"""


# COMMAND ----------

check_updates_campaign_matched_audience_query = """
    SELECT 1
    FROM fox_bi_prod.gold_ad_sales.ft_freewheel_matched_audience_daily AS tgt
    INNER JOIN (
        SELECT DISTINCT
            Campaign_Id
            , Campaign_Name
            , Campaign_External_Id
            , campaign_start_timestamp_est
            , campaign_end_timestamp_est
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_campaign
        WHERE etl_updated_at_timestamp_utc >= CURRENT_DATE() - 7
    ) AS src
    ON tgt.Campaign_Id = src.Campaign_Id
    WHERE COALESCE(src.Campaign_Name, 'NA') != COALESCE(tgt.Campaign_Name, 'NA')
    OR COALESCE(src.Campaign_External_Id, 'NA') != COALESCE(tgt.Campaign_External_Id, 'NA')
    OR COALESCE(src.campaign_start_timestamp_est, 'NA') != COALESCE(tgt.campaign_start_timestamp_est, 'NA')
    OR COALESCE(src.campaign_end_timestamp_est, 'NA') != COALESCE(tgt.campaign_end_timestamp_est, 'NA')
    LIMIT 1
"""

update_campaign_matched_audience_query = """
    MERGE INTO fox_bi_prod.gold_ad_sales.ft_freewheel_matched_audience_daily AS tgt
    USING (
        SELECT DISTINCT
            Campaign_Id
            , Campaign_Name
            , Campaign_External_Id
            , campaign_start_timestamp_est
            , campaign_end_timestamp_est
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_campaign
        WHERE etl_updated_at_timestamp_utc >= current_date() - 7
    ) AS src
    ON tgt.Campaign_Id = src.Campaign_Id
    WHEN MATCHED AND (
        COALESCE(src.Campaign_Name, 'NA') != COALESCE(tgt.Campaign_Name, 'NA')
        OR COALESCE(src.Campaign_External_Id, 'NA') != COALESCE(tgt.Campaign_External_Id, 'NA')
        OR COALESCE(src.campaign_start_timestamp_est, 'NA') != COALESCE(tgt.campaign_start_timestamp_est, 'NA')
        OR COALESCE(src.campaign_end_timestamp_est, 'NA') != COALESCE(tgt.campaign_end_timestamp_est, 'NA')
    )
    THEN UPDATE SET
        tgt.Campaign_Name = src.Campaign_Name
        , tgt.Campaign_External_Id = src.Campaign_External_Id
        , tgt.campaign_start_timestamp_est = src.campaign_start_timestamp_est
        , tgt.campaign_end_timestamp_est = src.campaign_end_timestamp_est
"""


# COMMAND ----------

check_updates_creative_matched_audience_query = """
    SELECT 1
    FROM fox_bi_prod.gold_ad_sales.ft_freewheel_matched_audience_daily AS tgt
    INNER JOIN (
        SELECT DISTINCT
            Creative_ID
            , creative_duration_secs
            , Creative_Name
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_creative
        WHERE etl_updated_at_timestamp_utc >= CURRENT_DATE() - 7
    ) AS src
    ON tgt.Creative_ID = src.Creative_ID
    WHERE COALESCE(src.creative_duration_secs, 'NA') != COALESCE(tgt.creative_duration_secs, 'NA')
    OR COALESCE(src.Creative_Name, 'NA') != COALESCE(tgt.Creative_Name, 'NA')
    LIMIT 1
"""

update_creative_matched_audience_query = """
    MERGE INTO fox_bi_prod.gold_ad_sales.ft_freewheel_matched_audience_daily AS tgt
    USING (
        SELECT DISTINCT
            Creative_ID
            , creative_duration_secs
            , Creative_Name
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_creative
        WHERE etl_updated_at_timestamp_utc >= current_date() - 7
    ) AS src
    ON tgt.Creative_ID = src.Creative_ID
    WHEN MATCHED AND (
        COALESCE(src.creative_duration_secs, 'NA') != COALESCE(tgt.creative_duration_secs, 'NA')
        OR COALESCE(src.Creative_Name, 'NA') != COALESCE(tgt.Creative_Name, 'NA')
    )
    THEN UPDATE SET
        tgt.creative_duration_secs = src.creative_duration_secs
        , tgt.Creative_Name = src.Creative_Name
"""


# COMMAND ----------

check_updates_deal_matched_audience_query = """
    SELECT 1
    FROM fox_bi_prod.gold_ad_sales.ft_freewheel_matched_audience_daily AS tgt
    INNER JOIN (
        SELECT DISTINCT
            Deal_ID
            , External_Deal_ID
            , Deal_Name
            , Deal_Type
            , deal_override_priority
            , Deal_Salesperson
            , Deal_Impression_Goal
            , deal_start_timestamp_est
            , deal_end_timestamp_est
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_deal
        WHERE etl_updated_at_timestamp_utc >= CURRENT_DATE() - 7
    ) AS src
    ON tgt.Deal_ID = src.Deal_ID
    WHERE COALESCE(src.External_Deal_ID, 'NA') != COALESCE(tgt.External_Deal_ID, 'NA')
    OR COALESCE(src.Deal_Name, 'NA') != COALESCE(tgt.Deal_Name, 'NA')
    OR COALESCE(src.Deal_Type, 'NA') != COALESCE(tgt.Deal_Type, 'NA')
    OR COALESCE(src.Deal_Salesperson, 'NA') != COALESCE(tgt.Deal_Salesperson, 'NA')
    OR COALESCE(src.Deal_Impression_Goal, 'NA') != COALESCE(tgt.Deal_Impression_Goal, 'NA')
    OR COALESCE(src.deal_start_timestamp_est, 'NA') != COALESCE(tgt.deal_start_timestamp_est, 'NA')
    OR COALESCE(src.deal_end_timestamp_est, 'NA') != COALESCE(tgt.deal_end_timestamp_est, 'NA')
    LIMIT 1
"""

update_deal_matched_audience_query = """
    MERGE INTO fox_bi_prod.gold_ad_sales.ft_freewheel_matched_audience_daily AS tgt
    USING (
        SELECT DISTINCT
            Deal_ID
            , External_Deal_ID
            , Deal_Name
            , Deal_Type
            , deal_override_priority
            , Deal_Salesperson
            , Deal_Impression_Goal
            , deal_start_timestamp_est
            , deal_end_timestamp_est
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_deal
        WHERE etl_updated_at_timestamp_utc >= current_date() - 7
    ) AS src
    ON tgt.Deal_ID = src.Deal_ID
    WHEN MATCHED AND (
        COALESCE(src.External_Deal_ID, 'NA') != COALESCE(tgt.External_Deal_ID, 'NA')
        OR COALESCE(src.Deal_Name, 'NA') != COALESCE(tgt.Deal_Name, 'NA')
        OR COALESCE(src.Deal_Type, 'NA') != COALESCE(tgt.Deal_Type, 'NA')
        OR COALESCE(src.Deal_Salesperson, 'NA') != COALESCE(tgt.Deal_Salesperson, 'NA')
        OR COALESCE(src.Deal_Impression_Goal, 'NA') != COALESCE(tgt.Deal_Impression_Goal, 'NA')
        OR COALESCE(src.deal_start_timestamp_est, 'NA') != COALESCE(tgt.deal_start_timestamp_est, 'NA')
        OR COALESCE(src.deal_end_timestamp_est, 'NA') != COALESCE(tgt.deal_end_timestamp_est, 'NA')
    )
    THEN UPDATE SET
        tgt.External_Deal_ID = src.External_Deal_ID
        , tgt.Deal_Name = src.Deal_Name
        , tgt.Deal_Type = src.Deal_Type
        , tgt.Deal_Salesperson = src.Deal_Salesperson
        , tgt.Deal_Impression_Goal = src.Deal_Impression_Goal
        , tgt.deal_start_timestamp_est = src.deal_start_timestamp_est
        , tgt.deal_end_timestamp_est = src.deal_end_timestamp_est
"""


# COMMAND ----------

check_updates_insertion_order_matched_audience_query = """
    SELECT 1
    FROM fox_bi_prod.gold_ad_sales.ft_freewheel_matched_audience_daily AS tgt
    INNER JOIN (
        SELECT DISTINCT
            Insertion_Order_Id
            , Insertion_Order_Name
            , insertion_order_external_id
            , insertion_order_end_timestamp_est
            , insertion_order_primary_salesperson
            , insertion_order_primary_trafficker
            , insertion_order_start_timestamp_est
            , insertion_order_status
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_insertion_order
        WHERE etl_updated_at_timestamp_utc >= CURRENT_DATE() - 7
    ) AS src
    ON tgt.Insertion_Order_Id = src.Insertion_Order_Id
    WHERE COALESCE(src.Insertion_Order_Name, 'NA') != COALESCE(tgt.Insertion_Order_Name, 'NA')
    OR COALESCE(src.insertion_order_external_id, 'NA') != COALESCE(tgt.insertion_order_external_id, 'NA')
    OR COALESCE(src.insertion_order_end_timestamp_est, 'NA') != COALESCE(tgt.insertion_order_end_timestamp_est, 'NA')
    OR COALESCE(src.insertion_order_primary_salesperson, 'NA') != COALESCE(tgt.insertion_order_primary_salesperson, 'NA')
    OR COALESCE(src.insertion_order_primary_trafficker, 'NA') != COALESCE(tgt.insertion_order_primary_trafficker, 'NA')
    OR COALESCE(src.insertion_order_start_timestamp_est, 'NA') != COALESCE(tgt.insertion_order_start_timestamp_est, 'NA')
    OR COALESCE(src.insertion_order_status, 'NA') != COALESCE(tgt.insertion_order_status, 'NA')
    LIMIT 1
"""

update_insertion_order_matched_audience_query = """
    MERGE INTO fox_bi_prod.gold_ad_sales.ft_freewheel_matched_audience_daily AS tgt
    USING (
        SELECT DISTINCT
            Insertion_Order_Id
            , Insertion_Order_Name
            , insertion_order_external_id
            , insertion_order_end_timestamp_est
            , insertion_order_primary_salesperson
            , insertion_order_primary_trafficker
            , insertion_order_start_timestamp_est
            , insertion_order_status
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_insertion_order
        WHERE etl_updated_at_timestamp_utc >= current_date() - 7
    ) AS src
    ON tgt.Insertion_Order_Id = src.Insertion_Order_Id
    WHEN MATCHED AND (
        COALESCE(src.Insertion_Order_Name, 'NA') != COALESCE(tgt.Insertion_Order_Name, 'NA')
        OR COALESCE(src.insertion_order_external_id, 'NA') != COALESCE(tgt.insertion_order_external_id, 'NA')
        OR COALESCE(src.insertion_order_end_timestamp_est, 'NA') != COALESCE(tgt.insertion_order_end_timestamp_est, 'NA')
        OR COALESCE(src.insertion_order_primary_salesperson, 'NA') != COALESCE(tgt.insertion_order_primary_salesperson, 'NA')
        OR COALESCE(src.insertion_order_primary_trafficker, 'NA') != COALESCE(tgt.insertion_order_primary_trafficker, 'NA')
        OR COALESCE(src.insertion_order_start_timestamp_est, 'NA') != COALESCE(tgt.insertion_order_start_timestamp_est, 'NA')
        OR COALESCE(src.insertion_order_status, 'NA') != COALESCE(tgt.insertion_order_status, 'NA')
    )
    THEN UPDATE SET
        tgt.Insertion_Order_Name = src.Insertion_Order_Name
        , tgt.insertion_order_external_id = src.insertion_order_external_id
        , tgt.insertion_order_end_timestamp_est = src.insertion_order_end_timestamp_est
        , tgt.insertion_order_primary_salesperson = src.insertion_order_primary_salesperson
        , tgt.insertion_order_primary_trafficker = src.insertion_order_primary_trafficker
        , tgt.insertion_order_start_timestamp_est = src.insertion_order_start_timestamp_est
        , tgt.insertion_order_status = src.insertion_order_status
"""


# COMMAND ----------

check_updates_mrm_rule_matched_audience_query = """
    SELECT 1
    FROM fox_bi_prod.gold_ad_sales.ft_freewheel_matched_audience_daily AS tgt
    INNER JOIN (
        SELECT DISTINCT
            MRM_Rule_ID
            , MRM_Rule_Name
            , mrm_rule_impression_goal
            , mrm_rule_start_timestamp_est
            , mrm_rule_end_timestamp_est
            , Priority_Setting
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_mrm_rule
        WHERE etl_updated_at_timestamp_utc >= CURRENT_DATE() - 7
    ) AS src
    ON tgt.MRM_Rule_ID = src.MRM_Rule_ID
    WHERE COALESCE(src.MRM_Rule_Name, 'NA') != COALESCE(tgt.MRM_Rule_Name, 'NA')
    OR COALESCE(src.mrm_rule_impression_goal, 'NA') != COALESCE(tgt.mrm_rule_impression_goal, 'NA')
    OR COALESCE(src.mrm_rule_start_timestamp_est, 'NA') != COALESCE(tgt.mrm_rule_start_timestamp_est, 'NA')
    OR COALESCE(src.mrm_rule_end_timestamp_est, 'NA') != COALESCE(tgt.mrm_rule_end_timestamp_est, 'NA')
    OR COALESCE(src.Priority_Setting, 'NA') != COALESCE(tgt.Priority_Setting, 'NA')
    LIMIT 1
"""

update_mrm_rule_matched_audience_query = """
    MERGE INTO fox_bi_prod.gold_ad_sales.ft_freewheel_matched_audience_daily AS tgt
    USING (
        SELECT DISTINCT
            MRM_Rule_ID
            , MRM_Rule_Name
            , mrm_rule_impression_goal
            , mrm_rule_start_timestamp_est
            , mrm_rule_end_timestamp_est
            , Priority_Setting
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_mrm_rule
        WHERE etl_updated_at_timestamp_utc >= current_date() - 7
    ) AS src
    ON tgt.MRM_Rule_ID = src.MRM_Rule_ID
    WHEN MATCHED AND (
        COALESCE(src.MRM_Rule_Name, 'NA') != COALESCE(tgt.MRM_Rule_Name, 'NA')
        OR COALESCE(src.mrm_rule_impression_goal, 'NA') != COALESCE(tgt.mrm_rule_impression_goal, 'NA')
        OR COALESCE(src.mrm_rule_start_timestamp_est, 'NA') != COALESCE(tgt.mrm_rule_start_timestamp_est, 'NA')
        OR COALESCE(src.mrm_rule_end_timestamp_est, 'NA') != COALESCE(tgt.mrm_rule_end_timestamp_est, 'NA')
        OR COALESCE(src.Priority_Setting, 'NA') != COALESCE(tgt.Priority_Setting, 'NA')
    )
    THEN UPDATE SET
        tgt.MRM_Rule_Name = src.MRM_Rule_Name
        , tgt.mrm_rule_impression_goal = src.mrm_rule_impression_goal
        , tgt.mrm_rule_start_timestamp_est = src.mrm_rule_start_timestamp_est
        , tgt.mrm_rule_end_timestamp_est = src.mrm_rule_end_timestamp_est
        , tgt.Priority_Setting = src.Priority_Setting
"""


# COMMAND ----------

check_updates_placement_matched_audience_query = """
    SELECT 1
    FROM fox_bi_prod.gold_ad_sales.ft_freewheel_matched_audience_daily AS tgt
    INNER JOIN (
        SELECT DISTINCT
            Placement_ID
            , Placement_External_ID
            , Placement_Name
            , Placement_Budgeted_Impressions
            , placement_start_timestamp_est
            , placement_end_timestamp_est
            , Placement_Industry
            , Placement_Status
            , Placement_Type
            , Unified_Yield_Name AS Unified_Yield
            , placement_booked_on_target_impression_goal AS Booked_On_Target_Impression_Goal
            , placement_budget_model AS Budget_Model
            , placement_demographic_on_target_calculation AS Demographic_On_Target_Calculation
            , placement_demographic_data_source AS Demographic_Data_Source
            , placement_forced_over_delivery_percent AS Forced_Over_Delivery_Percent
            , placement_impression_goal AS Impression_Goal
            , placement_pacing AS Delivery_Pacing
            , placement_priority AS delivery_priority
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_placement
        WHERE etl_updated_at_timestamp_utc >= CURRENT_DATE() - 7
    ) AS src
    ON tgt.placement_id = src.placement_id
    WHERE COALESCE(src.Placement_External_ID, 'NA') != COALESCE(tgt.Placement_External_ID, 'NA')
    OR COALESCE(src.Placement_Name, 'NA') != COALESCE(tgt.Placement_Name, 'NA')
    OR COALESCE(src.Placement_Budgeted_Impressions, 'NA') != COALESCE(tgt.Placement_Budgeted_Impressions, 'NA')
    OR COALESCE(src.placement_start_timestamp_est, 'NA') != COALESCE(tgt.placement_start_timestamp_est, 'NA')
    OR COALESCE(src.placement_end_timestamp_est, 'NA') != COALESCE(tgt.placement_end_timestamp_est, 'NA')
    OR COALESCE(src.Placement_Industry, 'NA') != COALESCE(tgt.Placement_Industry, 'NA')
    OR COALESCE(src.Placement_Status, 'NA') != COALESCE(tgt.Placement_Status, 'NA')
    OR COALESCE(src.Placement_Type, 'NA') != COALESCE(tgt.Placement_Type, 'NA')
    OR COALESCE(src.Unified_Yield, 'NA') != COALESCE(tgt.Unified_Yield, 'NA')
    OR COALESCE(src.Booked_On_Target_Impression_Goal, 'NA') != COALESCE(tgt.Booked_On_Target_Impression_Goal, 'NA')
    OR COALESCE(src.Budget_Model, 'NA') != COALESCE(tgt.Budget_Model, 'NA')
    OR COALESCE(src.Demographic_On_Target_Calculation, 'NA') != COALESCE(tgt.Demographic_On_Target_Calculation, 'NA')
    OR COALESCE(src.Demographic_Data_Source, 'NA') != COALESCE(tgt.Demographic_Data_Source, 'NA')
    OR COALESCE(src.Forced_Over_Delivery_Percent, 'NA') != COALESCE(tgt.Forced_Over_Delivery_Percent, 'NA')
    OR COALESCE(src.Impression_Goal, 'NA') != COALESCE(tgt.Impression_Goal, 'NA')
    OR COALESCE(src.Delivery_Pacing, 'NA') != COALESCE(tgt.Delivery_Pacing, 'NA')
    OR COALESCE(src.delivery_priority, 'NA') != COALESCE(tgt.delivery_priority, 'NA')
    LIMIT 1
"""

update_placement_matched_audience_query = """
    MERGE INTO fox_bi_prod.gold_ad_sales.ft_freewheel_matched_audience_daily AS tgt
    USING (
        SELECT DISTINCT
            Placement_ID
            , Placement_External_ID
            , Placement_Name
            , Placement_Budgeted_Impressions
            , placement_start_timestamp_est
            , placement_end_timestamp_est
            , Placement_Industry
            , Placement_Status
            , Placement_Type
            , Unified_Yield_Name Unified_Yield
            , placement_booked_on_target_impression_goal AS Booked_On_Target_Impression_Goal
            , placement_budget_model AS Budget_Model
            , placement_demographic_on_target_calculation AS Demographic_On_Target_Calculation
            , placement_demographic_data_source AS Demographic_Data_Source
            , placement_forced_over_delivery_percent AS Forced_Over_Delivery_Percent
            , placement_impression_goal AS Impression_Goal
            , placement_pacing AS Delivery_Pacing
            , placement_priority AS delivery_priority
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_placement
        WHERE etl_updated_at_timestamp_utc >= current_date() - 7
    ) AS src
    ON tgt.placement_id = src.placement_id
    WHEN MATCHED AND (
        COALESCE(src.Placement_External_ID, 'NA') != COALESCE(tgt.Placement_External_ID, 'NA')
        OR COALESCE(src.Placement_Name, 'NA') != COALESCE(tgt.Placement_Name, 'NA')
        OR COALESCE(src.Placement_Budgeted_Impressions, 'NA') != COALESCE(tgt.Placement_Budgeted_Impressions, 'NA')
        OR COALESCE(src.placement_start_timestamp_est, 'NA') != COALESCE(tgt.placement_start_timestamp_est, 'NA')
        OR COALESCE(src.placement_end_timestamp_est, 'NA') != COALESCE(tgt.placement_end_timestamp_est, 'NA')
        OR COALESCE(src.Placement_Industry, 'NA') != COALESCE(tgt.Placement_Industry, 'NA')
        OR COALESCE(src.Placement_Status, 'NA') != COALESCE(tgt.Placement_Status, 'NA')
        OR COALESCE(src.Placement_Type, 'NA') != COALESCE(tgt.Placement_Type, 'NA')
        OR COALESCE(src.Unified_Yield, 'NA') != COALESCE(tgt.Unified_Yield, 'NA')
        OR COALESCE(src.Booked_On_Target_Impression_Goal, 'NA') != COALESCE(tgt.Booked_On_Target_Impression_Goal, 'NA')
        OR COALESCE(src.Budget_Model, 'NA') != COALESCE(tgt.Budget_Model, 'NA')
        OR COALESCE(src.Demographic_On_Target_Calculation, 'NA') != COALESCE(tgt.Demographic_On_Target_Calculation, 'NA')
        OR COALESCE(src.Demographic_Data_Source, 'NA') != COALESCE(tgt.Demographic_Data_Source, 'NA')
        OR COALESCE(src.Forced_Over_Delivery_Percent, 'NA') != COALESCE(tgt.Forced_Over_Delivery_Percent, 'NA')
        OR COALESCE(src.Impression_Goal, 'NA') != COALESCE(tgt.Impression_Goal, 'NA')
        OR COALESCE(src.Delivery_Pacing, 'NA') != COALESCE(tgt.Delivery_Pacing, 'NA')
        OR COALESCE(src.delivery_priority, 'NA') != COALESCE(tgt.delivery_priority, 'NA')
    )
    THEN UPDATE SET
        tgt.Placement_External_ID = src.Placement_External_ID
        , tgt.Placement_Name = src.Placement_Name
        , tgt.Placement_Budgeted_Impressions = src.Placement_Budgeted_Impressions
        , tgt.placement_start_timestamp_est = src.placement_start_timestamp_est
        , tgt.placement_end_timestamp_est = src.placement_end_timestamp_est
        , tgt.Placement_Industry = src.Placement_Industry
        , tgt.Placement_Status = src.Placement_Status
        , tgt.Placement_Type = src.Placement_Type
        , tgt.Unified_Yield = src.Unified_Yield
        , tgt.Booked_On_Target_Impression_Goal = src.Booked_On_Target_Impression_Goal
        , tgt.Budget_Model = src.Budget_Model
        , tgt.Demographic_On_Target_Calculation = src.Demographic_On_Target_Calculation
        , tgt.Demographic_Data_Source = src.Demographic_Data_Source
        , tgt.Forced_Over_Delivery_Percent = src.Forced_Over_Delivery_Percent
        , tgt.Impression_Goal = src.Impression_Goal
        , tgt.Delivery_Pacing = src.Delivery_Pacing
        , tgt.delivery_priority = src.delivery_priority
"""


# COMMAND ----------

check_updates_programmatic_creative_matched_audience_query = """
    SELECT 1
    FROM fox_bi_prod.gold_ad_sales.ft_freewheel_matched_audience_daily AS tgt
    INNER JOIN (
        SELECT DISTINCT
            Programmatic_Ad_ID
            , Programmatic_Industry_Name
            , Programmatic_Brand_Name
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_programmatic_creative
        WHERE etl_updated_at_timestamp_utc >= CURRENT_DATE() - 7
    ) AS src
    ON tgt.Programmatic_Ad_ID = src.Programmatic_Ad_ID
    WHERE COALESCE(src.Programmatic_Industry_Name, 'NA') != COALESCE(tgt.Programmatic_Industry_Name, 'NA')
    OR COALESCE(src.Programmatic_Brand_Name, 'NA') != COALESCE(tgt.Programmatic_Brand_Name, 'NA')
    LIMIT 1
"""

update_programmatic_creative_matched_audience_query = """
    MERGE INTO fox_bi_prod.gold_ad_sales.ft_freewheel_matched_audience_daily AS tgt
    USING (
        SELECT DISTINCT
            Programmatic_Ad_ID
            , Programmatic_Industry_Name
            , Programmatic_Brand_Name
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_programmatic_creative
        WHERE etl_updated_at_timestamp_utc >= current_date() - 7
    ) AS src
    ON tgt.Programmatic_Ad_ID = src.Programmatic_Ad_ID
    WHEN MATCHED AND (
        COALESCE(src.Programmatic_Industry_Name, 'NA') != COALESCE(tgt.Programmatic_Industry_Name, 'NA')
        OR COALESCE(src.Programmatic_Brand_Name, 'NA') != COALESCE(tgt.Programmatic_Brand_Name, 'NA')
    )
    THEN UPDATE SET
        tgt.Programmatic_Industry_Name = src.Programmatic_Industry_Name
        , tgt.Programmatic_Brand_Name = src.Programmatic_Brand_Name
"""


# COMMAND ----------

check_updates_video_group_matched_audience_query = """
    SELECT 1
    FROM fox_bi_prod.gold_ad_sales.ft_freewheel_matched_audience_daily AS tgt
    INNER JOIN (
        SELECT DISTINCT
            Video_ID
            , Video_Name
            , primary_video_group_id
            , primary_video_group_name
            , secondary_video_group_id
            , secondary_video_group_name
            , season_video_group_id
            , season_video_group_Name
            , prefered_video_group
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_video_group_custom
        WHERE etl_updated_at_timestamp_utc >= CURRENT_DATE() - 7
    ) AS src
    ON tgt.Video_ID = src.Video_ID
    WHERE COALESCE(src.Video_Name, 'NA') != COALESCE(tgt.Video_Name, 'NA')
    OR COALESCE(src.primary_video_group_id, 'NA') != COALESCE(tgt.primary_video_group_id, 'NA')
    OR COALESCE(src.primary_video_group_name, 'NA') != COALESCE(tgt.primary_video_group_name, 'NA')
    OR COALESCE(src.Prefered_Video_Group, 'NA') != COALESCE(tgt.Prefered_Video_Group, 'NA')
    OR COALESCE(src.secondary_video_group_id, 'NA') != COALESCE(tgt.secondary_video_group_id, 'NA')
    OR COALESCE(src.secondary_video_group_name, 'NA') != COALESCE(tgt.secondary_video_group_name, 'NA')
    OR COALESCE(src.season_video_group_id, 'NA') != COALESCE(tgt.season_video_group_id, 'NA')
    OR COALESCE(src.season_video_group_Name, 'NA') != COALESCE(tgt.season_video_group_Name, 'NA')
    LIMIT 1
"""

update_video_group_matched_audience_query = """
    MERGE INTO fox_bi_prod.gold_ad_sales.ft_freewheel_matched_audience_daily AS tgt
    USING (
        SELECT DISTINCT
            Video_ID
            , Video_Name
            , primary_video_group_id
            , primary_video_group_name
            , secondary_video_group_id
            , secondary_video_group_name
            , season_video_group_id
            , season_video_group_Name
            , prefered_video_group
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_video_group_custom
        WHERE etl_updated_at_timestamp_utc >= current_date() - 7
    ) AS src
    ON tgt.Video_ID = src.Video_ID
    WHEN MATCHED AND (
        COALESCE(src.Video_Name, 'NA') != COALESCE(tgt.Video_Name, 'NA')
        OR COALESCE(src.primary_video_group_id, 'NA') != COALESCE(tgt.primary_video_group_id, 'NA')
        OR COALESCE(src.primary_video_group_name, 'NA') != COALESCE(tgt.primary_video_group_name, 'NA')
        OR COALESCE(src.Prefered_Video_Group, 'NA') != COALESCE(tgt.Prefered_Video_Group, 'NA')
        OR COALESCE(src.secondary_video_group_id, 'NA') != COALESCE(tgt.secondary_video_group_id, 'NA')
        OR COALESCE(src.secondary_video_group_name, 'NA') != COALESCE(tgt.secondary_video_group_name, 'NA')
        OR COALESCE(src.season_video_group_id, 'NA') != COALESCE(tgt.season_video_group_id, 'NA')
        OR COALESCE(src.season_video_group_Name, 'NA') != COALESCE(tgt.season_video_group_Name, 'NA')
    )
    THEN UPDATE SET
        tgt.Video_Name = src.Video_Name
        , tgt.primary_video_group_id = src.primary_video_group_id
        , tgt.primary_video_group_name = src.primary_video_group_name
        , tgt.Prefered_Video_Group = src.Prefered_Video_Group
        , tgt.secondary_video_group_id = src.secondary_video_group_id
        , tgt.secondary_video_group_name = src.secondary_video_group_name
        , tgt.season_video_group_id = src.season_video_group_id
        , tgt.season_video_group_name = src.season_video_group_name
"""


# COMMAND ----------

check_updates_agency_name_matched_audience_query = """
    SELECT 1
    FROM fox_bi_prod.gold_ad_sales.ft_freewheel_matched_audience_daily tgt
    INNER JOIN (
        WITH fw_cmp_agn AS (
            SELECT
                campaign_id
            FROM fox_bi_prod.gold_ad_sales.ft_freewheel_matched_audience_daily
            GROUP BY campaign_id
            HAVING COUNT(DISTINCT agency_name) > 1
        )
        SELECT
            campaign_id
            , agency_name
            , MIN(event_date) AS first_event
            , MAX(event_date) AS b
        FROM fox_bi_prod.gold_ad_sales.ft_freewheel_matched_audience_daily
        WHERE campaign_id IN (
            SELECT
                campaign_id
            FROM fw_cmp_agn
        )
        GROUP BY campaign_id, agency_name
        QUALIFY ROW_NUMBER() OVER (PARTITION BY campaign_id ORDER BY first_event DESC) = 1
    ) AS src
    ON tgt.campaign_id = src.campaign_id
    WHERE COALESCE(tgt.agency_name, 'NA') <> COALESCE(src.agency_name, 'NA')
    LIMIT 1
"""

update_agency_name_matched_audience_query = """
    MERGE INTO fox_bi_prod.gold_ad_sales.ft_freewheel_matched_audience_daily AS tgt
    USING (
        WITH fw_cmp_agn AS (
            SELECT
                campaign_id
            FROM fox_bi_prod.gold_ad_sales.ft_freewheel_matched_audience_daily
            GROUP BY campaign_id
            HAVING COUNT(DISTINCT agency_name) > 1
        )
        SELECT
            campaign_id
            , agency_name
            , MIN(event_date) AS first_event
            , MAX(event_date) AS b
        FROM fox_bi_prod.gold_ad_sales.ft_freewheel_matched_audience_daily
        WHERE campaign_id IN (
            SELECT
                campaign_id
            FROM fw_cmp_agn
        )
        GROUP BY campaign_id, agency_name
        QUALIFY ROW_NUMBER() OVER (PARTITION BY campaign_id ORDER BY first_event DESC) = 1
    ) AS src
    ON tgt.campaign_id = src.campaign_id
    WHEN MATCHED AND (
        COALESCE(tgt.agency_name, 'NA') <> COALESCE(src.agency_name, 'NA')
    )
    THEN UPDATE SET
        tgt.agency_name = src.agency_name
"""


# COMMAND ----------

check_updates_advertiser_name_matched_audience_query = """
    SELECT 1
    FROM fox_bi_prod.gold_ad_sales.ft_freewheel_matched_audience_daily tgt
    INNER JOIN (
        WITH fw_cmp_adv AS (
            SELECT
                campaign_id
            FROM fox_bi_prod.gold_ad_sales.ft_freewheel_matched_audience_daily
            GROUP BY campaign_id
            HAVING COUNT(DISTINCT advertiser_name) > 1
        )
        SELECT
            campaign_id
            , advertiser_name
            , MIN(event_date) AS first_event
            , MAX(event_date) AS b
        FROM fox_bi_prod.gold_ad_sales.ft_freewheel_matched_audience_daily
        WHERE campaign_id IN (
            SELECT campaign_id FROM fw_cmp_adv
        )
        GROUP BY campaign_id, advertiser_name
        QUALIFY ROW_NUMBER() OVER (PARTITION BY campaign_id ORDER BY first_event DESC) = 1
    ) AS src
    ON tgt.campaign_id = src.campaign_id
    WHERE COALESCE(tgt.advertiser_name, 'NA') <> COALESCE(src.advertiser_name, 'NA')
    LIMIT 1
"""

update_advertiser_name_matched_audience_query = """
    MERGE INTO fox_bi_prod.gold_ad_sales.ft_freewheel_matched_audience_daily AS tgt
    USING (
        WITH fw_cmp_adv AS (
            SELECT
                campaign_id
            FROM fox_bi_prod.gold_ad_sales.ft_freewheel_matched_audience_daily
            GROUP BY campaign_id
            HAVING COUNT(DISTINCT advertiser_name) > 1
        )
        SELECT
            campaign_id
            , advertiser_name
            , MIN(event_date) AS first_event
            , MAX(event_date) AS b
        FROM fox_bi_prod.gold_ad_sales.ft_freewheel_matched_audience_daily
        WHERE campaign_id IN (
            SELECT campaign_id FROM fw_cmp_adv
        )
        GROUP BY campaign_id, advertiser_name
        QUALIFY ROW_NUMBER() OVER (PARTITION BY campaign_id ORDER BY first_event DESC) = 1
    ) AS src
    ON tgt.campaign_id = src.campaign_id
    WHEN MATCHED AND (
        COALESCE(tgt.advertiser_name, 'NA') <> COALESCE(src.advertiser_name, 'NA')
    )
    THEN UPDATE SET
        tgt.advertiser_name = src.advertiser_name
"""


# COMMAND ----------

check_updates_agency_name_agg_matched_audience_query = """
    SELECT 1
    FROM fox_bi_prod.gold_ad_sales.agg_freewheel_matched_audience_daily tgt
    INNER JOIN (
        WITH fw_pl_agn AS (
            SELECT
                placement_id
            FROM fox_bi_prod.gold_ad_sales.agg_freewheel_matched_audience_daily
            GROUP BY placement_id
            HAVING COUNT(DISTINCT agency_name) > 1
        )
        SELECT
            placement_id
            , agency_name
            , MIN(event_date) AS first_event
            , MAX(event_date) AS b
        FROM fox_bi_prod.gold_ad_sales.agg_freewheel_matched_audience_daily
        WHERE placement_id IN (
            SELECT
                placement_id
            FROM fw_pl_agn
        )
        GROUP BY placement_id, agency_name
        QUALIFY ROW_NUMBER() OVER (PARTITION BY placement_id ORDER BY first_event DESC) = 1
    ) AS src
    ON tgt.placement_id = src.placement_id
    WHERE COALESCE(tgt.agency_name, 'NA') <> COALESCE(src.agency_name, 'NA')
    LIMIT 1
"""

update_agency_name_agg_matched_audience_query = """
    MERGE INTO fox_bi_prod.gold_ad_sales.agg_freewheel_matched_audience_daily AS tgt
    USING (
        WITH fw_pl_agn AS (
            SELECT
                placement_id
            FROM fox_bi_prod.gold_ad_sales.agg_freewheel_matched_audience_daily
            GROUP BY placement_id
            HAVING COUNT(DISTINCT agency_name) > 1
        )
        SELECT
            placement_id
            , agency_name
            , MIN(event_date) AS first_event
            , MAX(event_date) AS b
        FROM fox_bi_prod.gold_ad_sales.agg_freewheel_matched_audience_daily
        WHERE placement_id IN (
            SELECT
                placement_id
            FROM fw_pl_agn
        )
        GROUP BY placement_id, agency_name
        QUALIFY ROW_NUMBER() OVER (PARTITION BY placement_id ORDER BY first_event DESC) = 1
    ) AS src
    ON tgt.placement_id = src.placement_id
    WHEN MATCHED AND (
        COALESCE(tgt.agency_name, 'NA') <> COALESCE(src.agency_name, 'NA')
    )
    THEN UPDATE SET
        tgt.agency_name = src.agency_name
"""


# COMMAND ----------

check_updates_advertiser_name_agg_matched_audience_query = """
    SELECT 1
    FROM fox_bi_prod.gold_ad_sales.agg_freewheel_matched_audience_daily tgt
    INNER JOIN (
        WITH fw_cmp_adv AS (
            SELECT
                placement_id
            FROM fox_bi_prod.gold_ad_sales.agg_freewheel_matched_audience_daily
            GROUP BY placement_id
            HAVING COUNT(DISTINCT advertiser_name) > 1
        )
        SELECT
            placement_id
            , advertiser_name
            , MIN(event_date) AS first_event
            , MAX(event_date) AS b
        FROM fox_bi_prod.gold_ad_sales.agg_freewheel_matched_audience_daily
        WHERE placement_id IN (
            SELECT placement_id FROM fw_cmp_adv
        )
        GROUP BY placement_id, advertiser_name
        QUALIFY ROW_NUMBER() OVER (PARTITION BY placement_id ORDER BY first_event DESC) = 1
    ) AS src
    ON tgt.placement_id = src.placement_id
    WHERE COALESCE(tgt.advertiser_name, 'NA') <> COALESCE(src.advertiser_name, 'NA')
    LIMIT 1
"""

update_advertiser_name_agg_matched_audience_query = """
    MERGE INTO fox_bi_prod.gold_ad_sales.agg_freewheel_matched_audience_daily AS tgt
    USING (
        WITH fw_cmp_adv AS (
            SELECT
                placement_id
            FROM fox_bi_prod.gold_ad_sales.agg_freewheel_matched_audience_daily
            GROUP BY placement_id
            HAVING COUNT(DISTINCT advertiser_name) > 1
        )
        SELECT
            placement_id
            , advertiser_name
            , MIN(event_date) AS first_event
            , MAX(event_date) AS b
        FROM fox_bi_prod.gold_ad_sales.agg_freewheel_matched_audience_daily
        WHERE placement_id IN (
            SELECT placement_id FROM fw_cmp_adv
        )
        GROUP BY placement_id, advertiser_name
        QUALIFY ROW_NUMBER() OVER (PARTITION BY placement_id ORDER BY first_event DESC) = 1
    ) AS src
    ON tgt.placement_id = src.placement_id
    WHEN MATCHED AND (
        COALESCE(tgt.advertiser_name, 'NA') <> COALESCE(src.advertiser_name, 'NA')
    )
    THEN UPDATE SET
        tgt.advertiser_name = src.advertiser_name
"""

# COMMAND ----------

updated_series_capacity = spark.sql(check_updates_capacity_series_query)
if updated_series_capacity.count() > 0:
    print('Changes detected in series dimension for capacity')
    spark.sql(update_series_capacity_query)
else:
    print('No changes detected in series dimension for capacity')

updated_series_delivery = spark.sql(check_updates_delivery_series_query)
if updated_series_delivery.count() > 0:
    print('Changes detected in series dimension for delivery')
    spark.sql(update_series_delivery_query)
else:
    print('No changes detected in series dimension for delivery')

updated_series_matched_audience = spark.sql(check_updates_matched_audience_series_query)
if updated_series_matched_audience.count() > 0:
    print('Changes detected in series dimension for matched audience')
    spark.sql(update_series_matched_audience_query)
else:
    print('No changes detected in series dimension for matched audience')

updated_campaigns_delivery = spark.sql(check_updates_campaign_delivery_query)
if updated_campaigns_delivery.count() > 0:
    print('Changes detected in campaign dimension for delivery')
    spark.sql(update_campaign_delivery_query)
else:
    print('No changes detected in campaign dimension for delivery')

updated_placements_delivery = spark.sql(check_updates_placement_delivery_query)
if updated_placements_delivery.count() > 0:
    print('Changes detected in placement dimension for delivery')
    spark.sql(update_placement_delivery_query)
else:
    print('No changes detected in placement dimension for delivery')

updated_mrm_rule_delivery = spark.sql(check_updates_mrm_rule_delivery_query)
if updated_mrm_rule_delivery.count() > 0:
    print('Changes detected in mrm rule dimension for delivery')
    spark.sql(update_mrm_rule_delivery_query)
else:
    print('No changes detected in mrm rule dimension for delivery')

updated_sold_order_delivery = spark.sql(check_updates_sold_order_delivery_query)
if updated_sold_order_delivery.count() > 0:
    print('Changes detected in sold order dimension for delivery')
    spark.sql(update_sold_order_delivery_query)
else:
    print('No changes detected in sold order dimension for delivery')

updated_exchange_listing_delivery = spark.sql(check_updates_exchange_listing_delivery_query)
if updated_exchange_listing_delivery.count() > 0:
    print('Changes detected in exchange listing dimension for delivery')
    spark.sql(update_exchange_listing_delivery_query)
else:
    print('No changes detected in exchange listing dimension for delivery')

updated_deals_delivery = spark.sql(check_updates_deal_delivery_query)
if updated_deals_delivery.count() > 0:
    print('Changes detected in deal dimension for delivery')
    spark.sql(update_deal_delivery_query)
else:
    print('No changes detected in deal dimension for delivery')

print('Running updates in foxipedia titles for capacity')
spark.sql(update_matched_titles_capacity_query)

print('Running updates in foxipedia titles for delivery')
spark.sql(update_matched_titles_delivery_query)

print('Running updates in video vertical for capacity')
spark.sql(update_video_vertical_capacity_query)

print('Running updates in video vertical for delivery')
spark.sql(update_video_vertical_delivery_query)

print('Running updates in video vertical for matched audience')
spark.sql(update_video_vertical_matched_audience_query)

print('Running updates in demo comp for delivery')
spark.sql(update_demo_comp_delivery_query)

updated_agency_names_delivery = spark.sql(check_updates_agency_name_delivery_query)
if updated_agency_names_delivery.count() > 0:
    print('Changes detected in agency name for delivery')
    spark.sql(update_agency_name_delivery_query)
else:
    print('No changes detected in agency name for delivery')

updated_advertiser_names_delivery = spark.sql(check_updates_advertiser_name_delivery_query)
if updated_advertiser_names_delivery.count() > 0:
    print('Changes detected in advertiser name for delivery')
    spark.sql(update_advertiser_name_delivery_query)
else:
    print('No changes detected in advertiser name for delivery')

from datetime import datetime
if datetime.now().weekday() >= 5:
    updated_site_sections_capacity = spark.sql(check_updates_site_section_capacity_query)
    if updated_site_sections_capacity.count() > 0:
        print('Changes detected in site section dimension for capacity')
        spark.sql(update_site_section_capacity_query)
    else:
        print('No changes detected in site section dimension for capacity')

    updated_video_groups_capacity = spark.sql(check_updates_video_group_capacity_query)
    if updated_video_groups_capacity.count() > 0:
        print('Changes detected in video group dimension for capacity')
        spark.sql(update_video_group_capacity_query)
    else:
        print('No changes detected in video group dimension for capacity')

    updated_ad_units_delivery = spark.sql(check_updates_ad_unit_delivery_query)
    if updated_ad_units_delivery.count() > 0:
        print('Changes detected in ad unit dimension for delivery')
        spark.sql(update_ad_unit_delivery_query)
    else:
        print('No changes detected in ad unit dimension for delivery')

    updated_creatives_delivery = spark.sql(check_updates_creative_delivery_query)
    if updated_creatives_delivery.count() > 0:
        print('Changes detected in creative dimension for delivery')
        spark.sql(update_creative_delivery_query)
    else:
        print('No changes detected in creative dimension for delivery')

    updated_insertion_orders_delivery = spark.sql(check_updates_insertion_order_delivery_query)
    if updated_insertion_orders_delivery.count() > 0:
        print('Changes detected in insertion order dimension for delivery')
        spark.sql(update_insertion_order_delivery_query)
    else:
        print('No changes detected in insertion order dimension for delivery')

    updated_programmatic_creatives_delivery = spark.sql(check_updates_programmatic_creative_delivery_query)
    if updated_programmatic_creatives_delivery.count() > 0:
        print('Changes detected in programmatic creative dimension for delivery')
        spark.sql(update_programmatic_creative_delivery_query)
    else:
        print('No changes detected in programmatic creative dimension for delivery')

    updated_site_sections_delivery = spark.sql(check_updates_site_section_delivery_query)
    if updated_site_sections_delivery.count() > 0:
        print('Changes detected in site section dimension for delivery')
        spark.sql(update_site_section_delivery_query)
    else:
        print('No changes detected in site section dimension for delivery')

    updated_video_groups_delivery = spark.sql(check_updates_video_group_delivery_query)
    if updated_video_groups_delivery.count() > 0:
        print('Changes detected in video group dimension for delivery')
        spark.sql(update_video_group_delivery_query)
    else:
        print('No changes detected in video group dimension for delivery')

    updated_ad_units_matched_audience = spark.sql(check_updates_ad_unit_matched_audience_query)
    if updated_ad_units_matched_audience.count() > 0:
        print('Changes detected in ad unit dimension for matched audience')
        spark.sql(update_ad_unit_matched_audience_query)
    else:
        print('No changes detected in ad unit dimension for matched audience')

    updated_campaigns_matched_audience = spark.sql(check_updates_campaign_matched_audience_query)
    if updated_campaigns_matched_audience.count() > 0:
        print('Changes detected in campaign dimension for matched audience')
        spark.sql(update_campaign_matched_audience_query)
    else:
        print('No changes detected in campaign dimension for matched audience')

    updated_creatives_matched_audience = spark.sql(check_updates_creative_matched_audience_query)
    if updated_creatives_matched_audience.count() > 0:
        print('Changes detected in creative dimension for matched audience')
        spark.sql(update_creative_matched_audience_query)
    else:
        print('No changes detected in creative dimension for matched audience')

    updated_deals_matched_audience = spark.sql(check_updates_deal_matched_audience_query)
    if updated_deals_matched_audience.count() > 0:
        print('Changes detected in deal dimension for matched audience')
        spark.sql(update_deal_matched_audience_query)
    else:
        print('No changes detected in deal dimension for matched audience')

    updated_insertion_orders_matched_audience = spark.sql(check_updates_insertion_order_matched_audience_query)
    if updated_insertion_orders_matched_audience.count() > 0:
        print('Changes detected in insertion order dimension for matched audience')
        spark.sql(update_insertion_order_matched_audience_query)
    else:
        print('No changes detected in insertion order dimension for matched audience')

    updated_mrm_rule_matched_audience = spark.sql(check_updates_mrm_rule_matched_audience_query)
    if updated_mrm_rule_matched_audience.count() > 0:
        print('Changes detected in mrm rule dimension for matched audience')
        spark.sql(update_mrm_rule_matched_audience_query)
    else:
        print('No changes detected in mrm rule dimension for matched audience')

    updated_placements_matched_audience = spark.sql(check_updates_placement_matched_audience_query)
    if updated_placements_matched_audience.count() > 0:
        print('Changes detected in placement dimension for matched audience')
        spark.sql(update_placement_matched_audience_query)
    else:
        print('No changes detected in placement dimension for matched audience')

    updated_programmatic_creatives_matched_audience = spark.sql(check_updates_programmatic_creative_matched_audience_query)
    if updated_programmatic_creatives_matched_audience.count() > 0:
        print('Changes detected in programmatic creative dimension for matched audience')
        spark.sql(update_programmatic_creative_matched_audience_query)
    else:
        print('No changes detected in programmatic creative dimension for matched audience')

    updated_video_groups_matched_audience = spark.sql(check_updates_video_group_matched_audience_query)
    if updated_video_groups_matched_audience.count() > 0:
        print('Changes detected in video group dimension for matched audience')
        spark.sql(update_video_group_matched_audience_query)
    else:
        print('No changes detected in video group dimension for matched audience')

    updated_agency_names_matched_audience = spark.sql(check_updates_agency_name_matched_audience_query)
    if updated_agency_names_matched_audience.count() > 0:
        print('Changes detected in agency name for matched audience')
        spark.sql(update_agency_name_matched_audience_query)
    else:
        print('No changes detected in agency name for matched audience')

    updated_advertiser_names_matched_audience = spark.sql(check_updates_advertiser_name_matched_audience_query)
    if updated_advertiser_names_matched_audience.count() > 0:
        print('Changes detected in advertiser name for matched audience')
        spark.sql(update_advertiser_name_matched_audience_query)
    else:
        print('No changes detected in advertiser name for matched audience')

    updated_agency_names_agg_matched_audience = spark.sql(check_updates_agency_name_agg_matched_audience_query)
    if updated_agency_names_agg_matched_audience.count() > 0:
        print('Changes detected in agency name for agg matched audience')
        spark.sql(update_agency_name_agg_matched_audience_query)
    else:
        print('No changes detected in agency name for agg matched audience')

    updated_advertiser_names_agg_matched_audience = spark.sql(check_updates_advertiser_name_agg_matched_audience_query)
    if updated_advertiser_names_agg_matched_audience.count() > 0:
        print('Changes detected in advertiser name for agg matched audience')
        spark.sql(update_advertiser_name_agg_matched_audience_query)
    else:
        print('No changes detected in advertiser name for agg matched audience')