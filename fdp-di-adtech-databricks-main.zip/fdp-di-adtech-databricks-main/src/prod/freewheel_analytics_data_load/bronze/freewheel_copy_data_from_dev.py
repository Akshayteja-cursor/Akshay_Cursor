# Databricks notebook source

# COMMAND ----------
mpp = spark.sql("select * from fox_bi_dev.bronze_ads.freewheel_analytics_marketplace_platform_private where event_date = '2025-12-10'")
ds = spark.sql("select * from fox_bi_dev.bronze_ads.freewheel_analytics_direct_sold_delivery where event_date between '2024-07-01' and '2025-09-07'")
pg = spark.sql("select * from fox_bi_dev.bronze_ads.freewheel_analytics_markets_delivery where event_date between '2024-07-01' and '2025-09-07'")
rs = spark.sql("select * from fox_bi_dev.bronze_ads.freewheel_analytics_reseller_delivery where event_date between '2024-07-01' and '2025-06-30'")

mpp.write.format('delta')\
    .mode('overwrite')\
    .option('partitionOverwriteMode', 'dynamic')\
    .saveAsTable('fox_bi_prod.bronze_ads.freewheel_analytics_marketplace_platform_private')

ds.write.format('delta')\
    .mode('overwrite')\
    .option('partitionOverwriteMode', 'dynamic')\
    .saveAsTable('fox_bi_prod.bronze_ads.freewheel_analytics_direct_sold_delivery')

pg.write.format('delta')\
    .mode('overwrite')\
    .option('partitionOverwriteMode', 'dynamic')\
    .saveAsTable('fox_bi_prod.bronze_ads.freewheel_analytics_markets_delivery')

rs.write.format('delta')\
    .mode('overwrite')\
    .option('partitionOverwriteMode', 'dynamic')\
    .saveAsTable('fox_bi_prod.bronze_ads.freewheel_analytics_reseller_delivery')