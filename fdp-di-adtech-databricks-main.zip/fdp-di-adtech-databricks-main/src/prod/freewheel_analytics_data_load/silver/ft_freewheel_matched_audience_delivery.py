# Databricks notebook source
from pyspark.sql import functions as F
from pyspark.sql import types as T
from datetime import datetime, timedelta

# COMMAND ----------

query = """
    SELECT 
        mds.event_date
        , mds.distributor_name
        , mds.distributor_id
        , mds.site_section_id
        , mds.video_id
        , mds.series_id
        , au.ad_unit_position AS global_ad_unit_position
        , au.ad_unit_class AS global_ad_unit_class
        , 'Video Ads' AS global_ad_unit_category
        , CAST(mds.creative_id AS BIGINT) AS creative_id
        , CAST(mds.ad_unit_id AS BIGINT) AS ad_unit_id
        , CAST(mds.placement_id AS BIGINT) AS placement_id
        , CAST(mds.insertion_order_id AS BIGINT) AS insertion_order_id
        , CAST(mds.campaign_id AS BIGINT) AS campaign_id
        , 'Direct Sold' AS sales_channel_type
        , CAST(NULL AS STRING) AS reseller_name
        , CAST(NULL AS BIGINT) AS reseller_id
        , CAST(NULL AS BIGINT) AS mrm_rule_id
        , COALESCE(adv.advertiser_name, mds.advertiser_name) AS advertiser_name
        , CAST(mds.advertiser_id AS BIGINT) AS advertiser_id
        , mds.agency_name
        , CAST(NULL AS STRING) AS priority_setting
        , CAST(NULL AS STRING) AS dsp_name
        , CAST(NULL AS STRING) AS trading_desk_name
        , CAST(NULL AS STRING) AS buyer_name
        , CAST(NULL AS STRING) AS buyer_priority
        , CAST(NULL AS BIGINT) AS deal_id
        , CAST(NULL AS BIGINT) AS programmatic_ad_id
        , CAST(NULL AS BIGINT) AS programmatic_advertiser_id
        , CAST(NULL AS STRING) AS programmatic_advertiser_name
        , mds.matched_audience_item_name
        , mds.net_counted_ads
        , mds.gross_counted_ads
        , CAST(mds.run_revenue AS DECIMAL(32,7)) AS run_revenue
        , mds.ecpm
        , mds.delivered_clicks
        , mds.measurable_video_ads_quartile_impressions
    FROM fox_bi_prod.bronze_ads.freewheel_analytics_matched_audience_direct_sold_delivery_video_ads mds
    LEFT JOIN fox_bi_prod.silver_ads.dim_freewheel_analytics_ad_unit au
    ON mds.ad_unit_id = au.ad_unit_id
    LEFT JOIN fox_bi_prod.silver_ads.dim_freewheel_analytics_advertiser adv
    ON mds.advertiser_id = adv.advertiser_id
"""

spark.sql(query).createOrReplaceTempView("ft_matched_audience_direct_sold_video_ads")

# COMMAND ----------

query = """
    SELECT 
        mmd.event_date
        , mmd.distributor_name
        , mmd.distributor_id
        , mmd.site_section_id
        , mmd.video_id
        , mmd.series_id
        , mmd.ad_unit_position AS global_ad_unit_position
        , 'Video Ads' AS global_ad_unit_class
        , 'Video Ads' AS global_ad_unit_category
        , CAST(NULL AS BIGINT) AS creative_id
        , CAST(NULL AS BIGINT) AS ad_unit_id
        , CAST(NULL AS BIGINT) AS placement_id
        , CAST(NULL AS BIGINT) AS insertion_order_id
        , CAST(NULL AS BIGINT) AS campaign_id
        , 'Programmatic' AS sales_channel_type
        , CAST(NULL AS STRING) AS reseller_name
        , CAST(NULL AS BIGINT) AS reseller_id
        , CAST(NULL AS BIGINT) AS mrm_rule_id
        , CAST(NULL AS STRING) AS advertiser_name
        , CAST(NULL AS BIGINT) AS advertiser_id
        , CAST(NULL AS STRING) AS agency_name
        , CAST(NULL AS STRING) AS priority_setting
        , mmd.dsp_name
        , mmd.trading_desk_name
        , mmd.invite_buyer_name AS buyer_name
        , mmd.invite_buyer_priority AS buyer_priority
        , CAST(mmd.deal_id AS BIGINT) AS deal_id
        , CAST(mmd.programmatic_ad_id AS BIGINT) AS programmatic_ad_id
        , CAST(mmd.global_advertiser_id AS BIGINT) AS programmatic_advertiser_id
        , mmd.global_advertiser_name AS programmatic_advertiser_name
        , mmd.matched_audience_item_name
        , mmd.net_counted_ads
        , mmd.gross_counted_ads
        , CAST(mmd.run_revenue AS DECIMAL(32,7)) AS run_revenue
        , mmd.ecpm
        , mmd.delivered_clicks
        , CAST(NULL AS BIGINT) AS measurable_video_ads_quartile_impressions
    FROM fox_bi_prod.bronze_ads.freewheel_analytics_matched_audience_markets_delivery mmd
    LEFT JOIN fox_bi_prod.silver_ads.dim_freewheel_analytics_deal dl
    ON mmd.deal_id = dl.deal_id
    LEFT JOIN fox_bi_prod.silver_ads.lkp_freewheel_analytics_deal lkpdl
    ON mmd.deal_id = lkpdl.deal_id
    AND mmd.event_date = lkpdl.event_date
"""

spark.sql(query).createOrReplaceTempView("ft_matched_audience_markets_delivery")

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW ft_fw_matched_audience_delivery AS
# MAGIC SELECT * FROM ft_matched_audience_direct_sold_video_ads
# MAGIC UNION ALL
# MAGIC SELECT * FROM ft_matched_audience_markets_delivery

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW matched_audience_delivery_data AS
# MAGIC SELECT
# MAGIC     /*+ BROADCAST(vs, vc, ss, usvg, svgmo, site, svgio, cr, p, lkpp, io, cmp, mr, lkpmr, dl, lkpdl, pc, pa) */
# MAGIC     ft.event_date
# MAGIC     , vc.primary_video_group_id
# MAGIC     , vc.primary_video_group_name
# MAGIC     , CASE
# MAGIC         WHEN LOWER(vc.secondary_video_group_name) = 'unassigned' AND vc.video_name = 'V: Partner: Youtube TV: FS1 Live' THEN 18830626
# MAGIC         WHEN LOWER(vc.secondary_video_group_name) = 'unassigned' AND vc.video_name = 'V: Partner: Youtube TV: FS2 Live' THEN 18830626
# MAGIC         WHEN LOWER(vc.secondary_video_group_name) = 'unassigned' AND LOWER(ss.show_name) = 'studio shows' THEN 18830626
# MAGIC         ELSE COALESCE(TRY_CAST(usvg.assigned_secondary_video_group_id AS BIGINT), vc.secondary_video_group_id)
# MAGIC     END AS secondary_video_group_id
# MAGIC     , CASE
# MAGIC         WHEN LOWER(vc.secondary_video_group_name) = 'unassigned' AND vc.video_name = 'V: Partner: Youtube TV: FS1 Live' THEN 'VG: SPORTS: Long Form: Talk Shows'
# MAGIC         WHEN LOWER(vc.secondary_video_group_name) = 'unassigned' AND vc.video_name = 'V: Partner: Youtube TV: FS2 Live' THEN 'VG: SPORTS: Long Form: Talk Shows'
# MAGIC         WHEN LOWER(vc.secondary_video_group_name) = 'unassigned' AND LOWER(ss.show_name) = 'studio shows' THEN 'VG: SPORTS: Long Form: Talk Shows'
# MAGIC         ELSE COALESCE(usvg.assigned_secondary_video_group_name, vc.secondary_video_group_name)
# MAGIC     END AS secondary_video_group_name
# MAGIC     , COALESCE(TRY_CAST(svgmo.season_video_group_id AS BIGINT), vc.season_video_group_id) AS season_video_group_id
# MAGIC     , COALESCE(svgmo.season_video_group_name, vc.season_video_group_name) AS season_video_group_name
# MAGIC     , CASE 
# MAGIC         WHEN upper(ft.global_ad_unit_category) = 'DISPLAY ADS' THEN 'Display'
# MAGIC         WHEN LOWER(vs.series_name) LIKE '%deportes%' THEN 'Deportes'
# MAGIC         WHEN vc.primary_video_group_id = '18773867' THEN 'BTN'
# MAGIC         WHEN LOWER(vs.series_name) LIKE '%monarch%' THEN 'Entertainment'
# MAGIC         
# MAGIC         -- Weather Logic
# MAGIC         WHEN LOWER(vs.series_name) LIKE '%fox weather%' 
# MAGIC              OR LOWER(site.site_section_name) LIKE '%fox weather%' THEN 'Weather'
# MAGIC         
# MAGIC         -- News/Business Logic
# MAGIC         WHEN vc.primary_video_group_id IN ('20474534', '20474467')
# MAGIC              OR LOWER(vs.series_name) LIKE '%vs: news%'
# MAGIC              OR LOWER(vs.series_name) LIKE '%vs: fnc%'
# MAGIC              OR LOWER(vs.series_name) LIKE '%vs: fbn%'
# MAGIC              OR LOWER(vs.series_name) LIKE '%: fnc%'
# MAGIC              OR LOWER(vs.series_name) LIKE '%: fbn%'
# MAGIC              OR LOWER(vs.series_name) LIKE '%: fox business%'
# MAGIC              OR LOWER(site.site_section_name) LIKE '%fox news app%'
# MAGIC              OR LOWER(site.site_section_name) LIKE '%fnc%'
# MAGIC              OR LOWER(site.site_section_name) LIKE '%fbn%'
# MAGIC              OR LOWER(site.site_section_name) LIKE '%fox business%' THEN 'News/Business'
# MAGIC         
# MAGIC         -- Fox Nation Logic
# MAGIC         WHEN LOWER(vs.series_name) LIKE '%vs: nation%'
# MAGIC              OR LOWER(site.site_section_name) LIKE '%fox nation%' THEN 'Fox Nation'
# MAGIC         WHEN site.site_section_name LIKE '%Fox One%' AND site.site_section_name LIKE '%Nation%' THEN 'Fox Nation'
# MAGIC         
# MAGIC         WHEN LOWER(site.site_section_name) LIKE '%tmz%' THEN 'TMZ'
# MAGIC         WHEN LOWER(site.site_section_name) LIKE '%outkick app%' THEN 'Outkick'
# MAGIC         WHEN LOWER(vs.series_name) LIKE '%ultimate tag%' THEN 'Entertainment'
# MAGIC         WHEN vc.primary_video_group_id = '18698796' THEN 'Sports SFV'
# MAGIC         
# MAGIC         WHEN vc.primary_video_group_id = '414462094' OR vc.video_name LIKE '%NIVA%' THEN 'NIVA'
# MAGIC         
# MAGIC         -- Sports LFV Logic
# MAGIC         WHEN vc.primary_video_group_id IN ('18698781', '241987048', '241987474')
# MAGIC              OR UPPER(vs.series_name) LIKE '%WWE%'
# MAGIC              OR UPPER(vs.series_name) LIKE '%SMACKDOWN%'
# MAGIC              OR UPPER(vs.series_name) LIKE '%VS: SPORTS%' THEN 'Sports LFV'
# MAGIC         
# MAGIC         -- Entertainment Logic
# MAGIC         WHEN vc.primary_video_group_id = '18652208'
# MAGIC              OR LOWER(site.site_section_name) LIKE '%fox ent%'
# MAGIC              OR LOWER(vs.series_name) LIKE '%vs: ent: fox:%' THEN 'Entertainment'
# MAGIC         
# MAGIC         WHEN vc.primary_video_group_id = '18698699' THEN 'Entertainment SFV'
# MAGIC         
# MAGIC         -- Fox One Cross-Sells
# MAGIC         WHEN site.site_section_name LIKE '%Fox One%' AND site.site_section_name LIKE '%ENT%' THEN 'Entertainment'
# MAGIC         WHEN site.site_section_name LIKE '%Fox One%' AND site.site_section_name LIKE '%Sports%' THEN 'Sports LFV'
# MAGIC         WHEN site.site_section_name LIKE '%Fox One%' AND site.site_section_name LIKE '%Weather%' THEN 'Weather'
# MAGIC         WHEN site.site_section_name LIKE '%Fox One%' AND site.site_section_name LIKE '%Business%' THEN 'News/Business'
# MAGIC         WHEN site.site_section_name LIKE '%Fox One%' AND site.site_section_name LIKE '%Business%' THEN 'News/Business'
# MAGIC         
# MAGIC         -- Tubi Specific Logic
# MAGIC         WHEN UPPER(site.site_section_name) LIKE '%TUBI%' AND vs.series_name = 'Unknown Series' THEN
# MAGIC             CASE 
# MAGIC                 WHEN vc.video_name LIKE '%FOX Entertainment%' THEN 'Entertainment'
# MAGIC                 WHEN LOWER(vc.video_name) LIKE '%gordon ramsay%' THEN 'Entertainment'
# MAGIC                 WHEN LOWER(vc.video_name) LIKE '%masterchef%' THEN 'Entertainment'
# MAGIC                 WHEN LOWER(vc.video_name) LIKE "%hell's kitchen%" THEN 'Entertainment'
# MAGIC                 WHEN LOWER(vc.video_name) LIKE '%masked singer%' THEN 'Entertainment'
# MAGIC                 WHEN vc.video_name LIKE '%FOX Sports%' THEN 'Sports LFV'
# MAGIC                 WHEN vc.video_name LIKE '%FOX News%' THEN 'News/Business'
# MAGIC                 WHEN vc.video_name LIKE '%FOX Weather%' THEN 'Weather'
# MAGIC                 ELSE 'Tubi' -- Default if within Tubi/Unknown but no video match
# MAGIC             END
# MAGIC             
# MAGIC         WHEN vs.series_name = 'Unknown Series' AND LOWER(vc.video_name) LIKE '%masked singer%' THEN 'Entertainment'
# MAGIC         WHEN LOWER(site.site_section_name) LIKE '%tubi%' THEN 'Tubi'
# MAGIC     
# MAGIC         ELSE 'Unassigned'
# MAGIC     END AS video_vertical
# MAGIC     , ft.video_id
# MAGIC     , vc.video_name
# MAGIC     , vc.prefered_video_group
# MAGIC     , ft.distributor_id
# MAGIC     , ft.distributor_name
# MAGIC     , ft.series_id
# MAGIC     , vs.series_name
# MAGIC     , COALESCE(ss.show_name, 'N/A') AS show_name
# MAGIC     , CASE
# MAGIC         WHEN svgio.series_name IS NULL THEN 'Out of Season'
# MAGIC         ELSE 'In Season'
# MAGIC     END AS season_in_out_flag
# MAGIC     , ft.creative_id
# MAGIC     , cr.creative_name
# MAGIC     , cr.creative_duration_secs
# MAGIC     , ft.ad_unit_id
# MAGIC     , au.ad_unit_price
# MAGIC     , au.ad_unit_external_id
# MAGIC     , ft.placement_id
# MAGIC     , p.placement_external_id
# MAGIC     , p.placement_name
# MAGIC     , p.placement_budgeted_impressions
# MAGIC     , p.placement_start_timestamp_est
# MAGIC     , p.placement_end_timestamp_est
# MAGIC     , p.placement_industry
# MAGIC     , p.placement_status
# MAGIC     , p.placement_type
# MAGIC     , p.unified_yield_name AS unified_yield
# MAGIC     , p.placement_booked_on_target_impression_goal AS booked_on_target_impression_goal
# MAGIC     , p.placement_budget_model AS budget_model
# MAGIC     , p.placement_demographic_on_target_calculation AS demographic_on_target_calculation
# MAGIC     , p.placement_demographic_data_source AS demographic_data_source
# MAGIC     , p.placement_forced_over_delivery_percent AS forced_over_delivery_percent
# MAGIC     , p.placement_impression_goal AS impression_goal
# MAGIC     , p.placement_pacing AS delivery_pacing
# MAGIC     , p.placement_estimated_impression_goal AS estimated_impression_goal
# MAGIC     , p.placement_priority AS delivery_priority
# MAGIC     , COALESCE(lkpp.delivery_priority_type_point_in_time, p.placement_priority) AS delivery_priority_point_in_time
# MAGIC     , ft.insertion_order_id
# MAGIC     , io.insertion_order_name
# MAGIC     , io.insertion_order_external_id
# MAGIC     , io.insertion_order_end_timestamp_est
# MAGIC     , io.insertion_order_primary_salesperson
# MAGIC     , io.insertion_order_primary_trafficker
# MAGIC     , io.insertion_order_start_timestamp_est
# MAGIC     , io.insertion_order_status
# MAGIC     , ft.campaign_id
# MAGIC     , cmp.campaign_name
# MAGIC     , cmp.campaign_external_id
# MAGIC     , cmp.campaign_start_timestamp_est
# MAGIC     , cmp.campaign_end_timestamp_est
# MAGIC     , ft.global_ad_unit_position
# MAGIC     , ft.global_ad_unit_class
# MAGIC     , ft.advertiser_name
# MAGIC     , CASE
# MAGIC         WHEN LOWER(ft.sales_channel_type) = 'direct sold' THEN
# MAGIC             CASE
# MAGIC                 WHEN LOWER(ft.advertiser_name) = 'amazon aps' THEN
# MAGIC                     CASE
# MAGIC                         WHEN (io.insertion_order_name LIKE '%Guaranteed%' OR delivery_priority_point_in_time LIKE '%Guaranteed%') THEN 'Programmatic Guaranteed'
# MAGIC                         ELSE 'Backfill'
# MAGIC                     END
# MAGIC                 WHEN TRIM(ft.advertiser_name) IN (SELECT DISTINCT promo_advertiser FROM fox_bi_prod.raw_ads.freewheel_gsheet_map_promo_advertiser) THEN CONCAT('Promo ', delivery_priority_point_in_time)
# MAGIC                 WHEN p.placement_name LIKE '%Amobee%' OR p.placement_name LIKE '%B2B%' THEN 'Programmatic Guaranteed'
# MAGIC                 ELSE CONCAT('Direct ', delivery_priority_point_in_time)
# MAGIC             END
# MAGIC         WHEN LOWER(ft.sales_channel_type) = 'reseller sold' THEN
# MAGIC             CASE
# MAGIC                 WHEN ft.reseller_name LIKE '%Fox Affiliates Live%' THEN 'Affiliates'
# MAGIC                 WHEN mr.mrm_rule_name LIKE '%Inventory Share%' THEN 'Inventory Share'
# MAGIC                 WHEN mr.priority_setting LIKE '%HARD_GUARANTEE%' THEN 'Hard Guaranteed'
# MAGIC                 ELSE 'Backfill'
# MAGIC             END
# MAGIC         WHEN LOWER(ft.sales_channel_type) = 'programmatic' THEN
# MAGIC             CASE
# MAGIC                 WHEN lkpdl.deal_type IN ('DEAL', 'BACKFILL_DEAL', 'Backfill Deal', 'Deal') THEN 'Backfill'
# MAGIC                 WHEN lkpdl.deal_type IN ('FIRST_LOOK_DEAL', 'First Look','Biddable Guaranteed') THEN 'Hard Guaranteed'
# MAGIC                 WHEN lkpdl.deal_type IS NULL THEN
# MAGIC                     CASE 
# MAGIC                       WHEN dl.deal_type IN ('DEAL', 'BACKFILL_DEAL', 'Backfill Deal', 'Deal') THEN 'Backfill'
# MAGIC                       WHEN dl.deal_type IN ('FIRST_LOOK_DEAL', 'First Look', 'Biddable Guaranteed') THEN 'Hard Guaranteed'
# MAGIC                       ELSE 'Programmatic Guaranteed'
# MAGIC             	    END
# MAGIC                 ELSE 'Programmatic Guaranteed'
# MAGIC             END
# MAGIC         ELSE NULL
# MAGIC     END AS delivery_category
# MAGIC     , ft.matched_audience_item_name
# MAGIC     , CASE
# MAGIC         WHEN site.site_section_name LIKE '%: CTV:%' THEN 'CTV'
# MAGIC         WHEN site.site_section_name LIKE '%: STB%' THEN 'STB'
# MAGIC         WHEN site.site_section_name LIKE '%Comcast Production%' THEN 'STB'
# MAGIC         WHEN site.site_section_name LIKE '%: Mobile App:%' THEN 'MB/TB'
# MAGIC         WHEN site.site_section_name LIKE '%Handheld%' THEN 'MB/TB'
# MAGIC         WHEN site.site_section_name LIKE '%Tablet%' THEN 'MB/TB'
# MAGIC         WHEN site.site_section_name LIKE '%: Web%' THEN 'DT'
# MAGIC         WHEN site.site_section_name LIKE '%Desktop%' THEN 'DT'
# MAGIC         ELSE 'Unk'
# MAGIC     END AS device_name
# MAGIC     , CASE
# MAGIC         WHEN site.site_section_name like '%Fox One%' THEN 'Fox One'
# MAGIC         WHEN site.site_section_name like '%foxone%' THEN 'Fox One'
# MAGIC         WHEN site.site_section_name like '%Charter: Programmer VOD%' THEN 'STB VOD'
# MAGIC         WHEN site.site_section_name like '%Cox: Legacy Live%' THEN 'STB VOD'
# MAGIC         WHEN site.site_section_name like '%Cox: Watermark C2%' THEN 'STB VOD'
# MAGIC         WHEN site.site_section_name like '%Comcast%IP STB VOD%' THEN 'STB VOD'
# MAGIC         WHEN site.site_section_name like '%: Canoe%' THEN 'STB VOD'
# MAGIC         WHEN site.site_section_name LIKE '%FNC%' THEN 'FNC'
# MAGIC         WHEN site.site_section_name LIKE '%FBN%' THEN 'FBN'
# MAGIC         WHEN site.site_section_name LIKE '%FOX Nation%' THEN 'FOX Nation'
# MAGIC         WHEN site.site_section_name LIKE '%Hulu%' THEN 'Hulu'
# MAGIC         WHEN site.site_section_name LIKE '%Tubi%' THEN 'Tubi'
# MAGIC         WHEN site.site_section_name LIKE '%: STB%' THEN 'STB VOD'
# MAGIC         WHEN site.site_section_name LIKE '%Comcast Production%' THEN 'STB VOD'
# MAGIC         WHEN site.site_section_name LIKE '%Partner%' THEN 'Off-Platform'
# MAGIC         WHEN site.site_section_name LIKE '%Run Of Site%' THEN 'Off-Platform'
# MAGIC         WHEN site.site_section_name LIKE '%Owned%' THEN 'O&O'
# MAGIC         ELSE 'Other'
# MAGIC      END AS platform_group
# MAGIC     , CASE
# MAGIC         WHEN site.site_section_name LIKE '%:%' THEN
# MAGIC             CASE 
# MAGIC                 WHEN platform_group = 'Off-Platform' THEN SPLIT_PART(site_section_name, ':', 6)
# MAGIC                 ELSE SPLIT_PART(site.site_section_name, ':', 5)
# MAGIC             END
# MAGIC         ELSE 'N/A'
# MAGIC     END AS specific_device
# MAGIC     , CASE
# MAGIC         WHEN site.site_section_name LIKE '%Run Of Site%' THEN
# MAGIC             CASE
# MAGIC                 WHEN site.site_section_name LIKE '%Fubo%' THEN 'FuboTV'
# MAGIC                 ELSE SUBSTRING(site.site_section_name, 34, INSTR(SUBSTRING(site.site_section_name, 34), ' ') - 1)
# MAGIC             END
# MAGIC         WHEN site.site_section_name LIKE '%SS: Owned: %' THEN SUBSTRING(site.site_section_name, 12, INSTR(SUBSTRING(site.site_section_name, 12), ':') - 1)
# MAGIC         WHEN site.site_section_name LIKE '%SS: Partner: %' THEN SUBSTRING(site.site_section_name, 14, INSTR(SUBSTRING(site.site_section_name, 14), ':') - 1)
# MAGIC         ELSE NULL
# MAGIC     END AS platform_name
# MAGIC     , CASE
# MAGIC         WHEN site.site_section_name LIKE '%Live: FOX%' THEN 'T'
# MAGIC         ELSE 'F'
# MAGIC     END AS is_live_fox_ss
# MAGIC     , CASE
# MAGIC         WHEN site.site_section_name LIKE '%VOD%' THEN 'T'
# MAGIC         ELSE 'F'
# MAGIC     END AS is_fep
# MAGIC     , CASE
# MAGIC         WHEN site.site_section_name LIKE '%Live%' THEN 'T'
# MAGIC         ELSE 'F'
# MAGIC     END AS is_go
# MAGIC     , CASE
# MAGIC         WHEN UPPER(site.site_section_name) LIKE '%FOXNOW%' THEN 'Y'
# MAGIC         ELSE 'N'
# MAGIC     END AS is_fox_now
# MAGIC     , CASE WHEN delivery_category = 'Direct Guaranteed' THEN ft.net_counted_ads ELSE 0 END AS direct_guaranteed_impressions
# MAGIC     , CASE WHEN delivery_category = 'Direct Pre-emptible' THEN ft.net_counted_ads ELSE 0 END AS direct_pre_emptible_impressions
# MAGIC     , CASE WHEN delivery_category = 'Promo Guaranteed' THEN ft.net_counted_ads ELSE 0 END AS promo_guaranteed_impressions
# MAGIC     , CASE WHEN delivery_category = 'Promo Pre-emptible' THEN ft.net_counted_ads ELSE 0 END AS promo_pre_emptible_impressions
# MAGIC     , CASE WHEN delivery_category = 'Programmatic Guaranteed' THEN ft.net_counted_ads ELSE 0 END AS programmatic_guaranteed_impressions
# MAGIC     , CASE WHEN delivery_category = 'Inventory Share' THEN ft.net_counted_ads ELSE 0 END AS inventory_share_impressions
# MAGIC     , CASE WHEN delivery_category = 'Affiliates' THEN ft.net_counted_ads ELSE 0 END AS affiliates_impressions
# MAGIC     , CASE WHEN delivery_category = 'Hard Guaranteed' THEN ft.net_counted_ads ELSE 0 END AS hard_guaranteed_impressions
# MAGIC     , CASE WHEN delivery_category = 'Backfill' THEN ft.net_counted_ads ELSE 0 END AS backfill_impressions
# MAGIC     , ft.net_counted_ads
# MAGIC     , ft.run_revenue AS run_revenue_amount
# MAGIC     , ft.delivered_clicks
# MAGIC     , ft.measurable_video_ads_quartile_impressions
# MAGIC     , ft.gross_counted_ads
# MAGIC     , ft.sales_channel_type
# MAGIC     , ft.reseller_name
# MAGIC     , ft.reseller_id
# MAGIC     , ft.mrm_rule_id
# MAGIC     , mr.mrm_rule_name
# MAGIC     , mr.mrm_rule_impression_goal
# MAGIC     , mr.mrm_rule_start_timestamp_est
# MAGIC     , mr.mrm_rule_end_timestamp_est
# MAGIC     , mr.priority_setting
# MAGIC     , COALESCE(lkpmr.priority_setting_point_in_time, mr.priority_setting) AS priority_setting_point_in_time
# MAGIC     , ft.dsp_name
# MAGIC     , ft.trading_desk_name
# MAGIC     , ft.buyer_name
# MAGIC     , ft.buyer_priority
# MAGIC     , ft.deal_id
# MAGIC     , dl.deal_name
# MAGIC     , dl.deal_salesperson
# MAGIC     , dl.external_deal_id
# MAGIC     , dl.deal_impression_goal
# MAGIC     , dl.deal_start_timestamp_est
# MAGIC     , dl.deal_end_timestamp_est
# MAGIC     , lkpdl.deal_type AS deal_type_point_in_time
# MAGIC     , dl.deal_override_priority
# MAGIC     , pc.programmatic_industry_name
# MAGIC     , pc.programmatic_brand_name
# MAGIC     , ft.programmatic_advertiser_id
# MAGIC     , ft.programmatic_advertiser_name
# MAGIC     , ft.global_ad_unit_category
# MAGIC     , CASE
# MAGIC         WHEN pa.promo_advertiser IS NOT NULL THEN 'Y'
# MAGIC         ELSE 'N'
# MAGIC     END AS is_promo_advertiser
# MAGIC     , ft.agency_name
# MAGIC     , ft.programmatic_ad_id
# MAGIC     , dl.deal_type
# MAGIC     , ft.site_section_id
# MAGIC     , site.site_section_name
# MAGIC     , ft.advertiser_id
# MAGIC FROM ft_fw_matched_audience_delivery ft
# MAGIC LEFT JOIN fox_bi_prod.silver_ads.dim_freewheel_analytics_video_group_custom vc
# MAGIC ON ft.video_id = vc.video_id
# MAGIC LEFT JOIN fox_bi_prod.silver_ads.dim_freewheel_analytics_video_series vs
# MAGIC ON ft.series_id = vs.series_id
# MAGIC LEFT JOIN fox_bi_prod.silver_ads.freewheel_gsheet_map_series_to_show ss
# MAGIC ON vs.series_name = ss.series_name
# MAGIC LEFT JOIN fox_bi_prod.silver_ads.freewheel_gsheet_map_unassigned_secondary_video_group usvg
# MAGIC ON vc.video_name = usvg.video_name
# MAGIC AND vc.primary_video_group_name = usvg.primary_video_group_name
# MAGIC AND vc.secondary_video_group_name = usvg.secondary_video_group_name
# MAGIC AND vs.series_name = usvg.series_name
# MAGIC LEFT JOIN fox_bi_prod.raw_ads.freewheel_gsheet_map_season_video_group_manual_override svgmo
# MAGIC ON vc.video_name = svgmo.video_name
# MAGIC LEFT JOIN (
# MAGIC     SELECT
# MAGIC         *
# MAGIC     FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_site
# MAGIC     WHERE (
# MAGIC         site_section_id
# MAGIC         , site_id
# MAGIC     ) NOT IN (
# MAGIC         SELECT
# MAGIC             dfas.site_section_id
# MAGIC             , -1
# MAGIC         FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_site dfas
# MAGIC         GROUP BY dfas.site_section_id
# MAGIC         HAVING COUNT(*) > 1
# MAGIC     )
# MAGIC ) site
# MAGIC ON ft.site_section_id = site.site_section_id
# MAGIC LEFT JOIN (
# MAGIC     SELECT DISTINCT
# MAGIC         series_name
# MAGIC         , season_video_group_id
# MAGIC         , TO_DATE(start_date, 'M/d/yyyy') AS start_date
# MAGIC         , TO_DATE(end_date, 'M/d/yyyy') AS end_date
# MAGIC     FROM fox_bi_prod.raw_ads.freewheel_gsheet_map_season_video_group_in_out
# MAGIC     WHERE season_video_group_id NOT ILIKE 'NA'
# MAGIC ) svgio
# MAGIC ON COALESCE(TRY_CAST(svgmo.season_video_group_id AS BIGINT), vc.season_video_group_id) = svgio.season_video_group_id
# MAGIC AND ft.event_date BETWEEN svgio.start_date AND svgio.end_date
# MAGIC LEFT JOIN fox_bi_prod.silver_ads.dim_freewheel_analytics_creative cr
# MAGIC ON ft.creative_id = cr.creative_id
# MAGIC LEFT JOIN fox_bi_prod.silver_ads.dim_freewheel_analytics_ad_unit au
# MAGIC ON ft.ad_unit_id = au.ad_unit_id
# MAGIC LEFT JOIN fox_bi_prod.silver_ads.dim_freewheel_analytics_placement p
# MAGIC ON ft.placement_id = p.placement_id
# MAGIC LEFT JOIN fox_bi_prod.silver_ads.lkp_freewheel_analytics_placement lkpp
# MAGIC ON ft.event_date = lkpp.event_date
# MAGIC AND ft.placement_id = lkpp.placement_id
# MAGIC LEFT JOIN fox_bi_prod.silver_ads.dim_freewheel_analytics_insertion_order io
# MAGIC ON ft.insertion_order_id = io.insertion_order_id
# MAGIC LEFT JOIN fox_bi_prod.silver_ads.dim_freewheel_analytics_campaign cmp
# MAGIC ON ft.campaign_id = cmp.campaign_id
# MAGIC LEFT JOIN fox_bi_prod.silver_ads.dim_freewheel_analytics_mrm_rule mr
# MAGIC ON ft.mrm_rule_id = mr.mrm_rule_id
# MAGIC LEFT JOIN fox_bi_prod.silver_ads.lkp_freewheel_analytics_mrm_rule lkpmr
# MAGIC ON ft.event_date = lkpmr.event_date
# MAGIC AND ft.mrm_rule_id = lkpmr.mrm_rule_id
# MAGIC LEFT JOIN fox_bi_prod.silver_ads.dim_freewheel_analytics_deal dl
# MAGIC ON ft.deal_id = dl.deal_id
# MAGIC LEFT JOIN fox_bi_prod.silver_ads.lkp_freewheel_analytics_deal lkpdl
# MAGIC ON ft.deal_id = lkpdl.deal_id
# MAGIC AND ft.event_date = lkpdl.event_date
# MAGIC LEFT JOIN fox_bi_prod.silver_ads.dim_freewheel_analytics_programmatic_creative pc
# MAGIC ON ft.programmatic_ad_id = pc.programmatic_ad_id
# MAGIC LEFT JOIN fox_bi_prod.raw_ads.freewheel_gsheet_map_promo_advertiser pa
# MAGIC ON LOWER(TRIM(ft.advertiser_name)) = LOWER(pa.promo_advertiser)

# COMMAND ----------

query = """
    SELECT
        distributor_id
        , distributor_name
        , video_id
        , video_name
        , primary_video_group_id
        , primary_video_group_name
        , secondary_video_group_id
        , secondary_video_group_name
        , season_video_group_id
        , season_video_group_name
        , prefered_video_group
        , show_name
        , season_in_out_flag
        , video_vertical
        , site_section_id
        , site_section_name
        , series_id
        , series_name
        , creative_id
        , creative_name
        , creative_duration_secs
        , ad_unit_id
        , ad_unit_price
        , ad_unit_external_id
        , global_ad_unit_position
        , global_ad_unit_class
        , global_ad_unit_category
        , advertiser_id
        , advertiser_name
        , is_promo_advertiser
        , agency_name
        , campaign_id
        , campaign_name
        , campaign_external_id
        , campaign_start_timestamp_est
        , campaign_end_timestamp_est
        , placement_id
        , placement_external_id
        , placement_name
        , placement_budgeted_impressions
        , placement_start_timestamp_est
        , placement_end_timestamp_est
        , placement_industry
        , placement_status
        , placement_type
        , unified_yield
        , booked_on_target_impression_goal
        , budget_model
        , demographic_on_target_calculation
        , demographic_data_source
        , forced_over_delivery_percent
        , impression_goal
        , delivery_pacing
        , estimated_impression_goal
        , delivery_priority
        , delivery_priority_point_in_time
        , insertion_order_id
        , insertion_order_name
        , insertion_order_external_id
        , insertion_order_end_timestamp_est
        , insertion_order_primary_salesperson
        , insertion_order_primary_trafficker
        , insertion_order_start_timestamp_est
        , insertion_order_status
        , programmatic_ad_id
        , programmatic_advertiser_id
        , programmatic_advertiser_name
        , programmatic_industry_name
        , programmatic_brand_name
        , deal_id
        , deal_name
        , deal_salesperson
        , external_deal_id
        , deal_impression_goal
        , deal_start_timestamp_est
        , deal_end_timestamp_est
        , deal_type
        , deal_type_point_in_time
        , deal_override_priority
        , reseller_id
        , reseller_name
        , mrm_rule_id
        , mrm_rule_name
        , mrm_rule_impression_goal
        , mrm_rule_start_timestamp_est
        , mrm_rule_end_timestamp_est
        , priority_setting
        , priority_setting_point_in_time
        , dsp_name
        , trading_desk_name
        , buyer_name
        , buyer_priority
        , matched_audience_item_name
        , device_name
        , platform_group
        , specific_device
        , platform_name
        , is_live_fox_ss
        , is_fep
        , is_go
        , is_fox_now
        , sales_channel_type
        , delivery_category
        , SUM(direct_guaranteed_impressions) AS direct_guaranteed_impressions
        , SUM(direct_pre_emptible_impressions) AS direct_pre_emptible_impressions
        , SUM(promo_guaranteed_impressions) AS promo_guaranteed_impressions
        , SUM(promo_pre_emptible_impressions) AS promo_pre_emptible_impressions
        , SUM(programmatic_guaranteed_impressions) AS programmatic_guaranteed_impressions
        , SUM(inventory_share_impressions) AS inventory_share_impressions
        , SUM(affiliates_impressions) AS affiliates_impressions
        , SUM(hard_guaranteed_impressions) AS hard_guaranteed_impressions
        , SUM(backfill_impressions) AS backfill_impressions
        , SUM(net_counted_ads) AS net_counted_ads
        , CAST(SUM(run_revenue_amount) AS DECIMAL(32,7)) AS run_revenue_amount
        , SUM(delivered_clicks) AS delivered_clicks
        , SUM(measurable_video_ads_quartile_impressions) AS measurable_video_ads_quartile_impressions
        , SUM(gross_counted_ads) AS gross_counted_ads
        , event_date
        , DATE_FORMAT(CURRENT_TIMESTAMP(), 'yyyy-MM-dd') AS etl_load_date
        , CURRENT_TIMESTAMP() AS etl_load_timestamp
    FROM matched_audience_delivery_data
    GROUP BY
        distributor_id
        , distributor_name
        , video_id
        , video_name
        , primary_video_group_id
        , primary_video_group_name
        , secondary_video_group_id
        , secondary_video_group_name
        , season_video_group_id
        , season_video_group_name
        , prefered_video_group
        , show_name
        , season_in_out_flag
        , video_vertical
        , site_section_id
        , site_section_name
        , series_id
        , series_name
        , creative_id
        , creative_name
        , creative_duration_secs
        , ad_unit_id
        , ad_unit_price
        , ad_unit_external_id
        , global_ad_unit_position
        , global_ad_unit_class
        , global_ad_unit_category
        , advertiser_id
        , advertiser_name
        , is_promo_advertiser
        , agency_name
        , campaign_id
        , campaign_name
        , campaign_external_id
        , campaign_start_timestamp_est
        , campaign_end_timestamp_est
        , placement_id
        , placement_external_id
        , placement_name
        , placement_budgeted_impressions
        , placement_start_timestamp_est
        , placement_end_timestamp_est
        , placement_industry
        , placement_status
        , placement_type
        , unified_yield
        , booked_on_target_impression_goal
        , budget_model
        , demographic_on_target_calculation
        , demographic_data_source
        , forced_over_delivery_percent
        , impression_goal
        , delivery_pacing
        , estimated_impression_goal
        , delivery_priority
        , delivery_priority_point_in_time
        , insertion_order_id
        , insertion_order_name
        , insertion_order_external_id
        , insertion_order_end_timestamp_est
        , insertion_order_primary_salesperson
        , insertion_order_primary_trafficker
        , insertion_order_start_timestamp_est
        , insertion_order_status
        , programmatic_ad_id
        , programmatic_advertiser_id
        , programmatic_advertiser_name
        , programmatic_industry_name
        , programmatic_brand_name
        , deal_id
        , deal_name
        , deal_salesperson
        , external_deal_id
        , deal_impression_goal
        , deal_start_timestamp_est
        , deal_end_timestamp_est
        , deal_type
        , deal_type_point_in_time
        , deal_override_priority
        , reseller_id
        , reseller_name
        , mrm_rule_id
        , mrm_rule_name
        , mrm_rule_impression_goal
        , mrm_rule_start_timestamp_est
        , mrm_rule_end_timestamp_est
        , priority_setting
        , priority_setting_point_in_time
        , dsp_name
        , trading_desk_name
        , buyer_name
        , buyer_priority
        , matched_audience_item_name
        , device_name
        , platform_group
        , specific_device
        , platform_name
        , is_live_fox_ss
        , is_fep
        , is_go
        , is_fox_now
        , sales_channel_type
        , delivery_category
        , event_date
    """

matched_audience_delivery_data = spark.sql(query)

# COMMAND ----------

# matched_audience_delivery_data.write.format('delta')\
#     .mode('overwrite')\
#     .partitionBy('event_date')\
#     .option('mergeSchema', 'true')\
#     .option('overwriteDynamicPartitions', 'true')\
#     .option('delta.enableDeletionVectors', 'false')\
#     .option('delta.enableIcebergCompatV2', 'true')\
#     .option('delta.universalFormat.enabledFormats', 'iceberg')\
#     .option('delta.columnMapping.mode', 'name')\
#     .saveAsTable(f"fox_bi_prod.silver_ads.ft_freewheel_matched_audience_delivery_daily_data")

matched_audience_delivery_data.write.format('delta')\
    .mode('overwrite')\
    .option('partitionOverwriteMode', 'dynamic')\
    .saveAsTable('fox_bi_prod.silver_ads.ft_freewheel_matched_audience_delivery_daily_data')