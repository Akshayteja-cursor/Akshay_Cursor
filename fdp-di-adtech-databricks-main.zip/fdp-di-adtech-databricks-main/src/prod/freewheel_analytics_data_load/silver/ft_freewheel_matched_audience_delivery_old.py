# Databricks notebook source
# MAGIC %md FETCH DATA PARAMETERS

# COMMAND ----------

# MAGIC %md LOAD FT TABLES

# COMMAND ----------

df = spark.sql(f"""
SELECT *
FROM fox_bi_prod.bronze_ads.freewheel_analytics_matched_audience_direct_sold_delivery_video_ads
""")
df.createOrReplaceTempView("matched_audience_direct_sold_video_ads_vw")

# COMMAND ----------

df = spark.sql(f"""
SELECT *
FROM fox_bi_prod.bronze_ads.freewheel_analytics_matched_audience_markets_delivery
""")
df.createOrReplaceTempView("matched_audience_markets_delivery_video_ads_vw")

# COMMAND ----------

# MAGIC %md LOAD DIM TABLES

# COMMAND ----------

# MAGIC %sql
# MAGIC -- programmtic creative
# MAGIC CREATE OR REPLACE TEMP VIEW programmatic_creative_dim_vw AS
# MAGIC SELECT
# MAGIC DISTINCT
# MAGIC programmatic_ad_id,
# MAGIC programmatic_industry_name,
# MAGIC programmatic_brand_name
# MAGIC FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_programmatic_creative;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- programmtic creative
# MAGIC CREATE OR REPLACE TEMP VIEW creative_dim_vw AS
# MAGIC SELECT
# MAGIC DISTINCT
# MAGIC creative_id,
# MAGIC creative_name,
# MAGIC creative_duration_secs
# MAGIC FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_creative;

# COMMAND ----------

# MAGIC
# MAGIC %sql
# MAGIC -- SERIES
# MAGIC CREATE OR REPLACE TEMP VIEW series_dim_vw AS
# MAGIC SELECT 
# MAGIC DISTINCT
# MAGIC series_id, series_name
# MAGIC FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_video_series;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- SITE SECTION
# MAGIC CREATE OR REPLACE TEMP VIEW site_dim_vw AS
# MAGIC SELECT site_section_id, site_section_name
# MAGIC FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_site;

# COMMAND ----------

# MAGIC
# MAGIC %sql
# MAGIC -- AD UNIT
# MAGIC CREATE OR REPLACE TEMP VIEW ad_unit_dim_vw AS
# MAGIC SELECT DISTINCT ad_unit_id, ad_unit_class, ad_unit_position , ad_unit_price , ad_unit_external_id
# MAGIC FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_ad_unit;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- DEAL
# MAGIC CREATE OR REPLACE TEMP VIEW deal_dim_vw AS
# MAGIC SELECT deal_id, deal_name,deal_salesperson, external_deal_id,deal_impression_goal, deal_type,deal_override_priority,deal_start_timestamp_est,deal_end_timestamp_est
# MAGIC FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_deal;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Static placement dim
# MAGIC CREATE OR REPLACE TEMP VIEW placement_dim_vw AS
# MAGIC SELECT 
# MAGIC DISTINCT
# MAGIC placement_id,
# MAGIC placement_external_id,
# MAGIC placement_name,
# MAGIC placement_budgeted_impressions,
# MAGIC placement_start_timestamp_est,
# MAGIC placement_end_timestamp_est,
# MAGIC placement_industry,
# MAGIC placement_type,
# MAGIC placement_booked_on_target_impression_goal as booked_on_target_impression_goal,
# MAGIC placement_budget_model as budget_model,
# MAGIC placement_demographic_on_target_calculation as demographic_on_target_calculation,
# MAGIC placement_demographic_data_source as demographic_data_source,
# MAGIC placement_forced_over_delivery_percent as forced_over_delivery_percent,
# MAGIC placement_impression_goal as impression_goal,
# MAGIC placement_pacing as delivery_pacing,
# MAGIC placement_estimated_impression_goal as estimated_impression_goal,
# MAGIC placement_priority as delivery_priority,
# MAGIC unified_yield_name as unified_yield,
# MAGIC placement_status
# MAGIC FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_placement;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Static placement dim
# MAGIC CREATE OR REPLACE TEMP VIEW placement_lkp_vw AS
# MAGIC SELECT 
# MAGIC DISTINCT
# MAGIC cast(event_date as date) as event_date,
# MAGIC placement_id,
# MAGIC delivery_priority_type_point_in_time
# MAGIC FROM fox_bi_prod.silver_ads.lkp_freewheel_analytics_placement;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Static MRM rule dim
# MAGIC CREATE OR REPLACE TEMP VIEW mrm_rule_dim_vw AS
# MAGIC SELECT 
# MAGIC DISTINCT 
# MAGIC mrm_rule_id,
# MAGIC mrm_rule_name,
# MAGIC priority_setting,
# MAGIC mrm_rule_impression_goal,
# MAGIC mrm_rule_start_timestamp_est,
# MAGIC mrm_rule_end_timestamp_est
# MAGIC FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_mrm_rule;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- SCD MRM rule dim
# MAGIC CREATE OR REPLACE TEMP VIEW mrm_rule_lkp_vw AS
# MAGIC SELECT 
# MAGIC DISTINCT
# MAGIC cast(event_date as date) as event_date,
# MAGIC mrm_rule_id,
# MAGIC priority_setting_point_in_time
# MAGIC FROM fox_bi_prod.silver_ads.lkp_freewheel_analytics_mrm_rule;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- INSERTION ORDER
# MAGIC CREATE OR REPLACE TEMP VIEW insertion_order_dim_vw AS
# MAGIC SELECT 
# MAGIC DISTINCT 
# MAGIC insertion_order_id, 
# MAGIC insertion_order_name, 
# MAGIC insertion_order_external_id, 
# MAGIC insertion_order_end_timestamp_est,
# MAGIC insertion_order_primary_salesperson,
# MAGIC insertion_order_primary_trafficker,
# MAGIC insertion_order_start_timestamp_est,
# MAGIC insertion_order_status
# MAGIC FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_insertion_order;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- PROMO ADVERTISER
# MAGIC CREATE OR REPLACE TEMP VIEW promo_advertiser_dim_vw AS
# MAGIC SELECT DISTINCT promo_advertiser
# MAGIC FROM fox_bi_prod.raw_ads.freewheel_gsheet_map_promo_advertiser;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- SITE CUSTOM
# MAGIC CREATE OR REPLACE TEMP VIEW site_custom_dim_vw AS
# MAGIC SELECT
# MAGIC site_section_id,
# MAGIC device_name as dn1,
# MAGIC platform_group_name as pg1
# MAGIC FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_site_custom;

# COMMAND ----------

# MAGIC %sql
# MAGIC --- video_group_custom 
# MAGIC CREATE OR REPLACE TEMP VIEW video_group_custom_dim_vw AS
# MAGIC SELECT 
# MAGIC DISTINCT
# MAGIC video_id,
# MAGIC video_name,
# MAGIC primary_video_group_id,
# MAGIC primary_video_group_name,
# MAGIC secondary_video_group_id,
# MAGIC secondary_video_group_name,
# MAGIC season_video_group_id,
# MAGIC season_video_group_name,
# MAGIC prefered_video_group
# MAGIC FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_video_group_custom;

# COMMAND ----------

# MAGIC %sql
# MAGIC --- video_group_custom 
# MAGIC CREATE OR REPLACE TEMP VIEW campaign_dim_vw AS
# MAGIC SELECT 
# MAGIC DISTINCT
# MAGIC campaign_id,
# MAGIC campaign_name,
# MAGIC campaign_external_id,
# MAGIC campaign_start_timestamp_est,
# MAGIC campaign_end_timestamp_est
# MAGIC FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_campaign;

# COMMAND ----------

# MAGIC %sql
# MAGIC --- rl_Series_show 
# MAGIC CREATE OR REPLACE TEMP VIEW rl_series_show_dim_vw AS
# MAGIC SELECT 
# MAGIC DISTINCT
# MAGIC series_name,
# MAGIC show_name
# MAGIC FROM fox_bi_prod.silver_ads.freewheel_gsheet_map_series_to_show;

# COMMAND ----------

# MAGIC %sql
# MAGIC --- video_group_manual_override
# MAGIC CREATE OR REPLACE TEMP VIEW season_video_group_manual_override_dim_vw AS
# MAGIC SELECT 
# MAGIC DISTINCT
# MAGIC cast(season_video_group_id as bigint) as season_video_group_id,
# MAGIC video_name,
# MAGIC season_video_group_name
# MAGIC from
# MAGIC fox_bi_prod.raw_ads.freewheel_gsheet_map_season_video_group_manual_override

# COMMAND ----------

# MAGIC %sql
# MAGIC --- season_video_group_in_out_dim_vw
# MAGIC CREATE OR REPLACE TEMP VIEW season_video_group_in_out_dim_vw AS
# MAGIC SELECT DISTINCT
# MAGIC   TO_DATE(start_date, 'M/dd/yyyy') AS start_date,
# MAGIC   TO_DATE(end_date, 'M/dd/yyyy') AS end_date,
# MAGIC   show_name,
# MAGIC   cast(season_video_group_id as bigint) as season_video_group_id,
# MAGIC   season_video_group,
# MAGIC   series_name
# MAGIC FROM fox_bi_prod.raw_ads.freewheel_gsheet_map_season_video_group_in_out

# COMMAND ----------

# MAGIC %sql
# MAGIC --- unassigned_secondary_video_group_dim_vw
# MAGIC CREATE OR REPLACE TEMP VIEW unassigned_secondary_video_group_dim_vw AS
# MAGIC SELECT DISTINCT
# MAGIC   primary_video_group_name,
# MAGIC   series_name,
# MAGIC   video_name,
# MAGIC   secondary_video_group_name,
# MAGIC   CAST(assigned_secondary_video_group_id AS BIGINT) as assigned_secondary_video_group_id,
# MAGIC   CAST(assigned_secondary_video_group_name AS STRING) as assigned_secondary_video_group_name
# MAGIC FROM fox_bi_prod.silver_ads.freewheel_gsheet_map_unassigned_secondary_video_group

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW advertiser_dim_vw AS
# MAGIC select 
# MAGIC advertiser_id,
# MAGIC advertiser_name,
# MAGIC advertiser_external_id,
# MAGIC advertiser_industry
# MAGIC from fox_bi_prod.silver_ads.dim_freewheel_analytics_advertiser;

# COMMAND ----------

# MAGIC %md TRANSFORM

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW matched_audience_direct_sold_video_ads_transformed AS
# MAGIC SELECT 
# MAGIC     event_date,
# MAGIC     distributor_name,
# MAGIC     distributor_id,
# MAGIC     NULL as site_short_name,
# MAGIC     site_section_id,
# MAGIC     video_id,
# MAGIC     m.series_id,
# MAGIC     s.series_name,
# MAGIC     d.ad_unit_position AS global_ad_unit_position,
# MAGIC     d.ad_unit_class AS global_ad_unit_class,
# MAGIC     'Video Ads' as global_ad_unit_category,
# MAGIC     creative_id,
# MAGIC     m.ad_unit_id,
# MAGIC     placement_id,
# MAGIC     insertion_order_id,
# MAGIC     campaign_id,
# MAGIC     'Direct Sold' as sales_channel_type,
# MAGIC     NULL as reseller_name,
# MAGIC     NULL as reseller_id,
# MAGIC     NULL as mrm_rule_id,
# MAGIC      m.advertiser_id as advertiser_id,
# MAGIC     coalesce(a.advertiser_name,m.advertiser_name) as advertiser_name,
# MAGIC     agency_name,
# MAGIC     NULL as priority_setting,
# MAGIC     NULL as dsp_name,
# MAGIC     NULL as trading_desk_name,
# MAGIC     NULL as buyer_name,
# MAGIC     NULL as buyer_priority,
# MAGIC     NULL as deal_id,
# MAGIC     NULL as deal_name,
# MAGIC     NULL as deal_type_point_in_time,
# MAGIC     NULL as deal_type,
# MAGIC     NULL as deal_override_priority,
# MAGIC     NULL as programmatic_ad_id,
# MAGIC     NULL as programmatic_advertiser_id,
# MAGIC     NULL as programmatic_advertiser_name,
# MAGIC     NULL as device_name,
# MAGIC     NULL as specific_device,
# MAGIC     NULL as platform_name,
# MAGIC     NULL as platform_group,
# MAGIC     NULL as is_live_fox_ss,
# MAGIC     NULL as is_fep,
# MAGIC     NULL as is_go,
# MAGIC     matched_audience_item_name,
# MAGIC     NULL as direct_guaranteed_impressions,
# MAGIC     NULL as direct_pre_emptible_impressions,
# MAGIC     NULL as promo_guranteed_impressions,
# MAGIC     NULL as promo_pre_emptible_impressions,
# MAGIC     NULL as programmatic_guaranteed_impressions,
# MAGIC     NULL as inventory_share_impressions,
# MAGIC     NULL as affiliates_impressions,
# MAGIC     NULL as hard_guaranteed_impressions,
# MAGIC     NULL as backfill_impressions,
# MAGIC     net_counted_ads as net_counted_ads_qty,
# MAGIC     gross_counted_ads as gross_counted_ads_qty,
# MAGIC     run_revenue as run_revenue_amount,
# MAGIC     eCPM as eCPM_amt,
# MAGIC     delivered_clicks as delivered_clicks_qty,
# MAGIC     measurable_Video_ads_quartile_impressions as measurable_Video_ads_quartile_impressions_qty
# MAGIC FROM matched_audience_direct_sold_video_ads_vw m
# MAGIC LEFT JOIN ad_unit_dim_vw d
# MAGIC     ON m.ad_unit_id = d.ad_unit_id
# MAGIC LEFT JOIN series_dim_vw s
# MAGIC     ON m.series_id = s.series_id
# MAGIC LEFT JOIN advertiser_dim_vw a
# MAGIC     ON m.advertiser_id = a.advertiser_id

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW matched_audience_markets_delivery_transformed AS
# MAGIC SELECT 
# MAGIC     m.event_date,
# MAGIC     distributor_name,
# MAGIC     distributor_id,
# MAGIC     NULL as site_short_name,
# MAGIC     site_section_id,
# MAGIC     video_id,
# MAGIC     m.series_id,
# MAGIC     s.series_name,
# MAGIC     ad_unit_position as global_ad_unit_position,
# MAGIC     CASE WHEN ad_unit_position='Display' THEN 'Display Ads' ELSE 'Video Ads' END as global_ad_unit_class,
# MAGIC     CASE WHEN ad_unit_position='Display' THEN 'Display Ads' ELSE 'Video Ads' END as global_ad_unit_category,
# MAGIC     NULL as creative_id,
# MAGIC     NULL as ad_unit_id,
# MAGIC     NULL as placement_id,
# MAGIC     NULL as insertion_order_id,
# MAGIC     NULL as campaign_id,
# MAGIC     'Programmatic' as sales_channel_type,
# MAGIC     NULL as reseller_name,
# MAGIC     NULL as reseller_id,
# MAGIC     NULL as mrm_rule_id,
# MAGIC     NULL as advertiser_id,
# MAGIC     NULL as advertiser_name,
# MAGIC     NULL as agency_name,
# MAGIC     NULL as priority_setting,
# MAGIC     dsp_name,
# MAGIC     trading_desk_name,
# MAGIC     invite_buyer_name as buyer_name,
# MAGIC     invite_buyer_priority as buyer_priority,
# MAGIC     m.deal_id,
# MAGIC     d.deal_name,
# MAGIC     lkpdl.deal_type as deal_type_point_in_time,
# MAGIC     d.deal_type,
# MAGIC     d.deal_override_priority,
# MAGIC     programmatic_ad_id,
# MAGIC     global_advertiser_id as programmatic_advertiser_id,
# MAGIC     global_advertiser_name as programmatic_advertiser_name,
# MAGIC     NULL as device_name,
# MAGIC     NULL as specific_device,
# MAGIC     NULL as platform_name,
# MAGIC     NULL as platform_group,
# MAGIC     NULL as is_live_fox_ss,
# MAGIC     NULL as is_fep,
# MAGIC     NULL as is_go,
# MAGIC     matched_audience_item_name,
# MAGIC     NULL as direct_guaranteed_impressions,
# MAGIC     NULL as direct_pre_emptible_impressions,
# MAGIC     NULL as promo_guranteed_impressions,
# MAGIC     NULL as promo_pre_emptible_impressions,
# MAGIC     NULL as programmatic_guaranteed_impressions,
# MAGIC     NULL as inventory_share_impressions,
# MAGIC     NULL as affiliates_impressions,
# MAGIC     NULL as hard_guaranteed_impressions,
# MAGIC     NULL as backfill_impressions,
# MAGIC     net_counted_ads as net_counted_ads_qty,
# MAGIC     gross_counted_ads as gross_counted_ads_qty,
# MAGIC     run_revenue as run_revenue_amount,
# MAGIC     eCPM as eCPM_amt,
# MAGIC     delivered_clicks as delivered_clicks_qty,
# MAGIC     null as measurable_Video_ads_quartile_impressions_qty
# MAGIC FROM matched_audience_markets_delivery_video_ads_vw m
# MAGIC LEFT JOIN deal_dim_vw d
# MAGIC     ON m.deal_id = d.deal_id
# MAGIC LEFT JOIN series_dim_vw s
# MAGIC     ON m.series_id = s.series_id
# MAGIC LEFT JOIN fox_bi_prod.silver_ads.lkp_freewheel_analytics_deal lkpdl
# MAGIC ON m.deal_id = lkpdl.deal_id
# MAGIC AND m.event_date = lkpdl.event_date;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Union of the two reports and remove duplicates
# MAGIC CREATE OR REPLACE TEMP VIEW delivery_union_deduped AS
# MAGIC SELECT DISTINCT *
# MAGIC FROM (
# MAGIC     SELECT * FROM matched_audience_direct_sold_video_ads_transformed
# MAGIC     UNION ALL
# MAGIC     SELECT * FROM matched_audience_markets_delivery_transformed
# MAGIC ) combined;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Join delivery with static placement and SCD
# MAGIC CREATE OR REPLACE TEMP VIEW delivery_enriched AS
# MAGIC SELECT 
# MAGIC     d.*,
# MAGIC     p.placement_name,
# MAGIC     COALESCE(s.delivery_priority_type_point_in_time, p.delivery_priority) AS delivery_priority_type
# MAGIC FROM delivery_union_deduped d
# MAGIC LEFT JOIN placement_dim_vw p
# MAGIC     ON d.placement_id = p.placement_id
# MAGIC LEFT JOIN placement_lkp_vw s
# MAGIC     ON d.placement_id = cast(s.placement_id as bigint) AND d.event_date = s.event_date;

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC --MRM RULE JOIN IS NOT NEEEDED AS MRM RULE ID IS NULL IN SOURCE DATA
# MAGIC -- Final enriched delivery with static MRM and SCD
# MAGIC -- CREATE OR REPLACE TEMP VIEW delivery_fully_enriched AS
# MAGIC -- SELECT 
# MAGIC --     d.*,
# MAGIC -- r.mrm_rule_name,
# MAGIC --     COALESCE(s.priority_setting_point_in_time, r.priority_setting) AS priority_setting
# MAGIC -- FROM delivery_enriched d
# MAGIC -- LEFT JOIN dm_fw_mrm_rule r
# MAGIC --     ON d.mrm_rule_id = r.mrm_rule_id
# MAGIC -- LEFT JOIN dm_fw_mrm_rule_scd s
# MAGIC --     ON d.mrm_rule_id = s.mrm_rule_id AND d.event_date = s.event_date;
# MAGIC
# MAGIC --- Final enriched delivery with static MRM and SCD 
# MAGIC
# MAGIC
# MAGIC CREATE OR REPLACE TEMP VIEW delivery_fully_enriched AS
# MAGIC SELECT 
# MAGIC     d.*,
# MAGIC     NULL as mrm_rule_name
# MAGIC FROM delivery_enriched d

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW delivery_with_insertion_order AS
# MAGIC SELECT 
# MAGIC     d.*,
# MAGIC     i.insertion_order_name
# MAGIC FROM delivery_fully_enriched d
# MAGIC LEFT JOIN insertion_order_dim_vw i
# MAGIC     ON d.insertion_order_id = i.insertion_order_id;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW delivery_derived AS
# MAGIC SELECT 
# MAGIC     dio.*,
# MAGIC     
# MAGIC     -- Derived column: delivery_category
# MAGIC     CASE
# MAGIC         WHEN lower(sales_channel_type) = 'direct sold' THEN
# MAGIC             CASE
# MAGIC                 WHEN lower(advertiser_name) = 'amazon aps' THEN
# MAGIC                     CASE
# MAGIC                         WHEN (insertion_order_name LIKE '%Guaranteed%' OR delivery_priority_type LIKE '%Guaranteed%') THEN 'Programmatic Guaranteed'
# MAGIC                         ELSE 'Backfill'
# MAGIC                     END
# MAGIC     
# MAGIC                 WHEN TRIM(advertiser_name) IN (SELECT DISTINCT promo_advertiser FROM promo_advertiser_dim_vw) THEN CONCAT('Promo ', delivery_priority_type)
# MAGIC                 
# MAGIC                 WHEN placement_name LIKE '%Amobee%' OR placement_name LIKE '%B2B%' THEN 'Programmatic Guaranteed'
# MAGIC                 ELSE CONCAT('Direct ', delivery_priority_type)
# MAGIC             END
# MAGIC         
# MAGIC         WHEN lower(sales_channel_type) = 'reseller sold' THEN
# MAGIC             CASE
# MAGIC                 WHEN reseller_name LIKE '%Fox Affiliates Live%' THEN 'Affiliates'
# MAGIC                 WHEN mrm_rule_name LIKE '%Inventory Share%' THEN 'Inventory Share'
# MAGIC                 WHEN priority_setting LIKE '%HARD_GUARANTEE%' THEN 'Hard Guaranteed'
# MAGIC                 ELSE 'Backfill'
# MAGIC             END
# MAGIC         
# MAGIC         WHEN lower(sales_channel_type) = 'programmatic' THEN
# MAGIC             CASE
# MAGIC                 WHEN lkpdl.deal_type IN ('DEAL', 'BACKFILL_DEAL', 'Backfill Deal', 'Deal') THEN 'Backfill'
# MAGIC                 WHEN lkpdl.deal_type IN ('FIRST_LOOK_DEAL', 'First Look','Biddable Guaranteed') THEN 'Hard Guaranteed'
# MAGIC                 WHEN lkpdl.deal_type IS NULL THEN
# MAGIC                     CASE
# MAGIC                       WHEN dio.deal_type IN ('DEAL', 'BACKFILL_DEAL', 'Backfill Deal', 'Deal') THEN 'Backfill'
# MAGIC                       WHEN dio.deal_type IN ('FIRST_LOOK_DEAL', 'First Look', 'Biddable Guaranteed') THEN 'Hard Guaranteed'
# MAGIC                       ELSE 'Programmatic Guaranteed'
# MAGIC             	    END
# MAGIC                 ELSE 'Programmatic Guaranteed'
# MAGIC             END
# MAGIC
# MAGIC         ELSE NULL
# MAGIC     END AS delivery_category,
# MAGIC
# MAGIC     -- Cast net_counted_ads_qty to string
# MAGIC     CAST(net_counted_ads_qty AS STRING) AS net_counted_ads_qty_cast
# MAGIC
# MAGIC FROM delivery_with_insertion_order dio
# MAGIC LEFT JOIN fox_bi_prod.silver_ads.lkp_freewheel_analytics_deal lkpdl
# MAGIC ON dio.deal_id = lkpdl.deal_id
# MAGIC AND dio.event_date = lkpdl.event_date;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW delivery_final_selected AS
# MAGIC SELECT 
# MAGIC     event_date, 
# MAGIC     distributor_name, 
# MAGIC     distributor_id, 
# MAGIC     site_short_name,
# MAGIC     site_section_id, 
# MAGIC     video_id, 
# MAGIC     series_id, 
# MAGIC     series_name,
# MAGIC     global_ad_unit_position, 
# MAGIC     global_ad_unit_class, 
# MAGIC     global_ad_unit_category, 
# MAGIC     creative_id, 
# MAGIC     ad_unit_id, 
# MAGIC     placement_id,
# MAGIC     insertion_order_id, 
# MAGIC     campaign_id, 
# MAGIC     sales_channel_type, 
# MAGIC     reseller_name, 
# MAGIC     reseller_id, 
# MAGIC     mrm_rule_id, 
# MAGIC     advertiser_id,
# MAGIC     advertiser_name,
# MAGIC     agency_name, 
# MAGIC     priority_setting, 
# MAGIC     dsp_name, 
# MAGIC     trading_desk_name, 
# MAGIC     buyer_name, 
# MAGIC     buyer_priority, 
# MAGIC     deal_id, 
# MAGIC     deal_name,
# MAGIC     deal_type_point_in_time,
# MAGIC     deal_type,
# MAGIC     deal_override_priority, 
# MAGIC     programmatic_ad_id, 
# MAGIC     programmatic_advertiser_id, 
# MAGIC     programmatic_advertiser_name,
# MAGIC     device_name, 
# MAGIC     specific_device, 
# MAGIC     platform_name, 
# MAGIC     platform_group, 
# MAGIC     is_live_fox_ss, 
# MAGIC     is_fep, 
# MAGIC     is_go, 
# MAGIC     delivery_category,
# MAGIC     matched_audience_item_name,
# MAGIC     direct_guaranteed_impressions,
# MAGIC     direct_pre_emptible_impressions,
# MAGIC     promo_guranteed_impressions,
# MAGIC     promo_pre_emptible_impressions,
# MAGIC     programmatic_guaranteed_impressions,
# MAGIC     inventory_share_impressions,
# MAGIC     affiliates_impressions,
# MAGIC     hard_guaranteed_impressions,
# MAGIC     backfill_impressions,
# MAGIC     net_counted_ads_qty,
# MAGIC     gross_counted_ads_qty, 
# MAGIC     run_revenue_amount, 
# MAGIC     ecpm_amt, 
# MAGIC     delivered_clicks_qty,
# MAGIC     measurable_video_ads_quartile_impressions_qty
# MAGIC FROM delivery_derived;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create final delivery with derived metric quantities per category
# MAGIC CREATE OR REPLACE TEMP VIEW delivery_final_with_metrics AS
# MAGIC SELECT 
# MAGIC     event_date, 
# MAGIC     distributor_name, 
# MAGIC     distributor_id, 
# MAGIC     site_short_name,
# MAGIC     site_section_id, 
# MAGIC     video_id, 
# MAGIC     series_id, 
# MAGIC     series_name,
# MAGIC     global_ad_unit_position, 
# MAGIC     global_ad_unit_class, 
# MAGIC     global_ad_unit_category, 
# MAGIC     creative_id, 
# MAGIC     ad_unit_id, 
# MAGIC     placement_id,
# MAGIC     insertion_order_id, 
# MAGIC     campaign_id, 
# MAGIC     sales_channel_type, 
# MAGIC     reseller_name, 
# MAGIC     reseller_id, 
# MAGIC     mrm_rule_id, 
# MAGIC     advertiser_id,
# MAGIC     advertiser_name,
# MAGIC     agency_name, 
# MAGIC     priority_setting, 
# MAGIC     dsp_name, 
# MAGIC     trading_desk_name, 
# MAGIC     buyer_name, 
# MAGIC     buyer_priority, 
# MAGIC     deal_id, 
# MAGIC     deal_name,
# MAGIC     deal_type_point_in_time,
# MAGIC     deal_type,
# MAGIC     deal_override_priority, 
# MAGIC     programmatic_ad_id, 
# MAGIC     programmatic_advertiser_id, 
# MAGIC     programmatic_advertiser_name,
# MAGIC     device_name, 
# MAGIC     specific_device, 
# MAGIC     platform_name, 
# MAGIC     platform_group, 
# MAGIC     is_live_fox_ss, 
# MAGIC     is_fep, 
# MAGIC     is_go, 
# MAGIC     delivery_category,
# MAGIC     matched_audience_item_name,
# MAGIC     CASE WHEN delivery_category = 'Direct Guaranteed' THEN net_counted_ads_qty ELSE '0' END AS direct_guaranteed_impressions,
# MAGIC     CASE WHEN delivery_category = 'Direct Pre-emptible' THEN net_counted_ads_qty ELSE '0' END AS direct_pre_emptible_impressions,
# MAGIC     CASE WHEN delivery_category = 'Promo Guaranteed' THEN net_counted_ads_qty ELSE '0' END AS promo_guaranteed_impressions,
# MAGIC     CASE WHEN delivery_category = 'Promo Pre-emptible' THEN net_counted_ads_qty ELSE '0' END AS promo_pre_emptible_impressions,
# MAGIC     CASE WHEN delivery_category = 'Programmatic Guaranteed' THEN net_counted_ads_qty ELSE '0' END AS programmatic_guaranteed_impressions,
# MAGIC     CASE WHEN delivery_category = 'Inventory Share' THEN net_counted_ads_qty ELSE '0' END AS inventory_share_impressions,
# MAGIC     CASE WHEN delivery_category = 'Affiliates' THEN net_counted_ads_qty ELSE '0' END AS affiliates_impressions,
# MAGIC     CASE WHEN delivery_category = 'Hard Guaranteed' THEN net_counted_ads_qty ELSE '0' END AS hard_guaranteed_impressions,
# MAGIC     CASE WHEN delivery_category = 'Backfill' THEN net_counted_ads_qty ELSE '0' END AS backfill_impressions,
# MAGIC     net_counted_ads_qty,
# MAGIC     gross_counted_ads_qty, 
# MAGIC     run_revenue_amount, 
# MAGIC     ecpm_amt, 
# MAGIC     delivered_clicks_qty,
# MAGIC     measurable_video_ads_quartile_impressions_qty
# MAGIC FROM delivery_final_selected;

# COMMAND ----------

# MAGIC
# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW delivery_final_deduped AS
# MAGIC SELECT DISTINCT * FROM delivery_final_with_metrics;

# COMMAND ----------

# MAGIC %sql
# MAGIC CACHE TABLE delivery_final_deduped;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW delivery_final_cleaned AS
# MAGIC SELECT 
# MAGIC     -- All non-numeric columns (keep as-is)
# MAGIC     event_date, distributor_name, distributor_id, site_short_name, site_section_id, video_id, series_id, series_name,
# MAGIC     global_ad_unit_position, global_ad_unit_class, global_ad_unit_category, creative_id, ad_unit_id, placement_id,
# MAGIC     insertion_order_id, campaign_id, sales_channel_type, reseller_name, reseller_id, mrm_rule_id, advertiser_id, advertiser_name,
# MAGIC     agency_name, priority_setting, dsp_name, trading_desk_name, buyer_name, buyer_priority, deal_id, deal_name,
# MAGIC     deal_type_point_in_time, deal_type, deal_override_priority, programmatic_ad_id, programmatic_advertiser_id, programmatic_advertiser_name,
# MAGIC     device_name, specific_device, platform_name, platform_group, is_live_fox_ss, is_fep, is_go, delivery_category,
# MAGIC     matched_audience_item_name,
# MAGIC
# MAGIC     -- Cleaned numeric/qty columns (remove commas and cast to double)
# MAGIC     CAST(direct_guaranteed_impressions AS DOUBLE) AS direct_guaranteed_impressions,
# MAGIC     CAST(direct_pre_emptible_impressions AS DOUBLE) AS direct_pre_emptible_impressions,
# MAGIC     CAST(promo_guaranteed_impressions AS DOUBLE) AS promo_guaranteed_impressions,
# MAGIC     CAST(promo_pre_emptible_impressions AS DOUBLE) AS promo_pre_emptible_impressions,
# MAGIC     CAST(programmatic_guaranteed_impressions AS DOUBLE) AS programmatic_guaranteed_impressions,
# MAGIC     CAST(inventory_share_impressions AS DOUBLE) AS inventory_share_impressions,
# MAGIC     CAST(affiliates_impressions AS DOUBLE) AS affiliates_impressions,
# MAGIC     CAST(hard_guaranteed_impressions AS DOUBLE) AS hard_guaranteed_impressions,
# MAGIC     CAST(backfill_impressions AS DOUBLE) AS backfill_impressions,
# MAGIC     CAST(net_counted_ads_qty AS DOUBLE) AS net_counted_ads_qty,
# MAGIC     CAST(gross_counted_ads_qty AS DOUBLE) AS gross_counted_ads_qty,
# MAGIC     CAST(run_revenue_amount AS DOUBLE) AS run_revenue_amount,
# MAGIC     CAST(ecpm_amt AS DOUBLE) AS ecpm_amt,
# MAGIC     CAST(delivered_clicks_qty AS DOUBLE) AS delivered_clicks_qty,
# MAGIC     CAST(measurable_video_ads_quartile_impressions_qty AS DOUBLE) AS measurable_video_ads_quartile_impressions_qty
# MAGIC
# MAGIC FROM delivery_final_deduped;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW delivery_with_site_info AS
# MAGIC SELECT 
# MAGIC     d.*,
# MAGIC     s.site_section_name
# MAGIC FROM delivery_final_cleaned d
# MAGIC LEFT JOIN (
# MAGIC     SELECT DISTINCT site_section_id, site_section_name
# MAGIC     FROM site_dim_vw
# MAGIC ) s
# MAGIC ON d.site_section_id = s.site_section_id;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW delivery_with_site_custom AS
# MAGIC SELECT 
# MAGIC     d.*,
# MAGIC     sc.dn1,
# MAGIC     sc.pg1
# MAGIC FROM delivery_with_site_info d
# MAGIC LEFT JOIN site_custom_dim_vw sc
# MAGIC     ON d.site_section_id = sc.site_section_id;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW delivery_with_device_flags AS
# MAGIC SELECT 
# MAGIC     *,
# MAGIC     
# MAGIC     -- Derived device category from site_section_name
# MAGIC     CASE
# MAGIC         WHEN site_section_name LIKE '%: CTV:%' THEN 'CTV'
# MAGIC         WHEN site_section_name LIKE '%: STB%' THEN 'STB'
# MAGIC         WHEN site_section_name LIKE '%Comcast Production%' THEN 'STB'
# MAGIC         WHEN site_section_name LIKE '%: Mobile App:%' THEN 'MB/TB'
# MAGIC         WHEN site_section_name LIKE '%Handheld%' THEN 'MB/TB'
# MAGIC         WHEN site_section_name LIKE '%Tablet%' THEN 'MB/TB'
# MAGIC         WHEN site_section_name LIKE '%: Web%' THEN 'DT'
# MAGIC         WHEN site_section_name LIKE '%Desktop%' THEN 'DT'
# MAGIC         ELSE 'Unk'
# MAGIC     END AS dn2,
# MAGIC
# MAGIC     -- Derived platform group from site_section_name
# MAGIC     CASE
# MAGIC         WHEN site_section_name LIKE '%FNC%' THEN 'FNC'
# MAGIC         WHEN site_section_name LIKE '%FBN%' THEN 'FBN'
# MAGIC         WHEN site_section_name LIKE '%FOX Nation%' THEN 'FOX Nation'
# MAGIC         WHEN site_section_name LIKE '%Hulu%' THEN 'Hulu'
# MAGIC         WHEN site_section_name LIKE '%Tubi%' THEN 'Tubi'
# MAGIC         WHEN site_section_name LIKE '%: STB%' THEN 'STB VOD'
# MAGIC         WHEN site_section_name LIKE '%Comcast Production%' THEN 'STB VOD'
# MAGIC         WHEN site_section_name LIKE '%Partner%' THEN 'Off-Platform'
# MAGIC         WHEN site_section_name LIKE '%Run Of Site%' THEN 'Off-Platform'
# MAGIC         WHEN site_section_name LIKE '%Owned%' THEN 'O&O'
# MAGIC         ELSE 'Other'
# MAGIC     END AS pg2
# MAGIC
# MAGIC FROM delivery_with_site_custom;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW delivery_platform_final AS
# MAGIC SELECT 
# MAGIC     event_date, distributor_name, distributor_id,
# MAGIC
# MAGIC     -- Overwritten Site_Short_Name
# MAGIC     CASE
# MAGIC         WHEN site_section_name LIKE '%FNC%' THEN 'FNC'
# MAGIC         WHEN site_section_name LIKE '%FBN%' THEN 'FBN'
# MAGIC         ELSE 'Others'
# MAGIC     END AS site_short_name,
# MAGIC
# MAGIC     site_section_id,
# MAGIC     video_id, series_id, series_name, global_ad_unit_position, global_ad_unit_class, global_ad_unit_category,
# MAGIC     creative_id, ad_unit_id, placement_id, insertion_order_id, campaign_id, sales_channel_type, reseller_name,
# MAGIC     reseller_id, mrm_rule_id, advertiser_id, advertiser_name, agency_name,priority_setting, dsp_name, trading_desk_name,
# MAGIC     buyer_name, buyer_priority, deal_id, deal_name, deal_type_point_in_time, deal_type, deal_override_priority, programmatic_ad_id,
# MAGIC     programmatic_advertiser_id, programmatic_advertiser_name,
# MAGIC
# MAGIC     -- Final Device
# MAGIC     COALESCE(dn1, dn2) AS device_name,
# MAGIC
# MAGIC     -- Final Specific_Device
# MAGIC     CASE
# MAGIC         WHEN site_section_name LIKE '%:%' THEN
# MAGIC             CASE 
# MAGIC                 WHEN COALESCE(pg1, pg2) = 'Off-Platform' THEN SPLIT_PART(site_section_name, ':', 6)
# MAGIC                 ELSE SPLIT_PART(site_section_name, ':', 5)
# MAGIC             END
# MAGIC         ELSE 'N/A'
# MAGIC     END AS specific_device,
# MAGIC
# MAGIC     -- Overwritten Platform
# MAGIC     CASE
# MAGIC         WHEN site_section_name LIKE '%Run Of Site%' THEN
# MAGIC             CASE
# MAGIC                 WHEN site_section_name LIKE '%Fubo%' THEN 'FuboTV'
# MAGIC                 ELSE SUBSTRING(site_section_name, 34, INSTR(SUBSTRING(site_section_name, 34), ' ') - 1)
# MAGIC             END
# MAGIC         WHEN site_section_name LIKE '%SS: Owned: %' THEN
# MAGIC             SUBSTRING(site_section_name, 12, INSTR(SUBSTRING(site_section_name, 12), ':') - 1)
# MAGIC         WHEN site_section_name LIKE '%SS: Partner: %' THEN
# MAGIC             SUBSTRING(site_section_name, 14, INSTR(SUBSTRING(site_section_name, 14), ':') - 1)
# MAGIC         ELSE NULL
# MAGIC     END AS platform_name,
# MAGIC
# MAGIC     -- Final Platform_Group
# MAGIC     COALESCE(pg1, pg2) AS platform_group,
# MAGIC
# MAGIC     -- Updated flag columns
# MAGIC     CASE WHEN site_section_name LIKE '%Live: FOX%' THEN 'T' ELSE 'F' END AS is_live_fox_ss,
# MAGIC     CASE WHEN site_section_name LIKE '%VOD%' THEN 'T' ELSE 'F' END AS is_fep,
# MAGIC     CASE WHEN site_section_name LIKE '%Live%' THEN 'T' ELSE 'F' END AS is_go,
# MAGIC
# MAGIC     delivery_category, matched_audience_item_name,
# MAGIC     direct_guaranteed_impressions, direct_pre_emptible_impressions, promo_guaranteed_impressions, promo_pre_emptible_impressions,
# MAGIC     programmatic_guaranteed_impressions, inventory_share_impressions, affiliates_impressions, hard_guaranteed_impressions, backfill_impressions,
# MAGIC     net_counted_ads_qty, gross_counted_ads_qty, run_revenue_amount, ecpm_amt, delivered_clicks_qty,
# MAGIC     measurable_video_ads_quartile_impressions_qty
# MAGIC
# MAGIC FROM delivery_with_device_flags;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW delivery_final_aggregated AS
# MAGIC SELECT
# MAGIC     -- Dimensions
# MAGIC     event_date, distributor_name, distributor_id, site_short_name, site_section_id, video_id, series_id,
# MAGIC     series_name, global_ad_unit_position, global_ad_unit_class, global_ad_unit_category, creative_id,
# MAGIC     ad_unit_id, placement_id, insertion_order_id, campaign_id, sales_channel_type, reseller_name,
# MAGIC     reseller_id, mrm_rule_id, advertiser_id, advertiser_name, agency_name, priority_setting, dsp_name,
# MAGIC     trading_desk_name, buyer_name, buyer_priority, deal_id, deal_name, deal_type_point_in_time, deal_type, deal_override_priority,
# MAGIC     programmatic_ad_id, programmatic_advertiser_id, programmatic_advertiser_name, device_name, specific_device,
# MAGIC     platform_name, platform_group, is_live_fox_ss, is_fep, is_go, delivery_category, matched_audience_item_name,
# MAGIC
# MAGIC     -- Aggregates
# MAGIC     SUM(direct_guaranteed_impressions) AS direct_guaranteed_impressions,
# MAGIC     SUM(direct_pre_emptible_impressions) AS direct_pre_emptible_impressions,
# MAGIC     SUM(promo_guaranteed_impressions) AS promo_guaranteed_impressions,
# MAGIC     SUM(promo_pre_emptible_impressions) AS promo_pre_emptible_impressions,
# MAGIC     SUM(programmatic_guaranteed_impressions) AS programmatic_guaranteed_impressions,
# MAGIC     SUM(inventory_share_impressions) AS inventory_share_impressions,
# MAGIC     SUM(affiliates_impressions) AS affiliates_impressions,
# MAGIC     SUM(hard_guaranteed_impressions) AS hard_guaranteed_impressions,
# MAGIC     SUM(backfill_impressions) AS backfill_impressions,
# MAGIC     SUM(net_counted_ads_qty) AS net_counted_ads_qty,
# MAGIC     SUM(gross_counted_ads_qty) AS gross_counted_ads_qty,
# MAGIC     SUM(run_revenue_amount) AS run_revenue_amount,
# MAGIC     SUM(ecpm_amt) AS ecpm_amt,
# MAGIC     SUM(delivered_clicks_qty) AS delivered_clicks_qty,
# MAGIC     SUM(measurable_video_ads_quartile_impressions_qty) AS measurable_video_ads_quartile_impressions_qty
# MAGIC
# MAGIC FROM delivery_platform_final
# MAGIC GROUP BY
# MAGIC     event_date, distributor_name, distributor_id, site_short_name, site_section_id, video_id, series_id,
# MAGIC     series_name, global_ad_unit_position, global_ad_unit_class, global_ad_unit_category, creative_id,
# MAGIC     ad_unit_id, placement_id, insertion_order_id, campaign_id, sales_channel_type, reseller_name,
# MAGIC     reseller_id, mrm_rule_id, advertiser_id, advertiser_name, agency_name, priority_setting, dsp_name,
# MAGIC     trading_desk_name, buyer_name, buyer_priority, deal_id, deal_name, deal_type_point_in_time, deal_type, deal_override_priority,
# MAGIC     programmatic_ad_id, programmatic_advertiser_id, programmatic_advertiser_name, device_name, specific_device,
# MAGIC     platform_name, platform_group, is_live_fox_ss, is_fep, is_go, delivery_category, matched_audience_item_name;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from delivery_final_aggregated limit 30

# COMMAND ----------

# MAGIC %md DBT LOGIC TO BE ADDED BELOW

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW final_view AS
# MAGIC SELECT
# MAGIC     d.event_date AS event_date,
# MAGIC     v.primary_video_group_id,
# MAGIC     v.primary_video_group_name,
# MAGIC     CASE
# MAGIC         WHEN lower(v.secondary_video_group_name) = 'unassigned' AND v.video_name = 'V: Partner: Youtube TV: FS1 Live' THEN 18830626
# MAGIC         WHEN lower(v.secondary_video_group_name) = 'unassigned' AND v.video_name = 'V: Partner: Youtube TV: FS2 Live' THEN 18830626
# MAGIC         WHEN lower(v.secondary_video_group_name) = 'unassigned' AND lower(rs.show_name) = 'studio shows' THEN 18830626
# MAGIC         ELSE COALESCE(usvg.assigned_secondary_video_group_id, v.secondary_video_group_id)
# MAGIC     END AS secondary_video_group_id,
# MAGIC     CASE
# MAGIC         WHEN lower(v.secondary_video_group_name) = 'unassigned' AND v.video_name = 'V: Partner: Youtube TV: FS1 Live' THEN 'VG: SPORTS: Long Form: Talk Shows'
# MAGIC         WHEN lower(v.secondary_video_group_name) = 'unassigned' AND v.video_name = 'V: Partner: Youtube TV: FS2 Live' THEN 'VG: SPORTS: Long Form: Talk Shows'
# MAGIC         WHEN lower(v.secondary_video_group_name) = 'unassigned' AND lower(rs.show_name) = 'studio shows' THEN 'VG: SPORTS: Long Form: Talk Shows'
# MAGIC         ELSE COALESCE(usvg.assigned_secondary_video_group_name, v.secondary_video_group_name)
# MAGIC     END AS secondary_video_group_name,
# MAGIC     COALESCE(svgmo.season_video_group_id, v.season_video_group_id) AS season_video_group_id,
# MAGIC     COALESCE(svgmo.season_video_group_name, v.season_video_group_name) AS season_video_group_name,
# MAGIC     CASE
# MAGIC         WHEN upper(global_ad_unit_category) = 'DISPLAY ADS' THEN 'Display'
# MAGIC         WHEN LOWER(d.series_name) LIKE '%deportes%' THEN 'Deportes'
# MAGIC         WHEN v.primary_video_group_id = '18773867' THEN 'BTN'
# MAGIC         WHEN LOWER(d.series_name) LIKE '%monarch%' THEN 'Entertainment'
# MAGIC
# MAGIC         -- Weather Logic
# MAGIC         WHEN LOWER(d.series_name) LIKE '%fox weather%'
# MAGIC              OR LOWER(s.site_section_name) LIKE '%fox weather%' THEN 'Weather'
# MAGIC
# MAGIC         -- News/Business Logic
# MAGIC         WHEN v.primary_video_group_id IN ('20474534', '20474467')
# MAGIC              OR LOWER(d.series_name) LIKE '%vs: news%'
# MAGIC              OR LOWER(d.series_name) LIKE '%vs: fnc%'
# MAGIC              OR LOWER(d.series_name) LIKE '%vs: fbn%'
# MAGIC              OR LOWER(d.series_name) LIKE '%: fnc%'
# MAGIC              OR LOWER(d.series_name) LIKE '%: fbn%'
# MAGIC              OR LOWER(s.site_section_name) LIKE '%fox news app%'
# MAGIC              OR LOWER(s.site_section_name) LIKE '%fox business app%' THEN 'News/Business'
# MAGIC
# MAGIC         -- Fox Nation Logic
# MAGIC         WHEN LOWER(d.series_name) LIKE '%vs: nation%'
# MAGIC              OR LOWER(s.site_section_name) LIKE '%fox nation%' THEN 'Fox Nation'
# MAGIC         WHEN s.site_section_name LIKE '%Fox One%' AND s.site_section_name LIKE '%Nation%' THEN 'Fox Nation'
# MAGIC
# MAGIC         WHEN LOWER(s.site_section_name) LIKE '%tmz app%' THEN 'TMZ'
# MAGIC         WHEN LOWER(s.site_section_name) LIKE '%outkick app%' THEN 'Outkick'
# MAGIC         WHEN LOWER(d.series_name) LIKE '%ultimate tag%' THEN 'Entertainment'
# MAGIC         WHEN v.primary_video_group_id = '18698796' THEN 'Sports SFV'
# MAGIC
# MAGIC         WHEN v.primary_video_group_id = '414462094' OR v.video_name LIKE '%NIVA%' THEN 'NIVA'
# MAGIC
# MAGIC         -- Sports LFV Logic
# MAGIC         WHEN v.primary_video_group_id IN ('18698781', '241987048', '241987474')
# MAGIC              OR UPPER(d.series_name) LIKE '%WWE%'
# MAGIC              OR UPPER(d.series_name) LIKE '%SMACKDOWN%'
# MAGIC              OR UPPER(d.series_name) LIKE '%VS: SPORTS%' THEN 'Sports LFV'
# MAGIC
# MAGIC         -- Entertainment Logic
# MAGIC         WHEN v.primary_video_group_id = '18652208'
# MAGIC              OR LOWER(s.site_section_name) LIKE '%fox ent%'
# MAGIC              OR LOWER(d.series_name) LIKE '%vs: ent: fox:%' THEN 'Entertainment'
# MAGIC
# MAGIC         WHEN v.primary_video_group_id = '18698699' THEN 'Entertainment SFV'
# MAGIC
# MAGIC         -- Fox One Cross-Sells
# MAGIC         WHEN s.site_section_name LIKE '%Fox One%' AND s.site_section_name LIKE '%ENT%' THEN 'Entertainment'
# MAGIC         WHEN s.site_section_name LIKE '%Fox One%' AND s.site_section_name LIKE '%Sports%' THEN 'Sports LFV'
# MAGIC         WHEN s.site_section_name LIKE '%Fox One%' AND s.site_section_name LIKE '%Weather%' THEN 'Weather'
# MAGIC
# MAGIC         -- Tubi Specific Logic
# MAGIC         WHEN UPPER(s.site_section_name) LIKE '%TUBI%' AND d.series_name = 'Unknown Series' THEN
# MAGIC             CASE
# MAGIC                 WHEN v.video_name LIKE '%FOX Entertainment%' THEN 'Entertainment'
# MAGIC                 WHEN LOWER(v.video_name) LIKE '%gordon ramsay%' THEN 'Entertainment'
# MAGIC                 WHEN LOWER(v.video_name) LIKE '%masterchef%' THEN 'Entertainment'
# MAGIC                 WHEN LOWER(v.video_name) LIKE "%hell's kitchen%" THEN 'Entertainment'
# MAGIC                 WHEN LOWER(v.video_name) LIKE '%masked singer%' THEN 'Entertainment'
# MAGIC                 WHEN v.video_name LIKE '%FOX Sports%' THEN 'Sports LFV'
# MAGIC                 WHEN v.video_name LIKE '%FOX News%' THEN 'News/Business'
# MAGIC                 WHEN v.video_name LIKE '%FOX Weather%' THEN 'Weather'
# MAGIC                 ELSE 'Tubi' -- Default if within Tubi/Unknown but no video match
# MAGIC             END
# MAGIC
# MAGIC         WHEN d.series_name = 'Unknown Series' AND LOWER(v.video_name) LIKE '%masked singer%' THEN 'Entertainment'
# MAGIC         WHEN LOWER(s.site_section_name) LIKE '%tubi%' THEN 'Tubi'
# MAGIC
# MAGIC         ELSE 'Unassigned'
# MAGIC     END AS video_vertical,
# MAGIC     v.video_id,
# MAGIC     v.video_name,
# MAGIC     v.prefered_video_group,
# MAGIC     d.distributor_name,
# MAGIC     d.distributor_id,
# MAGIC     d.series_id,
# MAGIC     d.series_name,
# MAGIC     COALESCE(rs.show_name, 'N/A') AS show_name,
# MAGIC     CASE WHEN svg.series_name IS NULL THEN 'Out of Season' ELSE 'In Season' END AS season_in_out_flag,
# MAGIC     c.creative_id ,
# MAGIC     c.creative_name,
# MAGIC     c.creative_duration_secs,
# MAGIC     au.ad_unit_id ,
# MAGIC     au.ad_unit_price,
# MAGIC     au.ad_unit_external_id,
# MAGIC     p.placement_id ,
# MAGIC     p.placement_external_id,
# MAGIC     p.placement_name,
# MAGIC     p.placement_budgeted_impressions,
# MAGIC     p.placement_start_timestamp_est,
# MAGIC     p.placement_end_timestamp_est,
# MAGIC     p.placement_industry,
# MAGIC     p.placement_status,
# MAGIC     p.placement_type,
# MAGIC     p.unified_yield,
# MAGIC     p.booked_on_target_impression_goal,
# MAGIC     p.budget_model,
# MAGIC     p.demographic_on_target_calculation,
# MAGIC     p.demographic_data_source,
# MAGIC     p.forced_over_delivery_percent,
# MAGIC     p.impression_goal,
# MAGIC     p.delivery_pacing,
# MAGIC     p.estimated_impression_goal,
# MAGIC     p.delivery_priority,
# MAGIC     COALESCE(p_lkp.delivery_priority_type_point_in_time, p.delivery_priority) AS delivery_priority_point_in_time,
# MAGIC     io.insertion_order_id,
# MAGIC     io.insertion_order_name,
# MAGIC     io.insertion_order_external_id,
# MAGIC     io.insertion_order_end_timestamp_est,
# MAGIC     io.insertion_order_primary_salesperson,
# MAGIC     io.insertion_order_primary_trafficker,
# MAGIC     io.insertion_order_start_timestamp_est,
# MAGIC     io.insertion_order_status,
# MAGIC     camp.campaign_id ,
# MAGIC     camp.campaign_name,
# MAGIC     camp.campaign_external_id,
# MAGIC     camp.campaign_start_timestamp_est,
# MAGIC     camp.campaign_end_timestamp_est,
# MAGIC     d.global_ad_unit_position ,
# MAGIC     d.global_ad_unit_class ,
# MAGIC     d.advertiser_id ,
# MAGIC     d.advertiser_name ,
# MAGIC     d.agency_name ,
# MAGIC     d.delivery_category ,
# MAGIC     d.matched_audience_item_name,
# MAGIC     d.device_name,
# MAGIC     d.specific_device,
# MAGIC     d.platform_name,
# MAGIC     d.platform_group,
# MAGIC     d.is_live_fox_ss,
# MAGIC     d.is_FEP,
# MAGIC     d.is_GO,
# MAGIC
# MAGIC     SUM(CAST(direct_guaranteed_impressions AS bigint)) AS direct_guaranteed_impressions,
# MAGIC     SUM(CAST(direct_pre_emptible_impressions AS bigint)) AS direct_pre_emptible_impressions,
# MAGIC     SUM(CAST(promo_guaranteed_impressions AS bigint)) AS promo_guaranteed_impressions,
# MAGIC     SUM(CAST(promo_pre_emptible_impressions AS bigint)) AS promo_pre_emptible_impressions,
# MAGIC     SUM(CAST(programmatic_guaranteed_impressions AS bigint)) AS programmatic_guaranteed_impressions,
# MAGIC     SUM(CAST(inventory_share_impressions AS bigint)) AS inventory_share_impressions,
# MAGIC     SUM(CAST(affiliates_impressions AS bigint)) AS affiliates_impressions,
# MAGIC     SUM(CAST(hard_guaranteed_impressions AS bigint)) AS hard_guaranteed_impressions,
# MAGIC     SUM(CAST(backfill_impressions AS bigint)) AS backfill_impressions,
# MAGIC     SUM(CAST(d.net_counted_ads_qty AS bigint)) AS net_counted_ads,
# MAGIC     SUM(CAST(run_revenue_amount AS decimal(22, 7))) AS run_revenue_amount,
# MAGIC     --AVG(CAST(ecpm_amt AS NUMERIC)) AS ecpm,
# MAGIC     SUM(CAST(delivered_clicks_qty AS bigint)) AS delivered_clicks,
# MAGIC     SUM(CAST(measurable_video_ads_quartile_impressions_qty AS bigint)) AS measurable_video_ads_quartile_impressions,
# MAGIC     SUM(CAST(gross_counted_ads_qty AS bigint)) AS gross_counted_ads,
# MAGIC
# MAGIC     d.sales_channel_type ,
# MAGIC     CAST(d.reseller_name AS STRING) as reseller_name,
# MAGIC     CAST(d.reseller_id AS BIGINT) as reseller_id,
# MAGIC     r.mrm_rule_id,
# MAGIC     r.mrm_rule_name,
# MAGIC     r.mrm_rule_impression_goal,
# MAGIC     r.mrm_rule_start_timestamp_est,
# MAGIC     r.mrm_rule_end_timestamp_est,
# MAGIC     r.priority_setting,
# MAGIC     COALESCE(r_lkp.priority_setting_point_in_time, r.priority_setting) AS priority_setting_point_in_time,
# MAGIC     d.dsp_name ,
# MAGIC     d.trading_desk_name ,
# MAGIC     d.buyer_name ,
# MAGIC     d.buyer_priority ,
# MAGIC     d.deal_id,
# MAGIC     d.deal_name,
# MAGIC     deal.deal_salesperson,
# MAGIC     deal.external_deal_id,
# MAGIC     deal.deal_impression_goal,
# MAGIC     deal.deal_start_timestamp_est,
# MAGIC     deal.deal_end_timestamp_est,
# MAGIC     d.deal_type_point_in_time ,
# MAGIC     d.deal_type ,
# MAGIC     d.deal_override_priority,
# MAGIC     d.programmatic_ad_id,
# MAGIC     pc.programmatic_industry_name,
# MAGIC     pc.programmatic_brand_name,
# MAGIC     d.programmatic_advertiser_id ,
# MAGIC     d.programmatic_advertiser_name ,
# MAGIC     d.site_section_id,
# MAGIC     s.site_section_name,
# MAGIC     d.global_ad_unit_category,
# MAGIC     CAST(NULL as STRING) as sales_type,
# MAGIC     CAST(NULL as STRING) as finance_sales_type,
# MAGIC     CAST(NULL as STRING) as in_operative_flag,
# MAGIC     CASE WHEN upper(s.site_section_name) LIKE '%FOXNOW%' THEN 'Y' ELSE 'N' END AS is_fox_now,
# MAGIC     CAST(NULL as STRING) as advertiser_category,
# MAGIC     CAST(NULL as STRING) as demo_Band,
# MAGIC     CAST(NULL as STRING) as p2_plus_cpm,
# MAGIC     CAST(NULL AS STRING) as hh_cpm,
# MAGIC     CAST(NULL AS BIGINT) as parent_line_item_id,
# MAGIC     CAST(NULL AS STRING) AS estimated_demo_comp_vpvh,
# MAGIC     CAST(NULL  AS STRING) AS billable_third_party_descr,
# MAGIC     CAST(NULL AS BIGINT) AS is_makegood_flag,
# MAGIC     CAST(NULL AS BIGINT) AS is_added_value_flag,
# MAGIC     CAST(NULL  AS STRING) AS marketplace_type,
# MAGIC     CAST(NULL  AS STRING) AS product_name,
# MAGIC     CAST(NULL  AS STRING) AS placement_property,
# MAGIC     CAST(NULL  AS STRING) AS duration,
# MAGIC     CAST(NULL  AS STRING) AS freewheel_industry,
# MAGIC     CAST(NULL  AS STRING) AS advertiser_external_id,
# MAGIC     CAST(NULL  AS STRING) AS agency_external_id,
# MAGIC     CAST(NULL  AS STRING) AS foxipedia_advertiser_id,
# MAGIC     CAST(NULL  AS STRING) AS foxipedia_advertiser_name,
# MAGIC     CAST(NULL  AS STRING) AS foxipedia_advertiser_parent_name,
# MAGIC     CAST(NULL  AS STRING) AS foxipedia_advertiser_corporate_name,
# MAGIC     CAST(NULL  AS STRING) AS foxipedia_agency_id,
# MAGIC     CAST(NULL  AS STRING) AS foxipedia_agency_name,
# MAGIC     CAST(NULL  AS STRING) AS foxipedia_agency_parent_name,
# MAGIC     CAST(NULL  AS STRING) AS foxipedia_agency_holding_name,
# MAGIC     CASE WHEN pa.promo_advertiser IS NOT NULL THEN 'Y' ELSE 'N' END AS is_promo_advertiser,
# MAGIC     CAST(NULL  AS STRING) AS placement_delivered_demo_comp,
# MAGIC     CAST(NULL  AS STRING) AS property_delivered_demo_comp,
# MAGIC     CAST(NULL  AS STRING) AS parent_line_item_max_property_comp,
# MAGIC     DATE_FORMAT(CURRENT_TIMESTAMP(), 'yyyy-MM-dd') AS etl_load_date,
# MAGIC     CURRENT_TIMESTAMP() AS etl_load_timestamp
# MAGIC
# MAGIC FROM delivery_final_aggregated d
# MAGIC LEFT JOIN promo_advertiser_dim_vw pa
# MAGIC     ON lower(d.advertiser_name) = lower(pa.promo_advertiser)
# MAGIC LEFT JOIN video_group_custom_dim_vw v
# MAGIC     ON d.video_id = v.video_id
# MAGIC LEFT JOIN mrm_rule_dim_vw r
# MAGIC     ON d.mrm_rule_id = r.mrm_rule_id
# MAGIC LEFT JOIN mrm_rule_lkp_vw r_lkp
# MAGIC     ON d.mrm_rule_id = r_lkp.mrm_rule_id AND d.event_date = r_lkp.event_date
# MAGIC LEFT JOIN deal_dim_vw deal
# MAGIC     ON d.deal_id = deal.deal_id
# MAGIC LEFT JOIN programmatic_creative_dim_vw pc
# MAGIC     ON d.programmatic_ad_id = pc.programmatic_ad_id
# MAGIC LEFT JOIN creative_dim_vw c
# MAGIC     ON d.creative_id = c.creative_id
# MAGIC LEFT JOIN ad_unit_dim_vw au
# MAGIC     ON d.ad_unit_id = au.ad_unit_id
# MAGIC LEFT JOIN placement_dim_vw p
# MAGIC     ON d.placement_id = p.placement_id
# MAGIC LEFT JOIN placement_lkp_vw p_lkp
# MAGIC     ON d.placement_id = p_lkp.placement_id AND d.event_date = p_lkp.event_date
# MAGIC LEFT JOIN insertion_order_dim_vw io
# MAGIC     ON d.insertion_order_id = io.insertion_order_id
# MAGIC LEFT JOIN campaign_dim_vw camp
# MAGIC     ON d.campaign_id = camp.campaign_id
# MAGIC LEFT JOIN rl_series_show_dim_vw rs
# MAGIC     ON d.series_name = rs.series_name
# MAGIC LEFT JOIN season_video_group_manual_override_dim_vw svgmo
# MAGIC     ON v.video_name = svgmo.video_name
# MAGIC LEFT JOIN season_video_group_in_out_dim_vw svg
# MAGIC     ON COALESCE(svgmo.season_video_group_id, v.season_video_group_id) = svg.season_video_group_id
# MAGIC     AND d.event_date BETWEEN svg.start_date AND svg.end_date
# MAGIC LEFT JOIN unassigned_secondary_video_group_dim_vw usvg
# MAGIC     ON usvg.video_name = v.video_name 
# MAGIC     AND usvg.primary_video_group_name = v.primary_video_group_name
# MAGIC     AND usvg.secondary_video_group_name = v.secondary_video_group_name
# MAGIC     AND usvg.series_name = d.series_name
# MAGIC LEFT JOIN site_dim_vw s
# MAGIC     ON d.site_section_id = s.site_section_id
# MAGIC     GROUP BY
# MAGIC     d.event_date,
# MAGIC     v.primary_video_group_id,
# MAGIC     v.primary_video_group_name,
# MAGIC     v.secondary_video_group_name,
# MAGIC     v.video_name,
# MAGIC     rs.show_name,
# MAGIC     usvg.assigned_secondary_video_group_id,
# MAGIC     v.secondary_video_group_id,
# MAGIC     usvg.assigned_secondary_video_group_name,
# MAGIC     svgmo.season_video_group_id,
# MAGIC     v.season_video_group_id,
# MAGIC     svgmo.season_video_group_name,
# MAGIC     v.season_video_group_name,
# MAGIC     d.global_ad_unit_category,
# MAGIC     d.series_name,
# MAGIC     v.video_id,
# MAGIC     v.prefered_video_group,
# MAGIC     d.distributor_name,
# MAGIC     d.distributor_id,
# MAGIC     d.series_id,
# MAGIC     rs.show_name,
# MAGIC     svg.series_name,
# MAGIC     c.creative_id,
# MAGIC     c.creative_name,
# MAGIC     c.creative_duration_secs,
# MAGIC     au.ad_unit_id,
# MAGIC     au.ad_unit_price,
# MAGIC     au.ad_unit_external_id,
# MAGIC     p.placement_id,
# MAGIC     p.placement_external_id,
# MAGIC     p.placement_name,
# MAGIC     p.placement_budgeted_impressions,
# MAGIC     p.placement_start_timestamp_est,
# MAGIC     p.placement_end_timestamp_est,
# MAGIC     p.placement_industry,
# MAGIC     p.placement_status,
# MAGIC     p.placement_type,
# MAGIC     p.unified_yield,
# MAGIC     p.booked_on_target_impression_goal,
# MAGIC     p.budget_model,
# MAGIC     p.demographic_on_target_calculation,
# MAGIC     p.demographic_data_source,
# MAGIC     p.forced_over_delivery_percent,
# MAGIC     p.impression_goal,
# MAGIC     p.delivery_pacing,
# MAGIC     p.estimated_impression_goal,
# MAGIC     p.delivery_priority,
# MAGIC     p_lkp.delivery_priority_type_point_in_time,
# MAGIC     p.delivery_priority,
# MAGIC     io.insertion_order_id,
# MAGIC     io.insertion_order_name,
# MAGIC     io.insertion_order_external_id,
# MAGIC     io.insertion_order_end_timestamp_est,
# MAGIC     io.insertion_order_primary_salesperson,
# MAGIC     io.insertion_order_primary_trafficker,
# MAGIC     io.insertion_order_start_timestamp_est,
# MAGIC     io.insertion_order_status,
# MAGIC     camp.campaign_id,
# MAGIC     camp.campaign_name,
# MAGIC     camp.campaign_external_id,
# MAGIC     camp.campaign_start_timestamp_est,
# MAGIC     camp.campaign_end_timestamp_est,
# MAGIC     d.global_ad_unit_position,
# MAGIC     d.global_ad_unit_class,
# MAGIC     d.advertiser_id,
# MAGIC     d.advertiser_name,
# MAGIC     d.agency_name,
# MAGIC     d.delivery_category,
# MAGIC     d.matched_audience_item_name,
# MAGIC     d.device_name,
# MAGIC     d.specific_device,
# MAGIC     d.platform_name,
# MAGIC     d.platform_group,
# MAGIC     d.is_live_fox_ss,
# MAGIC     d.is_FEP,
# MAGIC     d.is_GO,
# MAGIC     d.sales_channel_type,
# MAGIC     d.reseller_name,
# MAGIC     d.reseller_id,
# MAGIC     r.mrm_rule_id,
# MAGIC     r.mrm_rule_name,
# MAGIC     r.mrm_rule_impression_goal,
# MAGIC     r.mrm_rule_start_timestamp_est,
# MAGIC     r.mrm_rule_end_timestamp_est,
# MAGIC     r.priority_setting,
# MAGIC     r_lkp.priority_setting_point_in_time,
# MAGIC     d.dsp_name,
# MAGIC     d.trading_desk_name,
# MAGIC     d.buyer_name,
# MAGIC     d.buyer_priority,
# MAGIC     d.deal_id,
# MAGIC     d.deal_name,
# MAGIC     deal.deal_salesperson,
# MAGIC     deal.external_deal_id,
# MAGIC     deal.deal_impression_goal,
# MAGIC     deal.deal_start_timestamp_est,
# MAGIC     deal.deal_end_timestamp_est,
# MAGIC     d.deal_type_point_in_time,
# MAGIC     d.deal_type,
# MAGIC     d.deal_override_priority,
# MAGIC     d.programmatic_ad_id,
# MAGIC     pc.programmatic_industry_name,
# MAGIC     pc.programmatic_brand_name,
# MAGIC     d.programmatic_advertiser_id,
# MAGIC     d.site_section_id,
# MAGIC     d.programmatic_advertiser_name,
# MAGIC     d.global_ad_unit_category,
# MAGIC     s.site_section_name,
# MAGIC     pa.promo_advertiser;

# COMMAND ----------

df=spark.sql("""select * from final_view""")

# COMMAND ----------

# df.write.format('delta')\
#     .mode('overwrite')\
#     .partitionBy('event_date')\
#     .option('mergeSchema', 'true')\
#     .option('overwriteDynamicPartitions', 'true')\
#     .option('delta.enableDeletionVectors', 'false')\
#     .option('delta.enableIcebergCompatV2', 'true')\
#     .option('delta.universalFormat.enabledFormats', 'iceberg')\
#     .option('delta.columnMapping.mode', 'name')\
#     .saveAsTable(f"fox_bi_prod.silver_ads.ft_freewheel_matched_audience_delivery_daily_data")

df.write.format('delta')\
    .mode('overwrite')\
    .option('partitionOverwriteMode', 'dynamic')\
    .saveAsTable('fox_bi_prod.silver_ads.ft_freewheel_matched_audience_delivery_daily_data')
