# Databricks notebook source
catalog_name = dbutils.widgets.get('catalog_name')
raw_schema_name = dbutils.widgets.get('raw_schema_name')
bronze_schema_name = dbutils.widgets.get('bronze_schema_name')

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql import types as T
from datetime import datetime, timedelta

# COMMAND ----------

def load_format_table(table_name):
    """
    Loads 'raw fw tables' and formats the columns names and types.
    """

    third_party_table = spark.read.table(f'{catalog_name}.{raw_schema_name}.{table_name}')
    
    column_format_info = {
        'Ad Unit Id': ['ad_unit_id', T.LongType()],
        'Ad Unit Name': ['ad_unit_name', T.StringType()],
        'Creative Name': ['creative_name', T.StringType()],
        'Creative Identifier': ['creative_id', T.StringType()],
        'Order ID': ['order_id', T.LongType()],
        'Order Name': ['order_name', T.StringType()],
        'Mapped Local Creative Name': ['mapped_local_creative_name', T.StringType()],
        'Mapped Local Creative Id': ['mapped_local_creative_id', T.StringType()],
        '3rd Party Name': ['third_party_name', T.StringType()],
        '3rd Party Creative Name': ['third_party_creative_name', T.StringType()],
        '3rd Party Creative Id': ['third_party_creative_id', T.StringType()],
        'Impressions': ['impressions', T.LongType()],
        'Impressions (3rd Party)': ['impressions_third_party', T.LongType()],
        'Clicks': ['clicks', T.LongType()],
        'Clicks (3rd Party)': ['clicks_third_party', T.LongType()],
        'Report Start Date': ['report_start_date', T.DateType()],
        'Report End Date': ['report_end_date', T.DateType()],
        'Report Start Date (3rd Party)': ['report_start_date_third_party', T.DateType()],
        'Report End Date (3rd Party)': ['report_end_date_third_party', T.DateType()],
        'Campaign Start': ['campaign_start_date', T.DateType()],
        'Campaign End': ['campaign_end_date', T.DateType()],
        '3rd Party Video 0': ['third_party_video_0_percent_complete', T.LongType()],
        '3rd Party Video 100': ['third_party_video_100_percent_complete', T.LongType()],
        '3rd Party Video 25': ['third_party_video_25_percent_complete', T.LongType()],
        '3rd Party Video 50': ['third_party_video_50_percent_complete', T.LongType()],
        '3rd Party Video 75': ['third_party_video_75_percent_complete', T.LongType()],
        '3rd Party Video Views': ['third_party_video_views', T.LongType()],
        '3rd Party Total Video Plays': ['third_party_total_video_plays', T.LongType()],
        '3rd Party Advertiser Id': ['third_party_advertiser_id', T.LongType()],
        '3rd Party Advertiser Name': ['third_party_advertiser_name', T.StringType()],
        '3rd Party Agency Id': ['third_party_agency_id', T.StringType()],
        '3rd Party Agency Name': ['third_party_agency_name', T.StringType()],
        'Unsplit 3rd Party Clicks': ['unsplit_third_party_clicks', T.LongType()],
        'Unsplit 3rd Party Impressions': ['unsplit_third_party_impressions', T.LongType()],
        '3rd Party In Target Impressions': ['third_party_in_target_impressions', T.LongType()],
        '3rd Party On Target Imps': ['third_party_on_target_impressions', T.LongType()],
        '3rd Party Billable Impressions': ['third_party_billable_impressions', T.LongType()],
        '3rd Party Non-Billable Impressions': ['third_party_non-billable_impressions', T.LongType()],
        '3rd Party Non-Billable Clicks': ['third_party_non-billable_clicks', T.LongType()],
        '3rd Party Billable Clicks': ['third_party_billable_clicks', T.LongType()],
        '3rd Party Billable Server': ['third_party_billable_server', T.StringType()],
        '3rd Party Campaign Id': ['third_party_campaign_id', T.StringType()],
        '3rd Party Campaign Name': ['third_party_campaign_name', T.StringType()],
        '3rd Party Cost': ['third_party_cost', T.DoubleType()],
        '3rd Party Impressions Analyzed': ['third_party_impressions_analyzed', T.LongType()],
        '3rd Party Placement ID': ['third_party_placement_id', T.StringType()],
        '3rd Party Placement Name': ['third_party_placement_name', T.StringType()],
        '3rd Party Revenue': ['third_party_revenue', T.DoubleType()],
        '3rd Party Requests': ['third_party_requests', T.LongType()],
        '3rd Party Server': ['third_party_server', T.StringType()],
        '3rd Party Targeting Description': ['third_party_targeting_description', T.StringType()],
        '3rd Party Timezone': ['third_party_timezone', T.StringType()],
        '3rd Party Total Demo Impressions': ['third_party_total_demo_impressions', T.LongType()],
        '3rd Party Views': ['third_party_views', T.LongType()],
        'Views': ['views', T.LongType()],
        'Total Video Plays': ['total_video_plays', T.LongType()],
        'Video 75': ['video_75_percent_complete', T.LongType()],
        'Video 50': ['video_50_percent_complete', T.LongType()],
        'Video 25': ['video_25_percent_complete', T.LongType()],
        'Video 100': ['video_100_percent_complete', T.LongType()],
        'Video 0': ['video_0_percent_complete', T.LongType()],
        'Video 25 Rate': ['video_25_rate', T.DoubleType()],
        'Video Completion Rate': ['video_completion_rate', T.DoubleType()],
        'Video Views': ['video_views', T.LongType()],
        'Viewable Impressions': ['viewable_impressions', T.LongType()],
        'Net Cost': ['net_cost', T.DoubleType()],
        'Agency Id': ['agency_id', T.StringType()],
        'Agency Name': ['agency_name', T.StringType()],
        'Advertiser': ['advertiser_name', T.StringType()],
        'Advertiser ID': ['advertiser_id', T.LongType()],
        'Campaign Identifier': ['campaign_id', T.StringType()],
        'Campaign Name': ['campaign_name', T.StringType()],
        'Contracted Impressions': ['contracted_impressions', T.LongType()],
        'Contracted Revenue': ['contracted_revenue', T.DoubleType()],
        'Demographic Target': ['demographic_target', T.StringType()],
        'Impressions Analyzed': ['impressions_analyzed', T.LongType()],
        'In Target Impressions': ['in_target_impressions', T.LongType()],
        'Local Server': ['local_server_type', T.StringType()],
        'Local Server Name': ['local_server_name', T.StringType()],
        'On Target Impressions': ['on_target_impressions', T.LongType()],
        'Placement ID': ['placement_id', T.StringType()],
        'Placement Name': ['placement_name', T.StringType()],
        'Total Revenue': ['total_revenue', T.DoubleType()],
        'Total Spend': ['total_spend', T.DoubleType()],
        'Report Data Date': ['report_data_date', T.DateType()],
        'event_date': ['event_date', T.DateType()],
        'created_timestamp': ['created_timestamp', T.TimestampType()],
        'Primary Trafficker': ['primary_trafficker', T.StringType()],
        'Ad Priority': ['ad_priority', T.StringType()],
        'Ad Slot Size': ['ad_slot_size', T.StringType()],
        'Megaphone Pacing Type': ['megaphone_pacing_type', T.StringType()],
        'Megaphone Priority': ['megaphone_priority', T.StringType()],
        'Audible Impressions': ['audible_impressions', T.StringType()],
        'Uniques': ['uniques', T.LongType()],
        'Campaign Billing Impressions': ['campaign_billing_impressions', T.LongType()],
        'Creative Type': ['creative_type', T.StringType()],

    }

    cols_to_be_formated_to_int = [
        'Impressions',
        'Impressions (3rd Party)',
        'Clicks',
        'Clicks (3rd Party)',
        '3rd Party Video 0',
        '3rd Party Video 100',
        '3rd Party Video 25',
        '3rd Party Video 50',
        '3rd Party Video 75',
        '3rd Party Video Views',
        '3rd Party Total Video Plays',
        '3rd Party Advertiser Id',
        'Unsplit 3rd Party Clicks',
        'Unsplit 3rd Party Impressions',
        '3rd Party In Target Impressions',
        '3rd Party On Target Imps',
        '3rd Party Billable Impressions',
        '3rd Party Non-Billable Impressions',
        '3rd Party Non-Billable Clicks',
        '3rd Party Billable Clicks',
        '3rd Party Impressions Analyzed',
        '3rd Party Requests',
        '3rd Party Total Demo Impressions',
        '3rd Party Views',
        'Views',
        'Total Video Plays',
        'Video 75',
        'Video 50',
        'Video 25',
        'Video 100',
        'Video 0',
        'Video Views',
        'Viewable Impressions',
        'Advertiser ID',
        'Contracted Impressions',
        'Impressions Analyzed',
        'In Target Impressions',
        'On Target Impressions',
        'Ad Priority',
        'Megaphone Priority',
        'Audible Impressions',
        'Uniques',
        'Campaign Billing Impressions',

    ]

    cols_to_be_formated_to_float = [
        '3rd Party Cost',
        '3rd Party Revenue',
        'Video 25 Rate',
        'Video Completion Rate',
        'Net Cost',
        'Contracted Revenue',
        'Total Revenue',
        'Total Spend',
    ]

    select_cols = []
    for col in third_party_table.columns:
        # if col != 'created_at' and col != 'updated_at':
        if col in column_format_info:
            select_cols.append(column_format_info[col][0])
            if col in cols_to_be_formated_to_int and '_id' not in column_format_info[col][0]:
                third_party_table = third_party_table.withColumn(col,
                    F.when(third_party_table[col] == 'N/A', F.lit(None).cast(T.LongType()))\
                    .when(third_party_table[col].isNull(), F.lit(None).cast(T.LongType()))\
                    .when(third_party_table[col].contains('.'), F.to_number(F.split(F.col(col), '[.]', 2)[0], F.lit('999,999,999,999,999')))\
                    .when(third_party_table[col].contains(','), F.to_number(F.col(col), F.lit('999,999,999,999,999')))\
                    .otherwise(F.to_number(F.col(col), F.lit('999999999999999')))
                )
            elif col in cols_to_be_formated_to_int and '_id' in column_format_info[col][0]:
                third_party_table = third_party_table.withColumn(col,
                    F.when(third_party_table[col] == 'N/A', F.lit(-1).cast(T.LongType()))\
                    .when(third_party_table[col].isNull(), F.lit(-1).cast(T.LongType()))\
                    .when(third_party_table[col].rlike("[a-zA-Z]"), F.lit(-2).cast(T.LongType()))\
                    .otherwise(F.to_number(F.col(col), F.lit('999999999999999')))
                )
            elif col in cols_to_be_formated_to_float:
                third_party_table = third_party_table.withColumn(col,
                    F.when(third_party_table[col] == 'N/A', F.lit(None).cast(T.DoubleType()))\
                    .when(third_party_table[col].isNull(), F.lit(None).cast(T.DoubleType()))\
                    .when(third_party_table[col].contains('$'), F.to_number(F.trim(F.regexp_replace(col, '\$', '')), F.lit('S999,999,999,999,999.99999')))\
                    .when(third_party_table[col].contains('%'), F.to_number(F.trim(F.regexp_replace(col, '\%', '')), F.lit('S999,999,999,999,999.99999')))\
                    .otherwise(F.to_number(F.trim(F.col(col)), F.lit('S999,999,999,999,999.99999')))
                )
            elif '_date' in column_format_info[col][0]:
                third_party_table = third_party_table.withColumn(col, F.to_date(F.col(col), 'MM/dd/yyyy'))
            else:
                if '_id' in column_format_info[col][0]:
                    third_party_table = third_party_table.withColumn(col,
                        F.when(third_party_table[col] == 'N/A', F.lit(-1).cast(T.StringType()))\
                        .when(third_party_table[col].isNull(), F.lit(-1).cast(T.StringType()))\
                        .otherwise(F.col(col).cast(column_format_info[col][1])))
                else:
                    third_party_table = third_party_table.withColumn(col,
                        F.when(third_party_table[col].isNull(), F.lit('N/A').cast(T.StringType()))\
                        .otherwise(F.col(col).cast(column_format_info[col][1])))

            third_party_table = third_party_table.withColumnRenamed(col, column_format_info[col][0])
            if '_date' not in column_format_info[col][0]:
                third_party_table = third_party_table.withColumn(column_format_info[col][0], F.col(column_format_info[col][0]).cast(column_format_info[col][1]))
        else:
            print('Column not selected : ', col)

    return third_party_table.select(select_cols)


# COMMAND ----------

if __name__ == '__main__':
    tables = [
        'third_party_campaign_reporting_megaphone',
        'megaphone_amperwave_campaign_reporting_delivery',
        'third_party_campaign_reporting_aggregate',
        'third_party_campaign_reporting_delivery',
    ]

    for table_name in tables:
        print(f'Processing table: {table_name}')
        formated_table = load_format_table(table_name)
        if not spark.catalog.tableExists(f'{catalog_name}.{bronze_schema_name}.{table_name}'): #Add the table name for First time load 
            formated_table.write.format('delta')\
                .mode('overwrite')\
                .partitionBy('event_date')\
                .option('mergeSchema', 'true')\
                .option('overwriteDynamicPartitions', 'true')\
                .option('delta.enableDeletionVectors', 'false')\
                .option('delta.enableIcebergCompatV2', 'true')\
                .option('delta.universalFormat.enabledFormats', 'iceberg')\
                .option('delta.columnMapping.mode', 'name')\
                .saveAsTable(f"{catalog_name}.{bronze_schema_name}.{table_name}")
        else:
            formated_table.write.format('delta')\
                .mode('overwrite')\
                .option('partitionOverwriteMode', 'dynamic')\
                .saveAsTable(f"{catalog_name}.{bronze_schema_name}.{table_name}")
