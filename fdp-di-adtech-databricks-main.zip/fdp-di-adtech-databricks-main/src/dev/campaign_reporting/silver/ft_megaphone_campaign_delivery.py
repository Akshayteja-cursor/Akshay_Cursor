# Databricks notebook source
catalog_name = dbutils.widgets.get('catalog_name')
bronze_schema_name = dbutils.widgets.get('bronze_schema_name')
silver_schema_name = dbutils.widgets.get('silver_schema_name')

# COMMAND ----------

query = f"""
    select event_date
       ,order_id
       ,campaign_id
       ,creative_id
        --,advertiser_id --?

       ,order_name
       ,campaign_name
       ,creative_name
       ,advertiser_name
       ,agency_name
       
       ,campaign_start_date
       ,campaign_end_date
      
       ,megaphone_pacing_type   as pacing_type
       ,ad_slot_size            as ad_unit_position
       ,megaphone_priority      as ad_unit_priority
       ,creative_type           as promo_code
       --,status --?
       --,video_completes --?
        --,video_starts --?

       , case when upper(campaign_name) ilike '%FNC%' then 'FOX News Channel'
              when upper(campaign_name) ilike '%FNC%' then 'FOX Business Network'
              when upper(campaign_name) ilike '%FXW%' then 'FOX Weather'
              when upper(campaign_name) ilike '%TMZ%' then 'TMZ'
              when upper(campaign_name) ilike '%OKI%' then 'Outkick'
              when upper(campaign_name) ilike '%TOF%' then 'TooFab'
              when upper(campaign_name) ilike '%TBI%' then 'Tubi'
              when upper(campaign_name) ilike '%FNM%' then 'FOX News Media'
        end as business_unit 
        
        ,sum(impressions)         as delivered_impressions
        ,sum(clicks)              as delivered_clicks
        --,delivered_revenue --?
        ,sum(campaign_billing_impressions) as impression_goal

        ,TO_DATE(DATE_FORMAT(CURRENT_TIMESTAMP(), 'yyyy-MM-dd'), 'yyyy-MM-dd') AS etl_load_date
        ,CURRENT_TIMESTAMP() AS etl_load_timestamp
    from {catalog_name}.{bronze_schema_name}.megaphone_amperwave_campaign_reporting_delivery
    where lower(local_server_name) = 'megaphone'
    group by all
"""

megaphone_campaign_delivery = spark.sql(query)

# COMMAND ----------

if not spark.catalog.tableExists(f'{catalog_name}.{silver_schema_name}.ft_megaphone_campaign_delivery'): #Add the table name for First time load 
    megaphone_campaign_delivery.write.format('delta')\
        .mode('overwrite')\
        .partitionBy('event_date')\
        .option('mergeSchema', 'true')\
        .option('overwriteDynamicPartitions', 'true')\
        .option('delta.enableDeletionVectors', 'false')\
        .option('delta.enableIcebergCompatV2', 'true')\
        .option('delta.universalFormat.enabledFormats', 'iceberg')\
        .option('delta.columnMapping.mode', 'name')\
        .saveAsTable(f"{catalog_name}.{silver_schema_name}.ft_megaphone_campaign_delivery")
else:
    megaphone_campaign_delivery.write.format('delta')\
        .mode('overwrite')\
        .option('partitionOverwriteMode', 'dynamic')\
        .saveAsTable(f"{catalog_name}.{silver_schema_name}.ft_megaphone_campaign_delivery")
