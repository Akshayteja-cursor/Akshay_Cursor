# Databricks notebook source
from datetime import datetime, timedelta

# COMMAND ----------

date = dbutils.widgets.get('date')

# COMMAND ----------

query = """
    select 
        camp.event_date 
        ,camp.campaign_id 
        ,camp.campaign_name 
        ,campaign_start_timestamp_est 
        ,campaign_end_timestamp_est 
        ,camp.advertiser_name 
        ,camp.agency_name 
        ,camp.placement_id 
        ,placement_name 
        ,placement_start_timestamp_est::date placement_start_date
        ,placement_end_timestamp_est::Date placement_end_date
        ,global_ad_unit_position 
        ,series_name 
        ,show_name 
        ,video_vertical
        ,video_vertical business_unit
        ,CASE
            WHEN device_name LIKE 'CTV' THEN 'CTV'
            WHEN device_name LIKE 'STB' THEN 'STB'
            WHEN device_name LIKE 'MB/TB' THEN 'Mobile/Tablet Web'
            WHEN device_name LIKE 'DT' THEN 'Desktop Web'
            ELSE 'N/A'
         END AS device_name 
        ,placement_avg_user_frequency 
        ,campaign_avg_user_frequency
        ,video_name 
        ,camp.insertion_order_id
        ,camp.insertion_order_name
        ,camp.insertion_order_start_timestamp_est::DATE as insertion_order_start_date
        ,camp.insertion_order_end_timestamp_est::DATE as insertion_order_end_date
        ,deal_id
        ,deal_name
        ,deal_start_timestamp_est::date as deal_start_date
        ,deal_end_timestamp_est::date as deal_end_date
        ,deal_type
        ,external_deal_id 
        ,programmatic_ad_id 
        ,programmatic_creative_duration 
        ,deal_ad_units 
        ,dsp_name 
        ,CASE
            WHEN platform_group = 'Tubi' THEN 'FOX on Tubi'
            WHEN video_vertical = 'Entertainment' THEN 
                CASE 
                    WHEN platform_group = 'Hulu' THEN 'FOX on Hulu'
                    WHEN platform_group = 'STB VOD' THEN 'STB VOD'
                    ELSE 'FOX'
                END
            ELSE video_vertical
        END Property
        ,camp.creative_id 
        ,camp.creative_name
        ,creative_duration_secs 
        ,video_duration 
        ,stream_type
        ,sales_channel_type
        ,camp.demo_band 
        ,camp.event_date not between nvl(campaign_start_timestamp_est::date, deal_start_timestamp_est::date) and nvl(campaign_end_timestamp_est::date, deal_end_timestamp_est::date) as out_of_flight_flag
        ,on_target_net_delivered_impressions_quantity
        ,sum(gross_counted_ads) gross_counted_ads
        ,sum(net_counted_ads) delivered_impressions
        ,sum(run_revenue_amount) Delivered_Revenue
        ,sum(delivered_clicks) delivered_clicks
        ,camp.AOS_deal_id 
        ,camp.AOS_deal_name
        ,camp.AOS_Deal_start_date
        ,camp.AOS_Deal_end_date
        ,sales_order_line_item_id
        ,camp.sales_order_line_item_name
        ,camp.AOS_advertiser_name
        ,Campaign_Name_Derived
        ,camp.package_name
        ,owner_name
        ,camp.net_unit_cost
        ,guaranteed_qty Guaranteed_Impressions
        ,camp.guaranteed_revenue Guaranteed_Revenue
        ,ps_line_item_id External_AD_ID
        ,primary_salesperson_name
        ,account_coordinator
        ,nvl(CASE
                WHEN billable_third_party_description = 'DCM' THEN 'FOX DCM'
                WHEN billable_third_party_description = 'Doubleverify' THEN 'FOX Doubleverify'
                WHEN billable_third_party_description = 'Innovid' THEN 'FOX Innovid'
                WHEN billable_third_party_description = 'Flashtalking' THEN 'FOX Flashtalking'
                WHEN billable_third_party_description = 'Extreme Reach' THEN 'FOX Extreme Reach'
                WHEN billable_third_party_description = 'Sizmek' THEN 'FOX Sizmek'
                WHEN billable_third_party_description = '1st Party' THEN 'FOX 1st Party'
                ELSE billable_third_party_description
            END,'N/A') as billable_third_part_server
        ,tpcd.third_party_video_completes
        ,tpcd.third_party_video_views
        ,tpcd.third_party_billable_impressions
        ,tpcd.third_party_clicks
        ,tpcd.third_party_revenue
        ,camp.etl_load_timestamp Create_Timestamp
        ,camp.etl_load_timestamp  Modified_Timestamp
    from fox_bi_qa.gold_ad_sales.ft_freewheel_delivery_daily camp
    left join (select event_date,placement_id,campaign_id, advertiser_name,agency_name,insertion_order_id, sum(on_target_net_delivered_impressions_quantity) on_target_net_delivered_impressions_quantity
    from fox_bi_qa.gold_ad_sales.ft_freewheel_demo_comp_daily where event_date::date >= '{}' group by all) dc
    on dc.placement_id = camp.placement_id 
    and dc.campaign_id = camp.campaign_id
    and dc.advertiser_name = camp.advertiser_name
    and dc.agency_name = camp.agency_name
    and dc.insertion_order_id = camp.insertion_order_id
    and dc.event_date = camp.event_date
    left join 
    ( select event_date,ad_unit_id,split_part(creative_id,'-', 1) creative_id
                ,sum(third_party_video_completes) third_party_video_completes
                ,sum(third_party_video_views) third_party_video_views
                ,sum(third_party_billable_impressions) third_party_billable_impressions
                ,sum(third_party_clicks) third_party_clicks
                ,sum(third_party_revenue) third_party_revenue
                ,CASE
                    WHEN third_party_billable_server = 'Moat' THEN 'Moat'
                    WHEN third_party_billable_server in ('DFA by Google', 'Dart Report Reader', 'Dart Report Reader, DFA by Google', 'DFP by Google') THEN 'FOX DCM'
                    WHEN third_party_billable_server = 'DoubleVerify' THEN 'FOX Doubleverify'
                    WHEN third_party_billable_server = 'Innovid 3rd Party' THEN 'FOX Innovid'
                    WHEN third_party_billable_server in ('FlashTalking', 'FlashTalking Email Reader') THEN 'FOX Flashtalking'
                    WHEN third_party_billable_server in ('Extreme Reach Email', 'ExtremeReachAPI') THEN 'FOX Extreme Reach'
                    WHEN third_party_billable_server in ('MediaMind', 'MediaMind Report Reader', 'Sizmek SAS Report Reader', 'MediaMind Report Reader, Sizmek SAS Report Reader', 'Sizmek SAS Report Reader, MediaMind Report Reader') THEN 'FOX Sizmek'
                    WHEN third_party_billable_server = 'TubeMogul' THEN 'TubeMogul'
                    ELSE 'FOX 1st Party'
                END billable_third_party_server from fox_bi_dev.silver_ads.ft_third_party_campaign_delivery_daily_data
        where ad_unit_id <> '-1'
        and event_date::date >= '{}'
        group by all) tpcd
    on split_part(tpcd.creative_id,'-', 1)  = camp.creative_id
    and tpcd.ad_unit_id = camp.ad_unit_id
    and tpcd.event_date = camp.event_date
    and CASE
            WHEN billable_third_party_description = 'DCM' THEN 'FOX DCM'
            WHEN billable_third_party_description = 'Doubleverify' THEN 'FOX Doubleverify'
            WHEN billable_third_party_description = 'Innovid' THEN 'FOX Innovid'
            WHEN billable_third_party_description = 'Flashtalking' THEN 'FOX Flashtalking'
            WHEN billable_third_party_description = 'Extreme Reach' THEN 'FOX Extreme Reach'
            WHEN billable_third_party_description = 'Sizmek' THEN 'FOX Sizmek'
            WHEN billable_third_party_description = '1st Party' THEN 'FOX 1st Party'
            ELSE billable_third_party_description
        END  = tpcd.billable_third_party_server
    where 1 = 1 
    and camp.event_date::date >= '{}'
    group by all
"""

if datetime.strptime(date, '%Y-%m-%d').day < 5:
    date = (datetime.strptime(date, '%Y-%m-%d') - timedelta(days=5)).replace(day=1).strftime('%Y-%m-%d')
else:
    date = datetime.strptime(date, '%Y-%m-%d').replace(day=1).strftime('%Y-%m-%d')

fw_campaign_pacing = spark.sql(query.format(date, date, date))

# COMMAND ----------

if not spark.catalog.tableExists(f'fox_bi_qa.gold_ad_sales.ft_freewheel_campaign_pacing'): #Add the table name for First time load 
    fw_campaign_pacing.write.format('delta')\
        .mode('overwrite')\
        .partitionBy('Event_Date')\
        .option('mergeSchema', 'true')\
        .option('overwriteDynamicPartitions', 'true')\
        .option('delta.enableDeletionVectors', 'false')\
        .option('delta.enableIcebergCompatV2', 'true')\
        .option('delta.universalFormat.enabledFormats', 'iceberg')\
        .option('delta.columnMapping.mode', 'name')\
        .saveAsTable('fox_bi_qa.gold_ad_sales.ft_freewheel_campaign_pacing')
else:
    fw_campaign_pacing.write.format('delta')\
        .mode('overwrite')\
        .option('partitionOverwriteMode', 'dynamic')\
        .saveAsTable('fox_bi_qa.gold_ad_sales.ft_freewheel_campaign_pacing')
    

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO fox_bi_qa.gold_ad_sales.ft_freewheel_campaign_pacing AS tgt
# MAGIC     USING (
# MAGIC     select
# MAGIC         distinct 
# MAGIC         ps_line_item_id External_AD_ID,
# MAGIC         sales_order_line_item_id,
# MAGIC         sales_order_line_item_name,
# MAGIC         demo_band,
# MAGIC 		nvl(CASE
# MAGIC                 WHEN billable_third_party_descr = 'DCM' THEN 'FOX DCM'
# MAGIC                 WHEN billable_third_party_descr = 'Doubleverify' THEN 'FOX Doubleverify'
# MAGIC                 WHEN billable_third_party_descr = 'Innovid' THEN 'FOX Innovid'
# MAGIC                 WHEN billable_third_party_descr = 'Flashtalking' THEN 'FOX Flashtalking'
# MAGIC                 WHEN billable_third_party_descr = 'Extreme Reach' THEN 'FOX Extreme Reach'
# MAGIC                 WHEN billable_third_party_descr = 'Sizmek' THEN 'FOX Sizmek'
# MAGIC                 WHEN billable_third_party_descr = '1st Party' THEN 'FOX 1st Party'
# MAGIC                 ELSE billable_third_party_descr 
# MAGIC             END,'N/A') as billable_third_part_server,
# MAGIC         package_name,
# MAGIC         owner_name,
# MAGIC         sales_order_id as AOS_deal_id,
# MAGIC         sales_order_name as AOS_deal_name,
# MAGIC         date(order_start_dt) as AOS_Deal_start_date,
# MAGIC         date(order_end_dt) as AOS_Deal_end_date,
# MAGIC         advertiser_name as AOS_advertiser_name,
# MAGIC         advertiser_name ||' - '|| order_start_dt || ' - '|| order_end_dt as Campaign_Name_Derived ,
# MAGIC         net_unit_cost_amt as net_unit_cost,
# MAGIC         sales_order_line_items_qty as Guaranteed_Impressions,
# MAGIC         contracted_amount_net_lifetime as Guaranteed_Revenue,
# MAGIC         primary_salesperson_name,
# MAGIC         account_coordinator    
# MAGIC     from
# MAGIC         fox_bi_prod.gold_ad_sales.ft_digital_operative_line_date_allocation
# MAGIC         where ps_line_item_id is not null
# MAGIC         and sales_order_line_item_name not ilike '%cancelled%'
# MAGIC         and date between sales_order_line_item_start_dt and sales_order_line_item_end_dt
# MAGIC         ) as src
# MAGIC         on nvl(src.External_AD_ID,'N/A') = coalesce(deal_id,placement_id,'N/A') 
# MAGIC         and nvl(src.sales_order_line_item_id,'N/A') = nvl(tgt.sales_order_line_item_id,'N/A')
# MAGIC     WHEN MATCHED AND (    
# MAGIC         nvl(src.demo_band,'N/A') <> nvl(tgt.demo_band,'N/A')
# MAGIC 		OR nvl(src.AOS_deal_id,'N/A') <> nvl(tgt.AOS_deal_id,'N/A')
# MAGIC 		OR nvl(src.AOS_deal_name,'N/A') <> nvl(tgt.AOS_deal_name,'N/A')
# MAGIC 		OR nvl(src.AOS_Deal_start_date,'N/A') <> nvl(tgt.AOS_Deal_start_date,'N/A')
# MAGIC 		OR nvl(src.AOS_Deal_end_date,'N/A') <> nvl(tgt.AOS_Deal_end_date,'N/A')
# MAGIC 		OR nvl(src.sales_order_line_item_id,'N/A') <> nvl(tgt.sales_order_line_item_id,'N/A')
# MAGIC 		OR nvl(src.sales_order_line_item_name,'N/A') <> nvl(tgt.sales_order_line_item_name,'N/A')
# MAGIC 		OR nvl(src.AOS_advertiser_name,'N/A') <> nvl(tgt.AOS_advertiser_name,'N/A')
# MAGIC 		OR nvl(src.Campaign_Name_Derived,'N/A') <> nvl(tgt.Campaign_Name_Derived,'N/A')
# MAGIC 		OR nvl(src.package_name,'N/A') <> nvl(tgt.package_name,'N/A')
# MAGIC 		OR nvl(src.owner_name,'N/A') <> nvl(tgt.owner_name,'N/A')
# MAGIC 		OR nvl(src.net_unit_cost,'N/A') <> nvl(tgt.net_unit_cost,'N/A')
# MAGIC 		OR nvl(src.Guaranteed_Impressions,'N/A') <> nvl(tgt.Guaranteed_Impressions,'N/A')
# MAGIC 		OR nvl(src.Guaranteed_Revenue,'N/A') <> nvl(tgt.Guaranteed_Revenue,'N/A')
# MAGIC 		OR nvl(src.External_AD_ID,'N/A') <> nvl(tgt.External_AD_ID,'N/A')
# MAGIC 		OR nvl(src.primary_salesperson_name,'N/A') <> nvl(tgt.primary_salesperson_name,'N/A')
# MAGIC 		OR nvl(src.account_coordinator,'N/A') <> nvl(tgt.account_coordinator,'N/A')
# MAGIC 		OR nvl(src.billable_third_part_server,'N/A') <> nvl(tgt.billable_third_part_server,'N/A')
# MAGIC         )
# MAGIC 
# MAGIC         THEN UPDATE SET 
# MAGIC          tgt.demo_band = src.demo_band
# MAGIC 		,tgt.AOS_deal_id = src.AOS_deal_id
# MAGIC 		,tgt.AOS_deal_name = src.AOS_deal_name
# MAGIC 		,tgt.AOS_Deal_start_date = src.AOS_Deal_start_date
# MAGIC 		,tgt.AOS_Deal_end_date = src.AOS_Deal_end_date
# MAGIC 		,tgt.sales_order_line_item_id = src.sales_order_line_item_id
# MAGIC 		,tgt.sales_order_line_item_name = src.sales_order_line_item_name
# MAGIC 		,tgt.AOS_advertiser_name = src.AOS_advertiser_name
# MAGIC 		,tgt.Campaign_Name_Derived = src.Campaign_Name_Derived
# MAGIC 		,tgt.package_name = src.package_name
# MAGIC 		,tgt.owner_name = src.owner_name
# MAGIC 		,tgt.net_unit_cost = src.net_unit_cost
# MAGIC 		,tgt.Guaranteed_Impressions = src.Guaranteed_Impressions
# MAGIC 		,tgt.Guaranteed_Revenue = src.Guaranteed_Revenue
# MAGIC 		,tgt.External_AD_ID = src.External_AD_ID
# MAGIC 		,tgt.primary_salesperson_name = src.primary_salesperson_name
# MAGIC 		,tgt.account_coordinator = src.account_coordinator
# MAGIC 		,tgt.billable_third_part_server = nvl(src.billable_third_part_server,'N/A')