# Databricks notebook source
from datetime import datetime, timedelta

# COMMAND ----------

date = dbutils.widgets.get('date')

# COMMAND ----------

query = """
    WITH gam_daily AS (
        SELECT
            ad_date,
            order_id,
            order_name,
            CASE 
                WHEN platform_group ILIKE '%other%' THEN 'N/A'
                ELSE platform_group
            END AS platform_group,
            advertiser_name,
            advertiser_id,
            business_unit,
            ad_format_name,
            requested_ad_sizes,
            line_item_id,
            line_item_name,
            line_item_type,
            line_item_start_timestamp,
            line_item_end_timestamp,
            SUM(total_cpm_and_cpc_revenue) AS total_cpm_and_cpc_revenue,
            SUM(total_impressions) AS total_impressions,
            SUM(video_viewership_complete) AS video_viewership_complete,
            SUM(video_viewership_start) AS video_viewership_start,
            SUM(total_clicks) AS total_clicks,
            etl_load_timestamp_utc
        FROM fox_bi_dev.silver_ads.ft_gam_summary_daily_data
        WHERE line_item_type IN ('SPONSORSHIP', 'STANDARD', 'BULK')
        AND ad_date >= '2024-01-01'
        AND line_item_id <> -1
        GROUP BY ALL
    ),
    third_party_delivery AS (
        SELECT
            event_date,
            campaign_id,
            campaign_name,
            third_party_billable_server,
            CASE
                WHEN third_party_billable_server = 'Moat' THEN 'Moat'
                WHEN third_party_billable_server in ('DFA by Google', 'Dart Report Reader', 'Dart Report Reader, DFA by Google', 'DFP by Google') THEN 'FOX DCM'
                WHEN third_party_billable_server = 'DoubleVerify' THEN 'FOX Doubleverify'
                WHEN third_party_billable_server = 'Innovid 3rd Party' THEN 'FOX Innovid'
                WHEN third_party_billable_server in ('FlashTalking', 'FlashTalking Email Reader') THEN 'FOX Flashtalking'
                WHEN third_party_billable_server in ('Extreme Reach Email', 'ExtremeReachAPI') THEN 'FOX Extreme Reach'
                WHEN third_party_billable_server in ('MediaMind', 'MediaMind Report Reader', 'Sizmek SAS Report Reader', 'MediaMind Report Reader, Sizmek SAS Report Reader', 'Sizmek SAS Report Reader, MediaMind Report Reader') THEN 'FOX Sizmek'
                WHEN third_party_billable_server = 'TubeMogul' THEN 'TubeMogul'
                ELSE 'FOX 1st Party'
            END AS billable_third_party_server,
            SUM(third_party_video_completes) AS third_party_video_completes,
            SUM(third_party_video_views) AS third_party_video_views,
            SUM(third_party_billable_impressions) AS third_party_billable_impressions,
            SUM(third_party_clicks) AS third_party_clicks,
            SUM(third_party_revenue) AS third_party_revenue
        FROM fox_bi_dev.silver_ads.ft_third_party_campaign_delivery_daily_data
        WHERE event_date >= '2024-01-01'
        GROUP BY ALL
    ),
    op_line_detail AS (
        SELECT
            source,
            sales_order_line_item_id AS sales_line_item_id,
            sales_order_line_item_name AS sales_line_item_name,
            sales_order_id,
            sales_order_name,
            order_start_dt AS sales_order_start_date,
            order_end_dt AS sales_order_end_date,
            agency_name,
            advertiser_name,
            owner_name,
            primary_salesperson_name,
            account_coordinator,
            package_name,
            ps_line_item_id,
            demo_band,
            CASE
                WHEN billable_third_party_descr = 'DCM' THEN 'FOX DCM'
                WHEN billable_third_party_descr = 'Doubleverify' THEN 'FOX Doubleverify'
                WHEN billable_third_party_descr = 'Innovid' THEN 'FOX Innovid'
                WHEN billable_third_party_descr = 'Flashtalking' THEN 'FOX Flashtalking'
                WHEN billable_third_party_descr = 'Extreme Reach' THEN 'FOX Extreme Reach'
                WHEN billable_third_party_descr = 'Sizmek' THEN 'FOX Sizmek'
                WHEN billable_third_party_descr = '1st Party' THEN 'FOX 1st Party'
                ELSE billable_third_party_descr
            END AS billable_third_party_server,
            net_unit_cost_amt AS net_unit_cost,
            net_cost_amt,
            sales_order_line_items_qty AS quantity
        FROM fox_bi_prod.gold_ad_sales.ft_digital_operative_line_date_allocation
        GROUP BY ALL
    ),
    campaign_delivery AS (
        SELECT
            /*+ BROADCAST(li) */
            gam_daily.ad_date AS Event_Date,
            CAST(op_line_detail.sales_line_item_id AS BIGINT) AS AOS_Deal_Line_Item_ID,
            op_line_detail.sales_line_item_name AS AOS_Deal_Line_Item_Name,
            COALESCE(op_line_detail.sales_order_id, -1) AS Campaign_ID,
            COALESCE(op_line_detail.sales_order_name, 'N/A') AS Campaign_Name,
            COALESCE(op_line_detail.sales_order_start_date, or.order_start_timestamp) AS Campaign_Start_Date,
            COALESCE(op_line_detail.sales_order_end_date, or.order_end_timestamp) AS Campaign_End_Date,
            CASE
                WHEN op_line_detail.sales_order_end_date < CURRENT_TIMESTAMP() THEN 'Closed'
                ELSE 'Active'
            END AS Campaign_Status,
            gam_daily.order_id AS Order_ID,
            gam_daily.order_name AS Order_Name,
            gam_daily.platform_group AS Device,
            gam_daily.advertiser_name AS Advertiser_Name,
            gam_daily.advertiser_id AS Advertiser_ID,
            gam_daily.business_unit AS Business_Unit,
            gam_daily.ad_format_name AS Ad_Unit_Format,
            gam_daily.requested_ad_sizes AS Ad_Unit_Size,
            gam_daily.line_item_id AS Line_Item_ID,
            gam_daily.line_item_name AS Line_Item_Name,
            gam_daily.line_item_type AS Line_Item_Type,
            TO_DATE(gam_daily.line_item_start_timestamp) AS Line_Item_Start_Date,
            TO_DATE(gam_daily.line_item_end_timestamp) AS Line_Item_End_Date,
            li.delivery_indicator_actual_delivery_percentage AS Actual_Delivery_Indicator,
            SUM(gam_daily.total_cpm_and_cpc_revenue) AS Delivered_Revenue,
            SUM(gam_daily.total_impressions) AS Delivered_Impressions,
            SUM(gam_daily.video_viewership_complete) AS Video_Completes,
            SUM(gam_daily.video_viewership_start) AS Video_Starts,
            SUM(gam_daily.total_clicks) AS Delivered_Clicks,
            COALESCE(op_line_detail.agency_name, 'N/A') AS Agency_Name,
            COALESCE(op_line_detail.advertiser_name, 'N/A') AS Advertiser_OMS,
            COALESCE(op_line_detail.owner_name, 'N/A') AS Account_Manager,
            COALESCE(op_line_detail.primary_salesperson_name, 'N/A') AS Primary_Salesperson_Name,
            COALESCE(op_line_detail.account_coordinator, 'N/A') AS Account_Coordinator,
            ROUND(COALESCE(op_line_detail.net_unit_cost, 0), 2) AS Net_Unit_Cost,
            ROUND(COALESCE(op_line_detail.net_cost_amt, 0), 2) AS Guaranteed_Revenue,
            COALESCE(op_line_detail.quantity, 0) AS Guaranteed_Impressions,
            COALESCE(op_line_detail.ps_line_item_id, '-1') AS External_AD_ID,
            COALESCE(op_line_detail.sales_order_id, -1) AS AOS_Deal_ID,
            COALESCE(op_line_detail.sales_order_name, 'N/A') as AOS_Deal_Name,
            DATE(op_line_detail.sales_order_start_date) AS AOS_Deal_Start_Date,
            DATE(op_line_detail.sales_order_end_date) AS AOS_Deal_End_Date,
            COALESCE(op_line_detail.demo_band, 'N/A') Demo_Band,
            COALESCE(op_line_detail.package_name, 'N/A') Package_Name,
            op_line_detail.billable_third_party_server AS Billable_Third_Party_Server,
            SUM(third_party_delivery.third_party_video_completes) AS Third_Party_Video_Completes,
            SUM(third_party_delivery.third_party_video_views) AS Third_Party_Video_Views,
            SUM(third_party_delivery.third_party_billable_impressions) AS Third_Party_Billable_Impressions,
            SUM(third_party_delivery.third_party_clicks) AS Third_Party_Clicks,
            ROUND(SUM(third_party_delivery.third_party_revenue), 2) AS Third_Party_Revenue,
            gam_daily.etl_load_timestamp_utc AS Create_Timestamp,
            gam_daily.etl_load_timestamp_utc AS Modified_Timestamp
        FROM gam_daily
        LEFT JOIN fox_bi_dev.silver_ads.dim_line_item li
        ON gam_daily.line_item_id = li.line_item_id
        LEFT JOIN fox_bi_dev.silver_ads.dim_orders or
        ON gam_daily.order_id = or.order_id
        LEFT JOIN op_line_detail
        ON gam_daily.line_item_id = op_line_detail.ps_line_item_id
        LEFT JOIN third_party_delivery
        ON gam_daily.ad_date = third_party_delivery.event_date
        AND gam_daily.line_item_id = third_party_delivery.campaign_id
        AND op_line_detail.billable_third_party_server = third_party_delivery.billable_third_party_server
        GROUP BY ALL
    )
    SELECT * FROM campaign_delivery
    WHERE Campaign_End_Date >= '{}'
    AND (
        CASE
            WHEN Line_Item_Type = 'SPONSORSHIP' AND (Advertiser_Name IN (SELECT promo_advertiser_name FROM fox_bi_qa.silver_ad_sales.map_fnb_promo_advertiser) OR External_AD_ID = '-1') 
            THEN FALSE
            ELSE TRUE
        END
    )
    AND (
        CASE
            WHEN ((LOWER(Advertiser_Name) LIKE '%promo%') OR (LOWER(Advertiser_Name) LIKE '% test%')) THEN FALSE
            WHEN ((LOWER(Order_Name) LIKE '%promo%') OR (LOWER(Order_Name) LIKE '% test%')) THEN FALSE
            WHEN ((LOWER(Agency_Name) LIKE '%promo%') OR (LOWER(Agency_Name) LIKE '% test%')) THEN FALSE
            ELSE TRUE
        END
    )
"""

if datetime.strptime(date, '%Y-%m-%d').day < 5:
    date = (datetime.strptime(date, '%Y-%m-%d') - timedelta(days=95)).replace(day=1).strftime('%Y-%m-%d')
else:
    date = (datetime.strptime(date, '%Y-%m-%d') - timedelta(days=90)).replace(day=1).strftime('%Y-%m-%d')

gam_campaign_delivery = spark.sql(query.format(date))

# COMMAND ----------

gam_campaign_delivery.write.format('delta')\
    .mode('overwrite')\
    .partitionBy('Campaign_ID')\
    .option('mergeSchema', 'true')\
    .option('overwriteDynamicPartitions', 'true')\
    .option('delta.enableDeletionVectors', 'false')\
    .option('delta.enableIcebergCompatV2', 'true')\
    .option('delta.universalFormat.enabledFormats', 'iceberg')\
    .option('delta.columnMapping.mode', 'name')\
    .saveAsTable('fox_bi_qa.gold_ad_sales.ft_gam_campaign_delivery')