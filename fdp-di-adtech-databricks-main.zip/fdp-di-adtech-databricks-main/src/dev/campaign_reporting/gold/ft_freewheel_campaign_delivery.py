# Databricks notebook source
from datetime import datetime, timedelta

# COMMAND ----------

date = dbutils.widgets.get('date')

# COMMAND ----------

query = """
    WITH campaign_delivery AS (
        select 
            camp.event_date 
            ,camp.campaign_id 
            ,camp.campaign_name 
            ,campaign_start_timestamp_est 
            ,campaign_end_timestamp_est 
            ,camp.advertiser_id
            ,camp.advertiser_name 
            ,camp.agency_name 
            ,camp.placement_id 
            ,placement_name 
            ,placement_start_timestamp_est::date placement_start_date
            ,placement_end_timestamp_est::Date placement_end_date
            ,global_ad_unit_position 
            ,series_name 
            ,show_name 
            ,video_vertical
            ,video_vertical business_unit
            ,CASE
                WHEN device_name LIKE 'CTV' THEN 'CTV'
                WHEN device_name LIKE 'STB' THEN 'STB'
                WHEN device_name LIKE 'MB/TB' THEN 'Mobile/Tablet Web'
                WHEN device_name LIKE 'DT' THEN 'Desktop Web'
                ELSE 'N/A'
             END AS device_name 
            ,placement_avg_user_frequency 
            ,campaign_avg_user_frequency
            ,video_name 
            ,camp.insertion_order_id
            ,camp.insertion_order_name
            ,camp.insertion_order_start_timestamp_est::DATE as insertion_order_start_date
            ,camp.insertion_order_end_timestamp_est::DATE as insertion_order_end_date
            ,deal_id
            ,deal_name
            ,deal_start_timestamp_est::date as deal_start_date
            ,deal_end_timestamp_est::date as deal_end_date
            ,deal_type
            ,external_deal_id 
            ,programmatic_ad_id 
            ,programmatic_creative_duration 
            ,deal_ad_units 
            ,dsp_name 
            ,CASE
                WHEN platform_group = 'Tubi' THEN 'FOX on Tubi'
                WHEN video_vertical = 'Entertainment' THEN 
                    CASE 
                        WHEN platform_group = 'Hulu' THEN 'FOX on Hulu'
                        WHEN platform_group = 'STB VOD' THEN 'STB VOD'
                        ELSE 'FOX'
                    END
                ELSE video_vertical
            END Property
            ,camp.creative_id 
            ,camp.creative_name
            ,creative_duration_secs 
            ,video_duration 
            ,stream_type
            ,sales_channel_type
            ,camp.demo_band 
            ,on_target_net_delivered_impressions_quantity
            ,sum(gross_counted_ads) gross_counted_ads
            ,sum(net_counted_ads) delivered_impressions
            ,sum(run_revenue_amount) Delivered_Revenue
            ,sum(delivered_clicks) delivered_clicks
            ,camp.AOS_deal_id 
            ,camp.AOS_deal_name
            ,camp.AOS_Deal_start_date
            ,camp.AOS_Deal_end_date
            ,sales_order_line_item_id
            ,camp.sales_order_line_item_name
            ,camp.AOS_advertiser_name
            ,Campaign_Name_Derived
            ,camp.package_name
            ,owner_name
            ,camp.net_unit_cost
            ,guaranteed_qty Guaranteed_Impressions
            ,camp.guaranteed_revenue Guaranteed_Revenue
            ,ps_line_item_id External_AD_ID
            ,primary_salesperson_name
            ,account_coordinator
            ,nvl(CASE
                    WHEN billable_third_party_description = 'DCM' THEN 'FOX DCM'
                    WHEN billable_third_party_description = 'Doubleverify' THEN 'FOX Doubleverify'
                    WHEN billable_third_party_description = 'Innovid' THEN 'FOX Innovid'
                    WHEN billable_third_party_description = 'Flashtalking' THEN 'FOX Flashtalking'
                    WHEN billable_third_party_description = 'Extreme Reach' THEN 'FOX Extreme Reach'
                    WHEN billable_third_party_description = 'Sizmek' THEN 'FOX Sizmek'
                    WHEN billable_third_party_description = '1st Party' THEN 'FOX 1st Party'
                    ELSE billable_third_party_description
                END,'N/A') as billable_third_part_server
            ,tpcd.third_party_video_completes
            ,tpcd.third_party_video_views
            ,tpcd.third_party_billable_impressions
            ,tpcd.third_party_clicks
            ,tpcd.third_party_revenue
            ,camp.etl_load_timestamp Create_Timestamp
            ,camp.etl_load_timestamp  Modified_Timestamp
        from fox_bi_qa.gold_ad_sales.ft_freewheel_delivery_daily camp
        left join (select event_date,placement_id,campaign_id, advertiser_name,agency_name,insertion_order_id, sum(on_target_net_delivered_impressions_quantity) on_target_net_delivered_impressions_quantity
        from fox_bi_qa.gold_ad_sales.ft_freewheel_demo_comp_daily where event_date::date >= '2024-01-01' group by all) dc
        on dc.placement_id = camp.placement_id 
        and dc.campaign_id = camp.campaign_id
        and dc.advertiser_name = camp.advertiser_name
        and dc.agency_name = camp.agency_name
        and dc.insertion_order_id = camp.insertion_order_id
        and dc.event_date = camp.event_date
        left join 
        ( select event_date,ad_unit_id,split_part(creative_id,'-', 1) creative_id
                ,sum(third_party_video_completes) third_party_video_completes
                ,sum(third_party_video_views) third_party_video_views
                ,sum(third_party_billable_impressions) third_party_billable_impressions
                ,sum(third_party_clicks) third_party_clicks
                ,sum(third_party_revenue) third_party_revenue
                ,CASE
                    WHEN third_party_billable_server = 'Moat' THEN 'Moat'
                    WHEN third_party_billable_server in ('DFA by Google', 'Dart Report Reader', 'Dart Report Reader, DFA by Google', 'DFP by Google') THEN 'FOX DCM'
                    WHEN third_party_billable_server = 'DoubleVerify' THEN 'FOX Doubleverify'
                    WHEN third_party_billable_server = 'Innovid 3rd Party' THEN 'FOX Innovid'
                    WHEN third_party_billable_server in ('FlashTalking', 'FlashTalking Email Reader') THEN 'FOX Flashtalking'
                    WHEN third_party_billable_server in ('Extreme Reach Email', 'ExtremeReachAPI') THEN 'FOX Extreme Reach'
                    WHEN third_party_billable_server in ('MediaMind', 'MediaMind Report Reader', 'Sizmek SAS Report Reader', 'MediaMind Report Reader, Sizmek SAS Report Reader', 'Sizmek SAS Report Reader, MediaMind Report Reader') THEN 'FOX Sizmek'
                    WHEN third_party_billable_server = 'TubeMogul' THEN 'TubeMogul'
                    ELSE 'FOX 1st Party'
                END billable_third_party_server from fox_bi_dev.silver_ads.ft_third_party_campaign_delivery_daily_data
        where ad_unit_id <> '-1'
        and event_date::date >= '2024-01-01'
        group by all) tpcd
        on split_part(tpcd.creative_id,'-', 1)  = camp.creative_id
        and tpcd.ad_unit_id = camp.ad_unit_id
        and tpcd.event_date = camp.event_date
        and CASE
                WHEN billable_third_party_description = 'DCM' THEN 'FOX DCM'
                WHEN billable_third_party_description = 'Doubleverify' THEN 'FOX Doubleverify'
                WHEN billable_third_party_description = 'Innovid' THEN 'FOX Innovid'
                WHEN billable_third_party_description = 'Flashtalking' THEN 'FOX Flashtalking'
                WHEN billable_third_party_description = 'Extreme Reach' THEN 'FOX Extreme Reach'
                WHEN billable_third_party_description = 'Sizmek' THEN 'FOX Sizmek'
                WHEN billable_third_party_description = '1st Party' THEN 'FOX 1st Party'
                ELSE billable_third_party_description
            END  = tpcd.billable_third_party_server
        where 1 = 1 
        and camp.event_date::date >= '2024-01-01'
        and camp.sales_channel_type in ('Direct Sold')
        and nvl(camp.campaign_name,'N/A') not ilike '%promo%'
        and nvl(camp.agency_name,'N/A') not in ('FNG IN-HOUSE MARKETING & PROMOTIONS', 'No Agency')
        and nvl(camp.advertiser_name,'N/A') not ilike '%promo%'
        and nvl(camp.advertiser_name,'N/A') not in ('Placeholder Advertiser')
        and nvl(camp.agency_name,'N/A') not in ('Placeholder Agency')
        and nvl(camp.ps_line_item_id,-1) <> -1
        group by all
    )
    SELECT * FROM campaign_delivery
    WHERE campaign_end_timestamp_est >= '{}' or campaign_id in (86484377)
"""

if datetime.strptime(date, '%Y-%m-%d').day < 5:
    date = (datetime.strptime(date, '%Y-%m-%d') - timedelta(days=95)).replace(day=1).strftime('%Y-%m-%d')
else:
    date = (datetime.strptime(date, '%Y-%m-%d') - timedelta(days=90)).replace(day=1).strftime('%Y-%m-%d')

fw_campaign_delivery = spark.sql(query.format(date, date, date))

# COMMAND ----------

fw_campaign_delivery.write.format('delta')\
    .mode('overwrite')\
    .partitionBy('Campaign_ID')\
    .option('mergeSchema', 'true')\
    .option('overwriteDynamicPartitions', 'true')\
    .option('delta.enableDeletionVectors', 'false')\
    .option('delta.enableIcebergCompatV2', 'true')\
    .option('delta.universalFormat.enabledFormats', 'iceberg')\
    .option('delta.columnMapping.mode', 'name')\
    .saveAsTable('fox_bi_qa.gold_ad_sales.ft_freewheel_campaign_delivery')
