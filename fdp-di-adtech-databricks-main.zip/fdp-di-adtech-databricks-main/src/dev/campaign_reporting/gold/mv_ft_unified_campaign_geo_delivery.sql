%sql
CREATE OR REPLACE MATERIALIZED VIEW `fox_bi_qa`.`gold_ad_sales`.`mv_ft_unified_campaign_geo_delivery`
  (

 Data_Source string ,
 event_date date ,
 Campaign_ID bigint ,
 Campaign_Name string ,
 campaign_start_date date ,
 campaign_end_date date ,
 Insertion_Order_ID bigint ,
 Insertion_Order_Name string ,
 Advertiser_Name string ,
 Agency_Name string ,
 Line_Item_or_Placement_ID bigint ,
 Line_Item_or_Placement_Name string ,
 Demand_Type string ,
 City_Name string ,
 Country_Name string ,
 State_Province_Name string ,
 Delivered_Impressions bigint ,
 Delivered_Clicks bigint ,
 Multiple_Ad_Server_Flag boolean ,
 Multiple_Ad_Server_ID string ,
 Create_Timestamp timestamp ,
 Modified_Timestamp timestamp 
  ) AS


select
*
FROM fox_bi_qa.gold_ad_sales.ft_unified_campaign_geo_delivery
CLUSTER BY campaign_id, event_date