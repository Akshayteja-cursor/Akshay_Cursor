%sql
CREATE OR REPLACE MATERIALIZED VIEW `fox_bi_qa`.`gold_ad_sales`.`mv_ft_unified_campaign_delivery`
  (

data_source STRING,
event_date DATE,
campaign_id BIGINT,
campaign_name STRING,
campaign_start_date TIMESTAMP,
campaign_end_date TIMESTAMP,
order_name STRING,
order_id BIGINT,
device STRING,
advertiser_name STRING,
agency_name STRING,
aos_advertiser_name STRING,
advertiser_id BIGINT,
business_unit STRING,
line_item_or_placement_id BIGINT,
line_item_or_placement_name STRING,
demand_type STRING,
line_item_or_placement_start_date DATE,
line_item_or_placement_end_date DATE,
Delivered_Impressions BIGINT,
Delivered_Revenue DOUBLE,
Video_Completes DOUBLE,
Video_Starts DOUBLE,
Delivered_Clicks BIGINT,
Freewheel_On_Target_Net_Delivered_Impressions DOUBLE,
campaign_name_derived STRING,
account_manager STRING,
package_name STRING,
net_unit_cost DOUBLE,
guaranteed_impressions BIGINT,
guaranteed_revenue DOUBLE,
external_ad_id STRING,
aos_deal_id BIGINT,
aos_deal_name STRING,
aos_deal_start_date DATE,
aos_deal_end_date DATE,
aos_deal_line_item_name STRING,
aos_deal_line_item_id BIGINT,
demo_band STRING,
billable_third_party_server STRING,
multiple_ad_servers BOOLEAN,
multiple_ad_server_id STRING,
Third_Party_Video_Completes BIGINT,
Third_Party_Video_Views BIGINT,
Third_Party_Billable_Impressions BIGINT,
Third_Party_Clicks BIGINT,
Third_Party_Revenue DOUBLE,
create_timestamp TIMESTAMP,
modified_timestamp TIMESTAMP
  ) AS


select
  *
FROM fox_bi_qa.gold_ad_sales.ft_unified_campaign_delivery
CLUSTER BY campaign_id, event_date