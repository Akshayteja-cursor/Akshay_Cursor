# Databricks notebook source
from datetime import datetime, timedelta

# COMMAND ----------

date = dbutils.widgets.get('date')

# COMMAND ----------

query = """
    WITH gam_daily AS (
        SELECT
            ad_date,
            order_id,
            order_name,
            CASE 
                WHEN platform_group ILIKE '%other%' THEN 'N/A'
                ELSE platform_group
            END AS platform_group,
            advertiser_name,
            advertiser_id,
            business_unit,
            ad_format_name,
            requested_ad_sizes,
            line_item_id,
            line_item_name,
            line_item_type,
            line_item_start_timestamp,
            line_item_end_timestamp,
            SUM(total_cpm_and_cpc_revenue) AS total_cpm_and_cpc_revenue,
            SUM(total_impressions) AS total_impressions,
            SUM(video_viewership_complete) AS video_viewership_complete,
            SUM(video_viewership_start) AS video_viewership_start,
            SUM(total_clicks) AS total_clicks,
            etl_load_timestamp_utc
        FROM fox_bi_dev.silver_ads.ft_gam_summary_daily_data
        WHERE ad_date >= '{}'
        AND line_item_id <> -1
        GROUP BY ALL
    ),
    third_party_delivery AS (
        SELECT
            event_date,
            campaign_id,
            campaign_name,
            third_party_billable_server,
            CASE
                WHEN third_party_billable_server = 'Moat' THEN 'Moat'
                WHEN third_party_billable_server in ('DFA by Google', 'Dart Report Reader', 'Dart Report Reader, DFA by Google', 'DFP by Google') THEN 'FOX DCM'
                WHEN third_party_billable_server = 'DoubleVerify' THEN 'FOX Doubleverify'
                WHEN third_party_billable_server = 'Innovid 3rd Party' THEN 'FOX Innovid'
                WHEN third_party_billable_server in ('FlashTalking', 'FlashTalking Email Reader') THEN 'FOX Flashtalking'
                WHEN third_party_billable_server in ('Extreme Reach Email', 'ExtremeReachAPI') THEN 'FOX Extreme Reach'
                WHEN third_party_billable_server in ('MediaMind', 'MediaMind Report Reader', 'Sizmek SAS Report Reader', 'MediaMind Report Reader, Sizmek SAS Report Reader', 'Sizmek SAS Report Reader, MediaMind Report Reader') THEN 'FOX Sizmek'
                WHEN third_party_billable_server = 'TubeMogul' THEN 'TubeMogul'
                ELSE 'FOX 1st Party'
            END AS billable_third_party_server,
            SUM(third_party_video_completes) AS third_party_video_completes,
            SUM(third_party_video_views) AS third_party_video_views,
            SUM(third_party_billable_impressions) AS third_party_billable_impressions,
            SUM(third_party_clicks) AS third_party_clicks,
            SUM(third_party_revenue) AS third_party_revenue
        FROM fox_bi_dev.silver_ads.ft_third_party_campaign_delivery_daily_data
        WHERE event_date >= '{}'
        GROUP BY ALL
    ),
    op_line_detail AS (
        SELECT
            source,
            sales_order_line_item_id AS sales_line_item_id,
            sales_order_line_item_name AS sales_line_item_name,
            sales_order_id,
            sales_order_name,
            order_start_dt AS sales_order_start_date,
            order_end_dt AS sales_order_end_date,
            agency_name,
            advertiser_name,
            owner_name,
            primary_salesperson_name,
            account_coordinator,
            package_name,
            ps_line_item_id,
            demo_band,
            CASE
                WHEN billable_third_party_descr = 'DCM' THEN 'FOX DCM'
                WHEN billable_third_party_descr = 'Doubleverify' THEN 'FOX Doubleverify'
                WHEN billable_third_party_descr = 'Innovid' THEN 'FOX Innovid'
                WHEN billable_third_party_descr = 'Flashtalking' THEN 'FOX Flashtalking'
                WHEN billable_third_party_descr = 'Extreme Reach' THEN 'FOX Extreme Reach'
                WHEN billable_third_party_descr = 'Sizmek' THEN 'FOX Sizmek'
                WHEN billable_third_party_descr = '1st Party' THEN 'FOX 1st Party'
                ELSE billable_third_party_descr
            END AS billable_third_party_server,
            net_unit_cost_amt AS net_unit_cost,
            net_cost_amt,
            sales_order_line_items_qty AS quantity
        FROM fox_bi_prod.gold_ad_sales.ft_digital_operative_line_date_allocation oms
        INNER JOIN (
            SELECT DISTINCT line_item_id FROM fox_bi_dev.silver_ads.ft_gam_summary_daily_data
            WHERE ad_date >= '2024-01-01'
            AND line_item_id <> -1
        ) gam
        ON oms.ps_line_item_id = gam.line_item_id
        WHERE ps_line_item_id IS NOT NULL
        AND oms.date BETWEEN oms.sales_order_line_item_start_dt and oms.sales_order_line_item_end_dt
        GROUP BY ALL
    )
    SELECT
        /*+ BROADCAST(li) */
        gam_daily.ad_date AS Event_Date,
        CAST(op_line_detail.sales_line_item_id AS BIGINT) AS AOS_Deal_Line_Item_ID,
        op_line_detail.sales_line_item_name AS AOS_Deal_Line_Item_Name,
        COALESCE(op_line_detail.sales_order_id, -1) AS Campaign_ID,
        COALESCE(op_line_detail.sales_order_name, 'N/A') AS Campaign_Name,
        COALESCE(op_line_detail.sales_order_start_date, or.order_start_timestamp) AS Campaign_Start_Date,
        COALESCE(op_line_detail.sales_order_end_date, or.order_end_timestamp) AS Campaign_End_Date,
        CASE
            WHEN op_line_detail.sales_order_end_date < CURRENT_TIMESTAMP() THEN 'Closed'
            ELSE 'Active'
        END AS Campaign_Status,
        gam_daily.ad_date NOT BETWEEN COALESCE(op_line_detail.sales_order_start_date, or.order_start_timestamp) AND COALESCE(op_line_detail.sales_order_end_date, or.order_end_timestamp) AS Out_Of_Flight_Flag,
        gam_daily.order_id AS Order_ID,
        gam_daily.order_name AS Order_Name,
        gam_daily.platform_group AS Device,
        gam_daily.advertiser_name AS Advertiser_Name,
        gam_daily.advertiser_id AS Advertiser_ID,
        gam_daily.business_unit AS Business_Unit,
        gam_daily.ad_format_name AS Ad_Unit_Format,
        gam_daily.requested_ad_sizes AS Ad_Unit_Size,
        gam_daily.line_item_id AS Line_Item_ID,
        gam_daily.line_item_name AS Line_Item_Name,
        gam_daily.line_item_type AS Line_Item_Type,
        TO_DATE(gam_daily.line_item_start_timestamp) AS Line_Item_Start_Date,
        TO_DATE(gam_daily.line_item_end_timestamp) AS Line_Item_End_Date,
        li.delivery_indicator_actual_delivery_percentage AS Actual_Delivery_Indicator,
        SUM(gam_daily.total_cpm_and_cpc_revenue) AS Delivered_Revenue,
        SUM(gam_daily.total_impressions) AS Delivered_Impressions,
        SUM(gam_daily.video_viewership_complete) AS Video_Completes,
        SUM(gam_daily.video_viewership_start) AS Video_Starts,
        SUM(gam_daily.total_clicks) AS Delivered_Clicks,
        COALESCE(op_line_detail.agency_name, 'N/A') AS Agency_Name,
        COALESCE(op_line_detail.advertiser_name, 'N/A') AS Advertiser_OMS,
        COALESCE(op_line_detail.owner_name, 'N/A') AS Account_Manager,
        COALESCE(op_line_detail.primary_salesperson_name, 'N/A') AS Primary_Salesperson_Name,
        COALESCE(op_line_detail.account_coordinator, 'N/A') AS Account_Coordinator,
        ROUND(COALESCE(op_line_detail.net_unit_cost, 0), 2) AS Net_Unit_Cost,
        ROUND(COALESCE(op_line_detail.net_cost_amt, 0), 2) AS Guaranteed_Revenue,
        COALESCE(op_line_detail.quantity, 0) AS Guaranteed_Impressions,
        COALESCE(op_line_detail.ps_line_item_id, '-1') AS External_AD_ID,
        COALESCE(op_line_detail.sales_order_id, -1) AS AOS_Deal_ID,
        COALESCE(op_line_detail.sales_order_name, 'N/A') as AOS_Deal_Name,
        DATE(op_line_detail.sales_order_start_date) AS AOS_Deal_Start_Date,
        DATE(op_line_detail.sales_order_end_date) AS AOS_Deal_End_Date,
        COALESCE(op_line_detail.demo_band, 'N/A') Demo_Band,
        COALESCE(op_line_detail.package_name, 'N/A') Package_Name,
        op_line_detail.billable_third_party_server AS Billable_Third_Party_Server,
        SUM(third_party_delivery.third_party_video_completes) AS Third_Party_Video_Completes,
        SUM(third_party_delivery.third_party_video_views) AS Third_Party_Video_Views,
        SUM(third_party_delivery.third_party_billable_impressions) AS Third_Party_Billable_Impressions,
        SUM(third_party_delivery.third_party_clicks) AS Third_Party_Clicks,
        ROUND(SUM(third_party_delivery.third_party_revenue), 2) AS Third_Party_Revenue,
        gam_daily.etl_load_timestamp_utc AS Create_Timestamp,
        gam_daily.etl_load_timestamp_utc AS Modified_Timestamp
    FROM gam_daily
    LEFT JOIN fox_bi_dev.silver_ads.dim_line_item li
    ON gam_daily.line_item_id = li.line_item_id
    LEFT JOIN fox_bi_dev.silver_ads.dim_orders or
    ON gam_daily.order_id = or.order_id
    LEFT JOIN op_line_detail
    ON gam_daily.line_item_id = op_line_detail.ps_line_item_id
    LEFT JOIN third_party_delivery
    ON gam_daily.ad_date = third_party_delivery.event_date
    AND gam_daily.line_item_id = third_party_delivery.campaign_id
    AND op_line_detail.billable_third_party_server = third_party_delivery.billable_third_party_server
    WHERE (
        CASE
            WHEN ((LOWER(gam_daily.advertiser_name) LIKE '%promo%') OR (LOWER(gam_daily.advertiser_name) LIKE '% test%')) THEN FALSE
            WHEN ((LOWER(gam_daily.order_name) LIKE '%promo%') OR (LOWER(gam_daily.order_name) LIKE '% test%')) THEN FALSE
            WHEN ((LOWER(op_line_detail.agency_name) LIKE '%promo%') OR (LOWER(op_line_detail.agency_name) LIKE '% test%')) THEN FALSE
            ELSE TRUE
        END
    )
    GROUP BY ALL
"""

if datetime.strptime(date, '%Y-%m-%d').day < 5:
    date = (datetime.strptime(date, '%Y-%m-%d') - timedelta(days=5)).replace(day=1).strftime('%Y-%m-%d')
else:
    date = datetime.strptime(date, '%Y-%m-%d').replace(day=1).strftime('%Y-%m-%d')

gam_campaign_pacing = spark.sql(query.format(date, date))

# COMMAND ----------

if not spark.catalog.tableExists(f'fox_bi_qa.gold_ad_sales.ft_gam_campaign_pacing'): #Add the table name for First time load 
    gam_campaign_pacing.write.format('delta')\
        .mode('overwrite')\
        .partitionBy('Event_Date')\
        .option('mergeSchema', 'true')\
        .option('overwriteDynamicPartitions', 'true')\
        .option('delta.enableDeletionVectors', 'false')\
        .option('delta.enableIcebergCompatV2', 'true')\
        .option('delta.universalFormat.enabledFormats', 'iceberg')\
        .option('delta.columnMapping.mode', 'name')\
        .saveAsTable('fox_bi_qa.gold_ad_sales.ft_gam_campaign_pacing')
else:
    gam_campaign_pacing.write.format('delta')\
        .mode('overwrite')\
        .option('partitionOverwriteMode', 'dynamic')\
        .saveAsTable('fox_bi_qa.gold_ad_sales.ft_gam_campaign_pacing')

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO fox_bi_qa.gold_ad_sales.ft_gam_campaign_pacing AS tgt
# MAGIC     USING (
# MAGIC         SELECT
# MAGIC             DISTINCT
# MAGIC             CAST(sales_order_line_item_id AS BIGINT) AS AOS_Deal_Line_Item_ID,
# MAGIC             sales_order_line_item_name AS AOS_Deal_Line_Item_Name,
# MAGIC             COALESCE(sales_order_id, -1) AS Campaign_ID,
# MAGIC             COALESCE(sales_order_name, 'N/A') AS Campaign_Name,
# MAGIC             order_start_dt AS Campaign_Start_Date,
# MAGIC             order_end_dt AS Campaign_End_Date,
# MAGIC             CASE
# MAGIC                 WHEN order_end_dt < CURRENT_TIMESTAMP() THEN 'Closed'
# MAGIC                 ELSE 'Active'
# MAGIC             END AS Campaign_Status,
# MAGIC             COALESCE(agency_name, 'N/A') AS Agency_Name,
# MAGIC             COALESCE(advertiser_name, 'N/A') AS Advertiser_OMS,
# MAGIC             COALESCE(owner_name, 'N/A') AS Account_Manager,
# MAGIC             COALESCE(primary_salesperson_name, 'N/A') AS Primary_Salesperson_Name,
# MAGIC             COALESCE(account_coordinator, 'N/A') AS Account_Coordinator,
# MAGIC             ROUND(COALESCE(net_unit_cost_amt, 0), 2) AS Net_Unit_Cost,
# MAGIC             ROUND(COALESCE(net_cost_amt, 0), 2) AS Guaranteed_Revenue,
# MAGIC             COALESCE(sales_order_line_items_qty, 0) AS Guaranteed_Impressions,
# MAGIC             COALESCE(ps_line_item_id, '-1') AS External_AD_ID,
# MAGIC             COALESCE(sales_order_id, -1) AS AOS_Deal_ID,
# MAGIC             COALESCE(sales_order_name, 'N/A') as AOS_Deal_Name,
# MAGIC             DATE(order_start_dt) AS AOS_Deal_Start_Date,
# MAGIC             DATE(order_end_dt) AS AOS_Deal_End_Date,
# MAGIC             COALESCE(demo_band, 'N/A') Demo_Band,
# MAGIC             COALESCE(package_name, 'N/A') Package_Name,
# MAGIC             CASE
# MAGIC                 WHEN billable_third_party_descr = 'DCM' THEN 'FOX DCM'
# MAGIC                 WHEN billable_third_party_descr = 'Doubleverify' THEN 'FOX Doubleverify'
# MAGIC                 WHEN billable_third_party_descr = 'Innovid' THEN 'FOX Innovid'
# MAGIC                 WHEN billable_third_party_descr = 'Flashtalking' THEN 'FOX Flashtalking'
# MAGIC                 WHEN billable_third_party_descr = 'Extreme Reach' THEN 'FOX Extreme Reach'
# MAGIC                 WHEN billable_third_party_descr = 'Sizmek' THEN 'FOX Sizmek'
# MAGIC                 WHEN billable_third_party_descr = '1st Party' THEN 'FOX 1st Party'
# MAGIC                 ELSE billable_third_party_descr
# MAGIC             END AS Billable_Third_Party_Server
# MAGIC         FROM fox_bi_prod.gold_ad_sales.ft_digital_operative_line_date_allocation oms
# MAGIC         INNER JOIN (
# MAGIC             SELECT DISTINCT line_item_id FROM fox_bi_dev.silver_ads.ft_gam_summary_daily_data
# MAGIC             WHERE ad_date >= '2024-01-01'
# MAGIC             AND line_item_id <> -1
# MAGIC         ) gam
# MAGIC         ON oms.ps_line_item_id = gam.line_item_id
# MAGIC         WHERE ps_line_item_id IS NOT NULL
# MAGIC         AND oms.date BETWEEN oms.sales_order_line_item_start_dt and oms.sales_order_line_item_end_dt
# MAGIC     ) AS src
# MAGIC     ON COALESCE(src.External_AD_ID, '-1') = COALESCE(tgt.Line_Item_ID, '-1')
# MAGIC     AND COALESCE(src.AOS_Deal_Line_Item_ID, '-1') = COALESCE(tgt.AOS_Deal_Line_Item_ID, '-1')
# MAGIC     WHEN MATCHED AND (
# MAGIC         COALESCE(src.AOS_Deal_Line_Item_ID,'N/A') <> COALESCE(tgt.AOS_Deal_Line_Item_ID,'N/A')
# MAGIC         OR COALESCE(src.AOS_Deal_Line_Item_Name,'N/A') <> COALESCE(tgt.AOS_Deal_Line_Item_Name,'N/A')
# MAGIC         OR COALESCE(src.Campaign_ID,'N/A') <> COALESCE(tgt.Campaign_ID,'N/A')
# MAGIC         OR COALESCE(src.Campaign_Name,'N/A') <> COALESCE(tgt.Campaign_Name,'N/A')
# MAGIC         OR COALESCE(src.Campaign_Start_Date,'1900-01-01') <> COALESCE(tgt.Campaign_Start_Date,'1900-01-01')
# MAGIC         OR COALESCE(src.Campaign_End_Date,'1900-01-01') <> COALESCE(tgt.Campaign_End_Date,'1900-01-01')
# MAGIC         OR COALESCE(src.Campaign_Status,'N/A') <> COALESCE(tgt.Campaign_Status,'N/A')
# MAGIC         OR COALESCE(src.Agency_Name,'N/A') <> COALESCE(tgt.Agency_Name,'N/A')
# MAGIC         OR COALESCE(src.Advertiser_OMS,'N/A') <> COALESCE(tgt.Advertiser_OMS,'N/A')
# MAGIC         OR COALESCE(src.Account_Manager,'N/A') <> COALESCE(tgt.Account_Manager,'N/A')
# MAGIC         OR COALESCE(src.Primary_Salesperson_Name,'N/A') <> COALESCE(tgt.Primary_Salesperson_Name,'N/A')
# MAGIC         OR COALESCE(src.Account_Coordinator,'N/A') <> COALESCE(tgt.Account_Coordinator,'N/A')
# MAGIC         OR COALESCE(src.Net_Unit_Cost,'N/A') <> COALESCE(tgt.Net_Unit_Cost,'N/A')
# MAGIC         OR COALESCE(src.Guaranteed_Revenue,'N/A') <> COALESCE(tgt.Guaranteed_Revenue,'N/A')
# MAGIC         OR COALESCE(src.Guaranteed_Impressions,'N/A') <> COALESCE(tgt.Guaranteed_Impressions,'N/A')
# MAGIC         OR COALESCE(src.External_AD_ID,'N/A') <> COALESCE(tgt.External_AD_ID,'N/A')
# MAGIC         OR COALESCE(src.AOS_Deal_ID,'N/A') <> COALESCE(tgt.AOS_Deal_ID,'N/A')
# MAGIC         OR COALESCE(src.AOS_Deal_Name,'N/A') <> COALESCE(tgt.AOS_Deal_Name,'N/A')
# MAGIC         OR COALESCE(src.AOS_Deal_Start_Date,'1900-01-01') <> COALESCE(tgt.AOS_Deal_Start_Date,'1900-01-01')
# MAGIC         OR COALESCE(src.AOS_Deal_End_Date,'1900-01-01') <> COALESCE(tgt.AOS_Deal_End_Date,'1900-01-01')
# MAGIC         OR COALESCE(src.Demo_Band,'N/A') <> COALESCE(tgt.Demo_Band,'N/A')
# MAGIC         OR COALESCE(src.Package_Name,'N/A') <> COALESCE(tgt.Package_Name,'N/A')
# MAGIC         OR COALESCE(src.Billable_Third_Party_Server,'N/A') <> COALESCE(tgt.Billable_Third_Party_Server,'N/A')
# MAGIC     ) THEN UPDATE SET
# MAGIC         tgt.AOS_Deal_Line_Item_ID = src.AOS_Deal_Line_Item_ID
# MAGIC         , tgt.AOS_Deal_Line_Item_Name = src.AOS_Deal_Line_Item_Name
# MAGIC         , tgt.Campaign_ID = src.Campaign_ID
# MAGIC         , tgt.Campaign_Name = src.Campaign_Name
# MAGIC         , tgt.Campaign_Start_Date = src.Campaign_Start_Date
# MAGIC         , tgt.Campaign_End_Date = src.Campaign_End_Date
# MAGIC         , tgt.Campaign_Status = src.Campaign_Status
# MAGIC         , tgt.Agency_Name = src.Agency_Name
# MAGIC         , tgt.Advertiser_OMS = src.Advertiser_OMS
# MAGIC         , tgt.Account_Manager = src.Account_Manager
# MAGIC         , tgt.Primary_Salesperson_Name = src.Primary_Salesperson_Name
# MAGIC         , tgt.Account_Coordinator = src.Account_Coordinator
# MAGIC         , tgt.Net_Unit_Cost = src.Net_Unit_Cost
# MAGIC         , tgt.Guaranteed_Revenue = src.Guaranteed_Revenue
# MAGIC         , tgt.Guaranteed_Impressions = src.Guaranteed_Impressions
# MAGIC         , tgt.External_AD_ID = src.External_AD_ID
# MAGIC         , tgt.AOS_Deal_ID = src.AOS_Deal_ID
# MAGIC         , tgt.AOS_Deal_Name = src.AOS_Deal_Name
# MAGIC         , tgt.AOS_Deal_Start_Date = src.AOS_Deal_Start_Date
# MAGIC         , tgt.AOS_Deal_End_Date = src.AOS_Deal_End_Date
# MAGIC         , tgt.Demo_Band = src.Demo_Band
# MAGIC         , tgt.Package_Name = src.Package_Name
# MAGIC         , tgt.Billable_Third_Party_Server = src.Billable_Third_Party_Server