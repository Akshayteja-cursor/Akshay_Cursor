# Databricks notebook source
from datetime import datetime, timedelta



# COMMAND ----------
query = """
    with raw_fw_data as 
	(
	 
	 select
	 'Freewheel' as `Data Source`,
	 event_date as `Event Date`,
	 COALESCE(Campaign_ID, Deal_ID) as `Campaign ID`,
	 COALESCE(Campaign_Name, Deal_Name) as `Campaign Name`,
	 COALESCE(campaign_start_timestamp_est, Deal_Start_Date) as `Campaign Start Date`,
	 COALESCE(campaign_end_timestamp_est, Deal_End_Date) as `Campaign End Date`,
	 Insertion_Order_Name as `Order Name`,
	 Insertion_Order_ID as `Order ID`,
	 device_name as `Device`,
	 Advertiser_Name as `Advertiser Name`,
	 Agency_Name as `Agency Name`,
	 AOS_advertiser_name as `AOS Advertiser Name`,
	 null as `Advertiser ID`,
	 Business_Unit as `Business Unit`,
	 placement_id as `Line Item or Placement ID`,
	 placement_name `Line Item or Placement Name`,
	 case
	   when sales_channel_type = 'Programmatic' then deal_type
	   else sales_channel_type
	 end `Demand Type`,
	 placement_start_date as `Line Item or Placement Start Date`,
	 placement_end_date as `Line Item or Placement End Date`,
	 delivered_impressions `Delivered Impressions`,
	 Delivered_Revenue `Delivered Revenue`,
	 null `Video Completes`,
	 null as `Video Starts`,
	 delivered_clicks `Delivered Clicks`,
	 on_target_net_delivered_impressions_quantity `Freewheel On-Target Net Delivered Impressions`,
	 Campaign_Name_Derived `Campaign Name Derived`,
	 owner_name `Account Manager`,
	 package_name `Package Name`,
	 net_unit_cost `Net Unit Cost`,
	 Guaranteed_Impressions `Guaranteed Impressions`,
	 Guaranteed_Revenue `Guaranteed Revenue`,
	 External_AD_ID `External AD ID`,
	 aos_deal_id AS `AOS Deal ID`,
	 AOS_deal_name `AOS Deal Name`,
	 AOS_Deal_Start_Date as `AOS Deal Start Date`,
	 AOS_Deal_End_Date as `AOS Deal End Date`,
	 sales_order_line_item_name as `AOS Deal Line Item Name`,
	 sales_order_line_item_id as `AOS Deal Line Item ID`,
	 demo_band `Demo Band`,
	 cmp.billable_third_part_server `Billable Third Party Server`,
	 CASE
	   WHEN
	 	regexp_substr(`Insertion_Order_Name`, '^\\\\d+[^-|_| ]*') in (
	 	  select distinct
	 		regexp_substr(`Order_Name`, '^\\\\d+[^-|_| ]*')
	 	  from
	 		fox_bi_qa.gold_ad_sales.ft_gam_campaign_delivery
	 	)
	   THEN
	 	True
	   ELSE False
	 END Multiple_Ad_Servers,
	 creative_id,
	 global_ad_unit_position,
	 regexp_substr(`Insertion_Order_Name`, '^\\\\d+[^-|_| ]*') `Multiple Ad Server ID`,
	 min(third_party_video_completes) over (partition by creative_id, placement_id, global_ad_unit_position, event_date) `Third Party Video Completes`,
	 min(third_party_video_views) over (partition by creative_id, placement_id, global_ad_unit_position, event_date) `Third Party Video Views`,
	 min(third_party_billable_impressions) over (partition by creative_id, placement_id, global_ad_unit_position, event_date) `Third Party Billable Impressions`,
	 min(third_party_clicks) over (partition by creative_id, placement_id, global_ad_unit_position, event_date) `Third Party Clicks`,
	 min(third_party_revenue) over (partition by creative_id, placement_id, global_ad_unit_position, event_date) `Third Party Revenue`,
	 Create_Timestamp `Create Timestamp`,
	 Modified_Timestamp `Modified Timestamp`
  from
	fox_bi_qa.gold_ad_sales.ft_freewheel_campaign_delivery cmp
	--where placement_id = '86295416' and cmp.event_date = '2025-09-02'
	-- and business_unit = 'Entertainment' and device_name = 'DT'
	 )
,min_fw_data 
	(
	  select
		`Data Source`,
		`Event Date`,
		`Campaign ID`,
		`Campaign Name`,
		`Campaign Start Date`,
		`Campaign End Date`,
		`Order Name`,
		`Order ID`,
		`Device`,
		`Advertiser Name`,
		`Agency Name`,
		`AOS Advertiser Name`,
		`Advertiser ID`,
		`Business Unit`,
		`Line Item or Placement ID`,
		`Line Item or Placement Name`,
		`Demand Type`,
		`Line Item or Placement Start Date`,
		`Line Item or Placement End Date`,
		sum(`Delivered Impressions`) `Delivered Impressions`,
		sum(`Delivered Revenue`) `Delivered Revenue`,
		sum(`Video Completes`) `Video Completes`,
		sum(`Video Starts`) `Video Starts`,
		sum(`Delivered Clicks`) `Delivered Clicks`,
		sum(`Freewheel On-Target Net Delivered Impressions`) `Freewheel On-Target Net Delivered Impressions`,
		`Campaign Name Derived`,
		`Account Manager`,
		`Package Name`,
		`Net Unit Cost`,
		`Guaranteed Impressions`,
		`Guaranteed Revenue`,
		`External AD ID`,
		`AOS Deal ID`,
		`AOS Deal Name`,
		`AOS Deal Start Date`,
		`AOS Deal End Date`,
		`AOS Deal Line Item Name`,
		`AOS Deal Line Item ID`,
		`Demo Band`,
		`Billable Third Party Server`,
		`Multiple_Ad_Servers`,
		`Multiple Ad Server ID`,
		creative_id,
		global_ad_unit_position,
		min(`Third Party Video Completes`) `Third Party Video Completes`,
		min(`Third Party Video Views`) `Third Party Video Views`,
		min(`Third Party Billable Impressions`) `Third Party Billable Impressions`,
		min(`Third Party Clicks`) `Third Party Clicks`,
		min(`Third Party Revenue`) `Third Party Revenue`,
		`Create Timestamp`,
		`Modified Timestamp`
	  from
		raw_fw_data
	  group by
		all   
	 )
,agg_fw_data 
	(
	 
      select
        `Data Source`,
        `Event Date`,
        `Campaign ID`,
        `Campaign Name`,
        `Campaign Start Date`,
        `Campaign End Date`,
        `Order Name`,
        `Order ID`,
        `Device`,
        `Advertiser Name`,
        `Agency Name`,
        `AOS Advertiser Name`,
        `Advertiser ID`,
        `Business Unit`,
        `Line Item or Placement ID`,
        `Line Item or Placement Name`,
        `Demand Type`,
        `Line Item or Placement Start Date`,
        `Line Item or Placement End Date`,
        sum(`Delivered Impressions`) `Delivered Impressions`,
        sum(`Delivered Revenue`) `Delivered Revenue`,
        sum(`Video Completes`) `Video Completes`,
        sum(`Video Starts`) `Video Starts`,
        sum(`Delivered Clicks`) `Delivered Clicks`,
        sum(
          `Freewheel On-Target Net Delivered Impressions`
        ) `Freewheel On-Target Net Delivered Impressions`,
        `Campaign Name Derived`,
        `Account Manager`,
        `Package Name`,
        `Net Unit Cost`,
        `Guaranteed Impressions`,
        `Guaranteed Revenue`,
        `External AD ID`,
        `AOS Deal ID`,
        `AOS Deal Name`,
        `AOS Deal Start Date`,
        `AOS Deal End Date`,
        `AOS Deal Line Item Name`,
        `AOS Deal Line Item ID`,
        `Demo Band`,
        `Billable Third Party Server`,
        `Multiple_Ad_Servers`,
        `Multiple Ad Server ID`,
        (`Third Party Video Completes`) `Third Party Video Completes`,
        (`Third Party Video Views`) `Third Party Video Views`,
        (`Third Party Billable Impressions`) `Third Party Billable Impressions`,
        (`Third Party Clicks`) `Third Party Clicks`,
        (`Third Party Revenue`) `Third Party Revenue`,
        `Create Timestamp`,
        `Modified Timestamp`
      from
        min_fw_data
      group by
        all
    
	)
,final_fw 
( 
  select
    `Data Source` data_source,
    `Event Date` event_date,
    `Campaign ID` campaign_id,
    `Campaign Name` campaign_name,
    `Campaign Start Date` campaign_start_date,
    `Campaign End Date` campaign_end_date,
    `Order Name` order_name,
    `Order ID` order_id,
    `Device` device,
    `Advertiser Name` advertiser_name,
    `Agency Name` agency_name,
    `AOS Advertiser Name` aos_advertiser_name,
    `Advertiser ID` advertiser_id,
    `Business Unit` business_unit,
    `Line Item or Placement ID` line_item_or_placement_id,
    `Line Item or Placement Name` line_item_or_placement_name,
    `Demand Type` demand_type,
    `Line Item or Placement Start Date` line_item_or_placement_start_date,
    `Line Item or Placement End Date` line_item_or_placement_end_date,
    sum(`Delivered Impressions`) `Delivered_Impressions`,
    sum(`Delivered Revenue`) `Delivered_Revenue`,
    sum(`Video Completes`) `Video_Completes`,
    sum(`Video Starts`) `Video_Starts`,
    sum(`Delivered Clicks`) `Delivered_Clicks`,
    sum(`Freewheel On-Target Net Delivered Impressions`) `Freewheel_On_Target_Net_Delivered_Impressions`,
    `Campaign Name Derived` campaign_name_derived,
    `Account Manager` account_manager,
    `Package Name` package_name,
    `Net Unit Cost` net_unit_cost,
    `Guaranteed Impressions` guaranteed_impressions,
    `Guaranteed Revenue` guaranteed_revenue,
    `External AD ID` external_ad_id,
    `AOS Deal ID` aos_deal_id,
    `AOS Deal Name` aos_deal_name,
    `AOS Deal Start Date` aos_deal_start_date,
    `AOS Deal End Date` aos_deal_end_date,
    `AOS Deal Line Item Name` aos_deal_line_item_name,
    `AOS Deal Line Item ID` aos_deal_line_item_id,
    `Demo Band` demo_band,
    `Billable Third Party Server` billable_third_party_server,
    `Multiple_Ad_Servers` multiple_ad_servers,
    `Multiple Ad Server ID` multiple_ad_server_id,
    sum(`Third Party Video Completes`) `Third_Party_Video_Completes`,
    sum(`Third Party Video Views`) `Third_Party_Video_Views`,
    sum(`Third Party Billable Impressions`) `Third_Party_Billable_Impressions`,
    sum(`Third Party Clicks`) `Third_Party_Clicks`,
    sum(`Third Party Revenue`) `Third_Party_Revenue`,
    `Create Timestamp` create_timestamp,
    `Modified Timestamp` modified_timestamp
  from
    agg_fw_data
  group by
    all
 )
 ,raw_gam_data AS (
    SELECT
        'GAM' AS `Data Source`,
        Event_Date AS `Event Date`,
        Campaign_ID AS `Campaign ID`,
        Campaign_Name AS `Campaign Name`,
        campaign_start_date AS `Campaign Start Date`,
        Campaign_End_Date AS `Campaign End Date`,
        Order_Name AS `Order Name`,
        Order_ID AS `Order ID`,
        Device,
        Advertiser_Name AS `Advertiser Name`,
        Agency_Name AS `Agency Name`,
        Advertiser_OMS AS `AOS Advertiser Name`,
        Advertiser_ID AS `Advertiser ID`,
        Business_Unit AS `Business Unit`,
        Line_Item_ID AS `Line Item or Placement ID`,
        Line_Item_Name AS `Line Item or Placement Name`,
        Line_Item_Type AS `Demand Type`,
        Line_Item_Start_Date AS `Line Item or Placement Start Date`,
        Line_Item_End_Date AS `Line Item or Placement End Date`,
        Delivered_Impressions,
        Delivered_Revenue,
        NULL AS `Video Completes`,
        NULL AS `Video Starts`,
        Delivered_Clicks,
        null as `Freewheel On-Target Net Delivered Impressions`,
        AOS_Deal_ID || '-' || AOS_Deal_Name AS `Campaign Name Derived`,
        Account_Manager AS `Account Manager`,
        package_name AS `Package Name`,
        Net_Unit_Cost AS `Net Unit Cost`,
        Guaranteed_Impressions AS `Guaranteed Impressions`,
        Guaranteed_Revenue AS `Guaranteed Revenue`,
        External_AD_ID AS `External AD ID`,
        aos_deal_id AS `AOS Deal ID`,
        AOS_deal_name AS `AOS Deal Name`,
        AOS_Deal_Start_Date AS `AOS Deal Start Date`,
        AOS_Deal_End_Date AS `AOS Deal End Date`,
        AOS_Deal_Line_Item_Name AS `AOS Deal Line Item Name`,
        AOS_Deal_Line_Item_ID AS `AOS Deal Line Item ID`,
        demo_band AS `Demo Band`,
        Billable_Third_Party_Server AS `Billable Third Party Server`,
        CASE
            WHEN regexp_substr(Order_Name, '^\\\d+[^-|_| ]*') IN (
                SELECT DISTINCT regexp_substr(`Insertion_Order_Name`, '^\\\d+[^-|_| ]*')
                FROM fox_bi_qa.gold_ad_sales.ft_freewheel_campaign_delivery
            ) THEN True
            ELSE False
        END AS Multiple_Ad_Servers,
        regexp_substr(Order_Name, '^\\\d+[^-|_| ]*') AS `Multiple Ad Server ID`,
        Ad_Unit_Format,
        Ad_unit_Size,
        -- Window functions for Third Party Metrics
        MIN(third_party_video_completes) OVER (PARTITION BY Line_Item_ID, event_date) AS `Third_party_Video_Completes_Min`,
        MIN(third_party_video_views) OVER (PARTITION BY Line_Item_ID, event_date) AS `Third_party_Video_Views_Min`,
        MIN(third_party_billable_impressions) OVER (PARTITION BY Line_Item_ID, event_date) AS `Third_Party_Billable_Impressions_Min`,
        MIN(third_party_clicks) OVER (PARTITION BY Line_Item_ID, event_date) AS `Third_party_Clicks_Min`,
        MIN(third_party_revenue) OVER (PARTITION BY Line_Item_ID, event_date) AS `Third_party_Revenue_Min`,
        Create_Timestamp AS `Create Timestamp`,
        Modified_Timestamp AS `Modified Timestamp`
    FROM fox_bi_qa.gold_ad_sales.ft_gam_campaign_delivery
    --where  Line_Item_ID =  '6811746476' and event_date = '2025-09-01'
),

final_gam AS (
    SELECT
    `Data Source` data_source,
    `Event Date` event_date,
    `Campaign ID` campaign_id,
    `Campaign Name` campaign_name,
    `Campaign Start Date` campaign_start_date,
    `Campaign End Date` campaign_end_date,
    `Order Name` order_name,
    `Order ID` order_id,
    `Device` device,
    `Advertiser Name` advertiser_name,
    `Agency Name` agency_name,
    `AOS Advertiser Name` aos_advertiser_name,
    `Advertiser ID` advertiser_id,
    `Business Unit` business_unit,
    `Line Item or Placement ID` line_item_or_placement_id,
    `Line Item or Placement Name` line_item_or_placement_name,
    `Demand Type` demand_type,
    `Line Item or Placement Start Date` line_item_or_placement_start_date,
    `Line Item or Placement End Date` line_item_or_placement_end_date,
    sum(`Delivered_Impressions`) `Delivered_Impressions`,
    sum(`Delivered_Revenue`) `Delivered_Revenue`,
    sum(`Video Completes`) `Video_Completes`,
    sum(`Video Starts`) `Video_Starts`,
    sum(`Delivered_Clicks`) `Delivered_Clicks`,
    sum(`Freewheel On-Target Net Delivered Impressions`) `Freewheel_On_Target_Net_Delivered_Impressions`,
    `Campaign Name Derived` campaign_name_derived,
    `Account Manager` account_manager,
    `Package Name` package_name,
    `Net Unit Cost` net_unit_cost,
    `Guaranteed Impressions` guaranteed_impressions,
    `Guaranteed Revenue` guaranteed_revenue,
    `External AD ID` external_ad_id,
    `AOS Deal ID` aos_deal_id,
    `AOS Deal Name` aos_deal_name,
    `AOS Deal Start Date` aos_deal_start_date,
    `AOS Deal End Date` aos_deal_end_date,
    `AOS Deal Line Item Name` aos_deal_line_item_name,
    `AOS Deal Line Item ID` aos_deal_line_item_id,
    `Demo Band` demo_band,
    `Billable Third Party Server` billable_third_party_server,
    `Multiple_Ad_Servers` multiple_ad_servers,
    `Multiple Ad Server ID` multiple_ad_server_id,
     MIN(`Third_Party_Video_Completes_Min`) `Third_Party_Video_Completes`,
     MIN(`Third_Party_Video_Views_Min`) `Third_Party_Video_Views`,
     MIN(`Third_Party_Billable_Impressions_Min`) `Third_Party_Billable_Impressions`,
     MIN(`Third_Party_Clicks_Min`) `Third_Party_Clicks`,
     MIN(`Third_Party_Revenue_Min`) `Third_Party_Revenue`,
    `Create Timestamp` create_timestamp,
    `Modified Timestamp` modified_timestamp
    FROM raw_gam_data
    GROUP BY ALL
)
SELECT * FROM final_gam
 UNION ALL
 SELECT * FROM final_fw
"""


unified_campaign_delivery = spark.sql(query)

# COMMAND ----------

unified_campaign_delivery.write.format('delta')\
    .mode('overwrite')\
    .partitionBy('Campaign_ID')\
    .option('mergeSchema', 'true')\
    .option('overwriteDynamicPartitions', 'true')\
    .option('delta.enableDeletionVectors', 'false')\
    .option('delta.enableIcebergCompatV2', 'true')\
    .option('delta.universalFormat.enabledFormats', 'iceberg')\
    .option('delta.columnMapping.mode', 'name')\
    .saveAsTable('fox_bi_qa.gold_ad_sales.ft_unified_campaign_delivery')