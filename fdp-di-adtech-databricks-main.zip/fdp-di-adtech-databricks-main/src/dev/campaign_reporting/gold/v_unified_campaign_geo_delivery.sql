  create or replace view fox_bi_qa.gold_ad_sales.v_unified_campaign_geo_delivery as
  (
    select
    Data_Source as `Data Source`,
    event_date as `Event Date`,
    nvl(Campaign_ID, -1) as `Campaign ID`,
    nvl(Campaign_Name, 'N/A') as `Campaign Name`,
    campaign_start_date as `Campaign Start Date`,
    campaign_end_date as `Campaign End Date`,
    nvl(Insertion_Order_ID, -1) as `Insertion Order ID`,
    nvl(Insertion_Order_Name, 'N/A') as `Insertion Order Name`,
    nvl(Advertiser_Name, 'N/A') as `Advertiser Name`,
    nvl(Agency_Name, 'N/A') as `Agency Name`,
    nvl(Line_Item_or_Placement_ID, -1) as `Line Item or Placement ID`,
    nvl(Line_Item_or_Placement_Name, 'N/A') as `Line Item or Placement Name`,
    nvl(Demand_Type, 'N/A') as `Demand Type`,
    nvl(City_Name, 'N/A') as `City Name`,
    nvl(Country_Name, 'N/A') as `Country Name`,
    nvl(State_Province_Name, 'N/A') as `State Province Name`,
    nvl(Delivered_Impressions, 0) as `Delivered Impressions`,
    nvl(Delivered_Clicks, 0) as `Delivered Clicks`,
    Multiple_Ad_Server_Flag as `Multiple Ad Server Flag`,
    Multiple_Ad_Server_ID as `Multiple Ad Server ID`,
    create_timestamp as `Create Timestamp`,
    modified_timestamp as `Modified Timestamp`
 from
    fox_bi_qa.gold_ad_sales.mv_ft_unified_campaign_geo_delivery
  )