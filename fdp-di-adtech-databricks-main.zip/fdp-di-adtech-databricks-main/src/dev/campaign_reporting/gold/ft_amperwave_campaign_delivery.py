# Databricks notebook source
catalog_name = dbutils.widgets.get('catalog_name')
silver_schema_name = dbutils.widgets.get('silver_schema_name')
gold_schema_name = dbutils.widgets.get('gold_schema_name')

# COMMAND ----------

query = f"""
    select 
        cam.event_date
       ,coalesce(cam.campaign_id, -1) as campaign_id
       ,coalesce(cam.creative_id, -1) as creative_id
       ,coalesce(op.sales_order_line_item_id, -1) as aos_deal_line_item_id
    
       ,coalesce(replace(cam.campaign_name, 'N/A', 'NA'), 'NA') as campaign_name
       ,coalesce(replace(cam.creative_name, 'N/A', 'NA'), 'NA') as creative_name
       ,case when cam.advertiser_name = '0' then 'NA'
             else coalesce(replace(cam.advertiser_name, 'N/A', 'NA'), 'NA')
        end as advertiser_name
       ,coalesce(replace(cam.agency_name, 'N/A', 'NA'), 'NA') as agency_name
       ,coalesce(replace(op.sales_order_line_item_name, 'N/A', 'NA'), 'NA') as aos_deal_line_item_name
       ,coalesce(replace(op.advertiser_name, 'N/A', 'NA'), 'NA') as advertiser_oms
       ,coalesce(replace(op.owner_name, 'N/A', 'NA'), 'NA') as account_manager
       ,coalesce(replace(op.package_name, 'N/A', 'NA'), 'NA') as package_name  

       ,cam.campaign_start_date
       ,cam.campaign_end_date
       ,coalesce(replace(cam.business_unit, 'N/A', 'NA'), 'NA') as business_unit 
        
       ,coalesce(sum(cam.delivered_impressions), 0) as delivered_impressions
       ,coalesce(sum(cam.delivered_clicks), 0) as delivered_clicks
       ,coalesce(sum(op.net_unit_cost_amt), 0.0) as net_unit_cost
       ,coalesce(sum(op.net_cost), 0.0) as guaranteed_revenue
       ,coalesce(sum(op.qty), 0.0) as guaranteed_impressions
       ,coalesce(sum(cam.uniques), 0) as uniques

       ,TO_DATE(DATE_FORMAT(CURRENT_TIMESTAMP(), 'yyyy-MM-dd'), 'yyyy-MM-dd') AS etl_load_date
       ,CURRENT_TIMESTAMP() AS etl_load_timestamp
    from {catalog_name}.{silver_schema_name}.ft_amperwave_campaign_delivery cam   
    left join fox_bi_prod.gold_ad_sales.ft_digital_operative_line_date_allocation op
        on op.ps_line_item_id = cam.campaign_id
        and op.date = cam.event_date
    group by all
"""

amperwave_campaign_delivery = spark.sql(query)

# COMMAND ----------

if not spark.catalog.tableExists(f'{catalog_name}.{gold_schema_name}.ft_amperwave_campaign_delivery'): #Add the table name for First time load 
    amperwave_campaign_delivery.write.format('delta')\
        .mode('overwrite')\
        .partitionBy('event_date')\
        .option('mergeSchema', 'true')\
        .option('overwriteDynamicPartitions', 'true')\
        .option('delta.enableDeletionVectors', 'false')\
        .option('delta.enableIcebergCompatV2', 'true')\
        .option('delta.universalFormat.enabledFormats', 'iceberg')\
        .option('delta.columnMapping.mode', 'name')\
        .saveAsTable(f"{catalog_name}.{gold_schema_name}.ft_amperwave_campaign_delivery")
else:
    amperwave_campaign_delivery.write.format('delta')\
        .mode('overwrite')\
        .option('partitionOverwriteMode', 'dynamic')\
        .saveAsTable(f"{catalog_name}.{gold_schema_name}.ft_amperwave_campaign_delivery")
