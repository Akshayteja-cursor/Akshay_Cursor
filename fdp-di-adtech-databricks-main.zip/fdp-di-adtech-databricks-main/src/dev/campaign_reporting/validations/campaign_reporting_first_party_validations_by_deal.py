# Databricks notebook source
# COMMAND ----------

spark.conf.set(
    "spark.databricks.remoteFiltering.blockSelfJoins",
    "false"
)
spark.conf.set(
    "spark.sql.execution.arrow.pyspark.enabled",
    "false"
)

# COMMAND ----------

global aws_profile, APPLICATION_NAME, NETWORK_CODE, cpe_s3_bucket

# COMMAND ----------

aws_profile=dbutils.widgets.get('aws_profile')
aws_arn=dbutils.widgets.get('aws_arn')
from_email=dbutils.widgets.get('from_email')

# COMMAND ----------

# make the variable available to shell
import os
os.environ["AWS_PROFILE_VAR"] = aws_profile
os.environ["AWS_ARN"] = aws_arn

# COMMAND ----------

# MAGIC %sh
# MAGIC aws configure set region us-west-2 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set s3.signature_version s3v4 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile $AWS_PROFILE_VAR
# MAGIC aws configure set role_arn $AWS_ARN --profile $AWS_PROFILE_VAR

# COMMAND ----------

from googleads import ad_manager, oauth2, errors
import boto3
import os
from datetime import datetime, timedelta
from dataclasses import dataclass
from typing import List, Optional, Any, cast
import json
import tempfile
from datetime import datetime, timedelta
import pytz
import time
import pandas as pd
from pyspark.sql import SparkSession
import pyspark.sql.types as T
import pyspark.sql.functions as F
from pyspark import SparkFiles
import io
from email import encoders
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from concurrent.futures import ThreadPoolExecutor, as_completed

# COMMAND ----------

aws_profile = f'{aws_profile}'
APPLICATION_NAME = 'Campaign Reporting - Validations'
NETWORK_CODE = 4145
cpe_s3_bucket = 'fox-fdp-bi-dev'
spark = SparkSession.builder.appName('Campaign Reporting - Validations').getOrCreate()
spark.conf.set("spark.sql.session.timeZone", "UTC")

# COMMAND ----------

def get_ad_manager_client(secret_arn: str) -> Any:
    session = boto3.Session(profile_name=aws_profile)
    resp = session.client('secretsmanager').get_secret_value(SecretId=secret_arn)
    secret = json.loads(resp['SecretString'])

    with tempfile.NamedTemporaryFile(mode='w', delete=False) as secret_file:
        json.dump(secret, secret_file, indent=2)
        secret_file.close()

    oauth2_client = oauth2.GoogleServiceAccountClient(secret_file.name, oauth2.GetAPIScope('ad_manager'))
    os.unlink(secret_file.name)
    ad_manager_client = ad_manager.AdManagerClient(oauth2_client, APPLICATION_NAME, NETWORK_CODE)

    return ad_manager_client

# COMMAND ----------

def format_datetime_to_obj(datetime_obj: Any) -> Any:
    obj = {}
    obj['year'] = datetime_obj.year
    obj['month'] = datetime_obj.month
    obj['day'] = datetime_obj.day
    return obj

def generate_processing_dates(start_date: datetime, end_date: datetime, step_size: int) -> list:
    processing_dates = []

    batch_start_date = start_date
    while batch_start_date <= end_date:
        batch_end_date = batch_start_date + timedelta(days=step_size - 1)
        if batch_end_date <= end_date:
            processing_dates.append((batch_start_date, batch_end_date))
        else:
            processing_dates.append((batch_start_date, end_date))
            break
        batch_start_date += timedelta(days=step_size)

    return processing_dates

def build_report_query(dimensions: list, columns: list, dimensionAttributes: list, start_date: datetime, end_date: datetime, filter: dict = None) -> Any:
    baseReportQuery = {
        'dimensions': [],
        'adUnitView': 'FLAT',
        'columns': [],
        'dimensionAttributes': [],
        'customFieldIds': [],
        'cmsMetadataKeyIds': [],
        'customDimensionKeyIds': [],
        'startDate': {},
        'endDate': {},
        'dateRangeType': 'CUSTOM_DATE',
        'statement': None,
        'reportCurrency': 'USD',
        'timeZoneType': 'PUBLISHER'
    }

    report_query = baseReportQuery
    report_query['dimensions'] = dimensions
    report_query['columns'] = columns
    report_query['dimensionAttributes'] = dimensionAttributes
    report_query['startDate'] = format_datetime_to_obj(start_date)
    report_query['endDate'] = format_datetime_to_obj(end_date)

    if filter:
        filter_field = next(iter(filter))
        filter_values = filter[filter_field]
        placeholders = [f':lin{i}' for i in range(len(filter_values))]
        report_query['statement'] = {
            'query': f'WHERE {filter_field} IN ({",".join(placeholders)})',
            'values': [
                {'key': f'lin{i}', 'value': {'xsi_type': 'TextValue', 'value': name}}
                for i, name in enumerate(filter_values)
            ]
        }

    return report_query


# COMMAND ----------

def format_report(report_data: Any, report_type: str) -> Any:
    if report_type == 'GAM Campaign Reporting Data Validation Report':
        format_columns = {
            'Dimension.ORDER_ID': ('order_id', T.LongType()),
            'Dimension.ORDER_NAME': ('order_name', T.StringType()),
            'Dimension.LINE_ITEM_ID': ('line_item_id', T.LongType()),
            'Dimension.LINE_ITEM_TYPE': ('line_item_type', T.StringType()),
            'Dimension.ADVERTISER_NAME': ('advertiser_name', T.StringType()),
            'DimensionAttribute.ORDER_END_DATE_TIME': ('order_end_date', T.TimestampType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS': ('total_impressions', T.LongType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_CLICKS': ('total_clicks', T.LongType()),
            'Column.VIDEO_VIEWERSHIP_START': ('video_views', T.LongType()),
            'Column.VIDEO_VIEWERSHIP_COMPLETE': ('video_completes', T.LongType())
        }
        select_cols = [
            'order_id',
            'order_name',
            'line_item_id',
            'line_item_type',
            'advertiser_name',
            'order_end_date',
            'total_impressions',
            'total_clicks',
            'video_views',
            'video_completes'
        ]

    for k, v in format_columns.items():
        report_data = report_data.withColumnRenamed(k, v[0])
        report_data = report_data.withColumn(v[0], F.col(v[0]).try_cast(v[1]))

    report_data = report_data.select(select_cols).dropDuplicates()

    return report_data

# COMMAND ----------

class NotebookData:
    #to run the notebooks in parallel 
    def __init__(self, path, timeout, parameters=None, retry=0):
        self.path = path
        self.timeout = timeout
        self.parameters = parameters
        self.retry = retry


    def submitNotebook(notebook):
        try:
            if (notebook.parameters):
                return dbutils.notebook.run(notebook.path, notebook.timeout, notebook.parameters)
            else:
                return dbutils.notebook.run(notebook.path, notebook.timeout)
        except Exception:
            raise SystemExit("Failed!")

#this function is to run noteboks in parallel
def parallelNotebooks(notebooks, numInParallel):
    with ThreadPoolExecutor(max_workers=numInParallel) as ec:
        return [ec.submit(NotebookData.submitNotebook, notebook) for notebook in notebooks]

# COMMAND ----------

def get_validation_status(validation_df):
    return True

# COMMAND ----------

if __name__ == '__main__':
    gam_service_account_creds_secret_arn = dbutils.widgets.get('gam_service_account_creds_secret_arn')
    gam_api_version = dbutils.widgets.get('gam_api_version')

    client = get_ad_manager_client(secret_arn=gam_service_account_creds_secret_arn)
    timezone = pytz.timezone("UTC")
    event_start_date = datetime.strptime('2024-01-01', '%Y-%m-%d').replace(tzinfo=timezone)
    event_end_date = datetime.today().replace(tzinfo=timezone) - timedelta(days=4)

    process_days = (event_end_date-event_start_date).days
    processing_dates = generate_processing_dates(event_start_date, event_end_date, 120)

    dev_catalog_name = dbutils.widgets.get('dev_catalog_name')
    qa_catalog_name = dbutils.widgets.get('qa_catalog_name')
    prod_catalog_name = dbutils.widgets.get('prod_catalog_name')
    cpe_s3_bucket = dbutils.widgets.get('cpe_s3_bucket')

    num_workers = int(dbutils.widgets.get('num_workers'))

    # GAM Campaign Reporting Data Validation Report
    print('Fetching GAM Campaign Reporting Source Data')
    for i, batch in enumerate(processing_dates):
        start_date, end_date = batch
        print(f"Processing {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}, batch - {i}", end=' ')
        report_service = client.GetService('ReportService', version=gam_api_version)
        report_query = build_report_query(
            dimensions = [
                'ORDER_ID',
                'ORDER_NAME',
                'LINE_ITEM_ID',
                'LINE_ITEM_TYPE',
                'ADVERTISER_NAME',
            ],
            columns = [
                'TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS',
                'TOTAL_LINE_ITEM_LEVEL_CLICKS',
                'VIDEO_VIEWERSHIP_START',
                'VIDEO_VIEWERSHIP_COMPLETE'
            ],
            dimensionAttributes = [
                'ORDER_END_DATE_TIME'
            ],
            start_date = start_date,
            end_date = end_date,
            filter = {
                'LINE_ITEM_TYPE': ['SPONSORSHIP', 'STANDARD', 'BULK']
            }
        )
        report_job = report_service.runReportJob({'reportQuery': report_query})

        while True:
            status = report_service.getReportJobStatus(report_job['id'])
            if status == 'COMPLETED':
                break
            elif status == 'FAILED':
                break
            else:
                time.sleep(7)

        if status == 'COMPLETED':
            print('Downloading...', end=' ')
            report_download_url = report_service.getReportDownloadURL(report_job['id'], 'CSV_DUMP')
            report_data = spark.createDataFrame(pd.read_csv(report_download_url, compression='gzip'))
            if i == 0:
                gam_source_data_df = format_report(report_data, 'GAM Campaign Reporting Data Validation Report')
            else:
                gam_source_data_df = gam_source_data_df.union(format_report(report_data, 'GAM Campaign Reporting Data Validation Report'))
            print('Completed')
        else:
            raise Exception('Report job failed')

    oms_source_query = f"""
        SELECT DISTINCT
            TRY_CAST(ps_line_item_id AS BIGINT) AS external_ad_id
            , TRY_CAST(sales_order_id AS BIGINT) AS aos_deal_id
            , order_end_dt AS deal_end_date
            , agency_name
            , net_unit_cost_amt AS net_unit_cost
        FROM {prod_catalog_name}.gold_ad_sales.ft_digital_operative_line_date_allocation
        WHERE sales_order_line_item_name NOT ILIKE '%cancelled%'
        AND ps_line_item_id IS NOT NULL
        AND TRY_CAST(ps_line_item_id AS BIGINT) IS NOT NULL
    """
    oms_source_df = spark.sql(oms_source_query)
    
    gam_source_df = gam_source_data_df.join(oms_source_df, (gam_source_data_df.line_item_id == oms_source_df.external_ad_id), how='left')

    gam_source_df = gam_source_df.fillna(0, subset=[
        'total_impressions',
        'total_clicks',
        'video_views',
        'video_completes',
        'net_unit_cost'
    ])

    gam_source_df = gam_source_df.fillna(-1, subset=[
        'aos_deal_id'
    ])

    gam_source_df = gam_source_df.fillna('N/A', subset=[
        'agency_name'
    ])

    gam_source_df.createOrReplaceTempView('gam_source_df')

    filtered_agg_gam_df_query = """
        WITH filtered AS (
            SELECT
                *
            FROM gam_source_df
            WHERE COALESCE(deal_end_date, order_end_date) BETWEEN DATE_TRUNC('month', ADD_MONTHS(CURRENT_DATE(), -3))::DATE AND CURRENT_DATE()
            AND (
                CASE
                    WHEN line_item_type = 'SPONSORSHIP' AND (advertiser_name IN (SELECT promo_advertiser_name FROM fox_bi_qa.silver_ad_sales.map_fnb_promo_advertiser) OR external_ad_id = '-1') 
                    THEN FALSE
                    ELSE TRUE
                END
            )
            AND (
                CASE
                    WHEN ((LOWER(advertiser_name) LIKE '%promo%') OR (LOWER(advertiser_name) LIKE '% test%')) THEN FALSE
                    WHEN ((LOWER(order_name) LIKE '%promo%') OR (LOWER(order_name) LIKE '% test%')) THEN FALSE
                    WHEN ((LOWER(agency_name) LIKE '%promo%') OR (LOWER(agency_name) LIKE '% test%')) THEN FALSE
                    ELSE TRUE
                END
            )
        ),
        agg_metrics AS (
            SELECT
                order_id
                , order_name
                , line_item_id
                , line_item_type
                , advertiser_name
                , order_end_date
                , SUM(total_impressions) AS total_impressions
                , SUM(total_clicks) AS total_clicks
                , SUM(video_views) AS video_views
                , SUM(video_completes) AS video_completes
                , CASE
                    WHEN line_item_type = 'SPONSORSHIP' THEN net_unit_cost
                    ELSE (SUM(total_impressions) * net_unit_cost) / 1000
                END AS total_revenue
                , external_ad_id
                , aos_deal_id
                , deal_end_date
                , agency_name
                , net_unit_cost
            FROM filtered
            GROUP BY ALL
        )
        SELECT
            'GAM' AS data_source
            , aos_deal_id
            , SUM(total_impressions) AS total_impressions
            , SUM(total_clicks) AS total_clicks
            , SUM(video_views) AS video_views
            , SUM(video_completes) AS video_completes
            , SUM(total_revenue) AS total_revenue
        FROM agg_metrics
        GROUP BY ALL
    """

    filtered_agg_gam_df = spark.sql(filtered_agg_gam_df_query)
    
    
    if not spark.catalog.tableExists(f'{dev_catalog_name}.bronze_ads.source_first_party_data_by_deal'): #Add the table name for First time load
        filtered_agg_gam_df.write.format('delta')\
            .mode('overwrite')\
            .partitionBy('data_source')\
            .option('mergeSchema', 'true')\
            .option('overwriteDynamicPartitions', 'true')\
            .option('delta.enableDeletionVectors', 'false')\
            .option('delta.enableIcebergCompatV2', 'true')\
            .option('delta.universalFormat.enabledFormats', 'iceberg')\
            .option('delta.columnMapping.mode', 'name')\
            .saveAsTable(f'{dev_catalog_name}.bronze_ads.source_first_party_data_by_deal')
    else:
        spark.sql(f'delete from {dev_catalog_name}.bronze_ads.source_first_party_data_by_deal')
        filtered_agg_gam_df.write.format('delta')\
            .mode('overwrite')\
            .option('partitionOverwriteMode', 'dynamic')\
            .saveAsTable(f'{dev_catalog_name}.bronze_ads.source_first_party_data_by_deal')
    
    # Freewheel Campaign Reporting Data
    print('Fetching Freewheel Campaign Reporting Source Data')
    freewheel_source_first_party_data_query = """
        WITH fw_data AS (
            SELECT
                campaign_id
                , placement_id
                , SUM(run_revenue_amount) AS Delivered_Revenue
                , SUM(net_counted_ads) AS delivered_impressions
                , SUM(delivered_clicks) AS delivered_clicks
            FROM fox_bi_qa.gold_ad_sales.ft_freewheel_delivery_daily
            WHERE (event_date BETWEEN '2024-01-01' AND CURRENT_DATE()
            AND sales_channel_type = 'Direct Sold'
            AND COALESCE(campaign_name,'N/A') NOT ILIKE '%promo%'
            AND COALESCE(agency_name,'N/A') NOT IN ('FNG IN-HOUSE MARKETING & PROMOTIONS')
            AND COALESCE(advertiser_name,'N/A') NOT ILIKE '%promo%'
            AND COALESCE(advertiser_name,'N/A') NOT IN ('Placeholder Advertiser')
            AND COALESCE(agency_name,'N/A') NOT IN ('Placeholder Agency')
            ) OR campaign_id IN (86484377)
            GROUP BY
                campaign_id
                , placement_id
        ),
        op1 AS (
            SELECT
                TRY_CAST(ps_line_item_id AS BIGINT) AS line_item_id
                , TRY_CAST(sales_order_id AS BIGINT) AS aos_deal_id
            FROM fox_bi_prod.gold_ad_sales.ft_digital_operative_line_date_allocation
            WHERE sales_order_line_item_name NOT ILIKE '%cancelled%'
            and order_end_dt BETWEEN DATE_TRUNC('month', ADD_MONTHS(CURRENT_DATE(), -3))::DATE AND CURRENT_DATE()
            
            GROUP BY ALL
        )
        SELECT
            'FREEWHEEL' AS data_source
            , aos_deal_id
            , SUM(delivered_impressions) AS total_impressions
            , SUM(delivered_clicks) AS total_clicks
            , CAST(0 AS BIGINT) AS video_views
            , CAST(0 AS BIGINT) AS video_completes
            , SUM(delivered_revenue) AS total_revenue
        FROM fw_data
        JOIN op1
        ON fw_data.placement_id = op1.line_item_id
        GROUP BY aos_deal_id
    """

    freewheel_source_df = spark.sql(freewheel_source_first_party_data_query)
    freewheel_source_df = freewheel_source_df.withColumn('data_source', F.lit('FREEWHEEL').cast(T.StringType()))
    if not spark.catalog.tableExists(f'{dev_catalog_name}.bronze_ads.source_first_party_data_by_deal'): #Add the table name for First time load
        freewheel_source_df.write.format('delta')\
            .mode('overwrite')\
            .partitionBy('data_source')\
            .option('mergeSchema', 'true')\
            .option('overwriteDynamicPartitions', 'true')\
            .option('delta.enableDeletionVectors', 'false')\
            .option('delta.enableIcebergCompatV2', 'true')\
            .option('delta.universalFormat.enabledFormats', 'iceberg')\
            .option('delta.columnMapping.mode', 'name')\
            .saveAsTable(f'{dev_catalog_name}.bronze_ads.source_first_party_data_by_deal')
    else:
        freewheel_source_df.write.format('delta')\
            .mode('overwrite')\
            .option('partitionOverwriteMode', 'dynamic')\
            .saveAsTable(f'{dev_catalog_name}.bronze_ads.source_first_party_data_by_deal')

    # Validate the source deal level data with the campaign reporting unified deal level data
    print('Validating the source deal level data with the campaign reporting unified deal level data')
    target_df_query = f"""
        SELECT
            `AOS Deal ID` AS aos_deal_id
            , `Total Delivered Impressions` AS total_impressions_view
            , `Total Delivered Clicks` AS total_clicks_view
            , `Total Views` AS total_video_views_view
            , `Total Delivered Revenue` AS total_revenue_view
            , CAST(`CPM` AS DOUBLE) AS cpm_view
            , CAST(`CTR` AS DOUBLE) AS ctr_view
        FROM {qa_catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal
        WHERE `AOS Deal ID` != -1
        AND (`Total Delivered Impressions` > 0 OR `Total Delivered Clicks` > 0 OR `Total Views` > 0 OR `Total Delivered Revenue` > 0)
    """
    target_df = spark.sql(target_df_query)
    target_df = target_df.fillna(0, subset=[
        'total_impressions_view',
        'total_clicks_view',
        'total_video_views_view',
        'total_revenue_view',
        'cpm_view',
        'ctr_view'
    ])

    source_df_query = f"""
        SELECT
            aos_deal_id
            , SUM(total_impressions) AS total_impressions_source
            , SUM(total_clicks) AS total_clicks_source
            , SUM(video_views) AS total_video_views_source
            , SUM(total_revenue) AS total_revenue_source
            , CASE
                WHEN SUM(total_impressions) = 0 THEN 0
                ELSE (SUM(total_revenue) * 1000) / SUM(total_impressions)
            END::double AS cpm_source
            , CASE
                WHEN SUM(total_impressions) = 0 THEN 0
                ELSE (SUM(total_clicks) / SUM(total_impressions)) * 100
            END::double AS ctr_source
        FROM {dev_catalog_name}.bronze_ads.source_first_party_data_by_deal
        WHERE aos_deal_id != -1
        GROUP BY aos_deal_id
    """

    source_df = spark.sql(source_df_query)

    validation_df = source_df.join(target_df, on=['aos_deal_id'], how='full_outer')

    pairs = [
        ("total_impressions_source", "total_impressions_view", "Total Impressions Variance %"),
        ("total_clicks_source", "total_clicks_view", "Total Clicks Variance %"),
        ("total_video_views_source", "total_video_views_view", "Total Video Views Variance %"),
        ("total_revenue_source", "total_revenue_view", "Total Revenue Variance %"),
        ("cpm_source", "cpm_view", "CPM Variance"),
        ("ctr_source", "ctr_view", "CTR Variance")
    ]

    print('Performing campaign reporting source vs view validtions')
    for source_col, view_col, out_col in pairs:
        if '%' in out_col:
            validation_df = validation_df.withColumn(out_col,\
                F.when(F.col(source_col) == 0, F.col(view_col))\
                .otherwise(F.round((F.col(source_col) - F.col(view_col))/F.col(source_col)*100, 3))
            )
        else:
            validation_df = validation_df.withColumn(out_col,\
                F.when(F.col(source_col) == 0, F.col(view_col))\
                .otherwise(F.round(F.col(source_col) - F.col(view_col), 3))
            )

    validation_df = validation_df.select([
        'aos_deal_id', 'total_impressions_source', 'total_impressions_view', 'total_clicks_source', 'total_clicks_view', 'total_video_views_source', 'total_video_views_view', 'total_revenue_source', 'total_revenue_view', 'cpm_source', 'cpm_view', 'ctr_source', 'ctr_view', 'Total Impressions Variance %', 'Total Clicks Variance %', 'Total Video Views Variance %', 'Total Revenue Variance %', 'CPM Variance', 'CTR Variance'
    ])
    validation_df = validation_df.withColumn('updated_timestamp', F.lit(F.current_timestamp()))
    print('Campaign summary validtions completed')
    if not spark.catalog.tableExists(f'{dev_catalog_name}.bronze_ads.campaign_reporting_first_party_validations'): #Add the table name for First time load
        validation_df.write.format('delta')\
            .mode('overwrite')\
            .partitionBy('aos_deal_id')\
            .option('mergeSchema', 'true')\
            .option('overwriteDynamicPartitions', 'true')\
            .option('delta.enableDeletionVectors', 'false')\
            .option('delta.enableIcebergCompatV2', 'true')\
            .option('delta.universalFormat.enabledFormats', 'iceberg')\
            .option('delta.columnMapping.mode', 'name')\
            .saveAsTable(f'{dev_catalog_name}.bronze_ads.campaign_reporting_first_party_validations')
    else:
        spark.sql(f'delete from {dev_catalog_name}.bronze_ads.campaign_reporting_first_party_validations')
        validation_df.write.format('delta')\
            .mode('overwrite')\
            .option('partitionOverwriteMode', 'dynamic')\
            .saveAsTable(f'{dev_catalog_name}.bronze_ads.campaign_reporting_first_party_validations')


    """
        # TODO:
            1. Add a mechanism to pass or fail the validations
            2. Write the output of step 1 to dbutils.task values
    """

    validation_status = get_validation_status(validation_df)
    dbutils.jobs.taskValues.set(key = "validation_status", value = str(validation_status))

    print('Validation Status:', 'Pass' if validation_status else 'Fail')