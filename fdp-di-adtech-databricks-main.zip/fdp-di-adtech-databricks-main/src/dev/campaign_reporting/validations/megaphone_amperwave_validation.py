# Databricks notebook source
# Megaphone Amperwave Validation
# This notebook validates campaign delivery data by comparing third-party (DoubleVerify Adjuster) 
# data against internal gold views for both Megaphone and Amperwave platforms.
# It downloads reports from DoubleVerify API, compares metrics, and sends validation reports via email.

# COMMAND ----------

aws_profile=dbutils.widgets.get('aws_profile')
aws_arn=dbutils.widgets.get('aws_arn')
catalog_name = dbutils.widgets.get('catalog_name')
gold_schema_name = dbutils.widgets.get('gold_schema_name')

# COMMAND ----------

# make the variable available to shell
import os
os.environ["AWS_PROFILE_VAR"] = aws_profile
os.environ["AWS_ARN"] = aws_arn

# COMMAND ----------

# MAGIC %sh
# MAGIC aws configure set region us-west-2 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set s3.signature_version s3v4 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile $AWS_PROFILE_VAR
# MAGIC aws configure set role_arn $AWS_ARN --profile $AWS_PROFILE_VAR

# COMMAND ----------

# Import required libraries
from typing import Any
import json
import time
from datetime import datetime
from dataclasses import dataclass
import requests
import boto3
import pyspark.sql.functions as F

import os
import sys
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from datetime import datetime, date,timedelta
import pandas as pd
import argparse
import requests
import json
import logging

# Track execution start time for performance monitoring
st_time=datetime.now()

# COMMAND ----------

# Email configuration for validation report notifications
from_email = 'adsales.dev@data.fox'
to_email = ["noormahammad.nalband@fox.com", ]
fail_email = []
cc_email = []

# COMMAND ----------

# MAGIC %sh
# MAGIC aws configure set region us-west-2 --profile databricks-fng-prod
# MAGIC aws configure set s3.signature_version s3v4 --profile databricks-fng-prod
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile databricks-fng-prod
# MAGIC aws configure set role_arn arn:aws:iam::640862407089:role/fng-dmo-prod-databricks-ec2-role --profile databricks-fng-prod

# COMMAND ----------

class cls_ssm(object):
    def __init__(self, aws_profile='default'):    
        import boto3
        try:
            session = boto3.Session(profile_name = aws_profile)
            client = session.client('ssm')

            self.client=client
            self.aws_profile=aws_profile

        except Exception as e:
            raise Exception('ERROR: '+ str(e))
        
    def get_ssm_param_by_path(self, path, full_path_dict_key=False, next_token=' ', keyvalue_dict={}) :
        # Get all values for all keys from SSM Path as Dictionary
        try:
            #-----------------------------------------------------------------------------------------------------------
            # To reset the keyvalue_dict we need to have below code , if we remove it is having trace of previous calls
            #-----------------------------------------------------------------------------------------------------------
            if next_token==' ':
                keyvalue_dict={}
                response  = self.client.get_parameters_by_path(Path=path, WithDecryption=True, Recursive=True)
            else:
                response  = self.client.get_parameters_by_path(Path=path, NextToken=next_token, WithDecryption=True, Recursive=True)

            for parameter in response['Parameters'] :

                if full_path_dict_key:
                    key = parameter['Name']
                else:
                    key = parameter['Name'].split('/')[-1]

                keyvalue_dict[key] = parameter['Value']
            #---------------------------------------------------------------------------------------------------------------
            # if there is more than 10 param in same path we need to paginate through next sets using next token from response
            #--------------------------------------------------------------------------------------------------------------
            if 'NextToken' in response.keys():
                next_token = response['NextToken']
                keyvalue_dict = self.get_ssm_param_by_path(path, full_path_dict_key, next_token, keyvalue_dict)

            if keyvalue_dict=={}:
                value = self.client.get_parameter(Name = path, WithDecryption = True)['Parameter']['Value']

                if full_path_dict_key:
                    key = path
                else:
                    key = path.split('/')[-1]

                keyvalue_dict[key]=value

            #print(keyvalue_dict)
            return keyvalue_dict
        except Exception as e:
            raise Exception('ERROR: '+ str(e))


# COMMAND ----------

# MAGIC %md
# MAGIC ###Source Data

# COMMAND ----------

# Data class to store DoubleVerify Adjuster API credentials
# Credentials are retrieved from AWS Secrets Manager
@dataclass
class AdjusterCredentials:
    public_key: str
    private_key: str

    @classmethod
    def from_secret(cls, secret_arn: str) -> 'AdjusterCredentials':
        try:
            session = boto3.Session(profile_name=aws_profile)
            resp = session.client('secretsmanager').get_secret_value(SecretId=secret_arn)
            secret = json.loads(resp['SecretString'])
            ajuster_creds_cls = cls(public_key=secret['public_key'], private_key=secret['private_key'])
            return ajuster_creds_cls
        except:
            raise Exception(f'Could not load Adjuster credentials from secret {secret_arn}')

# COMMAND ----------

# Downloads a report from DoubleVerify Adjuster API and uploads it to S3
# This function handles the full workflow: triggering report generation, 
# polling for completion, and downloading the final report
def download_report_to_s3(adjuster_credentials: AdjusterCredentials, report_name: str, report_date: datetime) -> str:
    # Report IDs from Ad-juster API:
    # https://pub.doubleverify.com/campaign-delivery/adjuster-api/reports
    reports_to_id = {
        'megaphone_amperware':37356,
    }
    report_id = reports_to_id[report_name]

    # Trigger report generation via API
    report_run = f'https://pub.doubleverify.com/campaign-delivery/adjuster-api/reports/run/{report_id}?email=false'
    report_run_r = requests.get(report_run, auth=(adjuster_credentials.public_key, adjuster_credentials.private_key))
    if report_run_r.status_code != 200:
        raise requests.HTTPError(
            report_run_r.status_code,
            'Report could not be run',
            report_name,
        )
    
    # Wait for completion or failure
    report_run_status = -1
    while report_run_status != 3:
        report_status = f'https://pub.doubleverify.com/campaign-delivery/adjuster-api/reports/runs/{report_id}?count=1'
        report_status_r = requests.get(report_status, auth=(adjuster_credentials.public_key, adjuster_credentials.private_key))
        content = report_status_r.content.decode('utf8')
        print(f'report status = {content}')
        for report in report_status_r.json()['data']:
            report_run_id = report['runId']
            report_run_status = report['status']
        if report_run_status not in {0, 1, 3}:
            # 0 = queued/triggered/requested
            # 1 = running
            # 3 = completed
            raise requests.HTTPError(
                report_run_status,
                'Report failed to complete run',
                report_name,
            )
        if report_run_status != 3:
            # Poll every 40 seconds until report completes
            time.sleep(40)

    # Download completed report and upload to S3
    reports_to_key = {
        'megaphone_amperware': 'Megaphone_Amperware_Daily_Validation',
    }
    report_s3_pfx = 'adtech/adjuster/'
    report_name_base = reports_to_key[report_name]

    report_dl = f'https://pub.doubleverify.com/campaign-delivery/adjuster-api/reports/download/{report_run_id}'
    report_dl_r = requests.get(report_dl, auth=(adjuster_credentials.public_key, adjuster_credentials.private_key))

    s3_key = report_s3_pfx + report_name_base + report_date.strftime('_%Y%m%d') + '.csv.gz'

    session = boto3.Session(profile_name=aws_profile)
    s3_client = session.client('s3')
    s3_client.put_object(
        Bucket=s3_bucket,
        Body=report_dl_r.content,
        Key=s3_key,
    )
    return s3_key

# COMMAND ----------

# Main execution block: Download and process third-party validation data
if __name__ == '__main__':
    date = dbutils.widgets.get('date')
    global s3_bucket, aws_profile
    s3_bucket = dbutils.widgets.get('s3_bucket')
    aws_profile = dbutils.widgets.get('aws_profile')
    adjuster_credentials_secret_arn = dbutils.widgets.get('adjuster_credentials_secret_arn')

    REPORT_CHOICES = [
        'megaphone_amperware',
    ]

    # Try to get report name from widget, otherwise default to megaphone_amperware
    try:
        assert dbutils.widgets.get('report') in REPORT_CHOICES, "Invalid report, should be one of {}".format(REPORT_CHOICES)
        reports = [dbutils.widgets.get('report')]
    except:
        reports = ['megaphone_amperware',]

    # Validate date format (YYYY-MM-DD)
    def parse_date(date: str) -> bool:
        format = "%Y-%m-%d"
        try:
            res = bool(datetime.strptime(date, format))
        except ValueError:
            res = False
        return res

    assert parse_date(date), "Invalid date format, should be in YYYY-MM-DD format"
    assert adjuster_credentials_secret_arn != '', "Invalid adjuster_credentials_secret_arn"

    # Fetch Adjuster API Credentials from AWS Secrets Manager
    adjuster_credentials = AdjusterCredentials.from_secret(adjuster_credentials_secret_arn)

    # Download report from DoubleVerify API and process the data
    for report in reports:
        s3_key = download_report_to_s3(adjuster_credentials, report, datetime.strptime(date, "%Y-%m-%d"))
        print('File downloaded. File path: ', s3_key)

        # Read CSV file from S3 mount (skip first 8 rows which contain header/metadata)
        mount_path = f'/mnt/{s3_bucket}/'
        df = spark.read.format('csv').option('header', 'true').option('inferSchema', 'false').load(f'{mount_path}/{s3_key}', skipRows=8)

        # Transform date column and add timestamp
        df = df.withColumn('event_date', F.to_date(F.col('Report End Date'), 'MM/dd/yyyy'))
        df = df.withColumn('created_timestamp', F.current_timestamp())
        src_df = df
        #display(src_df)

# COMMAND ----------

# Process source data: Filter and aggregate Amperwave data from DoubleVerify report
# Remove commas from numeric fields, convert to integers, and aggregate by date
src_amperwave_df = src_df.filter(F.col('Local Server Name') == 'Amperwave') \
    .withColumn('event_date', F.to_date(F.col('event_date'))) \
    .withColumnRenamed('Local Server Name', 'local_server_name') \
    .withColumn('Impressions_int', F.regexp_replace(F.col('Impressions'), ',', '').cast('int')) \
    .withColumn('Clicks_int', F.regexp_replace(F.col('Clicks'), ',', '').cast('bigint')) \
    .groupBy('event_date', 'local_server_name') \
    .agg(
        F.coalesce(F.sum('Impressions_int'), F.lit(0)).alias('third_party_impressions'),
        F.coalesce(F.sum('Clicks_int'), F.lit(0)).alias('third_party_clicks')
    ) \
    .withColumnRenamed('event_date', 'src_event_date')

# Process source data: Filter and aggregate Megaphone data from DoubleVerify report
src_megaphone_df = src_df.filter(F.col('Local Server Name') == 'Megaphone') \
    .withColumn('event_date', F.to_date(F.col('event_date'))) \
    .withColumnRenamed('Local Server Name', 'local_server_name') \
    .withColumn('Impressions_int', F.regexp_replace(F.col('Impressions'), ',', '').cast('int')) \
    .withColumn('Clicks_int', F.regexp_replace(F.col('Clicks'), ',', '').cast('bigint')) \
    .groupBy('event_date', 'local_server_name') \
    .agg(
        F.coalesce(F.sum('Impressions_int'), F.lit(0)).alias('third_party_impressions'),
        F.coalesce(F.sum('Clicks_int'), F.lit(0)).alias('third_party_clicks')
    ) \
    .withColumnRenamed('event_date', 'src_event_date')

display(src_amperwave_df)
display(src_megaphone_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Target Data

# COMMAND ----------

# Retrieve target data from gold views: Amperwave campaign delivery metrics
# Data is aggregated by event date for the last 7 days
tar_amperwave_df = spark.sql(
  f"""
  SELECT
    `Event Date` AS tar_event_date,
    coalesce(SUM(`Delivered Impressions`),0) AS gold_impressions,
    coalesce(SUM(`Delivered Clicks`),0) AS gold_clicks
  FROM
    {catalog_name}.{gold_schema_name}.v_ft_amperwave_campaign_delivery
  WHERE
    `Event Date`>=current_date()-6
  GROUP BY
    `Event Date`
  """)
display(tar_amperwave_df)

# Retrieve target data from gold views: Megaphone campaign delivery metrics
tar_megaphone_df = spark.sql(
  f"""
  SELECT
    `Event Date` AS tar_event_date,
    coalesce(SUM(`Delivered Impressions`),0) AS gold_impressions,
    coalesce(SUM(`Delivered Clicks`),0) AS gold_clicks
  FROM
    {catalog_name}.{gold_schema_name}.v_ft_megaphone_campaign_delivery
  WHERE
    `Event Date`>=current_date()-6
  GROUP BY
    `Event Date`
  """)
display(tar_megaphone_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Validation

# COMMAND ----------

# Compare third-party source data with internal gold view data
# Calculates variance percentages and flags discrepancies
# Variance threshold: >5% difference triggers a 'Variance' comment
def compare_data(src_df, tar_df):
    # Left join source and target dataframes on event_date
    joined_df = src_df.join(
        tar_df,
        src_df.src_event_date == tar_df.tar_event_date,
        how='left'
    )

    # Calculate variance percentage for impressions
    # Formula: ((third_party - gold) / gold) * 100
    # If gold is null, variance is set to 100% (missing data)
    compared_df = joined_df.withColumn(
        'impressions_variance_pct',
        F.when(
            F.col('gold_impressions').isNull(),
            F.lit(100.0)
        ).when(
            F.col('third_party_impressions').isNotNull() & F.col('gold_impressions').isNotNull(),
            (F.col('third_party_impressions') - F.col('gold_impressions')) / F.col('gold_impressions') * 100
        ).otherwise(None)
    ).withColumn(
        # Calculate variance percentage for clicks
        'clicks_variance_pct',
        F.when(
            F.col('gold_clicks').isNull(),
            F.lit(100.0)
        ).when(
            F.col('third_party_clicks').isNotNull() & F.col('gold_clicks').isNotNull() & (F.col('gold_clicks') != 0),
            (F.col('third_party_clicks') - F.col('gold_clicks')) / F.col('gold_clicks') * 100
        ).otherwise(None)
    )

    # Select relevant columns for comparison
    compared_df = compared_df.select('src_event_date', 'local_server_name', 'third_party_impressions','third_party_clicks','gold_impressions','gold_clicks','impressions_variance_pct','clicks_variance_pct')

    # Add comment column to flag issues:
    # - 'Missing Date': No data in gold view for this date
    # - 'Variance': Variance exceeds 5% threshold for impressions or clicks
    # - '-': No issues detected
    compared_df = compared_df.withColumn('Comment', 
            F.when(F.col('gold_impressions').isNull() | F.col('gold_clicks').isNull(), 'Missing Date')
             .when((F.abs(F.col('impressions_variance_pct')) > 5) | (F.abs(F.col('clicks_variance_pct')) > 5) 
                    & (F.col('gold_impressions').isNotNull() & F.col('gold_clicks').isNotNull()), 'Variance')
             .otherwise('-')
            )

    # Convert all columns to string for Excel export and order by date
    compared_df= compared_df.select([
    F.coalesce(F.col(c).cast('string'), F.lit('0')).alias(c) for c in compared_df.columns]).orderBy('src_event_date')

    # Filter to only show rows with issues (non-dash comments)
    final_df = compared_df.filter(F.col('Comment') != '-')

    return final_df, compared_df

final_amperwave_variance_df, amperwave_compared_df = compare_data(src_amperwave_df, tar_amperwave_df)
display(final_amperwave_variance_df)

final_megaphone_variance_df, megaphone_compared_df = compare_data(src_megaphone_df, tar_megaphone_df)
display(final_megaphone_variance_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Mail Service

# COMMAND ----------

# Generate Excel report and send email notification
import os
from datetime import date
import pandas as pd

# Set up file paths and directory structure for Excel export
today = date.today()
formatted_date = today.strftime("%m-%d-%Y")

current_directory = os.getcwd()
relative_path = 'Tableau_output/'

PREVIEW_FOLDER_LOCATION = os.path.join(current_directory, relative_path)

# Ensure the directory exists
if not os.path.exists(PREVIEW_FOLDER_LOCATION):
    os.makedirs(PREVIEW_FOLDER_LOCATION)

final_name=f'megaphone_amperwave_validation - {formatted_date}.xlsx'

file_path = PREVIEW_FOLDER_LOCATION + final_name
# Remove existing file if it exists
try:
    if os.path.isfile(file_path):
        os.remove(file_path)
except Exception as e:
    print(f"Error deleting file: {e}")

# Create Excel writer for multi-sheet workbook
writer = pd.ExcelWriter(file_path, engine='xlsxwriter')

# Write Amperwave comparison data to Excel sheet with auto-sized columns
res_df = amperwave_compared_df.toPandas()
res_df.to_excel(writer, index=False, sheet_name='Amperwave')
workbook = writer.book
worksheet = writer.sheets['Amperwave']
for i, col in enumerate(res_df.columns):
    width = max(res_df[col].apply(lambda x: len(str(x))).max(), len(col))
    worksheet.set_column(i, i, width)

# Write Megaphone comparison data to Excel sheet with auto-sized columns
res_df = megaphone_compared_df.toPandas()
res_df.to_excel(writer, index=False, sheet_name='Megaphone')
workbook = writer.book
worksheet = writer.sheets['Megaphone']
for i, col in enumerate(res_df.columns):
    width = max(res_df[col].apply(lambda x: len(str(x))).max(), len(col))
    worksheet.set_column(i, i, width)

writer.close()

print(file_path)

# COMMAND ----------

# Convert DataFrame to HTML table format for email body
def table_format(df):
    wh_data = "<tr>"
    ky = ''
    for i in df.columns:
        ky += f'<th style="color:white; background-color:#104985; font-weight:400;">{i}</th>'
    t1 = wh_data + ky + '</tr>'

    for j in range(len(df)):
        td = ''
        for k in df.columns:
            td += f'<td>{df.iloc[j][k]}</td>'
        t1 += wh_data + td + '</tr>'

    return t1
amp_diff=table_format(final_amperwave_variance_df.toPandas())
mega_diff=table_format(final_megaphone_variance_df.toPandas())


# COMMAND ----------

if src_amperwave_df.count()==0 and src_megaphone_df.count()==0:
    src_df_null = 'There is no data flowing from Amperwave and Megaphone for last five days.'
elif src_amperwave_df.count()==0 :
    src_df_null = 'There is no data flowing from Amperwave for last five days.'
elif src_megaphone_df.count()==0 :
    src_df_null = 'There is no data flowing from Megaphone for last five days.'
else:
    src_df_null = ''

# COMMAND ----------

# Send validation report email with Excel attachment
# Email content varies based on which platforms have variances detected
def send_opendeals_report(final_file_path, environment):
    # Case 1: Both Amperwave and Megaphone have variances
    if final_amperwave_variance_df.count()>0 and final_megaphone_variance_df.count()>0:
        html = f'''
            <html>
                <body>
                    <p><b><u>Megaphone_Amperwave_Validation:</u></b></p>
                    <p><b>Below table contains the mismatch of double verify and FoxAi views for Amperwave and Megaphone</b></p>
                    <p><b><u>{src_df_null}</u></b></p>
                    <table border=1>{amp_diff}</table>
                    
                    <table border=1>{mega_diff}</table>
                    <p>Please note that this is an auto-generated validation report. If you have any questions, please reach out to SRE_Data_Platform@fox.com</p>
                    <p>Best Regards,<br>
                    Data Ops Support Team</p>
                </body>
            </html>
            '''
    elif final_amperwave_variance_df.count()>0:
        html = f'''
            <html>
                <body>
                    <p><b><u>Megaphone_Amperwave_Validation:</u></b></p>
                    <p><b>Below table contains the mismatch of double verify and FoxAi views for Amperwave</b></p>
                    <p><b><u>{src_df_null}</u></b></p>
                    <table border=1>{amp_diff}</table>
                    
                    <p>Please note that this is an auto-generated validation report. If you have any questions, please reach out to SRE_Data_Platform@fox.com</p>
                    <p>Best Regards,<br>
                    Data Ops Support Team</p>
                </body>
            </html>
            '''
    elif final_megaphone_variance_df.count()>0:
        html = f'''
            <html>
                <body>
                    <p><b><u>Megaphone_Amperwave_Validation:</u></b></p>
                    <p><b>Below table contains the mismatch of double verify and FoxAi views for Megaphone</b></p>
                    <p><b><u>{src_df_null}</u></b></p>
                    <table border=1>{mega_diff}</table>
                    
                    <p>Please note that this is an auto-generated validation report. If you have any questions, please reach out to SRE_Data_Platform@fox.com</p>
                    <p>Best Regards,<br>
                    Data Ops Support Team</p>
                </body>
            </html>
            '''
    else:
        html = f'''
            <html>
                <body>
                    <p><b><u>Megaphone_Amperwave_Validation:</u></b></p>
                    <p><b><u>{src_df_null}</u></b></p>
                    <p><b>No Mismatch between double verify and FoxAi views</b></p>

                    <p>Please note that this is an auto-generated validation report. If you have any questions, please reach out to SRE_Data_Platform@fox.com</p>
                    <p>Best Regards,<br>
                    Data Ops Support Team</p>
                </body>
            </html>
            '''
    # Helper function to attach Excel file to email
    def attach_file_to_email(email_message, filename):
        with open(filename, "rb") as f:
            file_attachment = MIMEApplication(f.read())
        file_attachment.add_header(
            "Content-Disposition",
            f'attachment; filename= "{final_name}"',
        )

        email_message.attach(file_attachment)

    # Create email message with HTML body and Excel attachment
    email_message = MIMEMultipart()
    email_message['From'] = from_email
    # email_message['To'] = email_to
    if True:
        email_message['To'] = ', '.join(to_email)
        email_message['Cc'] = ', '.join(cc_email)
        send_to=to_email+cc_email
    else:
        email_message['To'] = ', '.join(fail_email)
        email_message['Cc'] = ', '.join(cc_email)
        send_to=to_email+cc_email
    email_message['Subject'] = (f"{environment} - Megaphone_Amperwave_Validation: {formatted_date}")

    # Attach the html doc defined earlier, as a MIMEText html content type to the MIME message
    email_message.attach(MIMEText(html, "html"))

    attach_file_to_email(email_message, final_file_path)

    # Convert email message to string format
    email_string = email_message.as_string()
    
    # Send email via AWS SES (Simple Email Service)
    import boto3
    session = boto3.Session(profile_name = aws_profile)
    ses = session.client('ses', region_name='us-west-2')
    
    ses.send_raw_email(
      Source=from_email,
      Destinations=send_to,
      RawMessage={'Data': email_string})
    print("Sent all the Emails!")

# Set environment for email subject line
environment = 'Dev'

final_file_path = file_path

# Only send emails on weekdays (Monday-Friday), skip weekends
if (datetime.now().isoweekday()) not in (6,7):
    send_opendeals_report(final_file_path, environment)
else:
    print('Saturday and Sunday, No mails required.')
# Print total execution time
print(datetime.now()-st_time)
