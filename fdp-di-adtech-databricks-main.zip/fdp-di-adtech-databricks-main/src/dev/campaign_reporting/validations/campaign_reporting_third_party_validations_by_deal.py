# Databricks notebook source

# COMMAND ----------

spark.conf.set(
    "spark.databricks.remoteFiltering.blockSelfJoins",
    "false"
)
spark.conf.set(
    "spark.sql.execution.arrow.pyspark.enabled",
    "false"
)

# COMMAND ----------

global aws_profile, APPLICATION_NAME, NETWORK_CODE, cpe_s3_bucket

# COMMAND ----------

aws_profile=dbutils.widgets.get('aws_profile')
aws_arn=dbutils.widgets.get('aws_arn')
from_email=dbutils.widgets.get('from_email')

# COMMAND ----------

# make the variable available to shell
import os
os.environ["AWS_PROFILE_VAR"] = aws_profile
os.environ["AWS_ARN"] = aws_arn

# COMMAND ----------

# MAGIC %sh
# MAGIC aws configure set region us-west-2 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set s3.signature_version s3v4 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile $AWS_PROFILE_VAR
# MAGIC aws configure set role_arn $AWS_ARN --profile $AWS_PROFILE_VAR

# COMMAND ----------

from googleads import ad_manager, oauth2, errors
import boto3
import os
from datetime import datetime, timedelta
from dataclasses import dataclass
from typing import List, Optional, Any, cast
import json
import tempfile
from datetime import datetime, timedelta
import pytz
import time
import pandas as pd
from pyspark.sql import SparkSession
import pyspark.sql.types as T
import pyspark.sql.functions as F
from pyspark import SparkFiles
import io
from email import encoders
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from concurrent.futures import ThreadPoolExecutor, as_completed

# COMMAND ----------

aws_profile = f'{aws_profile}'
APPLICATION_NAME = 'Campaign Reporting - Validations'
NETWORK_CODE = 4145
cpe_s3_bucket = 'fox-fdp-bi-dev'
spark = SparkSession.builder.appName('Campaign Reporting - Validations').getOrCreate()
spark.conf.set("spark.sql.session.timeZone", "UTC")

# COMMAND ----------

def get_ad_manager_client(secret_arn: str) -> Any:
    session = boto3.Session(profile_name=aws_profile)
    resp = session.client('secretsmanager').get_secret_value(SecretId=secret_arn)
    secret = json.loads(resp['SecretString'])

    with tempfile.NamedTemporaryFile(mode='w', delete=False) as secret_file:
        json.dump(secret, secret_file, indent=2)
        secret_file.close()

    oauth2_client = oauth2.GoogleServiceAccountClient(secret_file.name, oauth2.GetAPIScope('ad_manager'))
    os.unlink(secret_file.name)
    ad_manager_client = ad_manager.AdManagerClient(oauth2_client, APPLICATION_NAME, NETWORK_CODE)

    return ad_manager_client

# COMMAND ----------

def format_datetime_to_obj(datetime_obj: Any) -> Any:
    obj = {}
    obj['year'] = datetime_obj.year
    obj['month'] = datetime_obj.month
    obj['day'] = datetime_obj.day
    return obj

def generate_processing_dates(start_date: datetime, end_date: datetime, step_size: int) -> list:
    processing_dates = []

    batch_start_date = start_date
    while batch_start_date <= end_date:
        batch_end_date = batch_start_date + timedelta(days=step_size - 1)
        if batch_end_date <= end_date:
            processing_dates.append((batch_start_date, batch_end_date))
        else:
            processing_dates.append((batch_start_date, end_date))
            break
        batch_start_date += timedelta(days=step_size)

    return processing_dates

def build_report_query(dimensions: list, columns: list, dimensionAttributes: list, start_date: datetime, end_date: datetime, filter: dict = None) -> Any:
    baseReportQuery = {
        'dimensions': [],
        'adUnitView': 'FLAT',
        'columns': [],
        'dimensionAttributes': [],
        'customFieldIds': [],
        'cmsMetadataKeyIds': [],
        'customDimensionKeyIds': [],
        'startDate': {},
        'endDate': {},
        'dateRangeType': 'CUSTOM_DATE',
        'statement': None,
        'reportCurrency': 'USD',
        'timeZoneType': 'PUBLISHER'
    }

    report_query = baseReportQuery
    report_query['dimensions'] = dimensions
    report_query['columns'] = columns
    report_query['dimensionAttributes'] = dimensionAttributes
    report_query['startDate'] = format_datetime_to_obj(start_date)
    report_query['endDate'] = format_datetime_to_obj(end_date)

    if filter:
        filter_field = next(iter(filter))
        filter_values = filter[filter_field]
        placeholders = [f':lin{i}' for i in range(len(filter_values))]
        report_query['statement'] = {
            'query': f'WHERE {filter_field} IN ({",".join(placeholders)})',
            'values': [
                {'key': f'lin{i}', 'value': {'xsi_type': 'TextValue', 'value': name}}
                for i, name in enumerate(filter_values)
            ]
        }

    return report_query


# COMMAND ----------

def format_report(report_data: Any, report_type: str) -> Any:
    if report_type == 'GAM Campaign Reporting Data Validation Report':
        format_columns = {
            'Dimension.ORDER_ID': ('order_id', T.LongType()),
            'Dimension.ORDER_NAME': ('order_name', T.StringType()),
            'Dimension.LINE_ITEM_ID': ('line_item_id', T.LongType()),
            'Dimension.LINE_ITEM_TYPE': ('line_item_type', T.StringType()),
            'Dimension.ADVERTISER_NAME': ('advertiser_name', T.StringType()),
            'DimensionAttribute.ORDER_END_DATE_TIME': ('order_end_date', T.TimestampType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS': ('total_impressions', T.LongType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_CLICKS': ('total_clicks', T.LongType()),
            'Column.VIDEO_VIEWERSHIP_START': ('video_views', T.LongType()),
            'Column.VIDEO_VIEWERSHIP_COMPLETE': ('video_completes', T.LongType())
        }
        select_cols = [
            'order_id',
            'order_name',
            'line_item_id',
            'line_item_type',
            'advertiser_name',
            'order_end_date',
            'total_impressions',
            'total_clicks',
            'video_views',
            'video_completes'
        ]

    for k, v in format_columns.items():
        report_data = report_data.withColumnRenamed(k, v[0])
        report_data = report_data.withColumn(v[0], F.col(v[0]).cast(v[1]))

    report_data = report_data.select(select_cols).dropDuplicates()

    return report_data

# COMMAND ----------

class NotebookData:
    #to run the notebooks in parallel
    def __init__(self, path, timeout, parameters=None, retry=0):
        self.path = path
        self.timeout = timeout
        self.parameters = parameters
        self.retry = retry


    def submitNotebook(notebook):
        try:
            if (notebook.parameters):
                return dbutils.notebook.run(notebook.path, notebook.timeout, notebook.parameters)
            else:
                return dbutils.notebook.run(notebook.path, notebook.timeout)
        except Exception:
            raise SystemExit("Failed!")

#this function is to run noteboks in parallel
def parallelNotebooks(notebooks, numInParallel):
    with ThreadPoolExecutor(max_workers=numInParallel) as ec:
        return [ec.submit(NotebookData.submitNotebook, notebook) for notebook in notebooks]

# COMMAND ----------

def get_validation_status(validation_df):
    return True

# COMMAND ----------

if __name__ == '__main__':
    timezone = pytz.timezone("UTC")

    dev_catalog_name = dbutils.widgets.get('dev_catalog_name')
    qa_catalog_name = dbutils.widgets.get('qa_catalog_name')
    prod_catalog_name = dbutils.widgets.get('prod_catalog_name')
    cpe_s3_bucket = dbutils.widgets.get('cpe_s3_bucket')

    num_workers = int(dbutils.widgets.get('num_workers'))

    # DVPS Campaign Reporting Data Validation
    print('Fetching Third Party Campaign Reporting Source Data')
    third_party_source_query = f"""
        WITH op_line_detail AS (
            SELECT
                sales_order_id AS aos_deal_id,
                TRY_CAST(ps_line_item_id AS BIGINT) AS line_item_id,
                CASE
                    WHEN billable_third_party_descr = 'DCM' THEN 'FOX DCM'
                    WHEN billable_third_party_descr = 'Doubleverify' THEN 'FOX Doubleverify'
                    WHEN billable_third_party_descr = 'Innovid' THEN 'FOX Innovid'
                    WHEN billable_third_party_descr = 'Flashtalking' THEN 'FOX Flashtalking'
                    WHEN billable_third_party_descr = 'Extreme Reach' THEN 'FOX Extreme Reach'
                    WHEN billable_third_party_descr = 'Sizmek' THEN 'FOX Sizmek'
                    WHEN billable_third_party_descr = '1st Party' THEN 'FOX 1st Party'
                    ELSE billable_third_party_descr
                END AS billable_third_party_server,
                net_unit_cost_amt AS net_unit_cost,
                net_cost_amt AS guaranteed_revenue
            FROM {prod_catalog_name}.gold_ad_sales.ft_digital_operative_line_date_allocation
            WHERE sales_order_line_item_name NOT ILIKE '%cancelled%'
            AND order_end_dt BETWEEN DATE_TRUNC('month', ADD_MONTHS(CURRENT_DATE(), -3))::DATE AND CURRENT_DATE()
            AND ps_line_item_id IS NOT NULL
            GROUP BY ALL
        ),
        third_party_delivery AS (
            SELECT
                event_date,
                creative_id,
                ad_unit_id,
                TRY_CAST(campaign_id AS BIGINT) AS line_item_id,
                SUM(TRY_CAST(third_party_billable_impressions AS BIGINT)) AS third_party_impressions,
                SUM(TRY_CAST(third_party_revenue AS DOUBLE)) AS third_party_revenue,
                CASE
                    WHEN third_party_billable_server = 'Moat' THEN 'Moat'
                    WHEN third_party_billable_server IN ('DFA by Google', 'Dart Report Reader', 'Dart Report Reader, DFA by Google', 'DFP by Google') THEN 'FOX DCM'
                    WHEN third_party_billable_server = 'DoubleVerify' THEN 'FOX Doubleverify'
                    WHEN third_party_billable_server = 'Innovid 3rd Party' THEN 'FOX Innovid'
                    WHEN third_party_billable_server IN ('FlashTalking', 'FlashTalking Email Reader') THEN 'FOX Flashtalking'
                    WHEN third_party_billable_server IN ('Extreme Reach Email', 'ExtremeReachAPI') THEN 'FOX Extreme Reach'
                    WHEN third_party_billable_server IN ('MediaMind', 'MediaMind Report Reader', 'Sizmek SAS Report Reader','MediaMind Report Reader, Sizmek SAS Report Reader', 'Sizmek SAS Report Reader, MediaMind Report Reader') THEN 'FOX Sizmek'
                    WHEN third_party_billable_server = 'TubeMogul' THEN 'TubeMogul'
                    ELSE 'FOX 1st Party'
                END AS billable_third_party_server
            FROM {dev_catalog_name}.bronze_ads.third_party_campaign_reporting_delivery
            WHERE event_date BETWEEN '2024-01-01' AND  current_date()
            GROUP BY ALL
        ),
        third_party_agg_data AS (
            SELECT
                3p.event_date,
                3p.line_item_id,
                3p.creative_id,
                3p.ad_unit_id,
                SUM(3p.third_party_impressions) AS third_party_impressions,
                SUM(3p.third_party_revenue) AS third_party_revenue,
                3p.billable_third_party_server
            FROM third_party_delivery 3p
            INNER JOIN op_line_detail op
            ON 3p.line_item_id = op.line_item_id
            AND 3p.billable_third_party_server = op.billable_third_party_server
            GROUP BY ALL
        ),
        gam_data AS (
            SELECT DISTINCT
                ad_date,
                line_item_id,
                line_item_type
            FROM {dev_catalog_name}.silver_ads.ft_gam_summary_daily_data
            WHERE ad_date BETWEEN '2024-01-01' AND current_date()
            AND line_item_type IN ('SPONSORSHIP', 'STANDARD', 'BULK')
            AND line_item_id <> -1
        ),
        freewheel_data AS (
            SELECT DISTINCT
                event_date,
                placement_id,
                ad_unit_id,
                global_ad_unit_position,
                creative_id
            FROM {qa_catalog_name}.gold_ad_sales.ft_freewheel_delivery_daily
            WHERE event_date BETWEEN '2024-01-01' AND current_date()
            AND sales_channel_type in ('Direct Sold')
            AND COALESCE(campaign_name,'N/A') NOT ILIKE '%promo%'
            AND COALESCE(agency_name,'N/A') NOT IN ('FNG IN-HOUSE MARKETING & PROMOTIONS')
            AND COALESCE(advertiser_name,'N/A') NOT ILIKE '%promo%'
            AND COALESCE(advertiser_name,'N/A') NOT IN ('Placeholder Advertiser')
            AND COALESCE(agency_name,'N/A') NOT IN ('Placeholder Agency')
            AND COALESCE(TRY_CAST(ps_line_item_id AS BIGINT),-1) <> -1
            AND COALESCE(sales_order_line_item_name,'N/A') NOT ILIKE '%cancelled%'
        ),
        freewheel_3p AS (
            SELECT
                op.aos_deal_id,
                fw.placement_id,
                fw.creative_id,
                fw.event_date,
                fw.global_ad_unit_position,
                3p.line_item_id,
                MAX(3p.third_party_impressions) AS third_party_impressions,
                MAX(3p.third_party_revenue) AS third_party_revenue
            FROM freewheel_data fw
            LEFT JOIN third_party_agg_data 3p
            ON fw.creative_id = TRY_CAST(split_part(3p.creative_id,'-', 1) AS BIGINT)
            AND fw.ad_unit_id = 3p.ad_unit_id
            AND fw.event_date = 3p.event_date
            LEFT JOIN op_line_detail op
            ON fw.placement_id = op.line_item_id
            GROUP BY ALL
        ),
        gam_3p AS (
            SELECT
                op.aos_deal_id,
                coalesce(gam.line_item_id,3p.line_item_id),
                SUM(3p.third_party_impressions) AS third_party_impressions,
                CASE
                    WHEN MAX(gam.line_item_type) = 'SPONSORSHIP' THEN MAX(guaranteed_revenue)
                    ELSE (SUM(3p.third_party_impressions) * MAX(net_unit_cost)) / 1000
                END AS third_party_revenue
            FROM gam_data gam
            LEFT JOIN third_party_agg_data AS 3p
            ON gam.ad_date = 3p.event_date
            AND gam.line_item_id = 3p.line_item_id
            LEFT JOIN op_line_detail op
            ON gam.line_item_id = op.line_item_id
            GROUP BY ALL
        ),
        unified AS (
            SELECT
                aos_deal_id,
                line_item_id,
                third_party_impressions,
                third_party_revenue
            FROM freewheel_3p

            UNION ALL

            SELECT
                *
            FROM gam_3p
        )
        SELECT
            aos_deal_id,
            SUM(third_party_impressions) AS total_third_party_impressions,
            SUM(third_party_revenue) AS total_third_party_revenue
        FROM unified
        WHERE 1 = 1
        GROUP BY ALL
    """
    third_party_source_df = spark.sql(third_party_source_query)

    # Fetch the deal ids for which we have first party information
    first_party_deal_ids_query = f"""
        SELECT DISTINCT
            aos_deal_id
        FROM {dev_catalog_name}.bronze_ads.source_first_party_data_by_deal
        WHERE aos_deal_id != -1
    """
    first_party_deal_ids = spark.sql(first_party_deal_ids_query)

    third_party_source_df = third_party_source_df.join(first_party_deal_ids, on=['aos_deal_id'], how='inner')

    third_party_source_df = third_party_source_df.fillna(0, subset=[
        'total_third_party_impressions',
        'total_third_party_revenue'
    ])

    if not spark.catalog.tableExists(f'{dev_catalog_name}.bronze_ads.source_third_party_data_by_deal'): #Add the table name for First time load
        third_party_source_df.write.format('delta') \
            .mode('overwrite') \
            .partitionBy('aos_deal_id') \
            .option('mergeSchema', 'true') \
            .option('overwriteDynamicPartitions', 'true') \
            .option('delta.enableDeletionVectors', 'false') \
            .option('delta.enableIcebergCompatV2', 'true') \
            .option('delta.universalFormat.enabledFormats', 'iceberg') \
            .option('delta.columnMapping.mode', 'name') \
            .saveAsTable(f'{dev_catalog_name}.bronze_ads.source_third_party_data_by_deal')
    else:
        spark.sql(f'delete from {dev_catalog_name}.bronze_ads.source_third_party_data_by_deal')
        third_party_source_df.write.format('delta') \
            .mode('overwrite') \
            .option('partitionOverwriteMode', 'dynamic') \
            .saveAsTable(f'{dev_catalog_name}.bronze_ads.source_third_party_data_by_deal')

    # Validate the source deal level data with the campaign reporting unified deal level data
    print('Validating the source deal level data with the campaign reporting unified deal level data')
    target_df_query = f"""
        SELECT
            `AOS Deal ID` AS aos_deal_id
            , `Total Third Party Impressions` AS total_third_party_impressions_view
            , `Total Third Party Revenue` AS total_third_party_revenue_view
        FROM {qa_catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal
        WHERE `AOS Deal ID` != -1
        AND `AOS Deal End Date` BETWEEN DATE_TRUNC('month', ADD_MONTHS(CURRENT_DATE(), -3))::DATE AND CURRENT_DATE()
    """
    target_df = spark.sql(target_df_query)
    target_df = target_df.fillna(0, subset=[
        'total_third_party_impressions_view',
        'total_third_party_revenue_view'
    ])

    source_df_query = f"""
        SELECT
            aos_deal_id
            , total_third_party_impressions AS total_third_party_impressions_source
            , total_third_party_revenue AS total_third_party_revenue_source
        FROM {dev_catalog_name}.bronze_ads.source_third_party_data_by_deal
        WHERE aos_deal_id != -1
    """

    source_df = spark.sql(source_df_query)

    validation_df = source_df.join(target_df, on=['aos_deal_id'], how='full_outer')

    pairs = [
        ("total_third_party_impressions_source", "total_third_party_impressions_view", "Total Third Party Impressions Variance %"),
        ("total_third_party_revenue_source", "total_third_party_revenue_view", "Total  Third Party Revenue Variance %")
    ]

    print('Performing campaign reporting source vs view validtions')
    for source_col, view_col, out_col in pairs:
        if '%' in out_col:
            validation_df = validation_df.withColumn(out_col, \
                                                     F.when(F.col(source_col) == 0, F.col(view_col)) \
                                                     .otherwise(F.round((F.col(source_col) - F.col(view_col))/F.col(source_col)*100, 3))
                                                     )
        else:
            validation_df = validation_df.withColumn(out_col, \
                                                     F.when(F.col(source_col) == 0, F.col(view_col)) \
                                                     .otherwise(F.round(F.col(source_col) - F.col(view_col), 3))
                                                     )

    validation_df = validation_df.select([
        'aos_deal_id', 'total_third_party_impressions_source', 'total_third_party_impressions_view', 'total_third_party_revenue_source', 'total_third_party_revenue_view', 'Total Third Party Impressions Variance %', 'Total  Third Party Revenue Variance %'
    ])
    validation_df = validation_df.withColumn('updated_timestamp', F.lit(F.current_timestamp()))
    print('Campaign summary validtions completed')

    if not spark.catalog.tableExists(f'{dev_catalog_name}.bronze_ads.campaign_reporting_third_party_validations'): #Add the table name for First time load
        validation_df.write.format('delta') \
            .mode('overwrite') \
            .partitionBy('aos_deal_id') \
            .option('mergeSchema', 'true') \
            .option('overwriteDynamicPartitions', 'true') \
            .option('delta.enableDeletionVectors', 'false') \
            .option('delta.enableIcebergCompatV2', 'true') \
            .option('delta.universalFormat.enabledFormats', 'iceberg') \
            .option('delta.columnMapping.mode', 'name') \
            .saveAsTable(f'{dev_catalog_name}.bronze_ads.campaign_reporting_third_party_validations')
    else:
        spark.sql(f'delete from {dev_catalog_name}.bronze_ads.campaign_reporting_third_party_validations')
        validation_df.write.format('delta') \
            .mode('overwrite') \
            .option('partitionOverwriteMode', 'dynamic') \
            .saveAsTable(f'{dev_catalog_name}.bronze_ads.campaign_reporting_third_party_validations')

    """
        # TODO:
            1. Add a mechanism to pass or fail the validations
            2. Write the output of step 1 to dbutils.task values
    """

    validation_status = get_validation_status(validation_df)
    dbutils.jobs.taskValues.set(key = "validation_status", value = str(validation_status))

    print('Validation Status:', 'Pass' if validation_status else 'Fail')