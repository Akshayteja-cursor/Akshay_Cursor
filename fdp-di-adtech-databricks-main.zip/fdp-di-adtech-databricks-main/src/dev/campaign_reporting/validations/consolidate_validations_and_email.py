# Databricks notebook source
# Databricks Notebook / PySpark Application
# ----------------------------------------
# 1) Reads 3 validation tables
# 2) Detects variance conditions (per your rules) and builds summary strings
# 3) Exports all 3 tables into ONE Excel file with 3 tabs
# 4) Emails the Excel file + variance summary to a distribution list
#
# IMPORTANT (driver memory):
# - Excel writing uses toPandas(), so large tables can OOM the driver.
# - Use max_rows_per_tab to cap exports, or add filters (e.g., last N days / aos_deal_id list).
#
# Email:
# - Uses SMTP via Databricks secrets (recommended).
# - If your org uses a different mail mechanism (SendGrid/Graph/SES), say so and I’ll swap the sender block.

# =========================
# 0) Widgets / Parameters
# =========================

# COMMAND ----------

pip install boto3==1.40.49 awscli s3fs

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %sh
# MAGIC aws configure set region us-west-2 --profile databricks-cpe-dev
# MAGIC aws configure set s3.signature_version s3v4 --profile databricks-cpe-dev
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile databricks-cpe-dev
# MAGIC aws configure set role_arn arn:aws:iam::393000359662:role/data-infra-astro-bi-adtech-dev --profile databricks-cpe-dev

# COMMAND ----------

import boto3
import smtplib
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email import encoders
import pandas as pd
from datetime import datetime
import pyspark.sql.functions as F

# COMMAND ----------

dbutils.widgets.text("catalog", "fox_bi_dev")
dbutils.widgets.text("schema", "bronze_ads")

dbutils.widgets.text("table_aos", "aos_campaign_validations")
dbutils.widgets.text("table_1p", "campaign_reporting_first_party_validations")
dbutils.widgets.text("table_3p", "campaign_reporting_third_party_validations")
dbutils.widgets.text("table_report", "campaign_detailed_report_validation")
dbutils.widgets.text("table_unified", "v_ft_unified_campaign_delivery_by_deal")

dbutils.widgets.text("table_impressions_over_time_mismatches", "wrap_report_impressions_over_time_mismatches")
dbutils.widgets.text("table_line_item_type_performance_mismatches", "wrap_report_line_item_type_performance_mismatches")
dbutils.widgets.text("table_target_audience_distribution_mismatches", "wrap_report_target_audience_distribution_mismatches")
dbutils.widgets.text("table_package_performance_mismatches", "wrap_report_package_performance_mismatches")
dbutils.widgets.text("table_geo_performance_mismatches", "wrap_report_geo_performance_mismatches")
dbutils.widgets.text("table_duration_bucket_analysis_mismatches", "wrap_report_duration_bucket_analysis_mismatches")
dbutils.widgets.text("table_device_breakdown_mismatches", "wrap_report_device_breakdown_mismatches")
dbutils.widgets.text("table_device_ad_position_matrix_mismatches", "wrap_report_device_ad_position_matrix_mismatches")
dbutils.widgets.text("table_demo_band_performance_mismatches", "wrap_report_demo_band_performance_mismatches")
dbutils.widgets.text("table_deal_ad_units_performance_mismatches", "wrap_report_deal_ad_units_performance_mismatches")
dbutils.widgets.text("table_creative_performance_mismatches", "wrap_report_creative_performance_mismatches")
dbutils.widgets.text("table_content_performance_mismatches", "wrap_report_content_performance_mismatches")
dbutils.widgets.text("table_campaign_summary_mismatches", "wrap_report_campaign_summary_mismatches")
dbutils.widgets.text("table_ad_position_analysis_mismatches", "wrap_report_ad_position_analysis_mismatches")
dbutils.widgets.text("table_package_performance_analysis_threshold", "wrap_report_package_performance_threshold_exceed")

dbutils.widgets.text("output_dir", "/Workspace/Shared/Dev/WRAP/")
dbutils.widgets.text("file_name", "wrap_validations.xlsx")

dbutils.widgets.text("to_emails", "yogesh.nageswararao@fox.com")   # comma-separated
dbutils.widgets.text("from_emails", "adtech.dev@data.fox")
dbutils.widgets.text("cc_emails", "prajwal.harikishor@fox.com")                 # comma-separated optional
dbutils.widgets.text("email_subject", "[WRAP] Validation Report - Variance Summary")

dbutils.widgets.text("variance_threshold_pct", "10")  # 10 means >10
dbutils.widgets.text("max_rows_per_tab", "200000")    # cap to avoid driver OOM

CATALOG = dbutils.widgets.get("catalog").strip()
SCHEMA  = dbutils.widgets.get("schema").strip()

# COMMAND ----------

# Generate timestamp
current_ts = datetime.now().strftime("%Y%m%d_%H%M%S")

TBL_AOS = f"{CATALOG}.{SCHEMA}.{dbutils.widgets.get('table_aos').strip()}"
TBL_1P  = f"{CATALOG}.{SCHEMA}.{dbutils.widgets.get('table_1p').strip()}"
TBL_3P  = f"{CATALOG}.{SCHEMA}.{dbutils.widgets.get('table_3p').strip()}"
TBL_RPT = f"{CATALOG}.{SCHEMA}.{dbutils.widgets.get('table_report').strip()}"
TBL_UNIFIED = f"fox_bi_qa.gold_ad_sales.{dbutils.widgets.get('table_unified').strip()}"
TBL_IMPS_MISMATCH =f"{CATALOG}.{SCHEMA}.{dbutils.widgets.get('table_impressions_over_time_mismatches').strip()}"
TBL_LINE_ITEM_MISMATCH =f"{CATALOG}.{SCHEMA}.{dbutils.widgets.get('table_line_item_type_performance_mismatches').strip()}"
TBL_TGT_AUDI_MISMATCH =f"{CATALOG}.{SCHEMA}.{dbutils.widgets.get('table_target_audience_distribution_mismatches').strip()}"
TBL_PKG_MISMATCH =f"{CATALOG}.{SCHEMA}.{dbutils.widgets.get('table_package_performance_mismatches').strip()}"
TBL_GEO_MISMATCH =f"{CATALOG}.{SCHEMA}.{dbutils.widgets.get('table_geo_performance_mismatches').strip()}"
TBL_DURATION_MISMATCH =f"{CATALOG}.{SCHEMA}.{dbutils.widgets.get('table_duration_bucket_analysis_mismatches').strip()}"
TBL_DEVICE_BRK_MISMATCH =f"{CATALOG}.{SCHEMA}.{dbutils.widgets.get('table_device_breakdown_mismatches').strip()}"
TBL_DEVICE_AD_POS_MISMATCH =f"{CATALOG}.{SCHEMA}.{dbutils.widgets.get('table_device_ad_position_matrix_mismatches').strip()}"
TBL_DEMO_MISMATCH =f"{CATALOG}.{SCHEMA}.{dbutils.widgets.get('table_demo_band_performance_mismatches').strip()}"
TBL_AD_UNIT_MISMATCH =f"{CATALOG}.{SCHEMA}.{dbutils.widgets.get('table_deal_ad_units_performance_mismatches').strip()}"
TBL_CREATIVE_MISMATCH =f"{CATALOG}.{SCHEMA}.{dbutils.widgets.get('table_creative_performance_mismatches').strip()}"
TBL_CONTENT_MISMATCH =f"{CATALOG}.{SCHEMA}.{dbutils.widgets.get('table_content_performance_mismatches').strip()}"
TBL_SUMMARY_MISMATCH =f"{CATALOG}.{SCHEMA}.{dbutils.widgets.get('table_campaign_summary_mismatches').strip()}"
TBL_AD_POSITION_MISMATCH =f"{CATALOG}.{SCHEMA}.{dbutils.widgets.get('table_ad_position_analysis_mismatches').strip()}"
TBL_PKG_PERF_THRESHOLD =f"{CATALOG}.{SCHEMA}.{dbutils.widgets.get('table_package_performance_analysis_threshold').strip()}"

OUTPUT_DIR = dbutils.widgets.get("output_dir").strip().rstrip("/")
FILE_NAME = f"wrap_validations_{current_ts}.xlsx"


OUT_PATH_DBFS  = f"{OUTPUT_DIR}/{FILE_NAME}"
OUT_PATH_LOCAL = OUT_PATH_DBFS

TO_EMAILS = [e.strip() for e in dbutils.widgets.get("to_emails").split(",") if e.strip()]
FROM_EMAIL = dbutils.widgets.get("to_emails").strip()
CC_EMAILS = [e.strip() for e in dbutils.widgets.get("cc_emails").split(",") if e.strip()]

EMAIL_SUBJECT = dbutils.widgets.get("email_subject").strip()
THRESHOLD = float(dbutils.widgets.get("variance_threshold_pct").strip() or "10")
MAX_ROWS  = int(dbutils.widgets.get("max_rows_per_tab").strip() or "200000")

if not TO_EMAILS:
    raise ValueError("to_emails cannot be empty.")

dbutils.fs.mkdirs(OUTPUT_DIR)

# COMMAND ----------

# =========================
# 1) Read tables
# =========================
df_aos = spark.table(TBL_AOS)
df_1p  = spark.table(TBL_1P)
df_3p  = spark.table(TBL_3P)
df_rpt  = spark.table(TBL_RPT)
df_unified  = spark.table(TBL_UNIFIED)
df_impressions_over_time_mismatches = spark.table(TBL_IMPS_MISMATCH)
df_line_item_mismatches = spark.table(TBL_LINE_ITEM_MISMATCH)
df_tgt_audi_mismatches = spark.table(TBL_TGT_AUDI_MISMATCH)
df_pkg_mismatches = spark.table(TBL_PKG_MISMATCH)
df_geo_mismatches = spark.table(TBL_GEO_MISMATCH)
df_duration_mismatches = spark.table(TBL_DURATION_MISMATCH)
df_device_brk_mismatches = spark.table(TBL_DEVICE_BRK_MISMATCH)
df_device_ad_pos_mismatches = spark.table(TBL_DEVICE_AD_POS_MISMATCH)
df_demo_mismatches = spark.table(TBL_DEMO_MISMATCH)
df_ad_unit_mismatches = spark.table(TBL_AD_UNIT_MISMATCH)
df_creative_mismatches = spark.table(TBL_CREATIVE_MISMATCH)
df_content_mismatches = spark.table(TBL_CONTENT_MISMATCH)
df_summary_mismatches = spark.table(TBL_SUMMARY_MISMATCH)
df_ad_position_mismatches = spark.table(TBL_AD_POSITION_MISMATCH)
df_pkg_perf_threshold = spark.table(TBL_PKG_PERF_THRESHOLD)

# COMMAND ----------

# =========================
# 2) Variance checks + summary strings
# =========================
summary_lines = []

# ---- Find duplicate AOS_DEAL_IDs in PROD view
df_deals = df_unified.select(F.col("AOS DEAL ID").alias("aos_deal_id"))

df_dups = (
    df_deals
    .groupBy("aos_deal_id")
    .count()
    .filter(F.col("count") > 1)
    .orderBy(F.col("count").desc(), F.col("aos_deal_id"))
)

# Optional: quick boolean / count for notebook logs
has_dups = df_dups.limit(1).count() > 0
print(f"Duplicates present? {has_dups}. Duplicate dealIds count = {df_dups.count()}")

if has_dups:
    summary_lines.append("❗❗❗ Unified by deal base table is having duplicate records.")


# ---- AOS vs WRAP: any *_Mismatch = true
mismatch_cols = [c for c in df_aos.columns if c.lower().endswith("_mismatch")]
if not mismatch_cols:
    aos_has_variance = None
    summary_lines.append("⚠️ AOS vs WRAP check: No *_Mismatch columns found in aos_campaign_validations.")
else:
    mismatch_any_expr = None
    for c in mismatch_cols:
        expr = F.coalesce(F.col(c).cast("boolean"), F.lit(False)) == F.lit(True)
        mismatch_any_expr = expr if mismatch_any_expr is None else (mismatch_any_expr | expr)

    aos_var_count = df_aos.where(mismatch_any_expr).count()
    aos_has_variance = aos_var_count > 0

    if aos_has_variance:
        summary_lines.append("❗ AOS vs WRAP unified aggregated table has variance, please check.")
    else:
        summary_lines.append("✅ AOS vs WRAP: No variance detected in *_Mismatch fields.")

# ---- 1P vs WRAP: any "* Variance %" > 10
variance_pct_cols_1p = [c for c in df_1p.columns if "variance" in c.lower() and "%" in c]
if not variance_pct_cols_1p:
    onep_has_variance = None
    summary_lines.append("⚠️ 1P vs WRAP check: No '* Variance %' columns found in camaign_reporting_first_party_validations.")
else:
    onep_any_expr = None
    for c in variance_pct_cols_1p:
        expr = F.coalesce(F.col(c).cast("double"), F.lit(0.0)) > F.lit(THRESHOLD)
        onep_any_expr = expr if onep_any_expr is None else (onep_any_expr | expr)

    onep_var_count = df_1p.where(onep_any_expr).count()
    onep_has_variance = onep_var_count > 0

    if onep_has_variance:
        summary_lines.append(f"❗ 1P vs WRAP unified aggregated table has variance above the normal threshold of {int(THRESHOLD)}%, please check.")
    else:
        summary_lines.append(f"✅ 1P vs WRAP: No variance > {int(THRESHOLD)}% detected.")

# ---- 3P vs WRAP: any "* Variance %" > 10
variance_pct_cols_3p = [c for c in df_3p.columns if "variance" in c.lower() and "%" in c]
if not variance_pct_cols_3p:
    threep_has_variance = None
    summary_lines.append("⚠️ 3P vs WRAP check: No '* Variance %' columns found in camaign_reporting_third_party_validations.")
else:
    threep_any_expr = None
    for c in variance_pct_cols_3p:
        expr = F.coalesce(F.col(c).cast("double"), F.lit(0.0)) > F.lit(THRESHOLD)
        threep_any_expr = expr if threep_any_expr is None else (threep_any_expr | expr)

    threep_var_count = df_3p.where(threep_any_expr).count()
    threep_has_variance = threep_var_count > 0

    if threep_has_variance:
        summary_lines.append(f"❗ 3P vs WRAP unified aggregated table has variance above the normal threshold of {int(THRESHOLD)}%, please check.")
    else:
        summary_lines.append(f"✅ 3P vs WRAP: No variance > {int(THRESHOLD)}% detected.")

# ---- WRAP Report vs WRAP Unified: any parse with variance per aos_deal_id
validation_cols = [c for c in df_rpt.columns if c.lower() != "aos_deal_id"]

# Count deals with any FALSE / MISSING across validation columns
false_any_expr = None
missing_any_expr = None

for c in validation_cols:
    col_str = F.upper(F.trim(F.col(c).cast("string")))
    is_false = (col_str == F.lit("FALSE"))
    is_missing = (col_str == F.lit("MISSING"))

    false_any_expr = is_false if false_any_expr is None else (false_any_expr | is_false)
    missing_any_expr = is_missing if missing_any_expr is None else (missing_any_expr | is_missing)

false_deals_cnt = df_rpt.where(false_any_expr).select("deal_id").distinct().count() if false_any_expr is not None else 0
missing_deals_cnt = df_rpt.where(missing_any_expr).select("deal_id").distinct().count() if missing_any_expr is not None else 0

if false_deals_cnt > 0 or missing_deals_cnt > 0:
    summary_lines.append(
        f"❗ Detailed report validations: Variance/Missing detected (FALSE deals: {false_deals_cnt}, MISSING deals: {missing_deals_cnt}). Please check."
    )
else:
    summary_lines.append("✅ Detailed report validations: No variance detected.")

# COMMAND ----------

# =========================
# 3) Export to Excel (16 tabs)
# =========================
def to_pandas_capped(df, max_rows: int) -> pd.DataFrame:
    return df.limit(max_rows).toPandas()

# Tab names (Excel max 31 chars)
tabs = [
    ("unified_by_deal_duplicate", df_dups),
    ("aos_campaign_validations", df_aos),
    ("campaign_reporting_1p", df_1p),
    ("campaign_reporting_3p", df_3p),
    ("report_validation_all_parses", df_rpt),
    ("impressions_over_time_mismatches", df_impressions_over_time_mismatches),
    ("line_item_mismatches", df_line_item_mismatches),
    ("target_audience_mismatches", df_tgt_audi_mismatches),
    ("package_performance_mismatches", df_pkg_mismatches),
    ("geo_performance_mismatches", df_geo_mismatches),
    ("duration_bucket_mismatches", df_duration_mismatches),
    ("device_breakdown_mismatches", df_device_brk_mismatches),
    ("device_ad_position_mismatches", df_device_ad_pos_mismatches),
    ("demo_band_performance_mismatches", df_demo_mismatches),
    ("ad_unit_performance_mismatches", df_ad_unit_mismatches),
    ("creative_mismatches", df_creative_mismatches),
    ("content_mismatches", df_content_mismatches),
    ("campaign_summary_mismatches", df_summary_mismatches),
    ("ad_position_mismatches", df_ad_position_mismatches),
    ("package_performance_threshold", df_pkg_perf_threshold)
]

with pd.ExcelWriter(OUT_PATH_LOCAL, engine="xlsxwriter") as writer:
    workbook = writer.book
    red_format = workbook.add_format({"bg_color": "#FFC7CE", "font_color": "#9C0006"})

    # -------------------
    # TAB 1: Duplicate Check
    # -------------------
    pdf_dups = to_pandas_capped(df_dups, MAX_ROWS)
    sheet_name_dups = "unified_by_deal_duplicate"
    pdf_dups.to_excel(writer, sheet_name=sheet_name_dups[:31], index=False)
    ws_dups = writer.sheets[sheet_name_dups[:31]]

    # Nice-to-have formatting
    ws_dups.freeze_panes(1, 0)
    ws_dups.autofilter(0, 0, len(pdf_dups), len(pdf_dups.columns) - 1)

    # Highlight counts > 1 (entire count column)
    if "count" in pdf_dups.columns:
        count_idx = list(pdf_dups.columns).index("count")
        count_col_letter = chr(65 + count_idx)
        ws_dups.conditional_format(
            f"{count_col_letter}2:{count_col_letter}{len(pdf_dups)+1}",
            {"type": "cell", "criteria": ">", "value": 1, "format": red_format},
        )


    # -------------------
    # TAB 2: AOS
    # -------------------
    pdf_aos = to_pandas_capped(df_aos, MAX_ROWS)
    sheet_name = "aos_campaign_validations"
    pdf_aos.to_excel(writer, sheet_name=sheet_name[:31], index=False)

    worksheet = writer.sheets[sheet_name[:31]]

    # Apply RED color if *_Mismatch = TRUE
    for col_idx, col_name in enumerate(pdf_aos.columns):
        if col_name.lower().endswith("_mismatch"):
            col_letter = chr(65 + col_idx)
            cell_range = f"{col_letter}2:{col_letter}{len(pdf_aos)+1}"
            col_lower = col_name.lower()

            # ---------------------------------------
            # 1️⃣ Numeric mismatch columns (> 0.1 → RED)
            # ---------------------------------------
            if col_lower in [
                "budget_mismatch",
                "total_guaranteed_impressions_mismatch"
            ]:
                worksheet.conditional_format(
                    cell_range,
                    {
                        "type": "cell",
                        "criteria": ">",
                        "value": 0.1,
                        "format": red_format,
                    },
                )

            # ---------------------------------------
            # 2️⃣ Boolean mismatch columns (FALSE → RED)
            # ---------------------------------------
            elif col_lower.endswith("_mismatch"):
                worksheet.conditional_format(
                    cell_range,
                    {
                        "type": "cell",
                        "criteria": "==",
                        "value": False,
                        "format": red_format,
                    },
                )


            # worksheet.conditional_format(
            #     f"{col_letter}2:{col_letter}{len(pdf_aos)+1}",
            #     {
            #         "type": "cell",
            #         "criteria": "==",
            #         "value": False,
            #         "format": red_format,
            #     },
            # )

    # -------------------
    # TAB 3: 1P
    # -------------------
    pdf_1p = to_pandas_capped(df_1p, MAX_ROWS)
    sheet_name_1p = "campaign_reporting_1p"
    pdf_1p.to_excel(writer, sheet_name=sheet_name_1p[:31], index=False)

    worksheet_1p = writer.sheets[sheet_name_1p[:31]]

    for col_idx, col_name in enumerate(pdf_1p.columns):
        if "variance" in col_name.lower() and "%" in col_name:
            col_letter = chr(65 + col_idx)
            worksheet_1p.conditional_format(
                f"{col_letter}2:{col_letter}{len(pdf_1p)+1}",
                {
                    "type": "cell",
                    "criteria": ">",
                    "value": 10,
                    "format": red_format,
                },
            )

    # -------------------
    # TAB 4: 3P
    # -------------------
    pdf_3p = to_pandas_capped(df_3p, MAX_ROWS)
    sheet_name_3p = "campaign_reporting_3p"
    pdf_3p.to_excel(writer, sheet_name=sheet_name_3p[:31], index=False)

    worksheet_3p = writer.sheets[sheet_name_3p[:31]]

    for col_idx, col_name in enumerate(pdf_3p.columns):
        if "variance" in col_name.lower() and "%" in col_name:
            col_letter = chr(65 + col_idx)
            worksheet_3p.conditional_format(
                f"{col_letter}2:{col_letter}{len(pdf_3p)+1}",
                {
                    "type": "cell",
                    "criteria": ">",
                    "value": 10,
                    "format": red_format,
                },
            )

    # -------------------
    # TAB 5: report_validation_all_parses
    # -------------------
    pdf_rpt = to_pandas_capped(df_rpt, MAX_ROWS)
    sheet_name_4 = "report_validation_all_parses"
    pdf_rpt.to_excel(writer, sheet_name=sheet_name_4[:31], index=False)

    ws4 = writer.sheets[sheet_name_4[:31]]

    # Color RED if any validation cell is FALSE or MISSING (exclude aos_deal_id)
    for col_idx, col_name in enumerate(pdf_rpt.columns):
        if col_name.lower() == "aos_deal_id":
            continue

        # Excel column letter (SAFE if you already added the robust converter earlier;
        # if not, and your columns can exceed 26, tell me and I'll give you the AA/AB converter.)
        col_letter = chr(65 + col_idx)

        cell_range = f"{col_letter}2:{col_letter}{len(pdf_rpt)+1}"

        # FALSE -> RED
        ws4.conditional_format(
            cell_range,
            {"type": "cell", "criteria": "==", "value": '"FALSE"', "format": red_format},
        )

        # MISSING -> RED
        ws4.conditional_format(
            cell_range,
            {"type": "cell", "criteria": "==", "value": '"MISSING"', "format": red_format},
        )

    # --------------------------------------
    # TAB 6: Parse Impressions Over Time Mismatches
    # --------------------------------------
    pdf_impressions_over_time_mismatches = to_pandas_capped(df_impressions_over_time_mismatches, MAX_ROWS)
    sheet_name_6 = "impressions_over_time_mismatches"
    pdf_impressions_over_time_mismatches.to_excel(writer, sheet_name=sheet_name_6[:31], index=False)

    ws6 = writer.sheets[sheet_name_6[:31]]

    columns_to_highlight = ["mismatch_percent_variance"]

    for col in columns_to_highlight:
        if col in pdf_impressions_over_time_mismatches.columns:
            col_idx = list(pdf_impressions_over_time_mismatches.columns).index(col)
            col_letter = chr(65 + col_idx)
            cell_range = f"{col_letter}2:{col_letter}{len(pdf_impressions_over_time_mismatches) + 1}"

            ws6.conditional_format(
                cell_range,
                {
                    "type": "cell",
                    "criteria": ">",
                    "value": 0,
                    "format": red_format,
                },
            )


    # --------------------------------------
    # TAB 7: Parse Line Item Performance Mismatches
    # --------------------------------------
    pdf_line_item_mismatches = to_pandas_capped(df_line_item_mismatches, MAX_ROWS)
    sheet_name_7 = "line_item_mismatches"
    pdf_line_item_mismatches.to_excel(writer, sheet_name=sheet_name_7[:31], index=False)

    ws7 = writer.sheets[sheet_name_7[:31]]

    columns_to_highlight = ["mismatch_percent_variance"

    for col in columns_to_highlight:
        if col in pdf_line_item_mismatches.columns:
            col_idx = list(pdf_line_item_mismatches.columns).index(col)
            col_letter = chr(65 + col_idx)
            cell_range = f"{col_letter}2:{col_letter}{len(pdf_line_item_mismatches) + 1}"

            ws7.conditional_format(
                cell_range,
                {
                    "type": "cell",
                    "criteria": ">",
                    "value": 0,
                    "format": red_format,
                },
            )

    # --------------------------------------
    # TAB 8: Parse Target Audience Distribution Mismatches
    # --------------------------------------
    pdf_tgt_audi_mismatches = to_pandas_capped(df_tgt_audi_mismatches, MAX_ROWS)
    sheet_name_8 = "target_audience_mismatches"
    pdf_tgt_audi_mismatches.to_excel(writer, sheet_name=sheet_name_8[:31], index=False)

    ws8 = writer.sheets[sheet_name_8[:31]]

    columns_to_highlight = ["mismatch_percent_variance"

    for col in columns_to_highlight:
        if col in pdf_tgt_audi_mismatches.columns:
            col_idx = list(pdf_tgt_audi_mismatches.columns).index(col)
            col_letter = chr(65 + col_idx)
            cell_range = f"{col_letter}2:{col_letter}{len(pdf_tgt_audi_mismatches) + 1}"

            ws8.conditional_format(
                cell_range,
                {
                    "type": "cell",
                    "criteria": ">",
                    "value": 0,
                    "format": red_format,
                },
            )

    # --------------------------------------
    # TAB 9: Parse Package Performance Mismatches
    # --------------------------------------
    pdf_pkg_mismatches = to_pandas_capped(df_pkg_mismatches, MAX_ROWS)
    sheet_name_9 = "package_performance_mismatches"
    pdf_pkg_mismatches.to_excel(writer, sheet_name=sheet_name_9[:31], index=False)

    ws9 = writer.sheets[sheet_name_9[:31]]

    columns_to_highlight = ["mismatch_percent_variance"

    for col in columns_to_highlight:
        if col in pdf_pkg_mismatches.columns:
            col_idx = list(pdf_pkg_mismatches.columns).index(col)
            col_letter = chr(65 + col_idx)
            cell_range = f"{col_letter}2:{col_letter}{len(pdf_pkg_mismatches) + 1}"

            ws9.conditional_format(
                cell_range,
                {
                    "type": "cell",
                    "criteria": ">",
                    "value": 0,
                    "format": red_format,
                },
            )

    # --------------------------------------
    # TAB 10: Parse Geo Performance Mismatches
    # --------------------------------------
    pdf_geo_mismatches = to_pandas_capped(df_geo_mismatches, MAX_ROWS)
    sheet_name_10 = "geo_performance_mismatches"
    pdf_geo_mismatches.to_excel(writer, sheet_name=sheet_name_10[:31], index=False)

    ws10 = writer.sheets[sheet_name_10[:31]]

    columns_to_highlight = ["mismatch_percent_variance"]

    for col in columns_to_highlight:
        if col in pdf_geo_mismatches.columns:
            col_idx = list(pdf_geo_mismatches.columns).index(col)
            col_letter = chr(65 + col_idx)
            cell_range = f"{col_letter}2:{col_letter}{len(pdf_geo_mismatches) + 1}"

            ws7.conditional_format(
                cell_range,
                {
                    "type": "cell",
                    "criteria": ">",
                    "value": 0,
                    "format": red_format,
                },
            )

    # --------------------------------------
    # TAB 11: Parse Duration Bucket Mismatches
    # --------------------------------------
    pdf_duration_mismatches = to_pandas_capped(df_duration_mismatches, MAX_ROWS)
    sheet_name_11 = "duration_bucket_analysis_mismatches"
    pdf_duration_mismatches.to_excel(writer, sheet_name=sheet_name_11[:31], index=False)

    ws11 = writer.sheets[sheet_name_11[:31]]

    columns_to_highlight = ["mismatch_percent_variance"]

    for col in columns_to_highlight:
        if col in pdf_duration_mismatches.columns:
            col_idx = list(pdf_duration_mismatches.columns).index(col)
            col_letter = chr(65 + col_idx)
            cell_range = f"{col_letter}2:{col_letter}{len(pdf_duration_mismatches) + 1}"

            ws11.conditional_format(
                cell_range,
                {
                    "type": "cell",
                    "criteria": ">",
                    "value": 0,
                    "format": red_format,
                },
            )

    # --------------------------------------
    # TAB 12: Parse Device Breakdown Mismatches
    # --------------------------------------
    pdf_device_brk_mismatches = to_pandas_capped(df_device_brk_mismatches, MAX_ROWS)
    sheet_name_12 = "device_breakdown_mismatches"
    pdf_device_brk_mismatches.to_excel(writer, sheet_name=sheet_name_12[:31], index=False)

    ws12 = writer.sheets[sheet_name_12[:31]]

    columns_to_highlight = ["mismatch_percent_variance"]

    for col in columns_to_highlight:
        if col in pdf_device_brk_mismatches.columns:
            col_idx = list(pdf_device_brk_mismatches.columns).index(col)
            col_letter = chr(65 + col_idx)
            cell_range = f"{col_letter}2:{col_letter}{len(pdf_device_brk_mismatches) + 1}"

            ws12.conditional_format(
                cell_range,
                {
                    "type": "cell",
                    "criteria": ">",
                    "value": 0,
                    "format": red_format,
                },
            )

    # --------------------------------------
    # TAB 13: Parse Device Ad Position Mismatches
    # --------------------------------------
    pdf_device_ad_pos_mismatches = to_pandas_capped(df_device_ad_pos_mismatches, MAX_ROWS)
    sheet_name_13 = "device_ad_position_mismatches"
    pdf_device_ad_pos_mismatches.to_excel(writer, sheet_name=sheet_name_13[:31], index=False)

    ws13 = writer.sheets[sheet_name_13[:31]]

    columns_to_highlight = ["mismatch_percent_variance"]

    for col in columns_to_highlight:
        if col in pdf_device_ad_pos_mismatches.columns:
            col_idx = list(pdf_device_ad_pos_mismatches.columns).index(col)
            col_letter = chr(65 + col_idx)
            cell_range = f"{col_letter}2:{col_letter}{len(pdf_device_ad_pos_mismatches) + 1}"

            ws13.conditional_format(
                cell_range,
                {
                    "type": "cell",
                    "criteria": ">",
                    "value": 0,
                    "format": red_format,
                },
            )

    # --------------------------------------
    # TAB 14: Parse Demo Band Performance Mismatches
    # --------------------------------------
    pdf_demo_mismatches = to_pandas_capped(df_demo_mismatches, MAX_ROWS)
    sheet_name_14 = "demo_band_performance_mismatches"
    pdf_demo_mismatches.to_excel(writer, sheet_name=sheet_name_14[:31], index=False)

    ws14 = writer.sheets[sheet_name_14[:31]]

    columns_to_highlight = ["mismatch_percent_variance"]

    for col in columns_to_highlight:
        if col in pdf_demo_mismatches.columns:
            col_idx = list(pdf_demo_mismatches.columns).index(col)
            col_letter = chr(65 + col_idx)
            cell_range = f"{col_letter}2:{col_letter}{len(pdf_demo_mismatches) + 1}"

            ws14.conditional_format(
                cell_range,
                {
                    "type": "cell",
                    "criteria": ">",
                    "value": 0,
                    "format": red_format,
                },
            )

    # --------------------------------------
    # TAB 15: Parse Ad Unit Mismatches
    # --------------------------------------
    pdf_ad_unit_mismatches = to_pandas_capped(df_ad_unit_mismatches, MAX_ROWS)
    sheet_name_15 = "ad_unit_performance_mismatches"
    pdf_ad_unit_mismatches.to_excel(writer, sheet_name=sheet_name_15[:31], index=False)

    ws15 = writer.sheets[sheet_name_15[:31]]

    columns_to_highlight = ["mismatch_percent_variance"]

    for col in columns_to_highlight:
        if col in pdf_ad_unit_mismatches.columns:
            col_idx = list(pdf_ad_unit_mismatches.columns).index(col)
            col_letter = chr(65 + col_idx)
            cell_range = f"{col_letter}2:{col_letter}{len(pdf_ad_unit_mismatches) + 1}"

            ws15.conditional_format(
                cell_range,
                {
                    "type": "cell",
                    "criteria": ">",
                    "value": 0,
                    "format": red_format,
                },
            )

    # --------------------------------------
    # TAB 16: Parse Creative Performance Mismatches
    # --------------------------------------
    pdf_creative_mismatches = to_pandas_capped(df_creative_mismatches, MAX_ROWS)
    sheet_name_16 = "creative_performance_mismatches"
    pdf_creative_mismatches.to_excel(writer, sheet_name=sheet_name_16[:31], index=False)

    ws16 = writer.sheets[sheet_name_16[:31]]

    columns_to_highlight = ["mismatch_percent_variance"]

    for col in columns_to_highlight:
        if col in pdf_creative_mismatches.columns:
            col_idx = list(pdf_creative_mismatches.columns).index(col)
            col_letter = chr(65 + col_idx)
            cell_range = f"{col_letter}2:{col_letter}{len(pdf_creative_mismatches) + 1}"

            ws16.conditional_format(
                cell_range,
                {
                    "type": "cell",
                    "criteria": ">",
                    "value": 0,
                    "format": red_format,
                },
            )

    # --------------------------------------
    # TAB 17: Parse Content Performance Mismatches
    # --------------------------------------
    pdf_content_mismatches = to_pandas_capped(df_content_mismatches, MAX_ROWS)
    sheet_name_17 = "content_performance_mismatches"
    pdf_content_mismatches.to_excel(writer, sheet_name=sheet_name_17[:31], index=False)

    ws17 = writer.sheets[sheet_name_17[:31]]

    columns_to_highlight = ["mismatch_percent_variance"]

    for col in columns_to_highlight:
        if col in pdf_content_mismatches.columns:
            col_idx = list(pdf_content_mismatches.columns).index(col)
            col_letter = chr(65 + col_idx)
            cell_range = f"{col_letter}2:{col_letter}{len(pdf_content_mismatches) + 1}"

            ws17.conditional_format(
                cell_range,
                {
                    "type": "cell",
                    "criteria": ">",
                    "value": 0,
                    "format": red_format,
                },
            )

    # --------------------------------------
    # TAB 18: Parse Campaign Summary Mismatches
    # --------------------------------------
    pdf_summary_mismatches = to_pandas_capped(df_summary_mismatches, MAX_ROWS)
    sheet_name_18 = "campaign_summary_mismatches"
    pdf_summary_mismatches.to_excel(writer, sheet_name=sheet_name_18[:31], index=False)

    ws18 = writer.sheets[sheet_name_18[:31]]

    columns_to_highlight = ["mismatch_percent_variance", "threshold_variance"]

    for col in columns_to_highlight:
        if col in pdf_summary_mismatches.columns:
            col_idx = list(pdf_summary_mismatches.columns).index(col)
            col_letter = chr(65 + col_idx)
            cell_range = f"{col_letter}2:{col_letter}{len(pdf_summary_mismatches) + 1}"

            ws18.conditional_format(
                cell_range,
                {
                    "type": "cell",
                    "criteria": ">",
                    "value": 0,
                    "format": red_format,
                },
            )

    # --------------------------------------
    # TAB 19: Parse Campaign Summary Mismatches
    # --------------------------------------
    pdf_ad_position_mismatches = to_pandas_capped(df_ad_position_mismatches, MAX_ROWS)
    sheet_name_19 = "ad_position_analysis_mismatches"
    pdf_ad_position_mismatches.to_excel(writer, sheet_name=sheet_name_19[:31], index=False)

    ws19 = writer.sheets[sheet_name_19[:31]]

    columns_to_highlight = ["mismatch_percent_variance"]

    for col in columns_to_highlight:
        if col in pdf_ad_position_mismatches.columns:
            col_idx = list(pdf_ad_position_mismatches.columns).index(col)
            col_letter = chr(65 + col_idx)
            cell_range = f"{col_letter}2:{col_letter}{len(pdf_ad_position_mismatches) + 1}"

            ws19.conditional_format(
                cell_range,
                {
                    "type": "cell",
                    "criteria": ">",
                    "value": 0,
                    "format": red_format,
                },
            )

    # --------------------------------------
    # TAB 20: Parse Campaign Summary Mismatches
    # --------------------------------------
    pdf_pkg_perf_threshold = to_pandas_capped(df_pkg_perf_threshold, MAX_ROWS)
    sheet_name_20 = "package_performance_threshold"
    pdf_pkg_perf_threshold.to_excel(writer, sheet_name=sheet_name_20[:31], index=False)

    ws20 = writer.sheets[sheet_name_20[:31]]

    columns_to_highlight = ["threshold_1P_delivery_percent_variance", "threshold_3P_delivery_percent_variance"]

    for col in columns_to_highlight:
        if col in pdf_pkg_perf_threshold.columns:
            col_idx = list(pdf_pkg_perf_threshold.columns).index(col)
            col_letter = chr(65 + col_idx)
            cell_range = f"{col_letter}2:{col_letter}{len(pdf_pkg_perf_threshold) + 1}"

            ws20.conditional_format(
                cell_range,
                {
                    "type": "cell",
                    "criteria": ">",
                    "value": 0,
                    "format": red_format,
                },
            )

print(f"✅ Excel written with conditional formatting: {OUT_PATH_DBFS}")

# COMMAND ----------

email_body_html = f"""
<html>
  <body style="font-family: Arial, sans-serif; font-size: 14px;">
    <p>Hello Team,</p>

    <p>Please find attached the <b>WRAP validation report</b> (Excel) containing the following tabs:</p>
    <ul>
      <li>aos_campaign_validations</li>
      <li>camaign_reporting_first_party_validations</li>
      <li>camaign_reporting_third_party_validations</li>
    </ul>

    <p><b>Summary:</b></p>
    <ul>
      {''.join([f"<li>{line}</li>" for line in summary_lines])}
    </ul>

    <p>
      <b>Variance Threshold:</b> Greater than 10% for percentage variance fields.
    </p>

    <p>
      Please review the highlighted cells (in RED) within the Excel file where applicable.
    </p>

    <br>
    <p>Thanks,<br>
    Databricks Automated Validation Job</p>
  </body>
</html>
"""

# COMMAND ----------

# =========================
# 4) Email with attachment + summary
# =========================
def send_email(subject, html_body, to_addresses, cc_addresses, from_address,
               attachment_path=None,
               aws_profile='databricks-cpe-dev',
               aws_region='us-west-2'):

    msg = MIMEMultipart()
    msg['Subject'] = subject
    msg['From'] = from_address
    msg['To'] = ",".join(to_addresses)
    msg['Cc'] = ",".join(cc_addresses)

    # Add HTML body
    msg.attach(MIMEText(html_body, 'html'))

    # Attach file if provided
    if attachment_path:
        with open(attachment_path, "rb") as f:
            part = MIMEBase("application", "vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            part.set_payload(f.read())
        encoders.encode_base64(part)
        part.add_header(
            "Content-Disposition",
            f'attachment; filename="{attachment_path.split("/")[-1]}"'
        )
        msg.attach(part)

    # Send email via SES
    session = boto3.Session(profile_name=aws_profile)
    ses = session.client('ses', region_name=aws_region)

    ses.send_raw_email(
        Source=from_address,
        Destinations=to_addresses + cc_addresses,
        RawMessage={'Data': msg.as_string()}
    )

    print("Email sent successfully")

# COMMAND ----------

send_email(
    subject=EMAIL_SUBJECT,
    html_body=email_body_html,
    to_addresses=TO_EMAILS,
    cc_addresses=CC_EMAILS,
    from_address=FROM_EMAIL,
    attachment_path=OUT_PATH_LOCAL
)