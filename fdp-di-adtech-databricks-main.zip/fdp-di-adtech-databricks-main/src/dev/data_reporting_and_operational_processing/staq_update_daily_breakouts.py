# Databricks notebook source
# COMMAND ----------

# MAGIC %run "/Workspace/Users/prajwal.harikishor@fox.com/fdp-di-adtech-databricks/src/dev/data_reporting_and_operational_processing/alert"

# COMMAND ----------

from datetime import datetime, timedelta
import pandas as pd
import boto3
from typing import Any
import csv

# COMMAND ----------

def find_staq_file(report_date: datetime) -> str:
    session = boto3.Session(profile_name=aws_profile)
    s3 = session.client('s3')

    staq = 'STAQ_Adjuster_Daily_TEST_Last_7_Days_' + report_date.strftime('%Y-%m-%d')

    paginator = s3.get_paginator('list_objects_v2')
    page_iterator = paginator.paginate(Bucket=staq_bucket)

    for page in page_iterator:
        for obj in page.get('Contents', []):
            if staq in obj['Key']:
                return obj['Key']

def generate_dates(process_start_date: str, process_end_date: str):
    dates = pd.date_range(datetime.strptime(process_start_date, '%Y-%m-%d'), datetime.strptime(process_end_date,  '%Y-%m-%d'), freq='D')
    return dates

def months_in_period(dates):
    months = []
    for date in dates:
        months.append(date.replace(day=1))
    return set(months)

# COMMAND ----------

def update_daily_breakouts(file_path: str) -> None:
    last_n = pd.read_csv(
        f's3://{staq_bucket}/{file_path}',
        dtype={
            'Ad Unit ID': 'float64',
            '3rd Party Server': 'object',
            'Impressions (3rd Party)': 'float64',
            'Line Item ID': 'object',
            'Line Item Name': 'object',
            'Advertiser ID': 'object',
            'Advertiser Name': 'object',
            'Order ID': 'float64',
            'Order Name': 'object',
            '3rd Party Creative Id': 'object',
        },
        parse_dates=['Delivered Date'],
        encoding='utf-8',
        storage_options={'profile': aws_profile},
        quotechar='"',
        doublequote=True,
        quoting=csv.QUOTE_MINIMAL
    ).astype(
        {
            'Line Item ID': 'str',
            'Line Item Name': 'str',
            'Advertiser ID': 'str',
            'Advertiser Name': 'str',
            'Order Name': 'str',
            'Campaign Identifier': 'str',
            'Associated Line Item ID': 'str',
            '3rd Party Creative Id': 'str',
        }
    ).replace({'nan': ''}).dropna(subset=['Ad Unit ID']).astype({'Ad Unit ID': 'int64'})
    last_n['Campaign Identifier'] = pd.to_numeric(last_n['Campaign Identifier'], errors='coerce')
    last_n.fillna(
        {
            'Campaign Identifier': -1,
        },
        inplace=True
    )

    last_n['Impressions (3rd Party)'] = last_n['Impressions (3rd Party)'].fillna(0).astype('int64')

    missing_columns = [
        '3rd Party Non-Billable Impressions',
        '3rd Party Audible and Fully On-Screen for Half of Duration Impressions',
        '3rd Party Audible and Fully On-Screen for Half of Duration Rate',
        '3rd Party Full Measurable Impressions',
        'Full Measurable Impressions',
        'Impressions Analyzed',
        '3rd Party Measurable Impressions',
        '3rd Party Valid Impressions',
        '3rd Party Valid, Audible and Fully On-Screen for Half of the Duration Impressions (15 sec)',
        '3rd Party Valid, Audible and Fully On-Screen for Half of the Duration Rate (15 sec)',
        '3rd Party Valid and Viewable Impressions',
        'Report End Date',
        'Report Start Date'
    ]

    for col in missing_columns:
        if col == 'Report End Date' or col == 'Report Start Date':
            last_n[col] = last_n['Delivered Date']
        else:
            last_n[col] = 0

    last_n['Delivered Date'] = last_n['Delivered Date'].astype('str')

    last_n.rename(
        {
            'Ad Unit ID': 'Ad Unit Id',
            'Line Item ID': '3P Line Item ID',
            'Line Item Name': '3P Line Item Name',
            'Advertiser ID': '3P Advertiser ID',
            'Advertiser Name': '3P Advertiser Name',
            'Order ID': '3P Order ID',
            'Order Name': '3P Order Name',
        },
        axis=1,
        inplace=True,
    )

    for date, df in last_n.groupby('Report Start Date'):
        dt = date.strftime('%Y-%m-%d')
        parquet_path = f's3://{drop_bucket}/staq/daily/dt={dt}/staq_daily_{dt}.parquet'

        df.to_parquet(parquet_path, index=False, compression='gzip', storage_options={'profile': aws_profile})
        print(f'Updated daily partition dt={dt}')

def update_monthly_breakouts(month: datetime) -> None:
    dataframes = []
    current_date = month
    while current_date.month == month.month:
        try:
            dt = current_date.strftime('%Y-%m-%d')

            parquet_for_current_date = f's3://{drop_bucket}/staq/daily/dt={dt}/staq_daily_{dt}.parquet'

            df = pd.read_parquet(parquet_for_current_date, storage_options={'profile': aws_profile})
            df['Campaign Identifier'] = pd.to_numeric(df['Campaign Identifier'], errors='coerce')
            df.fillna(
                {
                    'Campaign Identifier': -1,
                },
                inplace=True
            )

            dataframes.append(df)
        except FileNotFoundError:
            pass
        current_date += timedelta(days=1)

    if len(dataframes)>=1:
        dataframe = pd.concat(dataframes)
    else:
        return

    dataframe['Clicks'] = 0
    dataframe['Clicks (3rd Party)'] = 0

    dt = month.strftime('%Y-%m')

    parquet_for_current_month = f's3://{drop_bucket}/staq/monthly/dt={dt}/staq_monthly_{dt}.parquet'
    dataframe.to_parquet(parquet_for_current_month, index=False, compression='gzip', storage_options={'profile': aws_profile})
    print(f'Updated monthly partition dt={dt}')

# COMMAND ----------

if __name__ == '__main__':
    report_date = dbutils.widgets.get('date')
    global drop_bucket, aws_profile, staq_bucket
    drop_bucket = dbutils.widgets.get('drop_bucket')
    aws_profile = dbutils.widgets.get('aws_profile')
    staq_bucket = dbutils.widgets.get('staq_bucket')
    try:
        process_start_date = dbutils.widgets.get('process_start_date')
        process_end_date = dbutils.widgets.get('process_end_date')
    except:
        process_start_date = report_date
        process_end_date = report_date

    def parse_date(date: str) -> bool:
        format = "%Y-%m-%d"
        try:
            res = bool(datetime.strptime(date, format))
        except ValueError:
            res = False
        return res

    assert parse_date(report_date), "Invalid date format, should be in YYYY-MM-DD format"
    assert parse_date(process_start_date), "Invalid date format, should be in YYYY-MM-DD format"
    assert parse_date(process_end_date), "Invalid date format, should be in YYYY-MM-DD format"
    assert datetime.strptime(process_start_date, "%Y-%m-%d") <= datetime.strptime(process_end_date, "%Y-%m-%d"), "process_start_date should be less than or equal to process_end_date"

    report_date = datetime.strptime(report_date, "%Y-%m-%d")

    try:
        if process_start_date != process_end_date:
            dates_to_process = generate_dates(process_start_date, process_end_date)
            for processing_date in dates_to_process:
                staq = find_staq_file(processing_date)
                if staq:
                    update_daily_breakouts(staq)
                else:
                    print('Missing Staq file for date: ', processing_date)
            months = months_in_period(dates_to_process)
            for month in months:
                if report_date - timedelta(days=1) > month:
                    update_monthly_breakouts(month)
                else:
                    data_begin_date = report_date - timedelta(days=1)
                    month_to_update = data_begin_date.replace(day=1)
                    if month_to_update in months:
                        # Already processed
                        pass
                    else:
                        update_monthly_breakouts(month_to_update)
        else:
            staq = find_staq_file(datetime.strptime(process_end_date, '%Y-%m-%d'))
            update_daily_breakouts(staq)
            data_begin_date = report_date - timedelta(days=1)
            if data_begin_date < datetime.strptime(process_end_date, '%Y-%m-%d').replace(day=1):
                month_to_update = data_begin_date.replace(day=1)
            else:
                month_to_update = datetime.strptime(process_end_date, '%Y-%m-%d').replace(day=1)
            update_monthly_breakouts(month_to_update)
    except Exception as error:
        alert = Alert()
        alert.send('Update Daily 3P Breakouts', f'{type(error).__name__}: {error}')
        dbutils.notebook.exit(f'ERROR!!! - {error}')