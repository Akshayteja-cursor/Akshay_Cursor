# Databricks notebook source
# MAGIC %run "/Workspace/Users/prajwal.harikishor@fox.com/fdp-di-adtech-databricks/src/dev/data_reporting_and_operational_processing/core"

# COMMAND ----------

# MAGIC %run "/Workspace/Users/prajwal.harikishor@fox.com/fdp-di-adtech-databricks/src/dev/data_reporting_and_operational_processing/alert"

# COMMAND ----------

from datetime import datetime, timedelta
import io
import boto3
import pandas as pd
import numpy as np
import traceback


# COMMAND ----------

def find_staq_file(report_date: datetime) -> str:
    session = boto3.Session(profile_name=aws_profile)
    s3 = session.client('s3')

    staq = 'STAQ_Adjuster_Pacing_YTD_All_Lines_' + report_date.strftime('%Y-%m-%d')

    paginator = s3.get_paginator('list_objects_v2')
    page_iterator = paginator.paginate(Bucket=staq_bucket, Prefix=staq)

    latest_file = None
    latest_modified = None

    for page in page_iterator:
        for obj in page.get('Contents', []):
            if staq in obj['Key']:
                if latest_modified is None or obj['LastModified'] > latest_modified:
                    latest_modified = obj['LastModified']
                    latest_file = obj['Key']

    if latest_file:
        return latest_file
    

# COMMAND ----------

def osi(row: pd.Series, report_date: datetime, type: str) -> float:
    if type == '1p':
        if row['Ad Server Impressions'] == 0 or row['Contracted Quantity'] == 0:
            return 0
        qty = row['Ad Server Impressions']/row['Contracted Quantity']
    else:
        if row['Impressions (3rd Party)'] == 0 or row['Contracted Quantity'] == 0:
            return 0
        qty = row['Impressions (3rd Party)']/row['Contracted Quantity']
    days_elapsed = report_date - row['Line Item Start Date'] + timedelta(days=1)
    flight = row['Line Item End Date'] - row['Line Item Start Date'] + timedelta(days=1)

    if report_date < row['Line Item End Date']:
        return qty/(days_elapsed/flight)
    else:
        return qty
    
def metrics_calculaition(row: pd.Series, calculation: str) -> float:
    if calculation == 'Total Error Rate':
        if row['Total Impressions'] + row['Total Error Count'] == 0:
            return 0
        return row['Total Error Count']/(row['Total Impressions']+row['Total Error Count'])
    
    if calculation == '3rd Party CTR':
        if row['Impressions (3rd Party)'] == 0:
            return 0
        return row['Clicks (3rd Party)']/row['Impressions (3rd Party)']
    
    if calculation == 'Buffer':
        if row['Contracted Quantity'] == 0:
            return 0
        return (row['Ad Server Booked Impressions']-row['Contracted Quantity'])/row['Contracted Quantity']
    
    if calculation == 'Discrepancy':
        if row['Impressions (3rd Party)'] == 0:
            return 0
        return (row['Impressions (3rd Party)']-row['Ad Server Impressions'])/row['Impressions (3rd Party)']


def calculate_metrics(df: pd.DataFrame, report_date: datetime) -> pd.DataFrame:
    df.loc[:, 'Total Error Rate'] = df.apply(metrics_calculaition, args=('Total Error Rate', ), axis=1)
    df.loc[:, '3rd Party CTR'] = df.apply(metrics_calculaition, args=('3rd Party CTR', ), axis=1)
    df.loc[:, 'Ad Server Booked Impressions'] = df['Quantity']
    df.loc[:, 'Buffer'] = df.apply(metrics_calculaition, args=('Buffer', ), axis=1)
    df.loc[:, 'Discrepancy'] = df.apply(metrics_calculaition, args=('Discrepancy', ), axis=1)
    df.loc[:, 'Current First Party OSI'] = df.apply(osi, args=(report_date, '1p'), axis=1)
    df.loc[:, 'Current Third Party OSI'] = df.apply(osi, args=(report_date, '3p'), axis=1)

    metric_columns = [
        'Total Error Rate',
        '3rd Party CTR',
        'Ad Server Booked Impressions',
        'Buffer',
        'Discrepancy',
        'Current First Party OSI',
        'Current Third Party OSI',
    ]

    df = df.fillna({col:0 for col in metric_columns})

    for col in metric_columns:
        df[col] = df[col].replace([np.inf,  -np.inf], 0)

    return df

def format_news_pacing(df: pd.DataFrame, report_date: datetime) -> pd.DataFrame:
    # Filter the lines for the current year
    df = df[df['Line Item End Date'] >= report_date.replace(month=1, day=1)]

    df = df.loc[:,
                [
                    'Advertiser',
                    'Order',
                    'Line Item Name',
                    'Line Item Start Date',
                    'Line Item End Date',
                    'Rate',
                    'Goal Quantity',
                    'Contracted Quantity',
                    'Delivery Indicator',
                    'Primary Salesperson Full Name',
                    'Ad Server Impressions',
                    'Impressions (3rd Party)',
                    'Clicks (3rd Party)',
                    '3rd Party CTR',
                    'Buffer',
                    'Discrepancy',
                    'Current First Party OSI',
                    'Current Third Party OSI',
                    'Total Error Count',
                    'Total Error Rate',
                ]]
    
    df = df.dropna(subset=['Line Item Name'])
    df = df.rename(columns={'Primary Salesperson Full Name': 'Salesperson'})

    return df
    
def news_lifetime_delivery(ad_juster_pacing_news: str, report_date: datetime) -> pd.DataFrame:
    global drop_bucket
    s3_dir = f's3://{drop_bucket}/'
    operative_filename = 'Operative_OMS.parquet'
    operative = s3_dir + 'processed/' + operative_filename
    gam_file_name = 'GAM_Lifetime_Delivery.parquet'
    gam_file = s3_dir + 'processed/' + gam_file_name
    adops_lifetime_filename = 'AdOps_Reporting_Lifetime_Delivery.parquet'
    adops_lifetime = s3_dir + 'processed/' + adops_lifetime_filename

    op_oms = pd.read_parquet(operative, storage_options={'profile': aws_profile})
    op_fw_adj = pd.read_parquet(adops_lifetime, storage_options={'profile': aws_profile})
    gam = read_gam_lifetime(gam_file, op_oms)
    adjuster_news = read_adjuster_news(ad_juster_pacing_news, op_oms, skiprows=0)
    

    ###########################################################
    with io.BytesIO() as output:
        adjuster_news.to_parquet(output, index=False)
        adjuster_news_data = output.getvalue()

    session = boto3.Session(profile_name=aws_profile)
    s3_client = session.client('s3')
    s3_bucket = drop_bucket
    s3_key = 'processed/' + f'adjuster_news_data_{report_date.year}.parquet'
    s3_client.put_object(Bucket=s3_bucket, Body=adjuster_news_data, Key=s3_key,)

    ###########################################################################

    op_gam_fw_adj = merge_news_delivery_data(op_oms, gam, adjuster_news, op_fw_adj)
    

    op_gam_fw_adj = calculate_metrics(op_gam_fw_adj, report_date)

    return op_gam_fw_adj

def export_news_lifetime_delivery(op_gam_fw_adj: pd.DataFrame, report_date: datetime) -> str:
    with io.BytesIO() as output:
        op_gam_fw_adj.to_parquet(output, index=False)
        op_gam_fw_adj_data = output.getvalue()

    session = boto3.Session(profile_name=aws_profile)
    s3_client = session.client('s3')
    global drop_bucket
    s3_bucket = drop_bucket
    s3_key = 'processed/' + f'AdOps_News_Reporting_Lifetime_Delivery_{report_date.year}.parquet'
    s3_client.put_object(
        Bucket=s3_bucket,
        Body=op_gam_fw_adj_data,
        Key=s3_key,
    )

    return s3_key

def export_news_pacing_report(op_gam_fw_adj: pd.DataFrame, report_date: datetime) -> str:
    news_pacing_report_filename = 'News_Pacing_Report_' + report_date.strftime('%Y%m%d')
    global drop_bucket
    op_gam_fw_adj = format_news_pacing(op_gam_fw_adj, report_date)

    with io.BytesIO() as output:
        with pd.ExcelWriter(
            output,
            datetime_format='MM/dd/yyyy',
            engine='xlsxwriter',
            options={'strings_to_numbers': True},
        ) as writer:
            workbook = writer.book
            pct_fmt = workbook.add_format({'num_format': '0.00%'})
            report_pct_cols = ['3rd Party CTR', 'Buffer', 'Discrepancy', 'Current First Party OSI', 'Current Third Party OSI']

            op_gam_fw_adj.to_excel(writer, sheet_name='News Pacing Report', index=False)
            worksheet = writer.sheets['News Pacing Report']
            set_col_fmt(
                pct_fmt,
                worksheet,
                op_gam_fw_adj,
                report_pct_cols
            )

        news_pacing_report_data = output.getvalue()

    session = boto3.Session(profile_name=aws_profile)
    s3_client = session.client('s3')
    s3_bucket = drop_bucket
    s3_key = 'reports/' + news_pacing_report_filename + '.xlsx'
    s3_client.put_object(
        Bucket=s3_bucket,
        Body=news_pacing_report_data,
        Key=s3_key,
    )

    return s3_key

# COMMAND ----------

def adops_news_lifetime_delivery(date: datetime, staq_file: str) -> None:
    global drop_bucket
    data_dir = f's3://{staq_bucket}/'
    ad_juster_pacing_news = data_dir + staq_file
    report_date = datetime.combine(date, datetime.min.time())
    news_lifetime_delivery_data = news_lifetime_delivery(ad_juster_pacing_news, report_date)
    export_news_lifetime_delivery(news_lifetime_delivery_data, report_date)
    out = export_news_pacing_report(news_lifetime_delivery_data, report_date)
    write_xcom_value('AdOps News Lifetime Delivery', str(out))

# COMMAND ----------

if __name__ == '__main__':
    date = dbutils.widgets.get('date')
    global drop_bucket, aws_profile
    drop_bucket = dbutils.widgets.get('drop_bucket')
    aws_profile = dbutils.widgets.get('aws_profile')
    staq_bucket = dbutils.widgets.get('staq_bucket')

    def parse_date(date: str) -> bool:
        format = "%Y-%m-%d"
        try:
            res = bool(datetime.strptime(date, format))
        except ValueError:
            res = False
        return res

    assert parse_date(date), "Invalid date format, should be in YYYY-MM-DD format"

    report_date = datetime.strptime(date, "%Y-%m-%d")

    staq_file = find_staq_file(report_date)
    print(staq_file)

    try:
        adops_news_lifetime_delivery(report_date, staq_file)
    except Exception as error:
        alert = Alert()
        alert.send('AdOps News Lifetime Delivery', f'{type(error).__name__}: {error}')
        #dbutils.notebook.exit(f'ERROR!!! - {error}')
        error_details = traceback.format_exc()
        dbutils.notebook.exit(error_details)
