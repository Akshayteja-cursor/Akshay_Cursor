# Databricks notebook source
# COMMAND ----------

# MAGIC %run "/Workspace/Users/prajwal.harikishor@fox.com/fdp-di-adtech-databricks/src/dev/data_reporting_and_operational_processing/core"

# COMMAND ----------

# MAGIC %run "/Workspace/Users/prajwal.harikishor@fox.com/fdp-di-adtech-databricks/src/dev/data_reporting_and_operational_processing/alert"

# COMMAND ----------

from typing import Dict, List, Optional, cast, Any
import io
from datetime import datetime, timedelta
from collections import OrderedDict
import pandas as pd
import numpy as np
import boto3

# COMMAND ----------

def prod_sys_lookup() -> pd.DataFrame:
    global drop_bucket
    s3_dir = f's3://{drop_bucket}/'
    if source == 'OP1':
        prod_sys_filename = 'Production System Mapping.xlsx'
    else:
        prod_sys_filename = 'Production System Mapping AOS.xlsx'
    prod_sys_file = s3_dir + 'lookup/' + prod_sys_filename
    prod_sys_mapping = pd.read_excel(
        prod_sys_file,
        usecols=[
            'Production System ID',
            'Name',
        ],
        dtype={
            'Production System ID': 'object',
            'Name': 'object',
        },
        index_col='Name',
        storage_options={'profile': aws_profile},
    ).to_dict()['Production System ID']
    return prod_sys_mapping


def prod_sys_id(row: pd.Series, prod_sys_mapping: Dict[Any, Any], name_col: str) -> Any:
    if row[name_col] in prod_sys_mapping:
        return prod_sys_mapping[row[name_col]]
    return '-1'

# COMMAND ----------

def apply_vpvh_elimination(df: pd.DataFrame, type: str) -> pd.DataFrame:
    df['Demo Comp Temp'] = np.where(df['Placement Property'] == 'FOX DAI VOD',
                                    -1, df['Demo Comp'])

    df['Demo Comp 1'] = np.where(df['Placement Property'] == 'FOX DAI VOD',
                                 df.groupby('Parent Sales Line Item ID')['Demo Comp Temp'].transform('max'), df['Demo Comp'])

    df['Demo Comp 2'] = np.where(df['Placement Property'] == 'FOX DAI VOD',
                                 np.where(df['Parent Sales Line Item ID'] == df['Sales Line Item ID'],
                                          df['Planned Demo Comp'], df['Demo Comp 1']),
                                          df['Demo Comp 1'])
    
    df['count_1'] = df.groupby(['Parent Sales Line Item ID', 'Placement Property'])['Placement Property'].transform(len)
    df['count_2'] = df.groupby(['Parent Sales Line Item ID'])['Parent Sales Line Item ID'].transform(len)

    df['Demo Comp 3'] = np.where(df['Placement Property'] == 'FOX DAI VOD',
                                 np.where(df['count_1']>1,
                                          np.where(df['count_1'] == df['count_2'],
                                                   df['Planned Demo Comp'], df['Demo Comp 2']),
                                          df['Demo Comp 2']),
                                 df['Demo Comp 2'])
    
    df['Demo Comp 4'] = np.where(df['Placement Property'] == 'FOX DAI VOD',
                                np.where(df['Is Audience Target'] == True,
                                          0, df['Demo Comp 3']),
                                 df['Demo Comp 3'])

    df['Demo Comp 5'] = np.where(df['Placement Property'] == 'FOX DAI VOD',
                                 np.where(df['Billable Metric'] == 'Bill on Contract',
                                          df['Demo Comp'], df['Demo Comp 4']),
                                 df['Demo Comp 4'])
    
    df['Demo Comp New'] = np.where(df['Placement Property'] == 'FOX DAI VOD',
                                   np.where(df['Billable Metric'] == 'Absolute A',
                                            1.2, df['Demo Comp 5']),
                                   df['Demo Comp 5'])
    
    df['Demo Comp New'] = df['Demo Comp New'].astype('float64')

    df.fillna(
        {
            'Impression Goal': 0,
            'Demo Comp New': 0,
        },
        inplace=True
    )

    df['check_absA/audT'] = np.where(df['Is Audience Target'] == True,
                                     True,
                                     np.where(df['Billable Metric'] == 'Absolute A',
                                              True, False))

    df['Billable Metric 1'] = np.where(df['Placement Property'] == 'FOX DAI VOD',
                                         np.where(df['check_absA/audT'] == True,
                                                  np.where(df['Billable Metric'] == 'Absolute A',
                                                           'Absolute A',
                                                           np.where(df['Billable Third Party Server'] == '1st Party',
                                                                    '1P Audience Target', '3P Audience Target')),
                                                  np.where(df['Demo Band'] != 'P2+',
                                                           np.where(df['Billable Third Party Server'] == '1st Party',
                                                                    '1P Demo Imps', '3P Demo Imps'),
                                                           np.where(df['Billable Third Party Server'] == '1st Party',
                                                                   '1P CoView Imps', '3P CoView Imps'))),
                                         df['Billable Metric'])

    df['Billable Metric New'] = np.where(df['Placement Property'] == 'FOX DAI VOD',
                                         np.where(df['Billable Metric'] == 'Bill on Contract',
                                                  'Bill on Contract',
                                                  df['Billable Metric 1']),
                                         df['Billable Metric 1'])

    df['Billable Metric New'] = np.where(df['Product Name'].str.contains('SOV', regex=True),
                                         'SOV', df['Billable Metric New'])

    df['Billable Metric New'] = np.where(df['Implied Billable Metric'].str.contains('CoView', regex=True),
                                         df['Implied Billable Metric'], df['Billable Metric New'])

    columns_to_drop = ['Demo Comp',
                       'Demo Comp Temp',
                       'Demo Comp 1',
                       'Demo Comp 2',
                       'Demo Comp 3',
                       'Demo Comp 4',
                       'Demo Comp 5',
                       'count_1',
                       'count_2',
                       'Billable Metric',
                       'Billable Metric 1',
                       'check_absA/audT']

    if type == '1p':

        df['1P Demo Imps New'] = np.where(df['Placement Property'] == 'FOX DAI VOD',
                                          np.where(df['Demo Comp New'] != 0,
                                                   df['1P Imps']*df['Demo Comp New'], df['1P Imps']),
                                          df['1P Demo Imps'])

        df['1P Demo Imps New'] = np.where(df['Product Name'].str.contains('SOV', regex=True),
                                          np.where(df['Impression Goal'] != 0,
                                                   df['Impression Goal'], df['1P Imps']),
                                          df['1P Demo Imps New'])

        columns_to_drop.append('1P Demo Imps')

    if type == '3p':

        df['3P Demo Imps New'] = np.where(df['Placement Property'] == 'FOX DAI VOD',
                                          np.where(df['Demo Comp New'] != 0,
                                                   df['3P Imps']*df['Demo Comp New'], df['3P Imps']),
                                          df['3P Demo Imps'])

        df['3P Demo Imps New'] = np.where(df['Product Name'].str.contains('SOV', regex=True),
                                          np.where(df['Impression Goal'] != 0,
                                                   df['Impression Goal'], df['3P Imps']),
                                          df['3P Demo Imps New'])

        columns_to_drop.append('3P Demo Imps')

    df.drop(columns=columns_to_drop, inplace=True, axis=1)

    if type == '1p':
        df.rename(
            {
                'Demo Comp New':'Demo Comp',
                'Billable Metric New':'Billable Metric',
                '1P Demo Imps New':'1P Demo Imps'
            },
            axis=1,
            inplace=True
        )

    if type == '3p':
        df.rename(
            {
                'Demo Comp New':'Demo Comp',
                'Billable Metric New':'Billable Metric',
                '3P Demo Imps New':'3P Demo Imps'
            },
            axis=1,
            inplace=True
        )

    return df


def apply_pg_billing(df: pd.DataFrame, date_range) -> pd.DataFrame:
    global drop_bucket
    s3_dir = f's3://{drop_bucket}/'
    fw_pg_filename = 'FW_PG_Lifetime_Delivery.parquet'
    fw_pg_file = s3_dir + 'processed/' + fw_pg_filename

    pg_billing = pd.read_parquet(fw_pg_file, storage_options={'profile': aws_profile})

    pg_billing = pg_billing.loc[pg_billing['Event Date'].isin(date_range), :]

    rename_cols = {
        'Deal ID': 'PG Deal ID',
        'Net Counted Ads': 'PG Impressions',
    }
    pg_billing.rename(rename_cols, axis=1, inplace=True)

    df = pd.merge(df, pg_billing, how='left', left_on='Placement ID', right_on='PG Deal ID')

    def is_pg_deal(row: pd.Series) -> bool:
        if row['Invoice Organization Name'] in {'FOX Corp Programmatic Guaranteed', 'FOX Corp Programmatic/Reseller Buys', 'FOX Corp Programmatic - Magnite', 'FOX Corp Programmatic - PubMatic'}:
            return True
        return False

    def billable_metric(row: pd.Series) -> str:
        if row['is_pg_deal'] and row['Sales Order Name'] is not None and 'evergreen' in row['Sales Order Name'].lower():
            return 'Programmatic Reseller Imps'
        if row['is_pg_deal'] and row['Programmatic Type'] is not None and 'programmatic guaranteed' in row['Programmatic Type'].lower():
            return "Programmatic Guaranteed Imps"
        if row['is_pg_deal'] and row['Invoice Organization Name'] is not None and 'programmatic guaranteed' in row['Invoice Organization Name'].lower():
            return "Programmatic Guaranteed Imps"
        return row['Billable Metric']

    df.loc[:, 'is_pg_deal'] = df.apply(is_pg_deal, axis=1)

    df.loc[:, 'Billable Metric'] = df.apply(billable_metric, axis=1)

    df['Programmatic Imps'] = np.where(df['is_pg_deal'] == True,
                                       df['PG Impressions'], 0)

    df['Report End Date'] = np.where(df['is_pg_deal'] == True,
                                     df['Event Date'], df['Report End Date'])
    
    df.fillna(
        {
            'Programmatic Imps': 0,
        },
        inplace=True,
    )

    return df


def apply_magnite_billing(df: pd.DataFrame, date_range) -> pd.DataFrame:
    global drop_bucket
    s3_dir = f's3://{drop_bucket}/'
    magnite_filename = 'Magnite_Lifetime_Delivery.parquet'
    magnite_file = s3_dir + 'processed/' + magnite_filename

    magnite_billing = pd.read_parquet(magnite_file, storage_options={'profile': aws_profile})

    magnite_billing = magnite_billing.loc[magnite_billing['Date'].isin(date_range), :]

    magnite_billing.loc[:, 'Deal ID'] = magnite_billing['Deal ID'].str.strip()

    magnite_billing.rename({'Deal ID':'Magnite Deal ID', 'Impressions':'Magnite Impressions', 'Total Gross Revenue':'Magnite Revenue'}, axis=1, inplace=True)

    def primary_placement_map(row: pd.Series) -> str:
        network_primary_placement_property_map = {
            'FOX Sports Streaming':'FOX Sports Streaming',
            'Tubi - One Fox':'Fox Sold Tubi',
            'FOX on Hulu':'FOX on Hulu',
            'FOXNow':'FOXNow',
            'FOX Business':'FOXBusiness.com',
            'FOX on Tubi':'FOX on Tubi',
            'FOX News':'FOXNews.com',
            'Fox SpringServe oRTB': '',
            'OneFox SpringServe oRTB brand': '',
            'Fox - Fox Television Stations - OneFox': 'Fox Sold FTS',
            'Fox - Weather - OneFox': 'FoxWeather.com',
            'FOX Weather': 'FoxWeather.com',
            'Tubi - One Fox- AAT Segments': '',
            'Fox Enterainment - OneFox - Segments': '',
            'OneFOX_AAT Segments': '',
        }

        try:
            return network_primary_placement_property_map[row['Network']]
        except:
            print('Unmapped Network - ',row['Network'])
            return ''

    def secondary_placement_map(row: pd.Series) -> str:
        network_secondary_placement_property_map = {
            'FOX Sports Streaming':'FOX Sports Clips',
            'Tubi - One Fox':'',
            'FOX on Hulu':'RON - Ent',
            'FOXNow':'RON - Ent',
            'FOX Business':'FOXNews.com',
            'FOX on Tubi':'FOX on Tubi',
            'FOX News':'RON - Ent',
            'Fox SpringServe oRTB': '',
            'OneFox SpringServe oRTB brand': '',
            'Fox - Fox Television Stations - OneFox': '',
            'Fox - Weather - OneFox': '',
            'FOX Weather': '',
            'Tubi - One Fox- AAT Segments': '',
            'Fox Enterainment - OneFox - Segments': '',
            'OneFOX_AAT Segments': '',
        }

        try:
            return network_secondary_placement_property_map[row['Network']]
        except:
            print('Unmapped Network - ',row['Network'])
            return ''

    magnite_billing.loc[:, 'Primary Placement Property'] = magnite_billing.apply(primary_placement_map, axis=1)
    magnite_billing.loc[:, 'Secondary Placement Property'] = magnite_billing.apply(secondary_placement_map, axis=1)

    def is_magnite_deal(row: pd.Series) -> bool:
        if row['Invoice Organization Name'] == 'FOX Corp Programmatic - Magnite':
            return True
        if row['Product Name'] is not None and ('PRG' in row['Product Name'] and 'Non Ad Served' in row['Product Name']):
            return True
        if row['Advertiser Name'] == 'MAGNITE':
            return True
        # if 'PRG' in row['Product Name'] and 'Non-Ad Served' in row['Product Name']:
        #     return True
        return False

    df.loc[:, 'is_magnite_deal'] = df.apply(is_magnite_deal, axis=1)

    def join_on_placement(row: pd.Series) -> bool:
        if row['is_magnite_deal'] == False:
            return False
        if row['Magnite Deal ID'] == None:
            return True
        if row['Primary Placement Property'] == '' and row['Secondary Placement Property'] == '':
            return True
        if row['Primary Placement Property'] == row['Placement Property']:
            return True
        if row['Secondary Placement Property'] == row['Placement Property']:
            return True
        return False

    magnite_billing = pd.merge(magnite_billing, df, how='left', left_on='Magnite Deal ID', right_on='Deal ID').reset_index(drop=True)
    magnite_billing.loc[:, 'join_on_placement'] = magnite_billing.apply(join_on_placement, axis=1)
    magnite_billing = magnite_billing[magnite_billing['join_on_placement'] == True]
    magnite_billing.rename({'Placement Property':'Magnite Placement Property'}, axis=1, inplace=True)
    magnite_billing = magnite_billing.loc[:, ['Date', 'Magnite Deal ID', 'Magnite Placement Property', 'Magnite Impressions', 'Magnite Revenue']]
    magnite_billing = magnite_billing.groupby(['Date', 'Magnite Deal ID', 'Magnite Placement Property']).sum().reset_index()

    df = pd.merge(df, magnite_billing, how='left', left_on=['Deal ID', 'Placement Property'], right_on=['Magnite Deal ID', 'Magnite Placement Property'])

    def billable_metric(row: pd.Series) -> str:
        if row['is_magnite_deal']:
            return 'Programmatic Guaranteed Imps'
        return row['Billable Metric']

    df.loc[:, 'Billable Metric'] = df.apply(billable_metric, axis=1)

    df['Programmatic Imps'] = np.where(df['is_magnite_deal'] == True,
                                       df['Magnite Impressions'], df['Programmatic Imps'])

    df['Report End Date'] = np.where(df['is_magnite_deal'] == True,
                                     df['Date'], df['Report End Date'])
    
    df.fillna(
        {
            'Programmatic Imps': 0,
        },
        inplace=True,
    )

    return df


def operative_billable(party: str, report_date: datetime) -> Dict[str, List[str]]:
    global drop_bucket
    data_dir = f's3://{drop_bucket}/processed/'
    if party == '1p':
        data_filename = 'freewheel_AdOps_Reporting_Daily_Delivery.parquet'
        op_fw_adj_daily = pd.read_parquet(data_dir + data_filename, storage_options={'profile': aws_profile})
    elif party == '3p':
        data_filename_1 = 'freewheel_AdOps_Reporting_Daily_Delivery.parquet'
        data_filename_2 = 'gam_AdOps_Reporting_Daily_Delivery.parquet'
        op_fw_adj_daily = pd.read_parquet(data_dir + data_filename_1, storage_options={'profile': aws_profile})
        op_gam_adj_daily = pd.read_parquet(data_dir + data_filename_2, storage_options={'profile': aws_profile})
        op_fw_adj_daily = pd.concat([op_fw_adj_daily, op_gam_adj_daily], ignore_index=True)

        # Remove lines that do not have 3p delivery or do not have a proper 3p server assigned
        op_fw_adj_daily = op_fw_adj_daily[op_fw_adj_daily['Impressions (3rd Party)'] != 0]
        op_fw_adj_daily = op_fw_adj_daily.dropna(subset=['Impressions (3rd Party)'])
        op_fw_adj_daily = op_fw_adj_daily.dropna(subset=['Operative 3rd Party Server'])
        op_fw_adj_daily = op_fw_adj_daily[
            (op_fw_adj_daily['Production System Name'] == op_fw_adj_daily['Billable Third Party Server']) \
            | (op_fw_adj_daily['Billable Third Party Server'].isna())
        ]
        op_fw_adj_daily = op_fw_adj_daily[
            ((op_fw_adj_daily['Operative 3rd Party Server'] != '1st Party') & (op_fw_adj_daily['Operative 3rd Party Server'] != 'FOX 1st Party'))
        ]

    def prod_sys_name(row: pd.Series) -> Optional[str]:
        if source == 'AOS':
            if row['Production System Name'] == '1st Party':
                return 'FOX 1st Party'
        if row['Production System Name'] == 'Programmatic Guaranteed Production System':
            return cast(str, row['Production System Name'])
        if row['Operative 3rd Party Server'] == 'DFA':
            return 'DCM'
        return cast(str, row['Operative 3rd Party Server'])

    op_fw_adj_daily.loc[:, 'Production System Name'] = op_fw_adj_daily.apply(prod_sys_name, axis=1)
    ps_lookup = prod_sys_lookup() #mapping needs to be provided by Rea Anna
    op_fw_adj_daily.loc[:, 'Production System ID'] = op_fw_adj_daily.apply(
        lambda row: prod_sys_id(row, ps_lookup, 'Production System Name'),
        axis=1,
    )

    # FreeWheel data and Operative data can be associated via 'Placement ID' for non-programmatic line and 'Deal ID' for programmatic lines
    op_fw_adj_daily_ds = op_fw_adj_daily.loc[~op_fw_adj_daily.loc[:, 'Placement ID'].isna(), :]
    op_fw_adj_daily_ds.loc[:, 'Placement ID'] = op_fw_adj_daily_ds.loc[:, 'Placement ID'].astype('int64')
    op_fw_adj_daily_pg = op_fw_adj_daily.loc[op_fw_adj_daily.loc[:, 'Placement ID'].isna(), :]
    op_fw_adj_daily_pg.loc[:, 'Placement ID'] = op_fw_adj_daily_pg.loc[:, 'Deal ID']
    op_fw_adj_daily = op_fw_adj_daily_ds.append(op_fw_adj_daily_pg)
    
    if party == '1p' or party == 'pg':
        return export_daily_1p(op_fw_adj_daily, report_date, party)
    if party == '3p':
        return export_daily_3p(op_fw_adj_daily_ds, report_date)
    raise ValueError('Party must be 1p, 3p or pg.')


def export_operative_billable(df: pd.DataFrame, basename: str, report_date: datetime) -> Dict[str, List[str]]:
    with io.StringIO() as output:
        df.to_csv(output, index=False, date_format='%Y-%m-%d')
        df_content = output.getvalue().encode('utf-8')

    filename = basename + report_date.strftime('%Y-%m-%d') + '.csv'

    operative_filenames = []

    global drop_bucket
    session = boto3.Session(profile_name=aws_profile)
    s3_client = session.client('s3')
    key = f'operative_billing/{filename}'
    operative_filenames.append(filename)
    s3_client.put_object(
        Bucket=drop_bucket,
        Body=df_content,
        Key=key,
    )

    if 'FreeWheel' in basename:
        dbutils.jobs.taskValues.set(key = "n_files_freewheel", value = str(len(operative_filenames)))
        dbutils.jobs.taskValues.set(key = "files_freewheel", value = str({'files': operative_filenames}))
    elif 'GoogleAdManager' in basename:
        dbutils.jobs.taskValues.set(key = "n_files_gam", value = str(len(operative_filenames)))
        dbutils.jobs.taskValues.set(key = "files_gam", value = str({'files': operative_filenames}))
    else:
        dbutils.jobs.taskValues.set(key = "n_files", value = str(len(operative_filenames)))
        dbutils.jobs.taskValues.set(key = "files", value = str({'files': operative_filenames}))
    print({'files': operative_filenames})
    return {'files': operative_filenames}


def export_daily_1p(op_fw_adj_daily: pd.DataFrame, report_date: datetime, party: str) -> Dict[str, List[str]]:
    op_fw_adj_daily['Insertion Order ID'] = op_fw_adj_daily['Insertion Order ID'].combine_first(op_fw_adj_daily['Sales Order ID'])
    op_fw_adj_daily['Insertion Order Name'] = op_fw_adj_daily['Insertion Order Name'].combine_first(op_fw_adj_daily['Sales Order Name'])
    op_fw_adj_daily['Placement Name'] = op_fw_adj_daily['Placement Name'].combine_first(op_fw_adj_daily['Sales Line Item Name'])
    op_fw_adj_daily['Placement Start Date'] = op_fw_adj_daily['Placement Start Date'].combine_first(op_fw_adj_daily['Sales Line Item Start Date'])
    op_fw_adj_daily['Placement End Date'] = op_fw_adj_daily['Placement End Date'].combine_first(op_fw_adj_daily['Sales Line Item End Date'])

    daily_1p_meta_cols = {
        'Production System ID': 'Production System ID',
        'Production System Name': 'Production System Name',
        'Report End Date': 'Delivered Date',
        'Advertiser ID': 'Advertiser ID',
        'Advertiser Name': 'Advertiser Name',
        'Insertion Order ID': 'Order ID',
        'Insertion Order Name': 'Order Name',
        'Placement ID': 'Line Item ID',
        'Placement Name': 'Line Item Name',
        'Placement Start Date': 'Start Date',
        'Placement End Date': 'End Date',
        'Net Unit Cost': 'Unit Cost',
        'Cost Method': 'Cost Method',
        'Sales Line Item ID': 'Associated Sales Line Item ID',
        'Deal ID': 'Deal ID',
        'FW - Deal Type': 'FW - Deal Type',
        'Production Line Item Status': 'Production Line Item Status',
        'Full PS Line Item IDs': 'Full PS Line Item IDs',
    }

    daily_1p_data_cols = OrderedDict({
        '1P Imps': 'Impressions',
        'Clicks': 'Clicks',
        'Actions': 'Actions',
        'Viewable Impressions': 'Viewable Impressions',
        '1P Demo Imps': 'CoV Impressions',
        '1P Equivalized Demo Imps': 'CoV Impressions Equivalized',
        '1P Viewability and Demo Imps': 'CoV Impressions Viewable',
        'Programmatic Imps': 'Programmatic Impressions',
        'Guaranteed Views': 'Guaranteed Views',
    })

    # Fill 0 for actions, viewable impressions and guaranteed views
    op_fw_adj_daily.loc[:, 'Actions'] = 0
    op_fw_adj_daily.loc[:, 'Viewable Impressions'] = 0
    op_fw_adj_daily.loc[:, 'Guaranteed Views'] = 0

    unit_types = list(daily_1p_data_cols.values())

    prev_month = datetime.today().month - 1 if datetime.today().month != 1 else 12
    bill_year = datetime.today().year - 1 if prev_month == 12 else datetime.today().year
    date_range = pd.date_range(
        start=datetime.combine(datetime.today(), datetime.min.time()).replace(month=prev_month, year=bill_year, day=1),
        end=datetime.combine(datetime.today(), datetime.min.time())
    )

    op_fw_adj_daily = apply_vpvh_elimination(op_fw_adj_daily, '1p')

    op_fw_adj_daily = apply_pg_billing(op_fw_adj_daily, date_range)

    op_fw_adj_daily = apply_magnite_billing(op_fw_adj_daily, date_range)

    op_fw_adj_daily = equivalize(op_fw_adj_daily, 'operative_1p')

    # Drop No Delivery Lines -> no point in ingesting them
    op_fw_adj_daily = op_fw_adj_daily.loc[(op_fw_adj_daily['1P Imps'] != 0) | (op_fw_adj_daily['Programmatic Imps'] != 0) , :]

    def get_prod_sys_name(row: pd.Series) -> str:
        if row['Production System Name'] == 'Programmatic Guaranteed Production System':
            return 'Programmatic Guaranteed Production System'
        return 'FreeWheel'

    def get_prod_sys_id(row: pd.Series) -> Any:
        if source == 'AOS':
            if row['Production System Name'] == 'Programmatic Guaranteed Production System':
                return 'fvQe-LDtQFWdkWWQTITMuA'
            return 'VPm71Q_wSm2_XgMnJeYzlA'
        else:
            if row['Production System Name'] == 'Programmatic Guaranteed Production System':
                return 71
            return 60

    op_fw_adj_daily.loc[:, 'Production System Name'] = op_fw_adj_daily.apply(get_prod_sys_name, axis=1)
    op_fw_adj_daily.loc[:, 'Production System ID'] = op_fw_adj_daily.apply(get_prod_sys_id, axis=1)

    op_fw_adj_daily_1p = op_fw_adj_daily.loc[:, list(daily_1p_meta_cols.keys()) + list(daily_1p_data_cols.keys())]
    op_fw_adj_daily_1p = op_fw_adj_daily_1p.rename(daily_1p_data_cols, axis=1)
    op_fw_adj_daily_1p.rename(daily_1p_meta_cols, axis=1, inplace=True)

    ps_lookup = prod_sys_lookup() # Mapping needs to be provided by Rea Anna
    op_fw_adj_daily_1p.fillna({'Production System Name': 'FreeWheel'}, inplace=True)
    op_fw_adj_daily_1p.loc[:, 'Production System ID'] = op_fw_adj_daily_1p.apply(lambda row: prod_sys_id(row, ps_lookup, 'Production System Name'), axis=1)
    op_fw_adj_daily_1p.loc[:, list(daily_1p_data_cols.values())] = op_fw_adj_daily_1p.loc[:, list(daily_1p_data_cols.values())].fillna(0)

    for index, unit_type in enumerate(unit_types):
        quant_col = 'Delivered Quantity ' + str(index+1)
        op_fw_adj_daily_1p.loc[:, quant_col] = op_fw_adj_daily_1p[unit_type]
        op_fw_adj_daily_1p.loc[:, quant_col] = op_fw_adj_daily_1p.loc[:, quant_col].fillna(0).astype('int64')
        op_fw_adj_daily_1p.drop(unit_type, axis=1, inplace=True)
        op_fw_adj_daily_1p['Unit Type ' + str(index+1)] = unit_type

    cols_1p_order = [
        'Start Date',
        'End Date',
        'Unit Cost',
        'Cost Method',
        'Associated Sales Line Item ID',
    ]

    cols_1p = (op_fw_adj_daily_1p.columns.drop(cols_1p_order).tolist()) + cols_1p_order
    op_fw_adj_daily_1p = op_fw_adj_daily_1p.reindex(columns=cols_1p)
    op_fw_adj_daily_1p = op_fw_adj_daily_1p.astype({'Associated Sales Line Item ID': 'Int64'})
    op_fw_adj_daily_1p = op_fw_adj_daily_1p.drop(columns=['Deal ID', 'FW - Deal Type', 'Production Line Item Status', 'Full PS Line Item IDs'])

    integer_columns = ['Advertiser ID', 'Delivered Quantity 8', 'Order ID']
    for integer_column in integer_columns:
        op_fw_adj_daily_1p[integer_column] = np.floor(op_fw_adj_daily_1p[integer_column]).astype('Int64')
    op_fw_adj_daily_1p['Delivered Quantity 8'] = op_fw_adj_daily_1p['Delivered Quantity 8'].fillna(0)
    op_fw_adj_daily_1p = op_fw_adj_daily_1p.drop_duplicates()

    if party == '1p':
        op_fw_adj_daily_1p = op_fw_adj_daily_1p.loc[
            ~op_fw_adj_daily_1p['Production System ID'].str.contains(
                'fvQe-LDtQFWdkWWQTITMuA',
                regex=True,
                na=False,
            ),
        :]
        op_1p_filenames = export_operative_billable(op_fw_adj_daily_1p, 'Operative_DeliveryPull_', report_date)
    else:
        op_fw_adj_daily_1p = op_fw_adj_daily_1p.loc[
            op_fw_adj_daily_1p['Production System ID'].str.contains(
                'fvQe-LDtQFWdkWWQTITMuA',
                regex=True,
                na=False,
            ),
        :]
        op_fw_adj_daily_1p.loc[:, 'Advertiser ID'] = 'PGADV1'
        op_fw_adj_daily_1p.loc[:, 'Advertiser Name'] = 'PG Advertiser'
        op_1p_filenames = export_operative_billable(op_fw_adj_daily_1p, 'Operative_DeliveryPull_PG_', report_date)

    return op_1p_filenames


def export_daily_3p(op_fw_adj_daily: pd.DataFrame, report_date: datetime) -> Dict[str, List[str]]:
    daily_3p_meta_cols = {
        'Delivery Source': 'Delivery Source',
        'Report End Date': 'Delivered Date',
        'Production System ID': 'Production System ID',
        'Production System Name': 'Production System Name',
        '3P Advertiser ID': 'Advertiser ID',
        '3P Advertiser Name': 'Advertiser Name',
        '3P Order ID': 'Order ID',
        '3P Order Name': 'Order Name',
        '3P Line Item ID': 'Line Item ID',
        'Placement ID': 'Associated Line Item ID',
        '3P Line Item Name': 'Line Item Name',
        'Placement Name': 'Associated Line Item Name',
        'Placement Start Date': 'Start Date',
        'Placement End Date': 'End Date',
    }

    daily_3p_data_cols = {
        '3P Imps': 'Impressions',
        'Clicks': 'Clicks',
        'Actions': 'Actions',
        'Viewable Impressions': 'Viewable Impressions',
        '3P Demo Imps': 'CoV Impressions',
        '3P Equivalized Demo Imps': 'CoV Impressions Equivalized',
        '3P Viewability and Demo Imps': 'CoV Impressions Viewable',
    }

    # Fill 0 for actions, viewable impressions
    op_fw_adj_daily.loc[:, 'Actions'] = 0
    op_fw_adj_daily.loc[:, 'Viewable Impressions'] = 0

    unit_types = list(daily_3p_data_cols.values())

    op_fw_adj_daily = apply_vpvh_elimination(op_fw_adj_daily,'3p')

    op_fw_adj_daily = equivalize(op_fw_adj_daily, 'operative_3p')

    # Drop No Delivery Lines -> no point in ingesting them
    op_fw_adj_daily = op_fw_adj_daily.loc[op_fw_adj_daily['3P Imps'] != 0 , :]

    op_fw_adj_daily.dropna(subset=['Placement ID'], inplace=True)

    op_fw_adj_daily_3p = op_fw_adj_daily.loc[:, list(daily_3p_meta_cols.keys()) + list(daily_3p_data_cols.keys())]
    op_fw_adj_daily_3p = op_fw_adj_daily_3p.loc[op_fw_adj_daily_3p['Production System Name'] != 'Moat', :]
    op_fw_adj_daily_3p = op_fw_adj_daily_3p.rename(daily_3p_data_cols, axis=1)

    for index, unit_type in enumerate(unit_types):
        op_fw_adj_daily_3p.loc[:, 'Delivered Quantity ' + str(index+1)] = op_fw_adj_daily_3p[unit_type]
        op_fw_adj_daily_3p.loc[:, 'Delivered Quantity ' + str(index+1)] = op_fw_adj_daily_3p.loc[:, 'Delivered Quantity ' + str(index+1)].fillna(0).astype('int64')
        op_fw_adj_daily_3p.drop(unit_type, axis=1, inplace=True)
        op_fw_adj_daily_3p['Unit Type ' + str(index+1)] = unit_type

    op_fw_adj_daily_3p.rename(
        daily_3p_meta_cols,
        axis=1,
        inplace=True,
    )

    op_fw_adj_daily_3p.loc[:, 'Associated Production System Name'] = np.where(op_fw_adj_daily_3p['Delivery Source'] == 'Freewheel + Adjuster',
                                                                              'FreeWheel', 'Google Ad Manager')

    ps_lookup = prod_sys_lookup()
    op_fw_adj_daily_3p.loc[:, 'Associated Production System ID'] = op_fw_adj_daily_3p.apply(
        lambda row: prod_sys_id(row, ps_lookup, 'Associated Production System Name'),
        axis=1,
    )
    op_fw_adj_daily_3p = op_fw_adj_daily_3p.drop(columns=['Delivery Source'], axis=1)

    # Filter lines that do not have a Production System ID
    op_fw_adj_daily_3p = op_fw_adj_daily_3p.loc[
        ~op_fw_adj_daily_3p['Production System ID'].str.contains(
            '-1',
            regex=True,
            na=False,
        ),
    :]

    cols_3p_order = [
        'Delivered Date',
        'Production System ID',
        'Production System Name',
        'Advertiser ID',
        'Advertiser Name',
        'Order ID',
        'Order Name',
        'Associated Production System ID',
        'Associated Production System Name',
        'Line Item ID',
        'Associated Line Item ID',
        'Line Item Name',
        'Associated Line Item Name',
        'Start Date',
        'End Date',
        'Delivered Quantity 1',
        'Unit Type 1',
        'Delivered Quantity 2',
        'Unit Type 2',
        'Delivered Quantity 3',
        'Unit Type 3',
        'Delivered Quantity 4',
        'Unit Type 4',
        'Delivered Quantity 5',
        'Unit Type 5',
        'Delivered Quantity 6',
        'Unit Type 6',
        'Delivered Quantity 7',
        'Unit Type 7'
    ]
    cols_3p = (op_fw_adj_daily_3p.columns.drop(cols_3p_order).tolist()) + cols_3p_order
    op_fw_adj_daily_3p = op_fw_adj_daily_3p.reindex(columns=cols_3p)
    op_fw_adj_daily_3p = op_fw_adj_daily_3p.astype(
        {
            'Associated Production System ID': 'object',
            'Associated Line Item ID': 'Int64',
            'Order ID': 'Int64',
        },
    )

    op_3p_filenames_freewheel = export_operative_billable(op_fw_adj_daily_3p[op_fw_adj_daily_3p['Associated Production System Name'] == 'FreeWheel'], 'Operative_3rdPartyDeliveryPull_FreeWheel_', report_date,)
    op_3p_filenames_gam = export_operative_billable(op_fw_adj_daily_3p[op_fw_adj_daily_3p['Associated Production System Name'] == 'Google Ad Manager'], 'Operative_3rdPartyDeliveryPull_GoogleAdManager_', report_date,)

    return {'files': op_3p_filenames_freewheel['files'] + op_3p_filenames_gam['files']}


def operative_billing(date: datetime, type: str) -> None:
    out = operative_billable(type, date)
    write_xcom_value('Operative Billing', str(out))

# COMMAND ----------

if __name__ == '__main__':
    date = dbutils.widgets.get('date')
    type_of_billing = dbutils.widgets.get('type')
    global drop_bucket, source, aws_profile
    drop_bucket = dbutils.widgets.get('drop_bucket')
    aws_profile = dbutils.widgets.get('aws_profile')
    source = dbutils.widgets.get('source')

    def parse_date(date: str) -> bool:
        format = "%Y-%m-%d"
        try:
            res = bool(datetime.strptime(date, format))
        except ValueError:
            res = False
        return res

    assert parse_date(date), "Invalid date format, should be in YYYY-MM-DD format"
    assert source != '', "Source is required"

    try:
        operative_billing(datetime.strptime(date, "%Y-%m-%d"), type_of_billing)
    except Exception as error:
        alert = Alert()
        alert.send('Operative Billing', f'Failed for {type_of_billing}.\n{type(error).__name__}: {error}')
        dbutils.notebook.exit(f'ERROR!!! - {error}')