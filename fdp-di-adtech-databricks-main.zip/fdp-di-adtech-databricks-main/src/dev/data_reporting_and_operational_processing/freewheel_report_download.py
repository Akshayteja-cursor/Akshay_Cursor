# Databricks notebook source
# COMMAND ----------

# MAGIC %run "/Workspace/Users/prajwal.harikishor@fox.com/fdp-di-adtech-databricks/src/dev/data_reporting_and_operational_processing/core"

# COMMAND ----------

# MAGIC %run "/Workspace/Users/prajwal.harikishor@fox.com/fdp-di-adtech-databricks/src/dev/data_reporting_and_operational_processing/alert"

# COMMAND ----------

from typing import Tuple
import io
import datetime
import json
from dataclasses import dataclass
import pandas as pd
import numpy as np
import boto3
import paramiko

# COMMAND ----------

@dataclass
class FreewheelSFTPCredentials:
    username: str
    password: str

    @classmethod
    def from_secret(cls, secret_arn: str) -> 'FreewheelSFTPCredentials':
        session = boto3.Session(profile_name=aws_profile)
        resp = session.client('secretsmanager').get_secret_value(SecretId=secret_arn)
        secret = json.loads(resp['SecretString'])
        return cls(username=secret['username'], password=secret['password'])


def pull_fw_sftp_report(freewheel_sftp_credentials: FreewheelSFTPCredentials, fw_report_type: str) -> Tuple[bytes, datetime.date]:
    fw_file_prefixes = {
        'lifetime': 'Ad Ops Pacing (Analytics) Fox New FW Placement Agg Copy_Placement-to-Date_',
        'monthly': 'Ad Ops Pacing (Analytics) Fox New FW QTD Monthly Agg Copy',
        'daily': 'Ad Ops Pacing (Analytics) Fox New FW Daily Agg Copy_Placement-to-Date_',
        'daily_m': 'Ad Ops Pacing (Analytics) Fox New FW Daily Agg Current Month Copy_',
        'daily_pm': 'Ops Pacing (Analytics) Fox New FW Daily Agg Last Month Copy_',
        'demo_monthly': 'Ad Ops Pacing (Analytics) Fox New FW Demo Monthly Agg Copy_Placement-to-Date_',
        'demo_daily': 'Ad Ops Pacing (Analytics) Fox New FW Demo Daily Agg Copy_Placement-to-Date_',
        'demo_testing': 'Ad Ops Pacing (Analytics) Fox New FW Demo Placement Agg Copy_Placement-to-Date_',
        'resellers': 'Billing Master (Analytics) Partners Markets Module Copy',
        'billing': 'Ad Ops Pacing (Analytics) Fox New FW Last Month Monthly Agg Copy',
        'metadata': 'Ad Ops (Analytics) Fox New FW Metadata Copy_Placement-to-Date_',
        'aud_metadata': 'Ad Ops (Analytics) Fox New FW Audience Item Metadata Copy_Placement-to-Date_',
        'affiliates': 'Affiliates',
        'programmatic': 'FW PG Delivery Report Daily Agg_',
    }
    fw_host = 'sftp.fwmrm.net'
    fw_port = 22
    if fw_report_type == 'affiliates':
        fw_sftp_dir = '/reports/analytics/prajwal.harikishor@fox.com@500763/'
    else:
        fw_sftp_dir = '/reports/analytics/prajwal.harikishor@fox.com@516429/'
    with paramiko.Transport((fw_host, fw_port)) as transport:
        transport.connect(None, freewheel_sftp_credentials.username, freewheel_sftp_credentials.password, None)
        print('Connected with username', 'fw_sftp_user=',freewheel_sftp_credentials.username, 'fw_sftp_dir=',fw_sftp_dir)
        fw_sftp = paramiko.SFTPClient.from_transport(transport)
        if fw_sftp is None:
            raise RuntimeError('Could not create SFTP client')
        with fw_sftp:
            fw_sftp.chdir(fw_sftp_dir)
            fw_sftp_files = fw_sftp.listdir()
            newest_suffix = sorted(
                file.split('_')[-1]
                for file
                in fw_sftp_files
                if file.startswith(fw_file_prefixes[fw_report_type])
            )[-1]
            newest_file = [
                file
                for file
                in fw_sftp_files
                if file.startswith(fw_file_prefixes[fw_report_type])
                and file.endswith(newest_suffix)
            ][0]
            with io.BytesIO() as output:
                fw_sftp.getfo(newest_file, output)
                sftp_data = output.getvalue()
                print('Got file', 'file=',newest_file)
            fw_sftp.close()
        transport.close()
    report_date = datetime.datetime.strptime(newest_suffix, '%Y%m%d%H%M%S.csv').date()
    return (sftp_data, report_date)


def fw_sftp_to_s3(freewheel_sftp_credentials: FreewheelSFTPCredentials, fw_report_type: str) -> Tuple[str, datetime.date]:
    reports_to_key = {
        'lifetime': 'Ad Ops Pacing (Analytics) Fox New FW Placement Agg',
        'monthly': 'Ad Ops Pacing (Analytics) Fox New FW QTD Monthly Agg',
        'daily': 'Ad Ops Pacing (Analytics) Fox New FW Daily Agg',
        'daily_m': 'Ad Ops Pacing (Analytics) Fox New FW Daily Agg Current Month',
        'daily_pm': 'Ad Ops Pacing (Analytics) Fox New FW Daily Agg Last Month',
        'demo_monthly': 'Ad Ops Pacing (Analytics) Fox New FW Demo Monthly Agg',
        'demo_testing': 'Ad Ops Pacing (Analytics) Fox New FW Demo Placement Agg',
        'demo_daily': 'Ad Ops Pacing (Analytics) Fox New FW Demo Daily Agg',
        'resellers': 'Billing Master (Analytics) Partners Markets Module',
        'billing': 'Ad Ops Pacing (Analytics) Fox New FW Last Month Monthly Agg',
        'metadata': 'Ad Ops (Analytics) Fox New FW Metadata',
        'aud_metadata': 'Ad Ops (Analytics) Fox New FW Audience Item Metadata',
        'affiliates': 'Affiliates Delivery Report',
        'programmatic': 'FW PG Delivery Report Daily Agg',
    }
    
    if fw_report_type not in reports_to_key:
        raise ValueError('Report key not defined.')

    output_file = reports_to_key[fw_report_type] + '.csv'
    (sftp_data, report_date) = pull_fw_sftp_report(freewheel_sftp_credentials, fw_report_type)
    print('Pulled report')

    session = boto3.Session(profile_name=aws_profile)
    s3_client = session.client('s3')
    global drop_bucket
    s3_bucket = drop_bucket
    s3_key = 'freewheel/' + output_file
    s3_client.put_object(
        Bucket=s3_bucket,
        Key=s3_key,
        Body=sftp_data,
    )
    print('Put report in S3', 'bucket=',s3_bucket, 'key=',s3_key)

    return (output_file, report_date)


def rename_file_fields(fw_report_type: str):
    reports_changed = ['lifetime','monthly','daily','daily_m','daily_pm','billing','metadata','aud_metadata']
    if fw_report_type not in reports_changed:
        return
    
    reports_to_key = {
        'lifetime': 'Ad Ops Pacing (Analytics) Fox New FW Placement Agg',
        'monthly': 'Ad Ops Pacing (Analytics) Fox New FW QTD Monthly Agg',
        'daily': 'Ad Ops Pacing (Analytics) Fox New FW Daily Agg',
        'daily_m': 'Ad Ops Pacing (Analytics) Fox New FW Daily Agg Current Month',
        'daily_pm': 'Ad Ops Pacing (Analytics) Fox New FW Daily Agg Last Month',
        'demo_monthly': 'Ad Ops Pacing (Analytics) Fox New FW Demo Monthly Agg',
        'demo_testing': 'Ad Ops Pacing (Analytics) Fox New FW Demo Placement Agg',
        'demo_daily': 'Ad Ops Pacing (Analytics) Fox New FW Demo Daily Agg',
        'resellers': 'Billing Master (Analytics) Partners Markets Module',
        'billing': 'Ad Ops Pacing (Analytics) Fox New FW Last Month Monthly Agg',
        'metadata': 'Ad Ops (Analytics) Fox New FW Metadata',
        'aud_metadata': 'Ad Ops (Analytics) Fox New FW Audience Item Metadata',
        'affiliates': 'Affiliates Delivery Report',
        'programmatic': 'FW PG Delivery Report Daily Agg',
    }
    

    output_file = reports_to_key[fw_report_type] + '.csv'
    global drop_bucket
    s3_bucket = drop_bucket
    s3_key = 'freewheel/' + output_file
    filepath = f's3://{s3_bucket}/{s3_key}'

    report_to_field_name_changes = {
        'lifetime': [['Placement Impression Goal','Placement Booked On-Target Impression Goal','Placement Budget Model','Placement FFDR (%)','Placement Forced Over Delivery Percent (%)'], ['Impression Goal','Booked On-Target Impression Goal','Budget Model','FFDR (%)','Forced Over Delivery Percent (%)']],
        'monthly': [['Placement Impression Goal','Placement Booked On-Target Impression Goal','Placement Budget Model','Placement FFDR (%)','Placement Forced Over Delivery Percent (%)'], ['Impression Goal','Booked On-Target Impression Goal','Budget Model','FFDR (%)','Forced Over Delivery Percent (%)']],
        'daily': [['Placement Impression Goal','Placement On-Target OSI (%)','Placement On-Target FFDR (%)','Placement Demographic On-Target Calculation','Placement Pacing','Placement Currency Goal','Placement Booked On-Target Impression Goal','Placement Booked On-Target Currency Goal','Placement Estimated Impression Goal','Placement Budget Model','Placement FFDR (%)','Placement Forced Over Delivery Percent (%)','Placement Price Model','Placement Priority Model','Placement Forecast Final Delivery'], ['Impression Goal','On-Target OSI (%)','On-Target FFDR (%)','Demographic On-Target Calculation','Delivery Pacing','Currency Goal','Booked On-Target Impression Goal','Booked On-Target Currency Goal','Estimated Impression Goal','Budget Model','FFDR (%)','Forced Over Delivery Percent (%)','Price Model','Delivery Priority','Forecast Final Delivery']],
        'daily_m': [['Placement Impression Goal','Placement On-Target OSI (%)','Placement On-Target FFDR (%)','Placement Demographic On-Target Calculation','Placement Pacing','Placement Currency Goal','Placement Booked On-Target Impression Goal','Placement Booked On-Target Currency Goal','Placement Estimated Impression Goal','Placement Budget Model','Placement FFDR (%)','Placement Forced Over Delivery Percent (%)','Placement Price Model','Placement Priority Model','Placement Forecast Final Delivery'], ['Impression Goal','On-Target OSI (%)','On-Target FFDR (%)','Demographic On-Target Calculation','Delivery Pacing','Currency Goal','Booked On-Target Impression Goal','Booked On-Target Currency Goal','Estimated Impression Goal','Budget Model','FFDR (%)','Forced Over Delivery Percent (%)','Price Model','Delivery Priority','Forecast Final Delivery']],
        'daily_pm': [['Placement Impression Goal','Placement On-Target OSI (%)','Placement On-Target FFDR (%)','Placement Demographic On-Target Calculation','Placement Pacing','Placement Currency Goal','Placement Booked On-Target Impression Goal','Placement Booked On-Target Currency Goal','Placement Estimated Impression Goal','Placement Budget Model','Placement FFDR (%)','Placement Forced Over Delivery Percent (%)','Placement Price Model','Placement Priority Model','Placement Forecast Final Delivery'], ['Impression Goal','On-Target OSI (%)','On-Target FFDR (%)','Demographic On-Target Calculation','Delivery Pacing','Currency Goal','Booked On-Target Impression Goal','Booked On-Target Currency Goal','Estimated Impression Goal','Budget Model','FFDR (%)','Forced Over Delivery Percent (%)','Price Model','Delivery Priority','Forecast Final Delivery']],
        'billing': [['Placement Impression Goal','Placement Booked On-Target Impression Goal','Placement Budget Model','Placement FFDR (%)','Placement Forced Over Delivery Percent (%)'], ['Impression Goal','Booked On-Target Impression Goal','Budget Model','FFDR (%)','Forced Over Delivery Percent (%)']],
        'metadata': [['Placement Budget Model','Placement Forced Over Delivery Percent (%)','Placement Level of Exclusivity','Placement Booked On-Target Impression Goal','Placement Impression Goal','Placement Estimated Impression Goal'], ['Budget Model','Forced Over Delivery Percent (%)','Level of Exclusivity','Booked On-Target Impression Goal','Impression Goal','Estimated Impression Goal']],
        'aud_metadata': [['Matched Audience Item Name'], ['Matched Audience Item']]
    }

    df = pd.read_csv(filepath, low_memory=False, storage_options={'profile': aws_profile})

    df.rename(
        {
            report_to_field_name_changes[fw_report_type][0][i]:report_to_field_name_changes[fw_report_type][1][i] for i in range(len(report_to_field_name_changes[fw_report_type][0]))
        },
        inplace=True,
        axis=1
    )

    if 'Forced Over Delivery Percent (%)' in df.columns:
        df['Forced Over Delivery Percent (%)'] = df['Forced Over Delivery Percent (%)'].replace(r'^\s*$', np.nan, regex=True)

    df.to_csv(filepath, index=False, storage_options={'profile': aws_profile})
    print('Columns renamed in file and put report in S3', 'bucket=',s3_bucket, 'key=',s3_key)

# COMMAND ----------

def freewheel(report: str, freewheel_sftp_credentials_secret_arn: str) -> None:
    freewheel_sftp_credentials = FreewheelSFTPCredentials.from_secret(freewheel_sftp_credentials_secret_arn)
    (output_file, report_date) = fw_sftp_to_s3(freewheel_sftp_credentials, report)
    if report_date < datetime.datetime.today().date():
        raise ValueError(
            'Freewheel report may not be up to date. Last generated on: ',
            report_date.strftime('%Y-%m-%d'),
        )
    rename_file_fields(report)
    write_xcom_value('Freewheel'+report, output_file)

# COMMAND ----------

if __name__ == '__main__':
    global drop_bucket, aws_profile
    drop_bucket = dbutils.widgets.get('drop_bucket')
    aws_profile = dbutils.widgets.get('aws_profile')
    freewheel_sftp_credentials_secret_arn = dbutils.widgets.get('freewheel_sftp_credentials_secret_arn') 
    report = dbutils.widgets.get('report')

    REPORT_CHOICES = [
        'lifetime',
        'monthly',
        'daily',
        'daily_m',
        'daily_pm',
        'demo_monthly',
        'demo_daily',
        'demo_testing',
        'resellers',
        'billing',
        'metadata',
        'aud_metadata',
        'affiliates',
        'programmatic',
    ]

    assert report in REPORT_CHOICES, "Invalid action, should be one of {}".format(REPORT_CHOICES)
    assert freewheel_sftp_credentials_secret_arn != '', "Invalid adjuster_credentials_secret_arn"

    try:
        freewheel(report, freewheel_sftp_credentials_secret_arn)
    except Exception as error:
        alert = Alert()
        alert.send('Freewheel', f'Failed for {report}\n{type(error).__name__}: {error}')
        dbutils.notebook.exit(f'ERROR!!! - {error}')

    # reports = ['lifetime', 'demo_monthly', 'demo_daily', 'programmatic'] #adops_lifetime
    # reports = ['daily_m', 'daily_pm'] #adops_daily
    # reports = ['billing'] #bar
    # reports = ['monthly'] #executive_summary
    # reports = ['metadata', 'aud_metadata'] #audit reprort
    # reports = ['lifetime', 'demo_monthly', 'demo_daily', 'programmatic', 'daily_m', 'daily_pm', 'billing', 'monthly', 'metadata', 'aud_metadata'] #All files
    # for report in reports:
    #     freewheel(report, freewheel_sftp_credentials_secret_arn)