# Databricks notebook source
from pyspark.sql import functions as F
from pyspark.sql import types as T
from datetime import datetime, timedelta

# COMMAND ----------

query = f"""
    SELECT
        /*+ BROADCAST(pl, cmp, cr, vs, io ,adv) */
          geo.event_date
        , geo.campaign_id
        , cmp.campaign_name
        , cmp.campaign_start_timestamp_est
        , cmp.campaign_end_timestamp_est
        , geo.placement_id
        , pl.placement_name
        , adv.advertiser_name --1
        , geo.advertiser_id  --2
        , geo.agency_name 
        , geo.delivered_device
        , geo.delivered_country_name
        , geo.delivered_state_province_name
        , geo.delivered_dma_name
        , geo.delivered_city_name
        , geo.delivered_zip_postal_code
        , geo.insertion_order_id
        , io.insertion_order_name
        , io.insertion_order_start_timestamp_est
        , io.insertion_order_end_timestamp_est
        , pl.placement_start_timestamp_est
        , pl.placement_end_timestamp_est
        , SUM(geo.net_counted_ads) As net_counted_ads
        , SUM(geo.delivered_clicks) As delivered_clicks
        , SUM(geo.video_ads_25_complete) As video_ads_25_complete
        , SUM(geo.video_ads_50_complete) As video_ads_50_complete
        , SUM(geo.video_ads_75_complete) As video_ads_75_complete
        , SUM(geo.video_ads_100_complete) As video_ads_100_complete
        , SUM(geo.measurable_video_ads_quartile_impressions) As measurable_video_ads_quartile_impressions
        , DATE_FORMAT(geo.event_date, 'MM') as event_month
        , DATE_FORMAT(geo.event_date, "y-'Q'Q") as event_quarter
        , DATE_FORMAT(geo.event_date, 'y') as event_year
        , event_year||event_month as ad_month_id
        , DATE_FORMAT(geo.event_date, 'MMMM-y') as ad_month_year
        , DATE_FORMAT(CURRENT_TIMESTAMP(), 'yyyy-MM-dd') AS etl_load_date
        , CURRENT_TIMESTAMP() AS etl_load_timestamp
    FROM fox_bi_dev.bronze_ads.freewheel_analytics_geo_data geo

    LEFT JOIN fox_bi_dev.silver_ads.dim_freewheel_analytics_placement pl
    ON geo.placement_id = pl.placement_id

    LEFT JOIN fox_bi_dev.silver_ads.dim_freewheel_analytics_campaign cmp
    ON geo.campaign_id = cmp.campaign_id

    LEFT JOIN fox_bi_dev.silver_ads.dim_freewheel_analytics_insertion_order io
    ON geo.insertion_order_id = io.insertion_order_id

    LEFT JOIN fox_bi_dev.silver_ads.dim_freewheel_analytics_advertiser adv
    ON geo.advertiser_id = adv.advertiser_id
    
    GROUP BY
        geo.event_date
        , geo.campaign_id
        , cmp.campaign_name
        , cmp.campaign_start_timestamp_est
        , cmp.campaign_end_timestamp_est
        , geo.placement_id
        , pl.placement_name
        , adv.advertiser_name  --1
        , geo.advertiser_id   --2
        , geo.agency_name
        , geo.delivered_device
        , geo.delivered_country_name
        , geo.delivered_state_province_name
        , geo.delivered_dma_name
        , geo.delivered_city_name
        , geo.delivered_zip_postal_code
        , geo.insertion_order_id
        , io.insertion_order_name
        , io.insertion_order_start_timestamp_est
        , io.insertion_order_end_timestamp_est
        , pl.placement_start_timestamp_est
        , pl.placement_end_timestamp_est
"""

fw_geo_data = spark.sql(query)

# COMMAND ----------


# fw_geo_data.write.format('delta')\
#     .mode('overwrite')\
#     .partitionBy('event_date')\
#     .option('mergeSchema', 'true')\
#     .option('overwriteDynamicPartitions', 'true')\
#     .option('delta.enableDeletionVectors', 'false')\
#     .option('delta.enableIcebergCompatV2', 'true')\
#     .option('delta.universalFormat.enabledFormats', 'iceberg')\
#     .option('delta.columnMapping.mode', 'name')\
#     .saveAsTable('fox_bi_dev.silver_ads.ft_freewheel_geo_daily_data')

fw_geo_data.write.format('delta')\
    .mode('overwrite')\
    .option('partitionOverwriteMode', 'dynamic')\
    .saveAsTable('fox_bi_dev.silver_ads.ft_freewheel_geo_daily_data')

# COMMAND ----------

# MAGIC %sql
# MAGIC select event_date, count(*) from fox_bi_dev.silver_ads.ft_freewheel_geo_daily_data group by event_date order by event_date
