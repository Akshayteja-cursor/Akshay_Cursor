# Databricks notebook source
import datetime
from datetime import timedelta
from pyspark.sql import functions as F
from pyspark.sql import types as T
from datetime import datetime, timedelta
import configparser

# COMMAND ----------

# MAGIC %run ./fts_delivery_config

# COMMAND ----------

config = configparser.ConfigParser()
dbutils.widgets.text("env", "")
env = dbutils.widgets.get("env")
config = fts_delivery_config[env]
display(config)
catalog=config['catalog']
silver_schema=config['silver_schema']
gold_schema=config['gold_schema']
bronze_schema = config['bronze_schema']
raw_schema=config['raw_schema']

# COMMAND ----------

# query_1 = """SELECT 
# CAST(ft.`Delivered Date` as date) as ad_delivery_date
# ,ft.`Associated Line Item ID` as external_ad_id 
# ,'DVPS' as data_source_name
# ,NULL as network_group_id
# ,NULL as isci_code 
# ,NULL as spot_length
# ,NULL as first_party_delivered_impressions 
# ,sum(`Delivered Quantity 1`) AS third_party_delivered_impressions --only DVPS
# ,NULL as first_party_clicks
# ,sum(`Delivered Quantity 2`) AS third_party_clicks --only DVPS
# FROM fox_bi_prod.raw_ads.fts_double_verify_delivery ft
# -- WHERE CAST(ft.`Delivered Date` as date) BETWEEN CURRENT_DATE-8 AND CURRENT_DATE-1
# GROUP BY 1,2
# """

# COMMAND ----------

#event_start_date = dbutils.widgets.get('event_start_date')
#event_end_date = dbutils.widgets.get('event_end_date')

query = f"""
SELECT 
ad_date as ad_delivery_date 
,external_ad_id
,ad_server_source as data_source_name
,network_group_id
,array_join(sort_array(collect_list(ISCI)), '/') as isci_code
,NULL as spot_length
,SUM(first_party_delivered_impressions) first_party_delivered_impressions
,NULL AS  third_party_delivered_impressions
,SUM(first_party_clicks) first_party_clicks
,NULL AS  third_party_clicks
FROM  
(SELECT 
A.event_date as ad_date
,CAST(A.line_item_id AS STRING) as external_ad_id
,'GAM' as ad_server_source
,'4145' as network_group_id
,(CASE WHEN dimension_creative_name LIKE '%\_%' THEN SPLIT(dimension_creative_name,'_')[0] ELSE NULL END) as ISCI 
,SUM(total_line_item_level_impressions) first_party_delivered_impressions
,SUM(total_line_item_level_clicks) first_party_clicks
FROM {catalog}.{bronze_schema}.fts_delivery_gam_api_4145 A
LEFT JOIN (select distinct order_id, order_name from fox_bi_prod.{raw_schema}.gam_order) B 
ON A.Order_Id = B.Order_Id
LEFT JOIN (select * from fox_bi_prod.{raw_schema}.gam_creative) C
ON A.creative_id=C.dimension_creative_id AND  A.event_date=C.dimension_date
WHERE order_name like '%Google Ad Manager - Fox News'
GROUP BY 
A.event_date
,CAST(A.line_item_id AS STRING)
,'GAM'
,'4145'
,(CASE WHEN dimension_creative_name LIKE '%\_%' THEN SPLIT(dimension_creative_name,'_')[0] ELSE NULL END)

UNION ALL

SELECT 
A.event_date as ad_delivery_date
,CAST(A.line_item_id AS STRING) as external_ad_id
,'GAM' as data_source_name
,'63790564' as network_group_id
,(CASE WHEN dimension_creative_name LIKE '%\_%' THEN SPLIT(dimension_creative_name,'_')[0] ELSE NULL END) as isci_code 
,SUM(total_line_item_level_impressions) first_party_delivered_impressions
,NULL AS first_party_clicks
FROM {catalog}.{bronze_schema}.fts_delivery_gam_api_63790564 A
LEFT JOIN (select * from fox_bi_prod.{raw_schema}.fts_gam_creative) C
ON A.creative_id=C.dimension_creative_id AND  A.event_date=C.dimension_date
GROUP BY 
A.event_date
,CAST(A.line_item_id AS STRING)
,'GAM'
,'63790564'
,(CASE WHEN dimension_creative_name LIKE '%\_%' THEN SPLIT(dimension_creative_name,'_')[0] ELSE NULL END)  
)
WHERE ad_date BETWEEN CURRENT_DATE-8 AND CURRENT_DATE-1
--WHERE ad_date BETWEEN event_start_date and event_start_date
 GROUP BY 1,2,3,4,6 

UNION ALL
--FW
SELECT 
CAST(CONVERT_TIMEZONE('UTC', 'America/New_York', ft.eventtime) AS DATE) as ad_delivery_date
,ft.placementid as external_ad_id
,'Freewheel' as data_source_name
,'500763' AS network_group_id
,`dim_ad_creative`.`creative_external_id` as isci_code
,CASE
    WHEN /* rounded_sec */ CAST(ROUND((
           CASE
             WHEN INSTR(CAST(creativeduration AS STRING), ':') > 0 THEN
               CAST(SPLIT(CAST(creativeduration AS STRING), ':')[0] AS INT) * 60 +
               CAST(SPLIT(CAST(creativeduration AS STRING), ':')[1] AS INT)
             WHEN TRY_CAST(creativeduration AS DOUBLE) IS NOT NULL THEN
               CAST(TRY_CAST(creativeduration AS DOUBLE) AS INT)
             ELSE NULL
           END
         ) / 5.0) * 5 AS INT) >= 60
      THEN CONCAT(
             CAST( CAST(ROUND((
                   CASE
                     WHEN INSTR(CAST(creativeduration AS STRING), ':') > 0 THEN
                       CAST(SPLIT(CAST(creativeduration AS STRING), ':')[0] AS INT) * 60 +
                       CAST(SPLIT(CAST(creativeduration AS STRING), ':')[1] AS INT)
                     WHEN TRY_CAST(creativeduration AS DOUBLE) IS NOT NULL THEN
                       CAST(TRY_CAST(creativeduration AS DOUBLE) AS INT)
                     ELSE NULL
                   END
                 ) / 5.0) * 5 AS INT) DIV 60 AS STRING),
             ':',
             LPAD(CAST( CAST(ROUND((
                   CASE
                     WHEN INSTR(CAST(creativeduration AS STRING), ':') > 0 THEN
                       CAST(SPLIT(CAST(creativeduration AS STRING), ':')[0] AS INT) * 60 +
                       CAST(SPLIT(CAST(creativeduration AS STRING), ':')[1] AS INT)
                     WHEN TRY_CAST(creativeduration AS DOUBLE) IS NOT NULL THEN
                       CAST(TRY_CAST(creativeduration AS DOUBLE) AS INT)
                     ELSE NULL
                   END
                 ) / 5.0) * 5 AS INT) % 60 AS STRING), 2, '0')
           )

    WHEN /* rounded_sec < 60 */
         CAST(ROUND((
           CASE
             WHEN INSTR(CAST(creativeduration AS STRING), ':') > 0 THEN
               CAST(SPLIT(CAST(creativeduration AS STRING), ':')[0] AS INT) * 60 +
               CAST(SPLIT(CAST(creativeduration AS STRING), ':')[1] AS INT)
             WHEN TRY_CAST(creativeduration AS DOUBLE) IS NOT NULL THEN
               CAST(TRY_CAST(creativeduration AS DOUBLE) AS INT)
             ELSE NULL
           END
         ) / 5.0) * 5 AS INT) IS NOT NULL
      THEN CAST(
             CAST(ROUND((
               CASE
                 WHEN INSTR(CAST(creativeduration AS STRING), ':') > 0 THEN
                   CAST(SPLIT(CAST(creativeduration AS STRING), ':')[0] AS INT) * 60 +
                   CAST(SPLIT(CAST(creativeduration AS STRING), ':')[1] AS INT)
                 WHEN TRY_CAST(creativeduration AS DOUBLE) IS NOT NULL THEN
                   CAST(TRY_CAST(creativeduration AS DOUBLE) AS INT)
                 ELSE NULL
               END
             ) / 5.0) * 5 AS INT) AS STRING)

  END as spot_length
,sum(case when (ft.eventname == 'defaultImpression' AND ft.givtdecisionresult == 'Pass') then 1 else 0 end) as first_party_delivered_impressions
,NULL AS third_party_delivered_impressions --only DVPS
,NULL AS first_party_clicks 
,NULL AS third_party_clicks --only DVPS
from fox_bi_prod.{raw_schema}.freewheel_s3_v4logs_500763_fox_affiliates ft
LEFT JOIN 
(SELECT DISTINCT COALESCE(`Creative ID`, '-1') AS creative_id,
`Creative External ID` AS creative_external_id
FROM fox_bi_prod.{raw_schema}.freewheel_s3_creative_external_500763_fox_affiliates) dim_ad_creative
ON ft.CreativeId=dim_ad_creative.creative_id
WHERE EventTime >= to_utc_timestamp(CURRENT_DATE - 8,'America/New_York')
        AND EventTime <  to_utc_timestamp(CURRENT_DATE,'America/New_York')
--WHERE CAST(CONVERT_TIMEZONE('UTC', 'America/New_York', ft.eventtime) AS DATE) BETWEEN CURRENT_DATE-8 AND CURRENT_DATE-1
--WHERE CAST(CONVERT_TIMEZONE('UTC', 'America/New_York', ft.eventtime) AS DATE) BETWEEN event_start_date and event_start_date
GROUP BY 1,2,5,6

UNION ALL

--Madhive
SELECT 
ft.date_et as ad_delivery_date
,ft.line_item_id as external_ad_id 
,'Madhive' as data_source_name
,NULL as network_group_id
,creative_isci_code as isci_code 
,CASE
    WHEN /* rounded_sec */ CAST(ROUND((
           CASE
             WHEN INSTR(CAST(creative_duration_sec AS STRING), ':') > 0 THEN
               CAST(SPLIT(CAST(creative_duration_sec AS STRING), ':')[0] AS INT) * 60 +
               CAST(SPLIT(CAST(creative_duration_sec AS STRING), ':')[1] AS INT)
             WHEN TRY_CAST(creative_duration_sec AS DOUBLE) IS NOT NULL THEN
               CAST(TRY_CAST(creative_duration_sec AS DOUBLE) AS INT)
             ELSE NULL
           END
         ) / 5.0) * 5 AS INT) >= 60
      THEN CONCAT(
             CAST( CAST(ROUND((
                   CASE
                     WHEN INSTR(CAST(creative_duration_sec AS STRING), ':') > 0 THEN
                       CAST(SPLIT(CAST(creative_duration_sec AS STRING), ':')[0] AS INT) * 60 +
                       CAST(SPLIT(CAST(creative_duration_sec AS STRING), ':')[1] AS INT)
                     WHEN TRY_CAST(creative_duration_sec AS DOUBLE) IS NOT NULL THEN
                       CAST(TRY_CAST(creative_duration_sec AS DOUBLE) AS INT)
                     ELSE NULL
                   END
                 ) / 5.0) * 5 AS INT) DIV 60 AS STRING),
             ':',
             LPAD(CAST( CAST(ROUND((
                   CASE
                     WHEN INSTR(CAST(creative_duration_sec AS STRING), ':') > 0 THEN
                       CAST(SPLIT(CAST(creative_duration_sec AS STRING), ':')[0] AS INT) * 60 +
                       CAST(SPLIT(CAST(creative_duration_sec AS STRING), ':')[1] AS INT)
                     WHEN TRY_CAST(creative_duration_sec AS DOUBLE) IS NOT NULL THEN
                       CAST(TRY_CAST(creative_duration_sec AS DOUBLE) AS INT)
                     ELSE NULL
                   END
                 ) / 5.0) * 5 AS INT) % 60 AS STRING), 2, '0')
           )

    WHEN /* rounded_sec < 60 */
         CAST(ROUND((
           CASE
             WHEN INSTR(CAST(creative_duration_sec AS STRING), ':') > 0 THEN
               CAST(SPLIT(CAST(creative_duration_sec AS STRING), ':')[0] AS INT) * 60 +
               CAST(SPLIT(CAST(creative_duration_sec AS STRING), ':')[1] AS INT)
             WHEN TRY_CAST(creative_duration_sec AS DOUBLE) IS NOT NULL THEN
               CAST(TRY_CAST(creative_duration_sec AS DOUBLE) AS INT)
             ELSE NULL
           END
         ) / 5.0) * 5 AS INT) IS NOT NULL
      THEN CAST(
             CAST(ROUND((
               CASE
                 WHEN INSTR(CAST(creative_duration_sec AS STRING), ':') > 0 THEN
                   CAST(SPLIT(CAST(creative_duration_sec AS STRING), ':')[0] AS INT) * 60 +
                   CAST(SPLIT(CAST(creative_duration_sec AS STRING), ':')[1] AS INT)
                 WHEN TRY_CAST(creative_duration_sec AS DOUBLE) IS NOT NULL THEN
                   CAST(TRY_CAST(creative_duration_sec AS DOUBLE) AS INT)
                 ELSE NULL
               END
             ) / 5.0) * 5 AS INT) AS STRING)

  END as spot_length
,sum(impressions_total) as first_party_delivered_impressions 
,NULL AS third_party_delivered_impressions --only DVPS
,sum(click_events_total) as first_party_clicks
,NULL AS third_party_clicks --only DVPS
FROM {catalog}.{bronze_schema}.fts_delivery_madhive ft
WHERE ft.date_et BETWEEN CURRENT_DATE-8 AND CURRENT_DATE-1
--WHERE DATE_FORMAT(TO_DATE(ft.date_et,'M/d/yy'), 'yyyy-MM-dd') BETWEEN event_start_date and event_start_date
GROUP BY 1,2,5,6

UNION ALL

--DVPS
SELECT 
CAST(ft.`Delivered Date` as date) as ad_delivery_date
,ft.`Associated Line Item ID` as external_ad_id 
,'DVPS' as data_source_name
,NULL as network_group_id
,NULL as isci_code 
,NULL as spot_length
,NULL as first_party_delivered_impressions 
,sum(`Delivered Quantity 1`) AS third_party_delivered_impressions --only DVPS
,NULL as first_party_clicks
,sum(`Delivered Quantity 2`) AS third_party_clicks --only DVPS
FROM {catalog}.{bronze_schema}.fts_delivery_double_verify ft
WHERE CAST(ft.`Delivered Date` as date) BETWEEN CURRENT_DATE-8 AND CURRENT_DATE-1
--WHERE CAST(ft.`Delivered Date` as date) BETWEEN event_start_date and event_start_date
GROUP BY 1,2 
"""

# COMMAND ----------

# spark.sql("""INSERT INTO fox_bi_prod.gold_ads.agg_ad_fts_delivery_daily SELECT 
# CAST(ft.`Delivered Date` as date) as ad_delivery_date
# ,ft.`Associated Line Item ID` as external_ad_id 
# ,'DVPS' as data_source_name
# ,NULL as network_group_id
# ,NULL as isci_code 
# ,NULL as spot_length
# ,NULL as first_party_delivered_impressions 
# ,sum(`Delivered Quantity 1`) AS third_party_delivered_impressions --only DVPS
# ,NULL as first_party_clicks
# ,sum(`Delivered Quantity 2`) AS third_party_clicks --only DVPS
# FROM fox_bi_prod.raw_ads.fts_double_verify_delivery ft
# where ft.`Associated Line Item ID`IN 
# ('S2z8UZnP0nFuKDWkAhz4GVnpQbG3',
# 'uqvxDFXUM7KpE4mcAXZmtKeG3jBm',
# 'zcu57tx0StyOQKlojFm79AfI2CTW',
# 'h1bMULoHjcz9dhnUfOdlm8dbpJZv',
# '6G2jUXGMvcdwFn1ZUBbwaGJvEQiH',
# 'oDzgmUE9wo8y8GbiZ8S072TiaWHN',
# '11YDEi5VTgRCamsjyZh2L0C1UzdT',
# 'xoPwC4qWJg04hff45TQ4Nadb7Ctp',
# 'YBIJQBoGuGjbu2VMkfiU5zWSPAGq',
# 'tlcidYCIBCKRA0T435tiIji1WvoE',
# 'AlaOhnoh9a2RciUl4kvhlbRJwJGl',
# 'cPc3wjMk4PmbsSOek3hjTilk9dR6',
# 'NqI31N6nPilt6berqHH40u5Sdlg5')
# GROUP BY 1,2 """)

# COMMAND ----------

gam_daily = spark.sql(query)
gam_daily = gam_daily.withColumn("ad_delivery_date", F.to_date(F.col("ad_delivery_date"), 'yyyy-MM-dd'))
#gam_daily = gam_daily.withColumn("spot_length", F.col("spot_length").cast("double"))


# gam_daily.write.format('delta')\
#    .mode('overwrite')\
#    .partitionBy('ad_delivery_date', 'data_source_name')\
#    .option('mergeSchema', 'true')\
#    .option('overwriteDynamicPartitions', 'true')\
#    .option('delta.enableDeletionVectors', 'false')\
#    .option('delta.enableIcebergCompatV2', 'true')\
#    .option('delta.universalFormat.enabledFormats', 'iceberg')\
#    .option('delta.columnMapping.mode', 'name')\
#    .saveAsTable('fox_bi_prod.gold_ads.agg_ad_fts_delivery_daily')

gam_daily.write.format('delta')\
     .mode('overwrite')\
      .option('mergeSchema', 'true')\
     .option('partitionOverwriteMode', 'dynamic')\
     .saveAsTable(f'{catalog}.{silver_schema}.ft_fts_delivery_daily')

# COMMAND ----------

# spark.sql("""
# UPDATE fox_bi_prod.gold_ads.agg_ad_fts_delivery_daily
# SET isci_code = NULL
# WHERE isci_code = '-1'
# """)

# COMMAND ----------

# spark.sql("""
# UPDATE fox_bi_prod.gold_ads.agg_ad_fts_delivery_daily
# SET spot_length =
#   CASE
#     WHEN /* rounded_sec */ CAST(ROUND((
#            CASE
#              WHEN INSTR(CAST(spot_length AS STRING), ':') > 0 THEN
#                CAST(SPLIT(CAST(spot_length AS STRING), ':')[0] AS INT) * 60 +
#                CAST(SPLIT(CAST(spot_length AS STRING), ':')[1] AS INT)
#              WHEN TRY_CAST(spot_length AS DOUBLE) IS NOT NULL THEN
#                CAST(TRY_CAST(spot_length AS DOUBLE) AS INT)
#              ELSE NULL
#            END
#          ) / 5.0) * 5 AS INT) >= 60
#       THEN CONCAT(
#              CAST( CAST(ROUND((
#                    CASE
#                      WHEN INSTR(CAST(spot_length AS STRING), ':') > 0 THEN
#                        CAST(SPLIT(CAST(spot_length AS STRING), ':')[0] AS INT) * 60 +
#                        CAST(SPLIT(CAST(spot_length AS STRING), ':')[1] AS INT)
#                      WHEN TRY_CAST(spot_length AS DOUBLE) IS NOT NULL THEN
#                        CAST(TRY_CAST(spot_length AS DOUBLE) AS INT)
#                      ELSE NULL
#                    END
#                  ) / 5.0) * 5 AS INT) DIV 60 AS STRING),
#              ':',
#              LPAD(CAST( CAST(ROUND((
#                    CASE
#                      WHEN INSTR(CAST(spot_length AS STRING), ':') > 0 THEN
#                        CAST(SPLIT(CAST(spot_length AS STRING), ':')[0] AS INT) * 60 +
#                        CAST(SPLIT(CAST(spot_length AS STRING), ':')[1] AS INT)
#                      WHEN TRY_CAST(spot_length AS DOUBLE) IS NOT NULL THEN
#                        CAST(TRY_CAST(spot_length AS DOUBLE) AS INT)
#                      ELSE NULL
#                    END
#                  ) / 5.0) * 5 AS INT) % 60 AS STRING), 2, '0')
#            )

#     WHEN /* rounded_sec < 60 */
#          CAST(ROUND((
#            CASE
#              WHEN INSTR(CAST(spot_length AS STRING), ':') > 0 THEN
#                CAST(SPLIT(CAST(spot_length AS STRING), ':')[0] AS INT) * 60 +
#                CAST(SPLIT(CAST(spot_length AS STRING), ':')[1] AS INT)
#              WHEN TRY_CAST(spot_length AS DOUBLE) IS NOT NULL THEN
#                CAST(TRY_CAST(spot_length AS DOUBLE) AS INT)
#              ELSE NULL
#            END
#          ) / 5.0) * 5 AS INT) IS NOT NULL
#       THEN CAST(
#              CAST(ROUND((
#                CASE
#                  WHEN INSTR(CAST(spot_length AS STRING), ':') > 0 THEN
#                    CAST(SPLIT(CAST(spot_length AS STRING), ':')[0] AS INT) * 60 +
#                    CAST(SPLIT(CAST(spot_length AS STRING), ':')[1] AS INT)
#                  WHEN TRY_CAST(spot_length AS DOUBLE) IS NOT NULL THEN
#                    CAST(TRY_CAST(spot_length AS DOUBLE) AS INT)
#                  ELSE NULL
#                END
#              ) / 5.0) * 5 AS INT) AS STRING)

#     ELSE spot_length
#   END
# """)
