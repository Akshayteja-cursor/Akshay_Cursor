# Databricks notebook source
# Get from freewheel_bronze
event_start_date = dbutils.jobs.taskValues.get("Set_Job_Parameters", "event_start_date_freewheel")
event_end_date = dbutils.jobs.taskValues.get("Set_Job_Parameters", "event_end_date_freewheel")
skip_freewheel = dbutils.jobs.taskValues.get("Set_Job_Parameters", "skip_freewheel")
skip_freewheel_ad_request = dbutils.jobs.taskValues.get("Set_Job_Parameters", "skip_freewheel_ad_request")

# COMMAND ----------

spark.conf.set("spark.sql.shuffle.partitions", "auto")

# COMMAND ----------

print(f"Running for {event_start_date} to {event_end_date}")

# COMMAND ----------

# Combined skip logic
if skip_freewheel == "true" or skip_freewheel_ad_request == "true":
    dbutils.notebook.exit("Skipping Freewheel Silver Ad Request due to skip flag")

# COMMAND ----------

# MAGIC %md PROCESSING LOGIC

# COMMAND ----------

from pyspark.sql import functions as F 
from pyspark.sql import types as T
from datetime import datetime, timedelta

# COMMAND ----------

# Load data sources from Unity Catalog
def load_table(table_name):
    return spark.read.table(f"fox_bi_dev.bronze_ads.{table_name}")

# COMMAND ----------

from pyspark.sql.functions import col, lit, regexp_extract, date_add,current_timestamp, expr, coalesce
from pyspark.sql.types import LongType

# COMMAND ----------

base_df_fw_logs_500763_scoped = load_table("freewheel_v4_logs_500763_fox_affiliates").filter((col("event_date") >= lit(event_start_date)) & (col("event_date") <= lit(event_end_date)))

base_df_fw_logs_516429_scoped = load_table("freewheel_v4_logs_516429_fox_corp").filter((col("event_date") >= lit(event_start_date)) & (col("event_date") <= lit(event_end_date)))

# COMMAND ----------

# --- Apply filter: fw_logs_500763
df1_fw_logs_500763 = (
    base_df_fw_logs_500763_scoped
    .select(
        col("transaction_id"),
        col("all_request_kv"),
        col("market_advertiser_id"),
        col("event_type"),
        col("event_date")
    )
    .filter(
        (col("event_type").isin("R"))
        & (
            (regexp_extract(col("market_advertiser_id"), r"^[0-9]+$", 0) != "")
            | col("market_advertiser_id").isNull()
        )
    )
)

# --- Apply filter: fw_logs_51642
df2_fw_logs_516429 = (
    base_df_fw_logs_516429_scoped
    .select(
        col("transaction_id"),
        col("all_request_kv"),
        col("market_advertiser_id"),
        col("event_type"),
        col("event_date")
    )
    .filter(
        (col("event_type").isin("R"))
        & (
            (regexp_extract(col("market_advertiser_id"), r"^[0-9]+$", 0) != "")
            | col("market_advertiser_id").isNull()
        )
    )
)

# --- UNION fw_logs_*
df_unioned = df1_fw_logs_500763.union(df2_fw_logs_516429)

# --- Project, distinct & generate event_date
df_distinct = (
    df_unioned
    .select(
        col("transaction_id"),
        col("all_request_kv"),
        col("event_date")
    )
    .distinct()
)

# COMMAND ----------

processed_ad_request_df = df_distinct.select(
        col('event_date'),
        coalesce(col('transaction_id'), lit('N/A')).cast("string").alias("transaction_id"),
        expr(
            """
            COALESCE(
                NULLIF(
                    CASE
                        WHEN lower(all_request_kv) ILIKE '%nw=%'
                        THEN
                            CASE
                                WHEN POSITION('&' IN SUBSTRING(lower(all_request_kv), POSITION('nw=' IN lower(all_request_kv)) + LEN('nw='), 1)) = 1
                                THEN '-1'
                                ELSE TRIM(
                                    SUBSTRING(
                                        lower(all_request_kv),
                                        POSITION('nw=' IN lower(all_request_kv)) + LEN('nw='),
                                        CASE
                                            WHEN POSITION('&' IN SUBSTRING(lower(all_request_kv), POSITION('nw=' IN lower(all_request_kv)) + LEN('nw='), LEN(lower(all_request_kv)))) > 0
                                            THEN POSITION('&' IN SUBSTRING(lower(all_request_kv), POSITION('nw=' IN lower(all_request_kv)) + LEN('nw='), LEN(lower(all_request_kv)))) - 1
                                            ELSE LEN(lower(all_request_kv))
                                        END
                                    )
                                )
                            END
                        ELSE '-1'
                    END,
                '')  -- NULLIF to handle empty strings
            ,'-1')
            """
        ).cast(LongType()).alias('freewheel_network_id'),
        expr(
            """
            coalesce(case
            when all_request_kv ilike '%resp=%'
              then
                  substring(
                          all_request_kv,position('resp=' in all_request_kv)+len('resp='),
                          case
                              when position ('&'in substring(all_request_kv,position('resp=' in all_request_kv)+len('resp='),len(all_request_kv))) <>0
                              then position('&' in substring(all_request_kv,position('resp=' in all_request_kv)+len('resp='),len(all_request_kv)))-1
                              else len(all_request_kv) end
              )
            end,
            'N/A')
            """
        ).alias("ad_response_type"),
        expr(
            """
            coalesce(case when all_request_kv ilike '%crtp=%' then substring(all_request_kv,position('crtp=' in all_request_kv)+len('crtp='),
            case when position ('&'in substring(all_request_kv,position('crtp=' in all_request_kv)+len('crtp='),len(all_request_kv))) <>0 then position('&' in substring(all_request_kv,position('crtp=' in all_request_kv)+len('crtp='),len(all_request_kv)))-1
            else len(all_request_kv) end) end,'N/A')
            """
        ).alias("additional_ad_response_type"),
        expr(
            """
            coalesce(case when all_request_kv ilike '%prof=%' then substring(all_request_kv,position('prof=' in all_request_kv)+len('prof='),
            case when position ('&'in substring(all_request_kv,position('prof=' in all_request_kv)+len('prof='),len(all_request_kv))) <>0 then position('&' in substring(all_request_kv,position('prof=' in all_request_kv)+len('prof='),len(all_request_kv)))-1
            else len(all_request_kv) end) end,'N/A')
            """
        ).alias("player_profile"),
        expr(
            """
            coalesce(case when all_request_kv ilike '%csid=%' then substring(all_request_kv,position('csid=' in all_request_kv)+len('csid='),
            case when position ('&'in substring(all_request_kv,position('csid=' in all_request_kv)+len('csid='),len(all_request_kv))) <>0 then position('&' in substring(all_request_kv,position('csid=' in all_request_kv)+len('csid='),len(all_request_kv)))-1
            else len(all_request_kv) end) end,'-1')
            """
        ).alias("custom_site_section_id"),
        expr(
            """
            coalesce(case when all_request_kv ilike '%caid=%' then substring(all_request_kv,position('caid=' in all_request_kv)+len('caid='),
            case when position ('&'in substring(all_request_kv,position('caid=' in all_request_kv)+len('caid='),len(all_request_kv))) <>0 then position('&' in substring(all_request_kv,position('caid=' in all_request_kv)+len('caid='),len(all_request_kv)))-1
            else len(all_request_kv) end) end,'N/A')
            """
        ).alias("video_asset"),
        expr(
            """
            COALESCE(
                  NULLIF(
                      CASE
                          WHEN lower(all_request_kv) ILIKE '%asnw=%'
                          THEN
                              CASE
                                  WHEN POSITION('&' IN SUBSTRING(lower(all_request_kv), POSITION('asnw=' IN lower(all_request_kv)) + LEN('asnw='), 1)) = 1
                                  THEN '-1'
                                  ELSE TRIM(
                                      SUBSTRING(
                                          lower(all_request_kv),
                                          POSITION('asnw=' IN lower(all_request_kv)) + LEN('asnw='),
                                          CASE
                                              WHEN POSITION('&' IN SUBSTRING(lower(all_request_kv), POSITION('asnw=' IN lower(all_request_kv)) + LEN('asnw='), LEN(lower(all_request_kv)))) > 0
                                              THEN POSITION('&' IN SUBSTRING(lower(all_request_kv), POSITION('asnw=' IN lower(all_request_kv)) + LEN('asnw='), LEN(lower(all_request_kv)))) - 1
                                              ELSE LEN(lower(all_request_kv))
                                          END
                                      )
                                  )
                              END
                          ELSE '-1'
                      END,
                  '')
              ,'-1')
            """
        ).cast(LongType()).alias("asset_network_id"),
        expr(
            """
            COALESCE(
                  NULLIF(
                      CASE
                          WHEN lower(all_request_kv) ILIKE '%ssnw=%'
                          THEN
                              CASE
                                  WHEN POSITION('&' IN SUBSTRING(lower(all_request_kv), POSITION('ssnw=' IN lower(all_request_kv)) + LEN('ssnw='), 1)) = 1
                                  THEN '-1'
                                  ELSE TRIM(
                                      SUBSTRING(
                                          lower(all_request_kv),
                                          POSITION('ssnw=' IN lower(all_request_kv)) + LEN('ssnw='),
                                          CASE
                                              WHEN POSITION('&' IN SUBSTRING(lower(all_request_kv), POSITION('ssnw=' IN lower(all_request_kv)) + LEN('ssnw='), LEN(lower(all_request_kv)))) > 0
                                              THEN POSITION('&' IN SUBSTRING(lower(all_request_kv), POSITION('ssnw=' IN lower(all_request_kv)) + LEN('ssnw='), LEN(lower(all_request_kv)))) - 1
                                              ELSE LEN(lower(all_request_kv))
                                          END
                                      )
                                  )
                              END
                          ELSE '-1'
                      END,
                  '')
              ,'-1')
            """
        ).cast(LongType()).alias("site_section_network_id"),
        expr(
            """
            coalesce(case when all_request_kv ilike '%pvrn=%' then substring(all_request_kv,position('pvrn=' in all_request_kv)+len('pvrn='),
            case when position ('&'in substring(all_request_kv,position('pvrn=' in all_request_kv)+len('pvrn='),len(all_request_kv))) <>0 then position('&' in substring(all_request_kv,position('pvrn=' in all_request_kv)+len('pvrn='),len(all_request_kv)))-1
            else len(all_request_kv) end) end,'N/A')
            """
        ).alias("page_view_random"),
        expr(
            """
            coalesce(case when all_request_kv ilike '%vprn=%' then substring(all_request_kv,position('vprn=' in all_request_kv)+len('vprn='),
            case when position ('&'in substring(all_request_kv,position('vprn=' in all_request_kv)+len('vprn='),len(all_request_kv))) <>0 then position('&' in substring(all_request_kv,position('vprn=' in all_request_kv)+len('vprn='),len(all_request_kv)))-1
            else len(all_request_kv) end) end,'N/A')
            """
        ).alias("video_player_random"),
        expr(
            """
            coalesce(case when all_request_kv ilike '%flag=%' then substring(all_request_kv,position('flag=' in all_request_kv)+len('flag='),
            case when position ('&'in substring(all_request_kv,position('flag=' in all_request_kv)+len('flag='),len(all_request_kv))) <>0 then position('&' in substring(all_request_kv,position('flag=' in all_request_kv)+len('flag='),len(all_request_kv)))-1
            else len(all_request_kv) end) end,'N/A')
            """
        ).alias("video_player_capabilities"),
        expr(
            """
            COALESCE(
                  NULLIF(
                      CASE
                          WHEN lower(all_request_kv) ILIKE '%metr=%'
                          THEN
                              CASE
                                  WHEN POSITION('&' IN SUBSTRING(lower(all_request_kv), POSITION('metr=' IN lower(all_request_kv)) + LEN('metr='), 1)) = 1
                                  THEN '-1'
                                  ELSE TRIM(
                                      SUBSTRING(
                                          lower(all_request_kv),
                                          POSITION('metr=' IN lower(all_request_kv)) + LEN('metr='),
                                          CASE
                                              WHEN POSITION('&' IN SUBSTRING(lower(all_request_kv), POSITION('metr=' IN lower(all_request_kv)) + LEN('metr='), LEN(lower(all_request_kv)))) > 0
                                              THEN POSITION('&' IN SUBSTRING(lower(all_request_kv), POSITION('metr=' IN lower(all_request_kv)) + LEN('metr='), LEN(lower(all_request_kv)))) - 1
                                              ELSE LEN(lower(all_request_kv))
                                          END
                                      )
                                  )
                              END
                          ELSE '-1'
                      END,
                  '')
              ,'-1')
            """
        ).cast(LongType()).alias("default_metrics"),
        expr(
            """
            coalesce(case when all_request_kv ilike '%fnl-affiliate=%' then substring(all_request_kv,position('fnl-affiliate=' in all_request_kv)+len('fnl-affiliate='),
            case when position ('&'in substring(all_request_kv,position('fnl-affiliate=' in all_request_kv)+len('fnl-affiliate='),len(all_request_kv))) <>0 then position('&' in substring(all_request_kv,position('fnl-affiliate=' in all_request_kv)+len('fnl-affiliate='),len(all_request_kv)))-1
            else len(all_request_kv) end)
            when all_request_kv ilike '%fs-affiliate=%' then substring(all_request_kv,position('fs-affiliate=' in all_request_kv)+len('fs-affiliate='),
            case when position ('&'in substring(all_request_kv,position('fs-affiliate=' in all_request_kv)+len('fs-affiliate='),len(all_request_kv))) <>0 then position('&' in substring(all_request_kv,position('fs-affiliate=' in all_request_kv)+len('fs-affiliate='),len(all_request_kv)))-1
            else len(all_request_kv) end) end,'N/A')
            """
        ).alias("kvp"),
        expr(
            """
            COALESCE(
                  NULLIF(
                      CASE
                          WHEN lower(all_request_kv) ILIKE '%afid=%'
                          THEN
                              CASE
                                  WHEN POSITION('&' IN SUBSTRING(lower(all_request_kv), POSITION('afid=' IN lower(all_request_kv)) + LEN('afid='), 1)) = 1
                                  THEN '-1'
                                  ELSE TRIM(
                                      SUBSTRING(
                                          lower(all_request_kv),
                                          POSITION('afid=' IN lower(all_request_kv)) + LEN('afid='),
                                          CASE
                                              WHEN POSITION('&' IN SUBSTRING(lower(all_request_kv), POSITION('afid=' IN lower(all_request_kv)) + LEN('afid='), LEN(lower(all_request_kv)))) > 0
                                              THEN POSITION('&' IN SUBSTRING(lower(all_request_kv), POSITION('afid=' IN lower(all_request_kv)) + LEN('afid='), LEN(lower(all_request_kv)))) - 1
                                              ELSE LEN(lower(all_request_kv))
                                          END
                                      )
                                  )
                              END
                          ELSE '-1'
                      END,
                  '')
              ,'-1')
            """
        ).cast(LongType()).alias("asset_fallback_id"),
        expr(
            """
            COALESCE(
                  NULLIF(
                      CASE
                          WHEN lower(all_request_kv) ILIKE '%sfid=%'
                          THEN
                              CASE
                                  WHEN POSITION('&' IN SUBSTRING(lower(all_request_kv), POSITION('sfid=' IN lower(all_request_kv)) + LEN('sfid='), 1)) = 1
                                  THEN '-1'
                                  ELSE TRIM(
                                      SUBSTRING(
                                          lower(all_request_kv),
                                          POSITION('sfid=' IN lower(all_request_kv)) + LEN('sfid='),
                                          CASE
                                              WHEN POSITION('&' IN SUBSTRING(lower(all_request_kv), POSITION('sfid=' IN lower(all_request_kv)) + LEN('sfid='), LEN(lower(all_request_kv)))) > 0
                                              THEN POSITION('&' IN SUBSTRING(lower(all_request_kv), POSITION('sfid=' IN lower(all_request_kv)) + LEN('sfid='), LEN(lower(all_request_kv)))) - 1
                                              ELSE LEN(lower(all_request_kv))
                                          END
                                      )
                                  )
                              END
                          ELSE '-1'
                      END,
                  '')
              ,'-1')
            """
        ).cast(LongType()).alias("site_section_fallback_id"),
        expr(
            """
            coalesce(case when all_request_kv ilike '%vip=%' then substring(all_request_kv,position('vip=' in all_request_kv)+len('vip='),
            case when position ('&'in substring(all_request_kv,position('vip=' in all_request_kv)+len('vip='),len(all_request_kv))) <>0 then position('&' in substring(all_request_kv,position('vip=' in all_request_kv)+len('vip='),len(all_request_kv)))-1
            else len(all_request_kv) end) end,'N/A')
            """
        ).alias("end_user_ip"),
        expr(
            """
            coalesce(case when all_request_kv ilike '%mode=%' then substring(all_request_kv,position('mode=' in all_request_kv)+len('mode='),
            case when position ('&'in substring(all_request_kv,position('mode=' in all_request_kv)+len('mode='),len(all_request_kv))) <>0 then position('&' in substring(all_request_kv,position('mode=' in all_request_kv)+len('mode='),len(all_request_kv)))-1
            else len(all_request_kv) end) end,'N/A')
            """
        ).alias("request_mode"),
        expr(
            """
            coalesce(case when all_request_kv ilike '%vdty=%' then substring(all_request_kv,position('vdty=' in all_request_kv)+len('vdty='),
            case when position ('&'in substring(all_request_kv,position('vdty=' in all_request_kv)+len('vdty='),len(all_request_kv))) <>0 then position('&' in substring(all_request_kv,position('vdty=' in all_request_kv)+len('vdty='),len(all_request_kv)))-1
            else len(all_request_kv) end) end,'N/A') :: varchar(50)
            """
        ).alias("video_asset_duration_type"),
        expr(
            """
            coalesce(case when all_request_kv ilike '%vdur=%' then substring(all_request_kv,position('vdur=' in all_request_kv)+len('vdur='),
            case when position ('&'in substring(all_request_kv,position('vdur=' in all_request_kv)+len('vdur='),len(all_request_kv))) <>0 then position('&' in substring(all_request_kv,position('vdur=' in all_request_kv)+len('vdur='),len(all_request_kv)))-1
            else len(all_request_kv) end) end,'N/A')
            """
        ).alias("content_video_duration_secs"),
        expr(
            """
            coalesce(case when all_request_kv ilike '%vrdu=%' then substring(all_request_kv,position('vrdu=' in all_request_kv)+len('vrdu='),
            case when position ('&'in substring(all_request_kv,position('vrdu=' in all_request_kv)+len('vrdu='),len(all_request_kv))) <>0 then position('&' in substring(all_request_kv,position('vrdu=' in all_request_kv)+len('vrdu='),len(all_request_kv)))-1
            else len(all_request_kv) end) end,'N/A')
            """
        ).alias("video_request_duration_secs"),
        expr(
            """
            coalesce(case when all_request_kv ilike '%_fw_exin=%' then substring(all_request_kv,position('_fw_exin=' in all_request_kv)+len('_fw_exin='),
            case when position ('&'in substring(all_request_kv,position('_fw_exin=' in all_request_kv)+len('_fw_exin='),len(all_request_kv))) <>0 then position('&' in substring(all_request_kv,position('_fw_exin=' in all_request_kv)+len('_fw_exin='),len(all_request_kv)))-1
            else len(all_request_kv) end) end,'N/A')
            """
        ).alias("server_side_vendor_indicator"),
        expr(
            """
            coalesce(case when all_request_kv ilike '%_fw_nielsen_app_id=%' then substring(all_request_kv,position('_fw_nielsen_app_id=' in all_request_kv)+len('_fw_nielsen_app_id='),
            case when position ('&'in substring(all_request_kv,position('_fw_nielsen_app_id=' in all_request_kv)+len('_fw_nielsen_app_id='),len(all_request_kv))) <>0 then position('&' in substring(all_request_kv,position('_fw_nielsen_app_id=' in all_request_kv)+len('_fw_nielsen_app_id='),len(all_request_kv)))-1
            else len(all_request_kv) end) end,'N/A')
            """
        ).alias("nielsen_app_id"),
        expr(
            """
            coalesce(case when all_request_kv ilike '%_fw_h_user_agent=%' then substring(all_request_kv,position('_fw_h_user_agent=' in all_request_kv)+len('_fw_h_user_agent='),
            case when position ('&'in substring(all_request_kv,position('_fw_h_user_agent=' in all_request_kv)+len('_fw_h_user_agent='),len(all_request_kv))) <>0 then position('&' in substring(all_request_kv,position('_fw_h_user_agent=' in all_request_kv)+len('_fw_h_user_agent='),len(all_request_kv)))-1
            else len(all_request_kv) end) end,'N/A')
            """
        ).alias("user_agent"),
        expr(
            """
            coalesce(case when all_request_kv ilike '%_fw_h_referer=%' then substring(all_request_kv,position('_fw_h_referer=' in all_request_kv)+len('_fw_h_referer='),
            case when position ('&'in substring(all_request_kv,position('_fw_h_referer=' in all_request_kv)+len('_fw_h_referer='),len(all_request_kv))) <>0 then position('&' in substring(all_request_kv,position('_fw_h_referer=' in all_request_kv)+len('_fw_h_referer='),len(all_request_kv)))-1
            else len(all_request_kv) end) end,'N/A')
            """
        ).alias("http_referer"),
        expr(
            """
            coalesce(case when all_request_kv ilike '%_fw_ae=%' then substring(all_request_kv,position('_fw_ae=' in all_request_kv)+len('_fw_ae='),
            case when position ('&'in substring(all_request_kv,position('_fw_ae=' in all_request_kv)+len('_fw_ae='),len(all_request_kv))) <>0 then position('&' in substring(all_request_kv,position('_fw_ae=' in all_request_kv)+len('_fw_ae='),len(all_request_kv)))-1
            else len(all_request_kv) end) end,'N/A')
            """
        ).alias("mvpd_provider"),
        expr(
            """
            coalesce(case when all_request_kv ilike '%_fw_hylda=%' then substring(all_request_kv,position('_fw_hylda=' in all_request_kv)+len('_fw_hylda='),
            case when position ('&'in substring(all_request_kv,position('_fw_hylda=' in all_request_kv)+len('_fw_hylda='),len(all_request_kv))) <>0 then position('&' in substring(all_request_kv,position('_fw_hylda=' in all_request_kv)+len('_fw_hylda='),len(all_request_kv)))-1
            else len(all_request_kv) end) end,'N/A')
            """
        ).alias("hylda"),
        expr(
            """
            coalesce(case when all_request_kv ilike '%_fw_us_privacy=%' then substring(all_request_kv,position('_fw_us_privacy=' in all_request_kv)+len('_fw_us_privacy='),
            case when position ('&'in substring(all_request_kv,position('_fw_us_privacy=' in all_request_kv)+len('_fw_us_privacy='),len(all_request_kv))) <>0 then position('&' in substring(all_request_kv,position('_fw_us_privacy=' in all_request_kv)+len('_fw_us_privacy='),len(all_request_kv)))-1
            else len(all_request_kv) end) end,'N/A')
            """
        ).alias("ccpa_compliance"),
        expr(
            """
            coalesce(case when all_request_kv ilike '%_fw_is_lat=%' then substring(all_request_kv,position('_fw_is_lat=' in all_request_kv)+len('_fw_is_lat='),
            case when position ('&'in substring(all_request_kv,position('_fw_is_lat=' in all_request_kv)+len('_fw_is_lat='),len(all_request_kv))) <>0 then position('&' in substring(all_request_kv,position('_fw_is_lat=' in all_request_kv)+len('_fw_is_lat='),len(all_request_kv)))-1
            else len(all_request_kv) end) end,'N/A')
            """
        ).alias("limited_ad_tracking"),
        expr(
            """
            coalesce(case when all_request_kv ilike '%_fw_did=%' then substring(all_request_kv,position('_fw_did=' in all_request_kv)+len('_fw_did='),
            case when position ('&'in substring(all_request_kv,position('_fw_did=' in all_request_kv)+len('_fw_did='),len(all_request_kv))) <>0 then position('&' in substring(all_request_kv,position('_fw_did=' in all_request_kv)+len('_fw_did='),len(all_request_kv)))-1
            else len(all_request_kv) end) end,'N/A')
            """
        ).alias("device_id"),
        expr(
            """
            coalesce(case when all_request_kv ilike '%_fw_vcid2=%' then substring(all_request_kv,position('_fw_vcid2=' in all_request_kv)+len('_fw_vcid2='),
            case when position ('&'in substring(all_request_kv,position('_fw_vcid2=' in all_request_kv)+len('_fw_vcid2='),len(all_request_kv))) <>0 then position('&' in substring(all_request_kv,position('_fw_vcid2=' in all_request_kv)+len('_fw_vcid2='),len(all_request_kv)))-1
            else len(all_request_kv) end) end,'N/A')
            """
        ).alias("custom_visitor_id"),
        expr(
            """
            coalesce(case when all_request_kv ilike '%slid=%' then substring(all_request_kv,position('slid=' in all_request_kv)+len('slid='),
            case when position ('&'in substring(all_request_kv,position('slid=' in all_request_kv)+len('slid='),len(all_request_kv))) <>0 then position('&' in substring(all_request_kv,position('slid=' in all_request_kv)+len('slid='),len(all_request_kv)))-1
            else len(all_request_kv) end) end,'N/A')
            """
        ).alias("slot_custom_id"),
        expr(
            """
            coalesce(case when all_request_kv ilike '%tpos=%' then substring(all_request_kv,position('tpos=' in all_request_kv)+len('tpos='),
            case when position ('&'in substring(all_request_kv,position('tpos=' in all_request_kv)+len('tpos='),len(all_request_kv))) <>0 then position('&' in substring(all_request_kv,position('tpos=' in all_request_kv)+len('tpos='),len(all_request_kv)))-1
            else len(all_request_kv) end) end,'N/A')
            """
        ).alias("slot_time_position"),
        expr(
            """
            coalesce(case when all_request_kv ilike '%ptgt=%' then substring(all_request_kv,position('ptgt=' in all_request_kv)+len('ptgt='),
            case when position ('&'in substring(all_request_kv,position('ptgt=' in all_request_kv)+len('ptgt='),len(all_request_kv))) <>0 then position('&' in substring(all_request_kv,position('ptgt=' in all_request_kv)+len('ptgt='),len(all_request_kv)))-1
            else len(all_request_kv) end) end,'N/A')
            """
        ).alias("type_of_slot"),
        expr(
            """
            coalesce(case when all_request_kv ilike '%maxd=%' then substring(all_request_kv,position('maxd=' in all_request_kv)+len('maxd='),
            case when position ('&'in substring(all_request_kv,position('maxd=' in all_request_kv)+len('maxd='),len(all_request_kv))) <>0 then position('&' in substring(all_request_kv,position('maxd=' in all_request_kv)+len('maxd='),len(all_request_kv)))-1
            else len(all_request_kv) end) end,'N/A')
            """
        ).alias("slot_max_duration_secs"),
        expr(
            """
            coalesce(case when all_request_kv ilike '%slau=%' then substring(all_request_kv,position('slau=' in all_request_kv)+len('slau='),
            case when position ('&'in substring(all_request_kv,position('slau=' in all_request_kv)+len('slau='),len(all_request_kv))) <>0 then position('&' in substring(all_request_kv,position('slau=' in all_request_kv)+len('slau='),len(all_request_kv)))-1
            else len(all_request_kv) end) end,'N/A')
            """
        ).alias("specify_custom_ad_unit"),
        expr(
            """
            coalesce(case when all_request_kv ilike '%cpsq=%' then substring(all_request_kv,position('cpsq=' in all_request_kv)+len('cpsq='),
            case when position ('&'in substring(all_request_kv,position('cpsq=' in all_request_kv)+len('cpsq='),len(all_request_kv))) <>0 then position('&' in substring(all_request_kv,position('cpsq=' in all_request_kv)+len('cpsq='),len(all_request_kv)))-1
            else len(all_request_kv) end) end,'N/A')
            """
        ).alias("cue_point_position"),
        expr(
            """
            coalesce(case when all_request_kv ilike '%mind=%' then substring(all_request_kv,position('mind=' in all_request_kv)+len('mind='),
            case when position ('&'in substring(all_request_kv,position('mind=' in all_request_kv)+len('mind='),len(all_request_kv))) <>0 then position('&' in substring(all_request_kv,position('mind=' in all_request_kv)+len('mind='),len(all_request_kv)))-1
            else len(all_request_kv) end) end,'N/A')
            """
        ).alias("minimum_duration_of_slot_secs"),
        expr(
            """
            coalesce(case when all_request_kv ilike '%ys_txn_id=%' then substring(all_request_kv,position('ys_txn_id=' in all_request_kv)+len('ys_txn_id='),
            case when position ('&'in substring(all_request_kv,position('ys_txn_id=' in all_request_kv)+len('ys_txn_id='),len(all_request_kv))) <>0 then position('&' in substring(all_request_kv,position('ys_txn_id=' in all_request_kv)+len('ys_txn_id='),len(all_request_kv)))-1
            else len(all_request_kv) end) end,'N/A')
            """
        ).alias("yospace_transaction_id"),

        # bundle_id <- _fw_app_bundle
        expr("""
        coalesce(
        case when lower(all_request_kv) ilike '%_fw_app_bundle=%' then
            substring(
            lower(all_request_kv),
            position('_fw_app_bundle=' in lower(all_request_kv)) + len('_fw_app_bundle='),
            case when position('&' in substring(lower(all_request_kv), position('_fw_app_bundle=' in lower(all_request_kv)) + len('_fw_app_bundle='), len(lower(all_request_kv)))) <> 0
                then position('&' in substring(lower(all_request_kv), position('_fw_app_bundle=' in lower(all_request_kv)) + len('_fw_app_bundle='), len(lower(all_request_kv)))) - 1
                else len(lower(all_request_kv)) end
            )
        end,
        'N/A')
        """).alias("bundle_id"),

        # IFA <- _fw_did value starting with 'idfa:'  (returns part after 'idfa:')
        expr("""
        case
        when lower(all_request_kv) ilike '%_fw_did=idfa%' then
            substring(
            all_request_kv,
            position('_fw_did=idfa' in lower(all_request_kv)) + len('_fw_did=idfa'),
            case
                when position('&' in substring(
                    lower(all_request_kv),
                    position('_fw_did=idfa' in lower(all_request_kv)) + len('_fw_did=idfa'),
                    len(lower(all_request_kv))
                    )) <> 0
                then position('&' in substring(
                    lower(all_request_kv),
                    position('_fw_did=idfa' in lower(all_request_kv)) + len('_fw_did=idfa'),
                    len(lower(all_request_kv))
                    )) - 1
                else len(lower(all_request_kv))
            end
            )
        else 'N/A'
        end
        """).alias("ifa"),

        # App_Store_URL <- fw_app_store_url
        expr("""
        coalesce(
        case when lower(all_request_kv) ilike '%fw_app_store_url=%' then
            substring(
            lower(all_request_kv),
            position('fw_app_store_url=' in lower(all_request_kv)) + len('fw_app_store_url='),
            case when position('&' in substring(lower(all_request_kv), position('fw_app_store_url=' in lower(all_request_kv)) + len('fw_app_store_url='), len(lower(all_request_kv)))) <> 0
                then position('&' in substring(lower(all_request_kv), position('fw_app_store_url=' in lower(all_request_kv)) + len('fw_app_store_url='), len(lower(all_request_kv)))) - 1
                else len(lower(all_request_kv)) end
            )
        end,
        'N/A')
        """).alias("app_store_url"),

        # Genre <- fw_content_genre
        expr("""
        coalesce(
        case when lower(all_request_kv) ilike '%fw_content_genre=%' then
            substring(
            lower(all_request_kv),
            position('fw_content_genre=' in lower(all_request_kv)) + len('fw_content_genre='),
            case when position('&' in substring(lower(all_request_kv), position('fw_content_genre=' in lower(all_request_kv)) + len('fw_content_genre='), len(lower(all_request_kv)))) <> 0
                then position('&' in substring(lower(all_request_kv), position('fw_content_genre=' in lower(all_request_kv)) + len('fw_content_genre='), len(lower(all_request_kv)))) - 1
                else len(lower(all_request_kv)) end
            )
        end,
        'N/A')
        """).alias("genre"),

        # Rating <- fw_content_rating
        expr("""
        coalesce(
        case when lower(all_request_kv) ilike '%fw_content_rating=%' then
            substring(
            lower(all_request_kv),
            position('fw_content_rating=' in lower(all_request_kv)) + len('fw_content_rating='),
            case when position('&' in substring(lower(all_request_kv), position('fw_content_rating=' in lower(all_request_kv)) + len('fw_content_rating='), len(lower(all_request_kv)))) <> 0
                then position('&' in substring(lower(all_request_kv), position('fw_content_rating=' in lower(all_request_kv)) + len('fw_content_rating='), len(lower(all_request_kv)))) - 1
                else len(lower(all_request_kv)) end
            )
        end,
        'N/A')
        """).alias("rating"),

        # Network <- fw_content_network
        expr("""
        coalesce(
        case when lower(all_request_kv) ilike '%fw_content_network=%' then
            substring(
            lower(all_request_kv),
            position('fw_content_network=' in lower(all_request_kv)) + len('fw_content_network='),
            case when position('&' in substring(lower(all_request_kv), position('fw_content_network=' in lower(all_request_kv)) + len('fw_content_network='), len(lower(all_request_kv)))) <> 0
                then position('&' in substring(lower(all_request_kv), position('fw_content_network=' in lower(all_request_kv)) + len('fw_content_network='), len(lower(all_request_kv)))) - 1
                else len(lower(all_request_kv)) end
            )
        end,
        'N/A')
        """).alias("network_ad_req"),

        # Channel <- fw_content_channel
        expr("""
        coalesce(
        case when lower(all_request_kv) ilike '%fw_content_channel=%' then
            substring(
            lower(all_request_kv),
            position('fw_content_channel=' in lower(all_request_kv)) + len('fw_content_channel='),
            case when position('&' in substring(lower(all_request_kv), position('fw_content_channel=' in lower(all_request_kv)) + len('fw_content_channel='), len(lower(all_request_kv)))) <> 0
                then position('&' in substring(lower(all_request_kv), position('fw_content_channel=' in lower(all_request_kv)) + len('fw_content_channel='), len(lower(all_request_kv)))) - 1
                else len(lower(all_request_kv)) end
            )
        end,
        'N/A')
        """).alias("channel"),
        coalesce(col('all_request_kv'), lit('N/A')).cast("string").alias("all_request_kv"),
        expr("CURRENT_TIMESTAMP() as etl_created_at_timestamp_utc"),
        expr("CURRENT_TIMESTAMP() as etl_updated_at_timestamp_utc")
    )

# COMMAND ----------

from pyspark.sql.functions import col, when

# Define the integer/long fields that should have -1 instead of null
long_fields = [
    "freewheel_network_id",
    "asset_network_id",
    "site_section_network_id",
    "default_metrics",
    "asset_fallback_id",
    "site_section_fallback_id",
    "custom_site_section_id"  # Added as requested
]

# Replace nulls with -1 in long fields
processed_ad_request_df_cleaned = processed_ad_request_df
for field in long_fields:
    processed_ad_request_df_cleaned = processed_ad_request_df_cleaned.withColumn(
        field,
        when(col(field).isNull(), -1).otherwise(col(field))
    )

# COMMAND ----------

# Define the target table
target_table = "fox_bi_dev.silver_ads.ft_freewheel_ad_request_daily"

# Overwrite partitions dynamically based on event_date and network_group_id
(
    processed_ad_request_df_cleaned.write.format("delta") \
    .mode('overwrite')\
    .option('partitionOverwriteMode', 'dynamic')\
    .saveAsTable(target_table)
)

print(f"Data successfully written to {target_table}")
