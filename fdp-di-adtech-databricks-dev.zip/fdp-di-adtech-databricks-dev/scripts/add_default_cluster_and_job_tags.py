import json
import os
import sys

# Command-line input for environment (e.g., dev, qa, prod)
if len(sys.argv) < 2:
    print("Python Script requires ENVIRONMENT argument")
    print("Usage: python script.py <environment>")
    sys.exit(1)

env_value = sys.argv[1]

# All tags to normalize
TAGS_TO_NORMALIZE = {
    "domain_name": "adtech",
    "environment": env_value
}

# List of jobs where only job_tags should be updated (cluster_tags should be skipped)
poolinstance_jobs_dev = []
poolinstance_jobs_qa = []
poolinstance_jobs_prod = []

# Dynamically assign poolinstance_jobs based on environment
env_to_pool_jobs = {
    "dev": poolinstance_jobs_dev,
    "qa": poolinstance_jobs_qa,
    "prod": poolinstance_jobs_prod
}

if env_value not in env_to_pool_jobs:
    print(f"Unsupported environment '{env_value}'. Expected one of: {list(env_to_pool_jobs.keys())}")
    sys.exit(1)

poolinstance_jobs = env_to_pool_jobs[env_value]

# Split tags: separate domain_name so we can selectively skip
NON_DOMAIN_TAGS = {k: v for k, v in TAGS_TO_NORMALIZE.items() if k.lower() != "domain_name"}

def normalize_tags(tags, allowed_keys=None):
    """
    Normalize only tags in allowed_keys (if specified),
    otherwise apply all TAGS_TO_NORMALIZE.
    """
    if tags is None:
        tags = {}

    normalized_tags = tags.copy()
    tag_source = TAGS_TO_NORMALIZE if allowed_keys is None else {
        k: v for k, v in TAGS_TO_NORMALIZE.items() if k in allowed_keys
    }

    for expected_key, expected_value in tag_source.items():
        found_key = None
        value_matches = False

        for key in normalized_tags:
            if key.lower() == expected_key.lower():
                found_key = key
                value_matches = normalized_tags[key].lower() == expected_value.lower()
                break

        if found_key:
            if not value_matches or found_key != expected_key:
                normalized_tags[expected_key] = expected_value
                if found_key != expected_key:
                    del normalized_tags[found_key]
        else:
            normalized_tags[expected_key] = expected_value

    return normalized_tags

def process_jobconfigs(file_path):
    print(f"Processing jobs: {file_path}")
    with open(file_path, "r") as f:
        data = json.load(f)

    for job_name, job_data in data.get("jobconfigs", {}).items():
        #  Always apply all tags to job_tags
        job_data["job_tags"] = normalize_tags(job_data.get("job_tags", {}))

        # If job is in poolinstance_jobs, skip updating cluster_tags
        if job_name in poolinstance_jobs:
            continue

        #  Otherwise, apply tags to cluster_tags too
        for cluster in job_data.get("job_clusters", []):
            cluster["cluster_tags"] = normalize_tags(cluster.get("cluster_tags", {}))

    with open(file_path, "w") as f:
        json.dump(data, f, indent=2)

def process_pipelines(file_path):
    print(f"Processing pipelines: {file_path}")
    with open(file_path, "r") as f:
        data = json.load(f)

    for pipeline_data in data.get("pipelines", {}).values():
        pipeline_data["tags"] = normalize_tags(pipeline_data.get("tags", {}))

    with open(file_path, "w") as f:
        json.dump(data, f, indent=2)

if __name__ == "__main__":
    job_file = "combined_jobconfigs.auto.tfvars.json"
    pipeline_file = "combined_pipelines.auto.tfvars.json"

    if os.path.exists(job_file):
        process_jobconfigs(job_file)

    if os.path.exists(pipeline_file):
        process_pipelines(pipeline_file)

    if not os.path.exists(job_file) and not os.path.exists(pipeline_file):
        print("No auto.tfvars.json files found.")