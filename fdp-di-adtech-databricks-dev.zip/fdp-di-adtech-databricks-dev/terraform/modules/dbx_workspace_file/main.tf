 # Resource to copy .whl files to the workspace folder path
resource "databricks_workspace_file" "dbx_upload_files" {
  for_each = tomap({
    for file in fileset("${var.source_path}", "*.whl") : file => file
  })
  source  =  "${var.source_path}/${each.value}"
  path    =  "${var.workspace_path}/${each.value}"
}