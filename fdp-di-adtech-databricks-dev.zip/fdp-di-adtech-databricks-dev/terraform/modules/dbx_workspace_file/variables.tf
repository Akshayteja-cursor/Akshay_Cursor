variable "workspace_path" {
  description = "Databricks workspace file path"
  type = string
}

variable "source_path" {
  description = "Workflow file source folder"
  type        = string
}