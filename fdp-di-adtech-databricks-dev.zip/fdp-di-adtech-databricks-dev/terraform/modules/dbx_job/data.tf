# Data resource to get policy using policy name from job clusters
data "databricks_cluster_policy" "job_compute_policy_default" {
  name = var.job_compute_policy_default
}

data "databricks_cluster_policy" "job_compute_policy_r6id_nodes" {
  name = var.job_compute_policy_r6id_nodes
}

data "databricks_cluster_policy" "job_compute_policy_high_dbus" {
  name = var.job_compute_policy_high_dbus
}
