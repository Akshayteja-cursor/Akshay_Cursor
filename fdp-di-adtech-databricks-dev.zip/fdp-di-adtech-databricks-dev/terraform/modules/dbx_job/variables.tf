variable "jobconfigs" {
  type        = any
  description = "map of all job compute configs"
}

variable "src_environment" {
  type = string
  description = "name of the environment"
}

variable "enforce_job_compute_policies" {
  type = bool
  description = "enforce job compute policies"
  default = false
}

variable "job_compute_policy_default" {
  type = string
  description = "name of the job compute policy"
}

variable "job_compute_policy_r6id_nodes" {
  type = string
  description = "name of the job compute policy for r6id nodes"
}

variable "job_compute_policy_high_dbus" {
  type = string
  description = "name of the job compute policy for high DBUs"
}

variable "job_clusters_r6id_nodes" {
  type = list(string)
  description = "list of job cluster keys for r6id nodes"
  default = []
}

variable "job_clusters_high_dbus" {
  type = list(string)
  description = "list of job cluster keys for high DBUs"
  default = []
}
