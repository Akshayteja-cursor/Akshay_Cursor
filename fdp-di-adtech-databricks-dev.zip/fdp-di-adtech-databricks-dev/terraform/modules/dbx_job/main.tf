# resource to create Job
resource "databricks_job" "dbx_job" {
  for_each = var.jobconfigs

  name = each.key

  # Handle Job Clusters
  dynamic "job_cluster" {
    for_each = try(each.value.job_clusters, [])

    content {
      job_cluster_key = job_cluster.value.job_cluster_key

      new_cluster {
        num_workers = job_cluster.value.is_single_node ? 0 : try(job_cluster.value.num_workers, null)

        # Enable autoscale if is_single_node is false
        dynamic "autoscale" {
          for_each = job_cluster.value.is_single_node == false && try(contains(keys(job_cluster.value), "autoscale"), false) ? [1] : []
          content {
            min_workers = job_cluster.value.autoscale.min_workers
            max_workers = job_cluster.value.autoscale.max_workers
          }
        }

        # Use cluster policy if available
        policy_id = var.enforce_job_compute_policies ? (
          contains(var.job_clusters_r6id_nodes, job_cluster.value.job_cluster_key) ? data.databricks_cluster_policy.job_compute_policy_r6id_nodes.id :
          contains(var.job_clusters_high_dbus, job_cluster.value.job_cluster_key) ? data.databricks_cluster_policy.job_compute_policy_high_dbus.id :
          data.databricks_cluster_policy.job_compute_policy_default.id
        ) : null

        spark_version           = job_cluster.value.spark_version
        node_type_id            = contains(keys(job_cluster.value), "node_type_id") ? job_cluster.value.node_type_id : null
        driver_node_type_id     = (!job_cluster.value.is_single_node && contains(keys(job_cluster.value), "driver_node_type_id")) ? job_cluster.value.driver_node_type_id : null
        instance_pool_id        = try(job_cluster.value.instance_pool_id, null)
        driver_instance_pool_id = try(job_cluster.value.driver_instance_pool_id, null)
        runtime_engine          = job_cluster.value.runtime_engine
        enable_elastic_disk     = try(job_cluster.value.enable_elastic_disk, false)
        data_security_mode      = job_cluster.value.data_security_mode

        spark_conf = merge(
          job_cluster.value.is_single_node ? {
            "spark.databricks.cluster.profile" = "singleNode"
            "spark.master"                     = "local[*]"
          } : {},
          try(job_cluster.value.spark_conf, {})
        )

        aws_attributes {
          instance_profile_arn   = try(job_cluster.value.instance_profile_arn, null)
          first_on_demand        = try(job_cluster.value.aws_attributes.first_on_demand, null)
          availability           = try(job_cluster.value.aws_attributes.availability, null)
          zone_id                = try(job_cluster.value.aws_attributes.zone_id, null)
          spot_bid_price_percent = try(job_cluster.value.aws_attributes.spot_bid_price_percent, null)
          ebs_volume_count       = try(job_cluster.value.aws_attributes.ebs_volume_count, null)
        }

        spark_env_vars = try(job_cluster.value.spark_env_vars, {})

        dynamic "init_scripts" {
          for_each = try(job_cluster.value.init_scripts, [])
          content {
            volumes {
              destination = init_scripts.value
            }
          }
        }

        custom_tags = job_cluster.value.is_single_node ? merge(job_cluster.value.cluster_tags, {
          "ResourceClass" = "SingleNode"
        }) : job_cluster.value.cluster_tags
      }
    }
  }

  dynamic "task" {
    for_each = try(each.value.tasks, [])

    content {
      task_key        = try(task.value.task_name, task.value.task_key)
      job_cluster_key = (try(task.value.task_type, "") == "for_each_task" || try(task.value.task_type, "") == "sql_task" || try(task.value.sql_task, null) != null) ? null : try(task.value.job_cluster_key, null)

      # Handle Python Wheel Tasks
      dynamic "python_wheel_task" {
        for_each = try(task.value.task_type, "") == "python_wheel_task" ? [1] : []
        content {
          entry_point  = task.value.entry_point
          package_name = task.value.package_name
          # Check for parameters and use it, otherwise check for named_parameters
          parameters       = try(task.value.parameters, [])
          named_parameters = lookup(task.value, "parameters", null) != null ? try(task.value.named_parameters, {}) : null
        }
      }

      # Handle Notebook Tasks
      dynamic "notebook_task" {
        for_each = try(task.value.task_type, "") == "notebook_task" ? [1] : []
        content {
          notebook_path   = task.value.notebook_path
          base_parameters = try(task.value.base_parameters, {})
        }
      }

      # Handle Spark Python Tasks
      dynamic "spark_python_task" {
        for_each = try(task.value.task_type, "") == "spark_python_task" ? [1] : []
        content {
          python_file = task.value.python_file
          parameters  = try(task.value.parameters, [])
        }
      }

      # Handle condition if-else Tasks
      dynamic "condition_task" {
        for_each = try(task.value.task_type, "") == "condition_task" ? [1] : []
        content {
          right = try(task.value.right)
          left  = try(task.value.left)
          op    = try(task.value.op)
        }
      }

      dynamic "run_job_task" {
        for_each = try(task.value.task_type, "") == "run_job_task" ? [1] : []
        content {
          job_id         = task.value.job_id
          job_parameters = try(task.value.job_parameters, null)
        }
      }

      # Handle SQL Tasks
      dynamic "sql_task" {
        for_each = try(task.value.task_type, "") == "sql_task" || try(task.value.sql_task, null) != null ? [1] : []
        content {
          warehouse_id = try(task.value.sql_task.warehouse_id, task.value.warehouse_id, null)

          dynamic "file" {
            for_each = try(task.value.sql_task.file, null) != null || try(task.value.file, null) != null || try(task.value.path, null) != null ? [1] : []
            content {
              path   = try(task.value.sql_task.file.path, task.value.file.path, task.value.path, null)
              source = try(task.value.sql_task.file.source, task.value.file.source, task.value.source, null)
            }
          }
        }
      }

      timeout_seconds = try(task.value.timeout_seconds, 0)


      ////// Handle for_each_task to loop over tasks //////////
      dynamic "for_each_task" {
        for_each = try(task.value.task_type, "") == "for_each_task" ? [1] : []
        content {
          inputs      = task.value.inputs
          concurrency = task.value.concurrency
          task {
            task_key        = task.value.task.task_key
            job_cluster_key = try(task.value.job_cluster_key, null)
            run_if          = try(task.value.task.run_if, "ALL_SUCCESS")

            dynamic "python_wheel_task" {
              for_each = try(task.value.task.python_wheel_task, null) != null ? [1] : []
              content {
                entry_point  = task.value.task.python_wheel_task.entry_point
                package_name = task.value.task.python_wheel_task.package_name

                # Check for parameters and use it, otherwise check for named_parameters
                parameters       = try(task.value.task.python_wheel_task.parameters, [])
                named_parameters = try(task.value.task.python_wheel_task.named_parameters, {})
              }
            }

            dynamic "notebook_task" {
              for_each = try(task.value.task.notebook_task, null) != null ? [1] : []
              content {
                notebook_path   = task.value.task.notebook_task.notebook_path
                base_parameters = try(task.value.task.notebook_task.base_parameters, {})
              }
            }

            dynamic "spark_python_task" {
              for_each = try(task.value.task.spark_python_task, null) != null ? [1] : []
              content {
                python_file = task.value.task.spark_python_task.python_file
                parameters  = try(task.value.task.spark_python_task.parameters, [])
              }
            }

            dynamic "run_job_task" {
              for_each = try(task.value.task.run_job_task, null) != null ? [1] : []
              content {
                job_id         = task.value.task.run_job_task.job_id
                job_parameters = try(task.value.task.run_job_task.job_parameters, null)
              }
            }

            dynamic "sql_task" {
              for_each = try(task.value.task.sql_task, null) != null ? [1] : []
              content {
                warehouse_id = try(task.value.task.sql_task.warehouse_id, null)

                dynamic "file" {
                  for_each = try(task.value.task.sql_task.file, null) != null ? [1] : []
                  content {
                    path   = try(task.value.task.sql_task.file.path, null)
                    source = try(task.value.task.sql_task.file.source, null)
                  }
                }
              }
            }

            # Add library under for_each_task for diff tasks
            dynamic "library" {
              for_each = try(task.value.task.libraries, [])
              content {
                dynamic "pypi" {
                  for_each = library.value.library_source == "pypi" ? [1] : []
                  content {
                    package = library.value.package
                  }
                }

                jar = library.value.library_source == "jar" ? try(library.value.jar_path[0], "") : ""

                whl = library.value.library_source == "workspace" ? try(library.value.workspace_path[0], "") : ""
              }
            }
            timeout_seconds = try(task.value.task.for_each_task.task.timeout_seconds, 0)
          }
        }
      } ///////// end of for_each_task

      ##### Handling Libraries #####
      # For PyPI or Workspace
      dynamic "library" {
        for_each = try(task.value.libraries, [])
        content {
          # PyPI Library
          dynamic "pypi" {
            for_each = library.value.library_source == "pypi" ? [1] : []
            content {
              package = library.value.package
            }
          }

          # Handle jar Libraries
          jar = library.value.library_source == "jar" ? try(library.value.jar_path[0], "") : ""

          # Handle Workspace Libraries (Whl files)
          whl = library.value.library_source == "workspace" ? try(library.value.workspace_path[0], "") : ""
        }
      }

      # email notifications
      email_notifications {
        on_success = try(each.value.email_notifications.on_success, [])
        on_failure = try(each.value.email_notifications.on_failure, [])
      }

      # max retries and timeout
      max_retries               = try(task.value.max_retries, 0)
      min_retry_interval_millis = try(task.value.min_retry_interval_millis, 300000)
      retry_on_timeout          = try(task.value.retry_on_timeout, false)

      dynamic "depends_on" {
        for_each = try(task.value.depends_on, [])
        content {
          task_key = try(depends_on.value.task_key, depends_on.value)
          outcome  = try(depends_on.value.outcome, null)
        }
      }

      # run if all-succeded
      run_if = try(task.value.run_if, "ALL_SUCCESS")
    }
  }

  dynamic "schedule" {
    for_each = try(each.value.schedule, null) != null ? [1] : []
    content {
      quartz_cron_expression = each.value.schedule
      timezone_id            = each.value.timezone_id
      pause_status           = each.value.pause_status
    }
  }

  max_concurrent_runs = try(each.value.max_concurrent_runs, 1)

  dynamic "queue" {
    for_each = try(each.value.queue, null) != null ? [1] : []
    content {
      enabled = each.value.queue
    }
  }
  tags = each.value.job_tags

  dynamic "parameter" {
    for_each = try(each.value.parameters, [])
    content {
      name    = parameter.value.name
      default = parameter.value.default
    }
  }
}

# data block to fetch service principal svc_astronomer_nonprod or svc_astronomer_prod
data "databricks_service_principal" "data_svc_astronomer" {
  display_name = contains(["dev", "develop", "test", "qa"], var.src_environment) ? "svc_astronomer_nonprod" : "svc_astronomer_prod"
}

data "databricks_service_principal" "data_svc_montecarlo" {
  display_name = contains(["dev", "develop", "test"], var.src_environment) ? "Svc_MonteCarlo_Monitor" : "Svc_MonteCarlo_Monitor_Prod"
}

data "databricks_service_principal" "data_svc_terraform_testing" {
  display_name = contains(["dev", "develop", "test", "qa"], var.src_environment) ? "svc_terraform_testing_nonprod" : "svc_terraform_testing_prod"
}
# data block to fetch service principal svc_revefi_nonprod_poc
# data "databricks_service_principal" "data_svc_revefi_nonprod_poc" {
#   display_name = "svc_revefi_nonprod_poc"
# }

# Job permissions management
resource "databricks_permissions" "dbx_job_permissions" {
  for_each = { for key, value in var.jobconfigs : key => value }
  job_id   = databricks_job.dbx_job[each.key].id

  access_control {
    group_name       = "FDP_Data_Governance_Team"
    permission_level = "CAN_VIEW"
  }

  dynamic "access_control" {
    for_each = contains(["dev", "test", "develop", "qa"], var.src_environment) ? [1] : []
    content {
      group_name       = "DataOps_Support_Team"
      permission_level = "CAN_VIEW"
    }
  }

  dynamic "access_control" {
    for_each = contains(["prod", "prd", "PROD"], var.src_environment) ? [1] : []
    content {
      group_name       = "support_team"
      permission_level = "CAN_VIEW"
    }
  }

  access_control {
    group_name       = "Adtech_Development_Team"
    permission_level = var.src_environment == "dev" || var.src_environment == "qa" || var.src_environment == "develop" || var.src_environment == "test" ? "CAN_MANAGE" : "CAN_VIEW"
  }

  access_control {
    group_name       = "Adsales_Development_Team"
    permission_level = var.src_environment == "dev" || var.src_environment == "qa" || var.src_environment == "develop" || var.src_environment == "test" ? "CAN_MANAGE" : "CAN_VIEW"
  }

  access_control {
    service_principal_name = data.databricks_service_principal.data_svc_astronomer.application_id
    permission_level       = "CAN_MANAGE_RUN"
  }
  
  access_control {
    service_principal_name = data.databricks_service_principal.data_svc_montecarlo.application_id
    permission_level       = "CAN_VIEW"
  }

  # Testing per-domain service principal
  dynamic "access_control" {
    for_each = contains(["dev", "test", "develop", "qa"], var.src_environment) ? [1] : []
    content {
      service_principal_name = data.databricks_service_principal.data_svc_terraform_testing.application_id
      permission_level       = "CAN_MANAGE"
    }
  }

  access_control {
    group_name = "fdp_devops_manage_access"
    permission_level       = "CAN_MANAGE"
  }

  # access_control {
  #   service_principal_name = data.databricks_service_principal.data_svc_revefi_nonprod_poc.application_id
  #   permission_level       = "CAN_VIEW"
  # }
}
