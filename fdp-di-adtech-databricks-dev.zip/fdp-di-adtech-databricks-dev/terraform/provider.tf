terraform {
  required_providers {
    databricks = {
      source  = "databricks/databricks"
      version = "1.84.0"
    }
  }
}

# Declare the aws provider
provider "aws" {
  region  = var.AWS_REGION
  default_tags {
    tags = {
      owner   = "fdp-di-adtech-databricks"
      project = "fdp-di-adtech-databricks"
      env     = var.ENVIRONMENT
    }
  }
}

provider "databricks" {
  alias         = "databricks_provider"
  host          = var.databricks_host
  client_id     = var.client_id
  client_secret = var.client_secret
}