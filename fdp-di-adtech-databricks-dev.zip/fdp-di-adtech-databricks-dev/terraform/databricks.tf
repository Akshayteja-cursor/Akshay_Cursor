# module to create databricks workspace file
module "dbx_workspace_file" {
  source = "./modules/dbx_workspace_file"

  source_path    = var.source_path
  workspace_path = var.workspace_path
}

# module to create job and tasks
module "dbx_job" {
  source = "./modules/dbx_job"

  jobconfigs      = var.jobconfigs
  src_environment = var.src_environment

  job_compute_policy_default    = var.job_compute_policy_default
  job_compute_policy_r6id_nodes = var.job_compute_policy_r6id_nodes
  job_compute_policy_high_dbus  = var.job_compute_policy_high_dbus

  job_clusters_r6id_nodes = var.job_clusters_r6id_nodes
  job_clusters_high_dbus  = var.job_clusters_high_dbus

  enforce_job_compute_policies = var.enforce_job_compute_policies
}
