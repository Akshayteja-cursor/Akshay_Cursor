terraform {
    backend "s3" {
        bucket         = "fdp-di-dbx-adtech-terraform-state-dev"
        region         = "us-west-2"
        key            = "terraform/dev.tfstate"
        encrypt        = true
        dynamodb_table = "fdp-di-dbx-adtech-terraform-state-dev"
    }
}