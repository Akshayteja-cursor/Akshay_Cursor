######### Provider parameters #########
aws_region  = "us-west-2"
tag_owner   = "fdp-di-adtech-databricks"
tag_project = "fdp-di-adtech-databricks"
tag_env     = "prod"

#### whl notebook parameters ####
# Path of generated whl file to be placed
workspace_path = "/Workspace/All_Domain_Wheel_Files/Adtech/dist"