terraform {
    backend "s3" {
        bucket         = "fdp-di-dbx-adtech-terraform-state-prod"
        region         = "us-west-2"
        key            = "terraform/prod.tfstate"
        encrypt        = true
        #dynamodb_table = "fdp-di-dbx-adtech-terraform-state-prod"
    }
}