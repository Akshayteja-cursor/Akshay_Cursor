########################################################################
# Provider Parameters
########################################################################
variable "aws_region" {
  description = "AWS provider region"
  type        = string
  default     = "us-west-2"
}

variable "tag_owner" {
  description = "Project owner"
  type        = string
  default     = "fdp-di-adtech-databricks"
}

variable "tag_project" {
  description = "Project name"
  type        = string
  default     = "adtech-databricks"
}

variable "tag_env" {
  description = "Deployment environment"
  type        = string
}

variable "databricks_host" {
  description = "Databricks workspace URL"
  type        = string
}

variable "client_id" {
  description = "Databricks service principal client ID"
  type        = string
  sensitive   = false
}

variable "client_secret" {
  description = "Databricks service principal client secret"
  type        = string
  sensitive   = true
}

variable "workspace_path" {
  description = "Databricks workspace file path"
  type = string
}

variable "source_path" {
  description = "Workflow file source folder"
  type        = string
}

variable "src_environment" {
  type = string
  description = "name of the environment"
}

####### Job and task parameters ########
variable "jobconfigs" {
  type        = any
  description = "map of all job compute configs"
}

####### Cluster policy parameters ########
variable "enforce_job_compute_policies" {
  type = bool
  description = "enforce job compute policies"
  default = false
}

variable "job_compute_policy_default" {
  type = string
  description = "name of the job compute policy"
}

variable "job_compute_policy_r6id_nodes" {
  type = string
  description = "name of the job compute policy for r6id nodes"
}

variable "job_compute_policy_high_dbus" {
  type = string
  description = "name of the job compute policy for high DBUs"
}

variable "job_clusters_r6id_nodes" {
  type = list(string)
  description = "list of job cluster keys for r6id nodes"
  default = []
}

variable "job_clusters_high_dbus" {
  type = list(string)
  description = "list of job cluster keys for high DBUs"
  default = []
}
