# fdp-di-adtech-databricks

This repository stores infrastructure definitions and application code to automate operations on Databricks.

- [Repo Contents](#repo-contents)
- [Usage](#usage)
  - [Workflow](#workflow)
  - [Scheduling](#scheduling)

---

## Repo Contents

- __[`terraform/`](./terraform/):__
  Infrastructure supporting deployment and execution on Databricks account

  - __[`environments/`](./terraform/environments/):__
    Environment configurations and parameter values
  
  - __[`main.tf`](./terraform/main.tf):__
    Resources to be managed by Terraform

  - __[`providers.tf`](./terraform/providers.tf):__
    Provider configurations

  - __[`variables.tf`](./terraform/variables.tf):__
    Input variable definitions

  - __[`versions.tf`](./terraform/versions.tf):__
    Required providers and version constraints

  - __[`scripts/`](./scripts/):__
    - Scripts used to pause and unpause pipeline at particular cron timing  as of now not using these and
    maintain workspace statefie for dev env
    - `add_default_cluster_and_job_tags.py` - this script will take care of adding default `domain_name` and `environment` tag to all Job, Job clusters and DLT Pipelines.
  

- __[`.github/workflows/`](./.github/workflows/):__
  GitHub Actions workflows for automated deployments

---

## Usage

### Workflow

1. Clone and enter the repository

   > ```sh
   > git clone https://github.com/fox-dataplatform/fdp-di-adtech-databricks
   > cd fdp-di-adtech-databricks/
   > ```
2. Create a branch for changes

   > ```sh
   > Create feature branch from 'main'/'develop' branch depending on requirement
   > git checkout -b my-new-stuff
   > ```

3. Add your changes under the path [`environments/`](./environments/)
  - **Note:** Respective Jobconfig name should be started with **jobconfig*(unique_name).json**

   > Under **environments/dev/dev.tfvars** or **environments/prod/prod.tfvars** :\
   > Changes in this block includes adding lib path and Cluster library to an existing cluster
   >>  workspace_path - Path of generated whl file to be placed in Databricks workspace
   >> workspace_job_config_path - Path of Job config folder to be placed in Databricks workspace

 - Sample schema for cluster library :
 >```
 > # Path of generated whl file to be placed
 > workspace_path = "/Workspace/All_Domain_Wheel_Files/data-infrastructure/dist"
 > ```

  - environments/jobconfig*(unique_name).json:<br>
    Here JSON file contains a mapping of job names to their respective configurations. Each key represents the job name, and the corresponding value holds the configuration details for that job. These job can also be provisioned with multiple job computes/clusters and Tasks can utilize any Job computes

> **JobCompute**:
> schema defines:<br>
>    eg: save this file as **jobconfig*(unique_name).json**
>>
>>  `job_cluster_key`- cluster name and it has to refernce in respective tasks \
>>  `is_single_node`- **false** (if it's multinode), **true** (if it's single node) \
>> `data_security_mode` - User access mode
>>    SINGLE_USER or USER_ISOLATION or NO_ISOLATION
>>  `num_workers` - number of worker nodes if autoscale{ } is not defined \
>>  `autoscale { }` - defines autoscaling of min and max number of worker nodes if **num_workers** is not defined \
>>      **Note:** either num_workers or autoscale{ } should be defined \
>>  `policy_name` - policy name \
>>  `runtime_engine` - runtime engine either PHOTON or STANDARAD \
>>  `spark_conf()` - spark configuration values, if no values keep it as null or you can delete \
>>     eg:\
>>        "spark_conf" : null\
>>          or \
>>          "spark_conf" : { \
>>        "spark.hadoop.fs.gs.auth.service.account.private.key.id" : "{{secrets/test_private.key}}", \
>>        "spark.hadoop.google.cloud.auth.service.account.enable" : true,\
>>        "spark.hadoop.fs.gs.project.id": "1234-xyz",\
>>        "spark.hadoop.fs.gs.auth.service.account.email" : "xyz123.com"\
>>      }\
>>  `instance_profile_arn` - Instance profile ARN
>>  
>>  **task parameters**: \
>>   `task_name` - Name of the task\
>>   `task_key` - Alternate task identifier (supported for Databricks native task JSON shape)\
>>   `task_type` - As of it supports `python_wheel_task, notebook_task, spark_python_task, sql_task, for_each_task, condition_task and run_job_task`\
>>   `job_cluster_key` - created job cluster name (used for Spark compute tasks; not used for `sql_task` and `for_each_task`)\
>>                  For python_wheel_task requires entry_point, package_name.\
>>                  Simlarly notebook_task requires notebook path \
>>                  For sql_task provide `warehouse_id` and `file` (`path` and optional `source`)\
>>   `parameters` - Specific parameters if required \
>>             -Note:_ For notebook it is mentioned as a map of `base_parameter` having key and value \
>>                   _ For whl task it will be `parameters` and also supports `named_paramertes` which is map of key and value \
>>   `libraries` - List of libraries with library_source and package or whl path values \
>>   `depends_on` - defines name of dependent task \
>>    sample depends_on:
>>   1. "depends_on": [
        >>          "sample_for_each_whl"
        >>        ] \
        >>     OR
>>    2. If `outcome` is present:\
         >>    "depends_on": [{\
         >>            "task_key":"sample-if-else",\
         >>            "outcome":"true"
         >>          }]\
         >>     OR
>>    3. if `task_key` is present. Here eg: 1 and 3 does the same\
         >>   "depends_on": [
         >>          {
         >>            "task_key":"sample_for_each_whl"
         >>          }]
>>
>> **cluster parameters**: \
>> `cluster_tags`- cluster specific tags \
>> `job_tags`- job specific tags \
>> `schedule` - scheduling of jobs, if you don't want you can delete this \
>> `email_notifications` - list of email notications on success and failure \
>> `queue` - Enale or disable queue for jobs \
>> `max_concurrent_runs` - maximum concurrent jobs default to 1 \
>> `min_retry_interval_millis` - min retry of jobs in milli sec, default set to _300000 millisec(5 min)_ \
>> `retry_on_timeout` - retry on timeout default to _false_ \
>> `spark_env_vars`- (Optional) Map with environment variable key-value pairs to fine-tune Spark clusters \
>> `parameters` - this defines Job level parameters \
>> `aws_attirbutes` - (Optional) configuration block contains attributes related to clusters running on Amazon Web Services \

- Default Job permission will be added once you created Jobs and they have restricted access:
```
DEV:
Group: Data_Frame_Platform_Access -- Can Manage (Restrict)
Service User: svc_astronomer_nonprod -- Can Manage Run (Restrict)

PROD:
Group: Data_Frame_Platform_Access --- Can View (Restrict)
Service User: svc_astronomer_prod ---- Can Manage Run (Restrict)
```

- Below is Sample schema for creating jobs that uses **JobCompute**:
- Note: It includes sample json for `python_wheel_task, notebook_task, spark_python_task, sql_task, for_each_task, condition_task and run_job_task`\

``````
{
    "iac_sample_jobcompute_adtech_databricks_job": {
      "job_clusters": [
        {
          "job_cluster_key": "iac_jobcompute_multinode",
          "is_single_node": false,
          "data_security_mode": "USER_ISOLATION",
          "autoscale": {
            "min_workers": 2,
            "max_workers": 3
          },
          "policy_name": null,
          "spark_version": "15.4.x-scala2.12",
          "node_type_id": "r5d.large",
          "driver_node_type_id": "r5d.large",
          "enable_elastic_disk": true,
          "runtime_engine": "PHOTON",
          "aws_attributes": {
            "first_on_demand": 1,
            "availability": "SPOT_WITH_FALLBACK",
            "zone_id": "us-west-2a",
            "spot_bid_price_percent": 50,
            "ebs_volume_count": 0
          },
          "spark_env_vars": {
            "spark_env_vars": "/databricks/python3/bin/python3"
          },
          "spark_conf": {
            "spark.hadoop.fs.gs.auth.service.account.private.key.id": "{{secrets/test_private.key}}",
            "spark.hadoop.google.cloud.auth.service.account.enable": true,
            "spark.hadoop.fs.gs.project.id": "sample-project-id"
          },
          "instance_profile_arn": "arn:aws:iam::12345:instance-profile/databricks-instance-role",
          "cluster_tags": {
            "Domain_name": "devops",
            "deployed-by": "terraform"
          }
        },
        {
          "job_cluster_key": "iac_jobcompute_singlenode",
          "is_single_node": true,
          "data_security_mode": "SINGLE_USER",
          "autoscale": {
            "min_workers": 2,
            "max_workers": 3
          },
          "policy_name": null,
          "spark_version": "15.4.x-scala2.12",
          "node_type_id": "r5d.large",
          "driver_node_type_id": "r5d.large",
          "enable_elastic_disk": true,
          "runtime_engine": "PHOTON",
          "spark_conf": {
            "spark.hadoop.google.cloud.auth.service.account.enable": true,
            "spark.hadoop.fs.gs.project.id": "sample-project-id"
          },
          "cluster_tags": {
            "Domain_name": "devops",
            "deployed-by": "terraform"
          }
        }
      ],
      "schedule": "0 0 * ? * *",
      "pause_status": "PAUSED",
      "timezone_id": "UTC",
      "email_notifications": {
        "on_success": [
          "xyz@fox.com"
        ],
        "on_failure": [
          "xyz@fox.com"
        ]
      },
      "parameters": [
        {
          "name": "test_job_param",
          "default": "null"
        }
      ],
      "job_tags": {
        "team": "fdp-data-infrastrucure",
        "Domain_name": "devops"
      },
      "tasks": [
        {
          "task_name": "sample_whl_task_with_param",
          "task_type": "python_wheel_task",
          "entry_point": "main",
          "package_name": "ingest_framework",
          "job_cluster_key": "iac_jobcompute_multinode",
          "parameters": [
            "--config",
            "file:/sample_path/sample.yml"
          ],
          "libraries": [
            {
              "library_source": "workspace",
              "workspace_path": [
                "/Workspace/sample_path/ingest_framework-0.0.5-py3-none-any.whl"
              ]
            }
          ],
          "queue": true,
          "max_concurrent_runs": 1,
          "max_retries": 2,
          "min_retry_interval_millis": 300000,
          "retry_on_timeout": true
        },
        {
          "task_name": "sample_whl_with_named_param_and_depends_on",
          "task_type": "python_wheel_task",
          "entry_point": "main",
          "package_name": "ingest_framework",
          "job_cluster_key": "iac_jobcompute_multinode",
          "named_parameters": {
                "config": "file:/Workspace/sample_path/ingest_framework-0.0.5-py3-none-any.whl"
              },
          "depends_on": [
            {
              "task_key":"sample-if-else",
              "outcome":"true"
            },
            {
              "task_key":"sample-if-else-2",
              "outcome":"false"
            }
          ],
          "libraries": [
            {
              "library_source": "workspace",
              "workspace_path": [
                "/Workspace/sample_path/ingest_framework-0.0.5-py3-none-any.whl"
              ]
            }
          ],
          "queue": true,
          "max_concurrent_runs": 1,
          "max_retries": 3,
          "min_retry_interval_millis": 400000,
          "retry_on_timeout": true
        },
        {
          "task_name": "sample_notebook_task_base_param",
          "task_type": "notebook_task",
          "notebook_path": "/Workspace/sample_path/test_notebook",
          "job_cluster_key": "iac_jobcompute_singlenode",
          "base_parameters": {
            "dev_file": "dev_sample.yml",
            "test_file": "test_sample.yml"
          },
          "libraries": [
            {
              "library_source": "jar",
              "jar_path": [
                "/Volumes/fox_bi_qa/raw_ad_sales/jars/7de2af08_305c_463e_b9c2_9e8b94789441-RedshiftJDBC42_1_2_43_1067-aab9f.jar"
              ]
            }
          ]
        },
        {
          "task_name": "samle_pypi_task",
          "task_type": "spark_python_task",
          "python_file": "/Workspace/Users/sample_path/test_python.py",
          "job_cluster_key": "iac_jobcompute_multinode",
          "parameters": [
            "--config",
            "file:/sample_path/sample.yml"
          ],
          "libraries": [
            {
              "library_source": "pypi",
              "package": "jinja2"
            }
          ]
        },
        {
          "task_name": "sample-if-else",
          "task_type": "condition_task",
          "depends_on": [
            "samle_pypi_task"
          ],
          "run_if": "ALL_SUCCESS",
          "op": "EQUAL_TO",
          "left": "{{job.parameters.test_job_param}}",
          "right": "{{job.start_time.iso_date}}"
        },
        {
          "task_name": "sample-if-else-2",
          "task_type": "condition_task",
          "run_if": "ALL_SUCCESS",
          "op": "EQUAL_TO",
          "left": "{{job.parameters.test_job_param}}",
          "right": "{{job.start_time.iso_date}}"
        },
        {
          "task_name": "sample_run_job",
          "task_type": "run_job_task",
              "job_id" : "1234567",
          "run_if": "ALL_SUCCESS",
              "job_parameters": {
              "job_param_run_job": "{{job.name}}",
              "job_param_run_job_1": "{{job.id}}"
            },
            "depends_on": [
              {
              "task_key":"samle_pypi_task"
              }]
        },
        {
          "task_name": "sample_sql_file_task",
          "task_type": "sql_task",
          "depends_on": [
            {
              "task_key": "sample_run_job"
            }
          ],
          "run_if": "ALL_SUCCESS",
          "sql_task": {
            "warehouse_id": "44f1aad29f6f0fcd",
            "file": {
              "source": "WORKSPACE",
              "path": "/Workspace/sample_path/sql/refresh_mv.sql"
            }
          },
          "timeout_seconds": 0
        },
        {
          "task_key": "sample_sql_file_task_native_shape",
          "depends_on": [
            {
              "task_key": "sample_sql_file_task"
            }
          ],
          "run_if": "ALL_SUCCESS",
          "sql_task": {
            "warehouse_id": "44f1aad29f6f0fcd",
            "file": {
              "source": "WORKSPACE",
              "path": "/Workspace/sample_path/sql/refresh_mv.sql"
            }
          },
          "timeout_seconds": 0
        },
        {
          "task_name": "sample_for_each_whl",
          "task_type": "for_each_task",
          "inputs": "{{tasks.samle_pypi_task.values.my_value}}",
          "job_cluster_key": "iac_jobcompute_multinode",
          "concurrency": 2,
          "depends_on": [
            "samle_pypi_task"
          ],
          "task": {
            "task_key": "test_whl_task",
            "run_if": "ALL_SUCCESS",
            "python_wheel_task": {
              "package_name": "delta_etl",
              "entry_point": "main",
              "named_parameters": {
                "config": "file:/Workspace/sample_path/ingest_framework-0.0.5-py3-none-any.whl"
              }
            },
            "libraries": [
              {
                "library_source": "workspace",
                "workspace_path": [
                  "/Workspace/sample_path/ingest_framework-0.0.5-py3-none-any.whl"
                ]
              }
            ],
            "timeout_seconds": 0
          }
        },
        {
          "task_name": "sample_for_each_notebook",
          "task_type": "for_each_task",
          "inputs": "{{tasks.samle_pypi_task.values.my_value}}",
          "job_cluster_key": "iac_jobcompute_multinode",
          "concurrency": 2,
          "depends_on": [
            "sample_for_each_whl"
          ],
          "task": {
            "task_key": "test_notebook_task",
            "run_if": "ALL_SUCCESS",
            "notebook_task": {
              "notebook_path": "/Workspace/sample_path/test_notebook",
              "base_parameters": {
                "dev_file": "dev_sample.yml",
                "test_file": "test_sample.yml"
              }
            },
            "libraries": [
                {
                  "library_source": "jar",
                  "jar_path": [
                    "/Volumes/fox_bi_qa/raw_ad_sales/jars/7de2af08_305c_463e_b9c2_9e8b94789441-RedshiftJDBC42_1_2_43_1067-aab9f.jar"
                  ]
                }
              ]
          }
        },
        {
          "task_name": "sample_for_each_run_job",
          "task_type": "for_each_task",
          "inputs": "{{tasks.samle_pypi_task.values.my_value}}",
          "concurrency": 2,
          "depends_on": [
            "sample_for_each_whl"
          ],
          "task": {
            "task_key": "sample_run_job_task",
            "run_if": "ALL_SUCCESS",
            "run_job_task": {
              "job_id" : "1234567",
              "job_parameters": {
                "job_param_run_job": "{{job.name}}",
                "job_param_run_job_1": "{{job.id}}"
            }
          }
         }
        }
      ],
      "timeout_seconds": 0
    }
  }

``````

- **`Under scripts`**: \
    Included a script `add_default_cluster_and_job_tags.py`- This script will take care of adding default `domain_name` and `environment` tag to all Job, Job clusters and DLT Pipelines.\
    Note: Default cluster_tags and tags from pool instance are conflicting so provided option `poolinstance_jobs` to exclude aadding tagging to list of jobs where domain_name should NOT be added to cluster_tags \
    For eg: poolinstance_jobs = ["poolInstance_job1", "poolInstance_job2"]

4. Commit changes and push to GitHub
   > ```sh
   > git add -A
   > git commit -m "Added my new changes"
   > git push --set-upstream=origin my-new-stuff
   > ```

5. Open a pull request from the new branch to the **dev or main** branch this will trigger validation in Non Prod(Dev) or PROD environment respectively

6. Once after validation is successful merge the PR to **dev or main** branch this will trigger deployment.
   And once after build has successful this will deploy changes into DEV or PROD environment respectively

### Scheduling
Cron expression and respective timezone for Jobs
Note: Here uses Quartz schedular expressions
>```
  >  "schedule": "0 10 16-17 * * ?",
  >  "timezone_id": "UTC"
  >  ```
Execution schedules can be specified using *cron expressions* in quartz expression.

- [Cron expressions reference](https://www.quartz-scheduler.org/documentation/quartz-2.3.0/tutorials/crontrigger.html)

---

## Authors
