from setuptools import setup, find_packages

setup(
    name="adtech_ingestion",
    version="0.0.1",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    install_requires=[
        "pyyaml>=5.3.1",
        "databricks-sdk==0.20.0",
        'boto3',
        'botocore'
    ],
    entry_points={
        'console_scripts': [
            'adtech_etl=adtech_etl.main:main',
        ],
        "packages": [
            "main=adtech_etl.main:main"
        ]
    },
    author="Tissa Rathnayake",
    author_email="Tissa.Rathnayake@fox.com",
    description="Framework to read from s3 and write to adtech Lake-Uniform.",
    long_description=open('README.md').read(),
    long_description_content_type="text/markdown",
    #url="https://github.com/",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.9',
)