# Databricks notebook source
event_start_date = dbutils.jobs.taskValues.get("Set_Job_Parameters", "event_start_date_gam")
event_end_date = dbutils.jobs.taskValues.get("Set_Job_Parameters", "event_end_date_gam")
skip_gam = dbutils.jobs.taskValues.get("Set_Job_Parameters", "skip_gam")

# COMMAND ----------

spark.conf.set("spark.sql.shuffle.partitions", "auto")

# COMMAND ----------

print(f"Running for {event_start_date} to {event_end_date}")

# COMMAND ----------

if skip_gam == "true":
    dbutils.notebook.exit("Skipping GAM Silver Daily")

# COMMAND ----------

# MAGIC %md PROCESSING LOGIC

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql import types as T
from datetime import datetime, timedelta

# COMMAND ----------

# Load data sources from Unity Catalog
def load_table(table_name):
    return spark.read.table(f"fox_bi_prod.silver_ads.{table_name}")

# COMMAND ----------

from datetime import datetime, timedelta
from pyspark.sql.functions import col, lit, when, coalesce, round



def load_gam(event_start_date=None, event_end_date=None):
    """
    Loads 'ft_gam_d_delivery_incr slot_level' with partition filters.
    """

    """
    Replace table name below with ft_gam_ad_delivery_slot_level later to keep it consistent
    """

    fw = (
        load_table("ft_gam_ad_delivery_ad_unit_level_daily")
        .filter((col("event_date") >= lit(event_start_date)) & (col("event_date") <= lit(event_end_date)))
    )

    print(f"GAM Partition Scan Range: '{event_end_date}' to '{event_end_date}'")
    return fw

# COMMAND ----------

# Load Source Table:
gam_slot_level = load_gam(event_start_date,event_end_date)

# COMMAND ----------

column_list = [
    "authority_code",
    "network_group_id",
    "event_date",
    "advertiser_id",
    "advertiser_name",
    "line_item_id",
    "line_item_name",
    "line_item_type",
    "sales_channel_type",
    "order_id",
    "order_name",
    "referrer_url",
    "country_name",
    "region_name",
    "metro_name",
    "city_name",
    "postal_code",
    "ad_unit_id",
    "site_section_detail",
    "network",
    "app_name",
    "ownership_type",
    "device_type_detail",
    "device_type",
    "distribution_partner_id",
    "distributor",
    "page_type_detail",
    "ad_unit_category",
    "ad_unit_format",
    "ad_unit_detail_name",
    "creative_id",
    "creative_name",
    "creative_pixel_size",
    "is_video_ad_fallback_request",
    "video_ad_fallback_position",
    "is_companion_ad",
    "video_asset_id",
    "video_asset_name",
    "series_id",
    "series_name",
    "business_unit",
    "content_key_hash",
    "line_item_key_hash",
]

# COMMAND ----------

gam_daily_level = gam_slot_level.groupBy(column_list).agg(
    F.sum(gam_slot_level.ad_requests).cast('bigint').alias("total_ad_requests"),
    F.sum(gam_slot_level.unmatched_ad_requests).cast('bigint').alias("total_unmatched_ad_requests"),
    F.sum(gam_slot_level.ad_responses).cast('bigint').alias("total_ad_responses"),
    F.sum(gam_slot_level.ad_impressions).cast('bigint').alias("total_ad_impressions"),
    F.sum(gam_slot_level.unfilled_impressions).cast('bigint').alias("total_unfilled_impressions"),
    F.sum(gam_slot_level.ad_clicks).cast('bigint').alias("total_ad_clicks"),
    F.round(F.avg(gam_slot_level.ad_click_through_rate), 14).cast("double").alias("avg_ad_click_through_rate"),
    F.round(F.avg(gam_slot_level.ad_cost_per_click_usd), 14).cast("double").alias("avg_ad_cost_per_click_usd"),
    F.round(F.sum(gam_slot_level.ad_revenue_usd), 14).cast("double").alias("total_ad_revenue_usd"),
    F.round(F.avg(gam_slot_level.ad_cost_per_mile_usd), 14).cast("double").alias("avg_ad_cost_per_mile_usd"),
    F.round(F.avg(gam_slot_level.max_ads), 14).cast("double").alias("avg_max_ads"),
    F.round(F.avg(gam_slot_level.max_duration_secs), 14).cast("double").alias("avg_max_duration_secs"),
    F.round(F.avg(gam_slot_level.ads_selected), 14).cast("double").alias("avg_ads_selected"),
    F.round(F.avg(gam_slot_level.ad_duration_secs), 14).cast("double").alias("avg_ad_duration_secs"),
    F.round(F.avg(gam_slot_level.time_filled_secs), 14).cast("double").alias("avg_time_filled_secs"),
    F.sum(gam_slot_level.total_ads_allowed).cast('bigint').alias("total_ads_allowed"),
    F.sum(gam_slot_level.total_ads_availed).cast('bigint').alias("total_ads_availed"),
    F.sum(gam_slot_level.total_ad_duration_allowed_secs).cast('bigint').alias("total_ad_duration_allowed_secs"),
    F.sum(gam_slot_level.total_ad_duration_availed_secs).cast('bigint').alias("total_ad_duration_availed_secs"),
    F.sum(gam_slot_level.total_ad_time_filled_secs).cast('bigint').cast('bigint').alias("total_ad_time_filled_secs"),
    F.sum(gam_slot_level.total_slate_duration_secs).cast('bigint').alias("total_slate_duration_secs"),
    F.round(F.avg(gam_slot_level.avg_slate_duration_secs), 14).cast("double").alias("avg_slate_duration_secs"),
    F.round(F.avg(gam_slot_level.slate_percentage), 14).cast("double").alias("avg_slate_percentage"),
    F.round(F.avg(gam_slot_level.fill_rate), 14).cast("double").alias("avg_fill_rate"),
    F.sum(gam_slot_level.total_breaks_complete_unfilled).cast('bigint').alias("total_breaks_complete_unfilled"),
    F.sum(gam_slot_level.total_breaks).cast('bigint').alias("total_breaks"),
    F.sum(gam_slot_level.total_error_count).cast('bigint').alias("total_error_count"),
    (F.sum(gam_slot_level.ad_responses) + F.sum(gam_slot_level.unfilled_impressions)).cast("bigint").alias("total_capacity")
)

# COMMAND ----------

gam_daily_level = gam_daily_level.withColumn(
    "percentage_of_ad_breaks_with_full_slate",
        round(
            100.0 * when(
                col("total_breaks") > 0,
                col("total_breaks_complete_unfilled").cast("decimal(31,14)") / col("total_breaks").cast("double")
            ).otherwise(0.0),
            2  # Round to 2 decimal places
        )
)

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

gam_daily_level = gam_daily_level.withColumn("etl_created_at_timestamp_utc", current_timestamp()) \
                                 .withColumn("etl_updated_at_timestamp_utc", current_timestamp())


# COMMAND ----------

gam_daily_level=gam_daily_level.withColumn("time_zone",F.lit("EST"))

# COMMAND ----------

gam_daily_level.write.format("delta") \
    .mode('overwrite')\
    .option('partitionOverwriteMode', 'dynamic')\
    .saveAsTable("fox_bi_prod.silver_ads.ft_gam_ad_delivery_daily")
