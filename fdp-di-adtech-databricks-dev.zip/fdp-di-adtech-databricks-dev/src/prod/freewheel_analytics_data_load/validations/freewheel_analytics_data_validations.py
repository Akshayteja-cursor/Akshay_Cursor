# Databricks notebook source
aws_profile=dbutils.widgets.get('aws_profile')
aws_arn=dbutils.widgets.get('aws_arn')
from_email=dbutils.widgets.get('from_email')

# COMMAND ----------

# make the variable available to shell
import os
os.environ["AWS_PROFILE_VAR"] = aws_profile
os.environ["AWS_ARN"] = aws_arn

# COMMAND ----------

# MAGIC %sh
# MAGIC aws configure set region us-west-2 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set s3.signature_version s3v4 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile $AWS_PROFILE_VAR
# MAGIC aws configure set role_arn $AWS_ARN --profile $AWS_PROFILE_VAR

# COMMAND ----------

import boto3
from datetime import datetime, timedelta
from dataclasses import dataclass
from typing import List, Optional, Any, cast
from datetime import datetime, timedelta
import pandas as pd
import pyspark.sql.types as T
import pyspark.sql.functions as F
import io
from email import encoders
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
import os

# COMMAND ----------

global aws_profile, cpe_s3_bucket
aws_profile = 'databricks-cpe-prod'
cpe_s3_bucket = 'fox-fdp-bi-prod'
report_mount_path = '/mnt/fw_analytics/516429/'

# COMMAND ----------

class ReportMailInfo:
    from_email = f'{from_email}'
    reply_to_address = 'data_adtech@fox.com'
    key = ''
    info = {}
    validation_status = False
    report_mailing_lists = {
        "Freewheel Delivery Data Validation Report" : {
            "key_format_string" : "freewheel_analytics/AD Tech Freewheel Delivery Data Validation Report_%d%b%Y.csv",
            "human_readable_name" : "Prod - ad tech freewheel delivery data validation report",
            "to" : [
                "data_adtech@fox.com",
                "Pradeep.Panneerselvam@fox.com",
                "Anitha.Mohanraj@fox.com",
                "akshay.dalvi@fox.com",
                "yogesh.nageswararao@fox.com",
            ],
            "cc" : [
                "alimaafroseshahul.hameed@fox.com",
                "Ramesh.Madepalli@fox.com",
            ]
        },

        "Freewheel Capacity Data Validation Report" : {
            "key_format_string" : "freewheel_analytics/AD Tech Freewheel Capacity Data Validation Report_%d%b%Y.csv",
            "human_readable_name" : "Prod - ad tech freewheel capacity data validation report",
            "to" : [
                "data_adtech@fox.com",
                "Pradeep.Panneerselvam@fox.com",
                "Anitha.Mohanraj@fox.com",
                "akshay.dalvi@fox.com",
                "yogesh.nageswararao@fox.com",
            ],
            "cc" : [
                "alimaafroseshahul.hameed@fox.com",
                "Ramesh.Madepalli@fox.com",
            ]
        },

        "Freewheel Demo Comp Data Validation Report" : {
            "key_format_string" : "freewheel_analytics/AD Tech Freewheel Demo Comp Data Validation Report_%d%b%Y.csv",
            "human_readable_name" : "Prod - ad tech freewheel demo comp data validation report",
            "to" : [
                "data_adtech@fox.com",
                "Pradeep.Panneerselvam@fox.com",
                "Anitha.Mohanraj@fox.com",
                "akshay.dalvi@fox.com",
                "yogesh.nageswararao@fox.com",
            ],
            "cc" : [
                "alimaafroseshahul.hameed@fox.com",
                "Ramesh.Madepalli@fox.com",
            ]
        },

        "Freewheel Video Starts Data Validation Report" : {
            "key_format_string" : "freewheel_analytics/AD Tech Freewheel Video Starts Data Validation Report_%d%b%Y.csv",
            "human_readable_name" : "Prod - ad tech freewheel video starts data validation report",
            "to" : [
                "data_adtech@fox.com",
                "Pradeep.Panneerselvam@fox.com",
                "Anitha.Mohanraj@fox.com",
                "akshay.dalvi@fox.com",
                "yogesh.nageswararao@fox.com",
            ],
            "cc" : [
                "alimaafroseshahul.hameed@fox.com",
                "Ramesh.Madepalli@fox.com",
            ]
        },

        "Freewheel Matched Audience Data Validation Report" : {
            "key_format_string" : "freewheel_analytics/AD Tech Freewheel Matched Audience Data Validation Report_%d%b%Y.csv",
            "human_readable_name" : "Prod - ad tech freewheel matched audience data validation report",
            "to" : [
                "data_adtech@fox.com",
                "Pradeep.Panneerselvam@fox.com",
                "Anitha.Mohanraj@fox.com",
                "akshay.dalvi@fox.com",
                "yogesh.nageswararao@fox.com",
            ],
            "cc" : [
                "alimaafroseshahul.hameed@fox.com",
                "Ramesh.Madepalli@fox.com",
            ]
        },

        "Freewheel Fox Weather Capacity Data Validation Report" : {
            "key_format_string" : "freewheel_analytics/AD Tech Freewheel Fox Weather Capacity Validation Report_%d%b%Y.csv",
            "human_readable_name" : "Prod - ad tech freewheel fox weather capacity data validation report",
            "to" : [
                "data_adtech@fox.com",
                "Pradeep.Panneerselvam@fox.com",
                "Anitha.Mohanraj@fox.com",
                "akshay.dalvi@fox.com",
                "yogesh.nageswararao@fox.com",
            ],
            "cc" : [
                "alimaafroseshahul.hameed@fox.com",
                "Ramesh.Madepalli@fox.com",
            ]
        },
    }

    def __init__(self, report, validation_status, report_date):
        self.info = self.report_mailing_lists[report]
        self.key = get_latest_report(report_date, self.info['key_format_string'])
        self.validation_status = validation_status

    def get_file_name(self):
        return os.path.basename(self.key)
    
    def get_report_body(self, report_date):
        footer = f'<p>This is an automated email. Please direct any questions or concerns to <a href="mailto: {self.reply_to_address}">{self.reply_to_address}</a>.</p>'
        if self.validation_status:
            body_text = f"""<p>Hello,</p>

<p>The validation status: PASS</p>

<p>Please find attached the {self.info['human_readable_name']}.</p>

{footer}
"""
        else:
            body_text = f"""<p>Hello,</p>

<p>The validation status: FAILED</p>

<p>Please find attached the {self.info['human_readable_name']}.</p>

{footer}
"""
        return MIMEText(body_text, 'html')

    def get_report_attachment(self):
        session = boto3.Session(profile_name=aws_profile)
        s3 = session.client('s3')
        resp = s3.get_object(Bucket=cpe_s3_bucket, Key=self.key)
        return resp['Body'].read()

# COMMAND ----------

def get_latest_report(report_date: datetime, key_format_string: str):
    session = boto3.Session(profile_name=aws_profile)
    s3 = session.client('s3')
    for delta in range(0, -7, -1):
        date = report_date + timedelta(days=delta)
        key = date.strftime(key_format_string)
        try:
            print(f'Trying object s3://{cpe_s3_bucket}/{key}')
            s3.head_object(Bucket=cpe_s3_bucket, Key=key)
            return key
        except s3.exceptions.ClientError as exc:
            if exc.response['Error']['Code'] == '404':
                continue
            raise
    raise RuntimeError('Could not find report')

# COMMAND ----------

def get_latest_report(report_date: datetime, key_format_string: str):
    session = boto3.Session(profile_name=aws_profile)
    s3 = session.client('s3')
    for delta in range(0, -7, -1):
        date = report_date + timedelta(days=delta)
        key = date.strftime(key_format_string)
        try:
            print(f'Trying object s3://{cpe_s3_bucket}/{key}')
            s3.head_object(Bucket=cpe_s3_bucket, Key=key)
            return key
        except s3.exceptions.ClientError as exc:
            if exc.response['Error']['Code'] == '404':
                continue
            raise
    raise RuntimeError('Could not find report')

# COMMAND ----------

def send_mail(report_name, validation_status, report_date):
    
    report = ReportMailInfo(report_name, validation_status, report_date)

    attachment_ready_html = []
    img_id = 0
    mime_images = []

    msg = MIMEMultipart()
    msg['Subject'] = report.info['human_readable_name'].title()
    msg['From'] = report.from_email
    msg['To'] = ", ".join(report.info['to'])
    msg['Cc'] = ", ".join(report.info['cc'])
    msg.attach(report.get_report_body(report_date))

    part = MIMEApplication(
        report.get_report_attachment(),
        Name=report.get_file_name(),
    )
    part['Content-Disposition'] = f'attachment; filename="{report.get_file_name()}"'
    msg.attach(part)

    session = boto3.Session(profile_name = aws_profile)
    ses = session.client('ses', region_name='us-west-2')
    ses.send_raw_email(
        Source=msg['From'],
        Destinations=list(set(report.info['to']).union(set(report.info['cc']))),
        RawMessage={'Data': msg.as_string()}
    )

    print('Email sent')

# COMMAND ----------

def get_validation_status(validation_df):
    variance_column_list = [
        'Net Counted Ads Variance %',
        'Total Historical Unconstrained Ad Avails Variance %',
        'Total Historical Constrained Ad Avails Variance %',
        'Historical Unfilled Ad Opportunities Variance %',
        'On-Target Net Delivered Impressions Variance %',
        'Gross Counted Ads Variance %',
        'Video Starts Variance %',
        'Net Ad Requests Variance %',
    ]
    for col in variance_column_list:
        if col in validation_df.columns:
            variance_values = validation_df.select(col).distinct().rdd.flatMap(lambda x: x).collect()
            if len(variance_values) == 1 and variance_values[0] == 0:
                pass
            else:
                print(f'Variance found in column {col}')
                return False
    return True

if __name__ == '__main__':
    event_start_date = datetime.strptime(dbutils.widgets.get('event_start_date'), '%Y-%m-%d')
    event_end_date = datetime.strptime(dbutils.widgets.get('event_end_date'), '%Y-%m-%d')

    # Freewheel Delivery Data Validation Report
    print('Freewheel Delivery Data Validation Report')
    delivery_dfs = {
        'direct_sold': 'ft_fw_Direct_Sold_Delivery_',
        'reseller_sold': 'ft_fw_Reseller_Delivery_',
        'markets_delivery': 'ft_fw_markets_delivery_',
        'mpp': 'ft_fw_marketplace_platform_private_',
        'mpe': 'ft_fw_marketplace_platform_exchange_',
    }

    for df_name, file_pattern in delivery_dfs.items():
        vars()[f'{df_name}'] = spark.read.format('csv')\
            .option('header','true')\
            .option('inferSchema','false')\
            .load(f'{report_mount_path}validations_adtech_{file_pattern}{event_start_date.strftime("%Y-%m-%d")}*-{event_end_date.strftime("%Y-%m-%d")}*.csv', quote='"', escape='"')
        
        vars()[f'{df_name}'] = vars()[f'{df_name}'].withColumn('Net Counted Ads', F.to_number(F.col('Net Counted Ads'), F.lit('999,999,999,999,999')))
        vars()[f'{df_name}'] = vars()[f'{df_name}'].select(['Event Date', 'Net Counted Ads'])

    for i, df_name in enumerate(delivery_dfs):
        if i==0:
            combined_df = vars()[f'{df_name}']
        else:
            combined_df = combined_df.union(vars()[f'{df_name}'])

    combined_df = combined_df.groupBy('Event Date').agg(F.sum('Net Counted Ads').alias('Net Counted Ads'))
    combined_df = combined_df.select(['Event Date', 'Net Counted Ads'])
    combined_df = combined_df.withColumnRenamed('Event Date', 'event_date')
    combined_df = combined_df.withColumnRenamed('Net Counted Ads', 'net_counted_ads_source')
    combined_df = combined_df.withColumn('event_date', F.to_date(F.col('event_date'), 'MM/dd/yyyy'))
    combined_df = combined_df.withColumn('net_counted_ads_source', F.col('net_counted_ads_source').cast(T.LongType()))

    table_query = f"""
        SELECT
            event_date
            , SUM(net_counted_ads) AS net_counted_ads_table
        FROM fox_bi_prod.silver_ads.ft_freewheel_delivery_daily_data
        WHERE event_date BETWEEN '{event_start_date.strftime('%Y-%m-%d')}' AND '{event_end_date.strftime('%Y-%m-%d')}'
        GROUP BY event_date
    """

    table_df = spark.sql(table_query)
    
    validation_df = combined_df.join(table_df, on='event_date', how='left')
    validation_df = validation_df.withColumn('Net Counted Ads Variance', F.col('net_counted_ads_source') - F.col('net_counted_ads_table'))
    validation_df = validation_df.withColumn('Net Counted Ads Variance %', F.round(F.col('Net Counted Ads Variance')/F.col('net_counted_ads_source')*100, 4))
    validation_df = validation_df.sort('event_date')

    validation_status = get_validation_status(validation_df)

    with io.StringIO() as output:
        validation_df.toPandas().to_csv(output, index=False)
        validation_data = output.getvalue()

    report_name = 'AD Tech Freewheel Delivery Data Validation Report_' + datetime.today().strftime('%d%b%Y') + '.csv'
    session = boto3.Session(profile_name=aws_profile)
    s3_client = session.client('s3')
    s3_bucket = cpe_s3_bucket
    s3_key = 'freewheel_analytics/' + report_name
    s3_client.put_object(
        Bucket=s3_bucket,
        Body=validation_data.encode('utf-8'),
        Key=s3_key,
    )

    send_mail('Freewheel Delivery Data Validation Report', validation_status, datetime.today())

    # Freewheel Capacity Data Validation Report
    print('Freewheel Capacity Data Validation Report')
    capacity_df = spark.read.format('csv')\
        .option('header','true')\
        .option('inferSchema','false')\
        .load(f'{report_mount_path}validations_adtech_ft_capacity_{event_start_date.strftime("%Y-%m-%d")}*-{event_end_date.strftime("%Y-%m-%d")}*.csv')

    capacity_df = capacity_df.withColumn('Total Historical Unconstrained Ad Avails',\
        F.to_number(F.col('Total Historical Unconstrained Ad Avails'), F.lit('999,999,999,999,999'))
    )
    capacity_df = capacity_df.withColumn('Total Historical Constrained Ad Avails',\
        F.to_number(F.col('Total Historical Constrained Ad Avails'), F.lit('999,999,999,999,999'))
    )
    capacity_df = capacity_df.withColumn('Historical Unfilled Available',\
        F.to_number(F.col('Historical Unfilled Available'), F.lit('999,999,999,999,999'))
    )
    capacity_df = capacity_df.withColumnRenamed('Event Date', 'event_date')
    capacity_df = capacity_df.withColumnRenamed('Total Historical Unconstrained Ad Avails', 'total_historical_unconstrained_ad_avails_source')
    capacity_df = capacity_df.withColumnRenamed('Total Historical Constrained Ad Avails', 'total_historical_constrained_ad_avails_source')
    capacity_df = capacity_df.withColumnRenamed('Historical Unfilled Available', 'historical_unfilled_ad_opportunities_source')
    capacity_df = capacity_df.withColumn('event_date', F.to_date(F.col('event_date'), 'MM/dd/yyyy'))
    capacity_df = capacity_df.withColumn('total_historical_unconstrained_ad_avails_source',\
        F.col('total_historical_unconstrained_ad_avails_source').cast(T.LongType())
    )
    capacity_df = capacity_df.withColumn('total_historical_constrained_ad_avails_source', F.col('total_historical_constrained_ad_avails_source').cast(T.LongType()))
    capacity_df = capacity_df.withColumn('historical_unfilled_ad_opportunities_source', F.col('historical_unfilled_ad_opportunities_source').cast(T.LongType()))

    table_query = f"""
        SELECT
            event_date
            , SUM(total_historical_unconstrained_ad_avails) AS total_historical_unconstrained_ad_avails_table
            , SUM(total_historical_constrained_ad_avails) AS total_historical_constrained_ad_avails_table
            , SUM(historical_unfilled_ad_opportunities) AS historical_unfilled_ad_opportunities_table
        FROM fox_bi_prod.silver_ads.ft_freewheel_capacity_summary_daily_data
        WHERE event_date BETWEEN '{event_start_date.strftime('%Y-%m-%d')}' AND '{event_end_date.strftime('%Y-%m-%d')}'
        GROUP BY event_date
    """

    table_df = spark.sql(table_query)

    validation_df = capacity_df.join(table_df, on='event_date', how='left')
    validation_df = validation_df.withColumn('Total Historical Unconstrained Ad Avails Variance',\
        F.col('total_historical_unconstrained_ad_avails_source') - F.col('total_historical_unconstrained_ad_avails_table')
    )
    validation_df = validation_df.withColumn('Total Historical Constrained Ad Avails Variance',\
        F.col('total_historical_constrained_ad_avails_source') - F.col('total_historical_constrained_ad_avails_table')
    )
    validation_df = validation_df.withColumn('Historical Unfilled Ad Opportunities Variance',\
        F.col('historical_unfilled_ad_opportunities_source') - F.col('historical_unfilled_ad_opportunities_table')
    )
    validation_df = validation_df.withColumn('Total Historical Unconstrained Ad Avails Variance %',\
        F.round(F.col('Total Historical Unconstrained Ad Avails Variance')/F.col('total_historical_unconstrained_ad_avails_source')*100, 4)
    )
    validation_df = validation_df.withColumn('Total Historical Constrained Ad Avails Variance %',\
        F.round(F.col('Total Historical Constrained Ad Avails Variance')/F.col('total_historical_constrained_ad_avails_source')*100, 4)
    )
    validation_df = validation_df.withColumn('Historical Unfilled Ad Opportunities Variance %',\
        F.round(F.col('Historical Unfilled Ad Opportunities Variance')/F.col('historical_unfilled_ad_opportunities_source')*100, 4)
    )
    validation_df = validation_df.sort('event_date')

    validation_status = get_validation_status(validation_df)

    with io.StringIO() as output:
        validation_df.toPandas().to_csv(output, index=False)
        validation_data = output.getvalue()

    report_name = 'AD Tech Freewheel Capacity Data Validation Report_' + datetime.today().strftime('%d%b%Y') + '.csv'
    session = boto3.Session(profile_name=aws_profile)
    s3_client = session.client('s3')
    s3_bucket = cpe_s3_bucket
    s3_key = 'freewheel_analytics/' + report_name
    s3_client.put_object(
        Bucket=s3_bucket,
        Body=validation_data.encode('utf-8'),
        Key=s3_key,
    )

    send_mail('Freewheel Capacity Data Validation Report', validation_status, datetime.today())

    # Freewheel Demo Comps Data Validation Report
    print('Freewheel Demo Comps Data Validation Report')
    demo_comps_df = spark.read.format('csv')\
        .option('header','true')\
        .option('inferSchema','false')\
        .load(f'{report_mount_path}validations_adtech_ft_fw_demo_comps_{event_start_date.strftime("%Y-%m-%d")}*-{event_end_date.strftime("%Y-%m-%d")}*.csv')

    demo_comps_df = demo_comps_df.withColumn('On-Target Net Delivered Impressions', F.to_number(F.col('On-Target Net Delivered Impressions'), F.lit('999,999,999,999,999')))
    demo_comps_df = demo_comps_df.withColumn('Gross Counted Ads', F.to_number(F.col('Gross Counted Ads'), F.lit('999,999,999,999,999')))
    demo_comps_df = demo_comps_df.withColumnRenamed('Event Date', 'event_date')
    demo_comps_df = demo_comps_df.withColumnRenamed('On-Target Net Delivered Impressions', 'on_target_net_delivered_impressions_source')
    demo_comps_df = demo_comps_df.withColumnRenamed('Gross Counted Ads', 'gross_counted_ads_source')
    demo_comps_df = demo_comps_df.withColumn('event_date', F.to_date(F.col('event_date'), 'MM/dd/yyyy'))
    demo_comps_df = demo_comps_df.withColumn('on_target_net_delivered_impressions_source', F.col('on_target_net_delivered_impressions_source').cast(T.LongType()))
    demo_comps_df = demo_comps_df.withColumn('gross_counted_ads_source', F.col('gross_counted_ads_source').cast(T.LongType()))

    table_query = f"""
        SELECT
            event_date
            , SUM(on_target_net_delivered_impressions) AS on_target_net_delivered_impressions_table
            , SUM(gross_counted_ads) AS gross_counted_ads_table
        FROM fox_bi_prod.silver_ads.ft_freewheel_demo_comp_daily_data
        WHERE event_date BETWEEN '{event_start_date.strftime('%Y-%m-%d')}' AND '{event_end_date.strftime('%Y-%m-%d')}'
        GROUP BY event_date
    """

    table_df = spark.sql(table_query)

    validation_df = demo_comps_df.join(table_df, on='event_date', how='left')
    validation_df = validation_df.withColumn('On-Target Net Delivered Impressions Variance',\
        F.col('on_target_net_delivered_impressions_source') - F.col('on_target_net_delivered_impressions_table')
    )
    validation_df = validation_df.withColumn('Gross Counted Ads Variance', F.col('gross_counted_ads_source') - F.col('gross_counted_ads_table'))
    validation_df = validation_df.withColumn('On-Target Net Delivered Impressions Variance %',\
        F.when((F.col('On-Target Net Delivered Impressions Variance') == 0) & (F.col('on_target_net_delivered_impressions_source') == 0), 0)\
        .otherwise(F.round(F.col('On-Target Net Delivered Impressions Variance')/F.col('on_target_net_delivered_impressions_source')*100, 4))
    )
    validation_df = validation_df.withColumn('Gross Counted Ads Variance %', F.round(F.col('Gross Counted Ads Variance')/F.col('gross_counted_ads_source')*100, 4))
    validation_df = validation_df.sort('event_date')

    validation_status = get_validation_status(validation_df)

    with io.StringIO() as output:
        validation_df.toPandas().to_csv(output, index=False)
        validation_data = output.getvalue()

    report_name = 'AD Tech Freewheel Demo Comp Data Validation Report_' + datetime.today().strftime('%d%b%Y') + '.csv'
    session = boto3.Session(profile_name=aws_profile)
    s3_client = session.client('s3')
    s3_bucket = cpe_s3_bucket
    s3_key = 'freewheel_analytics/' + report_name
    s3_client.put_object(
        Bucket=s3_bucket,
        Body=validation_data.encode('utf-8'),
        Key=s3_key,
    )

    send_mail('Freewheel Demo Comp Data Validation Report', validation_status, datetime.today())

    # Freewheel Video Starts Data Validation Report
    print('Freewheel Video Starts Data Validation Report')
    video_starts_df = spark.read.format('csv')\
        .option('header','true')\
        .option('inferSchema','false')\
        .load(f'{report_mount_path}validations_adtech_ft_fw_video_starts_{event_start_date.strftime("%Y-%m-%d")}*-{event_end_date.strftime("%Y-%m-%d")}*.csv')

    video_starts_df = video_starts_df.withColumn('Video Starts', F.to_number(F.col('Video Starts'), F.lit('999,999,999,999,999')))
    video_starts_df = video_starts_df.withColumnRenamed('Event Date', 'event_date')
    video_starts_df = video_starts_df.withColumnRenamed('Video Starts', 'video_starts_source')
    video_starts_df = video_starts_df.withColumn('event_date', F.to_date(F.col('event_date'), 'MM/dd/yyyy'))
    video_starts_df = video_starts_df.withColumn('video_starts_source', F.col('video_starts_source').cast(T.LongType()))

    table_query = f"""
        SELECT
            event_date
            , SUM(video_starts) AS video_starts_table
        FROM fox_bi_prod.silver_ads.ft_freewheel_video_starts_daily_data
        WHERE event_date BETWEEN '{event_start_date.strftime('%Y-%m-%d')}' AND '{event_end_date.strftime('%Y-%m-%d')}'
        GROUP BY event_date
    """

    table_df = spark.sql(table_query)

    validation_df = video_starts_df.join(table_df, on='event_date', how='left')
    validation_df = validation_df.withColumn('Video Starts Variance', F.col('video_starts_source') - F.col('video_starts_table'))
    validation_df = validation_df.withColumn('Video Starts Variance %', F.round(F.col('Video Starts Variance')/F.col('video_starts_source')*100, 4))
    validation_df = validation_df.sort('event_date')

    validation_status = get_validation_status(validation_df)

    with io.StringIO() as output:
        validation_df.toPandas().to_csv(output, index=False)
        validation_data = output.getvalue()

    report_name = 'AD Tech Freewheel Video Starts Data Validation Report_' + datetime.today().strftime('%d%b%Y') + '.csv'
    session = boto3.Session(profile_name=aws_profile)
    s3_client = session.client('s3')
    s3_bucket = cpe_s3_bucket
    s3_key = 'freewheel_analytics/' + report_name
    s3_client.put_object(
        Bucket=s3_bucket,
        Body=validation_data.encode('utf-8'),
        Key=s3_key,
    )

    send_mail('Freewheel Video Starts Data Validation Report', validation_status, datetime.today())

    # Freewheel Matched Audience Data Validation Report
    print('Freewheel Matched Audience Data Validation Report')
    matched_audience_dfs = {
            'matched_audience_direct_sold': 'ft_fw_matched_audience_direct_sold_delivery_video_ads_',
            'matched_audience_markets_delivery': 'ft_fw_Matched_Audience_Markets_Delivery_',
        }

    for df_name, file_pattern in matched_audience_dfs.items():
        vars()[f'{df_name}'] = spark.read.format('csv')\
            .option('header','true')\
            .option('inferSchema','false')\
            .load(f'{report_mount_path}validations_adtech_{file_pattern}{event_start_date.strftime("%Y-%m-%d")}*-{event_end_date.strftime("%Y-%m-%d")}*.csv')

        vars()[f'{df_name}'] = vars()[f'{df_name}'].withColumn('Net Counted Ads', F.to_number(F.col('Net Counted Ads'), F.lit('999,999,999,999,999')))

    for i, df_name in enumerate(matched_audience_dfs):
            if i==0:
                combined_df = vars()[f'{df_name}']
            else:
                combined_df = combined_df.union(vars()[f'{df_name}'])

    combined_df = combined_df.groupBy('Event Date').agg(F.sum('Net Counted Ads').alias('Net Counted Ads'))
    combined_df = combined_df.select(['Event Date', 'Net Counted Ads'])
    combined_df = combined_df.withColumnRenamed('Event Date', 'event_date')
    combined_df = combined_df.withColumnRenamed('Net Counted Ads', 'net_counted_ads_source')
    combined_df = combined_df.withColumn('event_date', F.to_date(F.col('event_date'), 'MM/dd/yyyy'))
    combined_df = combined_df.withColumn('net_counted_ads_source', F.col('net_counted_ads_source').cast(T.LongType()))

    table_query = f"""
        SELECT
            event_date
            , SUM(net_counted_ads) AS net_counted_ads_table
        FROM fox_bi_prod.silver_ads.ft_freewheel_matched_audience_delivery_daily_data
        WHERE event_date BETWEEN '{event_start_date.strftime('%Y-%m-%d')}' AND '{event_end_date.strftime('%Y-%m-%d')}'
        GROUP BY event_date
    """

    table_df = spark.sql(table_query)

    validation_df = combined_df.join(table_df, on='event_date', how='left')
    validation_df = validation_df.withColumn('Net Counted Ads Variance', F.col('net_counted_ads_source') - F.col('net_counted_ads_table'))
    validation_df = validation_df.withColumn('Net Counted Ads Variance %', F.round(F.col('Net Counted Ads Variance')/F.col('net_counted_ads_source')*100, 4))
    validation_df = validation_df.sort('event_date')

    validation_status = get_validation_status(validation_df)

    with io.StringIO() as output:
        validation_df.toPandas().to_csv(output, index=False)
        validation_data = output.getvalue()

    report_name = 'AD Tech Freewheel Matched Audience Data Validation Report_' + datetime.today().strftime('%d%b%Y') + '.csv'
    session = boto3.Session(profile_name=aws_profile)
    s3_client = session.client('s3')
    s3_bucket = cpe_s3_bucket
    s3_key = 'freewheel_analytics/' + report_name
    s3_client.put_object(
        Bucket=s3_bucket,
        Body=validation_data.encode('utf-8'),
        Key=s3_key,
    )

    send_mail('Freewheel Matched Audience Data Validation Report', validation_status, datetime.today())

    # Freewheel Fox Weather Capacity Data Validation Report
    print('Freewheel Fox Weather Capacity Data Validation Report')
    fxw_capacity_df = spark.read.format('csv')\
        .option('header','true')\
        .option('inferSchema','false')\
        .load(f'{report_mount_path}validations_adtech_ft_fxw_capacity_{event_start_date.strftime("%Y-%m-%d")}*-{event_end_date.strftime("%Y-%m-%d")}*.csv', quote='"', escape='"')

    fxw_capacity_df = fxw_capacity_df.withColumn('Net Ad Requests', F.to_number(F.col('Net Ad Requests'), F.lit('999,999,999,999,999')))
    fxw_capacity_df = fxw_capacity_df.withColumnRenamed('Event Date', 'event_date')
    fxw_capacity_df = fxw_capacity_df.withColumnRenamed('Net Ad Requests', 'net_ad_requests_source')
    fxw_capacity_df = fxw_capacity_df.withColumn('event_date', F.to_date(F.col('event_date'), 'MM/dd/yyyy'))
    fxw_capacity_df = fxw_capacity_df.withColumn('net_ad_requests_source', F.col('net_ad_requests_source').cast(T.LongType()))

    table_query = f"""
        SELECT
            event_date
            , SUM(net_ad_requests) AS net_ad_requests_table
        FROM fox_bi_prod.silver_ads.ft_freewheel_fxw_capacity_daily_data
        WHERE event_date BETWEEN '{event_start_date.strftime('%Y-%m-%d')}' AND '{event_end_date.strftime('%Y-%m-%d')}'
        GROUP BY event_date
    """

    table_df = spark.sql(table_query)

    validation_df = fxw_capacity_df.join(table_df, on='event_date', how='left')
    validation_df = validation_df.withColumn('Net Ad Requests Variance', F.col('net_ad_requests_source') - F.col('net_ad_requests_table'))
    validation_df = validation_df.withColumn('Net Ad Requests Variance %', F.round(F.col('Net Ad Requests Variance')/F.col('net_ad_requests_source')*100, 4))
    validation_df = validation_df.sort('event_date')

    validation_status = get_validation_status(validation_df)

    with io.StringIO() as output:
        validation_df.toPandas().to_csv(output, index=False)
        validation_data = output.getvalue()

    report_name = 'AD Tech Freewheel Fox Weather Capacity Validation Report_' + datetime.today().strftime('%d%b%Y') + '.csv'
    session = boto3.Session(profile_name=aws_profile)
    s3_client = session.client('s3')
    s3_bucket = cpe_s3_bucket
    s3_key = 'freewheel_analytics/' + report_name
    s3_client.put_object(
        Bucket=s3_bucket,
        Body=validation_data.encode('utf-8'),
        Key=s3_key,
    )

    send_mail('Freewheel Fox Weather Capacity Data Validation Report', validation_status, datetime.today())