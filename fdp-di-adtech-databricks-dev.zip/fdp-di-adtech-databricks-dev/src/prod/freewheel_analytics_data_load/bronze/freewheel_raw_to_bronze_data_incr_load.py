# Databricks notebook source
from pyspark.sql import functions as F
from pyspark.sql import types as T
from datetime import datetime, timedelta

# COMMAND ----------

def load_format_fw_table(table_name):
    """
    Loads 'raw fw tables' and formats the columns names and types.
    """

    fw_table = spark.read.table(f'fox_bi_prod.raw_ads.{table_name}')
    
    column_format_info = {
        'Event Date': ['event_date', T.DateType()],
        'Distributor Name': ['distributor_name', T.StringType()],
        'Distributor ID': ['distributor_id', T.LongType()],
        'Site Section ID': ['site_section_id', T.LongType()],
        'Video ID': ['video_id', T.LongType()],
        'Series ID': ['series_id', T.LongType()],
        'Ad Unit Type Name': ['ad_unit_type_name', T.StringType()],
        'Ad Unit Position': ['ad_unit_position', T.StringType()],
        'Ad Unit Class': ['ad_unit_class', T.StringType()],
        'Total Historical Unconstrained Ad Avails': ['total_historical_unconstrained_ad_avails', T.LongType()],
        'Total Historical Constrained Ad Avails': ['total_historical_constrained_ad_avails', T.LongType()],
        'Historical Unfilled Available': ['historical_unfilled_ad_opportunities', T.LongType()],
        'Net Ad Requests': ['net_ad_requests', T.LongType()],
        'Advertiser ID': ['advertiser_id', T.LongType()],
        'Advertiser Name': ['advertiser_name', T.StringType()],
        'Agency ID': ['agency_id', T.LongType()],
        'Agency Name': ['agency_name', T.StringType()],
        'Campaign ID': ['campaign_id', T.LongType()],
        'Insertion Order ID': ['insertion_order_id', T.LongType()],
        'Placement ID': ['placement_id', T.LongType()],
        'On-Target Net Delivered Impressions': ['on_target_net_delivered_impressions', T.LongType()],
        'Gross Counted Ads': ['gross_counted_ads', T.LongType()],
        'Creative ID': ['creative_id', T.LongType()],
        'Ad Unit ID': ['ad_unit_id', T.LongType()],
        'Ad Unit Type ID': ['ad_unit_type_id', T.LongType()],
        'Net Counted Ads': ['net_counted_ads', T.LongType()],
        'Run Revenue': ['run_revenue', T.DoubleType()],
        'eCPM': ['ecpm', T.DoubleType()],
        'Delivered Clicks': ['delivered_clicks', T.LongType()],
        'Measurable Video Ads Quartile Impressions': ['measurable_video_ads_quartile_impressions', T.LongType()],
        'Sales Channel Type': ['sales_channel_type', T.StringType()],
        'Exchange Listing ID': ['exchange_listing_id', T.LongType()],
        'Exchange Listing Name': ['exchange_listing_name', T.StringType()],
        'Exchange Listing Transaction Type': ['exchange_listing_transaction_type', T.StringType()],
        'Global Advertiser Name': ['global_advertiser_name', T.StringType()],
        'Exchange Listing Priority': ['exchange_listing_priority', T.StringType()],
        'Sold Order ID': ['sold_order_id', T.LongType()],
        'Private Listing Transaction Type': ['private_listing_transaction_type', T.StringType()],
        'DSP ID': ['dsp_id', T.LongType()],
        'DSP Name': ['dsp_name', T.StringType()],
        'Trading Desk Name': ['trading_desk_name', T.StringType()],
        'Invite Buyer Name': ['invite_buyer_name', T.StringType()],
        'Invite Buyer Priority': ['invite_buyer_priority', T.StringType()],
        'Deal ID': ['deal_id', T.LongType()],
        'Programmatic Ad ID': ['programmatic_ad_id', T.LongType()],
        'Global Advertiser ID': ['global_advertiser_id', T.LongType()],
        'Matched Audience Item Name': ['matched_audience_item_name', T.StringType()],
        'Reseller Name': ['reseller_name', T.StringType()],
        'Reseller ID': ['reseller_id', T.LongType()],
        'MRM Rule ID': ['mrm_rule_id', T.LongType()],
        'Video Starts': ['video_starts', T.LongType()],
        'Delivered Device': ['delivered_device', T.StringType()],
        'Delivered Country Name': ['delivered_country_name', T.StringType()],
        'Delivered State/Province Name': ['delivered_state_province_name', T.StringType()],
        'Delivered DMA Name': ['delivered_dma_name', T.StringType()],
        'Delivered City Name': ['delivered_city_name', T.StringType()],
        'Delivered ZIP/Postal Code': ['delivered_zip_postal_code', T.StringType()],
        'Video Ads 25% Complete': ['video_ads_25_complete', T.LongType()],
        'Video Ads 50% Complete': ['video_ads_50_complete', T.LongType()],
        'Video Ads 75% Complete': ['video_ads_75_complete', T.LongType()],
        'Video Ads 100% Complete': ['video_ads_100_complete', T.LongType()]
    }

    cols_to_be_formated_to_int = [
        'Total Historical Unconstrained Ad Avails',
        'Total Historical Constrained Ad Avails',
        'Historical Unfilled Available',
        'Net Ad Requests',
        'On-Target Net Delivered Impressions',
        'Gross Counted Ads',
        'Net Counted Ads',
        'Delivered Clicks',
        'Measurable Video Ads Quartile Impressions',
        'Video Starts',
        'Video Ads 25% Complete',
        'Video Ads 50% Complete',
        'Video Ads 75% Complete',
        'Video Ads 100% Complete'
    ]

    cols_to_be_formated_to_float = [
        'Run Revenue',
        'eCPM'
    ]

    select_cols = []
    for col in fw_table.columns:
        if col != 'created_at' and col != 'updated_at':
            select_cols.append(column_format_info[col][0])
            if col in cols_to_be_formated_to_int:
                fw_table = fw_table.withColumn(col, F.to_number(F.col(col), F.lit('999,999,999,999,999')))
            if col in cols_to_be_formated_to_float:
                fw_table = fw_table.withColumn(col, F.to_number(F.col(col), F.lit('999,999,999,999,999.99999')))
            fw_table = fw_table.withColumnRenamed(col, column_format_info[col][0])
            if 'date' in column_format_info[col][0]:
                fw_table = fw_table.withColumn(column_format_info[col][0], F.to_date(F.col(column_format_info[col][0]), 'MM/dd/yyyy'))
            else:
                fw_table = fw_table.withColumn(column_format_info[col][0], F.col(column_format_info[col][0]).cast(column_format_info[col][1]))

    return fw_table.select(select_cols)


# COMMAND ----------

if __name__ == '__main__':
    tables = [
        'stg_freewheel_analytics_capacity',
        'stg_freewheel_analytics_demo_comps',
        'stg_freewheel_analytics_direct_sold_delivery',
        'stg_freewheel_analytics_marketplace_platform_exchange',
        'stg_freewheel_analytics_marketplace_platform_private',
        'stg_freewheel_analytics_markets_delivery',
        'stg_freewheel_analytics_matched_audience_direct_sold_delivery_video_ads',
        'stg_freewheel_analytics_matched_audience_markets_delivery',
        'stg_freewheel_analytics_reseller_delivery',
        'stg_freewheel_analytics_video_starts',
        'stg_freewheel_analytics_fxw_capacity',
        'stg_freewheel_analytics_demo_comps_correction',
        'stg_freewheel_analytics_geo_data'
    ]

    for table_name in tables:
        fw = load_format_fw_table(table_name)

        # fw.write.format('delta')\
        #     .mode('overwrite')\
        #     .partitionBy('event_date')\
        #     .option('mergeSchema', 'true')\
        #     .option('overwriteDynamicPartitions', 'true')\
        #     .option('delta.enableDeletionVectors', 'false')\
        #     .option('delta.enableIcebergCompatV2', 'true')\
        #     .option('delta.universalFormat.enabledFormats', 'iceberg')\
        #     .option('delta.columnMapping.mode', 'name')\
        #     .saveAsTable(f"fox_bi_prod.bronze_ads.{table_name.replace('stg_', '')}")

        fw.write.format('delta')\
            .mode('overwrite')\
            .option('partitionOverwriteMode', 'dynamic')\
            .saveAsTable(f"fox_bi_prod.bronze_ads.{table_name.replace('stg_', '')}")