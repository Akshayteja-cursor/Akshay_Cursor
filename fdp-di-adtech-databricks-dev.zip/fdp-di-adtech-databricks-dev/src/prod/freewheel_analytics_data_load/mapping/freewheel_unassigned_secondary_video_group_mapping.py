# Databricks notebook source
aws_profile=dbutils.widgets.get('aws_profile')
aws_arn=dbutils.widgets.get('aws_arn')
from_email=dbutils.widgets.get('from_email')

# COMMAND ----------

# make the variable available to shell
import os
os.environ["AWS_PROFILE_VAR"] = aws_profile
os.environ["AWS_ARN"] = aws_arn

# COMMAND ----------

# MAGIC %sh
# MAGIC aws configure set region us-west-2 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set s3.signature_version s3v4 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile $AWS_PROFILE_VAR
# MAGIC aws configure set role_arn $AWS_ARN --profile $AWS_PROFILE_VAR

# COMMAND ----------

import json
import tempfile
import os
import boto3
import pandas as pd
from oauth2client.service_account import ServiceAccountCredentials
from googleapiclient.discovery import build
import sys
from pyspark.sql import functions as F
import pyspark.sql.types as T
from databricks.sdk import WorkspaceClient
import re
from datetime import datetime, timedelta
from dataclasses import dataclass
from typing import List, Optional, Any, cast
import io
from email import encoders
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication

# COMMAND ----------

global aws_profile, cpe_s3_bucket
aws_profile = 'databricks-cpe-prod'
cpe_s3_bucket = 'fox-fdp-bi-prod'

# COMMAND ----------

w = WorkspaceClient()

def get_secret_value(value):
    """Retrieve secret from Databricks Secrets if value follows {{secrets/scope/key}} pattern."""
    
    secret_pattern = re.compile(r'{{secrets/([^/]+)/([^}]+)}}')
    match = secret_pattern.match(value)
    
    if match:
        scope = match.group(1)
        key = match.group(2)
        
        # Retrieve secret value using Databricks secrets API
        secret = w.dbutils.secrets.get(scope, key)
        
        # Write the secret to a temporary file
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix=".json") as temp_json_file:
            temp_json_file.write(secret)  # Write secret as string to the file
            json_keyfile_path = temp_json_file.name  # Get the temp file path

        return json_keyfile_path
    else:
        raise ValueError("The provided value does not match the {{secrets/scope/key}} pattern.")

json_keyfile_path = get_secret_value("{{secrets/google_service_account/gsheet_access}}")

with open(json_keyfile_path, 'r') as f:
    secret_value = json.load(f)

# COMMAND ----------

# MAGIC %run "/Workspace/Repos/adtech/fdp-di-adtech-databricks/src/prod/freewheel_analytics_data_load/mapping/google_service"

# COMMAND ----------

# Google Sheet Information
google_worksheet_id = '1IU_DDBy37Ym2rQngtuQF3vwf4xx5EbaInvGTvNC8DB8'
google_sheet_range = 'Unassigned Secondary Video Group!A:F'
google_scope_list = ["https://spreadsheets.google.com/feeds",'https://www.googleapis.com/auth/spreadsheets',"https://www.googleapis.com/auth/drive.file","https://www.googleapis.com/auth/drive"]

# Get google service and read gsheet data
gsheet_service = get_service(secret_value, google_scope_list, 'sheets')
sheet_data = gsheet_get_data(gsheet_service, google_worksheet_id, google_sheet_range)
sheet_data_dict = list_to_dict(sheet_data)
sheet_df = spark.createDataFrame(sheet_data_dict)

for col in sheet_df.columns:
    if col == 'Assigned Secondary Video ID':
        sheet_df = sheet_df.withColumnRenamed(col, 'assigned_secondary_video_group_id')
    if col == 'Assigned Secondary Video Name':
        sheet_df = sheet_df.withColumnRenamed(col, 'assigned_secondary_video_group_name')
    else:
        sheet_df = sheet_df.withColumnRenamed(col, col.replace(' ', '_').lower())

if 'assigned_secondary_video_group_id' not in sheet_df.columns and 'assigned_secondary_video_group_name' not in sheet_df.columns:
    sheet_df = sheet_df.withColumn('assigned_secondary_video_group_id', F.lit(None).cast(T.StringType()))
    sheet_df = sheet_df.withColumn('assigned_secondary_video_group_name', F.lit(None).cast(T.StringType()))

sheet_df.createOrReplaceTempView('sheet_df')

# COMMAND ----------

query = """
    MERGE INTO fox_bi_prod.silver_ads.freewheel_gsheet_map_unassigned_secondary_video_group AS t
    USING sheet_df AS s
    ON t.series_name = s.series_name
    AND t.video_name = s.video_name
    WHEN MATCHED AND (
        COALESCE(t.assigned_secondary_video_group_id, -1) != COALESCE(s.assigned_secondary_video_group_id, -1) OR
        COALESCE(t.assigned_secondary_video_group_name, 'N/A') != COALESCE(s.assigned_secondary_video_group_name, 'N/A')
    )
    THEN UPDATE SET
        t.assigned_secondary_video_group_id = s.assigned_secondary_video_group_id,
        t.assigned_secondary_video_group_name = s.assigned_secondary_video_group_name,
        t.etl_updated_timestamp_utc = CURRENT_TIMESTAMP()
    WHEN NOT MATCHED
    THEN INSERT (
        series_name
        , video_name
        , primary_video_group_name
        , secondary_video_group_name
        , assigned_secondary_video_group_id
        , assigned_secondary_video_group_name
        , etl_created_timestamp_utc
        , etl_updated_timestamp_utc
    )
    VALUES (
        s.series_name
        , s.video_name
        , s.primary_video_group_name
        , s.secondary_video_group_name
        , s.assigned_secondary_video_group_id
        , s.assigned_secondary_video_group_name
        , CURRENT_TIMESTAMP()
        , CURRENT_TIMESTAMP()
    )
"""

result = spark.sql(query)
display(result)

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Merge data from series_unique_mapped into table
# MAGIC WITH series_unique_mapped AS (
# MAGIC     SELECT
# MAGIC         series_name
# MAGIC         , assigned_secondary_video_group_id
# MAGIC         , assigned_secondary_video_group_name
# MAGIC     FROM (
# MAGIC         SELECT
# MAGIC             series_name
# MAGIC             , assigned_secondary_video_group_id
# MAGIC             , assigned_secondary_video_group_name
# MAGIC             , COUNT(assigned_secondary_video_group_id) over (PARTITION by series_name) AS count_unique
# MAGIC         FROM (
# MAGIC             SELECT DISTINCT
# MAGIC                 series_name
# MAGIC                 , assigned_secondary_video_group_id
# MAGIC                 , assigned_secondary_video_group_name
# MAGIC             FROM fox_bi_prod.silver_ads.freewheel_gsheet_map_unassigned_secondary_video_group
# MAGIC             WHERE assigned_secondary_video_group_id IS NOT NULL
# MAGIC         )
# MAGIC     ) mapped
# MAGIC     WHERE mapped.count_unique = 1
# MAGIC )
# MAGIC
# MAGIC MERGE INTO fox_bi_prod.silver_ads.freewheel_gsheet_map_unassigned_secondary_video_group t
# MAGIC USING series_unique_mapped s
# MAGIC ON t.series_name = s.series_name
# MAGIC WHEN MATCHED AND (
# MAGIC     t.assigned_secondary_video_group_id IS NULL OR
# MAGIC     t.assigned_secondary_video_group_name IS NULL
# MAGIC )
# MAGIC THEN UPDATE SET
# MAGIC     t.assigned_secondary_video_group_id = s.assigned_secondary_video_group_id,
# MAGIC     t.assigned_secondary_video_group_name = s.assigned_secondary_video_group_name,
# MAGIC     t.etl_updated_timestamp_utc = current_timestamp()

# COMMAND ----------

write_back_query = """
    SELECT DISTINCT
        unmapped.primary_video_group_name
        , unmapped.secondary_video_group_name
        , unmapped.series_name
        , unmapped.video_name
        , NULL AS assigned_secondary_video_group_id
        , NULL AS assigned_secondary_video_group_name
    FROM (
        SELECT DISTINCT
            primary_video_group_name
            , secondary_video_group_name
            , series_name
            , video_name
        FROM fox_bi_prod.silver_ads.ft_freewheel_capacity_summary_daily_data
        WHERE primary_video_group_name = 'VG: SPORTS: Long Form'
        AND secondary_video_group_name = 'Unassigned'

        UNION

        SELECT DISTINCT
            primary_video_group_name
            , secondary_video_group_name
            , series_name
            , video_name
        FROM fox_bi_prod.silver_ads.ft_freewheel_delivery_daily_data
        WHERE primary_video_group_name = 'VG: SPORTS: Long Form'
        AND secondary_video_group_name = 'Unassigned'
    ) unmapped
    LEFT JOIN fox_bi_prod.silver_ads.freewheel_gsheet_map_unassigned_secondary_video_group usvg
    ON unmapped.series_name = usvg.series_name
    AND unmapped.video_name = usvg.video_name
    WHERE usvg.assigned_secondary_video_group_id IS NULL OR usvg.assigned_secondary_video_group_name IS NULL
"""

write_back_df = spark.sql(write_back_query)
write_back_df = write_back_df.sort('video_name')

write_back_df = write_back_df.withColumnRenamed('primary_video_group_name', 'Primary Video Group Name')\
    .withColumnRenamed('secondary_video_group_name', 'Secondary Video Group Name')\
    .withColumnRenamed('series_name', 'Series Name')\
    .withColumnRenamed('video_name', 'Video Name')\
    .withColumnRenamed('assigned_secondary_video_group_id', 'Assigned Secondary Video ID')\
    .withColumnRenamed('assigned_secondary_video_group_name', 'Assigned Secondary Video Name')

write_back_df = write_back_df.toPandas()
write_back_df = write_back_df[['Primary Video Group Name', 'Secondary Video Group Name', 'Series Name', 'Video Name', 'Assigned Secondary Video ID', 'Assigned Secondary Video Name']]
write_back_dict = write_back_df.to_dict('records')

# COMMAND ----------

# Update Google Sheet
clear_sheets(gsheet_service, google_worksheet_id, google_sheet_range)
update_sheet(gsheet_service, google_worksheet_id, google_sheet_range, write_back_dict)

# COMMAND ----------

class TargetMailInfo:
    from_email = f'{from_email}'
    reply_to_address = 'data_adtech@fox.com'
    key = ''
    info = {}
    target_mailing_lists = {
        "Freewheel Unassigned Secondary Video Group Mapping" : {
            "google_sheet_link" : "https://docs.google.com/spreadsheets/d/1IU_DDBy37Ym2rQngtuQF3vwf4xx5EbaInvGTvNC8DB8/edit?gid=0#gid=0",
            "human_readable_name" : "prod - ad tech freewheel unassigned secondary video group mapping",
            "to" : [
                "prajwal.harikishor@fox.com",
                "fox.ai@fox.com",
                "Spencer.Noonan@fox.com",
                "Denise.Franczyk@fox.com",
                "Anitha.Mohanraj@fox.com",
                "kevin.wakeman@fox.com",
                "alexa.bezzone@fox.com",
            ],
            "cc" : [
                "alimaafroseshahul.hameed@fox.com",
            ]
        }
    }

    def __init__(self, target):
        self.info = self.target_mailing_lists[target]
    
    def get_report_body(self):
        footer = f'<p>This is an automated email. Please direct any questions or concerns to <a href="mailto: {self.reply_to_address}">{self.reply_to_address}</a>.</p>'
        body_text = f"""<p>Hi,</p>

<p>New Unassigned Secondary Video Groups are aviailable in Freewheel, please proceed to map them.</p>

<p>Please find Google Sheet Link: <a href="{self.info['google_sheet_link']}">Unassigned Secondary Video Group</a>.</p>

{footer}
"""
        return MIMEText(body_text, 'html')

def send_mail(target):
    
    target = TargetMailInfo(target)

    attachment_ready_html = []
    img_id = 0
    mime_images = []

    msg = MIMEMultipart()
    msg['Subject'] = target.info['human_readable_name'].title()
    msg['From'] = target.from_email
    msg['To'] = ", ".join(target.info['to'])
    msg['Cc'] = ", ".join(target.info['cc'])
    msg.attach(target.get_report_body())

    session = boto3.Session(profile_name = aws_profile)
    ses = session.client('ses', region_name='us-west-2')
    ses.send_raw_email(
        Source=msg['From'],
        Destinations=list(set(target.info['to']).union(set(target.info['cc']))),
        RawMessage={'Data': msg.as_string()}
    )

    print('Email sent')

send_mail("Freewheel Unassigned Secondary Video Group Mapping")