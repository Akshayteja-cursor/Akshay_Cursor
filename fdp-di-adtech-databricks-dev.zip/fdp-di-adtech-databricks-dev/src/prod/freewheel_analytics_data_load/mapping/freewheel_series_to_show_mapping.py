# Databricks notebook source
aws_profile=dbutils.widgets.get('aws_profile')
aws_arn=dbutils.widgets.get('aws_arn')
from_email=dbutils.widgets.get('from_email')

# COMMAND ----------

# make the variable available to shell
import os
os.environ["AWS_PROFILE_VAR"] = aws_profile
os.environ["AWS_ARN"] = aws_arn

# COMMAND ----------

# MAGIC %sh
# MAGIC aws configure set region us-west-2 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set s3.signature_version s3v4 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile $AWS_PROFILE_VAR
# MAGIC aws configure set role_arn $AWS_ARN --profile $AWS_PROFILE_VAR

# COMMAND ----------

import json
import tempfile
import os
import boto3
import pandas as pd
from oauth2client.service_account import ServiceAccountCredentials
from googleapiclient.discovery import build
import sys
from pyspark.sql import functions as F
from databricks.sdk import WorkspaceClient
import re
from datetime import datetime, timedelta
from dataclasses import dataclass
from typing import List, Optional, Any, cast
import io
from email import encoders
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication

# COMMAND ----------

global aws_profile, cpe_s3_bucket
aws_profile = 'databricks-cpe-prod'
cpe_s3_bucket = 'fox-fdp-bi-prod'

# COMMAND ----------

w = WorkspaceClient()

def get_secret_value(value):
    """Retrieve secret from Databricks Secrets if value follows {{secrets/scope/key}} pattern."""
    
    secret_pattern = re.compile(r'{{secrets/([^/]+)/([^}]+)}}')
    match = secret_pattern.match(value)
    
    if match:
        scope = match.group(1)
        key = match.group(2)
        
        # Retrieve secret value using Databricks secrets API
        secret = w.dbutils.secrets.get(scope, key)
        
        # Write the secret to a temporary file
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix=".json") as temp_json_file:
            temp_json_file.write(secret)  # Write secret as string to the file
            json_keyfile_path = temp_json_file.name  # Get the temp file path

        return json_keyfile_path
    else:
        raise ValueError("The provided value does not match the {{secrets/scope/key}} pattern.")

json_keyfile_path = get_secret_value("{{secrets/google_service_account/gsheet_access}}")

with open(json_keyfile_path, 'r') as f:
    secret_value = json.load(f)

# COMMAND ----------

# MAGIC %run "/Workspace/Repos/adtech/fdp-di-adtech-databricks/src/prod/freewheel_analytics_data_load/mapping/google_service"

# COMMAND ----------

# Google Sheet Information
google_worksheet_id = '1blnK_gNGa5LlxcPGJRMFkmhGb_FrpDt9IjG4HaECJtI'
google_sheet_range = 'Series Show Map!A:C'
google_scope_list = ["https://spreadsheets.google.com/feeds",'https://www.googleapis.com/auth/spreadsheets',"https://www.googleapis.com/auth/drive.file","https://www.googleapis.com/auth/drive"]

# Get google service and read gsheet data
gsheet_service = get_service(secret_value, google_scope_list, 'sheets')
sheet_data = gsheet_get_data(gsheet_service, google_worksheet_id, google_sheet_range)
sheet_data_dict = list_to_dict(sheet_data)
sheet_df = spark.createDataFrame(sheet_data_dict)
sheet_df = sheet_df.withColumnRenamed('FreeWheel Series Name/TOR Series', 'series_name')\
    .withColumnRenamed('Show/Sport', 'show_name')\
    .withColumnRenamed('Is_Updated', 'is_updated_flag')
sheet_df.createOrReplaceTempView('sheet_df')

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO fox_bi_prod.silver_ads.freewheel_gsheet_map_series_to_show AS t
# MAGIC USING sheet_df AS s
# MAGIC ON t.series_name = s.series_name
# MAGIC WHEN MATCHED AND (
# MAGIC     t.show_name != s.show_name OR
# MAGIC     t.is_updated_flag != s.is_updated_flag
# MAGIC )
# MAGIC THEN UPDATE SET
# MAGIC     t.show_name = s.show_name,
# MAGIC     t.is_updated_flag = s.is_updated_flag,
# MAGIC     t.etl_updated_timestamp_utc = CURRENT_TIMESTAMP()
# MAGIC WHEN NOT MATCHED
# MAGIC THEN INSERT (
# MAGIC     series_name
# MAGIC     , show_name
# MAGIC     , is_updated_flag
# MAGIC     , etl_created_timestamp_utc
# MAGIC     , etl_updated_timestamp_utc
# MAGIC )
# MAGIC VALUES (
# MAGIC     s.series_name
# MAGIC     , s.show_name
# MAGIC     , s.is_updated_flag
# MAGIC     , CURRENT_TIMESTAMP()
# MAGIC     , CURRENT_TIMESTAMP()
# MAGIC )

# COMMAND ----------

write_back_query = """
    SELECT DISTINCT
        dd.series_name
        , NULL AS show_name
        , 'N' AS is_updated_flag
    FROM fox_bi_prod.silver_ads.ft_freewheel_delivery_daily_data dd
    LEFT JOIN fox_bi_prod.silver_ads.freewheel_gsheet_map_series_to_show ss
    ON LOWER(dd.series_name) = LOWER(ss.series_name)
    WHERE primary_video_group_name IN (
        'VG: SPORTS: Long Form'
        , 'VG: SPORTS: Short Form'
        , 'VG: ENT: Short Form'
        , 'VG: VOD: FOX','VG: SPORTS: Deportes'
    ) 
    AND (dd.show_name = 'N/A' OR ss.show_name IS NULL)
    AND dd.series_name IS NOT NULL

    UNION

    SELECT DISTINCT
        cd.series_name
        , NULL
        , 'N'
    FROM fox_bi_prod.silver_ads.ft_freewheel_capacity_summary_daily_data cd
    LEFT JOIN fox_bi_prod.silver_ads.freewheel_gsheet_map_series_to_show ss
    ON LOWER(cd.series_name) = LOWER(ss.series_name)
    WHERE primary_video_group_name IN (
        'VG: SPORTS: Long Form'
        , 'VG: SPORTS: Short Form'
        , 'VG: ENT: Short Form'
        , 'VG: VOD: FOX','VG: SPORTS: Deportes'
    ) 
    AND (cd.show_name = 'N/A' OR ss.show_name IS NULL)
    AND cd.series_name IS NOT NULL

    UNION

    SELECT DISTINCT
        hulu_tor.series
        , NULL
        , 'N'
    FROM fox_bi_prod.static_ad_sales.ft_hulu_tor_details hulu_tor
    LEFT JOIN fox_bi_prod.silver_ads.freewheel_gsheet_map_series_to_show ss
    ON hulu_tor.series = ss.series_name
    WHERE hulu_tor.cp in ('FBC', 'Fox_prior', 'Fox MPVOD')
    AND ss.show_name IS NULL
"""

write_back_df = spark.sql(write_back_query)
write_back_df = write_back_df.union(sheet_df.select('series_name', 'show_name', 'is_updated_flag')).dropDuplicates()
write_back_df = write_back_df.sort('series_name')


write_back_df = write_back_df.withColumnRenamed('series_name', 'FreeWheel Series Name/TOR Series')\
    .withColumnRenamed('show_name', 'Show/Sport')\
    .withColumnRenamed('is_updated_flag', 'Is_Updated')

write_back_df = write_back_df.toPandas()
write_back_df = write_back_df[['FreeWheel Series Name/TOR Series', 'Show/Sport', 'Is_Updated']]
write_back_df['Show/Sport'] = write_back_df['Show/Sport'].replace("9-1-2001","'9-1-1")
write_back_df['Show/Sport'] = write_back_df['Show/Sport'].replace("9-1-1","'9-1-1")
write_back_df['FreeWheel Series Name/TOR Series'] = write_back_df['FreeWheel Series Name/TOR Series'].replace("01-09-2001","'01-09-2001")
write_back_df['FreeWheel Series Name/TOR Series'] = write_back_df['FreeWheel Series Name/TOR Series'].replace("9-1-1","'9-1-1")
write_back_dict = write_back_df.to_dict('records')

# COMMAND ----------

# Update Google Sheet
clear_sheets(gsheet_service, google_worksheet_id, google_sheet_range)
update_sheet(gsheet_service, google_worksheet_id, google_sheet_range, write_back_dict)

# COMMAND ----------

class TargetMailInfo:
    from_email = f'{from_email}'
    reply_to_address = 'data_adtech@fox.com'
    key = ''
    info = {}
    target_mailing_lists = {
        "Freewheel Series to Show Mapping" : {
            "google_sheet_link" : "https://docs.google.com/spreadsheets/d/1blnK_gNGa5LlxcPGJRMFkmhGb_FrpDt9IjG4HaECJtI/edit?gid=0#gid=0",
            "human_readable_name" : "prod - ad tech freewheel series to show mapping",
            "to" : [
                "prajwal.harikishor@fox.com",
                "fox.ai@fox.com",
                "Lawrence.Medina@fox.com",
                "Rich.KorzeliusIII@fox.com",
                "Anitha.Mohanraj@fox.com",
                "Pradeep.Panneerselvam@fox.com",
                "Spencer.Noonan@fox.com",
                "Jason.Drimer@fox.com",
                "Kristen.Passaro@fox.com",
                "Denise.Franczyk@fox.com",
                "alexa.bezzone@fox.com",
            ],
            "cc" : [
                "alimaafroseshahul.hameed@fox.com",
            ]
        }
    }

    def __init__(self, target):
        self.info = self.target_mailing_lists[target]
    
    def get_report_body(self):
        footer = f'<p>This is an automated email. Please direct any questions or concerns to <a href="mailto: {self.reply_to_address}">{self.reply_to_address}</a>.</p>'
        body_text = f"""<p>Hi,</p>

<p>New Series Names are aviailable in Freewheel, please proceed to map them.</p>

<p>Please find Google Sheet Link: <a href="{self.info['google_sheet_link']}">Series to Show</a>.</p>

{footer}
"""
        return MIMEText(body_text, 'html')

def send_mail(target):
    
    target = TargetMailInfo(target)

    attachment_ready_html = []
    img_id = 0
    mime_images = []

    msg = MIMEMultipart()
    msg['Subject'] = target.info['human_readable_name'].title()
    msg['From'] = target.from_email
    msg['To'] = ", ".join(target.info['to'])
    msg['Cc'] = ", ".join(target.info['cc'])
    msg.attach(target.get_report_body())

    session = boto3.Session(profile_name = aws_profile)
    ses = session.client('ses', region_name='us-west-2')
    ses.send_raw_email(
        Source=msg['From'],
        Destinations=list(set(target.info['to']).union(set(target.info['cc']))),
        RawMessage={'Data': msg.as_string()}
    )

    print('Email sent')

if datetime.today().weekday() == 1:
    send_mail("Freewheel Series to Show Mapping")