# Databricks notebook source
from pyspark.sql import functions as F
from pyspark.sql import types as T
from datetime import datetime, timedelta

# COMMAND ----------

query = f"""
    SELECT
        ft.event_date
        , ft.video_id
        , vc.video_name
        , ft.site_section_id
        , s.site_section_name
        , ft.series_id
        , vs.series_name
        , vc.primary_video_group_id
        , vc.primary_video_group_name
        , vc.prefered_video_group
        , vc.secondary_video_group_id
        , vc.secondary_video_group_name
        , CASE
            WHEN LOWER(vs.series_name) LIKE '%deportes%' THEN 'Deportes'
            WHEN vc.primary_video_group_id = '18773867' THEN 'BTN'
            WHEN LOWER(vs.series_name) LIKE '%monarch%' THEN 'Entertainment'
            
            -- Weather Logic
            WHEN LOWER(vs.series_name) LIKE '%fox weather%' 
                OR LOWER(s.site_section_name) LIKE '%fox weather%' THEN 'Weather'
            
            -- News/Business Logic
            WHEN vc.primary_video_group_id IN ('20474534', '20474467')
                OR LOWER(vs.series_name) LIKE '%vs: news%'
                OR LOWER(vs.series_name) LIKE '%vs: fnc%'
                OR LOWER(vs.series_name) LIKE '%vs: fbn%'
                OR LOWER(vs.series_name) LIKE '%: fnc%'
                OR LOWER(vs.series_name) LIKE '%: fbn%'
                OR LOWER(s.site_section_name) LIKE '%fox news app%'
                OR LOWER(s.site_section_name) LIKE '%fox business app%' THEN 'News/Business'
            
            -- Fox Nation Logic
            WHEN LOWER(vs.series_name) LIKE '%vs: nation%'
                OR LOWER(s.site_section_name) LIKE '%fox nation%' THEN 'Fox Nation'
            WHEN s.site_section_name LIKE '%Fox One%' AND s.site_section_name LIKE '%Nation%' THEN 'Fox Nation'
            
            WHEN LOWER(s.site_section_name) LIKE '%tmz app%' THEN 'TMZ'
            WHEN LOWER(s.site_section_name) LIKE '%outkick app%' THEN 'Outkick'
            WHEN LOWER(vs.series_name) LIKE '%ultimate tag%' THEN 'Entertainment'
            WHEN vc.primary_video_group_id = '18698796' THEN 'Sports SFV'
            
            WHEN vc.primary_video_group_id = '414462094' OR vc.video_name LIKE '%NIVA%' THEN 'NIVA'
            
            -- Sports LFV Logic
            WHEN vc.primary_video_group_id IN ('18698781', '241987048', '241987474')
                OR UPPER(vs.series_name) LIKE '%WWE%'
                OR UPPER(vs.series_name) LIKE '%SMACKDOWN%'
                OR UPPER(vs.series_name) LIKE '%VS: SPORTS%' THEN 'Sports LFV'
            
            -- Entertainment Logic
            WHEN vc.primary_video_group_id = '18652208'
                OR LOWER(s.site_section_name) LIKE '%fox ent%'
                OR LOWER(vs.series_name) LIKE '%vs: ent: fox:%' THEN 'Entertainment'
            
            WHEN vc.primary_video_group_id = '18698699' THEN 'Entertainment SFV'
            
            -- Fox One Cross-Sells
            WHEN s.site_section_name LIKE '%Fox One%' AND s.site_section_name LIKE '%ENT%' THEN 'Entertainment'
            WHEN s.site_section_name LIKE '%Fox One%' AND s.site_section_name LIKE '%Sports%' THEN 'Sports LFV'
            WHEN s.site_section_name LIKE '%Fox One%' AND s.site_section_name LIKE '%Weather%' THEN 'Weather'
            
            -- Tubi Specific Logic
            WHEN UPPER(s.site_section_name) LIKE '%TUBI%' AND vs.series_name = 'Unknown Series' THEN
                CASE 
                    WHEN vc.video_name LIKE '%FOX Entertainment%' THEN 'Entertainment'
                    WHEN LOWER(vc.video_name) LIKE '%gordon ramsay%' THEN 'Entertainment'
                    WHEN LOWER(vc.video_name) LIKE '%masterchef%' THEN 'Entertainment'
                    WHEN LOWER(vc.video_name) LIKE '%hell''s kitchen%' THEN 'Entertainment'
                    WHEN vc.video_name LIKE '%FOX Sports%' THEN 'Sports LFV'
                    WHEN vc.video_name LIKE '%FOX News%' THEN 'News/Business'
                    WHEN vc.video_name LIKE '%FOX Weather%' THEN 'Weather'
                    ELSE 'Tubi' -- Default if within Tubi/Unknown but no video match
                END
                
            WHEN vs.series_name = 'Unknown Series' AND LOWER(vc.video_name) LIKE '%masked singer%' THEN 'Entertainment'
            WHEN LOWER(s.site_section_name) LIKE '%tubi%' THEN 'Tubi'

            ELSE 'Unassigned'
        END AS video_vertical
        , ss.show_name
        , ft.distributor_id
        , ft.distributor_name
        , SUM(ft.video_starts) video_starts
        , DATE_FORMAT(CURRENT_TIMESTAMP(), 'yyyy-MM-dd') AS etl_load_date
        , CURRENT_TIMESTAMP() AS etl_load_timestamp
    FROM fox_bi_prod.bronze_ads.freewheel_analytics_video_starts ft
    LEFT JOIN fox_bi_prod.silver_ads.dim_freewheel_analytics_site s
    ON ft.site_section_id = s.site_section_id
    LEFT JOIN fox_bi_prod.silver_ads.dim_freewheel_analytics_video_series vs
    ON ft.series_id = vs.series_id
    LEFT JOIN fox_bi_prod.silver_ads.dim_freewheel_analytics_video_group_custom vc
    ON ft.video_id = vc.video_id
    LEFT JOIN fox_bi_prod.silver_ads.freewheel_gsheet_map_series_to_show ss
    ON vs.series_name = ss.series_name
    GROUP BY
        ft.event_date
        , ft.video_id
        , vc.video_name
        , ft.site_section_id
        , s.site_section_name
        , ft.series_id
        , vs.series_name
        , vc.primary_video_group_id
        , vc.primary_video_group_name
        , vc.prefered_video_group
        , vc.secondary_video_group_id
        , vc.secondary_video_group_name
        , ss.show_name
        , ft.distributor_id
        , ft.distributor_name
"""

# COMMAND ----------

ft_freewheel_video_starts = spark.sql(query)

# COMMAND ----------

# ft_freewheel_video_starts.write.format('delta')\
#     .mode('overwrite')\
#     .partitionBy('event_date')\
#     .option('mergeSchema', 'true')\
#     .option('overwriteDynamicPartitions', 'true')\
#     .option('delta.enableDeletionVectors', 'false')\
#     .option('delta.enableIcebergCompatV2', 'true')\
#     .option('delta.universalFormat.enabledFormats', 'iceberg')\
#     .option('delta.columnMapping.mode', 'name')\
#     .saveAsTable('fox_bi_prod.silver_ads.ft_freewheel_video_starts_daily_data')

ft_freewheel_video_starts.write.format('delta')\
    .mode('overwrite')\
    .option('partitionOverwriteMode', 'dynamic')\
    .saveAsTable('fox_bi_prod.silver_ads.ft_freewheel_video_starts_daily_data')

# COMMAND ----------

# MAGIC %sql
# MAGIC select event_date, count(*) from fox_bi_prod.silver_ads.ft_freewheel_video_starts_daily_data group by event_date order by event_date