# Databricks notebook source
from pyspark.sql import functions as F
from pyspark.sql import types as T
from datetime import datetime, timedelta

# COMMAND ----------

query = f"""
    SELECT
        /*+ BROADCAST(site, vc) */
        cap.event_date
        , cap.distributor_name
        , cap.distributor_id
        , cap.site_section_id
        , site.site_section_name
        , site.site_id
        , site.site_name
        , cap.video_id
        , vc.video_name
        , vc.prefered_video_group
        , vc.primary_video_group_id
        , vc.primary_video_group_name
        , cap.series_id
        , vs.series_name
        , SUM(cap.net_ad_requests) As net_ad_requests
        , DATE_FORMAT(cap.event_date, 'MM') as event_month
        , DATE_FORMAT(cap.event_date, "y-'Q'Q") as event_quarter
        , DATE_FORMAT(cap.event_date, 'y') as event_year
        , event_year||event_month as ad_month_id
        , DATE_FORMAT(cap.event_date, 'MMMM-y') as ad_month_year
        , DATE_FORMAT(CURRENT_TIMESTAMP(), 'yyyy-MM-dd') AS etl_load_date
        , CURRENT_TIMESTAMP() AS etl_load_timestamp
    FROM fox_bi_prod.bronze_ads.freewheel_analytics_fxw_capacity cap
    LEFT JOIN (
        SELECT
            *
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_site
        WHERE (
            site_section_id
            , site_id
        ) NOT IN (
            SELECT
                dfas.site_section_id
                , -1
            FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_site dfas
            GROUP BY dfas.site_section_id
            HAVING COUNT(*) > 1
        )
    ) site
    ON cap.site_section_id = site.site_section_id
    LEFT JOIN fox_bi_prod.silver_ads.dim_freewheel_analytics_video_group_custom vc
    ON cap.video_id = vc.video_id
    LEFT JOIN fox_bi_prod.silver_ads.dim_freewheel_analytics_video_series vs
    ON cap.series_id = vs.series_id
    GROUP BY
        cap.event_date
        , cap.distributor_name
        , cap.distributor_id
        , cap.site_section_id
        , cap.video_id
        , cap.series_id
        , site.site_section_name
        , site.site_id
        , site.site_name
        , vc.video_name
        , vc.prefered_video_group
        , vc.primary_video_group_id
        , vc.primary_video_group_name
        , vs.series_name
"""

fxw_capacity = spark.sql(query)

# COMMAND ----------

# fxw_capacity.write.format('delta')\
#     .mode('overwrite')\
#     .partitionBy('event_date')\
#     .option('mergeSchema', 'true')\
#     .option('overwriteDynamicPartitions', 'true')\
#     .option('delta.enableDeletionVectors', 'false')\
#     .option('delta.enableIcebergCompatV2', 'true')\
#     .option('delta.universalFormat.enabledFormats', 'iceberg')\
#     .option('delta.columnMapping.mode', 'name')\
#     .saveAsTable('fox_bi_prod.silver_ads.ft_freewheel_fxw_capacity_daily_data')

fxw_capacity.write.format('delta')\
    .mode('overwrite')\
    .option('partitionOverwriteMode', 'dynamic')\
    .saveAsTable('fox_bi_prod.silver_ads.ft_freewheel_fxw_capacity_daily_data')

# COMMAND ----------

# MAGIC %sql
# MAGIC select event_date, count(*) from fox_bi_prod.silver_ads.ft_freewheel_fxw_capacity_daily_data group by event_date order by event_date