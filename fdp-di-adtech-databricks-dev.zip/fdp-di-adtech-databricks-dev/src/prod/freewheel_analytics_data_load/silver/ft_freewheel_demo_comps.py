# Databricks notebook source
from pyspark.sql import functions as F
from pyspark.sql import types as T
from datetime import datetime, timedelta

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW dim_placement AS
# MAGIC SELECT DISTINCT
# MAGIC     placement_id
# MAGIC     , placement_name
# MAGIC     , placement_start_timestamp_est
# MAGIC     , placement_end_timestamp_est
# MAGIC     , placement_budget_model
# MAGIC     , placement_booked_on_target_impression_goal
# MAGIC     , placement_impression_goal
# MAGIC     , placement_forced_over_delivery_percent
# MAGIC     , placement_demographic_on_target_calculation
# MAGIC FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_placement

# COMMAND ----------

current_timestamp = datetime.now()

# COMMAND ----------

query_new = f"""
    SELECT
        ft.event_date
        , COALESCE(ft.advertiser_id, -1) AS advertiser_id
        , COALESCE(ft.advertiser_name, 'N/A') AS advertiser_name
        , COALESCE(ft.agency_id, -1) AS agency_id
        , COALESCE(ft.agency_name, 'N/A') AS agency_name
        , COALESCE(ft.campaign_id, -1) AS campaign_id
        , COALESCE(c.campaign_name, 'N/A') AS campaign_name
        , COALESCE(ft.insertion_order_id, -1) AS insertion_order_id
        , COALESCE(io.insertion_order_name, 'N/A') AS insertion_order_name
        , COALESCE(ft.placement_id, -1) AS placement_id
        , COALESCE(p.placement_name, 'N/A') AS placement_name
        , p.placement_start_timestamp_est
        , p.placement_end_timestamp_est
        , p.placement_budget_model
        , p.placement_booked_on_target_impression_goal
        , p.placement_impression_goal
        , p.placement_forced_over_delivery_percent
        , p.placement_demographic_on_target_calculation
        , SUM(ft.on_target_net_delivered_impressions) AS on_target_net_delivered_impressions
        , SUM(ft.gross_counted_ads) AS gross_counted_ads
        , DATE_FORMAT(CURRENT_TIMESTAMP(), 'yyyy-MM-dd') AS etl_load_date
        , CAST('{current_timestamp.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]}' AS TIMESTAMP) AS etl_load_timestamp
    FROM fox_bi_prod.bronze_ads.freewheel_analytics_demo_comps ft
    LEFT JOIN fox_bi_prod.silver_ads.dim_freewheel_analytics_campaign c
    ON ft.campaign_id = c.campaign_id
    LEFT JOIN fox_bi_prod.silver_ads.dim_freewheel_analytics_insertion_order io
    ON ft.insertion_order_id = io.insertion_order_id
    LEFT JOIN dim_placement p
    ON ft.placement_id = p.placement_id
    GROUP BY
        ft.event_date
        , ft.advertiser_id
        , ft.advertiser_name
        , ft.agency_id
        , ft.agency_name
        , ft.campaign_id
        , c.campaign_name
        , ft.insertion_order_id
        , io.insertion_order_name
        , ft.placement_id
        , p.placement_name
        , p.placement_start_timestamp_est
        , p.placement_end_timestamp_est
        , p.placement_budget_model
        , p.placement_booked_on_target_impression_goal
        , p.placement_impression_goal
        , p.placement_forced_over_delivery_percent
        , p.placement_demographic_on_target_calculation
"""

# COMMAND ----------

query_current = """
    SELECT
        event_date
        , COALESCE(advertiser_id, -1) AS advertiser_id
        , COALESCE(advertiser_name, 'N/A') AS advertiser_name
        , COALESCE(agency_id, -1) AS agency_id
        , COALESCE(agency_name, 'N/A') AS agency_name
        , COALESCE(campaign_id, -1) AS campaign_id
        , COALESCE(campaign_name, 'N/A') AS campaign_name
        , COALESCE(insertion_order_id, -1) AS insertion_order_id
        , COALESCE(insertion_order_name, 'N/A') AS insertion_order_name
        , COALESCE(placement_id, -1) AS placement_id
        , COALESCE(placement_name, 'N/A') AS placement_name
        , placement_start_timestamp_est
        , placement_end_timestamp_est
        , placement_budget_model
        , placement_booked_on_target_impression_goal
        , placement_impression_goal
        , placement_forced_over_delivery_percent
        , placement_demographic_on_target_calculation
        , on_target_net_delivered_impressions
        , gross_counted_ads
        , etl_load_date
        , etl_load_timestamp
    FROM fox_bi_prod.silver_ads.ft_freewheel_demo_comp_daily_data
"""

# COMMAND ----------

ft_freewheel_demo_comp_new = spark.sql(query_new)
ft_freewheel_demo_comp_current = spark.sql(query_current)
ft_freewheel_demo_comp_final = ft_freewheel_demo_comp_new.union(ft_freewheel_demo_comp_current)

primary_key = [
    'event_date',
    'advertiser_id',
    'agency_id',
    'campaign_id',
    'insertion_order_id',
    'placement_id'
]

temp_df = ft_freewheel_demo_comp_final.groupBy(primary_key).agg(F.max('etl_load_timestamp').alias('etl_load_timestamp'))
ft_freewheel_demo_comp_final = ft_freewheel_demo_comp_final.join(temp_df.select(primary_key+['etl_load_timestamp']), on=primary_key+['etl_load_timestamp'], how='inner').dropDuplicates()

# COMMAND ----------

# ft_freewheel_demo_comp_final.write.format('delta')\
#     .mode('overwrite')\
#     .partitionBy('event_date')\
#     .option('mergeSchema', 'true')\
#     .option('overwriteDynamicPartitions', 'true')\
#     .option('delta.enableDeletionVectors', 'false')\
#     .option('delta.enableIcebergCompatV2', 'true')\
#     .option('delta.universalFormat.enabledFormats', 'iceberg')\
#     .option('delta.columnMapping.mode', 'name')\
#     .saveAsTable('fox_bi_prod.silver_ads.ft_freewheel_demo_comp_daily_data')

ft_freewheel_demo_comp_final.write.format('delta')\
    .mode('overwrite')\
    .option('partitionOverwriteMode', 'dynamic')\
    .saveAsTable('fox_bi_prod.silver_ads.ft_freewheel_demo_comp_daily_data')

# COMMAND ----------

# MAGIC %sql
# MAGIC select event_date, count(*) from fox_bi_prod.silver_ads.ft_freewheel_demo_comp_daily_data group by event_date order by event_date