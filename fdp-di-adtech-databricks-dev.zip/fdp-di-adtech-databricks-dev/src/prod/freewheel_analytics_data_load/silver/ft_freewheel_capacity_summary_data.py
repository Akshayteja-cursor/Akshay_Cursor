# Databricks notebook source
from pyspark.sql import functions as F
from pyspark.sql import types as T
from datetime import datetime, timedelta

# COMMAND ----------

query = f"""
    SELECT
        cap.event_date
        , cap.distributor_name
        , cap.distributor_id
        , cap.site_section_id
        , cap.video_id
        , cap.series_id
        , cap.ad_unit_position AS global_ad_unit_position
        , cap.ad_unit_class AS global_ad_unit_class
        , CASE
            WHEN cap.ad_unit_type_name LIKE '%Affiliate%' THEN 'Affiliates'
            ELSE cap.ad_unit_class
        END AS global_ad_unit_category
        , SUM(cap.total_historical_unconstrained_ad_avails) AS total_historical_unconstrained_ad_avails
        , SUM(cap.total_historical_constrained_ad_avails) AS total_historical_constrained_ad_avails
        , SUM(cap.historical_unfilled_ad_opportunities) AS historical_unfilled_ad_opportunities
    FROM fox_bi_prod.bronze_ads.freewheel_analytics_capacity cap
    GROUP BY
        cap.event_date
        , cap.distributor_name
        , cap.distributor_id
        , cap.site_section_id
        , cap.video_id
        , cap.series_id
        , cap.ad_unit_position
        , cap.ad_unit_class
        , global_ad_unit_category
"""

spark.sql(query).createOrReplaceTempView('ft_capacity_delivery')

# COMMAND ----------

query = f"""
    SELECT
        dd.event_date
        , dd.distributor_name
        , dd.distributor_id
        , dd.site_section_id
        , dd.video_id
        , dd.series_id
        , dd.global_ad_unit_position
        , dd.global_ad_unit_class
        , dd.global_ad_unit_category
        , SUM(dd.net_counted_ads) AS net_counted_ads
        , SUM(dd.gross_counted_ads) AS gross_counted_ads
        , SUM(dd.run_revenue_amount) AS run_revenue_amount
        , (SUM(dd.run_revenue_amount)/SUM(dd.net_counted_ads)) * 1000 AS ecpm_amount
        , SUM(dd.delivered_clicks) AS delivered_clicks
        , SUM(dd.measurable_video_ads_quartile_impressions) AS measurable_video_ads_quartile_impressions
        , SUM(dd.direct_guaranteed_impressions) AS direct_guaranteed_impressions
        , SUM(dd.direct_pre_emptible_impressions) AS direct_pre_emptible_impressions
        , SUM(dd.promo_guaranteed_impressions) AS promo_guaranteed_impressions
        , SUM(dd.promo_pre_emptible_impressions) AS promo_pre_emptible_impressions
        , SUM(dd.programmatic_guaranteed_impressions) AS programmatic_guaranteed_impressions
        , SUM(dd.inventory_share_impressions) AS inventory_share_impressions
        , SUM(dd.affiliates_impressions) AS affiliates_impressions
        , SUM(dd.hard_guaranteed_impressions) AS hard_guaranteed_impressions
        , SUM(dd.backfill_impressions) AS backfill_impressions
        , SUM(dd.promo_guaranteed_monetizable_impressions) AS promo_guaranteed_monetizable_impressions
        , SUM(dd.promo_guaranteed_unmonetizable_impressions) AS promo_guaranteed_unmonetizable_impressions
        , SUM(dd.promo_pre_emptible_monetizable_impressions) AS promo_pre_emptible_monetizable_impressions
        , SUM(dd.promo_pre_emptible_unmonetizable_impressions) AS promo_pre_emptible_unmonetizable_impressions
    FROM fox_bi_prod.silver_ads.ft_freewheel_delivery_daily_data dd
    GROUP BY
        dd.event_date
        , dd.distributor_name
        , dd.distributor_id
        , dd.site_section_id
        , dd.video_id
        , dd.series_id
        , dd.global_ad_unit_position
        , dd.global_ad_unit_class
        , dd.global_ad_unit_category
"""

spark.sql(query).createOrReplaceTempView('ft_delivery_data')

# COMMAND ----------

query = f"""
    SELECT
        /*+ BROADCAST(site, vs, vc, svgmo, svgio, ss, usvg) */
        COALESCE(dd.distributor_name, cap.distributor_name) AS distributor_name
        , COALESCE(dd.distributor_id, cap.distributor_id) AS distributor_id
        , COALESCE(dd.site_section_id, cap.site_section_id) AS site_section_id
        , site.site_section_name
        , site.site_id
        , site.site_name
        , COALESCE(dd.video_id, cap.video_id) AS video_id
        , vc.video_name
        , COALESCE(dd.series_id, cap.series_id) AS series_id
        , vs.series_name
        , COALESCE(dd.global_ad_unit_position, cap.global_ad_unit_position) AS global_ad_unit_position
        , COALESCE(dd.global_ad_unit_class, cap.global_ad_unit_class) AS global_ad_unit_class
        , COALESCE(dd.global_ad_unit_category, cap.global_ad_unit_category) AS global_ad_unit_category
        , CASE
            WHEN LOWER(site.site_section_name) LIKE '%vod%' THEN 'VOD'
            WHEN LOWER(site.site_section_name) LIKE '%run of site%' THEN 'Unk'
            WHEN LOWER(site.site_section_name) LIKE '%live%' THEN 'Live'
            ELSE 'Unk'
        END AS stream_type
        , CASE
            WHEN site.site_section_name LIKE '%Run Of Site%' THEN
                CASE
                    WHEN site.site_section_name LIKE '%Fubo%' THEN 'FuboTV'
                    ELSE SPLIT_PART(SUBSTRING(site.site_section_name FROM 34), ' ', 1)
                END
            WHEN site.site_section_name LIKE '%SS: Owned: %' THEN SPLIT_PART(SUBSTRING(site.site_section_name FROM 12), ':', 1)
            WHEN site.site_section_name LIKE '%SS: Partner: %' THEN SPLIT_PART(SUBSTRING(site.site_section_name FROM 14), ':', 1)
            WHEN site.site_section_name LIKE '%Charter: Programmer VOD%' THEN 'Canoe'
			WHEN site.site_section_name LIKE '%Cox: Legacy Live%' THEN 'Canoe'
			WHEN site.site_section_name LIKE '%Cox: Watermark C2%' THEN 'Canoe'
			WHEN site.site_section_name LIKE '%Comcast%IP STB VOD%' THEN 'Canoe'
        END AS platform_name
        ,  CASE
            WHEN UPPER(COALESCE(dd.global_ad_unit_category, cap.global_ad_unit_category)) = 'DISPLAY ADS' THEN 'Display'
            WHEN LOWER(vs.series_name) LIKE '%deportes%' THEN 'Deportes'
            WHEN vc.primary_video_group_id = '18773867' THEN 'BTN'
            WHEN LOWER(vs.series_name) LIKE '%monarch%' THEN 'Entertainment'
            
            -- Weather Logic
            WHEN LOWER(vs.series_name) LIKE '%fox weather%' 
                OR LOWER(site.site_section_name) LIKE '%fox weather%' THEN 'Weather'
            
            -- News/Business Logic
            WHEN vc.primary_video_group_id IN ('20474534', '20474467')
                OR LOWER(vs.series_name) LIKE '%vs: news%'
                OR LOWER(vs.series_name) LIKE '%vs: fnc%'
                OR LOWER(vs.series_name) LIKE '%vs: fbn%'
                OR LOWER(vs.series_name) LIKE '%: fnc%'
                OR LOWER(vs.series_name) LIKE '%: fbn%'
                OR LOWER(site.site_section_name) LIKE '%fox news app%'
                OR LOWER(site.site_section_name) LIKE '%fox business app%' THEN 'News/Business'
            
            -- Fox Nation Logic
            WHEN LOWER(vs.series_name) LIKE '%vs: nation%'
                OR LOWER(site.site_section_name) LIKE '%fox nation%' THEN 'Fox Nation'
            WHEN site.site_section_name LIKE '%Fox One%' AND site.site_section_name LIKE '%Nation%' THEN 'Fox Nation'
            
            WHEN LOWER(site.site_section_name) LIKE '%tmz app%' THEN 'TMZ'
            WHEN LOWER(site.site_section_name) LIKE '%outkick app%' THEN 'Outkick'
            WHEN LOWER(vs.series_name) LIKE '%ultimate tag%' THEN 'Entertainment'
            WHEN vc.primary_video_group_id = '18698796' THEN 'Sports SFV'
            
            WHEN vc.primary_video_group_id = '414462094' OR vc.video_name LIKE '%NIVA%' THEN 'NIVA'
            
            -- Sports LFV Logic
            WHEN vc.primary_video_group_id IN ('18698781', '241987048', '241987474')
                OR UPPER(vs.series_name) LIKE '%WWE%'
                OR UPPER(vs.series_name) LIKE '%SMACKDOWN%'
                OR UPPER(vs.series_name) LIKE '%VS: SPORTS%' THEN 'Sports LFV'
            
            -- Entertainment Logic
            WHEN vc.primary_video_group_id = '18652208'
                OR LOWER(site.site_section_name) LIKE '%fox ent%'
                OR LOWER(vs.series_name) LIKE '%vs: ent: fox:%' THEN 'Entertainment'
            
            WHEN vc.primary_video_group_id = '18698699' THEN 'Entertainment SFV'
            
            -- Fox One Cross-Sells
            WHEN site.site_section_name LIKE '%Fox One%' AND site.site_section_name LIKE '%ENT%' THEN 'Entertainment'
            WHEN site.site_section_name LIKE '%Fox One%' AND site.site_section_name LIKE '%Sports%' THEN 'Sports LFV'
            WHEN site.site_section_name LIKE '%Fox One%' AND site.site_section_name LIKE '%Weather%' THEN 'Weather'
            
            -- Tubi Specific Logic
            WHEN UPPER(site.site_section_name) LIKE '%TUBI%' AND vs.series_name = 'Unknown Series' THEN
                CASE 
                    WHEN vc.video_name LIKE '%FOX Entertainment%' THEN 'Entertainment'
                    WHEN LOWER(vc.video_name) LIKE '%gordon ramsay%' THEN 'Entertainment'
                    WHEN LOWER(vc.video_name) LIKE '%masterchef%' THEN 'Entertainment'
                    WHEN LOWER(vc.video_name) LIKE "%hell's kitchen%" THEN 'Entertainment'
                    WHEN LOWER(vc.video_name) LIKE '%masked singer%' THEN 'Entertainment'
                    WHEN vc.video_name LIKE '%FOX Sports%' THEN 'Sports LFV'
                    WHEN vc.video_name LIKE '%FOX News%' THEN 'News/Business'
                    WHEN vc.video_name LIKE '%FOX Weather%' THEN 'Weather'
                    ELSE 'Tubi' -- Default if within Tubi/Unknown but no video match
                END
                
            WHEN vs.series_name = 'Unknown Series' AND LOWER(vc.video_name) LIKE '%masked singer%' THEN 'Entertainment'
            WHEN LOWER(site.site_section_name) LIKE '%tubi%' THEN 'Tubi'

            ELSE 'Unassigned'
        END Video_vertical
        , CASE
            WHEN video_vertical ='Deportes' OR video_vertical LIKE '%Sports%' THEN (
                CASE
                    WHEN stream_type ='VOD' THEN 'VOD'
                    WHEN site.site_section_name like '%Live: FOX%' THEN 'FBC'
                    WHEN lower(site.site_section_name) like '%live: fbn%' THEN 'FBN'
                    WHEN lower(site.site_section_name) like '%live: btn%' THEN 'BTN'
                    WHEN lower(site.site_section_name) like '%live: deportes%' THEN 'Deportes'
                    WHEN lower(site.site_section_name) like '%fs1%' 
                        OR lower(site.site_section_name) like '%fs2%' 
                        OR lower(site.site_section_name) like '%live: fsp%' 
                        OR (site.site_section_name) like '%Live: FoxDigital%' 
                        OR (site.site_section_name) like '%Live: Fox Digital%' THEN 'FS1/FS2'
                    ELSE 'Unk'
                END
            )
            ELSE 'Unk'
        END as network
        , CASE
            WHEN site.site_section_name LIKE '%Charter: Programmer VOD%' THEN 'STB VOD'
			WHEN site.site_section_name LIKE '%Cox: Legacy Live%' THEN 'STB VOD'
			WHEN site.site_section_name LIKE '%Cox: Watermark C2%' THEN 'STB VOD'
			WHEN site.site_section_name LIKE '%Comcast%IP STB VOD%' THEN 'STB VOD'
			WHEN site.site_section_name like '%: Canoe%' THEN 'STB VOD'
            WHEN site.site_section_name LIKE '%FNC%' THEN 'FNC'
            WHEN site.site_section_name LIKE '%FBN%' THEN 'FBN'
            WHEN site.site_section_name LIKE '%FOX Nation%' THEN 'FOX Nation'
            WHEN site.site_section_name LIKE '%Hulu%' THEN 'Hulu'
            WHEN site.site_section_name LIKE '%Tubi%' THEN 'Tubi'
            WHEN site.site_section_name LIKE '%: STB%' THEN 'STB VOD'
            WHEN site.site_section_name LIKE '%Comcast Production%' THEN 'STB VOD'
            WHEN site.site_section_name LIKE '%Partner%' THEN 'Off-Platform'
            WHEN site.site_section_name LIKE '%Run Of Site%' THEN 'Off-Platform'
            WHEN site.site_section_name LIKE '%Owned%' THEN 'O&O'
            ELSE 'Other'
        END AS platform_group
        , CASE
            WHEN svgio.series_name IS NULL THEN 'Out of Season'
            ELSE 'In Season'
        END AS season_in_out_flag
        , vc.prefered_video_group
        , vc.primary_video_group_id
        , vc.primary_video_group_name
        , COALESCE(svgmo.season_video_group_id, vc.season_video_group_id) AS season_video_group_id
        , COALESCE(svgmo.season_video_group_name, vc.season_video_group_name) AS season_video_group_name
        , COALESCE(ss.show_name, 'N/A') AS show_name
        , CASE
            WHEN LOWER(vc.secondary_video_group_name) = 'unassigned' AND vc.video_name='V: Partner: Youtube TV: FS1 Live' THEN '18830626'
            WHEN LOWER(vc.secondary_video_group_name) = 'unassigned' AND vc.video_name='V: Partner: Youtube TV: FS2 Live' THEN '18830626'
            WHEN LOWER(vc.secondary_video_group_name) = 'unassigned' AND LOWER(ss.show_name) = 'studio shows' THEN '18830626'
            WHEN LOWER(vc.secondary_video_group_name) = 'unassigned' THEN COALESCE(usvg.assigned_secondary_video_group_id, vc.secondary_video_group_id)
            ELSE vc.secondary_video_group_id
        END AS secondary_video_group_id
        , CASE
            WHEN LOWER(vc.secondary_video_group_name) = 'unassigned' AND vc.video_name='V: Partner: Youtube TV: FS1 Live' THEN 'VG: SPORTS: Long Form: Talk Shows'
            WHEN LOWER(vc.secondary_video_group_name) = 'unassigned' AND vc.video_name='V: Partner: Youtube TV: FS2 Live' THEN 'VG: SPORTS: Long Form: Talk Shows'
            WHEN LOWER(vc.secondary_video_group_name) = 'unassigned' AND LOWER(ss.show_name) = 'studio shows' THEN 'VG: SPORTS: Long Form: Talk Shows'
            WHEN LOWER(vc.secondary_video_group_name) = 'unassigned' THEN COALESCE(usvg.assigned_secondary_video_group_name, vc.secondary_video_group_name)
            ELSE vc.secondary_video_group_name
        END AS secondary_video_group_name
        , dd.net_counted_ads
        , dd.gross_counted_ads
        , dd.run_revenue_amount
        , dd.ecpm_amount
        , dd.delivered_clicks
        , dd.measurable_video_ads_quartile_impressions
        , dd.direct_guaranteed_impressions
        , dd.direct_pre_emptible_impressions
        , dd.promo_guaranteed_impressions
        , dd.promo_pre_emptible_impressions
        , dd.programmatic_guaranteed_impressions
        , dd.inventory_share_impressions
        , dd.affiliates_impressions
        , dd.hard_guaranteed_impressions
        , dd.backfill_impressions
        , dd.promo_guaranteed_monetizable_impressions
        , dd.promo_guaranteed_unmonetizable_impressions
        , dd.promo_pre_emptible_monetizable_impressions
        , dd.promo_pre_emptible_unmonetizable_impressions
        , cap.total_historical_unconstrained_ad_avails
        , cap.total_historical_constrained_ad_avails
        , cap.historical_unfilled_ad_opportunities
        , COALESCE(dd.event_date, cap.event_date) AS event_date
        , DATE_FORMAT(COALESCE(dd.event_date, cap.event_date), 'MM') as event_month
        , DATE_FORMAT(COALESCE(dd.event_date, cap.event_date), "y-'Q'Q") as event_quarter
        , DATE_FORMAT(COALESCE(dd.event_date, cap.event_date), 'y') as event_year
        , event_year||event_month as ad_month_id
        , DATE_FORMAT(COALESCE(dd.event_date, cap.event_date), 'MMMM-y') as ad_month_year
        , DATE_FORMAT(CURRENT_TIMESTAMP(), 'yyyy-MM-dd') AS etl_load_date
        , CURRENT_TIMESTAMP() AS etl_load_timestamp

        , CASE
            WHEN LOWER(site.site_section_name) LIKE '%android tv%'       THEN 'Android TV'
            WHEN LOWER(site.site_section_name) LIKE '%androidtv%'        THEN 'Android TV'
            WHEN LOWER(site.site_section_name) LIKE '%apple%'            THEN 'Apple TV'
            WHEN LOWER(site.site_section_name) LIKE '%fire%'             THEN 'Amazon TV'
            WHEN LOWER(site.site_section_name) LIKE '%roku%'             THEN 'Roku'
            WHEN LOWER(site.site_section_name) LIKE '%mobile app: android%' THEN 'Android App'
            WHEN LOWER(site.site_section_name) LIKE '%android phone%'    THEN 'Android App'
            WHEN LOWER(site.site_section_name) LIKE '%android tablet%'   THEN 'Android App'
            WHEN LOWER(site.site_section_name) LIKE '%ios%'              THEN 'iOS App'
            WHEN LOWER(site.site_section_name) LIKE '%ipad%'             THEN 'iOS App'
            WHEN LOWER(site.site_section_name) LIKE '%iphone%'           THEN 'iOS App'
            WHEN LOWER(site.site_section_name) LIKE '%mobile app%'       THEN 'Mobile App'
            WHEN LOWER(site.site_section_name) LIKE '%mobile web%'       THEN 'Mobile Web'
            WHEN LOWER(site.site_section_name) LIKE '%tablet web%'       THEN 'Tablet Web'
            WHEN LOWER(site.site_section_name) LIKE '%mobile tablet%'    THEN 'Mobile Web'
            WHEN LOWER(site.site_section_name) LIKE '%mobile handheld%'  THEN 'Mobile Web'
            WHEN LOWER(site.site_section_name) LIKE '%desktop%'          THEN 'Desktop Web'
            WHEN LOWER(site.site_section_name) LIKE '%web%'              THEN 'Web'
            WHEN LOWER(site.site_section_name) LIKE '%amp%'              THEN 'AMP'
            WHEN LOWER(site.site_section_name) LIKE '%ctv%'              THEN 'Other CTV'
            ELSE 'Unknown'
          END AS custom_platform

        , CASE 
            WHEN LOWER(custom_platform) = "android tv"  THEN "CTV"
            WHEN LOWER(custom_platform) = "apple tv"    THEN "CTV"
            WHEN LOWER(custom_platform) = "amazon tv"   THEN "CTV"
            WHEN LOWER(custom_platform) = "roku"        THEN "CTV"
            WHEN LOWER(custom_platform) = "other ctv"   THEN "CTV"
            WHEN LOWER(custom_platform) LIKE '%app%'    THEN "Mobile Apps"
            WHEN LOWER(custom_platform) = "mobile web"  THEN "Mobile/Tablet Web"
            WHEN LOWER(custom_platform) = "tablet web"  THEN "Mobile/Tablet Web"
            WHEN LOWER(custom_platform) = "amp"         THEN "Mobile/Tablet Web"
            WHEN LOWER(custom_platform) = "desktop web" THEN "Desktop Web"
            WHEN LOWER(custom_platform) = "web"         THEN "Web"
            ELSE "Unknown"
          END AS custom_platform_group

        , CASE
            -- Series Name–based rules
            WHEN (UPPER(COALESCE(vs.series_name, '')) LIKE '%FBN%'
                    OR UPPER(COALESCE(vs.series_name, '')) LIKE '%FOX BUSINESS%'
                    OR UPPER(COALESCE(vs.series_name, '')) LIKE '%VS: BUSINESS%') THEN 'FBN'
            WHEN UPPER(COALESCE(vs.series_name, '')) LIKE '%FOX WEATHER%'         THEN 'FXW'
            WHEN UPPER(COALESCE(vs.series_name, '')) LIKE '%NEWS%'                THEN 'FNC'
            WHEN UPPER(COALESCE(vs.series_name, '')) LIKE '%BTN%'                 THEN 'BTN'
            WHEN UPPER(COALESCE(vs.series_name, '')) LIKE '%DEPORTES%'            THEN 'Deportes'
            WHEN UPPER(COALESCE(vs.series_name, '')) LIKE '%SPORTS%'              THEN 'FS'
            WHEN UPPER(COALESCE(vs.series_name, '')) LIKE '%VS: ENT%'             THEN 'ENT'
            WHEN UPPER(COALESCE(vs.series_name, '')) LIKE '%TUBI%'                THEN 'TUBI'
            WHEN UPPER(COALESCE(vs.series_name, '')) LIKE '%VS: NATION%'          THEN 'Fox Nation'

            -- Site Section Name–based rules
            WHEN (UPPER(COALESCE(site.site_section_name, '')) LIKE '%FOX NEWS%'
                    OR UPPER(COALESCE(site.site_section_name, '')) LIKE '%FNC%')  THEN 'FNC'
            WHEN (UPPER(COALESCE(site.site_section_name, '')) LIKE '%FOX BUSINESS%'
                    OR UPPER(COALESCE(site.site_section_name, '')) LIKE '%FBN%')  THEN 'FBN'
            WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%FOX WEATHER%' THEN 'FXW'
            WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%TMZ%'         THEN 'TMZ'
            WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%OUTKICK%'     THEN 'OKI'
            WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%BTN%'         THEN 'BTN'
            WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%DEPORTES%'    THEN 'Deportes'
            WHEN (UPPER(COALESCE(site.site_section_name, '')) LIKE '%FS%'
                    OR UPPER(COALESCE(site.site_section_name, '')) LIKE '%FOX SPORTS%')
                                                                                  THEN 'FS'
            WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%FOX ENT%'     THEN 'ENT'

            -- Tubi + Unknown Series + Video Name disambiguation
            WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%TUBI%'
                AND COALESCE(vs.series_name, '') = 'Unknown Series'
                AND UPPER(COALESCE(vc.video_name, '')) LIKE '%FOX ENTERTAINMENT%'           THEN 'ENT'
            WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%TUBI%'
                AND COALESCE(vs.series_name, '') = 'Unknown Series'
                AND ( UPPER(COALESCE(vc.video_name, '')) LIKE '%FOX SPORTS%'
                        OR UPPER(COALESCE(vc.video_name, '')) LIKE '%ONEFOX VOD SPORTS%' )  THEN 'FS'
            WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%TUBI%'
                AND COALESCE(vs.series_name, '') = 'Unknown Series'
                AND UPPER(COALESCE(vc.video_name, '')) LIKE '%FOX NEWS%'                    THEN 'FNC'
            WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%TUBI%'
                AND COALESCE(vs.series_name, '') = 'Unknown Series'
                AND UPPER(COALESCE(vc.video_name, '')) LIKE '%FOX WEATHER%'                 THEN 'FXW'

            -- Remaining Tubi / Fox Nation
            WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%TUBI%'                  THEN 'TUBI'
            WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%FOX NATION%'            THEN 'Fox Nation'

            ELSE 'Unknown'
          END AS custom_property 

        , CASE
            WHEN UPPER(custom_property) IN ('FNC', 'FBN', 'FXW', 'TMZ', 'OKI') THEN 'NEWS'
            WHEN UPPER(custom_property) IN ('FS', 'BTN', 'DEPORTES') THEN 'SPORTS'
            WHEN UPPER(custom_property) = 'ENT' THEN 'ENTERTAINMENT'
            WHEN UPPER(custom_property) = 'TUBI' THEN 'TUBI'
            ELSE 'Unknown'
          END AS custom_vertical

        , CASE
            -- Case 1: SS: Owned
            WHEN site.site_section_name ILIKE '%SS: Owned%' THEN
                CASE
                WHEN LOCATE(':', site.site_section_name, 12) > 0 THEN
                    SUBSTRING(
                    site.site_section_name,
                    12,
                    LOCATE(':', site.site_section_name, 12) - 12
                    )
                ELSE
                    SUBSTRING(
                    site.site_section_name,
                    12,
                    LENGTH(site.site_section_name) - 11
                    )
                END

            -- Case 2: SS: Partner
            WHEN site.site_section_name ILIKE '%SS: Partner%' THEN
                CASE
                WHEN LOCATE(':', site.site_section_name, 14) > 0 THEN
                    SUBSTRING(
                    site.site_section_name,
                    14,
                    LOCATE(':', site.site_section_name, 14) - 14
                    )
                ELSE
                    SUBSTRING(
                    site.site_section_name,
                    14,
                    LENGTH(site.site_section_name) - 13
                    )
                END

            ELSE NULL
          END AS custom_distributor

        ,CASE 
            WHEN UPPER(site.site_section_name) LIKE '%CLIP%' THEN "SFV" 
            WHEN UPPER(site.site_section_name) LIKE '%SS: OWNED: FOX WEATHER APP: MOBILE APP%' THEN "SFV"
            WHEN UPPER(site.site_section_name) LIKE '%SS: OWNED: FOX WEATHER APP: WEB%' THEN "SFV" 
            ELSE "LFV" 
          END AS custom_ad_format
          
    FROM ft_delivery_data dd
    FULL OUTER JOIN ft_capacity_delivery cap
    ON dd.event_date = cap.event_date
    AND dd.distributor_name = cap.distributor_name
    AND dd.distributor_id = cap.distributor_id
    AND dd.site_section_id = cap.site_section_id
    AND dd.video_id = cap.video_id
    AND dd.series_id = cap.series_id
    AND dd.global_ad_unit_position = cap.global_ad_unit_position
    AND dd.global_ad_unit_class = cap.global_ad_unit_class
    AND dd.global_ad_unit_category = cap.global_ad_unit_category
    LEFT JOIN (
        SELECT
            *
        FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_site
        WHERE (
            site_section_id
            , site_id
        ) NOT IN (
            SELECT
                dfas.site_section_id
                , -1
            FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_site dfas
            GROUP BY dfas.site_section_id
            HAVING COUNT(*) > 1
        )
    ) site
    ON COALESCE(dd.site_section_id, cap.site_section_id) = site.site_section_id
    LEFT JOIN fox_bi_prod.silver_ads.dim_freewheel_analytics_video_series vs
    ON COALESCE(dd.series_id, cap.series_id) = vs.series_id
    LEFT JOIN fox_bi_prod.silver_ads.dim_freewheel_analytics_video_group_custom vc
    ON COALESCE(dd.video_id, cap.video_id) = vc.video_id
    LEFT JOIN fox_bi_prod.raw_ads.freewheel_gsheet_map_season_video_group_manual_override svgmo
    ON vc.video_name = svgmo.video_name
    LEFT JOIN (
        SELECT DISTINCT
            series_name
            , season_video_group_id
            , start_date
            , end_date
        FROM fox_bi_prod.raw_ads.freewheel_gsheet_map_season_video_group_in_out
        WHERE season_video_group_id NOT ILIKE 'NA'
    ) svgio
    ON COALESCE(svgmo.season_video_group_id, vc.season_video_group_id) = svgio.season_video_group_id
    AND COALESCE(dd.event_date, cap.event_date) BETWEEN TO_DATE(svgio.start_date, 'M/d/yyyy') AND TO_DATE(svgio.end_date, 'M/d/yyyy')
    LEFT JOIN fox_bi_prod.silver_ads.freewheel_gsheet_map_series_to_show ss
    ON vs.series_name = ss.series_name
    LEFT JOIN fox_bi_prod.silver_ads.freewheel_gsheet_map_unassigned_secondary_video_group usvg
    ON vc.video_name = usvg.video_name
    AND vc.primary_video_group_name = usvg.primary_video_group_name
    AND vc.secondary_video_group_name = usvg.secondary_video_group_name
    AND vs.series_name = usvg.series_name
"""

capacity_summary = spark.sql(query)

# COMMAND ----------

# capacity_summary.write.format('delta')\
#     .mode('overwrite')\
#     .partitionBy('event_date')\
#     .option('mergeSchema', 'true')\
#     .option('overwriteDynamicPartitions', 'true')\
#     .option('delta.enableDeletionVectors', 'false')\
#     .option('delta.enableIcebergCompatV2', 'true')\
#     .option('delta.universalFormat.enabledFormats', 'iceberg')\
#     .option('delta.columnMapping.mode', 'name')\
#     .saveAsTable('fox_bi_prod.silver_ads.ft_freewheel_capacity_summary_daily_data')

capacity_summary.write.format('delta')\
    .mode('overwrite')\
    .option('partitionOverwriteMode', 'dynamic')\
    .saveAsTable('fox_bi_prod.silver_ads.ft_freewheel_capacity_summary_daily_data')

# COMMAND ----------

# MAGIC %sql
# MAGIC select event_date, count(*) from fox_bi_prod.silver_ads.ft_freewheel_capacity_summary_daily_data group by event_date order by event_date
