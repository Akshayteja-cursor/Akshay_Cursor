# Databricks notebook source
import configparser

# COMMAND ----------

# MAGIC %run ./freewheel_analytics_config

# COMMAND ----------

dbutils.widgets.text("env", "")
env = dbutils.widgets.get("env")

# COMMAND ----------

config = configparser.ConfigParser()
config = freewheel_analytics_config[env]
display(config)
catalog=config['catalog']
silver_schema=config['silver_schema']
bronze_schema = config['bronze_schema']
raw_schema=config['raw_schema']

# COMMAND ----------

capicity_sql = f"""
WITH capacity_agg AS (
    SELECT
        event_date,
        site_section_id,
        video_id,
        series_id,
        distributor_id,
        distributor_name,
        SUM(total_historical_unconstrained_ad_avails) AS total_historical_unconstrained_ad_avails,
        SUM(total_historical_constrained_ad_avails)   AS total_historical_constrained_ad_avails,
        SUM(historical_unfilled_ad_opportunities)     AS historical_unfilled_ad_opportunities
    FROM {catalog}.{bronze_schema}.freewheel_analytics_capacity
    GROUP BY
        event_date,
        site_section_id,
        video_id,
        series_id,
        distributor_id,
        distributor_name
),
fxw_agg AS (
    SELECT
        event_date,
        site_section_id,
        video_id,
        series_id,
        distributor_id,
        distributor_name,
        SUM(net_ad_requests) AS net_ad_requests
    FROM {catalog}.{bronze_schema}.freewheel_analytics_fxw_capacity
    GROUP BY
        event_date,
        site_section_id,
        video_id,
        series_id,
        distributor_id,
        distributor_name
),
base AS (
    SELECT
        COALESCE(c.event_date, f.event_date) AS event_date,
        COALESCE(c.site_section_id, f.site_section_id) AS site_section_id,
        COALESCE(c.video_id, f.video_id) AS video_id,
        COALESCE(c.series_id, f.series_id) AS series_id,
        COALESCE(c.distributor_id, f.distributor_id) AS distributor_id,
        COALESCE(c.distributor_name, f.distributor_name) AS distributor_name,
        c.total_historical_unconstrained_ad_avails,
        c.total_historical_constrained_ad_avails,
        c.historical_unfilled_ad_opportunities,
        f.net_ad_requests
    FROM capacity_agg c
    FULL OUTER JOIN fxw_agg f
        ON c.event_date = f.event_date
       AND c.site_section_id = f.site_section_id
       AND c.video_id = f.video_id
       AND c.series_id = f.series_id
       AND c.distributor_id = f.distributor_id
),

fnl AS (
    SELECT
        b.event_date,
        b.site_section_id,
        site.site_section_name,
        b.video_id,
        vc.video_name,
        b.series_id,
        vs.series_name,
        b.distributor_id,
        b.distributor_name,
        b.total_historical_unconstrained_ad_avails,
        b.total_historical_constrained_ad_avails,
        b.historical_unfilled_ad_opportunities,
        -- b.net_ad_requests as net_ad_requests_old,
        CASE 
            WHEN site_section_name ILIKE '%FOX Weather%' 
            AND site_section_name ILIKE '%Partner%' 
            AND site_section_name NOT ILIKE '%Phase 1%' 
            THEN 
                CASE 
                WHEN TRIM(SPLIT_PART(site_section_name, ':', 3)) 
                    IN ('Xumo', 'Comcast', 'DIRECTV')
                THEN net_ad_requests * 0.7
                ELSE net_ad_requests
                END
            ELSE net_ad_requests
        END AS net_ad_requests

    FROM base b
    LEFT JOIN {catalog}.{silver_schema}.dim_freewheel_analytics_video_series vs
        ON b.series_id = vs.series_id
    LEFT JOIN {catalog}.{silver_schema}.dim_freewheel_analytics_video_group_custom vc
        ON b.video_id = vc.video_id
    LEFT JOIN {catalog}.{silver_schema}.freewheel_gsheet_map_series_to_show ss
        ON vs.series_name = ss.series_name
    LEFT JOIN (
    SELECT
        *
    FROM {catalog}.{silver_schema}.dim_freewheel_analytics_site
    WHERE (
        site_section_id
        , site_id
    ) NOT IN (
        SELECT
            dfas.site_section_id
            , -1
        FROM {catalog}.{silver_schema}.dim_freewheel_analytics_site dfas
        GROUP BY dfas.site_section_id
        HAVING COUNT(*) > 1
    )
) site
ON b.site_section_id = site.site_section_id  
)
SELECT *
FROM fnl
where event_date >='2021-07-01'
"""

# COMMAND ----------

capacity_df = spark.sql(capicity_sql)
# capacity_df.createOrReplaceTempView("capacity_temp")
# display(capacity_df)

# COMMAND ----------

capacity_df.write.format('delta')\
    .mode('overwrite')\
    .partitionBy('event_date')\
    .option('mergeSchema', 'true')\
    .option("partitionOverwriteMode", "dynamic")\
    .option('delta.enableDeletionVectors', 'false')\
    .option('delta.enableIcebergCompatV2', 'true')\
    .option('delta.universalFormat.enabledFormats', 'iceberg')\
    .option('delta.columnMapping.mode', 'name')\
    .saveAsTable(f'{catalog}.{silver_schema}.ft_freewheel_analytics_unified_capacity')

# capacity_df.write.format('delta')\
#     .mode('overwrite')\
#     .option('partitionOverwriteMode', 'dynamic')\
#     .saveAsTable(f'{catalog}.{silver_schema}.ft_freewheel_analytics_unified_capacity')
