# Databricks notebook source
from pyspark.sql import functions as F
from pyspark.sql import types as T
from datetime import datetime, timedelta

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW dim_placement AS
# MAGIC SELECT DISTINCT
# MAGIC     placement_id
# MAGIC     , placement_name
# MAGIC     , placement_start_timestamp_est
# MAGIC     , placement_end_timestamp_est
# MAGIC     , placement_budget_model
# MAGIC     , placement_booked_on_target_impression_goal
# MAGIC     , placement_impression_goal
# MAGIC     , placement_forced_over_delivery_percent
# MAGIC     , placement_demographic_on_target_calculation
# MAGIC FROM fox_bi_prod.silver_ads.dim_freewheel_analytics_placement

# COMMAND ----------

current_timestamp = datetime.now()

# COMMAND ----------

query = f"""
    SELECT
        ft.event_date
        , COALESCE(ft.advertiser_id, -1) AS advertiser_id
        , COALESCE(ft.advertiser_name, 'N/A') AS advertiser_name
        , COALESCE(ft.agency_id, -1) AS agency_id
        , COALESCE(ft.agency_name, 'N/A') AS agency_name
        , COALESCE(ft.campaign_id, -1) AS campaign_id
        , COALESCE(c.campaign_name, 'N/A') AS campaign_name
        , COALESCE(ft.insertion_order_id, -1) AS insertion_order_id
        , COALESCE(io.insertion_order_name, 'N/A') AS insertion_order_name
        , COALESCE(ft.placement_id, -1) AS placement_id
        , COALESCE(p.placement_name, 'N/A') AS placement_name
        , p.placement_start_timestamp_est
        , p.placement_end_timestamp_est
        , p.placement_budget_model
        , p.placement_booked_on_target_impression_goal
        , p.placement_impression_goal
        , p.placement_forced_over_delivery_percent
        , p.placement_demographic_on_target_calculation
        , SUM(ft.on_target_net_delivered_impressions) AS on_target_net_delivered_impressions
        , SUM(ft.gross_counted_ads) AS gross_counted_ads
        , DATE_FORMAT(CURRENT_TIMESTAMP(), 'yyyy-MM-dd') AS etl_load_date
        , CAST('{current_timestamp.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]}' AS TIMESTAMP) AS etl_load_timestamp
    FROM fox_bi_prod.bronze_ads.freewheel_analytics_demo_comps_correction ft
    LEFT JOIN fox_bi_prod.silver_ads.dim_freewheel_analytics_campaign c
    ON ft.campaign_id = c.campaign_id
    LEFT JOIN fox_bi_prod.silver_ads.dim_freewheel_analytics_insertion_order io
    ON ft.insertion_order_id = io.insertion_order_id
    LEFT JOIN dim_placement p
    ON ft.placement_id = p.placement_id
    GROUP BY
        ft.event_date
        , ft.advertiser_id
        , ft.advertiser_name
        , ft.agency_id
        , ft.agency_name
        , ft.campaign_id
        , c.campaign_name
        , ft.insertion_order_id
        , io.insertion_order_name
        , ft.placement_id
        , p.placement_name
        , p.placement_start_timestamp_est
        , p.placement_end_timestamp_est
        , p.placement_budget_model
        , p.placement_booked_on_target_impression_goal
        , p.placement_impression_goal
        , p.placement_forced_over_delivery_percent
        , p.placement_demographic_on_target_calculation
"""

# COMMAND ----------

ft_freewheel_demo_comp_correction = spark.sql(query)

# COMMAND ----------

ft_freewheel_demo_comp_correction.write.format('delta')\
    .mode('overwrite')\
    .option('partitionOverwriteMode', 'dynamic')\
    .saveAsTable('fox_bi_prod.silver_ads.ft_freewheel_demo_comp_daily_data')

# COMMAND ----------

# MAGIC %sql
# MAGIC select event_date, count(*) from fox_bi_prod.silver_ads.ft_freewheel_demo_comp_daily_data group by event_date order by event_date