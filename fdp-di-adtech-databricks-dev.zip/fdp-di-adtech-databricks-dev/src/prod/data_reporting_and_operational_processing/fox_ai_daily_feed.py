# Databricks notebook source
# COMMAND ----------

# MAGIC %run "/Workspace/Repos/adtech/fdp-di-adtech-databricks/src/prod/data_reporting_and_operational_processing/alert"

# COMMAND ----------

import io
from datetime import datetime
import pandas as pd
import boto3

# COMMAND ----------

def export_foxai_daily_feed(report_date: datetime) -> None:
    data_dir = f's3://{drop_bucket}/processed/'
    data_filename_1 = 'freewheel_AdOps_Reporting_Daily_Delivery.parquet'
    data_filename_2 = 'gam_AdOps_Reporting_Daily_Delivery.parquet'
    op_fw_adj_daily = pd.read_parquet(data_dir + data_filename_1, storage_options={'profile': aws_profile})
    op_gam_adj_daily = pd.read_parquet(data_dir + data_filename_2, storage_options={'profile': aws_profile})
    op_fw_adj_daily = pd.concat([op_fw_adj_daily, op_gam_adj_daily], ignore_index=True)
    op_fw_adj_daily = op_fw_adj_daily[['Sales Line Item ID', 'Impressions (3rd Party)']]
    op_fw_adj_daily['Date'] = report_date
    op_fw_adj_daily['Sales Line Item ID'] = op_fw_adj_daily['Sales Line Item ID'].astype(str)
    op_fw_adj_daily = op_fw_adj_daily[['Sales Line Item ID', 'Date', 'Impressions (3rd Party)']]
    with io.StringIO() as output:
        op_fw_adj_daily.to_csv(output, index=False, date_format='%Y-%m-%d')
        body = output.getvalue().encode('utf-8')

    session = boto3.Session(profile_name=aws_profile)
    s3 = session.client('s3')
    key = f'foxai_daily_feed/daily_feed_{report_date.strftime("%Y-%m-%d")}.csv'
    s3.put_object(
        Bucket=drop_bucket,
        Key=key,
        Body=body,
    )


def export_foxai_daily_lifetime_feed(report_date: datetime) -> None:
    global drop_bucket, fox_datahub_bucket
    session = boto3.Session(profile_name=aws_profile)
    drop_bucket_resource = session.resource('s3').Bucket(drop_bucket)
    objects = drop_bucket_resource.objects.filter(Prefix='foxai_daily_feed/')
    max_key = f'foxai_daily_feed/daily_feed_{report_date.strftime("%Y-%m-%d")}.csv'
    keys = []
    for object in objects:
        if object.key <= max_key:
            keys.append(object.key)
    dfs = []
    for key in keys:
        df = pd.read_csv(f's3://{drop_bucket}/{key}', dtype=str, storage_options={'profile': aws_profile})
        dfs.append(df)
    df = pd.concat(dfs)
    with io.StringIO() as output:
        df.to_csv(output, index=False, date_format='%Y-%m-%d')
        body = output.getvalue().encode('utf-8')

    s3_client = session.client('s3')
    s3_client.put_object(
        Bucket=drop_bucket,
        Body=body,
        Key=f'foxai_daily_lifetime_feed/daily_feed_{report_date.strftime("%Y-%m-%d")}.csv',
    )

    foxai_session = boto3.Session(profile_name='fox-datahub-prod')
    foxai_s3_client = foxai_session.client('s3')

    foxai_s3_client.put_object(
        Bucket=fox_datahub_bucket,
        Body=body,
        Key=f'fng/domestic/raw/drop-daily/daily_feed_{report_date.strftime("%Y%m%d")}.csv',
    )

# COMMAND ----------

def foxai_daily_feed(date: datetime, action: str) -> None:
    if action == 'export_daily_feed':
        export_foxai_daily_feed(date)
    elif action == 'export_lifetime_feed':
        export_foxai_daily_lifetime_feed(date)
    else:
        raise NotImplementedError(f'Action {action} not implemented')

# COMMAND ----------

if __name__ == '__main__':
    report_date = dbutils.widgets.get('date')
    global drop_bucket, fox_datahub_bucket, aws_profile
    drop_bucket = dbutils.widgets.get('drop_bucket')
    fox_datahub_bucket = 'fox-data-hub'
    aws_profile = dbutils.widgets.get('aws_profile')
    action = dbutils.widgets.get('action')

    def parse_date(date: str) -> bool:
        format = "%Y-%m-%d"
        try:
            res = bool(datetime.strptime(date, format))
        except ValueError:
            res = False
        return res

    assert parse_date(report_date), "Invalid date format, should be in YYYY-MM-DD format"
    assert action != '', "Invalid action, should be either export_daily_feed or export_lifetime_feed"

    try:
        foxai_daily_feed(datetime.strptime(report_date, "%Y-%m-%d"), action)
    except Exception as error:
        alert = Alert()
        alert.send('FoxAI Daily Feed', f'{type(error).__name__}: {error}')
        dbutils.notebook.exit(f'ERROR!!! - {error}')