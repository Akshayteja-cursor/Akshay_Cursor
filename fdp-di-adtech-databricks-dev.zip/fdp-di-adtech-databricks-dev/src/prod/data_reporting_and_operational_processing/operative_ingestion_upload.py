# Databricks notebook source
# COMMAND ----------

# MAGIC %run "/Workspace/Repos/adtech/fdp-di-adtech-databricks/src/prod/data_reporting_and_operational_processing/alert"

# COMMAND ----------

import boto3
from datetime import datetime
from dataclasses import dataclass
import json
import requests
from typing import List
import time

# COMMAND ----------

@dataclass
class AOSSecrets:
    access_key: str
    secret_key: str
    api_key: str
    username: str
    password: str

    @classmethod
    def from_secrets(cls, keys_secret_arn: str, creds_secret_arn: str) -> 'AOSSecrets':
        try:
            session = boto3.Session(profile_name=aws_profile)
            resp1 = session.client('secretsmanager').get_secret_value(SecretId=keys_secret_arn)
            secret1 = json.loads(resp1['SecretString'])
            resp2 = session.client('secretsmanager').get_secret_value(SecretId=creds_secret_arn)
            secret2 = json.loads(resp2['SecretString'])
            aos_secrets_cls = cls(access_key=secret1['access_key'], secret_key=secret1['secret_key'], api_key=secret2['apikey'], username=secret2['username'], password=secret2['password'])
            return aos_secrets_cls
        except:
            raise Exception(f'Could not load AOSSecrets from secrets {keys_secret_arn} and {creds_secret_arn}')

# COMMAND ----------

def generate_api_token(aos_secrets: AOSSecrets) -> str:
    token_url = "https://aos-prod-gw.operativeone.com:443/mayiservice/tenant/fox"
    payload = {
        'apiKey': aos_secrets.api_key,
        'userId': aos_secrets.username,
        'password': aos_secrets.password
    }
    response = requests.post(token_url, json=payload)
    token = json.loads(response.text)["token"]
    return token

def operative_ingestion_upload(aos_secrets: AOSSecrets, report_date: datetime, type: str, files: List[str]):
    token = generate_api_token(aos_secrets)

    # Copy files to aos bucket
    aos_session = boto3.Session(aws_access_key_id=aos_secrets.access_key, aws_secret_access_key=aos_secrets.secret_key, region_name='us-west-2')
    aos_s3_client = aos_session.client('s3')
    drop_session = boto3.Session(profile_name=aws_profile)
    drop_s3_client = drop_session.client('s3')

    drop_s3_prefix = 'operative_billing/'
    aos_s3_prefix = 'in/fox/delivery/drop/'

    url = "https://aos-prod-gw.operativeone.com/ingress/v2/" + aos_secrets.api_key + "/ingest/inlinePayload"
    headers = {
        'Accept':'application/json',
        'Content-Type':'application/json',
        'Authorization':'Bearer ' + token
    }
    payload = {
        "callBackUrl": "",
        "platform": "Digital",
        "entityDetail": {
            "entitySource": "PAYLOAD",
            "entityType": ""
        },
        "externalSystemId": "",
        "externalSystemName": "Adserver",
        "payload": "",
        "routingDetail": {
            "sourceSystemName": {
                "extSystemId": "",
                "extSystemName": "AOS"
            },
            "targetSystemName": {
                "extSystemId": "",
                "extSystemName": "Adserver"
            }
        },
        "parserDetail": None,
        "schemaDetail": {
            "keyFields": []
        }
    }

    for file in files:
        print('Copying file to aos - ', drop_s3_prefix + file)
        obj = drop_s3_client.get_object(Bucket=drop_bucket, Key=drop_s3_prefix + file)

        aos_s3_client.put_object(
            Body=obj['Body'].read(),
            Bucket=aos_bucket,
            Key=aos_s3_prefix+file
        )

        time.sleep(60) # Wait for the upload to complete and also helps stagger the api calls

        if type == '1p':
            delivery_source = 'xBZPaILuRJC21PVwSPQ31Q'
            entity_type = 'DeliveryPull'
        
        if type == '3p':
            delivery_source = 'sOq-I_FqS2qCItnIY6vrJQ'
            entity_type = 'ThirdPartyDeliveryPull'

        payload['entityDetail']['entityType'] = entity_type
        payload['payload'] = "{" + "\"startDate\":\"" + report_date.strftime("%Y-%m-%d") + "\",\"productionSystemId\":\"" + delivery_source + "\",\"file\":\"" + file + "\"}"

        print(payload)

        resp = requests.post(url, headers=headers, json=payload)
        print(resp.text)

# COMMAND ----------

if __name__ == '__main__':
    date = dbutils.widgets.get('date')
    type_of_billing = dbutils.widgets.get('type')
    global drop_bucket, aos_bucket, aws_profile
    drop_bucket = dbutils.widgets.get('drop_bucket')
    aos_bucket = dbutils.widgets.get('aos_bucket')
    aws_profile = dbutils.widgets.get('aws_profile')
    aos_keys_secret_arn = dbutils.widgets.get('aos_keys_secret_arn')
    aos_creds_secret_arn = dbutils.widgets.get('aos_creds_secret_arn')

    # n_files = 1
    # files = eval("{'files': ['Operative_3rdPartyDeliveryPull_2025-10-22.csv']}")['files']

    if type_of_billing == '1p':
        n_files = int(dbutils.jobs.taskValues.get(taskKey = f"operative_billing_{type_of_billing}", key = "n_files"))
        files = eval(dbutils.jobs.taskValues.get(taskKey = f"operative_billing_{type_of_billing}", key = "files"))['files']
    elif type_of_billing == '3p':
        n_files_freewheel = int(dbutils.jobs.taskValues.get(taskKey = f"operative_billing_{type_of_billing}", key = "n_files_freewheel"))
        files_freewheel = eval(dbutils.jobs.taskValues.get(taskKey = f"operative_billing_{type_of_billing}", key = "files_freewheel"))['files']
        n_files_gam = int(dbutils.jobs.taskValues.get(taskKey = f"operative_billing_{type_of_billing}", key = "n_files_gam"))
        files_gam = eval(dbutils.jobs.taskValues.get(taskKey = f"operative_billing_{type_of_billing}", key = "files_gam"))['files']
    
    def parse_date(date: str) -> bool:
        format = "%Y-%m-%d"
        try:
            res = bool(datetime.strptime(date, format))
        except ValueError:
            res = False
        return res

    assert parse_date(date), "Invalid date format, should be in YYYY-MM-DD format"
    if type_of_billing == '1p':
        assert n_files > 0, "No files found"
        assert len(files) == n_files, "Number of files does not match the number of files found"
    if type_of_billing == '3p':
        assert n_files_freewheel > 0, "No files found freewheel"
        assert len(files_freewheel) == n_files_freewheel, "Number of files does not match the number of files found for freewheel"
        assert n_files_gam > 0, "No files found gam"
        assert len(files_gam) == n_files_gam, "Number of files does not match the number of files found for gam"
    assert aos_creds_secret_arn != '', "Invalid aos_creds_secret_arn"
    assert aos_keys_secret_arn != '', "Invalid aos_keys_secret_arn"

    aos_secrets = AOSSecrets.from_secrets(aos_keys_secret_arn, aos_creds_secret_arn)

    try:
        if type_of_billing == '3p':
            time.sleep(100) # The api calls between 1p and 3p have to be staggered as instructed by Operative (2024/11/22)
            operative_ingestion_upload(aos_secrets, datetime.strptime(date, "%Y-%m-%d"), type_of_billing, files_freewheel)
            time.sleep(100)
            operative_ingestion_upload(aos_secrets, datetime.strptime(date, "%Y-%m-%d"), type_of_billing, files_gam)
        else:
            operative_ingestion_upload(aos_secrets, datetime.strptime(date, "%Y-%m-%d"), type_of_billing, files)
    except Exception as error:
        alert = Alert()
        alert.send('Operative Ingestion Upload', f'Failed for {type_of_billing}.\n{type(error).__name__}: {error}')
        dbutils.notebook.exit(f'ERROR!!! - {error}')