# Databricks notebook source
# MAGIC %sh
# MAGIC aws configure set region us-west-2 --profile databricks-cpe-prod
# MAGIC aws configure set s3.signature_version s3v4 --profile databricks-cpe-prod
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile databricks-cpe-prod
# MAGIC aws configure set role_arn arn:aws:iam::501246562447:role/data-infra-astro-bi-adtech-prod --profile databricks-cpe-prod
# MAGIC
# MAGIC aws configure set region us-west-2 --profile fox-datahub-prod
# MAGIC aws configure set s3.signature_version s3v4 --profile fox-datahub-prod
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile fox-datahub-prod
# MAGIC aws configure set role_arn arn:aws:iam::745717147149:role/fng-fox-datahub-prod-databricks-ec2-role --profile fox-datahub-prod