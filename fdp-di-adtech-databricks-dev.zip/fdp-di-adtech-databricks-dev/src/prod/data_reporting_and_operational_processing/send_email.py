# Databricks notebook source
# MAGIC %run "/Workspace/Repos/adtech/fdp-di-adtech-databricks/src/prod/data_reporting_and_operational_processing/alert"

# COMMAND ----------

import boto3
from email import encoders
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
import os
from datetime import datetime, timedelta
from dataclasses import dataclass
from typing import List, Optional, Any, cast
import time

# COMMAND ----------

def check_send_report(report: str, report_date: datetime) -> bool:
    if report == 'test':
        return True
    if report == "affiliates_delivery":
        return False # Disabled
    if report == "pacing":
        return True # All days
    if report == 'executive_summary':
        return True # All days
    if report == 'bar':
        return report_date.day == 5 # Only on 5th
    if report == 'adops_audit':
        return True # All days
    if report == 'news_pacing':
        if datetime.today().strftime("%A") == 'Monday': # Only on Monday
            return True
        return False
    if report == 'client_services_audit':
        cur = report_date.replace(day=1) # First Monday of the month
        while cur.weekday() != 0:
            cur += timedelta(days=1)
        return report_date == cur

# COMMAND ----------

class ReportMailInfo:
    from_email = 'adtech.prod@data.fox'
    reply_to_address = 'prajwal.harikishor@fox.com'
    key = ''
    info = {}
    report_mailing_lists = {
        "test" : {
            "key_format_string" : "reports/Pacing_Report_%Y%m%d.xlsx",
            "human_readable_name" : "drop test - news pacing report",
            "to" : [
                "prajwal.harikishor@fox.com",
            ],
            "cc" : [
                "alimaafroseshahul.hameed@fox.com",
            ]
        },

        "pacing" : {
            "key_format_string" : "reports/Pacing_Report_%Y%m%d.xlsx",
            "human_readable_name" : "pacing report",
            "to" : [
                "lisa.camacho@fox.com",
            ],
            "cc" : [
                "reaanna.embrador@fox.com",
                "yusuke.uetani@fox.com",
                "AdTech-APP@fox.com",
                "prajwal.harikishor@fox.com",
            ]
        },

        "news_pacing" : {
            "key_format_string" : "reports/News_Pacing_Report_%Y%m%d.xlsx",
            "human_readable_name" : "news pacing report",
            "to" : [
                "digitaltraffic@fox.com",
                "Paul.Braunger@fox.com",
            ],
            "cc" : [
                "reaanna.embrador@fox.com",
                "kevin.fuhrmann@fox.com",
                "AdTech-APP@fox.com",
                "prajwal.harikishor@fox.com",
            ],
        },

        "affiliates_delivery" : {
            "key_format_string" : "reports/Affiliates_Delivery_Report_%Y%m%d.xlsx",
            "human_readable_name" : "affiliates delivery report",
            "to" : [
                "lisa.camacho@fox.com",
            ],
            "cc" : [
                "prajwal.harikishor@fox.com",
                "AdTech-APP@fox.com",
            ],
        },

        "client_services_audit" : {
            "key_format_string" : "reports/Audit_Report_Client_Services_%d%b%Y.csv",
            "human_readable_name" : "client services audit report",
            "to" : [
                "martha.datlen@fox.com",
            ],
            "cc" : [
                "prajwal.harikishor@fox.com",
                "AdTech-APP@fox.com",
                "lisa.camacho@fox.com",
                "reaanna.embrador@fox.com",
            ],
        },

        "adops_audit" : {
            "key_format_string" : "reports/Audit_Report_Ad_Operations_%d%b%Y.csv",
            "human_readable_name" : "ad operations audit report",
            "to" : [
                "lisa.camacho@fox.com",
                "emerald.greene@fox.com",
                "shannon.o'brien@fox.com",
                "holly.bechtoldt@fox.com",
                "kimberly.dickens@fox.com",
            ],
            "cc" : [
                "reaanna.embrador@fox.com",
                "AdTech-APP@fox.com",
                "prajwal.harikishor@fox.com",
            ],
        },

        "bar" : {
            "key_format_string" : "reports/%B_%Y_Billing_Adjustment.xlsx",
            "human_readable_name" : "bar report",
            "to" : [
                "lisa.camacho@fox.com",
            ],
            "cc" : [
                "reaanna.embrador@fox.com",
                "yusuke.uetani@fox.com",
                "AdTech-APP@fox.com",
                "Kevin.Wakeman@fox.com",
                "Kristen.Passaro@fox.com",
                "Karthik.Aravind@fox.com",
                "prajwal.harikishor@fox.com",
                "jillian.benanti@fox.com",
                "Eric.Pollitzer@fox.com",
            ],
        },

        "executive_summary" : {
            "key_format_string" : "reports/Executive Summary_%Y%m%d.xlsx",
            "human_readable_name" : "executive summary report",
            "to" : [
                "jack.young@fox.com",
                "kristin.tortorello@fox.com",
                "Paul.Braunger@fox.com",
                "scott.kelly1@fox.com",
                "dade_validations_qa@foxanalyticsgroup.com",
                "dade_validations@foxanalyticsgroup.com",
                "salvatore.carosa@fox.com",
                "sarah.spitzer@fox.com",
                "Anitha.Mohanraj@fox.com",
                "Pradeep.Panneerselvam@fox.com",
                "Deepthi.Chunduru@fox.com",
                "ajanta.kumar@fox.com",
                "Mackenzie.Mucci@FOX.COM",
                "jason.moe@fox.com"
            ],
            "cc" : [
                "reaanna.embrador@fox.com",
                "lisa.camacho@fox.com",
                "prajwal.harikishor@fox.com",
                "AdTech-APP@fox.com",
                "alimaafroseshahul.hameed@fox.com",
            ],
        }
    }

    def __init__(self, report, report_date):
        self.info = self.report_mailing_lists[report]
        self.key = get_latest_report(report_date, self.info['key_format_string'])

    def get_file_name(self):
        return os.path.basename(self.key)
    
    def get_report_body(self, report_date):
        footer = f'<p>This is an automated email. Please direct any questions or concerns to <a href="mailto: {self.reply_to_address}">{self.reply_to_address}</a>.</p>'
        body_text = f"""<p>Hello,</p>

<p>Please find attached the {self.info['human_readable_name']}.</p>

{footer}
"""
        return MIMEText(body_text, 'html')

    def get_report_attachment(self):
        global drop_bucket
        session = boto3.Session(profile_name=aws_profile)
        s3 = session.client('s3')
        resp = s3.get_object(Bucket=drop_bucket, Key=self.key)
        return resp['Body'].read()

# COMMAND ----------

def get_latest_report(report_date: datetime, key_format_string: str):
    global drop_bucket
    session = boto3.Session(profile_name=aws_profile)
    s3 = session.client('s3')
    for delta in range(0, -7, -1):
        if 'Billing_Adjustment' in key_format_string:
            date = report_date + timedelta(days=delta*28)
        else:
            date = report_date + timedelta(days=delta)
        key = date.strftime(key_format_string)
        try:
            print(f'Trying object s3://{drop_bucket}/{key}')
            s3.head_object(Bucket=drop_bucket, Key=key)
            return key
        except s3.exceptions.ClientError as exc:
            if exc.response['Error']['Code'] == '404':
                continue
            raise
    raise RuntimeError('Could not find report')

# COMMAND ----------

def send_mail(report_name, report_date):
    
    report = ReportMailInfo(report_name, report_date)

    attachment_ready_html = []
    img_id = 0
    mime_images = []

    msg = MIMEMultipart()
    msg['Subject'] = report.info['human_readable_name'].title()
    msg['From'] = report.from_email
    msg['To'] = ", ".join(report.info['to'])
    msg['Cc'] = ", ".join(report.info['cc'])
    msg.attach(report.get_report_body(report_date))

    part = MIMEApplication(
        report.get_report_attachment(),
        Name=report.get_file_name(),
    )
    part['Content-Disposition'] = f'attachment; filename="{report.get_file_name()}"'
    msg.attach(part)

    session = boto3.Session(profile_name = aws_profile)
    ses = session.client('ses', region_name='us-west-2')
    ses.send_raw_email(
        Source=msg['From'],
        Destinations=list(set(report.info['to']).union(set(report.info['cc']))),
        RawMessage={'Data': msg.as_string()}
    )

    print('Email sent')

# COMMAND ----------

if __name__ == '__main__':
    time.sleep(30)
    global drop_bucket, aws_profile
    drop_bucket = dbutils.widgets.get('drop_bucket')
    aws_profile = dbutils.widgets.get('aws_profile')
    date = dbutils.widgets.get('date')
    report = dbutils.widgets.get('report')
    
    def parse_date(date: str) -> bool:
        format = "%Y-%m-%d"
        try:
            res = bool(datetime.strptime(date, format))
        except ValueError:
            res = False
        return res

    assert parse_date(date), "Invalid date format, should be in YYYY-MM-DD format"
    assert report != '', "Report name is required"

    if check_send_report(report, datetime.strptime(date, "%Y-%m-%d")):
        try:
            send_mail(report, datetime.strptime(date, "%Y-%m-%d"))
        except Exception as error:
            alert = Alert()
            alert.send('Send Email', f'Failed for {report}.\n{type(error).__name__}: {error}')
            dbutils.notebook.exit(f'ERROR!!! - {error}')
