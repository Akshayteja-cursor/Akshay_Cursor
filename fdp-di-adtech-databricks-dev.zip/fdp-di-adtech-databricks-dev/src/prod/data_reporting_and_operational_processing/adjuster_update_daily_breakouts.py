# Databricks notebook source
# COMMAND ----------

# MAGIC %run "/Workspace/Repos/adtech/fdp-di-adtech-databricks/src/prod/data_reporting_and_operational_processing/core"

# COMMAND ----------

# MAGIC %run "/Workspace/Repos/adtech/fdp-di-adtech-databricks/src/prod/data_reporting_and_operational_processing/alert"

# COMMAND ----------

from typing import Any
import logging
import json
import time
from datetime import datetime, timedelta
from dataclasses import dataclass
import requests
import boto3
import pandas as pd
import csv

# COMMAND ----------

@dataclass
class AdjusterCredentials:
    public_key: str
    private_key: str

    @classmethod
    def from_secret(cls, secret_arn: str) -> 'AdjusterCredentials':
        try:
            session = boto3.Session(profile_name=aws_profile)
            resp = session.client('secretsmanager').get_secret_value(SecretId=secret_arn)
            secret = json.loads(resp['SecretString'])
            ajuster_creds_cls = cls(public_key=secret['public_key'], private_key=secret['private_key'])
            return ajuster_creds_cls
        except:
            raise Exception(f'Could not load Adjuster credentials from secret {secret_arn}')

# COMMAND ----------

def run_report_by_id(adjuster_credentials: AdjusterCredentials, report_id: int, report_name: str) -> Any:
    report_run = f'https://pub.doubleverify.com/campaign-delivery/adjuster-api/reports/run/{report_id}?email=false'
    report_run_r = requests.get(report_run, auth=(adjuster_credentials.public_key, adjuster_credentials.private_key))

    if report_run_r.status_code == 200:
        report_status(
            adjuster_credentials,
            report_id,
            report_name,
        )
    else:
        raise requests.HTTPError(
            report_run_r.status_code,
            'Report could not be run',
            report_name,
        )

def report_status(adjuster_credentials: AdjusterCredentials, report_id: int, report_name: str) -> Any:
    report_run_status = -1
    while report_run_status != 3:
        report_status = f'https://pub.doubleverify.com/campaign-delivery/adjuster-api/reports/runs/{report_id}?count=1'
        report_status_r = requests.get(report_status, auth=(adjuster_credentials.public_key, adjuster_credentials.private_key))
        content = report_status_r.content.decode('utf8')
        print(f'report status = {content}')
        for report in report_status_r.json()['data']:
            report_run_id = report['runId']
            report_run_status = report['status']
        if report_run_status not in {0, 1, 3}:
            raise requests.HTTPError(
                report_run_status,
                'Report failed to complete run',
                report_name,
            )
        if report_run_status != 3:
            time.sleep(40)
    return report_run_id

def download_report(adjuster_credentials: AdjusterCredentials, report_run_id: Any, report_name: str, report_date: datetime) -> str:

    complete_report_s3_key = ''

    reports_to_key = {
        'pacing': 'Adjuster_Pacing_Base',
        'qtd': 'Adjuster_QTD',
        'mtd': 'Adjuster_MTD',
        'pm': 'Adjuster_Previous_Month',
        'daily': 'Adjuster_Daily',
        'daily_pm': 'Adjuster_Daily_PM',
        'daily_last_n': 'Adjuster_Daily_Last_N',
        'pacing_news': 'Adjuster_Pacing_News',
        'clicks_mtd': 'Adjuster_Clicks_MTD',
        'backfill_daily': 'Adjuster_Daily_',
    }

    report_s3_pfx = 'adjuster'
    report_name_base = reports_to_key[report_name]

    global drop_bucket
    s3_bucket = drop_bucket

    report_run_s3_keys = []
    multiple_reports = False

    if isinstance(report_run_id, list):
        multiple_reports = True
        for report_run_id_item in report_run_id:
            report_run_s3_key = download_report_by_run_id(adjuster_credentials, s3_bucket, report_s3_pfx, report_run_id_item, report_name_base, report_date, multiple_reports)

            report_run_s3_keys.append(report_run_s3_key)
            if report_name == 'daily_last_n' or report_name == 'backfill_daily':
                update_daily_breakouts(report_run_s3_key) # add data for date-range of each run to /adjuster/daily/dt={dt}/adjuster_daily_{dt}.parquet
    else:
        report_run_s3_key = download_report_by_run_id(adjuster_credentials, s3_bucket, report_s3_pfx, report_run_id, report_name_base, report_date, multiple_reports)

        report_run_s3_keys.append(report_run_s3_key)

    today = report_date.strftime('_%Y%m%d')

    if len(report_run_s3_keys)>1:
        session = boto3.Session(profile_name=aws_profile)
        s3_client = session.client('s3')

        s3_bucket = drop_bucket
        complete_report_s3_key = report_s3_pfx + '/' + report_name_base + '_files_info_' + today + '.txt'
        complete_report_s3_body = "\n".join(report_run_s3_keys)
        s3_client.put_object(
            Bucket=s3_bucket,
            Body=complete_report_s3_body,
            Key=complete_report_s3_key,
        )
    elif report_name_base == 'Adjuster_Clicks_MTD':
        complete_report_s3_key = report_s3_pfx + '/' + report_name_base + today + '.csv'
    else:
        complete_report_s3_key = report_s3_pfx + '/' + report_name_base + today + '.csv.gz'

    return complete_report_s3_key


def download_report_by_run_id(adjuster_credentials: AdjusterCredentials, s3_bucket: str, report_s3_pfx: str, report_run_id: Any, report_name_base: str, report_date: datetime, multiple_reports: bool) -> str:
    report_dl = f'https://pub.doubleverify.com/campaign-delivery/adjuster-api/reports/download/{report_run_id}'
    report_dl_r = requests.get(report_dl, auth=(adjuster_credentials.public_key, adjuster_credentials.private_key))

    today = report_date.strftime('_%Y%m%d')
    if multiple_reports:
        s3_key = report_s3_pfx + '/' + report_name_base + '_' + str(report_run_id) + today + '.csv.gz'
    elif report_name_base == 'Adjuster_Clicks_MTD':
        s3_key = report_s3_pfx + '/' + report_name_base + today + '.csv'
    else:
        s3_key = report_s3_pfx + '/' + report_name_base + today + '.csv.gz'

    session = boto3.Session(profile_name=aws_profile)
    s3_client = session.client('s3')
    s3_client.put_object(
        Bucket=s3_bucket,
        Body=report_dl_r.content,
        Key=s3_key,
    )
    return s3_key

def update_daily_breakouts(last_n_path: str) -> None:  # TODO: refactor this into "report classes". report classes will be used in each click module, which the dags call. point is centralize all functionality for a particular report/api/biz-fcn in one place, instead of them being scattered across all the click modules - makes it difficult to track and find
    global drop_bucket
    last_n = pd.read_csv(
        f's3://{drop_bucket}/{last_n_path}',
        dtype={
            'Ad Unit Id': 'float64',
            '3rd Party Server': 'object',
            'Impressions (3rd Party)': 'int64',
            '3rd Party Audible and Fully On-Screen'
            ' for Half of Duration Impressions': 'int64',
            'Impressions Analyzed': 'int64',
            '3rd Party Valid Impressions': 'int64',
            '3rd Party Valid, Audible and Fully On-Screen'
            ' for Half of the Duration Impressions (15 sec)': 'int64',
            '3rd Party Valid and Viewable Impressions': 'int64',
            'Line Item ID': 'object',
            'Line Item Name': 'object',
            'Advertiser ID': 'object',
            'Advertiser Name': 'object',
            'Order ID': 'float64',
            'Order Name': 'object',
            '3rd Party Creative Id': 'object',
            'Campaign Identifier': 'object',
        },
        skiprows=6,
        parse_dates=['Report Start Date', 'Report End Date'],
        encoding='utf-8',
        storage_options={'profile': aws_profile},
        quotechar='"',
        doublequote=True,
        quoting=csv.QUOTE_MINIMAL
    ).astype(
        {
            'Line Item ID': 'str',
            'Line Item Name': 'str',
            'Advertiser ID': 'str',
            'Advertiser Name': 'str',
            'Order Name': 'str',
            'Campaign Identifier': 'str',
            'Associated Line Item ID': 'str',
            '3rd Party Creative Id': 'str',
            'Creative Identifier': 'str',
        },
    ).replace({'nan': ''})
    last_n['Campaign Identifier'] = pd.to_numeric(last_n['Campaign Identifier'], errors='coerce')

    last_n.fillna(
        {
            'Ad Unit Id': -1,
            'Campaign Identifier': -1,
        },
        inplace=True
    )
    last_n['Ad Unit Id'] = last_n['Ad Unit Id'].astype('int64')

    last_n.rename(
        {
            'Line Item ID': '3P Line Item ID',
            'Line Item Name': '3P Line Item Name',
            'Advertiser ID': '3P Advertiser ID',
            'Advertiser Name': '3P Advertiser Name',
            'Order ID': '3P Order ID',
            'Order Name': '3P Order Name',
        },
        axis=1,
        inplace=True,
    )

    for date, df in last_n.groupby('Report Start Date'):
        dt = date.strftime('%Y-%m-%d')
        parquet_path = f's3://{drop_bucket}/adjuster/daily/dt={dt}/adjuster_daily_{dt}.parquet'

        df.to_parquet(parquet_path, index=False, compression='gzip', storage_options={'profile': aws_profile})
        print(f'Updated Daily partition dt={dt}')

def update_monthly_breakouts(month: datetime) -> None:
    global drop_bucket
    dataframes = []
    current_date = month
    while current_date.month == month.month:
        try:
            dt = current_date.strftime('%Y-%m-%d')

            parquet_for_current_date = f's3://{drop_bucket}/adjuster/daily/dt={dt}/adjuster_daily_{dt}.parquet'

            df = pd.read_parquet(parquet_for_current_date, storage_options={'profile': aws_profile})
            df['Campaign Identifier'] = pd.to_numeric(df['Campaign Identifier'], errors='coerce')
            df.fillna(
                {
                    'Ad Unit Id': -1,
                    'Campaign Identifier': -1,
                },
                inplace=True
            )

            dataframes.append(df)
        except FileNotFoundError:
            print('File not found - ' + f's3://{drop_bucket}/adjuster/daily/dt={dt}/adjuster_daily_{dt}.parquet')
            pass
        current_date += timedelta(days=1)

    if len(dataframes)>=1:
        dataframe = pd.concat(dataframes)
    else:
        return

    dt = month.strftime('%Y-%m')

    dataframe.loc[:, 'Clicks'] = 0
    dataframe.loc[:, 'Clicks (3rd Party)'] = 0

    parquet_for_current_month = f's3://{drop_bucket}/adjuster/monthly/dt={dt}/adjuster_monthly_{dt}.parquet'
    dataframe.to_parquet(parquet_for_current_month, index=False, compression='gzip', storage_options={'profile': aws_profile})
    print(f'Updated Monthly partition dt={dt}')

# COMMAND ----------

def run_report(adjuster_credentials: AdjusterCredentials, report_name: str) -> int:
    # Report IDs from Ad-juster API:
    # https://pub.doubleverify.com/campaign-delivery/adjuster-api/reports
    reports_to_id = {
        'pacing': 35450, #34220 old # 28779 old report, 29102 backup report
        'qtd': 30913,
        'mtd': 30914,
        'pm': 30912,
        'daily': 27951, 
        'daily_pm': 28831,  # 29103 backup report
        'daily_last_n': [35304, 35303], # 34359 old report (5 days - 0 offset)
        'pacing_news': 37016,
        'clicks_mtd': 37238,
        'backfill_daily': [37321, 37322]
    }
    report_id = reports_to_id[report_name]

    if isinstance(report_id, list):
        for report_id_item in report_id:
            run_report_by_id(adjuster_credentials, report_id_item, report_name)
    else:
        run_report_by_id(adjuster_credentials, report_id, report_name)

    return report_id

def pull_adjuster_report(adjuster_credentials: AdjusterCredentials, report_name: str, report_date: datetime, month: datetime) -> str:
    report_id = run_report(adjuster_credentials, report_name)
    
    if isinstance(report_id, list):
        report_run_id = []
        for report_id_item in report_id:
            report_run_id.append(report_status(adjuster_credentials, report_id_item, report_name))
    else:
        report_run_id = report_status(adjuster_credentials, report_id, report_name)

    s3_key = download_report(adjuster_credentials, report_run_id, report_name, report_date)
    update_monthly_breakouts(month)
    logging.info('File exported to S3: %s', s3_key)
    return s3_key

# COMMAND ----------

def adjuster(action: str, date: datetime, adjuster_credentials_secret_arn: str) -> None:
    adjuster_credentials = AdjusterCredentials.from_secret(adjuster_credentials_secret_arn)

    month_begin = date.replace(day=1)
    data_begin_date = date - timedelta(days=1)

    if data_begin_date < month_begin:
        out = pull_adjuster_report(adjuster_credentials, action, date, data_begin_date)
    else:
        out = pull_adjuster_report(adjuster_credentials, action, date, month_begin)
    
    write_xcom_value('Adjuster'+action, out)

# COMMAND ----------

if __name__ == '__main__':
    date = dbutils.widgets.get('date')
    global drop_bucket, aws_profile
    drop_bucket = dbutils.widgets.get('drop_bucket')
    aws_profile = dbutils.widgets.get('aws_profile')
    adjuster_credentials_secret_arn = dbutils.widgets.get('adjuster_credentials_secret_arn')
    action = dbutils.widgets.get('action')

    REPORT_CHOICES = [
        'status',
        'pacing',
        'qtd',
        'mtd',
        'pm',
        'daily',
        'daily_pm',
        'daily_last_n',
        'pacing_news',
        'clicks_mtd',
        'backfill_daily',
    ]

    def parse_date(date: str) -> bool:
        format = "%Y-%m-%d"
        try:
            res = bool(datetime.strptime(date, format))
        except ValueError:
            res = False
        return res

    assert parse_date(date), "Invalid date format, should be in YYYY-MM-DD format"
    assert action in REPORT_CHOICES, "Invalid action, should be one of {}".format(REPORT_CHOICES)
    assert adjuster_credentials_secret_arn != '', "Invalid adjuster_credentials_secret_arn"

    try:
        adjuster(action, datetime.strptime(date, "%Y-%m-%d"), adjuster_credentials_secret_arn)
    except Exception as error:
        alert = Alert()
        alert.send('Adjuster', f'Failed for action - {action}.\n{type(error).__name__}: {error}')
        dbutils.notebook.exit(f'ERROR!!! - {error}')

    # actions = ['qtd', 'mtd', 'pm', 'clicks_mtd', 'pacing', 'daily_last_n']
    # for action in actions:
    #     adjuster(action, datetime.strptime(date, "%Y-%m-%d"), adjuster_credentials_secret_arn)