# Databricks notebook source
# COMMAND ----------

# MAGIC %run "/Workspace/Repos/adtech/fdp-di-adtech-databricks/src/prod/data_reporting_and_operational_processing/alert"

# COMMAND ----------

import pandas as pd
from datetime import datetime, timedelta

# COMMAND ----------

def update_daily_breakouts(pg_file_path: str) -> None:
    global drop_bucket
    pg = pd.read_csv(
        f's3://{drop_bucket}/{pg_file_path}',
        usecols={
            'Deal ID',
            'Event Date',
            'Net Counted Ads',
        },
        dtype={
            'Deal ID': 'int64',
            'Net Counted Ads':'object',
        },
        parse_dates=['Event Date'],
        encoding='utf-8',
        storage_options={'profile': aws_profile}
    )

    pg['Net Counted Ads'] = pg['Net Counted Ads'].str.replace(',', '').fillna(0).astype('int64')

    pg_delivery_agg_dict = {
        'Deal ID': 'max',
        'Event Date': 'max',
        'Net Counted Ads': 'sum',
    }

    pg = pg.groupby(pg.index).aggregate(pg_delivery_agg_dict)

    for date, df in pg.groupby('Event Date'):
        dt = date.strftime('%Y-%m-%d')
        df.to_parquet(f's3://{drop_bucket}/programmatic/daily/dt={dt}/fw_pg_daily_{dt}.parquet', compression='gzip', storage_options={'profile': aws_profile})
        print(f'Updated partition dt={dt}')

# COMMAND ----------

def update_monthly_breakouts(month: datetime) -> None:
    global drop_bucket
    dataframes = []
    current_date = month

    while current_date.month == month.month:
        try:
            dt = current_date.strftime('%Y-%m-%d')

            file_for_date = f's3://{drop_bucket}/programmatic/daily/dt={dt}/fw_pg_daily_{dt}.parquet'

            df = pd.read_parquet(file_for_date, storage_options={'profile': aws_profile})
            dataframes.append(df)

        except FileNotFoundError:
            pass
        current_date += timedelta(days=1)

    if len(dataframes)>=1:
        month_df = pd.concat(dataframes)
    else:
        print('No files to update')
        return

    dt = month.strftime('%Y-%m')
    month_df.to_parquet(f's3://{drop_bucket}/programmatic/monthly/dt={dt}/fw_pg_monthly_{dt}.parquet', compression='gzip', storage_options={'profile': aws_profile})
    print(f'Updated partition dt={dt}')

# COMMAND ----------

def lifetime_delivery(month: datetime) -> None:
    dt = month.strftime('%Y-%m')
    global drop_bucket

    pg_lifetime = pd.read_parquet(f's3://{drop_bucket}/processed/FW_PG_Lifetime_Delivery.parquet', storage_options={'profile': aws_profile})

    pg_lifetime = pg_lifetime.set_index(['Deal ID', 'Event Date'])

    latest = pd.read_parquet(f's3://{drop_bucket}/programmatic/monthly/dt={dt}/fw_pg_monthly_{dt}.parquet', storage_options={'profile': aws_profile})

    latest = latest.set_index(['Deal ID', 'Event Date'])

    pg_lifetime_updated = pd.concat([pg_lifetime[~pg_lifetime.index.isin(latest.index)], latest])

    pg_lifetime_updated = pg_lifetime_updated.reset_index()

    pg_lifetime_updated.to_parquet(f's3://{drop_bucket}/processed/FW_PG_Lifetime_Delivery.parquet', storage_options={'profile': aws_profile})

    print(f'Updated data for {dt}')

# COMMAND ----------

if __name__ == '__main__':
    global drop_bucket, aws_profile
    drop_bucket = dbutils.widgets.get('drop_bucket')
    aws_profile = dbutils.widgets.get('aws_profile')
    date = dbutils.widgets.get('date')

    def parse_date(date: str) -> bool:
        format = "%Y-%m-%d"
        try:
            res = bool(datetime.strptime(date, format))
        except ValueError:
            res = False
        return res

    assert parse_date(date), "Invalid date format, should be in YYYY-MM-DD format"

    date = datetime.strptime(date, "%Y-%m-%d")

    pg_file_name = 'FW PG Delivery Report Daily Agg.csv'
    pg_file = 'freewheel/' + pg_file_name

    try:
        update_daily_breakouts(pg_file)

        month_begin = date.replace(day = 1)
        if month_begin > date - timedelta(days=5):
            update_monthly_breakouts((date - timedelta(days=5)).replace(day=1))
            lifetime_delivery((date - timedelta(days=5)).replace(day=1))
        else:
            update_monthly_breakouts(month_begin)
            lifetime_delivery(month_begin)
    except Exception as error:
        alert = Alert()
        alert.send('Freewheel PG Lifetime Delivery', f'{type(error).__name__}: {error}')
        dbutils.notebook.exit(f'ERROR!!! - {error}')