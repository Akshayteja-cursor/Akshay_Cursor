# Databricks notebook source
# COMMAND ----------

# MAGIC %run "/Workspace/Repos/adtech/fdp-di-adtech-databricks/src/prod/data_reporting_and_operational_processing/alert"

# COMMAND ----------

import pandas as pd
import boto3
from datetime import datetime, timedelta

# COMMAND ----------

def find_staq_file(report_date: datetime) -> str:
    session = boto3.Session(profile_name=aws_profile)
    s3 = session.client('s3')

    staq = 'STAQ_Magnite_PG_Orders_Last7_Last_7_Days_' + report_date.strftime('%Y-%m-%d')

    paginator = s3.get_paginator('list_objects_v2')
    page_iterator = paginator.paginate(Bucket=staq_bucket)

    for page in page_iterator:
        for obj in page.get('Contents', []):
            if staq in obj['Key']:
                return obj['Key']

# COMMAND ----------

def update_daily_breakouts(mg_file_path: str) -> None:
    global drop_bucket
    magnite = pd.read_csv(
        f's3://{staq_bucket}/{mg_file_path}',
        usecols={
            'Date',
            'Ad Source',
            'Deal ID',
            'Network',
            'Impressions',
            'Total Gross Revenue',
        },
        dtype={
            'Impressions': 'int64',
            'Total Gross Revenue': 'float64',
        },
        parse_dates=['Date'],
        storage_options={'profile': aws_profile}
    )

    mg_delivery_agg_dict = {
        'Date': 'max',
        'Ad Source': 'max',
        'Deal ID': 'max',
        'Network': 'max',
        'Impressions': 'sum',
        'Total Gross Revenue': 'sum',
    }

    magnite = magnite.groupby(magnite.index).aggregate(mg_delivery_agg_dict)

    for date, df in magnite.groupby('Date'):
        dt = date.strftime('%Y-%m-%d')
        df.to_parquet(f's3://{drop_bucket}/magnite/daily/dt={dt}/magnite_daily_{dt}.parquet', compression='gzip', storage_options={'profile': aws_profile})
        print(f'Updated partition dt={dt}')

def lifetime_delivery(date: datetime) -> None:
    global drop_bucket
    magnite_lifetime = pd.read_parquet(f's3://{drop_bucket}/processed/Magnite_Lifetime_Delivery.parquet', storage_options={'profile': aws_profile})
    magnite_lifetime = magnite_lifetime.set_index(['Date', 'Deal ID', 'Network'])

    updated = []

    for i in range(0,7):
        upd = date - timedelta(days=7-i)
        try:
            latest = pd.read_parquet(f's3://{drop_bucket}/magnite/daily/dt={upd.strftime("%Y-%m-%d")}/magnite_daily_{upd.strftime("%Y-%m-%d")}.parquet', storage_options={'profile': aws_profile})
            latest = latest.set_index(['Date', 'Deal ID', 'Network'])
            updated.append(latest)
        except FileNotFoundError as error:
            alert = Alert()
            alert.send('Magnite Lifetime Delivery', f'{type(error).__name__}: {error}', 'Warning')

    
    updated = pd.concat(updated)
    
    magnite_lifetime_updated = pd.concat([magnite_lifetime[~magnite_lifetime.index.isin(updated.index)], updated])
    magnite_lifetime_updated = magnite_lifetime_updated.reset_index()
    magnite_lifetime_updated.to_parquet(f's3://{drop_bucket}/processed/Magnite_Lifetime_Delivery.parquet', storage_options={'profile': aws_profile})
    print(f'Updated for date - ', date)

# COMMAND ----------

if __name__ == '__main__':
    report_date = dbutils.widgets.get('date')
    global drop_bucket, aws_profile, staq_bucket
    drop_bucket = dbutils.widgets.get('drop_bucket')
    aws_profile = dbutils.widgets.get('aws_profile')
    staq_bucket = dbutils.widgets.get('staq_bucket')

    def parse_date(date: str) -> bool:
        format = "%Y-%m-%d"
        try:
            res = bool(datetime.strptime(date, format))
        except ValueError:
            res = False
        return res

    assert parse_date(report_date), "Invalid date format, should be in YYYY-MM-DD format"

    try:
        staq_file = find_staq_file(datetime.strptime(report_date, "%Y-%m-%d"))
        update_daily_breakouts(staq_file)
        lifetime_delivery(datetime.strptime(report_date, "%Y-%m-%d"))
    except Exception as error:
        alert = Alert()
        alert.send('Magnite Lifetime Delivery', f'{type(error).__name__}: {error}')
        dbutils.notebook.exit(f'ERROR!!! - {error}')