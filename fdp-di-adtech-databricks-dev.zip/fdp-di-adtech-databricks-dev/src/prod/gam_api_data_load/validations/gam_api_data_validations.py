# Databricks notebook source
aws_profile=dbutils.widgets.get('aws_profile')
aws_arn=dbutils.widgets.get('aws_arn')
from_email=dbutils.widgets.get('from_email')

# COMMAND ----------

# make the variable available to shell
import os
os.environ["AWS_PROFILE_VAR"] = aws_profile
os.environ["AWS_ARN"] = aws_arn

# COMMAND ----------

# MAGIC %sh
# MAGIC aws configure set region us-west-2 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set s3.signature_version s3v4 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile $AWS_PROFILE_VAR
# MAGIC aws configure set role_arn $AWS_ARN --profile $AWS_PROFILE_VAR

# COMMAND ----------

from googleads import ad_manager, oauth2, errors
import boto3
import os
from datetime import datetime, timedelta
from dataclasses import dataclass
from typing import List, Optional, Any, cast
import json
import tempfile
from datetime import datetime, timedelta
import pytz
import time
import pandas as pd
from pyspark.sql import SparkSession
import pyspark.sql.types as T
import pyspark.sql.functions as F
from pyspark import SparkFiles
import io
from email import encoders
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication

# COMMAND ----------

global aws_profile, APPLICATION_NAME, NETWORK_CODE, cpe_s3_bucket
aws_profile = f'{aws_profile}'
APPLICATION_NAME = 'AdSales - GAM Data Ingestion'
NETWORK_CODE = 4145
cpe_s3_bucket = 'fox-fdp-bi-prod'
spark = SparkSession.builder.appName('GAM Report Data Load').getOrCreate()
spark.conf.set("spark.sql.session.timeZone", "UTC")

# COMMAND ----------

def get_ad_manager_client(secret_arn: str) -> Any:
    session = boto3.Session(profile_name=aws_profile)
    resp = session.client('secretsmanager').get_secret_value(SecretId=secret_arn)
    secret = json.loads(resp['SecretString'])

    with tempfile.NamedTemporaryFile(mode='w', delete=False) as secret_file:
        json.dump(secret, secret_file, indent=2)
        secret_file.close()

    oauth2_client = oauth2.GoogleServiceAccountClient(secret_file.name, oauth2.GetAPIScope('ad_manager'))
    os.unlink(secret_file.name)
    ad_manager_client = ad_manager.AdManagerClient(oauth2_client, APPLICATION_NAME, NETWORK_CODE)

    return ad_manager_client

# COMMAND ----------

def format_to_datetime(date_dict: Any) -> datetime:
    return datetime(
        date_dict['date']['year'],
        date_dict['date']['month'],
        date_dict['date']['day'],
        date_dict['hour'],
        date_dict['minute'],
        date_dict['second'],
        tzinfo=pytz.timezone(date_dict['timeZoneId'])
    )

def format_datetime_to_obj(datetime_obj: Any) -> Any:
    obj = {}
    obj['year'] = datetime_obj.year
    obj['month'] = datetime_obj.month
    obj['day'] = datetime_obj.day
    return obj

def generate_processing_dates(start_date: datetime, end_date: datetime, step_size: int) -> list:
    processing_dates = []

    batch_start_date = start_date
    while batch_start_date <= end_date:
        batch_end_date = batch_start_date + timedelta(days=step_size - 1)
        if batch_end_date <= end_date:
            processing_dates.append((batch_start_date, batch_end_date))
        else:
            processing_dates.append((batch_start_date, end_date))
            break
        batch_start_date += timedelta(days=step_size)

    return processing_dates

def build_report_query(dimensions: list, columns: list, dimensionAttributes: list, start_date: datetime, end_date: datetime) -> Any:
    baseReportQuery = {
        'dimensions': [],
        'adUnitView': 'FLAT',
        'columns': [],
        'dimensionAttributes': [],
        'customFieldIds': [],
        'cmsMetadataKeyIds': [],
        'customDimensionKeyIds': [],
        'startDate': {},
        'endDate': {},
        'dateRangeType': 'CUSTOM_DATE',
        'statement': None,
        'reportCurrency': 'USD',
        'timeZoneType': 'PUBLISHER'
    }

    report_query = baseReportQuery
    report_query['dimensions'] = dimensions
    report_query['columns'] = columns
    report_query['dimensionAttributes'] = dimensionAttributes
    report_query['startDate'] = format_datetime_to_obj(start_date)
    report_query['endDate'] = format_datetime_to_obj(end_date)
    return report_query


# COMMAND ----------

def format_report(report_data: Any, report_type: str) -> Any:
    if report_type == 'GAM API Daily Data Validation Report':
        format_columns = {
            'Dimension.DATE': ('event_date', T.DateType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS': ('total_line_item_level_impressions', T.LongType()),
            'Column.VIDEO_ERRORS_VAST_ERROR_303_COUNT': ('video_errors_vast_error_303_count', T.LongType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_CPM_AND_CPC_REVENUE': ('total_line_item_level_cpm_and_cpc_revenue', T.LongType()),
            'Column.TOTAL_UNMATCHED_AD_REQUESTS': ('total_ad_unit_level_unmatched_ad_requests', T.LongType()),
        }
        select_cols = [
            'event_date',
            'total_line_item_level_impressions',
            'video_errors_vast_error_303_count',
            'total_line_item_level_cpm_and_cpc_revenue',
            'total_ad_unit_level_unmatched_ad_requests',
        ]

    if report_type == 'GAM API Monthly Data Validation Report':
        format_columns = {
            'Dimension.MONTH_AND_YEAR': ('event_month', T.DateType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS': ('total_line_item_level_impressions', T.LongType()),
            'Column.VIDEO_ERRORS_VAST_ERROR_303_COUNT': ('video_errors_vast_error_303_count', T.LongType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_CPM_AND_CPC_REVENUE': ('total_line_item_level_cpm_and_cpc_revenue', T.LongType()),
            'Column.TOTAL_UNMATCHED_AD_REQUESTS': ('total_ad_unit_level_unmatched_ad_requests', T.LongType()),
            'Column.AD_SERVER_RESPONSES_SERVED': ('ad_unit_level_ad_server_responses_served', T.LongType()),
            'Column.TOTAL_AD_REQUESTS': ('total_ad_unit_level_ad_requests', T.LongType()),
            'Column.TOTAL_RESPONSES_SERVED': ('total_ad_unit_level_responses_served', T.LongType()),
            'Column.VIDEO_VIEWERSHIP_TOTAL_ERROR_COUNT': ('video_ad_unit_level_viewership_total_error_count', T.LongType())
        }
        select_cols = [
            'event_month',
            'total_line_item_level_impressions',
            'video_errors_vast_error_303_count',
            'total_line_item_level_cpm_and_cpc_revenue',
            'total_ad_unit_level_unmatched_ad_requests',
            'ad_unit_level_ad_server_responses_served',
            'total_ad_unit_level_ad_requests',
            'total_ad_unit_level_responses_served',
            'video_ad_unit_level_viewership_total_error_count'
        ]

    for k, v in format_columns.items():
        report_data = report_data.withColumnRenamed(k, v[0])
        report_data = report_data.withColumn(v[0], F.col(v[0]).cast(v[1]))

    report_data = report_data.select(select_cols)

    return report_data

# COMMAND ----------

class ReportMailInfo:
    from_email = f'{from_email}'
    reply_to_address = 'data_adtech@fox.com'
    key = ''
    info = {}
    report_mailing_lists = {
        "GAM Validation Report 1" : {
            "key_format_string" : "gam_analytics/AD Tech GAM Daily Data Validation Report_%d%b%Y.csv",
            "human_readable_name" : "Prod - ad tech GAM analytics daily data validation report",
            "to" : [
                "data_adtech@fox.com",
                "Pradeep.Panneerselvam@fox.com",
                "Anitha.Mohanraj@fox.com",
                "akshay.dalvi@fox.com",
                "yogesh.nageswararao@fox.com",
            ],
            "cc" : [
                "alimaafroseshahul.hameed@fox.com",
                "Ramesh.Madepalli@fox.com",
            ]
        },

        "GAM Validation Report 2" : {
            "key_format_string" : "gam_analytics/AD Tech GAM Monthly Data Validation Report_%d%b%Y.csv",
            "human_readable_name" : "Prod - ad tech GAM analytics monthly data validation report",
            "to" : [
                "data_adtech@fox.com",
                "Pradeep.Panneerselvam@fox.com",
                "Anitha.Mohanraj@fox.com",
                "akshay.dalvi@fox.com",
                "yogesh.nageswararao@fox.com",
            ],
            "cc" : [
                "alimaafroseshahul.hameed@fox.com",
                "Ramesh.Madepalli@fox.com",
            ]
        }
    }

    def __init__(self, report, report_date):
        self.info = self.report_mailing_lists[report]
        self.key = get_latest_report(report_date, self.info['key_format_string'])

    def get_file_name(self):
        return os.path.basename(self.key)
    
    def get_report_body(self, report_date):
        footer = f'<p>This is an automated email. Please direct any questions or concerns to <a href="mailto: {self.reply_to_address}">{self.reply_to_address}</a>.</p>'
        body_text = f"""<p>Hello,</p>

<p>Please find attached the {self.info['human_readable_name']}.</p>

{footer}
"""
        return MIMEText(body_text, 'html')

    def get_report_attachment(self):
        session = boto3.Session(profile_name=aws_profile)
        s3 = session.client('s3')
        resp = s3.get_object(Bucket=cpe_s3_bucket, Key=self.key)
        return resp['Body'].read()

# COMMAND ----------

def get_latest_report(report_date: datetime, key_format_string: str):
    session = boto3.Session(profile_name=aws_profile)
    s3 = session.client('s3')
    for delta in range(0, -7, -1):
        date = report_date + timedelta(days=delta)
        key = date.strftime(key_format_string)
        try:
            print(f'Trying object s3://{cpe_s3_bucket}/{key}')
            s3.head_object(Bucket=cpe_s3_bucket, Key=key)
            return key
        except s3.exceptions.ClientError as exc:
            if exc.response['Error']['Code'] == '404':
                continue
            raise
    raise RuntimeError('Could not find report')

# COMMAND ----------

def send_mail(report_name, report_date):
    
    report = ReportMailInfo(report_name, report_date)

    attachment_ready_html = []
    img_id = 0
    mime_images = []

    msg = MIMEMultipart()
    msg['Subject'] = report.info['human_readable_name'].title()
    msg['From'] = report.from_email
    msg['To'] = ", ".join(report.info['to'])
    msg['Cc'] = ", ".join(report.info['cc'])
    msg.attach(report.get_report_body(report_date))

    part = MIMEApplication(
        report.get_report_attachment(),
        Name=report.get_file_name(),
    )
    part['Content-Disposition'] = f'attachment; filename="{report.get_file_name()}"'
    msg.attach(part)

    session = boto3.Session(profile_name = aws_profile)
    ses = session.client('ses', region_name='us-west-2')
    ses.send_raw_email(
        Source=msg['From'],
        Destinations=list(set(report.info['to']).union(set(report.info['cc']))),
        RawMessage={'Data': msg.as_string()}
    )

    print('Email sent')

# COMMAND ----------

if __name__ == '__main__':
    gam_service_account_creds_secret_arn = dbutils.widgets.get('gam_service_account_creds_secret_arn')
    gam_api_version = dbutils.widgets.get('gam_api_version')

    client = get_ad_manager_client(secret_arn=gam_service_account_creds_secret_arn)
    timezone = pytz.timezone("UTC")
    event_start_date = datetime.strptime(dbutils.widgets.get('event_start_date'), '%Y-%m-%d').replace(tzinfo=timezone)
    event_end_date = datetime.strptime(dbutils.widgets.get('event_end_date'), '%Y-%m-%d').replace(tzinfo=timezone)

    process_days = (event_end_date-event_start_date).days
    processing_dates = generate_processing_dates(event_start_date, event_end_date, 15)

    # GAM API Daily Data Validation Report
    print('GAM API Daily Data Validation Report')
    for i, batch in enumerate(processing_dates):
        start_date, end_date = batch
        print(f"Processing {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}, batch - {i}", end=' ')
        report_service = client.GetService('ReportService', version=gam_api_version)
        report_query = build_report_query(
            dimensions = [
                'DATE',
            ],
            columns = [
                'TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS',
                'VIDEO_ERRORS_VAST_ERROR_303_COUNT',
                'TOTAL_LINE_ITEM_LEVEL_CPM_AND_CPC_REVENUE',
                'TOTAL_UNMATCHED_AD_REQUESTS',
            ],
            dimensionAttributes = [],
            start_date = start_date,
            end_date = end_date
        )
        report_job = report_service.runReportJob({'reportQuery': report_query})

        while True:
            status = report_service.getReportJobStatus(report_job['id'])
            if status == 'COMPLETED':
                break
            elif status == 'FAILED':
                break
            else:
                time.sleep(10)

        if status == 'COMPLETED':
            print('Downloading...', end=' ')
            report_download_url = report_service.getReportDownloadURL(report_job['id'], 'CSV_DUMP')
            report_data = spark.createDataFrame(pd.read_csv(report_download_url, compression='gzip'))
            if i == 0:
                final_df = format_report(report_data, 'GAM API Daily Data Validation Report')
            else:
                final_df = final_df.union(format_report(report_data, 'GAM API Daily Data Validation Report'))
            print('Completed')
        else:
            raise Exception('Report job failed')

    table_query_1 = f"""
        SELECT
            ad_date as event_date
            , SUM(total_impressions) AS total_impressions
            , SUM(vast_error_303_count) AS vast_error_303_count
            , SUM(total_cpm_and_cpc_revenue) AS total_cpm_and_cpc_revenue
        FROM fox_bi_prod.silver_ads.ft_gam_summary_daily_data
        WHERE ad_date >= '{event_start_date}' AND ad_date <= '{event_end_date}'
        GROUP BY 1
    """
    table_df_1 = spark.sql(table_query_1)

    table_query_2 = f"""
        SELECT
            event_date
            , SUM(total_unmatched_ad_requests) AS total_unmatched_ad_requests
        FROM(
            SELECT DISTINCT
                ad_date as event_date
                , ad_unit_id
                , country_id
                , total_unmatched_ad_requests
            FROM fox_bi_prod.silver_ads.ft_gam_summary_daily_data
            WHERE ad_date >= '{event_start_date}' AND ad_date <= '{event_end_date}'
        )
        GROUP BY 1
    """

    table_df_2 = spark.sql(table_query_2)

    table_df = table_df_1.join(table_df_2, on='event_date', how='left')
    
    validation_df = table_df.join(final_df, on='event_date', how='left')
    validation_df = validation_df.withColumn('Impressions Variance %',\
        F.round((F.col('total_impressions') - F.col('total_line_item_level_impressions'))/F.col('total_line_item_level_impressions')*100, 3)
    )
    validation_df = validation_df.withColumn('Vast Errors 303 Variance %',\
        F.round((F.col('vast_error_303_count') - F.col('video_errors_vast_error_303_count'))/F.col('video_errors_vast_error_303_count')*100, 3)
    )
    validation_df = validation_df.withColumn('Revenue Variance %',\
        F.round((F.col('total_cpm_and_cpc_revenue') - F.col('total_line_item_level_cpm_and_cpc_revenue'))/F.col('total_line_item_level_cpm_and_cpc_revenue')*100, 3)
    )
    validation_df = validation_df.withColumn('Unmatched Ad Requests Variance %',\
        F.round((F.col('total_unmatched_ad_requests') - F.col('total_ad_unit_level_unmatched_ad_requests'))/F.col('total_ad_unit_level_unmatched_ad_requests')*100, 3))
    validation_df = validation_df.sort('event_date')

    with io.StringIO() as output:
        validation_df.toPandas().to_csv(output, index=False)
        validation_data = output.getvalue()

    report_name = 'AD Tech GAM Daily Data Validation Report_' + datetime.today().strftime('%d%b%Y') + '.csv'
    session = boto3.Session(profile_name=aws_profile)
    s3_client = session.client('s3')
    s3_bucket = cpe_s3_bucket
    s3_key = 'gam_analytics/' + report_name
    s3_client.put_object(
        Bucket=s3_bucket,
        Body=validation_data.encode('utf-8'),
        Key=s3_key,
    )

    send_mail('GAM Validation Report 1', datetime.today())

    # GAM API Monthly Data Validation Report
    print('GAM API Monthly Data Validation Report')
    # Load configuration values
    current_date = datetime.strptime(dbutils.widgets.get("current_date"), '%Y-%m-%d')

    def _is_current_month(current_date):
        today = datetime.today()
        if current_date.month == today.month and current_date.year == today.year:
            return True
        else:
            return False
    
    is_current_month = _is_current_month(current_date)

    if current_date.day <= 5 and is_current_month:
        event_start_date = (current_date - timedelta(days=current_date.day)).replace(day=1).replace(tzinfo=timezone)
        event_end_date = (current_date - timedelta(days=current_date.day)).replace(tzinfo=timezone)
    elif current_date.day == 15 and is_current_month:
        event_start_date = (current_date - timedelta(days=current_date.day)).replace(day=1).replace(tzinfo=timezone)
        event_end_date = (current_date - timedelta(days=current_date.day)).replace(tzinfo=timezone)
    elif not is_current_month:
        event_start_date = current_date.replace(day=1).replace(tzinfo=timezone)
        next_month = current_date.replace(day=28) + timedelta(days=4)
        event_end_date = (next_month - timedelta(days=next_month.day)).replace(tzinfo=timezone)
    else:
        event_start_date = current_date.replace(day=1).replace(tzinfo=timezone)
        event_end_date = current_date.replace(tzinfo=timezone)
    
    processing_dates = [(event_start_date, event_end_date)]

    for i, batch in enumerate(processing_dates):
        start_date, end_date = batch
        print(f"Processing {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}, batch - {i}", end=' ')
        report_service = client.GetService('ReportService', version=gam_api_version)
        report_query = build_report_query(
            dimensions = [
                'MONTH_AND_YEAR',
            ],
            columns = [
                'TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS',
                'VIDEO_ERRORS_VAST_ERROR_303_COUNT',
                'TOTAL_LINE_ITEM_LEVEL_CPM_AND_CPC_REVENUE',
                'TOTAL_UNMATCHED_AD_REQUESTS',
                'AD_SERVER_RESPONSES_SERVED',
                'TOTAL_AD_REQUESTS',
                'TOTAL_RESPONSES_SERVED',
                'VIDEO_VIEWERSHIP_TOTAL_ERROR_COUNT'
            ],
            dimensionAttributes = [],
            start_date = start_date,
            end_date = end_date
        )
        report_job = report_service.runReportJob({'reportQuery': report_query})

        while True:
            status = report_service.getReportJobStatus(report_job['id'])
            if status == 'COMPLETED':
                break
            elif status == 'FAILED':
                break
            else:
                time.sleep(10)

        if status == 'COMPLETED':
            print('Downloading...', end=' ')
            report_download_url = report_service.getReportDownloadURL(report_job['id'], 'CSV_DUMP')
            report_data = spark.createDataFrame(pd.read_csv(report_download_url, compression='gzip'))
            if i == 0:
                final_df = format_report(report_data, 'GAM API Monthly Data Validation Report')
            else:
                final_df = final_df.union(format_report(report_data, 'GAM API Monthly Data Validation Report'))
            print('Completed')
        else:
            raise Exception('Report job failed')

    table_query_1 = f"""
        SELECT
            ad_month_start_date as event_month
            , SUM(total_impressions) AS total_impressions
            , SUM(vast_error_303_count) AS vast_error_303_count
            , SUM(total_cpm_and_cpc_revenue) AS total_cpm_and_cpc_revenue
        FROM fox_bi_prod.silver_ads.ft_gam_summary_monthly_data
        WHERE ad_month_start_date = '{event_start_date.strftime('%Y-%m-%d')}'
        GROUP BY 1
    """
    table_df_1 = spark.sql(table_query_1)

    table_query_2 = f"""
        SELECT
            ad_month_start_date as event_month
            , SUM(total_ad_requests) AS total_ad_requests
            , SUM(total_responses_served) AS total_responses_served
            , SUM(total_unmatched_ad_requests) AS total_unmatched_ad_requests
            , SUM(ad_server_responses_served) AS ad_server_responses_served
            , SUM(video_viewership_total_error_count) AS video_viewership_total_error_count
            FROM (
                SELECT DISTINCT
                    ad_month_start_date
                    , ad_unit_id
                    , requested_ad_sizes
                    , country_id
                    , country_name
                    , total_unmatched_ad_requests
                    , ad_server_responses_served
                    , total_ad_requests
                    , total_responses_served
                    , video_viewership_total_error_count
                FROM fox_bi_prod.silver_ads.ft_gam_summary_monthly_data
                WHERE ad_month_start_date = '{event_start_date.strftime('%Y-%m-%d')}'
            )
        GROUP BY ad_month_start_date
    """

    table_df_2 = spark.sql(table_query_2)

    table_df = table_df_1.join(table_df_2, on='event_month', how='left')
    
    validation_df = table_df.join(final_df, on='event_month', how='left')
    validation_df = validation_df.withColumn('Impressions Variance %',\
        F.round((F.col('total_impressions') - F.col('total_line_item_level_impressions'))/F.col('total_line_item_level_impressions')*100, 3)
    )
    validation_df = validation_df.withColumn('Vast Errors 303 Variance %',\
        F.round((F.col('vast_error_303_count') - F.col('video_errors_vast_error_303_count'))/F.col('video_errors_vast_error_303_count')*100, 3)
    )
    validation_df = validation_df.withColumn('Revenue Variance %',\
        F.round((F.col('total_cpm_and_cpc_revenue') - F.col('total_line_item_level_cpm_and_cpc_revenue'))/F.col('total_line_item_level_cpm_and_cpc_revenue')*100, 3)
    )
    validation_df = validation_df.withColumn('Unmatched Ad Requests Variance %',\
        F.round((F.col('total_unmatched_ad_requests') - F.col('total_ad_unit_level_unmatched_ad_requests'))/F.col('total_ad_unit_level_unmatched_ad_requests')*100, 3))
    validation_df = validation_df.withColumn('Ad Server Responses Served Variance %',\
        F.round((F.col('ad_server_responses_served') - F.col('ad_unit_level_ad_server_responses_served'))/F.col('ad_unit_level_ad_server_responses_served')*100, 3)
    )
    validation_df = validation_df.withColumn('Ad Requests Variance %',\
        F.round((F.col('total_ad_requests') - F.col('total_ad_unit_level_ad_requests'))/F.col('total_ad_unit_level_ad_requests')*100, 3)
    )
    validation_df = validation_df.withColumn('Responses Served Variance %',\
        F.round((F.col('total_responses_served') - F.col('total_ad_unit_level_responses_served'))/F.col('total_ad_unit_level_responses_served')*100, 3)
    )
    validation_df = validation_df.withColumn('Video Viewership Total Error Count Variance %',\
        F.round((F.col('video_viewership_total_error_count') - F.col('video_ad_unit_level_viewership_total_error_count'))/F.col('video_ad_unit_level_viewership_total_error_count')*100, 3)
    )

    with io.StringIO() as output:
        validation_df.toPandas().to_csv(output, index=False)
        validation_data = output.getvalue()

    report_name = 'AD Tech GAM Monthly Data Validation Report_' + datetime.today().strftime('%d%b%Y') + '.csv'
    session = boto3.Session(profile_name=aws_profile)
    s3_client = session.client('s3')
    s3_bucket = cpe_s3_bucket
    s3_key = 'gam_analytics/' + report_name
    s3_client.put_object(
        Bucket=s3_bucket,
        Body=validation_data.encode('utf-8'),
        Key=s3_key,
    )

    send_mail('GAM Validation Report 2', datetime.today())