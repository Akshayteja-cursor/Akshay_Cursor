# Databricks notebook source
from pyspark.sql import functions as F
from pyspark.sql import types as T
from datetime import datetime, timedelta

# COMMAND ----------

# Load configuration values
current_date = datetime.strptime(dbutils.widgets.get("current_date"), '%Y-%m-%d')

def _is_current_month(current_date):
    today = datetime.today()
    if current_date.month == today.month and current_date.year == today.year:
        return True
    else:
        return False

is_current_month = _is_current_month(current_date)

if current_date.day <= 5 and is_current_month:
    event_start_date = (current_date - timedelta(days=current_date.day)).replace(day=1).strftime('%Y-%m-%d')
    event_end_date = (current_date - timedelta(days=current_date.day)).strftime('%Y-%m-%d')
elif current_date.day == 15 and is_current_month:
    event_start_date = (current_date - timedelta(days=current_date.day)).replace(day=1).strftime('%Y-%m-%d')
    event_end_date = (current_date - timedelta(days=current_date.day)).strftime('%Y-%m-%d')
elif not is_current_month:
    event_start_date = current_date.replace(day=1).strftime('%Y-%m-%d')
    next_month = current_date.replace(day=28) + timedelta(days=4)
    event_end_date = (next_month - timedelta(days=next_month.day)).strftime('%Y-%m-%d')
else:
    event_start_date = current_date.replace(day=1).strftime('%Y-%m-%d')
    next_month = current_date.replace(day=28) + timedelta(days=4)
    event_end_date = (next_month - timedelta(days=next_month.day)).strftime('%Y-%m-%d')

print(f"Processing: {event_start_date} to {event_end_date}")

# COMMAND ----------

query = f"""
    SELECT
        /*+ BROADCAST(adv, li, or, au) */
        DISTINCT
        summary_impressions.line_item_id
        , li.line_item_name
        , li.line_item_start_timestamp
        , li.line_item_start_timestamp_timezone
        , li.line_item_start_timestamp_type
        , li.line_item_end_timestamp
        , li.line_item_end_timestamp_timezone
        , li.line_item_type
        , li.contracted_units_bought_qty
        , li.is_unlimited_end_datetime
        , li.is_skippable_ad_type
        , li.line_item_priority
        , li.value_cost_per_unit_currency_code
        , li.value_cost_per_unit_micro_amt
        , li.delivery_indicator_expected_delivery_percentage
        , li.delivery_indicator_actual_delivery_percentage
        , li.delivery_data
        , li.budget_currency_code
        , li.budget_micro_amt
        , li.line_item_status
        , li.is_missing_creatives
        , li.primary_goal_type
        , li.primary_goal_unit_type
        , li.primary_goal_units_qty
        , summary_impressions.advertiser_id
        , adv.advertiser_name
        , adv.advertiser_type
        , adv.advertiser_credit_status
        , adv.advertiser_external_id
        , mab.brand_supported
        , COALESCE(summary_impressions.country_id, summary_unmatched_ad_requests.country_id) AS country_id
        , COALESCE(summary_impressions.country_name, summary_unmatched_ad_requests.country_name) as country_name
        , COALESCE(summary_impressions.country_name, summary_unmatched_ad_requests.country_name) as location
        , summary_impressions.programmatic_channel_name
        , li.order_id
        , or.order_name
        , or.order_start_timestamp
        , or.order_start_timestamp_timezone
        , or.order_end_timestamp
        , or.order_end_timestamp_timezone
        , or.order_status
        , or.salesperson_id
        , or.salesperson_name
        , COALESCE(summary_impressions.ad_unit_id, summary_unmatched_ad_requests.ad_unit_id) AS ad_unit_id
        , au.ad_unit_id_level_1
        , au.ad_unit_id_level_2
        , au.ad_unit_id_level_3
        , au.ad_unit_id_level_4
        , au.ad_unit_id_level_5
        , au.ad_unit_name
        , au.ad_unit_name_level_1
        , au.ad_unit_name_level_2
        , au.ad_unit_name_level_3
        , au.ad_unit_name_level_4
        , au.ad_unit_name_level_5
        , au.status AS ad_unit_status
        , au.has_children
        , au.is_native
        , au.is_explicitly_targeted
        , au.is_fluid
        , au.is_interstitial
        , au.is_weather
        , au.is_weather_fast
        , au.ad_category_name
        , au.ad_detail_name
        , au.ad_format_name
        , au.ad_unit_code
        , au.description
        , au.distributor_name
        , au.page_type_name
        , au.parent_id
        , au.platform_name
        , au.platform_group
        , au.site_name_abbreviation
        , au.site_name
        , au.section_name
        , COALESCE(summary_impressions.requested_ad_sizes, summary_unmatched_ad_requests.requested_ad_sizes) AS requested_ad_sizes
        , SUM(summary_impressions.total_line_item_level_impressions) AS total_impressions
        , SUM(total_line_item_level_cpm_and_cpc_revenue) AS total_cpm_and_cpc_revenue
        , SUM(video_errors_vast_error_303_count) AS vast_error_303_count
        , SUM(total_unmatched_ad_requests) AS total_unmatched_ad_requests
        , SUM(ad_server_responses_served) AS ad_server_responses_served
        , SUM(total_ad_requests) AS total_ad_requests
        , SUM(total_responses_served) AS total_responses_served
        , SUM(video_viewership_total_error_count) AS video_viewership_total_error_count
        , COALESCE(summary_impressions.ad_month_start, summary_unmatched_ad_requests.ad_month_start) AS ad_month_start_date
        , DATE_FORMAT(ad_month_start_date, 'MM') as ad_month
        , DATE_FORMAT(ad_month_start_date, "y-'Q'Q") as ad_quarter
        , DATE_FORMAT(ad_month_start_date, 'y') as ad_year
        , ad_year||ad_month as ad_month_id
        , DATE_FORMAT(ad_month_start_date, 'MMMM-y') as ad_month_year
        , DATE_FORMAT(CURRENT_TIMESTAMP(), 'yyyy-MM-dd') AS etl_load_date
        , CURRENT_TIMESTAMP() AS etl_load_timestamp_utc
    FROM (
        SELECT
            DATE_FORMAT(event_date, 'y-MM-01') as ad_month_start
            , advertiser_id
            , line_item_id
            , ad_unit_id
            , requested_ad_sizes
            , country_id
            , country_name
            , programmatic_channel_name
            , SUM(total_line_item_level_impressions) AS total_line_item_level_impressions
            , SUM(video_errors_vast_error_303_count) AS video_errors_vast_error_303_count
            , SUM(total_line_item_level_cpm_and_cpc_revenue) AS total_line_item_level_cpm_and_cpc_revenue
        FROM fox_bi_prod.raw_ads.gam_api_summary_with_impressions_and_error_count
        WHERE event_date BETWEEN '{event_start_date}' AND '{event_end_date}'
        GROUP BY
            ad_month_start
            , advertiser_id
            , line_item_id
            , ad_unit_id
            , requested_ad_sizes
            , country_id
            , country_name
            , programmatic_channel_name
    ) as summary_impressions
    FULL OUTER JOIN (
        SELECT
            DATE_FORMAT(event_date, 'y-MM-01') as ad_month_start
            , ad_unit_id
            , requested_ad_sizes
            , country_id
            , country_name
            , SUM(total_unmatched_ad_requests) AS total_unmatched_ad_requests
            , SUM(ad_server_responses_served) AS ad_server_responses_served
            , SUM(total_ad_requests) AS total_ad_requests
            , SUM(total_responses_served) AS total_responses_served
            , SUM(video_viewership_total_error_count) AS video_viewership_total_error_count
        FROM fox_bi_prod.raw_ads.gam_api_summary_with_unmatched_ad_requests
        WHERE event_date BETWEEN '{event_start_date}' AND '{event_end_date}'
        GROUP BY
            ad_month_start
            , ad_unit_id
            , requested_ad_sizes
            , country_id
            , country_name
    ) as summary_unmatched_ad_requests
    ON summary_impressions.ad_month_start = summary_unmatched_ad_requests.ad_month_start
    AND summary_impressions.ad_unit_id = summary_unmatched_ad_requests.ad_unit_id
    AND summary_impressions.country_id = summary_unmatched_ad_requests.country_id
    AND summary_impressions.requested_ad_sizes = summary_unmatched_ad_requests.requested_ad_sizes
    LEFT JOIN fox_bi_prod.silver_ads.dim_advertiser adv
    ON summary_impressions.advertiser_id = adv.advertiser_id
    AND adv.network_group_id = 4145
    LEFT JOIN fox_bi_prod.silver_ads.dim_line_item li
    ON summary_impressions.line_item_id = li.line_item_id
    AND li.network_group_id = 4145
    LEFT JOIN fox_bi_prod.silver_ads.dim_orders or
    ON li.order_id = or.order_id
    AND or.network_group_id = 4145
    LEFT JOIN fox_bi_prod.silver_ads.dim_ad_unit au
    ON COALESCE(summary_impressions.ad_unit_id, summary_unmatched_ad_requests.ad_unit_id) = au.ad_unit_id
    AND au.network_group_id = 4145
    LEFT JOIN fox_bi_prod.raw_ads.freewheel_gsheet_map_advertiser_to_brand mab
    ON LOWER(adv.advertiser_name) = LOWER(mab.advertiser_name)
    GROUP BY
        summary_impressions.line_item_id
        , li.line_item_name
        , li.line_item_start_timestamp
        , li.line_item_start_timestamp_timezone
        , li.line_item_start_timestamp_type
        , li.line_item_end_timestamp
        , li.line_item_end_timestamp_timezone
        , li.line_item_type
        , li.contracted_units_bought_qty
        , li.is_unlimited_end_datetime
        , li.is_skippable_ad_type
        , li.line_item_priority
        , li.value_cost_per_unit_currency_code
        , li.value_cost_per_unit_micro_amt
        , li.delivery_indicator_expected_delivery_percentage
        , li.delivery_indicator_actual_delivery_percentage
        , li.delivery_data
        , li.budget_currency_code
        , li.budget_micro_amt
        , li.line_item_status
        , li.is_missing_creatives
        , li.primary_goal_type
        , li.primary_goal_unit_type
        , li.primary_goal_units_qty
        , summary_impressions.advertiser_id
        , adv.advertiser_name
        , adv.advertiser_type
        , adv.advertiser_credit_status
        , adv.advertiser_external_id
        , mab.brand_supported
        , COALESCE(summary_impressions.country_id, summary_unmatched_ad_requests.country_id)
        , location
        , summary_impressions.programmatic_channel_name
        , li.order_id
        , or.order_name
        , or.order_start_timestamp
        , or.order_start_timestamp_timezone
        , or.order_end_timestamp
        , or.order_end_timestamp_timezone
        , or.order_status
        , or.salesperson_id
        , or.salesperson_name
        , COALESCE(summary_impressions.ad_unit_id, summary_unmatched_ad_requests.ad_unit_id)
        , au.ad_unit_id_level_1
        , au.ad_unit_id_level_2
        , au.ad_unit_id_level_3
        , au.ad_unit_id_level_4
        , au.ad_unit_id_level_5
        , au.ad_unit_name
        , au.ad_unit_name_level_1
        , au.ad_unit_name_level_2
        , au.ad_unit_name_level_3
        , au.ad_unit_name_level_4
        , au.ad_unit_name_level_5
        , au.status
        , au.has_children
        , au.is_native
        , au.is_explicitly_targeted
        , au.is_fluid
        , au.is_interstitial
        , au.is_weather
        , au.is_weather_fast
        , au.ad_category_name
        , au.ad_detail_name
        , au.ad_format_name
        , au.ad_unit_code
        , au.description
        , au.distributor_name
        , au.page_type_name
        , au.parent_id
        , au.platform_name
        , au.platform_group
        , au.site_name_abbreviation
        , au.site_name
        , au.section_name
        , COALESCE(summary_impressions.requested_ad_sizes, summary_unmatched_ad_requests.requested_ad_sizes)
        , COALESCE(summary_impressions.ad_month_start, summary_unmatched_ad_requests.ad_month_start)
        , ad_month_start_date
"""

# COMMAND ----------

gam_monthly = spark.sql(query)

# Fill in missing values with N/A
string_cols_with_missing_values = [
    'line_item_name',
    'line_item_start_timestamp_timezone',
    'line_item_start_timestamp_type',
    'line_item_end_timestamp_timezone',
    'line_item_type',
    'line_item_priority',
    'value_cost_per_unit_currency_code',
    # 'budget_currency_code',
    # 'line_item_status',
    # 'primary_goal_type',
    # 'primary_goal_unit_type',
    'advertiser_name',
    'advertiser_type',
    'advertiser_credit_status',
    'country_name',
    'location',
    'order_name',
    'ad_unit_name',
    'programmatic_channel_name',
    'order_status',
    'salesperson_name',
    'ad_unit_status',
    'ad_category_name',
    'ad_detail_name',
    'ad_format_name',
    'ad_unit_code',
    'description',
    'distributor_name',
    'page_type_name',
    'parent_id',
    'platform_name',
    'platform_group',
    'site_name_abbreviation',
    'site_name'
]

id_cols_with_missing_values = [
    'line_item_id',
    'advertiser_id',
    'country_id',
    'order_id',
    'ad_unit_id',
    'salesperson_id',
    'ad_category_name',
    'ad_detail_name',
    'ad_format_name',
    'ad_unit_code',
    'description',
    'distributor_name',
    'page_type_name',
    'parent_id',
    'platform_name',
    'platform_group',
    'site_name_abbreviation',
    'site_name',
    'section_name'
]

gam_monthly = gam_monthly.fillna('N/A', subset=string_cols_with_missing_values)
gam_monthly = gam_monthly.fillna(-1, subset=id_cols_with_missing_values)

# COMMAND ----------

# gam_monthly.write.format('delta')\
#     .mode('overwrite')\
#     .partitionBy('ad_month_start_date')\
#     .option('mergeSchema', 'true')\
#     .option('overwriteDynamicPartitions', 'true')\
#     .option('delta.enableDeletionVectors', 'false')\
#     .option('delta.enableIcebergCompatV2', 'true')\
#     .option('delta.universalFormat.enabledFormats', 'iceberg')\
#     .option('delta.columnMapping.mode', 'name')\
#     .saveAsTable('fox_bi_prod.silver_ads.ft_gam_summary_monthly_data')

gam_monthly.write.format('delta')\
    .mode('overwrite')\
    .option('partitionOverwriteMode', 'dynamic')\
    .saveAsTable('fox_bi_prod.silver_ads.ft_gam_summary_monthly_data')

# COMMAND ----------

spark.sql('select ad_month_start_date, count(*) from fox_bi_prod.silver_ads.ft_gam_summary_monthly_data group by 1 order by 1').show()
# +-------------------+--------+
# |ad_month_start_date|count(1)|
# +-------------------+--------+
# |         2025-03-01|23597192|
# |         2025-04-01|11499063|
# +-------------------+--------+