# Databricks notebook source
# MAGIC %run ../Utilities

# COMMAND ----------

gam_service_account_creds_secret_arn = dbutils.widgets.get('gam_service_account_creds_secret_arn')
gam_api_version = dbutils.widgets.get('gam_api_version')

event_start_date_param=dbutils.widgets.get('event_start_date')
event_end_date_param=dbutils.widgets.get('event_end_date')

# COMMAND ----------

client = get_ad_manager_client(secret_arn=gam_service_account_creds_secret_arn)
custom_targeting_service = client.GetService('CustomTargetingService', version=gam_api_version)
key_statement = ad_manager.StatementBuilder(version='v202405')
key_response = custom_targeting_service.getCustomTargetingKeysByStatement(key_statement.ToStatement())

# COMMAND ----------

value_lookup = {}

for key in key_response.results:
    key_id = key.id
    key_name = key.name

    # Step 2: Fetch values under each key
    value_statement = (
        ad_manager.StatementBuilder(version='v202405')
        .Where('customTargetingKeyId = :key_id')
        .WithBindVariable('key_id', key_id)
    )

    while True:
        value_response = custom_targeting_service.getCustomTargetingValuesByStatement(value_statement.ToStatement())

        if hasattr(value_response, 'results') and value_response.results:
            for value in value_response.results:
                value_lookup[value.id] = {
                    'key_name': key_name,
                    'key_id': key_id,
                    'value_name': value.name
                }

        if not value_response.totalResultSetSize or value_statement.offset + value_statement.limit >= value_response.totalResultSetSize:
            break
        else:
            value_statement.offset += value_statement.limit

print(f"\n✅ Total mapping entries collected: {(value_lookup)}")

# COMMAND ----------

def resolve_targeting(val_id):
    entry = value_lookup.get(val_id)
    if entry:
        return pd.Series([entry['key_name'], entry['value_name']])
    else:
        return pd.Series(['UNKNOWN', 'UNKNOWN'])

# COMMAND ----------

# MAGIC %md KEY VALUE LOOKUP PART ENDS

# COMMAND ----------

def format_report(report_data: Any, report_type: str) -> Any:
    if report_type == 'Sports GAM API Daily Data Validation Report NON KVP':
        format_columns = {
            'Dimension.DATE': ('event_date', T.DateType()),
            'Dimension.COUNTRY_CODE': ('country_CODE', T.StringType()),
            'Dimension.LINE_ITEM_ID': ('line_item_id', T.LongType()),
            'Dimension.AD_UNIT_ID': ('ad_unit_id', T.LongType()),
            'Dimension.ORDER_ID': ('order_id', T.LongType()),
            'Dimension.PROGRAMMATIC_CHANNEL_NAME': ('programmatic_channel_name', T.StringType()),
            'Dimension.COUNTRY_NAME': ('country_name', T.StringType()),
            'Dimension.DEMAND_CHANNEL_NAME': ('demand_channel_name', T.StringType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS': ('total_line_item_level_impressions', T.LongType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_CPM_AND_CPC_REVENUE': ('total_line_item_level_cpm_and_cpc_revenue', T.LongType()),
            'Column.TOTAL_ACTIVE_VIEW_MEASURABLE_IMPRESSIONS': ('total_active_view_measurable_impressions', T.LongType()),
            'Column.TOTAL_ACTIVE_VIEW_VIEWABLE_IMPRESSIONS': ('total_active_view_viewable_impressions', T.LongType()),
            'Column.TOTAL_ACTIVE_VIEW_ELIGIBLE_IMPRESSIONS': ('total_active_view_eligible_impressions', T.LongType())
        }
        select_cols = [
            'event_date',
            'line_item_id',
            'ad_unit_id',
            'order_id',
            'programmatic_channel_name',
            'demand_channel_name',
            'country_code',         
            'country_name',
            'total_line_item_level_impressions',
            'total_line_item_level_cpm_and_cpc_revenue',
            'total_active_view_measurable_impressions',
            'total_active_view_viewable_impressions',
            'total_active_view_eligible_impressions'   
        ]


    if report_type == 'Sports GAM API Daily Data Validation Report KVP':
        format_columns = {
            'Dimension.DATE': ('event_date', T.DateType()),
            'Dimension.LINE_ITEM_ID': ('line_item_id', T.LongType()),
            'Dimension.AD_UNIT_ID': ('ad_unit_id', T.LongType()),
            'Dimension.ORDER_ID': ('order_id', T.LongType()),
            'Dimension.PROGRAMMATIC_CHANNEL_NAME': ('programmatic_channel_name', T.StringType()), 
            'Dimension.DEMAND_CHANNEL_NAME': ('demand_channel_name', T.StringType()),
            'Dimension.CUSTOM_TARGETING_VALUE_ID': ('custom_targeting_value_id', T.LongType()),
            'TARGETING_KEY': ('targeting_key', T.StringType()),
            'TARGETING_VALUE': ('targeting_value', T.StringType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS': ('total_line_item_level_impressions', T.LongType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_CPM_AND_CPC_REVENUE': ('total_line_item_level_cpm_and_cpc_revenue', T.LongType()),
            'Column.TOTAL_ACTIVE_VIEW_MEASURABLE_IMPRESSIONS': ('total_active_view_measurable_impressions', T.LongType()),
            'Column.TOTAL_ACTIVE_VIEW_VIEWABLE_IMPRESSIONS': ('total_active_view_viewable_impressions', T.LongType()),
            'Column.TOTAL_ACTIVE_VIEW_ELIGIBLE_IMPRESSIONS': ('total_active_view_eligible_impressions', T.LongType())
        }
        select_cols = [
            'event_date',
            'line_item_id',
            'ad_unit_id',
            'order_id',
            'programmatic_channel_name',
            'demand_channel_name',
            'custom_targeting_value_id',
            'targeting_key',
            'targeting_value',
            'total_line_item_level_impressions',
            'total_line_item_level_cpm_and_cpc_revenue',
            'total_active_view_measurable_impressions',
            'total_active_view_viewable_impressions',
            'total_active_view_eligible_impressions'
        ]

    if report_type == 'Sports GAM API Daily Data Validation Report Requests':
        format_columns = {
            'Dimension.DATE': ('event_date', T.DateType()),
            'Dimension.AD_UNIT_ID': ('ad_unit_id', T.LongType()),
            'Dimension.COUNTRY_CODE': ('country_code', T.StringType()),
            'Dimension.COUNTRY_NAME': ('country_name', T.StringType()),
            'Column.TOTAL_UNMATCHED_AD_REQUESTS': ('total_unmatched_ad_requests', T.LongType())
        }
        select_cols = [
            'event_date',
            'ad_unit_id',
            'country_code',
            'country_name',
            'total_unmatched_ad_requests'
        ]

    for k, v in format_columns.items():
        report_data = report_data.withColumnRenamed(k, v[0])
        report_data = report_data.withColumn(v[0], F.col(v[0]).cast(v[1]))

    report_data = report_data.select(select_cols)

    return report_data

# COMMAND ----------

import boto3
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

def send_email(subject, html_body, to_addresses, cc_addresses, from_address, aws_profile=f"{aws_profile}", aws_region='us-west-2'):
    msg = MIMEMultipart()
    msg['Subject'] = subject
    msg['From'] = from_address
    msg['To'] = ", ".join(to_addresses)
    msg['Cc'] = ", ".join(cc_addresses)

    # Add HTML body
    msg.attach(MIMEText(html_body, 'html'))

    # Send email
    session = boto3.Session(profile_name=aws_profile)
    ses = session.client('ses', region_name=aws_region)

    ses.send_raw_email(
        Source=from_address,
        Destinations=to_addresses + cc_addresses,
        RawMessage={'Data': msg.as_string()}
    )

    print("Email sent successfully")

# COMMAND ----------

if __name__ == '__main__':

    timezone = pytz.timezone("UTC")
    event_start_date = datetime.strptime(event_start_date_param, '%Y-%m-%d').replace(tzinfo=timezone)
    event_end_date = datetime.strptime(event_end_date_param, '%Y-%m-%d').replace(tzinfo=timezone)

    process_days = (event_end_date-event_start_date).days
    processing_dates = generate_processing_dates(event_start_date, event_end_date, 1)


    #REPORT 1
    # GAM API Daily Data Validation Report
    print('Sports GAM API Daily Data Validation Report NON KVP')
    for i, batch in enumerate(processing_dates):
        start_date, end_date = batch
        print(f"Processing {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}, batch - {i}", end=' ')
        report_service = client.GetService('ReportService', version=gam_api_version)
        report_query = build_report_query(
            dimensions=[
                'DATE',
                'COUNTRY_NAME',
                'COUNTRY_CODE',
                'LINE_ITEM_ID',
                'AD_UNIT_ID',
                'ORDER_ID',
                'PROGRAMMATIC_CHANNEL_NAME',
                'DEMAND_CHANNEL_NAME',
                ],
            columns=[
                'TOTAL_LINE_ITEM_LEVEL_CPM_AND_CPC_REVENUE',
                'TOTAL_ACTIVE_VIEW_MEASURABLE_IMPRESSIONS',
                'TOTAL_ACTIVE_VIEW_VIEWABLE_IMPRESSIONS',
                'TOTAL_ACTIVE_VIEW_ELIGIBLE_IMPRESSIONS',
                'TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS'
            ],
            dimensionAttributes=[],
            start_date=start_date,
            end_date=end_date
        )
        report_job = report_service.runReportJob({'reportQuery': report_query})

        while True:
            status = report_service.getReportJobStatus(report_job['id'])
            if status == 'COMPLETED':
                break
            elif status == 'FAILED':
                break
            else:
                time.sleep(10)

        if status == 'COMPLETED':
            print('Downloading...', end=' ')
            report_download_url = report_service.getReportDownloadURL(report_job['id'], 'CSV_DUMP')
            report_data = spark.createDataFrame(pd.read_csv(report_download_url, compression='gzip'))
            if i == 0:
                final_df_1 = format_report(report_data, 'Sports GAM API Daily Data Validation Report NON KVP')
            else:
                final_df_1 = final_df_1.union(format_report(report_data, 'Sports GAM API Daily Data Validation Report NON KVP'))
            print('Completed')
        else:
            raise Exception('Report job failed')
    
    #REPORT 2 
    # GAM API Daily Data Validation Report
    print('Sports GAM API Daily Data Validation Report KVP')

    final_df_2=None
    
    for i, batch in enumerate(processing_dates):
        start_date, end_date = batch
        print(f"Processing {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}, batch - {i}", end=' ')
        report_service = client.GetService('ReportService', version=gam_api_version)
        report_query = build_report_query(
            dimensions=[
                'DATE',
                'CUSTOM_TARGETING_VALUE_ID',
                'LINE_ITEM_ID',
                'AD_UNIT_ID',
                'ORDER_ID',
                'PROGRAMMATIC_CHANNEL_NAME',
                'DEMAND_CHANNEL_NAME' 
            ],
            columns=[
                'TOTAL_LINE_ITEM_LEVEL_CPM_AND_CPC_REVENUE',
                'TOTAL_ACTIVE_VIEW_MEASURABLE_IMPRESSIONS',
                'TOTAL_ACTIVE_VIEW_VIEWABLE_IMPRESSIONS',
                'TOTAL_ACTIVE_VIEW_ELIGIBLE_IMPRESSIONS',
                'TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS'
            ],
            dimensionAttributes=[],
            start_date=start_date,
            end_date=end_date
        )
        report_job = report_service.runReportJob({'reportQuery': report_query})

        while True:
            status = report_service.getReportJobStatus(report_job['id'])
            if status == 'COMPLETED':
                break
            elif status == 'FAILED':
                break
            else:
                time.sleep(10)

        if status == 'COMPLETED':
            start_time = time.time()
            print('Downloading...', end=' ')
            report_download_url = report_service.getReportDownloadURL(report_job['id'], 'CSV_DUMP')
            report_data_df = pd.read_csv(report_download_url, compression='gzip')


            if report_data_df.empty:
                continue
            report_data_df[['TARGETING_KEY', 'TARGETING_VALUE']] = report_data_df['Dimension.CUSTOM_TARGETING_VALUE_ID'].astype(int).apply(resolve_targeting)
            
        

            report_data = spark.createDataFrame(report_data_df)
            if final_df_2 is None:
                final_df_2 = format_report(report_data, 'Sports GAM API Daily Data Validation Report KVP')
            else:
                final_df_2 = final_df_2.union(format_report(report_data, 'Sports GAM API Daily Data Validation Report KVP'))
                
            end_time = time.time()
            duration = end_time - start_time
            print(f"Completed in {duration:.2f} seconds")
        else:
            raise Exception('Report job failed')
    

    #REPORT 3 
    # GAM API Daily Data Validation Report
    print('Sports GAM API Daily Data Validation Report Requests')

    final_df_3=None
    
    for i, batch in enumerate(processing_dates):
        start_date, end_date = batch
        print(f"Processing {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}, batch - {i}", end=' ')
        report_service = client.GetService('ReportService', version=gam_api_version)
        report_query = build_report_query(
            dimensions=[
                'DATE',
                'AD_UNIT_ID',
                'COUNTRY_CODE',
                'COUNTRY_NAME' 
            ],
            columns=[
                'TOTAL_UNMATCHED_AD_REQUESTS'
            ],
            dimensionAttributes=[],
            start_date=start_date,
            end_date=end_date
        )
        report_job = report_service.runReportJob({'reportQuery': report_query})

        while True:
            status = report_service.getReportJobStatus(report_job['id'])
            if status == 'COMPLETED':
                break
            elif status == 'FAILED':
                break
            else:
                time.sleep(10)

        if status == 'COMPLETED':
            start_time = time.time()
            print('Downloading...', end=' ')
            report_download_url = report_service.getReportDownloadURL(report_job['id'], 'CSV_DUMP')
            report_data_df = pd.read_csv(report_download_url, compression='gzip')


            if report_data_df.empty:
                continue
        

            report_data = spark.createDataFrame(report_data_df)
            if final_df_3 is None:
                final_df_3 = format_report(report_data, 'Sports GAM API Daily Data Validation Report Requests')
            else:
                final_df_3 = final_df_3.union(format_report(report_data, 'Sports GAM API Daily Data Validation Report Requests'))
                
            end_time = time.time()
            duration = end_time - start_time
            print(f"Completed in {duration:.2f} seconds")
        else:
            raise Exception('Report job failed')

    

# COMMAND ----------

final_df_1.createOrReplaceTempView('sport_gam_ui_non_kvp_table')
final_df_2.createOrReplaceTempView('sport_gam_ui_kvp_table')
final_df_3.createOrReplaceTempView('sport_gam_ui_requests')

# COMMAND ----------

spark.sql("""
WITH non_kvp_agg AS (
    SELECT
        event_date,
        SUM(total_line_item_level_impressions) AS total_line_item_level_impressions,
        SUM(total_line_item_level_cpm_and_cpc_revenue) AS total_line_item_level_cpm_and_cpc_revenue,
        SUM(total_active_view_measurable_impressions) AS total_active_view_measurable_impressions,
        SUM(total_active_view_viewable_impressions) AS total_active_view_viewable_impressions,
        SUM(total_active_view_eligible_impressions) AS total_active_view_eligible_impressions
    FROM sport_gam_ui_non_kvp_table
    GROUP BY event_date
),
requests_agg AS (
    SELECT
    event_date,
    SUM(total_unmatched_ad_requests) AS total_unmatched_ad_requests
    FROM sport_gam_ui_requests
    GROUP BY event_date
)
SELECT
    n.event_date,
    n.total_line_item_level_impressions,
    n.total_line_item_level_cpm_and_cpc_revenue,
    n.total_active_view_measurable_impressions,
    n.total_active_view_viewable_impressions,
    n.total_active_view_eligible_impressions,
    r.total_unmatched_ad_requests
FROM non_kvp_agg n
JOIN requests_agg r
  ON n.event_date = r.event_date
""").createOrReplaceTempView("sport_gam_ui_table_non_kvp_agg")

# COMMAND ----------

spark.sql("""
select 
       event_date,
       sum(total_line_item_level_impressions) as total_line_item_level_impressions
       ,sum(total_line_item_level_cpm_and_cpc_revenue) as total_line_item_level_cpm_and_cpc_revenue
from
sport_gam_ui_kvp_table 
where lower(targeting_key) in ("category", "league", "conference", "specialevent", "show",
        "personality", "contest", "author", "componenttype",  "contenttype", "topic", "video_playback_orientation", "pagetype", "event_rights","event_state") 
        group by 1""").createOrReplaceTempView('sport_gam_ui_table_kvp_agg')

# COMMAND ----------

# MAGIC %md FT_SPORTS_GAM_AD_DELIVERY_AND_CAPACTY VALIDATION

# COMMAND ----------

table_query_1 = f"""
        SELECT
              event_date
            , SUM(total_impressions) AS total_impressions
            , SUM(total_cpm_and_cpc_revenue_usd) AS total_cpm_and_cpc_revenue_usd
            , SUM(total_unmatched_ad_requests) AS total_unmatched_ad_requests
        FROM {catalog}.{silver_schema}.ft_sports_gam_ad_delivery_and_capacity
        WHERE event_date >= '{event_start_date}' AND event_date <= '{event_end_date}'
        GROUP BY 1
    """
table_df_1 = spark.sql(table_query_1)
table_df_1.createOrReplaceTempView('summary_delivery_and_capacity_table')

# COMMAND ----------

validations_df=spark.sql("""
            select 
            silver.event_date,
            round((abs((silver.total_impressions - ui.total_line_item_level_impressions))*100/silver.total_impressions),4) as total_impressions_variance_percent,
            round(abs((silver.total_cpm_and_cpc_revenue_usd - ui.total_line_item_level_cpm_and_cpc_revenue))*100/silver.total_cpm_and_cpc_revenue_usd,4) as total_revenue_variance_percent,
            round(abs((silver.total_unmatched_ad_requests - ui.total_unmatched_ad_requests))*100/silver.total_unmatched_ad_requests,4) as total_unmatched_ad_requests_variance_percent
            from
            summary_delivery_and_capacity_table silver join
            sport_gam_ui_table_non_kvp_agg ui on 
            silver.event_date=ui.event_date
                         """)

# COMMAND ----------

display(validations_df)

# COMMAND ----------

# Collect results
rows = validations_df.orderBy("event_date").collect()

# Format HTML table
html_table = """
<table border="1" cellpadding="4" cellspacing="0" style="border-collapse: collapse;">
<tr>
<th>event_date</th>
<th>total_impressions_variance_percent</th>
<th>total_revenue_variance_percent</th>
<th>total_unmatched_ad_requests_variance_percent</th>
</tr>
"""

for row in rows:
    html_table += f"""
    <tr>
        <td>{row['event_date'].strftime('%Y-%m-%d')}</td>
        <td>{row['total_impressions_variance_percent']}</td>
        <td>{row['total_revenue_variance_percent']}</td>
        <td>{row['total_unmatched_ad_requests_variance_percent']}</td>
    </tr>
    """

html_table += "</table>"

# Final email body
html_body = f"""
<p>Hi Team,</p>
<p>Below is the validation between Sports Gam UI and Silver Layer (Prod) Table ft_summary_delivery_and_capacity.</p>
<p><b>Sports Gam Validation Report</b></p>
{html_table}
<p>Regards,<br>AdTech Team</p>
"""

# COMMAND ----------

send_email(
    subject="Sports Gam Validation Report for ft_summary_delivery_and_capacity Prod",
    html_body=html_body,
    to_addresses=["data_adtech@fox.com"],
    cc_addresses=[],
    from_address=f"{from_email}",
    aws_profile=f"{aws_profile}"
)

# COMMAND ----------

# MAGIC %md FT_SPORTS_GAM_VIEWABILITY VALIDATION

# COMMAND ----------

table_query_2 = f"""
        SELECT
              event_date,
              Sum(total_impressions) as total_impressions,
             sum(total_active_view_measurable_impressions) AS total_active_view_measurable_impressions,
            SUM(total_active_view_viewable_impressions) AS total_active_view_viewable_impressions,
            SUM(total_active_view_eligible_impressions) AS total_active_view_eligible_impressions
        FROM {catalog}.{silver_schema}.ft_sports_gam_viewability
        WHERE event_date >= '{event_start_date}' AND event_date <= '{event_end_date}'
        GROUP BY 1
    """
table_df_2 = spark.sql(table_query_2)
table_df_2.createOrReplaceTempView('viewability_table')

# COMMAND ----------

validations_df=spark.sql("""
            select 
            silver.event_date,
            round(abs((silver.total_impressions - ui.total_line_item_level_impressions))*100/silver.total_impressions,4) as total_impressions_variance_percent,
            round(abs((silver.total_active_view_measurable_impressions - ui.total_active_view_measurable_impressions))*100/silver.total_active_view_measurable_impressions,4) as total_measurable_impressions_variance_percent,
            round(abs((silver.total_active_view_viewable_impressions - ui.total_active_view_viewable_impressions))*100/silver.total_active_view_viewable_impressions,4) as total_viewable_impressions_variance_percent,
            round(abs((silver.total_active_view_eligible_impressions - ui.total_active_view_eligible_impressions))*100/silver.total_active_view_eligible_impressions,4) as total_eligible_impressions_variance_percent
            from
            viewability_table silver join
            sport_gam_ui_table_non_kvp_agg ui on 
            silver.event_date=ui.event_date
                         """)

# COMMAND ----------

display(validations_df)

# COMMAND ----------

# Collect results
rows = validations_df.orderBy("event_date").collect()
print(rows)

# Format HTML table
html_table = """
<table border="1" cellpadding="4" cellspacing="0" style="border-collapse: collapse;">
<tr>
<th>event_date</th>
<th>total_impressions_variance_percent</th>
<th>total_measurable_impressions_variance_percent</th>
<th>total_viewable_impressions_variance_percent</th>
<th>total_eligible_impressions_variance_percent</th>
</tr>
"""

for row in rows:
    html_table += f"""
    <tr>
        <td>{row['event_date'].strftime('%Y-%m-%d')}</td>
        td>{row['total_impressions_variance_percent']}</td>
        <td>{row['total_measurable_impressions_variance_percent']}</td>
        <td>{row['total_viewable_impressions_variance_percent']}</td>
        <td>{row['total_eligible_impressions_variance_percent']}</td>
    </tr>
    """

html_table += "</table>"

# Final email body
html_body = f"""
<p>Hi Team,</p>
<p>Below is the validation between Sports Gam UI and Silver Layer(Prod) Table ft_sports_gam_viewability.</p>
<p><b>Sports Gam Validation Report</b></p>
{html_table}
<p>Regards,<br>AdTech Team</p>
"""

# COMMAND ----------

send_email(
    subject="Sports Gam Validation Report for ft_sports_gam_viewability Prod",
    html_body=html_body,
    to_addresses=["data_adtech@fox.com"],
    cc_addresses=[],
    from_address=f"{from_email}",
    aws_profile=f"{aws_profile}"
)

# COMMAND ----------

# MAGIC %md FT_SPORTS_GAM_AD_DELIVERY_AND_KVP VALIDATION

# COMMAND ----------

table_query_3 = f"""
        SELECT
              event_date,
              Sum(total_impressions) as total_impressions,
              sum(total_cpm_and_cpc_revenue_usd) as total_cpm_and_cpc_revenue_usd
        FROM {catalog}.{silver_schema}.ft_sports_gam_ad_delivery_and_kvp
        WHERE event_date >= '{event_start_date}' AND event_date <= '{event_end_date}'
        GROUP BY 1
    """
table_df_3 = spark.sql(table_query_3)
table_df_3.createOrReplaceTempView('kvp_table')

# COMMAND ----------

validations_df=spark.sql("""
            select 
            silver.event_date,
            round(abs((silver.total_impressions - ui.total_line_item_level_impressions))*100/silver.total_impressions,4) as total_impressions_variance_percent,
            round(abs((silver.total_cpm_and_cpc_revenue_usd - ui.total_line_item_level_cpm_and_cpc_revenue))*100/silver.total_cpm_and_cpc_revenue_usd,4) as total_revenue_variance_percent
            from
            kvp_table silver join
            sport_gam_ui_table_kvp_agg ui on 
            silver.event_date=ui.event_date
                         """)

# COMMAND ----------

display(validations_df)

# COMMAND ----------

# Collect results
rows = validations_df.orderBy("event_date").collect()

# Format HTML table
html_table = """
<table border="1" cellpadding="4" cellspacing="0" style="border-collapse: collapse;">
<tr>
<th>event_date</th>
<th>total_impressions_variance_percent</th>
<th>total_revenue_variance_percent</th>
</tr>
"""

for row in rows:
    html_table += f"""
    <tr>
        <td>{row['event_date'].strftime('%Y-%m-%d')}</td>
        <td>{row['total_impressions_variance_percent']}</td>
        <td>{row['total_revenue_variance_percent']}</td>
    </tr>
    """

html_table += "</table>"

# Final email body
html_body = f"""
<p>Hi Team,</p>
<p>Below is the validation between Sports Gam UI and Silver Layer (Prod) Table ft_sports_gam_ad_delivery_and_kvp.</p>
<p><b>Sports Gam Validation Report</b></p>
{html_table}
<p>Regards,<br>AdTech Team</p>
"""

# COMMAND ----------

send_email(
    subject="Sports Gam Validation Report for ft_sports_gam_ad_delivery_and_kvp Prod",
    html_body=html_body,
    to_addresses=["data_adtech@fox.com"],
    cc_addresses=[],
    from_address=f"{from_email}",
    aws_profile=f"{aws_profile}"
)
