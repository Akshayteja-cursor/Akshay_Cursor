# Databricks notebook source
import json
import tempfile
import os
import boto3
import pandas as pd
import pandas.io.sql as sqlio
from oauth2client.service_account import ServiceAccountCredentials
from googleapiclient.discovery import build
import psycopg2
import requests
import sys
import io

# COMMAND ----------

# MAGIC %run ../Utilities

# COMMAND ----------

from databricks.sdk import WorkspaceClient
import re
import tempfile
import json

w = WorkspaceClient()

def get_secret_value(value):
    """Retrieve secret from Databricks Secrets if value follows {{secrets/scope/key}} pattern."""
    
    secret_pattern = re.compile(r'{{secrets/([^/]+)/([^}]+)}}')
    match = secret_pattern.match(value)
    
    if match:
        scope = match.group(1)
        key = match.group(2)
        
        # Retrieve secret value using Databricks secrets API
        secret = w.dbutils.secrets.get(scope, key)
        
        # Write the secret to a temporary file
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix=".json") as temp_json_file:
            temp_json_file.write(secret)  # Write secret as string to the file
            json_keyfile_path = temp_json_file.name  # Get the temp file path

        return json_keyfile_path
    else:
        raise ValueError("The provided value does not match the {{secrets/scope/key}} pattern.")


# COMMAND ----------

json_keyfile_path = get_secret_value("{{secrets/google_service_account/gsheet_access}}")

# COMMAND ----------

adrise_sports_mapping_alerts=dbutils.secrets.get('slack_webhooks','adrise_sports_mapping_alerts')
adtech_infra_alerts=dbutils.secrets.get('slack_webhooks','adtech_infra_alerts')


# COMMAND ----------


with open(json_keyfile_path, 'r') as f:
    secret_data = json.load(f)
  

# COMMAND ----------

# MAGIC %run "../Google Service"

# COMMAND ----------

# Google Sheet 
#https://docs.google.com/spreadsheets/d/1oBxk9ODAAMCnuiEFw33cnX7aov08XailrV8Av6omx2k/edit?gid=0#gid=0
google_worksheet_id = '11dpkXnn_CyJLReCgfc9Uc0vMywBR73wTH7eERnB1KM0'
google_sheet_range = 'Sheet1!A1:J'
google_scope_list = ["https://spreadsheets.google.com/feeds",'https://www.googleapis.com/auth/spreadsheets',"https://www.googleapis.com/auth/drive.file","https://www.googleapis.com/auth/drive"]

# Get google service
gsheet_service = get_service(secret_data, google_scope_list, 'sheets')
sheet_data = gsheet_get_data(gsheet_service, google_worksheet_id, google_sheet_range)
sheet_data_dict = list_to_dict(sheet_data)
sheet_data_df = pd.DataFrame(sheet_data_dict)

# Identify if there are duplicate Ad unit(s) in the Gsheet
is_duplicate_id = sheet_data_df['Ad unit'].duplicated().any()
if is_duplicate_id:
  webhook_url = f'{adtech_infra_alerts}'
  
  headers = {'Content-type':'application/json'}
  payload = {'text':f'Prod Duplicate Ad units Found in Gsheet - https://docs.google.com/spreadsheets/d/{google_worksheet_id}'}
  
  response = requests.post(url=webhook_url, headers=headers, data=json.dumps(payload))

  if response.status_code == 200:
    print('Slack alert sent')
  else:
    print('Failed to send slack alert')

  dbutils.notebook.exit("Duplicates Ad units in google sheet.")



# COMMAND ----------

table_data_df = spark.sql(f"""
    SELECT
        ad_unit_id as id,
        ad_unit_name as `Ad unit`,
        '' as Site,
        '' as `Ad Category`,
        '' as `Ad Detail`,
        '' as `Page Type`,
        '' as `Sports: Top Level`,
        '' as `Platform Group`,
        '' as `Platform`,
        '' as `Sports: Platform Breakout`
    FROM {catalog}.{silver_schema}.dim_sports_gam_ad_unit
""").toPandas()

# COMMAND ----------

sheet_data_df['id'] = sheet_data_df['id'].astype(int)
new_records = table_data_df[~table_data_df['id'].isin(sheet_data_df['id'])]


# COMMAND ----------

if  not new_records.empty:
  webhook_url = f'{adtech_infra_alerts}'
  google_worksheet_id = '<your_google_worksheet_id>'  # Replace with your actual worksheet ID

  headers = {'Content-type': 'application/json'}
  google_worksheet_id='11dpkXnn_CyJLReCgfc9Uc0vMywBR73wTH7eERnB1KM0'
  payload = {'text': f"Prod - New Ad units Found in Gsheet - https://docs.google.com/spreadsheets/d/{google_worksheet_id}"}
  response = requests.post(url=webhook_url, headers=headers, data=json.dumps(payload))

  if response.status_code == 200:
    print('Slack alert sent')
  else:
    print('Failed to send slack alert')

  webhook_url = f'{adrise_sports_mapping_alerts}'
  response = requests.post(url=webhook_url, headers=headers, data=json.dumps(payload))

  if response.status_code == 200:
    print('Slack alert sent')
  else:
    print('Failed to send slack alert')

  both_df = pd.concat([sheet_data_df, new_records]).reset_index(drop=True)
  final_df = both_df.drop_duplicates(subset=['id'], keep='last')
  final_df = final_df.fillna('')
  final_data_dict = final_df.to_dict('records')
  print(len(final_df.columns))  # to see how many columns you're trying to write
  clear_sheets(gsheet_service, google_worksheet_id, google_sheet_range)
  update_sheet(gsheet_service, google_worksheet_id, google_sheet_range, final_data_dict)
  
else:
  print('No new Ad units Found in Gsheet')

  

# COMMAND ----------

# final_data_dict = final_df.to_dict('records')
# print(len(final_df.columns))  # to see how many columns you're trying to write
# clear_sheets(gsheet_service, google_worksheet_id, google_sheet_range)
# update_sheet(gsheet_service, google_worksheet_id, google_sheet_range, final_data_dict)
