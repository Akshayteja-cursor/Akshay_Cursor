# Databricks notebook source
# MAGIC   %run ../Utilities

# COMMAND ----------

# COMMAND ----------

# Load configuration values
event_start_date = dbutils.widgets.get("event_start_date")
event_end_date = dbutils.widgets.get("event_end_date")


gam_service_account_creds_secret_arn=dbutils.widgets.get('gam_service_account_creds_secret_arn')
gam_api_version=dbutils.widgets.get('gam_api_version')

# COMMAND ----------

query=f"""
SELECT
event_date,
COALESCE(ad_unit_id,-1) as ad_unit_id,
COALESCE(line_item_id,-1) as line_item_id,
COALESCE(order_id,-1) as order_id,
COALESCE(programmatic_channel_name,'N/A') as programmatic_channel_name,
COALESCE(demand_channel_name,'N/A') as demand_channel_name,
lower(TARGETING_KEY) AS targeting_key,
COALESCE(TARGETING_VALUE,'N/A') as targeting_value,
total_line_item_level_impressions,
total_line_item_level_cpm_and_cpc_revenue,
total_active_view_measurable_impressions,
total_active_view_viewable_impressions,
total_active_view_eligible_impressions
from
{catalog}.{raw_schema}.sports_gam_api_summary_with_impressions_viewability_and_kvp
where event_date>='{event_start_date}' and event_date<='{event_end_date}'
and lower(targeting_key) in ("category", "league", "conference", "specialevent", "show",
        "personality", "contest", "author", "componenttype",
        "contenttype", "topic", "video_playback_orientation", "pagetype", "event_rights","event_state")
"""


df=spark.sql(query)
df=df.withColumn('authority_code',F.lit('Sports Gam'))\
               .withColumn('network_group_id',F.lit(20893548).cast("bigint"))
df.createOrReplaceTempView("src_tbl")

# COMMAND ----------

query=query = f"""
SELECT /*+ BROADCAST({catalog}.{silver_schema}.dim_sports_ad_unit), BROADCAST({catalog}.{silver_schema}.dim_sports_line_item) */ 
  COALESCE(ft.authority_code, 'N/A') AS authority_code,
  COALESCE(ft.network_group_id, -1) AS network_group_id,
  ft.event_date,
  'Sports' AS business_unit,
  COALESCE(ft.ad_unit_id, -1) AS ad_unit_id,
  COALESCE(ft.line_item_id, -1) AS line_item_id,
  line_item.line_item_type,
  COALESCE(ad_unit.ad_unit_name, 'N/A') AS ad_unit_name,
  COALESCE(ad_unit.ad_category_name, 'N/A') AS ad_category_name,
  COALESCE(ad_unit.ad_detail_name, 'N/A') AS ad_detail_name,
  COALESCE(ad_unit.page_type_name, 'N/A') AS page_type_name,
  COALESCE(ad_unit.site_name, 'N/A') AS site_name,
  COALESCE(ad_unit.platform_name, 'N/A') AS platform_name,
  COALESCE(ad_unit.platform_group, 'N/A') AS platform_group,
  COALESCE(ad_unit.top_level_platform, 'N/A') AS top_level_platform,
  COALESCE(ad_unit.platform_breakout, 'N/A') AS platform_breakout,
  COALESCE(ft.programmatic_channel_name, 'N/A') AS programmatic_channel_name,
  COALESCE(ft.demand_channel_name, 'N/A') AS demand_channel_name,
  targeting_key,
  targeting_value,
  

  SUM(COALESCE(total_line_item_level_impressions, 0)) AS total_impressions,

  SUM(
    CASE 
      WHEN line_item.line_item_type LIKE '%SPONSORSHIP%' THEN ft.total_line_item_level_impressions
      WHEN line_item.line_item_type LIKE '%STANDARD%' THEN ft.total_line_item_level_impressions
      WHEN line_item.line_item_type LIKE '%PREFERRED_DEAL%' THEN ft.total_line_item_level_impressions
      WHEN line_item.line_item_type LIKE '%AD_EXCHANGE%' THEN ft.total_line_item_level_impressions
      WHEN line_item.line_item_type LIKE '%PRICE_PRIORITY%' THEN ft.total_line_item_level_impressions
      WHEN line_item.line_item_type LIKE '%PROGRAMMATIC%' OR line_item.line_item_type LIKE '%BULK%' OR line_item.line_item_type LIKE '%STANDARD%' THEN ft.total_line_item_level_impressions
      WHEN line_item.line_item_type IS NULL THEN ft.total_line_item_level_impressions
      ELSE 0 
    END
  ) AS sold_impressions,

  SUM(COALESCE(total_line_item_level_cpm_and_cpc_revenue, 0)) AS total_cpm_and_cpc_revenue_usd,
  CURRENT_TIMESTAMP() AS etl_created_at_timestamp_utc,
  CURRENT_TIMESTAMP() AS etl_updated_at_timestamp_utc

FROM src_tbl ft 
LEFT JOIN {catalog}.{silver_schema}.dim_sports_gam_ad_unit ad_unit 
  ON ft.ad_unit_id = ad_unit.ad_unit_id
  AND ft.network_group_id = ad_unit.network_group_id

LEFT JOIN {catalog}.{silver_schema}.dim_sports_gam_line_item line_item 
  ON ft.line_item_id = line_item.line_item_id
  AND ft.network_group_id = line_item.network_group_id

GROUP BY
  COALESCE(ft.authority_code, 'N/A'),
  COALESCE(ft.network_group_id, -1),
  ft.event_date,
  COALESCE(ft.ad_unit_id, -1),
  COALESCE(ft.line_item_id, -1),
  COALESCE(ad_unit.ad_unit_name, 'N/A'),
  COALESCE(ad_unit.ad_category_name, 'N/A'),
  COALESCE(ad_unit.ad_detail_name, 'N/A'),
  COALESCE(ad_unit.page_type_name, 'N/A'),
  COALESCE(ad_unit.site_name, 'N/A'),
  COALESCE(ad_unit.platform_name, 'N/A'),
  COALESCE(ad_unit.platform_group, 'N/A'),
  COALESCE(ad_unit.top_level_platform, 'N/A'),
  COALESCE(ad_unit.platform_breakout, 'N/A'),
  COALESCE(ft.programmatic_channel_name, 'N/A'),
  COALESCE(ft.demand_channel_name, 'N/A'),
  line_item.line_item_type,
  targeting_key,
  targeting_value
"""


result_df=spark.sql(query)

# COMMAND ----------

from pyspark.sql import functions as F

aggregated_df = result_df.groupBy(
    "authority_code",
    "network_group_id",
    "event_date",
    "business_unit",
    "ad_unit_id",
    "ad_unit_name",
    "ad_category_name",
    "ad_detail_name",
    "page_type_name",
    "site_name",
    "platform_name",
    "platform_group",
    "top_level_platform",
    "platform_breakout",
    "programmatic_channel_name",
    "demand_channel_name",
    "targeting_key",
    "targeting_value",
    "etl_created_at_timestamp_utc",
    "etl_updated_at_timestamp_utc"
).agg(
    F.sum("total_impressions").alias("total_impressions"),
    F.sum("sold_impressions").alias("sold_impressions"),
    F.sum("total_cpm_and_cpc_revenue_usd").alias("total_cpm_and_cpc_revenue_usd"),
)

# COMMAND ----------

try:
  aggregated_df.write.format('delta')\
           .mode('overwrite')\
           .option('partitionOverwriteMode', 'dynamic')\
           .saveAsTable(f'{catalog}.{silver_schema}.ft_sports_gam_ad_delivery_and_kvp')
except Exception as e:
  print(f"Write failed with Exception{e}")
  sys.exit(-1)