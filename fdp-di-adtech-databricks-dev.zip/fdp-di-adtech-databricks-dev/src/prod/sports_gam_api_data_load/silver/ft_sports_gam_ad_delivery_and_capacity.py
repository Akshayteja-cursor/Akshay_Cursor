# Databricks notebook source
# MAGIC %run ../Utilities

# COMMAND ----------

# COMMAND ----------

# Load configuration values
event_start_date = dbutils.widgets.get("event_start_date")
event_end_date = dbutils.widgets.get("event_end_date")

# COMMAND ----------

src_df_1=spark.read.table(f"{catalog}.{raw_schema}.sports_gam_api_summary_with_impressions_and_viewability").\
  filter(F.col('event_date')>=F.lit(event_start_date)).\
  filter(F.col('event_date')<=F.lit(event_end_date))
src_df_2=spark.read.table(f"{catalog}.{raw_schema}.sports_gam_api_summary_with_unmatched_ad_requests").\
  filter(F.col('event_date')>=F.lit(event_start_date)).\
  filter(F.col('event_date')<=F.lit(event_end_date)). \
    select('event_date','ad_unit_id','country_code','country_name','total_unmatched_ad_requests')

# COMMAND ----------

src_df_1=src_df_1.withColumn('authority_code',F.lit('Sports Gam'))\
               .withColumn('network_group_id',F.lit(20893548).cast("bigint"))

# COMMAND ----------

src_df_2=src_df_2.withColumn('authority_code',F.lit('Sports Gam'))\
               .withColumn('network_group_id',F.lit(20893548).cast("bigint"))

# COMMAND ----------

src_df_1.createOrReplaceTempView('summarry_impression_and_viewability')
src_df_2.createOrReplaceTempView('summarry_unmatched_ad_requests')

# COMMAND ----------

query=query = f"""
SELECT /*+ BROADCAST({catalog}.{silver_schema}.dim_sports_ad_unit), BROADCAST({catalog}.{silver_schema}.dim_sports_line_item) */ 
  COALESCE(ft.authority_code, 'N/A') AS authority_code,
  COALESCE(ft.network_group_id, -1) AS network_group_id,
  ft.event_date,
  'Sports' AS business_unit,
  COALESCE(ft.ad_unit_id, -1) AS ad_unit_id,
  COALESCE(ft.line_item_id, -1) as line_item_id,
  COALESCE(line_item.line_item_type, 'N/A') AS line_item_type,
  COALESCE(ad_unit.ad_unit_name, 'N/A') AS ad_unit_name,
  COALESCE(ad_unit.ad_category_name, 'N/A') AS ad_category_name,
  COALESCE(ad_unit.ad_detail_name, 'N/A') AS ad_detail_name,
  COALESCE(ad_unit.page_type_name, 'N/A') AS page_type_name,
  COALESCE(ad_unit.site_name, 'N/A') AS site_name,
  COALESCE(ad_unit.platform_name, 'N/A') AS platform_name,
  COALESCE(ad_unit.platform_group, 'N/A') AS platform_group,
  COALESCE(ad_unit.top_level_platform, 'N/A') AS top_level_platform,
  COALESCE(ad_unit.platform_breakout, 'N/A') AS platform_breakout,
  COALESCE(ft.programmatic_channel_name, 'N/A') AS programmatic_channel_name,
  COALESCE(ft.demand_channel_name, 'N/A') AS demand_channel_name,
  SUM(total_line_item_level_impressions) AS total_impressions,
  SUM(total_line_item_level_cpm_and_cpc_revenue)  AS total_cpm_and_cpc_revenue_usd,
  SUM(
    CASE 
      WHEN line_item.line_item_type LIKE '%SPONSORSHIP%' THEN ft.total_line_item_level_impressions
      WHEN line_item.line_item_type LIKE '%STANDARD%' THEN ft.total_line_item_level_impressions
      WHEN line_item.line_item_type LIKE '%PREFERRED_DEAL%' THEN ft.total_line_item_level_impressions
      WHEN line_item.line_item_type LIKE '%AD_EXCHANGE%' THEN ft.total_line_item_level_impressions
      WHEN line_item.line_item_type LIKE '%PRICE_PRIORITY%' THEN ft.total_line_item_level_impressions
      WHEN line_item.line_item_type LIKE '%PROGRAMMATIC%' OR line_item.line_item_type LIKE '%BULK%' OR line_item.line_item_type LIKE '%STANDARD%' THEN ft.total_line_item_level_impressions
      WHEN line_item.line_item_type IS NULL THEN ft.total_line_item_level_impressions
      ELSE 0 
    END
  ) AS sold_impressions
FROM summarry_impression_and_viewability ft 



LEFT JOIN {catalog}.{silver_schema}.dim_sports_gam_ad_unit ad_unit 
  ON ft.ad_unit_id = ad_unit.ad_unit_id
  AND ft.network_group_id = ad_unit.network_group_id


LEFT JOIN {catalog}.{silver_schema}.dim_sports_gam_line_item line_item 
  ON ft.line_item_id = line_item.line_item_id
  AND ft.network_group_id = line_item.network_group_id



GROUP BY
  COALESCE(ft.authority_code, 'N/A'),
  COALESCE(ft.network_group_id, -1),
  ft.event_date,
  COALESCE(ft.ad_unit_id, -1),
  line_item.line_item_type,
  COALESCE(ft.line_item_id, -1),
  COALESCE(ad_unit.ad_unit_name, 'N/A'),
  COALESCE(ad_unit.ad_category_name, 'N/A'),
  COALESCE(ad_unit.ad_detail_name, 'N/A'),
  COALESCE(ad_unit.page_type_name, 'N/A'),
  COALESCE(ad_unit.site_name, 'N/A'),
  COALESCE(ad_unit.platform_name, 'N/A'),
  COALESCE(ad_unit.platform_group, 'N/A'),
  COALESCE(ad_unit.top_level_platform, 'N/A'),
  COALESCE(ad_unit.platform_breakout, 'N/A'),
  COALESCE(ft.programmatic_channel_name, 'N/A'),
  COALESCE(ft.demand_channel_name, 'N/A')
"""


result_df_1=spark.sql(query)

# COMMAND ----------

result_df_1.createOrReplaceTempView('result_tbl_1')

# COMMAND ----------

query = f"""
SELECT
  result_tbl_1.authority_code as authority_code,
  result_tbl_1.network_group_id as network_group_id,
  result_tbl_1.event_date as event_date,
  result_tbl_1.business_unit as business_unit,
  COALESCE(result_tbl_1.line_item_type, 'N/A') AS line_item_type,
  result_tbl_1.ad_unit_id AS ad_unit_id,
  COALESCE(ad_unit_name,'N/A') as ad_unit_name,
  COALESCE(ad_category_name,'N/A') as ad_category_name,
  COALESCE(ad_detail_name,'N/A') as ad_detail_name,
  COALESCE(page_type_name,'N/A') as page_type_name,
  COALESCE(site_name,'N/A') as site_name,
  COALESCE(platform_name,'N/A') as platform_name,
  COALESCE(platform_group,'N/A') as platform_group,
  COALESCE(top_level_platform,'N/A') as top_level_platform,
  COALESCE(platform_breakout,'N/A') as platform_breakout,
  COALESCE(programmatic_channel_name,'N/A') as programmatic_channel_name,
  COALESCE(demand_channel_name,'N/A') as demand_channel_name,
  SUM(total_impressions) AS total_impressions,
  SUM(total_cpm_and_cpc_revenue_usd) AS total_cpm_and_cpc_revenue_usd,
  NULL AS total_unmatched_ad_requests,
  SUM(sold_impressions) AS sold_impressions,
  SUM(total_impressions) as capacity,
  CAST(SUM(total_cpm_and_cpc_revenue_usd) * 1000 / NULLIF(SUM(sold_impressions), 0) AS DOUBLE) AS m_cpm
FROM result_tbl_1
GROUP BY
  result_tbl_1.authority_code,
  result_tbl_1.network_group_id,
  result_tbl_1.event_date,
  result_tbl_1.business_unit,
  result_tbl_1.ad_unit_id,
  result_tbl_1.line_item_type,
 COALESCE(ad_unit_name,'N/A'),
  COALESCE(ad_category_name,'N/A'),
  COALESCE(ad_detail_name,'N/A'),
  COALESCE(page_type_name,'N/A'),
  COALESCE(site_name,'N/A'),
  COALESCE(platform_name,'N/A'),
  COALESCE(platform_group,'N/A'),
  COALESCE(top_level_platform,'N/A'),
  COALESCE(platform_breakout,'N/A'),
  COALESCE(programmatic_channel_name,'N/A'),
  COALESCE(demand_channel_name,'N/A')
"""

summary_impressions = spark.sql(query)

summary_impressions.createOrReplaceTempView('summary_impressions_agg')

# COMMAND ----------

query=f"""
SELECT
ft.authority_code,
ft.network_group_id,
'Sports' as business_unit,
ft.event_date,
COALESCE(ft.ad_unit_id,-1) AS ad_unit_id,
COALESCE(ad_unit_name,'N/A') as ad_unit_name,
COALESCE(ad_category_name,'N/A') as ad_category_name,
COALESCE(ad_detail_name,'N/A') as ad_detail_name,
COALESCE(page_type_name,'N/A') as page_type_name,
COALESCE(site_name,'N/A') as site_name,
COALESCE(platform_name,'N/A') as platform_name,
COALESCE(platform_group,'N/A') as platform_group,
COALESCE(top_level_platform,'N/A') as top_level_platform,
COALESCE(platform_breakout,'N/A') as platform_breakout,
null as programmatic_channel_name,
null as demand_channel_name,
NULL AS total_impressions,
NULL AS total_cpm_and_cpc_revenue_usd,
SUM(total_unmatched_ad_requests) AS total_unmatched_ad_requests,
NULL AS sold_impressions,
SUM(total_unmatched_ad_requests) as capacity,
null as m_cpm
FROM summarry_unmatched_ad_requests ft

LEFT JOIN {catalog}.{silver_schema}.dim_sports_gam_ad_unit ad_unit 
  ON ft.ad_unit_id = ad_unit.ad_unit_id
  AND ft.network_group_id = ad_unit.network_group_id


GROUP BY 
ft.authority_code,
ft.network_group_id,
business_unit,
ft.event_date,
COALESCE(ft.ad_unit_id,-1),
COALESCE(ad_unit_name,'N/A'),
COALESCE(ad_category_name,'N/A'),
COALESCE(ad_detail_name,'N/A'),
COALESCE(page_type_name,'N/A'),
COALESCE(site_name,'N/A'),
COALESCE(platform_name,'N/A'),
COALESCE(platform_group,'N/A'),
COALESCE(top_level_platform,'N/A'),
COALESCE(platform_breakout,'N/A')"""

summarry_unmatched_ad_requests_agg=spark.sql(query)

summarry_unmatched_ad_requests_agg.createOrReplaceTempView('summarry_unmatched_ad_requests_agg')

# COMMAND ----------

query="""
SELECT
authority_code,
network_group_id,
business_unit,
event_date,
'N/A' as line_item_type,
ad_unit_id,
ad_unit_name,
ad_category_name,
ad_detail_name,
page_type_name,
site_name,
platform_name,
platform_group,
top_level_platform,
platform_breakout,
programmatic_channel_name,
demand_channel_name,
total_impressions,
total_cpm_and_cpc_revenue_usd,
total_unmatched_ad_requests,
sold_impressions,
capacity,
m_cpm,
CURRENT_TIMESTAMP() AS etl_created_at_timestamp_utc,
CURRENT_TIMESTAMP() AS etl_updated_at_timestamp_utc
FROM
summarry_unmatched_ad_requests_agg

UNION


SELECT
authority_code,
network_group_id,
business_unit,
event_date,
line_item_type,
ad_unit_id,
ad_unit_name,
ad_category_name,
ad_detail_name,
page_type_name,
site_name,
platform_name,
platform_group,
top_level_platform,
platform_breakout,
programmatic_channel_name,
demand_channel_name,
total_impressions,
total_cpm_and_cpc_revenue_usd,
total_unmatched_ad_requests,
sold_impressions,
capacity,
m_cpm,
CURRENT_TIMESTAMP() AS etl_created_at_timestamp_utc,
CURRENT_TIMESTAMP() AS etl_updated_at_timestamp_utc
FROM
summary_impressions_agg """


summary_delivery_and_capacity=spark.sql(query)

# COMMAND ----------

summary_delivery_and_capacity.createOrReplaceTempView('summary_delivery_and_capacity')

# COMMAND ----------


try:
  summary_delivery_and_capacity.write.format('delta')\
           .mode('overwrite')\
           .option('partitionOverwriteMode', 'dynamic')\
           .saveAsTable(f'{catalog}.{silver_schema}.ft_sports_gam_ad_delivery_and_capacity')
except Exception as e:
  print(f"Write failed with Exception{e}")
  sys.exit(-1)