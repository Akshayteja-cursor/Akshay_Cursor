# Databricks notebook source
# MAGIC %run ../Utilities

# COMMAND ----------


# Load configuration values
gam_service_account_creds_secret_arn = dbutils.widgets.get('gam_service_account_creds_secret_arn')
gam_api_version = dbutils.widgets.get('gam_api_version')

# COMMAND ----------

# COMMAND ----------

def format_ad_unit(response: Any) -> Any:
    if 'results' in response and len(response['results']):
        inventory = response['results']
        inventory_data = []
        print("inv " ,inventory)
        for item in inventory:
            print('item ',item)
            if len(item['parentPath']) > 0:
                del item['parentPath'][0]
            item['parentPath'].append({'id': item['id'],'name': item['name'],'adUnitCode': item['adUnitCode']})
            ad_unit_id_level_1, ad_unit_id_level_2, ad_unit_id_level_3, ad_unit_id_level_4, ad_unit_id_level_5 = [item['parentPath'][i]['id'] if len(item['parentPath']) > i else None for i in range(5)]
            ad_unit_name_level_1, ad_unit_name_level_2, ad_unit_name_level_3, ad_unit_name_level_4, ad_unit_name_level_5 = [item['parentPath'][i]['name'] if len(item['parentPath']) > i else None for i in range(5)]

            ad_unit_name = []
            for i in range(len(item['parentPath'])):
                ad_unit_name.append(vars()[f'ad_unit_name_level_{i+1}']+' ('+vars()[f'ad_unit_id_level_{i+1}']+')')
            ad_unit_name = ' » '.join(ad_unit_name)

            inventory_data.append(
                [
                    -1 if item['id'] == None else int(item['id']),
                    -1 if item['parentId'] == None else int(item['parentId']),
                    
                    item['description'],
                    item['status'],
                    item['adUnitCode'],
                    ad_unit_id_level_1,
                    ad_unit_id_level_2,
                    ad_unit_id_level_3,
                    ad_unit_id_level_4,
                    ad_unit_id_level_5,
                    ad_unit_name_level_1,
                    ad_unit_name_level_2,
                    ad_unit_name_level_3,
                    ad_unit_name_level_4,
                    ad_unit_name_level_5,
                    ad_unit_name,
                    format_to_datetime(item['lastModifiedDateTime']) if item['lastModifiedDateTime'] else None,
                ]
            )

    schema = T.StructType(
        [
            T.StructField('ad_unit_id', T.LongType(), True),
            T.StructField('parent_id', T.LongType(), True),
            
            T.StructField('description', T.StringType(), True),
            T.StructField('status', T.StringType(), True),
            T.StructField('ad_unit_code', T.StringType(), True),
            T.StructField('ad_unit_id_level_1', T.StringType(), True),
            T.StructField('ad_unit_id_level_2', T.StringType(), True),
            T.StructField('ad_unit_id_level_3', T.StringType(), True),
            T.StructField('ad_unit_id_level_4', T.StringType(), True),
            T.StructField('ad_unit_id_level_5', T.StringType(), True),
            T.StructField('ad_unit_name_level_1', T.StringType(), True),
            T.StructField('ad_unit_name_level_2', T.StringType(), True),
            T.StructField('ad_unit_name_level_3', T.StringType(), True),
            T.StructField('ad_unit_name_level_4', T.StringType(), True),
            T.StructField('ad_unit_name_level_5', T.StringType(), True),
            T.StructField('ad_unit_name', T.StringType(), True),
            T.StructField('last_modified_datetime', T.TimestampType(), True),
        ]
    )
    inventory_data = spark.createDataFrame(inventory_data,  schema=schema)
    return inventory_data



# COMMAND ----------
def format_line_item(response: Any) -> Any:
    if 'results' in response and len(response['results']):
        line_items = response['results']
        line_item_data = []

        for line_item in line_items:
            
            line_item_data.append(
                [
                    line_item['id'],
                    line_item['name'],
                    line_item['orderId'],
                    line_item['orderName'],
                    format_to_datetime(line_item['startDateTime']) if line_item['startDateTime'] else None,
                    line_item['startDateTime']['timeZoneId'] if line_item['startDateTime'] else None,
                    line_item['startDateTimeType'],
                    format_to_datetime(line_item['endDateTime']) if line_item['endDateTime'] else None,
                    line_item['endDateTime']['timeZoneId'] if line_item['endDateTime'] else None,
                    line_item['lineItemType'],
                    line_item['priority'],
                    line_item['status'],
                    format_to_datetime(line_item['lastModifiedDateTime']) if line_item['lastModifiedDateTime'] else None,
                ]
            )

    schema = T.StructType(
        [
            T.StructField('line_item_id', T.LongType(), True),
            T.StructField('line_item_name', T.StringType(), True),
            T.StructField('order_id', T.LongType(), True),
            T.StructField('order_name', T.StringType(), True),
            T.StructField('line_item_start_datetime', T.TimestampType(), True),
            T.StructField('line_item_start_datetime_timezone', T.StringType(), True),
            T.StructField('line_item_start_datetime_type', T.StringType(), True),
            T.StructField('line_item_end_datetime', T.TimestampType(), True),
            T.StructField('line_item_end_datetime_timezone', T.StringType(), True),
            T.StructField('line_item_type', T.StringType(), True),
            T.StructField('line_item_priority', T.StringType(), True),
            T.StructField('line_item_status', T.StringType(), True),
            T.StructField('last_modified_datetime', T.TimestampType(), True),
        ]
    )
    line_item_data = spark.createDataFrame(line_item_data,  schema=schema)
    return line_item_data

# COMMAND ----------

# COMMAND ----------

if __name__ == '__main__':
    

    client = get_ad_manager_client(secret_arn=gam_service_account_creds_secret_arn)
    timezone = pytz.timezone("UTC")
    

    #Commented , Uncomment for first run and one time historical load
    # last_updated_timestamp = (datetime.now()-timedelta(days=210)).replace(tzinfo=timezone)
    # print(last_updated_timestamp)

    # Fetch dimensions one by one from match table api
    # Ad Unit
    last_updated_timestamp = spark.sql(f"""select max(last_modified_datetime) as last_updated_timestamp from {catalog}.{raw_schema}.sports_gam_ad_unit""").collect()[0]['last_updated_timestamp'].replace(tzinfo=timezone)
    statement = ad_manager.StatementBuilder(version=gam_api_version)\
                .Where('lastModifiedDateTime >= :lastModifiedDateTime')\
                .WithBindVariable('lastModifiedDateTime', last_updated_timestamp)
    inventory_service = client.GetService('InventoryService', version=gam_api_version)
    response = inventory_service.getAdUnitsByStatement(statement.ToStatement())
    batch_number = 0
    while True:
        response = inventory_service.getAdUnitsByStatement(statement.ToStatement())
        if 'results' in response and len(response['results']) == 0:
            print('no ad unit results')
            break
        batch_size = len(response['results'])
        if batch_number == 0:
            ad_unit_data = format_ad_unit(response)
        else:
            ad_unit_data = ad_unit_data.union(format_ad_unit(response))
        batch_number += 1
        statement.limit = batch_size
        statement.offset += batch_size

    if batch_number != 0:
        ad_unit_data = ad_unit_data.withColumn('etl_created_at_timestamp_utc', F.current_timestamp()).withColumn('etl_updated_at_timestamp_utc', F.current_timestamp())

        ad_unit_data.write.mode('append').saveAsTable(f'{catalog}.{raw_schema}.sports_gam_ad_unit')


        
    #Line Item
    last_updated_timestamp = spark.sql(f"""select max(last_modified_datetime) as last_updated_timestamp from {catalog}.{raw_schema}.sports_gam_line_item""").collect()[0]['last_updated_timestamp'].replace(tzinfo=timezone)
    statement = ad_manager.StatementBuilder(version=gam_api_version)\
                .Where('lastModifiedDateTime >= :lastModifiedDateTime')\
                .WithBindVariable('lastModifiedDateTime', last_updated_timestamp)
    line_item_service = client.GetService('LineItemService', version=gam_api_version)
    batch_number = 0
    while True:
        response = line_item_service.getLineItemsByStatement(statement.ToStatement())
        if 'results' in response and len(response['results']) == 0:
            print('no line item results')
            break
        batch_size = len(response['results'])
        if batch_number == 0:
            line_item_data = format_line_item(response)
        else:
            line_item_data = line_item_data.union(format_line_item(response))
        batch_number += 1
        statement.limit = batch_size
        statement.offset += batch_size

    if batch_number != 0:
        line_item_data = line_item_data.withColumn('etl_created_at_timestamp_utc', F.current_timestamp()).withColumn('etl_updated_at_timestamp_utc', F.current_timestamp())

        line_item_data.write.mode('append').saveAsTable(f'{catalog}.{raw_schema}.sports_gam_line_item')