# Databricks notebook source
skip_gam = dbutils.jobs.taskValues.get("set_job_parameters","skip_gam")
event_start_date = dbutils.jobs.taskValues.get("set_job_parameters","event_start_date_gam")
event_end_date = dbutils.jobs.taskValues.get("set_job_parameters","event_end_date_gam")

# COMMAND ----------

if skip_gam=='true':
  dbutils.notebook.exit("Skipping Gam")

# COMMAND ----------

spark.conf.set("spark.sql.shuffle.partitions", "auto")

# COMMAND ----------

base_path=f"/mnt/fox-fdp-bi-prod/adtech/news_gam"

# COMMAND ----------

from datetime import datetime, timedelta

# COMMAND ----------

# MAGIC %md
# MAGIC NETWORK CODESERVES

# COMMAND ----------

target_table="fox_bi_prod.bronze_ads.news_gam_network_code_serves"
key_column="event_date"

# COMMAND ----------

from pyspark.sql.functions import *


# Convert strings to datetime objects
start = datetime.strptime(event_start_date, "%Y-%m-%d")
end = datetime.strptime(event_end_date, "%Y-%m-%d")


# Generate list of date strings in the required format
date_list = [(start + timedelta(days=i)).strftime("%Y-%m-%d") 
             for i in range((end - start).days + 1)]

print(date_list)

# Initialize with the first day's DataFrame
df_source = spark.read.parquet(
    f"{base_path}/network_code_serves/dt={date_list[0]}/"
).withColumn("eventdate", lit(date_list[0]))

# Union the rest
for date_str in date_list[1:]:
    df_next = spark.read.parquet(
        f"{base_path}/network_code_serves/dt={date_str}/"
    ).withColumn("eventdate", lit(date_str))
    df_source = df_source.unionByName(df_next)

# COMMAND ----------

df_source = df_source.withColumnRenamed("time","Time")  
df_source = df_source.withColumnRenamed("hour",'eventhour')

# Step : Mask the IP column using SHA-256
df_with_masked_ip = df_source.withColumn("masked_ip", sha2(col("IP"), 256))

# COMMAND ----------

df_transformed = df_with_masked_ip.selectExpr(
    "cast(EventDate as date) as event_date",
    "InventoryShareAssignmentId as inventory_share_assignment_id",
    "InventoryShareOutcome as inventory_share_outcome",
    "ServingRestriction as serving_restriction",
    "CmsMetadata as cms_metadata",
    "NativeFormat as native_format",
    "NativeStyle as native_style",
    "Time as event_time",
    "UserId as user_id",
    "masked_ip as ip",
    "AdvertiserId as advertiser_id",
    "cast(OrderId as bigint) as order_id",
    "cast(LineItemId as bigint) as line_item_id",
    "InventoryShareAssignmentName as inventory_share_assignment_name",
    "cast(CreativeId as bigint) as creative_id",
    "cast(CreativeVersion as bigint) as creative_version",
    "CreativeSize as creative_size",
    "CustomTargeting as custom_targeting",
    "cast(AdUnitId as bigint) as ad_unit_id",
    "Country as country",
    "Browser as browser",
    "Region as region",
    "OS as os",
    "Domain as domain",
    "Metro as metro",
    "City as city",
    "PostalCode as postal_code",
    "BandWidth as bandwidth",
    "cast(TimeUsec as bigint) as timeusec",
    "cast(GfpContentId as bigint) as gfp_content_id",
    "cast(OSId as bigint) as os_id",
    "cast(BrowserId as bigint) as browser_id",
    "cast(CountryId as bigint) as country_id",
    "cast(RegionId as bigint) as region_id",
    "cast(CityId as bigint) as city_id",
    "cast(MetroId as bigint) as metro_id",
    "cast(PostalCodeId as bigint) as postal_code_id",
    "cast(BandwidthId as bigint) as bandwidth_id",
    "AudienceSegmentIds as audience_segment_ids",
    "RequestedAdUnitSizes as requested_ad_unit_sizes",
    "MobileDevice as mobile_device",
    "OSVersion as os_version",
    "MobileCapability as mobile_capability",
    "cast(BandwidthGroupId as bigint) as bandwidth_group_id",
    "MobileCarrier as mobile_carrier",
    "Product as product",
    "PublisherProvidedID as publisher_provided_id",
    "cast(IsCompanion as boolean) as is_companion",
    "cast(VideoPosition as bigint) as video_position",
    "cast(PodPosition as bigint) as pod_position",
    "cast(VideoFallbackPosition as bigint) as video_fallback_position",
    "TargetedCustomCriteria as targeted_custom_criteria",
    "KeyPart as keypart",
    "cast(TimeUsec2 as bigint) as timeusec2",
    "DeviceCategory as device_category",
    "cast(IsInterstitial as boolean) as is_interstitial",
    "ActiveViewEligibleImpression as active_view_eligible_impression",
    "EventKeyPart as event_keypart",
    "cast(EventTimeUsec2 as bigint) as event_timeusec2",
    "RefererURL as referer_url",
    "cast(EstimatedBackfillRevenue as double) as estimated_backfill_revenue",
    "YieldGroupNames as yield_group_names",
    "cast(YieldGroupCompanyId as bigint) as yield_group_company_id",
    "MobileAppId as mobile_app_id",
    "RequestLanguage as request_language",
    "DealId as deal_id",
    "DealType as deal_type",
    "cast(AdxAccountId as bigint) as adx_account_id",
    "OptimizationType as optimization_type",
    "CreativeSizeDelivered as creative_size_delivered",
    "cast(Anonymous as boolean) as anonymous",
    "Advertiser as advertiser",
    "cast(SellerReservePrice as double) as seller_reserve_price",
    "Buyer as buyer",
    "ImpressionId as impression_id",
    "CAST(NULL AS STRING) as att_consent_status",
    "CAST(NULL AS STRING) as backfill_keypart",
    "cast(NULL as bigint) as custom_spot_subpod_ids",
    "cast(NULL as string) ppid_presence",
    "cast(NULL as string) as processing_date_and_hour",
    "cast(NULL as boolean) as protected_audience_api_delivery",
    "cast(NULL as string) as publisher_provided_signals",
    "cast(NULL as string) as user_identifier_status",
    "cast(NULL as string) as yield_partner_tag",
    "CURRENT_TIMESTAMP() as etl_created_at_timestamp_utc",
    "CURRENT_TIMESTAMP() as etl_updated_at_timestamp_utc",
    "EventHour as event_hour"
)

# COMMAND ----------

print(f"""
    DELETE FROM {target_table}
    WHERE {key_column} >= DATE('{event_start_date}')
      AND {key_column} <= DATE('{event_end_date}')
    """)


spark.sql( 
    f"""
    DELETE FROM {target_table}
    WHERE {key_column} >= DATE('{event_start_date}')
      AND {key_column} <= DATE('{event_end_date}')
    """
);

# COMMAND ----------

(
    df_transformed.write
    .mode("append")  # Or "append" if you're not replacing existing partitions
    .saveAsTable(f"{target_table}")
)