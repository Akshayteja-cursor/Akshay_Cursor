# Databricks notebook source
skip_gam = dbutils.jobs.taskValues.get("set_job_parameters","skip_gam")
event_start_date = dbutils.jobs.taskValues.get("set_job_parameters","event_start_date_gam")
event_end_date = dbutils.jobs.taskValues.get("set_job_parameters","event_end_date_gam")

# COMMAND ----------

if skip_gam=='true':
  dbutils.notebook.exit("Skipping Gam")

# COMMAND ----------

spark.conf.set("spark.sql.shuffle.partitions", "auto")

# COMMAND ----------

base_path=f"/mnt/fox-fdp-bi-prod/adtech/news_gam"

# COMMAND ----------

from datetime import datetime, timedelta

# COMMAND ----------

# MAGIC %md
# MAGIC NETWORK BACKFILL REQUESTS

# COMMAND ----------

target_table="fox_bi_prod.bronze_ads.news_gam_network_backfill_requests"
key_column="event_date"

# COMMAND ----------

from pyspark.sql.functions import *


# Convert strings to datetime objects
start = datetime.strptime(event_start_date, "%Y-%m-%d")
end = datetime.strptime(event_end_date, "%Y-%m-%d")


# Generate list of date strings in the required format
date_list = [(start + timedelta(days=i)).strftime("%Y-%m-%d") 
             for i in range((end - start).days + 1)]

print(date_list)

# Initialize with the first day's DataFrame
df_source = spark.read.parquet(
    f"{base_path}/network_backfill_requests/dt={date_list[0]}/"
).withColumn("eventdate", lit(date_list[0]))

# Union the rest
for date_str in date_list[1:]:
    df_next = spark.read.parquet(
        f"{base_path}/network_backfill_requests/dt={date_str}/"
    ).withColumn("eventdate", lit(date_str))
    df_source = df_source.unionByName(df_next)

# COMMAND ----------

df_source = df_source.withColumnRenamed("time","Time")  
df_source = df_source.withColumnRenamed("hour",'eventhour')

# COMMAND ----------

df_transformed = df_source.selectExpr(
    "cast(eventdate as date) as event_date",
    "CAST(IsFilledRequest AS BOOLEAN) AS is_filled_request",
    "CAST(IsVideoFallbackRequest AS BOOLEAN) AS is_video_fallback_request",
    "InventoryShareAssignmentId AS inventory_share_assignment_id",
    "InventoryShareAssignmentName AS inventory_share_assignment_name",
    "InventoryShareOutcome AS inventory_share_outcome",
    "ServingRestriction AS serving_restriction",
    "CmsMetadata AS cms_metadata",
    "Time AS event_time",
    "UserId AS user_id",
    "CAST(AdUnitId AS BIGINT) AS ad_unit_id",
    "CustomTargeting AS custom_targeting",
    "Country AS country",
    "Region AS region",
    "OS AS os",
    "Browser AS browser",
    "Domain AS domain",
    "City AS city",
    "Metro AS metro",
    "PostalCode AS postal_code",
    "BandWidth AS bandwidth",
    "CAST(TimeUsec AS BIGINT) AS timeusec",
    "CAST(BrowserId AS BIGINT) AS browser_id",
    "CAST(CountryId AS BIGINT) AS country_id",
    "CAST(OSId AS BIGINT) AS os_id",
    "CAST(RegionId AS BIGINT) AS region_id",
    "CAST(CityId AS BIGINT) AS city_id",
    "CAST(MetroId AS BIGINT) AS metro_id",
    "CAST(BandwidthId AS BIGINT) AS bandwidth_id",
    "CAST(PostalCodeId AS BIGINT) AS postal_code_id",
    "CAST(GfpContentId AS BIGINT) AS gfp_content_id",
    "CAST(IsInterstitial AS BOOLEAN) AS is_interstitial",
    "DeviceCategory AS device_category",
    "KeyPart AS keypart",
    "CAST(TimeUsec2 AS BIGINT) AS timeusec2",
    "CAST(PodPosition AS bigint) AS pod_position",
    "CAST(IsCompanion AS BOOLEAN) AS is_companion",
    "CAST(VideoPosition AS BIGINT) AS video_position",
    "PublisherProvidedID AS publisher_provided_id",
    "CAST(BandwidthGroupId AS BIGINT) AS bandwidth_group_id",
    "MobileCarrier AS mobile_carrier",
    "MobileCapability AS mobile_capability",
    "RequestedAdUnitSizes AS requested_ad_unit_sizes",
    "MobileDevice AS mobile_device",
    "OSVersion AS os_version",
    "AudienceSegmentIds AS audience_segment_ids",
    "CAST(Anonymous AS BOOLEAN) AS anonymous",
    "RequestLanguage AS request_language",
    "MobileAppId AS mobile_app_id",
    "RefererURL AS referer_url",
    "cast(NULL as string) AS att_consent_status",
    "cast(NULL as string) AS backfill_keypart",
    "cast(NULL as string) AS custom_spot_subpod_ids",
    "CAST(NULL AS BIGINT) AS max_ads_in_optimized_pod",
    "CAST(NULL AS BIGINT) AS optimized_pods_filled_duration_seconds",
    "CAST(NULL AS BIGINT) AS optimized_pods_unfilled_duration_seconds",
    "CAST(NULL AS STRING) AS ppid_presence",
    "CAST(NULL AS STRING) processing_date_and_hour",
    "CAST(NULL AS STRING) publisher_provided_signals",
    "CAST(NULL AS STRING) AS user_identifier_status",
    "CURRENT_TIMESTAMP() as etl_created_at_timestamp_utc",
    "CURRENT_TIMESTAMP() as etl_updated_at_timestamp_utc",
    "eventhour as event_hour"
)

# COMMAND ----------

print(f"""
    DELETE FROM {target_table}
    WHERE {key_column} >= DATE('{event_start_date}')
      AND {key_column} <= DATE('{event_end_date}')
    """)


spark.sql( 
    f"""
    DELETE FROM {target_table}
    WHERE {key_column} >= DATE('{event_start_date}')
      AND {key_column} <= DATE('{event_end_date}')
    """
);

# COMMAND ----------

(
    df_transformed.write
    .mode("append")  # Or "append" if you're not replacing existing partitions
    .saveAsTable(f"{target_table}")
)