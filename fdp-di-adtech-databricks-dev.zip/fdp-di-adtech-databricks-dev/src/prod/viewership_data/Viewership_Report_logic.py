# Databricks notebook source
from datetime import datetime, timedelta

run_type = dbutils.widgets.get("run_type")

if run_type == 'backfill':
    event_start_date_freewheel = dbutils.widgets.get("event_start_date_freewheel")
    event_end_date_freewheel = dbutils.widgets.get("event_end_date_freewheel")
    event_start_date_gam = dbutils.widgets.get("event_start_date_gam")
    event_end_date_gam = dbutils.widgets.get("event_end_date_gam")
    event_start_date_engagement = event_start_date_freewheel
    event_end_date_engagement = event_end_date_freewheel

    # Use GAM range for event_key values
    event_key_start = int(datetime.strptime(event_start_date_engagement, "%Y-%m-%d").strftime("%Y%m%d"))
    event_key_end = int(datetime.strptime(event_end_date_engagement, "%Y-%m-%d").strftime("%Y%m%d"))

else: #for regular run
    current_date_str = dbutils.widgets.get('current_date')
    current_date = datetime.strptime(current_date_str, '%Y-%m-%d')

    # Freewheel: use current_date - 1
    event_start_date_freewheel = (current_date - timedelta(days=1)).strftime('%Y-%m-%d')
    event_end_date_freewheel = event_start_date_freewheel

    # GAM: use current_date - 2
    event_start_date_gam = (current_date - timedelta(days=1)).strftime('%Y-%m-%d')
    event_end_date_gam = event_start_date_gam

    event_start_date_engagement = event_start_date_freewheel
    event_end_date_engagement = event_end_date_freewheel

    # event_key range
    event_key_start = int((current_date - timedelta(days=1)).strftime('%Y%m%d'))
    event_key_end = int((current_date - timedelta(days=1)).strftime('%Y%m%d'))

print("Freewheel:", event_start_date_freewheel, event_end_date_freewheel)
print("GAM:", event_start_date_gam, event_end_date_gam)
print("Event Key Range:", event_key_start, event_key_end)

# COMMAND ----------

import json
import tempfile
import os
import boto3
import pandas as pd
import pandas.io.sql as sqlio
import psycopg2
import requests
import sys
import boto3

# COMMAND ----------

# MAGIC %md
# MAGIC ENGAGEMENT

# COMMAND ----------

qry_viewership_engagement=f"""

select
    engmt_ft.event_date_time_utc::DATE as event_date,
    case
        when lower(app.conformed_primary_business_unit) = 'to be mapped' then 'N/A'
        else app.conformed_primary_business_unit
    end as business_unit,
    case
        when lower(p.conformed_platform) = 'to be mapped' then 'N/A'
        when lower(p.conformed_platform) like '%unknown%' then 'N/A'
        else p.conformed_platform
    end as platform,
    case
        -- when lower(n.conformed_video_network) in ('ktvu','kdfw','wtvt','ktbc','kmsp','wnyw','wtxf','wttg','wofl','wjbk','kttv','lnfx','wfld','ksaz','kriv','witi','waga','kcpq') then 'FTS'
        when lower(n.conformed_video_network) = 'to be mapped' then 'N/A'
        when lower(n.conformed_video_network) like '%unknown%' then 'N/A'
        else n.conformed_video_network
    end as network,
    case
        -- when lower(app.conformed_app_name) in ('kcpq','wttg','kriv','kdfw','ksaz','wtxf','waga','ktbc','witi','wnyw','woqx','ktvu','kmsp','wjbk','wtvt','kttv','wfld','wofl','credible','q13 fox') then 'FTS App'
        when lower(app.conformed_app_name) = 'to be mapped' then 'N/A'
        when lower(app.conformed_app_name) like '%unknown%' then 'N/A'
        else app.conformed_app_name
    end as app,
    case
        when lower(p.conformed_platform_type) like '%unknown%' then 'N/A'
        else p.conformed_platform_type
    end as platform_type,
    'Owned' as ownership_type,
    case
        when lower(engmt_ft.stream_type) like 'other' then 'N/A'
        else engmt_ft.stream_type
    end as stream_type,
    sum(engmt_ft.page_views) as page_views,
    sum(engmt_ft.content_starts) as content_starts,
    sum(engmt_ft.total_video_viewing_time_secs) as total_video_viewing_time_secs,
    sum(engmt_ft.media_starts) as media_starts,
    sum(engmt_ft.media_time_spent) as media_times_spent
    from fox_bi_prod.silver_engagement.ft_fox_digital_engagement_visitors_daily engmt_ft
    left join fox_bi_prod.silver_engagement.dim_platform p
    on engmt_ft.platform_key = p.platform_key
    left join fox_bi_prod.silver_engagement.dim_app app
    on engmt_ft.app_key = app.app_key
    left join fox_bi_prod.silver_engagement.dim_network n
    on engmt_ft.network_key = n.network_key
    where engmt_ft.data_source_name like 'adobe%'
    and lower(app.conformed_primary_business_unit) != 'credible'
    and date_key >= {event_key_start} and date_key <= {event_key_end}
    and to_date(event_date_time_utc) >= DATE('{event_start_date_engagement}')
    and to_date(event_date_time_utc) <= DATE('{event_end_date_engagement}')
    group by 1,2,3,4,5,6,7,8


"""

# COMMAND ----------

from pyspark.sql.functions import col

# COMMAND ----------

# Spark DataFrame
engagement_df=spark.sql(qry_viewership_engagement)

# Step 2: Cast media_times_spent to DoubleType
engagement_df = engagement_df.withColumn("media_times_spent", col("media_times_spent").cast("double"))

# COMMAND ----------

# MAGIC %md
# MAGIC ADS

# COMMAND ----------

query = f"""
SELECT
    ads_ft.authority_code,
    ads_ft.network_group_id AS network_group_id,
    ads_ft.event_date AS event_date,
    COALESCE(CASE
        WHEN LOWER(vs.business_unit) = 'n/a' THEN 'N/A'
        ELSE vs.business_unit
    END,'N/A') AS business_unit,
    COALESCE(CASE
        WHEN LOWER(svm.standardized_platform) = 'na' THEN 'N/A'
        WHEN LOWER(svm.standardized_platform) LIKE '%unknown%' THEN 'N/A'
        ELSE svm.standardized_platform
    END,'N/A') AS platform,
    COALESCE(dn.network,'N/A') AS network,
    COALESCE(CASE
        WHEN LOWER(svm.standardized_app) = 'na' THEN 'N/A'
        WHEN LOWER(svm.standardized_app) LIKE '%unknown%' THEN 'N/A'
        ELSE svm.standardized_app
    END,'N/A') AS app,
    COALESCE(CASE
        WHEN LOWER(svm.standardized_platform_type) = 'na' THEN 'N/A'
        WHEN LOWER(svm.standardized_platform_type) LIKE '%unknown%' THEN 'N/A'
        ELSE svm.standardized_platform_type
    END,'N/A') AS platform_type,
    COALESCE(CASE
        WHEN LOWER(svm.standardized_owned_or_distributed) = 'na' THEN 'N/A'
        WHEN LOWER(svm.standardized_owned_or_distributed) LIKE '%unknown%' THEN 'N/A'
        ELSE svm.standardized_owned_or_distributed
    END,'N/A') AS ownership_type,
    COALESCE(CASE
        WHEN LOWER(ss.stream_type) LIKE '%live%' THEN 'Live'
        WHEN LOWER(ss.stream_type) LIKE '%vod%' THEN 'VOD'
        ELSE 'N/A'
    END,'N/A') AS stream_type,
    SUM(ads_ft.total_ad_impressions) total_ad_impressions,
    SUM(ads_ft.total_ad_clicks) total_ad_clicks,
    SUM(ads_ft.total_ad_duration_allowed_secs) total_ad_duration_allowed_secs,
    SUM(ads_ft.total_ad_duration_availed_secs) total_ad_duration_availed_secs,
    SUM(ads_ft.total_unfilled_reseller_ad_slots) total_unfilled_reseller_ad_slots,
    SUM(ads_ft.total_ad_requests) total_ad_requests,
    SUM(ads_ft.total_ad_responses) total_ad_responses,
    SUM(ads_ft.total_ad_revenue_usd) total_ad_revenue_usd,
    SUM(ads_ft.total_ad_time_filled_secs) total_ad_time_filled_secs,
    SUM(ads_ft.total_ads_allowed) total_ads_allowed,
    SUM(ads_ft.total_ads_availed) total_ads_availed,
    SUM(ads_ft.total_breaks) total_breaks,
    SUM(ads_ft.total_breaks_complete_unfilled) total_breaks_complete_unfilled,
    NULL::BIGINT total_error_count,
    SUM(ads_ft.total_slate_duration_secs) total_slate_duration_secs,
    SUM(ads_ft.total_slot_impressions) total_slot_impressions,
    SUM(ads_ft.total_unfilled_impressions) total_unfilled_impressions, 
    NULL::BIGINT total_unmatched_ad_requests
FROM fox_bi_prod.silver_ads.ft_freewheel_ad_delivery_daily ads_ft
LEFT JOIN fox_bi_prod.silver_ads.dim_site_section ss
    ON ads_ft.site_section_id = ss.site_section_id
    AND ads_ft.network_group_id = ss.network_group_id
LEFT JOIN fox_bi_prod.raw_ads.viewership_gsheet_map_site_sections svm
    ON ads_ft.site_section_id = svm.site_section_id
LEFT JOIN fox_bi_prod.silver_ads.dim_video_series vs
    ON ads_ft.series_id = vs.series_id
    AND ads_ft.network_group_id = vs.network_group_id
LEFT JOIN fox_bi_prod.silver_ads.dim_network dn
    ON ads_ft.site_section_detail = dn.site_section_name
    AND ads_ft.series_name = dn.series_name
WHERE event_date >= '{event_start_date_freewheel}' and event_date <= '{event_end_date_freewheel}'
AND ads_ft.authority_code = 'freewheel'
GROUP BY 1,2,3,4,5,6,7,8,9,10

UNION

SELECT
    ads_ft_gam.authority_code,
    ads_ft_gam.network_group_id AS network_group_id,
    ads_ft_gam.event_date :: date AS event_date,
    COALESCE(svmg.bu,'N/A') AS business_unit,
    COALESCE(svmg.platform,'N/A') AS platform,
    COALESCE(svmg.Network,'N/A') AS network,
    COALESCE(svmg.app,'N/A') AS app,
    COALESCE(svmg.Platform_type,'N/A') AS platform_type,
    COALESCE(svmg.owned_or_distributed,'N/A') AS ownership_type,
    COALESCE(svmg.stream_type,'N/A') AS stream_type,
    SUM(ads_ft_gam.total_ad_impressions) total_ad_impressions,
    SUM(ads_ft_gam.total_ad_clicks) total_ad_clicks,
    SUM(ads_ft_gam.total_ad_duration_allowed_secs) total_ad_duration_allowed_secs,
    SUM(ads_ft_gam.total_ad_duration_availed_secs) total_ad_duration_availed_secs,
    NULL:: bigint total_unfilled_reseller_ad_slots,
    SUM(ads_ft_gam.total_ad_requests) total_ad_requests,
    SUM(ads_ft_gam.total_ad_responses) total_ad_responses,
    SUM(ads_ft_gam.total_ad_revenue_usd) total_ad_revenue_usd,
    SUM(ads_ft_gam.total_ad_time_filled_secs) total_ad_time_filled_secs,
    SUM(ads_ft_gam.total_ads_allowed) total_ads_allowed,
    SUM(ads_ft_gam.total_ads_availed) total_ads_availed,
    SUM(ads_ft_gam.total_breaks) total_breaks,
    SUM(ads_ft_gam.total_breaks_complete_unfilled) total_breaks_complete_unfilled,
    SUM(ads_ft_gam.total_error_count) total_error_count,
    SUM(ads_ft_gam.total_slate_duration_secs) total_slate_duration_secs,
    NULL:: BIGINT total_slot_impressions,
    SUM(ads_ft_gam.total_unfilled_impressions) total_unfilled_impressions,
    SUM(ads_ft_gam.total_unmatched_ad_requests) total_unmatched_ad_request
FROM fox_bi_prod.silver_ads.ft_gam_ad_delivery_daily ads_ft_gam
LEFT JOIN fox_bi_prod.raw_ads.viewership_gsheet_map_adunits svmg
    ON ads_ft_gam.ad_unit_id = svmg.ad_unit_id
WHERE event_date>= '{event_start_date_gam}' and event_date<= '{event_end_date_gam}'
AND ads_ft_gam.authority_code = 'gam'
GROUP BY 1,2,3,4,5,6,7,8,9,10
"""

# Execute query using Spark SQL
ads_df = spark.sql(query)


# COMMAND ----------

display(ads_df)

# COMMAND ----------

# MAGIC %md
# MAGIC FULL JOIN ADS WITH ENGAGEMENT

# COMMAND ----------

from pyspark.sql.functions import (
    lower, coalesce, col, sum, lit, current_timestamp
)

# Aliasing input DataFrames
ads = ads_df.alias("ads")
eng = engagement_df.alias("eng")

# Perform FULL OUTER JOIN
joined_df = ads.join(
    eng,
    on=(
        (ads.event_date.cast("date")     == eng.event_date.cast("date")) &
        (lower(ads.platform)             == lower(eng.platform)) &
        (lower(ads.network)              == lower(eng.network)) &
        (lower(ads.app)                  == lower(eng.app)) &
        (lower(ads.platform_type)        == lower(eng.platform_type)) &
        (lower(ads.ownership_type)       == lower(eng.ownership_type)) &
        (lower(ads.stream_type)          == lower(eng.stream_type))
    ),
    how="outer"
)

# Coalesced group-by columns
group_cols = [
    coalesce(ads.authority_code, lit("N/A")).alias("authority_code"),
    coalesce(ads.network_group_id, lit(-1)).alias("network_group_id"),
    coalesce(ads.event_date, eng.event_date).alias("event_date"),
    coalesce(ads.platform, eng.platform).alias("platform"),
    coalesce(ads.network, eng.network).alias("network"),
    coalesce(ads.app, eng.app).alias("app"),
    coalesce(ads.platform_type, eng.platform_type).alias("platform_type"),
    coalesce(ads.ownership_type, eng.ownership_type).alias("ownership_type"),
    coalesce(ads.stream_type, eng.stream_type).alias("stream_type")
]

# Aggregate
aggregated_df = joined_df.groupBy(*group_cols).agg(
    coalesce(sum(ads.total_ad_impressions),           lit(0)).alias("total_ad_impressions"),
    coalesce(sum(ads.total_ad_clicks),                lit(0)).alias("total_ad_clicks"),
    coalesce(sum(ads.total_ad_duration_allowed_secs), lit(0)).alias("total_ad_duration_allowed_secs"),
    coalesce(sum(ads.total_ad_duration_availed_secs), lit(0)).alias("total_ad_duration_availed_secs"),
    coalesce(sum(ads.total_unfilled_reseller_ad_slots), lit(0)).alias("total_unfilled_reseller_ad_slots"),
    coalesce(sum(ads.total_ad_requests),              lit(0)).alias("total_ad_requests"),
    coalesce(sum(ads.total_ad_responses),             lit(0)).alias("total_ad_responses"),
    coalesce(sum(ads.total_ad_revenue_usd),           lit(0)).alias("total_ad_revenue_usd"),
    coalesce(sum(ads.total_ad_time_filled_secs),      lit(0)).alias("total_ad_time_filled_secs"),
    coalesce(sum(ads.total_ads_allowed),              lit(0)).alias("total_ads_allowed"),
    coalesce(sum(ads.total_ads_availed),              lit(0)).alias("total_ads_availed"),
    coalesce(sum(ads.total_breaks),                   lit(0)).alias("total_breaks"),
    coalesce(sum(ads.total_breaks_complete_unfilled), lit(0)).alias("total_breaks_complete_unfilled"),
    coalesce(sum(ads.total_error_count),              lit(0)).alias("total_error_count"),
    coalesce(sum(ads.total_slate_duration_secs),      lit(0)).alias("total_slate_duration_secs"),
    coalesce(sum(ads.total_slot_impressions),         lit(0)).alias("total_slot_impressions"),
    coalesce(sum(ads.total_unfilled_impressions),     lit(0)).alias("total_unfilled_impressions"),
    coalesce(sum(ads.total_unmatched_ad_requests),    lit(0)).alias("total_unmatched_ad_requests"),
    coalesce(sum(eng.page_views),                     lit(0)).alias("page_views"),
    coalesce(sum(eng.content_starts),                 lit(0)).alias("content_starts"),
    coalesce(sum(eng.total_video_viewing_time_secs),  lit(0)).alias("total_video_viewing_time_secs"),
    coalesce(sum(eng.media_starts),                   lit(0)).alias("media_starts"),
    coalesce(sum(eng.media_times_spent),              lit(0)).alias("media_times_spent")
)

# Add timestamp columns
aggregated_df = (
    aggregated_df
    .withColumn("etl_created_at_timestamp_utc", current_timestamp())
    .withColumn("etl_updated_at_timestamp_utc", current_timestamp())
)

# COMMAND ----------

(aggregated_df.write.mode("overwrite")
  .mode('overwrite')\
  .option('partitionOverwriteMode', 'dynamic')\
  .saveAsTable("fox_bi_prod.business_analytics.ft_viewership_ads_engagement_daily")
)