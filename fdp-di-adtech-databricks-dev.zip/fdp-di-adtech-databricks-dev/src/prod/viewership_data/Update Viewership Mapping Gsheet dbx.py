# Databricks notebook source
import json
import tempfile
import os
import boto3
import pandas as pd
import pandas.io.sql as sqlio
from oauth2client.service_account import ServiceAccountCredentials
from googleapiclient.discovery import build
import psycopg2
import requests
import sys

# COMMAND ----------

from databricks.sdk import WorkspaceClient
import re
import tempfile
import json

w = WorkspaceClient()

def get_secret_value(value):
    """Retrieve secret from Databricks Secrets if value follows {{secrets/scope/key}} pattern."""
    
    secret_pattern = re.compile(r'{{secrets/([^/]+)/([^}]+)}}')
    match = secret_pattern.match(value)
    
    if match:
        scope = match.group(1)
        key = match.group(2)
        
        # Retrieve secret value using Databricks secrets API
        secret = w.dbutils.secrets.get(scope, key)
        
        # Write the secret to a temporary file
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix=".json") as temp_json_file:
            temp_json_file.write(secret)  # Write secret as string to the file
            json_keyfile_path = temp_json_file.name  # Get the temp file path

        return json_keyfile_path
    else:
        raise ValueError("The provided value does not match the {{secrets/scope/key}} pattern.")


# COMMAND ----------

json_keyfile_path = get_secret_value("{{secrets/google_service_account/gsheet_access}}")
print(json_keyfile_path)



# COMMAND ----------

adtech_infra_alerts = dbutils.secrets.get('slack_webhooks', 'adtech_infra_alerts')
adrise_mapping_alerts = dbutils.secrets.get('slack_webhooks', 'adrise_mapping_alerts')


# COMMAND ----------

print(json_keyfile_path)
with open(json_keyfile_path, 'r') as f:
    secret_data = json.load(f)
    print(type(secret_data))
    print(f.read())

# COMMAND ----------

# MAGIC %run "./Google Service"

# COMMAND ----------

# Google Sheet Information
google_worksheet_id = '1LwmAV8e5N8kf48hSo2ntbh0w2oFN3khlzx_GNmJycSw'
google_sheet_range = 'AdTech!A1:K'
google_scope_list = ["https://spreadsheets.google.com/feeds",'https://www.googleapis.com/auth/spreadsheets',"https://www.googleapis.com/auth/drive.file","https://www.googleapis.com/auth/drive"]

# Get google service
gsheet_service = get_service(secret_data, google_scope_list, 'sheets')
sheet_data = gsheet_get_data(gsheet_service, google_worksheet_id, google_sheet_range)
sheet_data_dict = list_to_dict(sheet_data)
sheet_data_df = pd.DataFrame(sheet_data_dict)

# Step 2: Separate -1 rows from others
is_minus_one = sheet_data_df['site_section_id'] == '-1'
minus_one_df = sheet_data_df[is_minus_one].drop_duplicates(subset='site_section_id', keep='first')
non_minus_one_df = sheet_data_df[~is_minus_one]

# Step 3: Combine back
sheet_data_df = pd.concat([minus_one_df, non_minus_one_df], ignore_index=True)

# Identify if there are duplicate Site Section Id(s) in the Gsheet
is_duplicate_id = sheet_data_df['site_section_id'].duplicated().any()
if is_duplicate_id:
  webhook_url = f'{adtech_infra_alerts}'
  
  headers = {'Content-type':'application/json'}
  payload = {'text':f'Duplicate Site Section ID Found in Gsheet - https://docs.google.com/spreadsheets/d/{google_worksheet_id}'}
  
  response = requests.post(url=webhook_url, headers=headers, data=json.dumps(payload))

  if response.status_code == 200:
    print('Slack alert sent')
  else:
    print('Failed to send slack alert')

  dbutils.notebook.exit("Duplicates site_section_id in google sheet.")



# Test Gsheet entry
# sheet_data_dict.append({'site_section_key': 'test',
#   'site_section_id': 'test',
#   'site_section_name': 'test',
#   'standardized_app': 'test',
#   'standardized_network': 'test',
#   'standardized_platform': 'test',
#   'standardized_platform_type': 'test',
#   'standardized_owned_or_distributed': 'test',
#   'standardized_stream_type': 'test',
#   'Filled In': ''})
# clear_sheets(gsheet_service, google_worksheet_id, google_sheet_range)
# update_sheet(gsheet_service, google_worksheet_id, google_sheet_range, sheet_data_dict)

# COMMAND ----------

table_data_df = spark.sql("""SELECT
        -1 as site_section_key,
        network_group_id,
        CAST(site_section_id AS STRING) as site_section_id,
        site_section_name,
        '' as standardized_app, '' as standardized_network, 
'' as standardized_platform, '' as standardized_platform_type, '' as standardized_owned_or_distributed, '' as standardized_stream_type 
    FROM fox_bi_prod.bronze_ads.freewheel_site_section""").toPandas()

# COMMAND ----------

new_records = table_data_df[~table_data_df['site_section_id'].isin(sheet_data_df['site_section_id'])]


# COMMAND ----------

if not new_records.empty:
  webhook_url = f'{adtech_infra_alerts}'
  google_worksheet_id = '<your_google_worksheet_id>'  # Replace with your actual worksheet ID

  headers = {'Content-type': 'application/json'}
  google_worksheet_id='1LwmAV8e5N8kf48hSo2ntbh0w2oFN3khlzx_GNmJycSw'
  payload = {'text': f"New Site Sections Found in Gsheet - https://docs.google.com/spreadsheets/d/{google_worksheet_id}"}

  response = requests.post(url=webhook_url, headers=headers, data=json.dumps(payload))

  if response.status_code == 200:
    print('Slack alert sent')
  else:
    print('Failed to send slack alert')

  webhook_url = f'{adrise_mapping_alerts}'
  response = requests.post(url=webhook_url, headers=headers, data=json.dumps(payload))
  
  if response.status_code == 200:
    print('Slack alert sent')
  else:
    print('Failed to send slack alert')
else:
  print("No new records found")

# COMMAND ----------

both_df = pd.concat([sheet_data_df, new_records]).reset_index(drop=True)
final_df = both_df.drop_duplicates(subset=['site_section_id'], keep='last')
final_df = final_df.fillna('')
cols = list(final_df.columns)
cols.remove('network_group_id')
reordered_cols = [cols[0], 'network_group_id'] + cols[1:]
final_df = final_df[reordered_cols]

# COMMAND ----------

display(final_df)

# COMMAND ----------

both_df = pd.concat([sheet_data_df, new_records]).reset_index(drop=True)
final_df = both_df.drop_duplicates(subset=['site_section_id'], keep='last')
final_df = final_df.fillna('')
print(google_sheet_range)
final_data_dict = final_df.to_dict('records')
clear_sheets(gsheet_service, google_worksheet_id, google_sheet_range)
update_sheet(gsheet_service, google_worksheet_id, google_sheet_range, final_data_dict)

# COMMAND ----------

# MAGIC %md GAM MAPPINGS

# COMMAND ----------

# Google Sheet Information
google_worksheet_id = '1LwmAV8e5N8kf48hSo2ntbh0w2oFN3khlzx_GNmJycSw'
google_sheet_range = 'GAM!A:N'


# # Get google service
gsheet_service = get_service(secret_data, google_scope_list, 'sheets')
sheet_data = gsheet_get_data(gsheet_service, google_worksheet_id, google_sheet_range)
sheet_data_dict = list_to_dict(sheet_data)
sheet_data_df = pd.DataFrame(sheet_data_dict)


# Identify if there are duplicate Site Section Id(s) in the Gsheet
is_duplicate_id = sheet_data_df['ad_unit_id'].duplicated().any()
duplicates = sheet_data_df[sheet_data_df['ad_unit_id'].duplicated()]
print(is_duplicate_id)


if is_duplicate_id:
  if len(duplicates) == 1:
    if duplicates['ad_unit_id'].iloc[0] == -1:
      print('No duplicates found in Gsheet')
  else:
    print("duplicates found")
    webhook_url = f'{adtech_infra_alerts}'

    headers = {'Content-type':'application/json'}
    payload = {'text':f'Duplicate Ad Unit ID Found in Gsheet - https://docs.google.com/spreadsheets/d/{google_worksheet_id}'}

    response = requests.post(url=webhook_url, headers=headers, data=json.dumps(payload))

    if response.status_code == 200:
      print('Slack alert sent')
    else:
      print('Failed to send slack alert')

    dbutils.notebook.exit("Duplicates site_section_id in google sheet.")

# COMMAND ----------

table_data_df = spark.sql("""
SELECT distinct 
ad_unit_name,
cast(-1 as bigint) as ad_unit_key, 
cast(ad_unit_id as string) as ad_unit_id, 
site_name,
platform_name as device_type_detail,
platform_group as device_type,
distributor_name as distributor,
'' as BU, 
'' as Platform, 
'' as Network, 
'' as App, 
'' as `Platform Type`, 
'' as owned_or_distributed,
'' as stream_type 
FROM fox_bi_prod.silver_ads.dim_ad_unit
where ad_category_name = 'Video' """).toPandas()

# COMMAND ----------

new_records = table_data_df[~table_data_df['ad_unit_id'].isin(sheet_data_df['ad_unit_id'])]
# Then drop duplicates again
new_records = new_records.drop_duplicates()

# COMMAND ----------

if not new_records.empty:
  webhook_url = f'{adtech_infra_alerts}'
  google_worksheet_id = '<your_google_worksheet_id>'  # Replace with your actual worksheet ID

  headers = {'Content-type': 'application/json'}
  google_worksheet_id='1LwmAV8e5N8kf48hSo2ntbh0w2oFN3khlzx_GNmJycSw'
  payload = {'text': f"New Ad Unit ID Found in Gsheet - https://docs.google.com/spreadsheets/d/{google_worksheet_id}"}

  response = requests.post(url=webhook_url, headers=headers, data=json.dumps(payload))

  if response.status_code == 200:
    print('Slack alert sent')
  else:
    print('Failed to send slack alert')

else:
  print("No new records found")

# COMMAND ----------

# Normalize column names (lowercase and strip) before combining
sheet_data_df.columns = sheet_data_df.columns.str.strip().str.lower()
new_records.columns = new_records.columns.str.strip().str.lower()

# Now concat will align the columns correctly
both_df = pd.concat([sheet_data_df, new_records], ignore_index=True)
final_df = both_df.drop_duplicates(subset=['ad_unit_id'], keep='last')
final_df = final_df.fillna('')
final_data_dict = final_df.to_dict('records')
print(len(final_df.columns))  # to see how many columns you're trying to write
clear_sheets(gsheet_service, google_worksheet_id, google_sheet_range)
update_sheet(gsheet_service, google_worksheet_id, google_sheet_range, final_data_dict)
