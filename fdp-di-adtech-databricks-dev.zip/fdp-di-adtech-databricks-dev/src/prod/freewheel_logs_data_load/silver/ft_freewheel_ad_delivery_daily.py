# Databricks notebook source
event_start_date = dbutils.jobs.taskValues.get("Set_Job_Parameters", "event_start_date_freewheel")
event_end_date = dbutils.jobs.taskValues.get("Set_Job_Parameters", "event_end_date_freewheel")
skip_freewheel = dbutils.jobs.taskValues.get("Set_Job_Parameters", "skip_freewheel")

# COMMAND ----------

spark.conf.set("spark.sql.shuffle.partitions", "auto")

# COMMAND ----------

print(f"Running for {event_start_date} to {event_end_date}")

# COMMAND ----------

if skip_freewheel == "true":
    dbutils.notebook.exit("Skipping Freewheel Daily")

# COMMAND ----------

# MAGIC %md PROCESSING LOGIC

# COMMAND ----------

from pyspark.sql import functions as F 
from pyspark.sql import types as T
from datetime import datetime, timedelta

# COMMAND ----------

# Load data sources from Unity Catalog
def load_table(table_name, schema_name="silver_ads"):
    return spark.read.table(f"fox_bi_prod.{schema_name}.{table_name}")

# COMMAND ----------

# DBTITLE 1,LOAD FW SOURCES
from datetime import datetime, timedelta
from pyspark.sql.functions import col, lit


def load_fw(event_start_date=None, event_end_date=None):
    """
    Loads 'ft_ad_delivery_slot_level_freewheel' with partition filters.
    """

    fw = (
        load_table("ft_freewheel_ad_delivery_slot_level_daily")
        .filter((col("event_date") >= lit(event_start_date)) & (col("event_date") <= lit(event_end_date)))
    )

    print(f"FW Partition Scan Range: '{event_end_date}' to '{event_end_date}'")
    return fw

# COMMAND ----------

# Load Source Table:
fw_slot_level = load_fw(event_start_date,event_end_date)

# COMMAND ----------

column_list = [
    "authority_code",
    "network_group_id",
    "event_date",
    "advertiser_id",
    "advertiser_name",
    "insertion_order_id",
    "insertion_order_name",
    "campaign_id",
    "campaign_name",
    "placement_id",
    "placement_name",
    "placement_type",
    "network",
    "site_section_id",
    "site_section_detail",
    "stream_type",
    "app_name",
    "distributor",
    "ownership_type",
    "device_type",
    "device_type_detail",
    "series_id",
    "series_name",
    "business_unit",
    "group_series_type",
    "video_asset_id",
    "video_asset_name",
    "sales_channel_type",
    "distribution_partner_id",
    "ad_unit_category",
    "ad_unit_format",
    "creative_id",
    "creative_pixel_size",
    "creative_name",
    "creative_duration_secs",
    "mrm_rule_id",
    "mrm_rule_name",
    "listing_id",
    "listing_name",
    "sold_order_id",
    "sold_order_name",
    "market_deal_id",
    "market_deal_name",
    "referrer_url",
    "country_name",
    "region_name",
    "metro_name",
    "city_name",
    "zip_code",
    "mrm_key_hash",
    "site_section_key_hash",
    "series_key_hash",
]


valid_break_key = F.when(
    F.col("slot_index") != -1,
    F.concat(F.col("transaction_id"), F.lit("-"), F.col("slot_index").cast("string"))
)

valid_complete_unfilled = F.when(
    (F.col("time_unfilled_secs") == F.col("max_duration_secs")) &
    ~((F.col("time_unfilled_secs") == 0) & (F.col("max_duration_secs") == 0)),
    1
)

# COMMAND ----------

fw_agg = fw_slot_level.groupBy(column_list).agg(
    F.sum(fw_slot_level.ad_requests).cast('bigint').alias("total_ad_requests"),
    F.sum(fw_slot_level.ad_responses).cast('bigint').alias("total_ad_responses"),
    F.sum(fw_slot_level.ad_impressions).cast('bigint').alias("total_ad_impressions"),
    F.sum(fw_slot_level.net_counted_ads).cast('bigint').alias("net_counted_ads"),
    F.sum(fw_slot_level.unfilled_impressions).cast('bigint').alias("total_unfilled_impressions"),
    F.sum(fw_slot_level.slot_impressions).cast('bigint').alias("total_slot_impressions"),
    F.sum(fw_slot_level.ad_clicks).cast('bigint').alias("total_ad_clicks"),
    F.round(F.avg(fw_slot_level.ad_click_through_rate),14).cast('double').alias("avg_ad_click_through_rate"),
    F.round(F.avg(fw_slot_level.ad_cost_per_click_usd),14).cast('double').alias("avg_ad_cost_per_click_usd"),
    F.round(F.sum(fw_slot_level.ad_revenue_usd),14).cast('double').alias("total_ad_revenue_usd"),
    F.round(F.avg(fw_slot_level.ad_cost_per_mile_usd),14).cast('double').alias("avg_ad_cost_per_mile_usd"),
    F.sum(fw_slot_level.unfilled_reseller_ad_slots).cast("bigint").alias("total_unfilled_reseller_ad_slots"),
    F.round(F.avg(fw_slot_level.max_ads), 14).cast("double").alias("avg_max_ads"),
    F.round(F.avg(fw_slot_level.max_duration_secs), 14).cast("double").alias("avg_max_duration_secs"),
    F.round(F.avg(fw_slot_level.ads_selected), 14).cast("double").alias("avg_ads_selected"),
    F.round(F.avg(fw_slot_level.ad_duration_secs), 14).cast("double").alias("avg_ad_duration_secs"),
    F.round(F.avg(fw_slot_level.time_filled_secs), 14).cast("double").alias("avg_time_filled_secs"),
    F.sum(fw_slot_level.max_ads).cast("bigint").alias("total_ads_allowed"),
    F.sum(fw_slot_level.ads_selected).cast("bigint").alias("total_ads_availed"),
    F.sum(fw_slot_level.max_duration_secs).cast("bigint").alias("total_ad_duration_allowed_secs"),
    F.sum(fw_slot_level.ad_duration_secs).cast("bigint").alias("total_ad_duration_availed_secs"),
    F.sum(fw_slot_level.time_filled_secs).cast("bigint").alias("total_ad_time_filled_secs"),
    F.sum(fw_slot_level.time_unfilled_secs).cast("bigint").alias("total_slate_duration_secs"),
    F.round(F.avg(fw_slot_level.time_unfilled_secs),14).cast("double").alias("avg_slate_duration_secs"),
    F.round(F.avg(fw_slot_level.slate_percentage),14).cast("double").alias("avg_slate_percentage"),
    F.round(F.avg(fw_slot_level.fill_rate),14).cast("double").alias("avg_fill_rate"),
    F.count(valid_complete_unfilled).alias("total_breaks_complete_unfilled"),
    F.countDistinct(valid_break_key).alias("total_breaks"),
    F.max(fw_slot_level.max_duration_secs).alias("max_max_duration_secs_internal")
)


# Step 2: Compute total_capacity and drop internal columns
fw_daily_level = fw_agg.withColumn(
    "total_capacity",
    (F.col("total_ad_requests") * F.col("max_max_duration_secs_internal")/15).cast("bigint")
).drop("max_max_duration_secs_internal")


fw_daily_level_with_percentage = fw_daily_level.withColumn(
    "percentage_of_ad_breaks_with_full_slate",
    F.round(
        F.when(
            F.col("total_breaks") > 0,
            (F.col("total_breaks_complete_unfilled").cast(T.DoubleType()) /
             F.col("total_breaks").cast(T.DoubleType())) * 100
        ),
        14
    ).cast("double")
)




# COMMAND ----------

from pyspark.sql.functions import current_timestamp

fw_daily_level_final = fw_daily_level_with_percentage.withColumn("etl_created_at_timestamp_utc", current_timestamp()) \
                                 .withColumn("etl_updated_at_timestamp_utc", current_timestamp())


# COMMAND ----------

fw_daily_level_final=fw_daily_level_final.withColumn("time_zone",F.lit("UTC"))


# COMMAND ----------

from pyspark.sql.functions import col

# Define the target table
target_table = "fox_bi_prod.silver_ads.ft_freewheel_ad_delivery_daily"

# Overwrite partitions dynamically based on event_date and network_group_id
(
    fw_daily_level_final.write.format("delta") \
    .mode('overwrite') \
    .option('partitionOverwriteMode', 'dynamic')\
    .saveAsTable(target_table)
)

print(f"Data successfully written to {target_table}")
