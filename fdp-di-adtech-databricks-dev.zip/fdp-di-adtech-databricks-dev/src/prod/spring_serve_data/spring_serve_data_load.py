# Databricks notebook source
# MAGIC %sh
# MAGIC aws configure set region us-west-2 --profile databricks-cpe-prod
# MAGIC aws configure set s3.signature_version s3v4 --profile databricks-cpe-prod
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile databricks-cpe-prod
# MAGIC aws configure set role_arn arn:aws:iam::501246562447:role/data-infra-astro-bi-adtech-prod --profile databricks-cpe-prod
# MAGIC
# MAGIC aws configure set region us-west-2 --profile fox-datahub-prod
# MAGIC aws configure set s3.signature_version s3v4 --profile fox-datahub-prod
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile fox-datahub-prod
# MAGIC aws configure set role_arn arn:aws:iam::745717147149:role/fng-fox-datahub-prod-databricks-ec2-role --profile fox-datahub-prod

# COMMAND ----------

from datetime import datetime, timedelta
import io
import boto3
import pandas as pd
import numpy as np
import traceback
import re
import traceback
from pyspark.sql.functions import regexp_replace, col, to_date, date_format
from delta.tables import DeltaTable

# COMMAND ----------

global catalog, raw_schema, bronze_schema, silver_schema
catalog = 'fox_bi_prod'
raw_schema = 'raw_ads'
bronze_schema = 'bronze_ads'
silver_schema = 'silver_ads'

# COMMAND ----------

def find_spring_serve_file(staq_bucket, file, report_date: datetime) -> str:

    global s3_client
    session = boto3.Session(profile_name=aws_profile)
    s3_client = session.client('s3')

    paginator = s3_client.get_paginator('list_objects_v2')
    page_iterator = paginator.paginate(Bucket=staq_bucket, Prefix=file)
    
    latest_file = None
    latest_modified = None

    for page in page_iterator:
      for obj in page.get('Contents', []):
        if file in obj['Key']:
          if latest_modified is None or obj['LastModified'] > latest_modified:
              latest_modified = obj['LastModified']
              latest_file = obj['Key']

    if latest_file:
        return latest_file

# COMMAND ----------

def read_spring_serve_file(staq_bucket, springserve_file):

    obj = s3_client.get_object(Bucket= staq_bucket, Key= springserve_file)
    df = pd.read_csv(io.BytesIO(obj['Body'].read()))
    raw_df = spark.createDataFrame(df)
    raw_df = raw_df.withColumn("impressions", regexp_replace(col("impressions"), ",", "").cast("int"))
    raw_df = raw_df.withColumn("revenue", regexp_replace(col("revenue"), ",", "").cast("double"))
    #spark_df = spark_df.withColumn("date", date_format(to_date(col("date"), "M/d/yyyy"), "yyyy-MM-dd"))
    return raw_df

# COMMAND ----------

def bronze_table_load(raw_df):
    global dates
    # Get unique dates from raw_df
    dates = [row["date"] for row in raw_df.select("date").distinct().collect()]

    # Delete existing records for those dates
    delta_table = DeltaTable.forName(spark, "{catalog}.{bronze_schema}.staq_spring_serve_data")
    delta_table.delete(col("date").isin(dates))

    # Insert new data
    raw_df.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("{catalog}.{bronze_schema}.staq_spring_serve_data")

# COMMAND ----------

def build_spring_serve_sql(full_load):
    # If full_load is True, no WHERE clause; else filter by dates
    where_clause = "" if full_load else f"WHERE date IN ({','.join([f'\'{d}\'' for d in dates])})"

    sql = f"""
        WITH ss_base AS (
        SELECT
            *,
            lower(supply_tag) AS supply_tag_l
        FROM {catalog}.{bronze_schema}.staq_spring_serve_data
        {where_clause}
        ),

        -- Platform
        platform_map AS (
            SELECT
                ss.supply_tag,
                cus.platform_name,
                cus.platform_group,
                ROW_NUMBER() OVER (PARTITION BY ss.supply_tag ORDER BY cus._row) rn
            FROM ss_base ss
            JOIN {catalog}.{raw_schema}.gam_gsheet_map_ad_platform cus
            ON ss.supply_tag_l LIKE concat('%', lower(cus.ad_unit_name), '%')
        ),

        -- Page Type
        page_type_map AS (
            SELECT
                ss.supply_tag,
                cus.page_type_name,
                ROW_NUMBER() OVER (PARTITION BY ss.supply_tag ORDER BY cus._row) rn
            FROM ss_base ss
            JOIN {catalog}.{raw_schema}.gam_gsheet_map_page_type cus
            ON ss.supply_tag_l LIKE concat('%', lower(CASE  WHEN ad_unit_name LIKE '%» %'
                                                            THEN split_part(ad_unit_name,'» ',2)
                                                            ELSE ad_unit_name
                                                      END), '%')
        ),

        -- Ad Category
        -- ad_category_map AS (
        --     SELECT
        --         ss.supply_tag,
        --         cus.ad_category_name,
        --         ROW_NUMBER() OVER (PARTITION BY ss.supply_tag ORDER BY cus._row) rn
        --     FROM ss_base ss
        --     JOIN {catalog}.{raw_schema}.gam_gsheet_map_adcategory cus
        --     ON ss.supply_tag_l LIKE concat('%', lower(cus.ad_unit_name), '%')
        -- ),

        -- Ad Format
        ad_format_map AS (
            SELECT
                ss.supply_tag,
                cus.ad_format_name,
                cus.ad_detail_name,
                ROW_NUMBER() OVER (PARTITION BY ss.supply_tag ORDER BY cus._row) rn
            FROM ss_base ss
            JOIN {catalog}.{raw_schema}.gam_gsheet_map_ad_format cus
            ON ss.supply_tag_l LIKE concat('%', lower(CASE  WHEN ad_unit_name LIKE '%» %'
                                                      THEN split_part(ad_unit_name,'» ',2)
                                                      ELSE ad_unit_name
                                                END), '%')
        ),

        -- Section
        section_map AS (
            SELECT
                ss.supply_tag,
                cus.section_name,
                ROW_NUMBER() OVER (PARTITION BY ss.supply_tag ORDER BY cus._row) rn
            FROM ss_base ss
            JOIN {catalog}.{raw_schema}.gam_gsheet_map_section cus
            ON ss.supply_tag_l LIKE concat('%', lower(cus.ad_unit_name), '%')
        ),

        -- Site
        site_map AS (
            SELECT
                ss.supply_tag,
                cus.site_name_abbreviation,
                cus.site_name,
                ROW_NUMBER() OVER (PARTITION BY ss.supply_tag ORDER BY cus._row) rn
            FROM ss_base ss
            JOIN {catalog}.{raw_schema}.gam_gsheet_map_site cus
            ON ss.supply_tag_l LIKE concat('%', lower(cus.ad_unit_name), '%')
        ),

        -- Distributor
        distributor_map AS (
            SELECT
                ss.supply_tag,
                cus.distributor,
                ROW_NUMBER() OVER (PARTITION BY ss.supply_tag ORDER BY cus._row) rn
            FROM ss_base ss
            JOIN {catalog}.{raw_schema}.gam_gsheet_map_distributor cus
            ON ss.supply_tag_l LIKE concat('%', lower(cus.ad_unit_name), '%')
        )

        SELECT
            ss.date AS event_date,
            year(ss.date) AS calendar_year,
            concat('FY',
                lpad(cast(
                    case when month(ss.date) >= 7 then year(ss.date)+1
                        else year(ss.date)
                    end % 100 as string),2,'0')
            ) AS fiscal_year,
            concat(
                'FY',
                lpad(cast(
                    case when month(ss.date) >= 7 then year(ss.date)+1
                        else year(ss.date)
                    end % 100 as string),2,'0'),
                'Q',
                case
                    when month(ss.date) between 7 and 9 then 1
                    when month(ss.date) between 10 and 12 then 2
                    when month(ss.date) between 1 and 3 then 3
                    else 4
                end
            ) AS fiscal_qtr,
            date_format(ss.date,'yyyyMM') AS month_id,
            date_format(ss.date,'yyyy MMM') AS month_name,
            ss.site AS site_name_source,
            ss.supply_router,
            'Spring Serve' AS source,
            'Spring Serve' AS ad_server,
            ss.supply_tag AS site_section_name,
            ss.demand_partner AS advertiser_name,
            'N' AS in_operative_flag,
            'N' AS social_flag,
            CASE WHEN ss.supply_tag_l LIKE '%now%' THEN 'Y' ELSE 'N' END AS is_fox_now_flag,
            af.ad_format_name,
            af.ad_detail_name,
            'Video' AS ad_category_name,
            pt.page_type_name,
            pl.platform_name,
            pl.platform_group,
            d.distributor,
            sc.section_name,
            st.site_name_abbreviation AS site,
            st.site_name,
            'Unknown' AS order_primary_team_name,
            'Programmatic' AS business_type,
            ss.impressions AS delivered_impressions,
            ss.revenue

        FROM ss_base ss
        LEFT JOIN platform_map pl
            ON ss.supply_tag = pl.supply_tag AND pl.rn = 1
        LEFT JOIN page_type_map pt
            ON ss.supply_tag = pt.supply_tag AND pt.rn = 1
        -- LEFT JOIN ad_category_map ac
        --     ON ss.supply_tag = ac.supply_tag AND ac.rn = 1
        LEFT JOIN ad_format_map af
            ON ss.supply_tag = af.supply_tag AND af.rn = 1
        LEFT JOIN section_map sc
            ON ss.supply_tag = sc.supply_tag AND sc.rn = 1
        LEFT JOIN site_map st
            ON ss.supply_tag = st.supply_tag AND st.rn = 1
        LEFT JOIN distributor_map d
            ON ss.supply_tag = d.supply_tag AND d.rn = 1
    """
    return sql

# COMMAND ----------

def silver_table_load(joined_df, full_load):
    if full_load:
        joined_df.write.format("delta").mode("overwrite").option("mergeSchema", "true").saveAsTable(f"{catalog}.{silver_schema}.ft_spring_serve")
    else:
        # Delete existing records for those dates
        delta_table_silver = DeltaTable.forName(spark, f"{catalog}.{silver_schema}.ft_spring_serve")
        delta_table_silver.delete(col("event_date").isin(dates))
        # Insert new data
        joined_df.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable(f"{catalog}.{silver_schema}.ft_spring_serve")

# COMMAND ----------

if __name__ == '__main__':
    global drop_bucket, aws_profile
    report_date = dbutils.widgets.get('report_date')
    aws_profile = dbutils.widgets.get('aws_profile')
    staq_bucket = dbutils.widgets.get('staq_bucket')
    folder = dbutils.widgets.get('folder')
    file_name = dbutils.widgets.get('file_name')
    no_of_days = dbutils.widgets.get('no_of_days')
    full_load = dbutils.widgets.get('full_load')

    def parse_date(report_date: str) -> bool:
        format = "%Y-%m-%d"
        try:
            res = bool(datetime.strptime(report_date, format))
        except ValueError:
            res = False
        return res

    assert parse_date(report_date), "Invalid date format, should be in YYYY-MM-DD format"
    report_date = datetime.strptime(report_date, "%Y-%m-%d")

    file = folder + file_name + report_date.strftime('%Y-%m-%d') 

    try:
        springserve_file = find_spring_serve_file(staq_bucket, file, report_date - timedelta(days=int(no_of_days)))
        print(springserve_file)
        raw_df = read_spring_serve_file(staq_bucket, springserve_file)
        bronze_table_load(raw_df)
        sql = build_spring_serve_sql(full_load)
        joined_df = spark.sql(sql)
        silver_table_load(joined_df, full_load)

    except Exception as error:
        error_details = traceback.format_exc()
        dbutils.notebook.exit(error_details)
        dbutils.notebook.exit(f'ERROR!!! - {error}')