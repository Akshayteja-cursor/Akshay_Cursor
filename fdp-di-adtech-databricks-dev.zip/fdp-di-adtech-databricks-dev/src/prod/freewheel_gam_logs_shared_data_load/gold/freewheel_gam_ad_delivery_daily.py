# Databricks notebook source
event_start_date_freewheel=dbutils.jobs.taskValues.get("Set_Job_Parameters",'event_start_date_freewheel')
event_end_date_freewheel=dbutils.jobs.taskValues.get("Set_Job_Parameters",'event_end_date_freewheel')

event_start_date_gam=dbutils.jobs.taskValues.get("Set_Job_Parameters",'event_start_date_gam')
event_end_date_gam=dbutils.jobs.taskValues.get("Set_Job_Parameters",'event_end_date_gam')

skip_freewheel=dbutils.jobs.taskValues.get("Set_Job_Parameters",'skip_freewheel')
skip_gam=dbutils.jobs.taskValues.get("Set_Job_Parameters",'skip_gam')

# COMMAND ----------

spark.conf.set("spark.sql.shuffle.partitions", "auto")

# COMMAND ----------

query_freewheel_select=f""" 

SELECT
ft.authority_code,
ft.network_group_id,
ft.event_date,
ft.time_zone,
ft.advertiser_id,
ft.advertiser_name,
ft.insertion_order_id,
ft.insertion_order_name,
ft.campaign_id as campaign_or_order_id,
ft.campaign_name as campaign_or_order_name,
ft.placement_id as placement_or_line_item_id,
ft.placement_name as placement_or_line_item_name,
ft.placement_type as placement_or_line_item_type,
ft.network as network_name,
ft.site_section_id as site_section_or_ad_unit_id,
ft.site_section_detail,
ft.stream_type,
ft.app_name,
ft.distributor as distributor_name,
ft.ownership_type,
ft.device_type,
ft.device_type_detail,
ft.series_id,
ft.series_name,
ft.business_unit,
ft.group_series_type,
ft.video_asset_id,
ft.video_asset_name,
ft.sales_channel_type,
ft.distribution_partner_id,
ft.ad_unit_category,
ft.ad_unit_format,
ft.creative_id,
ft.creative_pixel_size,
ft.creative_name,
ft.creative_duration_secs,
ft.mrm_rule_id,
ft.mrm_rule_name,
ft.listing_id,
ft.listing_name,
ft.sold_order_id,
ft.sold_order_name,
ft.market_deal_id,
ft.market_deal_name,
ft.referrer_url,
ft.country_name,
ft.region_name,
ft.metro_name,
ft.city_name,
ft.zip_code,
NULL AS is_video_ad_fallback_request,
-1 AS video_ad_fallback_position,
NULL AS is_companion_ad,
-1 as line_item_key_hash,
-1 as content_key_hash,
ft.site_section_key_hash,
ft.mrm_key_hash,
ft.series_key_hash,

--METRICS
ft.total_ad_requests,
NULL:: BIGINT AS total_unmatched_ad_requests,
ft.total_ad_responses,
ft.total_ad_impressions,
ft.net_counted_ads,
ft.total_unfilled_impressions,
ft.total_slot_impressions,
ft.total_ad_clicks,
ft.avg_ad_click_through_rate,
ft.avg_ad_cost_per_click_usd,
ft.total_ad_revenue_usd,
ft.avg_ad_cost_per_mile_usd,
ft.total_unfilled_reseller_ad_slots,
ft.avg_max_ads,
ft.avg_max_duration_secs,
ft.avg_ads_selected,
ft.avg_ad_duration_secs,
ft.avg_time_filled_secs,
ft.total_ads_allowed,
ft.total_ads_availed,
ft.total_ad_duration_allowed_secs,
ft.total_ad_duration_availed_secs,
ft.total_ad_time_filled_secs,
ft.total_slate_duration_secs,
ft.avg_slate_duration_secs,
ft.avg_slate_percentage,
ft.avg_fill_rate,
ft.total_breaks_complete_unfilled,
ft.total_breaks,
NULL::BIGINT as total_error_count,
ft.percentage_of_ad_breaks_with_full_slate,
ft.total_capacity,
CURRENT_TIMESTAMP AS etl_created_at_timestamp_utc,
CURRENT_TIMESTAMP AS etl_updated_at_timestamp_utc

from
fox_bi_prod.SILVER_ADS.FT_FREEWHEEL_AD_DELIVERY_daily ft

WHERE event_date>='{event_start_date_freewheel}' and event_date<='{event_end_date_freewheel}'
"""


if skip_freewheel=='true':
  query_freewheel_filter=""" AND 1=0 """
else:
  query_freewheel_filter =""" AND 1=1 """

query_freewheel_final=query_freewheel_select+query_freewheel_filter

# COMMAND ----------

query_gam_select=f"""

SELECT
ft.authority_code,
ft.network_group_id,
ft.event_date,
ft.time_zone,
ft.advertiser_id,
ft.advertiser_name,
-1 as insertion_order_id,
'N/A' AS insertion_order_name,
ft.order_id as campaign_or_order_id,
ft.order_name as campaign_or_order_name,
ft.line_item_id as placement_or_line_item_id,
ft.line_item_name as placement_or_line_item_name,
ft.line_item_type as placement_or_line_item_type,
ft.network as network_name,
ft.ad_unit_id as site_section_or_ad_unit_id,
ft.site_section_detail,
'N/A' as stream_type,
ft.app_name,
ft.distributor as distributor_name,
ft.ownership_type,
ft.device_type,
ft.device_type_detail,
ft.series_id,
ft.series_name,
ft.business_unit,
'N/A' AS group_series_type,
ft.video_asset_id,
ft.video_asset_name,
ft.sales_channel_type,
ft.distribution_partner_id,
ft.ad_unit_category,
ft.ad_unit_format,
ft.creative_id,
ft.creative_pixel_size,
ft.creative_name,
-1 as creative_duration_secs,
-1 as mrm_rule_id,
'N/A' as mrm_rule_name,
'-1' as listing_id,
'N/A' as listing_name,
-1 as sold_order_id,
'NA' as sold_order_name,
'-1' as market_deal_id,
'N/A' as market_deal_name,
ft.referrer_url,
ft.country_name,
ft.region_name,
ft.metro_name,
ft.city_name,
ft.postal_code as zip_code,
ft.is_video_ad_fallback_request,
ft.video_ad_fallback_position,
ft.is_companion_ad,
ft.line_item_key_hash,
ft.content_key_hash,
-1 as site_section_key_hash,
-1 as mrm_key_hash,
-1 as series_key_hash,



--METRICS
ft.total_ad_requests,
ft.total_unmatched_ad_requests,
ft.total_ad_responses,
ft.total_ad_impressions,
NULL:: BIGINT AS net_counted_ads,
ft.total_unfilled_impressions,
NULL:: BIGINT AS total_slot_impressions,
ft.total_ad_clicks,
ft.avg_ad_click_through_rate,
ft.avg_ad_cost_per_click_usd,
ft.total_ad_revenue_usd,
ft.avg_ad_cost_per_mile_usd,
NULL:: BIGINT AS total_unfilled_reseller_ad_slots,
ft.avg_max_ads,
ft.avg_max_duration_secs,
ft.avg_ads_selected,
ft.avg_ad_duration_secs,
ft.avg_time_filled_secs,
ft.total_ads_allowed,
ft.total_ads_availed,
ft.total_ad_duration_allowed_secs,
ft.total_ad_duration_availed_secs,
ft.total_ad_time_filled_secs,
ft.total_slate_duration_secs,
ft.avg_slate_duration_secs,
ft.avg_slate_percentage,
ft.avg_fill_rate,
ft.total_breaks_complete_unfilled,
ft.total_breaks,
ft.total_error_count,
ft.percentage_of_ad_breaks_with_full_slate,
ft.total_capacity,
CURRENT_TIMESTAMP AS etl_created_at_timestamp_utc,
CURRENT_TIMESTAMP AS etl_updated_at_timestamp_utc

from
fox_bi_prod.SILVER_ADS.FT_GAM_AD_DELIVERY_DAILY ft

WHERE event_date>='{event_start_date_gam}' and event_date<='{event_end_date_gam}'
"""


if skip_gam=='true':
  query_gam_filter=""" AND 1=0 """
else:
  query_gam_filter =""" AND 1=1 """

query_gam_final=query_gam_select+query_gam_filter

# COMMAND ----------

query_final=query_freewheel_final +""" 

UNION 

"""+query_gam_final

# COMMAND ----------

print(query_final)

# COMMAND ----------

df=spark.sql(query_final)

# COMMAND ----------

df.write.format('delta') \
  .mode('overwrite')\
  .option('partitionOverwriteMode', 'dynamic')\
  .saveAsTable("fox_bi_prod.gold_ads.ft_ad_delivery_daily")