# Databricks notebook source
from_email=dbutils.jobs.taskValues.get("Set_Job_Parameters",'from_email')
aws_profile=dbutils.jobs.taskValues.get("Set_Job_Parameters",'aws_profile')
aws_arn=dbutils.jobs.taskValues.get("Set_Job_Parameters",'aws_arn')

# COMMAND ----------

# make the variable available to shell
import os
os.environ["AWS_PROFILE_VAR"] = aws_profile
os.environ["AWS_ARN"] = aws_arn

# COMMAND ----------

# MAGIC %sh
# MAGIC aws configure set region us-west-2 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set s3.signature_version s3v4 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile $AWS_PROFILE_VAR
# MAGIC aws configure set role_arn $AWS_ARN --profile $AWS_PROFILE_VAR

# COMMAND ----------

import boto3
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

def send_email(subject, html_body, to_addresses, cc_addresses, from_address, aws_profile=f'{aws_profile}', aws_region='us-west-2'):
    msg = MIMEMultipart()
    msg['Subject'] = subject
    msg['From'] = from_address
    msg['To'] = ", ".join(to_addresses)
    msg['Cc'] = ", ".join(cc_addresses)

    # Add HTML body
    msg.attach(MIMEText(html_body, 'html'))

    # Send email
    session = boto3.Session(profile_name=aws_profile)
    ses = session.client('ses', region_name=aws_region)

    ses.send_raw_email(
        Source=from_address,
        Destinations=to_addresses + cc_addresses,
        RawMessage={'Data': msg.as_string()}
    )

    print("Email sent successfully")

# COMMAND ----------

df_freewheel=spark.sql("""SELECT "source system" as source_system,
        case when network_group_id =516429 then 'Fox Corporation - Live'
                when network_group_id =500763 then 'Fox Affiliates Live' end  network_group_name ,
        ft.event_date AS event_date,
        SUM(total_ad_impressions) AS gross_counted_impressions,
        SUM(net_counted_ads) as net_counted_impressions
FROM fox_bi_prod.gold_ads.ft_ad_delivery_daily ft
WHERE lower(ft.authority_code) = 'freewheel' and event_date >=current_date()-7
GROUP BY 1,2,3""")

# COMMAND ----------

display(df_freewheel)

# COMMAND ----------

df_interface_516429=spark.sql("""select
`Network Name` as network_name,
TO_DATE(`Event Date`, 'MM/dd/yyyy') AS event_date,
CAST(REPLACE(`Gross Counted Ads`, ',', '') AS BIGINT) as gross_counted_ads,
CAST(REPLACE(`Net Counted Ads`, ',', '') AS BIGINT) as net_counted_ads
from 
fox_bi_prod.raw_ads.freewheel_s3_reconciliation_manifest_516429_fox_corp
WHERE TO_DATE(`Event Date`, 'MM/dd/yyyy') >= current_date()-7""")


df_interface_500763=spark.sql("""select
`Network Name` as network_name,
TO_DATE(`Event Date`, 'MM/dd/yyyy') AS event_date,
CAST(REPLACE(`Gross Counted Ads`, ',', '') AS BIGINT) as gross_counted_ads,
CAST(REPLACE(`Net Counted Ads`, ',', '') AS BIGINT) as net_counted_ads
from 
fox_bi_prod.raw_ads.freewheel_s3_reconciliation_manifest_500763_fox_affiliates
WHERE TO_DATE(`Event Date`, 'MM/dd/yyyy') >= current_date()-7""")

df_interface=df_interface_516429.union(df_interface_500763).dropDuplicates()

# COMMAND ----------

display(df_interface)

# COMMAND ----------

from pyspark.sql.functions import abs as ps_abs, col, round as ps_round

# 1. Join and calculate ads_variance_percentage
df_joined = df_freewheel.alias("gold").join(
    df_interface.alias("fw_ui"),
    on=[
        col("gold.event_date") == col("fw_ui.event_date"),
        col("gold.network_group_name") == col("fw_ui.network_name")
    ],
    how="inner"
).select(
    col("gold.network_group_name").alias("network_group_name"),
    col("gold.event_date").alias("event_date"),
    col("fw_ui.gross_counted_ads"),
    col("fw_ui.net_counted_ads"),
    col("gold.gross_counted_impressions"),
    col("gold.net_counted_impressions"),
    ps_round(ps_abs(
        ((col("fw_ui.gross_counted_ads") - col("gold.gross_counted_impressions")).cast("float")
        / col("fw_ui.gross_counted_ads").cast("float")) * 100
    ), 2).alias("gross_counted_ads_variance_percentage"),
    ps_round(ps_abs(
        ((col("fw_ui.net_counted_ads") - col("gold.net_counted_impressions")).cast("float")
        / col("fw_ui.net_counted_ads").cast("float")) * 100
    ), 2).alias("net_counted_ads_variance_percentage")
).filter(col('net_counted_ads_variance_percentage').isNotNull()).dropDuplicates()


# COMMAND ----------

display(df_joined)

# COMMAND ----------

# Collect for formatting
report_rows = df_joined.orderBy("event_date", "network_group_name").collect()

# Format as HTML table
html_table = """
<table border="1" cellpadding="4" cellspacing="0" style="border-collapse: collapse;">
<tr>
<th>network_group_name</th>
<th>event_date</th>
<th>gross_counted_ads</th>
<th>net_counted_ads</th>
<th>gross_counted_impressions</th>
<th>net_counted_impressions</th>
<th>gross_counted_ads_variance_percentage</th>
<th>net_counted_ads_variance_percentage</th>
</tr>
"""

for row in report_rows:
    html_table += f"""
    <tr>
        <td>{row['network_group_name']}</td>
        <td>{row['event_date'].strftime('%m/%d/%Y')}</td>
        <td>{row['gross_counted_ads']}</td>
        <td>{row['net_counted_ads']}</td>
        <td>{row['gross_counted_impressions']}</td>
        <td>{row['net_counted_impressions']}</td>
        <td>{row['gross_counted_ads_variance_percentage']}</td>
        <td>{row['net_counted_ads_variance_percentage']}</td>
    </tr>
    """

html_table += "</table>"

# Compose final body
html_body = f"""
<p>Hi Team,</p>
<p>Below is the validation between Freewheel UI and Gold Layer in  Databricks (Prod).</p>
<p><b>Freewheel Validation Report</b></p>
{html_table}
<p>Regards,<br>AdTech Team</p>
"""

# Send it
send_email(
    subject="Freewheel Validation Report from Databricks Prod",
    html_body=html_body,
    to_addresses=["data_adtech@fox.com"],
    cc_addresses=[],
    from_address=f"{from_email}",
    aws_profile=f"{aws_profile}"
)