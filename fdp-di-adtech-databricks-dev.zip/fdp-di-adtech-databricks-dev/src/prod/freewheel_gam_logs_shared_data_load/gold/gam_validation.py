# Databricks notebook source
from_email=dbutils.jobs.taskValues.get("Set_Job_Parameters",'from_email')
aws_profile=dbutils.jobs.taskValues.get("Set_Job_Parameters",'aws_profile')
aws_arn=dbutils.jobs.taskValues.get("Set_Job_Parameters",'aws_arn')

# COMMAND ----------

# make the variable available to shell
import os
os.environ["AWS_PROFILE_VAR"] = aws_profile
os.environ["AWS_ARN"] = aws_arn

# COMMAND ----------

# MAGIC %sh
# MAGIC aws configure set region us-west-2 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set s3.signature_version s3v4 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile $AWS_PROFILE_VAR
# MAGIC aws configure set role_arn $AWS_ARN --profile $AWS_PROFILE_VAR

# COMMAND ----------

import boto3
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

def send_email(subject, html_body, to_addresses, cc_addresses, from_address, aws_profile=f'{aws_profile}', aws_region='us-west-2'):
    msg = MIMEMultipart()
    msg['Subject'] = subject
    msg['From'] = from_address
    msg['To'] = ", ".join(to_addresses)
    msg['Cc'] = ", ".join(cc_addresses)

    # Add HTML body
    msg.attach(MIMEText(html_body, 'html'))

    # Send email
    session = boto3.Session(profile_name=aws_profile)
    ses = session.client('ses', region_name=aws_region)

    ses.send_raw_email(
        Source=from_address,
        Destinations=to_addresses + cc_addresses,
        RawMessage={'Data': msg.as_string()}
    )

    print("Email sent successfully")

# COMMAND ----------

query="""
SELECT
"source system" AS source_system,
event_date as event_date,
SUM(total_ad_impressions) AS total_ad_impressions,
SUM(total_ad_impressions)::float/sum(total_ad_requests) as avg_fill_rate,
SUM(total_ad_requests) AS total_ad_requests,
SUM(total_ad_responses) AS total_ad_responses,
SUM(total_ad_revenue_usd) as total_ad_revenue,
SUM(total_ad_revenue_usd)::float/sum(total_ad_impressions) as avg_ad_cpm,
SUM(total_ad_clicks) AS total_ad_clicks,
SUM(avg_ad_click_through_rate) as avg_ad_click_through_rate
from
fox_bi_prod.gold_ads.ft_ad_delivery_daily
where
lower(authority_code) = 'gam' and event_date >= CURRENT_DATE() - INTERVAL 30 DAYS
GROUP BY 1,2
"""

df_gam=spark.sql(query)

# COMMAND ----------

display(df_gam)

# COMMAND ----------

query="""select
dimension_date AS event_date,
column_total_line_item_level_impressions AS  total_ad_impressions,
(column_total_fill_rate :: decimal(31,14)) AS avg_fill_rate,
column_total_ad_requests AS total_ad_requests,
column_total_responses_served  AS total_ad_responses,
(column_total_line_item_level_cpm_and_cpc_revenue/1000000) :: float AS total_ad_revenue,
((column_total_line_item_level_cpm_and_cpc_revenue:: float) /column_total_line_item_level_impressions :: float)/1000000 AS avg_ad_cpm,
column_total_line_item_level_clicks AS total_ad_clicks,
column_total_line_item_level_ctr :: float AS avg_ad_click_thru_rate
--total_unmatched_ad_requests AS total_unmatched_ad_request
from fox_bi_prod.raw_ads.gam_reconciliation_manifest

where dimension_date >=CURRENT_DATE() - INTERVAL 30 DAYS
"""

df_interface=spark.sql(query)

# COMMAND ----------

display(df_interface)

# COMMAND ----------

from pyspark.sql.functions import col, abs as ps_abs, round as ps_round

# Join and compute variances
df_joined = df_interface.alias("ui").join(
    df_gam.alias("gold"),
    on=col("ui.event_date") == col("gold.event_date"),
    how="inner"
).select(
    col("ui.event_date"),
    ps_round(ps_abs((col("ui.total_ad_impressions") - col("gold.total_ad_impressions")) / col("ui.total_ad_impressions") * 100), 2).alias("ad_imps_variance_percentage"),
    ps_round(ps_abs((col("ui.avg_fill_rate") - col("gold.avg_fill_rate")) / col("ui.avg_fill_rate") * 100), 2).alias("fill_rate_variance_percentage"),
    ps_round(ps_abs((col("ui.total_ad_requests") - col("gold.total_ad_requests")) / col("ui.total_ad_requests") * 100), 2).alias("ad_req_variance_percentage"),
    ps_round(ps_abs((col("ui.total_ad_responses") - col("gold.total_ad_responses")) / col("ui.total_ad_responses") * 100), 2).alias("ad_res_variance_percentage"),
    ps_round(ps_abs((col("ui.total_ad_revenue") - col("gold.total_ad_revenue")) / col("ui.total_ad_revenue") * 100), 2).alias("ad_revenue_variance_percentage"),
    ps_round(ps_abs((col("ui.avg_ad_cpm") - col("gold.avg_ad_cpm")) / col("ui.avg_ad_cpm") * 100), 2).alias("ad_cpm_variance_percentage"),
    ps_round(ps_abs((col("ui.total_ad_clicks") - col("gold.total_ad_clicks")) / col("ui.total_ad_clicks") * 100), 2).alias("ad_clicks_variance_percentage"),
    ps_round(ps_abs((col("ui.avg_ad_click_thru_rate") - col("gold.avg_ad_click_through_rate")) / col("ui.avg_ad_click_thru_rate") * 100), 2).alias("ad_ctr_variance_percentage")
)

# COMMAND ----------

display(df_joined)

# COMMAND ----------

# Collect results
rows = df_joined.orderBy("event_date").collect()

# Format HTML table
html_table = """
<table border="1" cellpadding="4" cellspacing="0" style="border-collapse: collapse;">
<tr>
<th>event_date</th>
<th>ad_imps_variance_percentage</th>
<th>fill_rate_variance_percentage</th>
<th>ad_req_variance_percentage</th>
<th>ad_res_variance_percentage</th>
<th>ad_revenue_variance_percentage</th>
<th>ad_cpm_variance_percentage</th>
<th>ad_clicks_variance_percentage</th>
<th>ad_ctr_variance_percentage</th>
</tr>
"""

for row in rows:
    html_table += f"""
    <tr>
        <td>{row['event_date'].strftime('%Y-%m-%d')}</td>
        <td>{row['ad_imps_variance_percentage']}</td>
        <td>{row['fill_rate_variance_percentage']}</td>
        <td>{row['ad_req_variance_percentage']}</td>
        <td>{row['ad_res_variance_percentage']}</td>
        <td>{row['ad_revenue_variance_percentage']}</td>
        <td>{row['ad_cpm_variance_percentage']}</td>
        <td>{row['ad_clicks_variance_percentage']}</td>
        <td>{'{:.2e}'.format(row['ad_ctr_variance_percentage'])}</td>  <!-- SCIENTIFIC NOTATION -->
    </tr>
    """

html_table += "</table>"

# Final email body
html_body = f"""
<p>Hi Team,</p>
<p>Below is the validation between Gam UI and Gold Layer in Databricks (Prod).</p>
<p><b>Gam Validation Report</b></p>
{html_table}
<p>Regards,<br>AdTech Team</p>
"""

# COMMAND ----------

send_email(
    subject="Gam Validation Report From Databricks Prod",
    html_body=html_body,
    to_addresses=["data_adtech@fox.com"],
    cc_addresses=[],
    from_address=f"{from_email}",
    aws_profile=f"{aws_profile}"
)
