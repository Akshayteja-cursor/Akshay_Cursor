# Databricks notebook source
fts_delivery_config={
"dev": {
'catalog' : 'fox_bi_dev',
'raw_schema':'raw_ads',
'bronze_schema':'bronze_ads',
'silver_schema':'silver_ads',
'gold_schema' : 'gold_ads',
'from_email':'adtech.dev@data.fox',
'to_mail':["yogesh.nageswararao@fox.com", "narendra.pedakoleme@fox.com"],
'cc_mail':[
                 "Anitha.Mohanraj@fox.com",
                 "alex.lehman@fox.com",
                 "Pradeep.Panneerselvam@fox.com"           
            ]
  },
"prod": {
'catalog' : 'fox_bi_prod',
'raw_schema':'raw_ads',
'bronze_schema':'bronze_ads',
'silver_schema':'silver_ads',
'gold_schema' : 'gold_ads',
'from_email':'adtech.prod@data.fox',
'to_mail':["yogesh.nageswararao@fox.com","Anitha.Mohanraj@fox.com","data_adtech@fox.com",
                 "alex.lehman@fox.com"
                ],
'cc_mail':[
                 "FTSRevenueOps@fox.com",
                 "Kyle.Wood@fox.com",
                 "Eric.Olivencia@fox.com",
                 "Pradeep.Panneerselvam@fox.com",
                 "Allison.Katz@fox.com",
                 "kimberly.perkins@fox.com"
            ]
  },
}

