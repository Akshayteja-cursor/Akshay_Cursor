# Databricks notebook source
from pyspark.sql import functions as F
from pyspark.sql import types as T
from datetime import datetime, timedelta

# COMMAND ----------

query = f"""
    SELECT
        /*+ BROADCAST(pl, cr) */
        ft.event_date
        , ft.placement_id
        , pl.placement_external_id
        , pl.placement_name
        , pl.placement_start_timestamp_est
        , pl.placement_end_timestamp_est
        , pl.placement_industry
        , pl.placement_type
        , pl.placement_budget_model
        , pl.placement_forced_over_delivery_percent
        , pl.placement_pacing
        , pl.placement_priority
        , pl.unified_yield_name
        , pl.placement_status
        , pl.placement_budgeted_impressions
        , pl.placement_impression_goal
        , pl.placement_estimated_impression_goal
        , pl.placement_avg_user_frequency
        , ft.creative_id
        , cr.creative_external_id
        , cr.creative_name
        , cr.creative_duration_secs
        , SUM(ft.net_counted_ads) AS net_counted_ads
        , SUM(ft.delivered_clicks) AS delivered_clicks
        , DATE_FORMAT(ft.event_date, 'MM') as event_month
        , DATE_FORMAT(ft.event_date, "y-'Q'Q") as event_quarter
        , DATE_FORMAT(ft.event_date, 'y') as event_year
        , event_year||event_month as ad_month_id
        , DATE_FORMAT(ft.event_date, 'MMMM-y') as ad_month_year
        , DATE_FORMAT(CURRENT_TIMESTAMP(), 'yyyy-MM-dd') AS etl_load_date
        , CURRENT_TIMESTAMP() AS etl_load_timestamp
    FROM fox_bi_dev.bronze_ads.freewheel_analytics_fox_affiliates_direct_sold_delivery ft
    LEFT JOIN fox_bi_dev.silver_ads.dim_freewheel_analytics_fox_affiliates_placement pl
    ON ft.placement_id = pl.placement_id
    LEFT JOIN fox_bi_dev.silver_ads.dim_freewheel_analytics_fox_affiliates_creative cr
    ON ft.creative_id = cr.creative_id
    GROUP BY
        ft.event_date
        , ft.placement_id
        , pl.placement_external_id
        , pl.placement_name
        , pl.placement_start_timestamp_est
        , pl.placement_end_timestamp_est
        , pl.placement_industry
        , pl.placement_type
        , pl.placement_budget_model
        , pl.placement_forced_over_delivery_percent
        , pl.placement_pacing
        , pl.placement_priority
        , pl.unified_yield_name
        , pl.placement_status
        , pl.placement_budgeted_impressions
        , pl.placement_impression_goal
        , pl.placement_estimated_impression_goal
        , pl.placement_avg_user_frequency
        , ft.creative_id
        , cr.creative_external_id
        , cr.creative_name
        , cr.creative_duration_secs
"""

fox_affiliates_direct_sold_delivery = spark.sql(query)

# COMMAND ----------

if not spark.catalog.tableExists(f'fox_bi_dev.silver_ads.ft_freewheel_fox_affiliates_direct_sold_delivery_daily_data'): #Add the table name for First time load 
    fox_affiliates_direct_sold_delivery.write.format('delta')\
        .mode('overwrite')\
        .partitionBy('event_date')\
        .option('mergeSchema', 'true')\
        .option('overwriteDynamicPartitions', 'true')\
        .option('delta.enableDeletionVectors', 'false')\
        .option('delta.enableIcebergCompatV2', 'true')\
        .option('delta.universalFormat.enabledFormats', 'iceberg')\
        .option('delta.columnMapping.mode', 'name')\
        .saveAsTable('fox_bi_dev.silver_ads.ft_freewheel_fox_affiliates_direct_sold_delivery_daily_data')
else:
    fox_affiliates_direct_sold_delivery.write.format('delta')\
        .mode('overwrite')\
        .option('partitionOverwriteMode', 'dynamic')\
        .saveAsTable('fox_bi_dev.silver_ads.ft_freewheel_fox_affiliates_direct_sold_delivery_daily_data')

# COMMAND ----------

# MAGIC %sql
# MAGIC select event_date, count(*) from fox_bi_dev.silver_ads.ft_freewheel_fox_affiliates_direct_sold_delivery_daily_data group by event_date order by event_date