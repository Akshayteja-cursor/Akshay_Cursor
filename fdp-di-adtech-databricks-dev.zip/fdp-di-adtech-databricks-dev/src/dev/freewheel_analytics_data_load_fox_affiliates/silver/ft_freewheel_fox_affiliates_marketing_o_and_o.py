# Databricks notebook source
from pyspark.sql import functions as F
from pyspark.sql import types as T
from datetime import datetime, timedelta

# COMMAND ----------

query = f"""
    SELECT
        event_date,
        SUM(net_counted_ads) AS net_counted_ads
    FROM fox_bi_dev.bronze_ads.freewheel_analytics_marketing_o_and_o ft
    GROUP BY 1
"""

ft_fw_marketing_o_and_o=spark.sql(query)

# COMMAND ----------

ft_fw_marketing_o_and_o.write.format('delta')\
    .mode('overwrite')\
    .option('partitionOverwriteMode', 'dynamic')\
    .saveAsTable('fox_bi_dev.silver_ads.ft_freewheel_fox_affiliates_maketing_o_and_o')