# Databricks notebook source
import configparser
from io import BytesIO
from datetime import datetime,timedelta
from pyspark.sql.types import StructType, StructField, DateType, LongType
import pytz
import boto3
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, coalesce, when,abs,lit
import pandas as pd
import os
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
%pip install googleads
from googleads import ad_manager, oauth2, errors
from typing import Any
import json
import tempfile
import time
import pyspark.sql.types as T
import pyspark.sql.functions as F
from pyspark import SparkFiles
import io
from email import encoders
from email.mime.text import MIMEText  
from email.mime.image import MIMEImage

# COMMAND ----------

spark.conf.set("spark.sql.session.timeZone", "UTC")

# COMMAND ----------

# MAGIC %run ./fts_delivery_config

# COMMAND ----------

dbutils.widgets.text("aws_profile", "")
dbutils.widgets.text("aws_arn", "")
aws_profile=dbutils.widgets.get('aws_profile')
aws_arn=dbutils.widgets.get('aws_arn')
dbutils.widgets.text("env", "")
env = dbutils.widgets.get("env")
gam_service_account_creds_secret_arn = dbutils.widgets.text('gam_service_account_creds_secret_arn','')
gam_api_version = dbutils.widgets.text('gam_api_version','')
gam_service_account_creds_secret_arn = dbutils.widgets.get('gam_service_account_creds_secret_arn')
gam_api_version = dbutils.widgets.get('gam_api_version')


# COMMAND ----------

import os
os.environ["AWS_PROFILE_VAR"] = aws_profile
os.environ["AWS_ARN"] = aws_arn

# COMMAND ----------

# MAGIC %sh
# MAGIC aws configure set region us-west-2 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set s3.signature_version s3v4 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile $AWS_PROFILE_VAR
# MAGIC aws configure set role_arn $AWS_ARN --profile $AWS_PROFILE_VAR
# MAGIC

# COMMAND ----------

config = configparser.ConfigParser()
dbutils.widgets.text("env", "")
env = dbutils.widgets.get("env")
config = fts_delivery_config[env]
display(config)
catalog=config['catalog']
silver_schema=config['silver_schema']
gold_schema=config['gold_schema']
bronze_schema = config['bronze_schema']
from_email = config['from_email']
raw_schema = config['raw_schema']
cc_mail = config['cc_mail']
to_mail = config['to_mail']
lucid_id = config['lucid_id']
ad_sales_catalog = config['ad_sales_catalog']


# COMMAND ----------

missing_file_alert = []
miss_match_count = {}
madhive = True
dvps=True


# COMMAND ----------

# MAGIC %md
# MAGIC ##Email Notifications

# COMMAND ----------

def build_excel_and_send_mail(
        # source_validation_config,
        validation_config,
        missing_file_alert,
        from_email,
        to_mail,
        cc_mail,
        aws_profile,
        s3_bucket
):

    session = boto3.Session(profile_name=aws_profile)
    s3 = session.client("s3")
    ses = session.client("ses", region_name="us-west-2")

    # --------------------------------------------------
    # Common Sheet Writer
    # --------------------------------------------------
    def write_sheet(writer, df, sheet_name):
        if df.rdd.isEmpty():
            # print(f"{sheet_name} : DF empty → writing headers only")
            columns = df.columns   
            pdf = pd.DataFrame(columns=columns)
        else:
            pdf = df.toPandas()
        pdf.to_excel(writer, index=False, sheet_name=sheet_name)

        ws = writer.sheets[sheet_name]
        for i, col in enumerate(pdf.columns):
            if len(pdf) == 0:
                width = len(col) + 2   
            else:
                width = max(pdf[col].astype(str).map(len).max(), len(col))
            ws.set_column(i, i, width)

    # --------------------------------------------------
    # Create Source Excel in Memory
    # --------------------------------------------------
    # file_name = f"FTS_delivery_source_validation_report_{datetime.today().strftime('%Y-%m-%d')}.xlsx"
    # source_buffer = BytesIO()

    # with pd.ExcelWriter(source_buffer, engine="xlsxwriter") as writer:
    #     for cfg in source_validation_config.values():
    #         write_sheet(writer, cfg["df"], cfg["sheet"])

    # source_buffer.seek(0)

    # Upload to S3
    # source_key = f"fts_delivery_validation_reports/{file_name}"
    # s3.put_object(Bucket=s3_bucket, Key=source_key, Body=source_buffer.getvalue())

    # print(f"Uploaded Source Excel to s3://{s3_bucket}/{source_key}")
   
    # --------------------------------------------------
    # Create Tableau Excel in Memory
    # --------------------------------------------------
    tableau_file_name = f"Tableau_vs_FTS_Delivery_validation_{datetime.today().strftime('%Y-%m-%d')}.xlsx"
    tableau_buffer = BytesIO()

    with pd.ExcelWriter(tableau_buffer, engine="xlsxwriter") as writer:
        for cfg in validation_config.values():
            write_sheet(writer, cfg["df"], cfg["sheet"])

    tableau_buffer.seek(0)

    tableau_key = f"fts_delivery_validation_reports/{tableau_file_name}"
    s3.put_object(Bucket=s3_bucket, Key=tableau_key, Body=tableau_buffer.getvalue())

    # print(f"Uploaded Tableau Excel to s3://{s3_bucket}/{tableau_key}")

    # --------------------------------------------------
    # BUILD EMAIL BODY
    # --------------------------------------------------
    html_body = """
            <p>Hi Team,</p>

            <p>Please find attached the latest <b>FTS Delivery Validation</b> report</p>
            """

    # Missing files section
    if missing_file_alert:
        html_body += "<p><b>⚠ Missing Files/Data:</b></p><ul>"
        for msg in missing_file_alert:
            html_body += f"<li><b>{msg}</b></li>"
        html_body += "</ul>"

    # --------------------------------------------------
    # Source mismatch status
    # --------------------------------------------------
    # source_mismatches = [
    #     cfg["message"] for cfg in source_validation_config.values()
    #     if cfg.get("flag")
    # ]

    # if source_mismatches:
    #     html_body +=  "<p><b>🚨 Source Validation Status:</b></p><ul>"
    #     for msg in source_mismatches:
    #         html_body += f"<li><b>{msg}</b></li>"
    #     html_body += "</ul>"

    # --------------------------------------------------
    # Tableau mismatch status
    # --------------------------------------------------
    # tableau_failed = [
    #     cfg["sheet"] for cfg in tableau_validation_config.values()
    #     if cfg.get("flag")
    # ]

    # html_body += "<p><b>📊 Tableau vs FTS Delivery Validation Summary:</b></p><ul>"

    # if tableau_failed:
    #     failed_text = ", ".join(tableau_failed)
    #     html_body += f"<li><b>Discrepancies were identified in the following Tableau metrics/columns: {failed_text}. Please review the attached report for details.</b></li>"
    # else:
    #     html_body += "<li><b>Tableau validation completed successfully against the FTS Delivery Silver table. No discrepancies were identified.</b></li>"

    html_body += "</ul>"

    html_body += """
    <p>This report summarizes any delivery differences identified during today’s validation run.</p>
    <p>Thanks</p>
    """

    # --------------------------------------------------
    # SEND EMAIL
    # --------------------------------------------------
    email_message = MIMEMultipart()
    email_message["From"] = from_email
    email_message["To"] = ", ".join(to_mail)
    email_message["Cc"] = ", ".join(cc_mail)
    email_message["Subject"] = f"FTS Delivery Validation – {datetime.today().strftime('%Y-%m-%d')}"

    email_message.attach(MIMEText(html_body, "html"))

    # --------------------------------------------------
    # Function to download file from S3
    # --------------------------------------------------
    def get_s3_file_bytes(s3_client, bucket, key):
        # print(f"Downloading from s3://{bucket}/{key}")
        resp = s3_client.get_object(Bucket=bucket, Key=key)
        return resp["Body"].read()


    # --------------------------------------------------
    # Attach Source Excel (Downloaded from S3)
    # --------------------------------------------------
    # source_bytes = get_s3_file_bytes(s3, s3_bucket, source_key)

    # source_file = MIMEApplication(source_bytes, Name=file_name)
    # source_file.add_header("Content-Disposition", f'attachment; filename="{file_name}"')
    # email_message.attach(source_file)


    # --------------------------------------------------
    # Attach Tableau Excel (Downloaded from S3)
    # --------------------------------------------------
    tableau_bytes = get_s3_file_bytes(s3, s3_bucket, tableau_key)

    tableau_file = MIMEApplication(tableau_bytes, Name=tableau_file_name)
    tableau_file.add_header("Content-Disposition", f'attachment; filename="{tableau_file_name}"')
    email_message.attach(tableau_file)

    session = boto3.Session(profile_name=aws_profile)
    ses = session.client("ses", region_name="us-west-2")

    ses.send_raw_email(
        Source=from_email,
        Destinations=list(set(to_mail).union(set(cc_mail))),
        RawMessage={"Data": email_message.as_string()}
    )

    print("📧 Validation Email Sent Successfully!")


# COMMAND ----------

# MAGIC %md
# MAGIC ##GAM

# COMMAND ----------

global aws_profile, APPLICATION_NAME, NETWORK_CODE
aws_profile = aws_profile
APPLICATION_NAME = 'AdSales - GAM Data Ingestion'
cpe_s3_bucket = f'fox-fdp-bi-{env}'


# COMMAND ----------

def format_report(report_data: Any, report_type: str) -> Any:
    if report_type == 'Summary with Impressions and Clicks':
        format_columns = {
            'Dimension.DATE': ('event_date', T.DateType()),
            'Dimension.ORDER_ID': ('order_id', T.LongType()),
            'Dimension.LINE_ITEM_ID': ('line_item_id', T.StringType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS': ('total_line_item_level_impressions', T.LongType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_CLICKS': ('total_line_item_level_clicks', T.LongType())
            
        }
        select_cols = [
            'event_date',
            'order_id',
            'line_item_id',
            'total_line_item_level_impressions',
            'total_line_item_level_clicks',
            
            
        ]


    for k, v in format_columns.items():
        report_data = report_data.withColumnRenamed(k, v[0])
        report_data = report_data.withColumn(v[0], F.col(v[0]).cast(v[1]))

    report_data = report_data.select(select_cols)

    return report_data

# COMMAND ----------

def get_ad_manager_client(secret_arn: str,NETWORK_CODE) -> Any:
    session = boto3.Session(profile_name=aws_profile)
    resp = session.client('secretsmanager').get_secret_value(SecretId=secret_arn)
    secret = json.loads(resp['SecretString'])

    with tempfile.NamedTemporaryFile(mode='w', delete=False) as secret_file:
        json.dump(secret, secret_file, indent=2)
        secret_file.close()

    oauth2_client = oauth2.GoogleServiceAccountClient(secret_file.name, oauth2.GetAPIScope('ad_manager'))
    os.unlink(secret_file.name)
    ad_manager_client = ad_manager.AdManagerClient(oauth2_client, APPLICATION_NAME, NETWORK_CODE)

    return ad_manager_client

# COMMAND ----------

def format_datetime_to_obj(datetime_obj: Any) -> Any:
    obj = {}
    obj['year'] = datetime_obj.year
    obj['month'] = datetime_obj.month
    obj['day'] = datetime_obj.day
    return obj

def generate_processing_dates(start_date: datetime, end_date: datetime, step_size: int) -> list:
    processing_dates = []

    batch_start_date = start_date
    while batch_start_date <= end_date:
        batch_end_date = batch_start_date + timedelta(days=step_size - 1)
        if batch_end_date <= end_date:
            processing_dates.append((batch_start_date, batch_end_date))
        else:
            processing_dates.append((batch_start_date, end_date))
            break
        batch_start_date += timedelta(days=step_size)

    return processing_dates

def build_report_query(dimensions: list, columns: list, dimensionAttributes: list, start_date: datetime, end_date: datetime) -> Any:
    baseReportQuery = {
        'dimensions': [],
        'adUnitView': 'FLAT',
        'columns': [],
        'dimensionAttributes': [],
        'customFieldIds': [],
        'cmsMetadataKeyIds': [],
        'customDimensionKeyIds': [],
        'startDate': {},
        'endDate': {},
        'dateRangeType': 'CUSTOM_DATE',
        'statement': None,
        'reportCurrency': 'USD',
        'timeZoneType': 'PUBLISHER'
    }

    report_query = baseReportQuery
    report_query['dimensions'] = dimensions
    report_query['columns'] = columns
    report_query['dimensionAttributes'] = dimensionAttributes
    report_query['startDate'] = format_datetime_to_obj(start_date)
    report_query['endDate'] = format_datetime_to_obj(end_date)
    return report_query


# COMMAND ----------

def get_report_send_mail(client,network_code):
    timezone = pytz.timezone("UTC")
    # event_start_date = dbutils.widgets.text("event_start_date", "")
    # event_end_date = dbutils.widgets.text("event_end_date", "")
    event_start_date_param = '2025-10-01'
    event_end_date_param = ''

    # Default start date = 7 days ago if not provided
    if not event_start_date_param:
        print('no start date ')
        event_start_date = datetime.today() - timedelta(days=7)
        event_start_date = event_start_date.replace(hour=0, minute=0, second=0, microsecond=0)
    else:
        event_start_date = datetime.strptime(event_start_date_param, '%Y-%m-%d')

    # Default end date = today if not provided
    if not event_end_date_param:
        print('no end date ')
        event_end_date = datetime.today()
        event_end_date = event_end_date.replace(hour=0, minute=0, second=0, microsecond=0)
    else:
        
        event_end_date = datetime.strptime(event_end_date_param, '%Y-%m-%d')

    # Apply UTC timezone
    event_start_date = timezone.localize(event_start_date)
    event_end_date = timezone.localize(event_end_date)
    #event_start_date = datetime.strptime(dbutils.widgets.get('event_start_date'), '%Y-%m-%d').replace(tzinfo=timezone)
    #event_end_date = datetime.strptime(dbutils.widgets.get('event_end_date'), '%Y-%m-%d').replace(tzinfo=timezone)

    process_days = (event_end_date-event_start_date).days
    processing_dates = generate_processing_dates(event_start_date, event_end_date, 120)

    # Summary with Impressions and Error Count
    print('Summary with Impressions and Clicks')
    for i, batch in enumerate(processing_dates):
        start_date, end_date = batch
        print(f"Processing {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}, batch - {i}", end=' ')
        report_service = client.GetService('ReportService', version=gam_api_version)
        report_query = build_report_query(
            dimensions = [
                'DATE',
                'ORDER_ID',
                'LINE_ITEM_ID'
                
                
            ],
            columns = [
                'TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS',
                'TOTAL_LINE_ITEM_LEVEL_CLICKS'
                
            ],
            dimensionAttributes = [],
            start_date = start_date,
            end_date = end_date
        )
        report_job = report_service.runReportJob({'reportQuery': report_query})

        while True:
            status = report_service.getReportJobStatus(report_job['id'])
            if status == 'COMPLETED':
                break
            elif status == 'FAILED':
                break
            else:
                time.sleep(10)

        if status == 'COMPLETED':
            print('Downloading...', end=' ')
            report_download_url = report_service.getReportDownloadURL(report_job['id'], 'CSV_DUMP')
            report_data_df = pd.read_csv(report_download_url, compression='gzip')
            print(report_data_df.shape)
            
            
            if report_data_df.empty:
                continue
            #print(report_data_df)
            report_data = spark.createDataFrame(report_data_df)
            if i == 0:
                final_df = format_report(report_data, 'Summary with Impressions and Clicks')
            else:
                final_df = final_df.union(format_report(report_data, 'Summary with Impressions and Clicks'))
            print('Completed')
        else:
            raise Exception('Report job failed')

    # table_query = f"""
    #     SELECT ad_delivery_date as event_date, SUM(first_party_delivered_impressions) as first_party_delivered_impressions FROM {catalog}.{silver_schema}.ft_fts_delivery_daily 
        
    #     where ad_delivery_date >= '{event_start_date}' AND ad_delivery_date <= '{event_end_date}' AND data_source_name = 'GAM' and network_group_id ='{NETWORK_CODE}' GROUP BY 1 ;
    # """
    order_query = f"""
        
            select distinct order_id from {catalog}.{raw_schema}.gam_order
            WHERE order_name like '%Google Ad Manager - Fox News'
            """
    # table_df = spark.sql(table_query)
    print('code---- ',network_code)
    # print('actual count ',final_df.count())
    if network_code == 4145:
        order_df = spark.sql(order_query)
        print('before join ',final_df.count( ))
        final_df = final_df.join(order_df, on='order_id', how='inner')
 
    
    return final_df

# COMMAND ----------


NETWORK_CODE = 63790564
print('running network ',NETWORK_CODE)
client = get_ad_manager_client(gam_service_account_creds_secret_arn,NETWORK_CODE)
gam_df_637 = get_report_send_mail(client,NETWORK_CODE)
display(gam_df_637)
gam_df_637.createOrReplaceTempView("gam_df_637")


NETWORK_CODE = 4145
client = get_ad_manager_client(gam_service_account_creds_secret_arn,NETWORK_CODE)
gam_df_4145 = get_report_send_mail(client,NETWORK_CODE)
display(gam_df_4145)

gam_df_4145.createOrReplaceTempView("gam_df_4145")

                  
  

# COMMAND ----------

gam_query = """
SELECT 
ad_date as ad_delivery_date 
,external_ad_id
,SUM(first_party_delivered_impressions) first_party_delivered_impressions
,NULL AS  third_party_delivered_impressions
,SUM(first_party_clicks) first_party_clicks
,NULL AS  third_party_clicks
FROM  
(SELECT 
A.event_date as ad_date
,CAST(A.line_item_id AS STRING) as external_ad_id
,SUM(total_line_item_level_impressions) first_party_delivered_impressions
,SUM(total_line_item_level_clicks) first_party_clicks
FROM gam_df_4145  A
GROUP BY 
all

UNION ALL

SELECT 
A.event_date as ad_delivery_date
,CAST(A.line_item_id AS STRING) as external_ad_id
,SUM(total_line_item_level_impressions) first_party_delivered_impressions
,NULL AS first_party_clicks
FROM gam_df_637 A
GROUP BY 
all  
)
GROUP BY all
"""
gam_df = spark.sql(gam_query)
gam_df.createOrReplaceTempView("gam_data")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Madhive Validation

# COMMAND ----------

timezone = pytz.UTC
mdv_pull_date = (
    datetime.now(timezone)
).strftime("%Y-%m-%d")
print("Madhive pull date:", mdv_pull_date)
from datetime import timedelta

dates = sorted([(datetime.strptime(mdv_pull_date, "%Y-%m-%d") - timedelta(days=i)).strftime("%Y-%m-%d") for i in range(7)])
print("Dates to process:", dates)
global aws_profile
aws_profile =aws_profile
# Set up boto3 for S3 access (make sure AWS creds are configured)
session = boto3.Session(profile_name=aws_profile)
s3 = session.client('s3')

# Define your S3 details
bucket_name = 'bi-lz-analytics-import'
prefix = 'fts/madhive/'  
for date in dates:
    if env.lower() == 'prod':
        response = s3.list_objects_v2(Bucket=bucket_name, Prefix=prefix)
        todays_files = [
            f"s3://{bucket_name}/{obj['Key']}"
            for obj in response.get('Contents', [])
            if date in obj['Key']
        ]
        todays_files.sort()
    else:
        response =  dbutils.fs.ls(f"s3://{bucket_name}/{prefix}")
        todays_files = [
            file.path
            for file in response
            if date in file.name
        ]
        todays_files.sort()
    try:
        # Read file(s) using Spark
        if todays_files:
            file_name = todays_files[0]
            print(f"Loading Madhive file: {file_name}")
            df = spark.read.format("csv") \
            .option("header", True) \
            .option("delimiter", ",") \
            .option("quote", '"') \
            .option("escape", '"') \
            .option("multiLine", True) \
            .load(file_name)
            df = df.withColumn('file_path', lit(file_name))
            # df.write.mode("overwrite").option("partitionOverwriteMode", "dynamic").partitionBy("date_et").saveAsTable("fox_bi_dev.raw_ads.raw_fts_delivery_madhive")
        else:
            missing_file_alert.append(f'Madhive file not received for this run date: {mdv_pull_date}')
            madhive = False
    except Exception as e:
        missing_file_alert.append(f'Madhive file not received for this run date: {mdv_pull_date}')
        madhive = False
        print(f"Error reading Madhive data: {e}")

# COMMAND ----------

# from datetime import datetime

# files = dbutils.fs.ls("s3://bi-lz-analytics-import/fts/madhive/")
# latest_files = sorted(files, key=lambda x: x.modificationTime)
# latest_files_with_ts = [
#     {
#         "path": f.path,
#         "name": f.name,
#         "size": f.size,
#         "modificationTime": f.modificationTime,
#         "modificationTimestamp": datetime.fromtimestamp(f.modificationTime / 1000)
#     }
#     for f in latest_files
# ]
# # min_modification_date = min(f["modificationTimestamp"].date() for f in latest_files_with_ts)
# # print(min_modification_date)

# for file_info in latest_files_with_ts:
#     file_path = file_info["path"]
    #   df = spark.read.format("csv") \
    #         .option("header", True) \
    #         .option("delimiter", ",") \
    #         .option("quote", '"') \
    #         .option("escape", '"') \
    #         .option("multiLine", True) \
    #         .load(file_path)
#     df = df.withColumn('file_path', lit(file_path))
#     df.write.mode("overwrite").option("partitionOverwriteMode", "dynamic").partitionBy("date_et").saveAsTable("fox_bi_dev.raw_ads.raw_fts_delivery_madhive")

# COMMAND ----------

madhive_df = spark.sql("""
SELECT 
    date_et as ad_delivery_date,
    line_item_id as external_ad_id,
    SUM(COALESCE(impressions_total,0)) AS first_party_delivered_impressions,
    NULL AS  third_party_delivered_impressions,
    SUM(COALESCE(click_events_total,0)) AS first_party_clicks,
    NULL AS  third_party_clicks
FROM fox_bi_dev.raw_ads.raw_fts_delivery_madhive
where date_et>='2025-10-01'
GROUP BY all
""")
madhive_df.cache()
madhive_df.createOrReplaceTempView("madhive_data")


# COMMAND ----------

# MAGIC %md
# MAGIC ##DVPS Validation

# COMMAND ----------

# from datetime import datetime

# files = dbutils.fs.ls("s3://bi-lz-analytics-import/fts/double-verify/")
# latest_files = sorted(files, key=lambda x: x.modificationTime)
# latest_files_with_ts = [
#     {
#         "path": f.path,
#         "name": f.name,
#         "size": f.size,
#         "modificationTime": f.modificationTime,
#         "modificationTimestamp": datetime.fromtimestamp(f.modificationTime / 1000)
#     }
#     for f in latest_files
# ]
# # min_modification_date = min(f["modificationTimestamp"].date() for f in latest_files_with_ts)
# # print(min_modification_date)

# for file_info in latest_files_with_ts:
#     file_path = file_info["path"]
#     print(file_path)
#     df = spark.read.format("csv") \
#     .option("header", "true") \
#     .load(file_path)
#     from pyspark.sql.functions import lit
#     df = df.withColumnRenamed("Delivered Date", "delivered_date").withColumn("file_name", lit(file_info["path"]))

#     # display(df)
#     df = df.toDF(*[c.lower().replace(" ", "_") for c in df.columns])
#     df.write.mode("overwrite").option("partitionOverwriteMode", "dynamic").partitionBy("delivered_date").saveAsTable("fox_bi_dev.raw_ads.raw_fts_delivery_double_verify")

# COMMAND ----------

# from pyspark.sql import functions as F
# query ="""
# SELECT 
# CAST(ft.`Delivered_Date` as date) as ad_delivery_date
# ,ft.`Associated_Line_Item_ID` as external_ad_id 
# ,'DVPS' as data_source_name
# ,NULL as network_group_id
# ,NULL as isci_code 
# ,NULL as spot_length
# ,NULL as first_party_delivered_impressions 
# ,sum(`Delivered_Quantity_1`) AS third_party_delivered_impressions --only DVPS
# ,NULL as first_party_clicks
# ,sum(`Delivered_Quantity_2`) AS third_party_clicks --only DVPS
# FROM fox_bi_dev.raw_ads.raw_fts_delivery_double_verify ft
# --WHERE CAST(ft.`Delivered Date` as date) >= '2026-02-09'
# GROUP BY 1,2 
# """
# dv_df = spark.sql(query)
# dv_df = dv_df.withColumn("ad_delivery_date", F.to_date(F.col("ad_delivery_date"), 'yyyy-MM-dd'))


# COMMAND ----------

# display(dv_df)

# COMMAND ----------

# dv_df.write.format('delta')\
#      .mode('overwrite')\
#       .partitionBy('ad_delivery_date','data_source_name')\
#       .option('mergeSchema', 'true')\
#      .option('partitionOverwriteMode', 'dynamic')\
#     .saveAsTable(f'fox_bi_dev.silver_ads.ft_fts_delivery_daily_test')

# COMMAND ----------

timezone = pytz.UTC

files = dbutils.fs.ls("s3://bi-lz-analytics-import/fts/double-verify/")
latest_files = sorted(files, key=lambda x: x.modificationTime, reverse=True)[:7]
latest_files = sorted(latest_files, key=lambda x: x.modificationTime)

file_names = [f.path for f in latest_files]
event_start_date = (datetime.now(timezone) - timedelta(days=1)).strftime('%Y-%m-%d') 
event_end_date = (datetime.now(timezone) - timedelta(days=7)).strftime('%Y-%m-%d')
print(f"Double Verify: pulling data between {event_end_date} and {event_start_date}")

latest_file_name = f's3://bi-lz-analytics-import/fts/double-verify/FTS - Operative - S3 Report_{event_end_date}_{event_start_date}.csv'

if latest_file_name not in file_names:
    print(f"Double Verify: latest file not found: {latest_file_name}")
    missing_file_alert.append(f'DVPS file not received for {event_end_date} - {event_start_date}')


for file_name in file_names:
    print(file_name)
    try:
        df = spark.read.format("csv") \
            .option("header", True) \
            .option("delimiter", ",") \
            .option("quote", '"') \
            .option("escape", '"') \
            .option("multiLine", True) \
            .load(file_name)
        df = df.withColumnRenamed("Delivered Date", "delivered_date").withColumn("file_name", lit(file_name))

        # display(df)
        df = df.toDF(*[c.lower().replace(" ", "_") for c in df.columns])
        df.write.mode("overwrite").option("partitionOverwriteMode", "dynamic").partitionBy("delivered_date").saveAsTable("fox_bi_dev.raw_ads.raw_fts_delivery_double_verify")

        # df.createOrReplaceTempView("double_verify_data")
    except Exception as e:
        import re
        date_matches = re.findall(r'\d{4}-\d{2}-\d{2}', 's3://bi-lz-analytics-import/fts/double-verify/FTS - Operative - S3 Report_2026-02-24_2026-03-02.csv')
        missing_file_alert.append(f'DVPS file not received for dates: {", ".join(date_matches) if date_matches else "unknown"}')
        dvps = False
        print(f'Error: {e}')

# COMMAND ----------

dvps_df = spark.sql("""
  SELECT 
  delivered_date,
  associated_line_item_id as external_ad_id,
  NULL as first_party_delivered_impressions,
  SUM(COALESCE(delivered_quantity_1,0))  AS third_party_delivered_impressions,
  NULL as  first_party_clicks,
  SUM(COALESCE(delivered_quantity_2,0))  AS third_party_clicks
  FROM fox_bi_dev.raw_ads.raw_fts_delivery_double_verify 
  where delivered_date>='2025-10-01'
  GROUP BY all 
  """)
dvps_df.cache()
dvps_df.createOrReplaceTempView("dvps_data")

# COMMAND ----------

# from pyspark.sql.functions import col, when
# import pyspark.sql.functions as F
# dvps =True
# if dvps:

#   fts_silver_dvps_df = spark.sql(f"""
#   SELECT 
#       ad_delivery_date,
#       external_ad_id,
#       SUM(COALESCE(third_party_delivered_impressions,0))  AS third_party_delivered_impressions,
#       SUM(COALESCE(third_party_clicks,0))                 AS third_party_clicks
#   FROM fox_bi_prod.silver_ads.ft_fts_delivery_daily
#   WHERE lower(data_source_name) = 'dvps' and  ad_delivery_date between '2025-06-01' and '2025-06-30'
#     --AND ad_delivery_date BETWEEN CURRENT_DATE-7 AND CURRENT_DATE-1
#   GROUP BY all
#   """)

#   dvps_df = spark.sql("""
#   SELECT 
#   ad_delivery_date,
#   external_ad_id,
#       SUM(COALESCE(third_party_delivered_impressions,0))  AS third_party_delivered_impressions,
#       SUM(COALESCE(third_party_clicks,0))                 AS third_party_clicks
#   FROM fox_bi_dev.silver_ads.ft_fts_delivery_daily_test 
#   where ad_delivery_date between '2025-06-01' and '2025-06-30'
#   GROUP BY all 
#   """)

#   dvps_compare_df = (
#       dvps_df.alias("d")
#       .join(fts_silver_dvps_df.alias("f"),
#             (col("f.ad_delivery_date") == col("d.ad_delivery_date"))
#             & (col("f.external_ad_id") == col("d.external_ad_id")),
#             "left")
#       .select(
#           col("d.ad_delivery_date").alias("ad_delivery_date"),
#           col("d.external_ad_id").alias("external_ad_id"),

#           col("f.third_party_delivered_impressions").alias("silver_third_party_delivered_impressions"),
#           col("d.third_party_delivered_impressions").alias("source_dvps_third_party_delivered_impressionss"),

#           (F.coalesce(col("d.third_party_delivered_impressions"), F.lit(0)) - F.coalesce(col("f.third_party_delivered_impressions"), F.lit(0))).alias("third_party_delivered_impressions_varience"),

#           col("f.third_party_clicks").alias("silver_third_party_clicks"),
#           col("d.third_party_clicks").alias("source_dvps_third_party_clicks"),

# (F.coalesce(col("d.third_party_clicks"), F.lit(0)) - F.coalesce(col("f.third_party_clicks"), F.lit(0))).alias("third_party_clicks_varience"),

#           when(
#               col("d.third_party_delivered_impressions")
#               != col("f.third_party_delivered_impressions"),
#               "Mismatch"
#           ).otherwise("Match").alias("third_party_delivered_impressions_status"),

#           when(
#               col("d.third_party_clicks")
#               != col("f.third_party_clicks"),
#               "Mismatch"
#           ).otherwise("Match").alias("third_party_clicks_status")
#       )
#   )

#   dvps_df = dvps_compare_df.select(
#       col("ad_delivery_date"),
#       col("external_ad_id"),
#       col("silver_third_party_delivered_impressions"),
#       col("source_dvps_third_party_delivered_impressionss"),
#       col("third_party_delivered_impressions_varience"),
#       col("silver_third_party_clicks"),
#       col("source_dvps_third_party_clicks"),
#       col("third_party_clicks_varience")
#     )
#   display(dvps_df)
# #   dvps_mismatch_df = dvps_compare_df.filter(
# #       (col("third_party_delivered_impressions_status") == "Mismatch") |
# #       (col("third_party_clicks_status") == "Mismatch")
# #   )
# #   if dvps_mismatch_df.count() > 0:
# #     miss_match_count['dvps']=True
# else:

#   empty_schema = StructType([
#       StructField("ad_delivery_date", DateType(), True),
#       StructField("silver_third_party_delivered_impressions", LongType(), True),
#       StructField("dvps_third_party_delivered_impressionss", LongType(), True),
#       StructField("third_party_delivered_impressions_varience", LongType(), True),
#       StructField("silver_third_party_clicks", LongType(), True),
#       StructField("dvps_third_party_clicks", LongType(), True),
#       StructField("third_party_clicks_varience", LongType(), True)
#   ])
#   dvps_df = spark.createDataFrame([], empty_schema)

# COMMAND ----------

# dvps_df.write.mode("overwrite").saveAsTable("fox_bi_dev.bronze_ads.fts_dvps_validation")

# COMMAND ----------

# MAGIC %md
# MAGIC ##freewheel
# MAGIC

# COMMAND ----------

fw_max_ts = spark.sql(f"""
SELECT coalesce(max(eventtime), '1900-01-01') AS max_ts
FROM fox_bi_prod.raw_ads.freewheel_s3_v4logs_500763_fox_affiliates
where eventtime BETWEEN CURRENT_DATE-7 AND CURRENT_DATE
""").collect()[0]["max_ts"]

from pyspark.sql.functions import from_utc_timestamp

fw_max_date = spark.createDataFrame([(fw_max_ts,)], ["ts"]) \
    .selectExpr("CAST(from_utc_timestamp(ts,'America/New_York') AS DATE) as max_date") \
    .collect()[0]["max_date"]
print(fw_max_date)


# COMMAND ----------

today_date = datetime.today().date()
yesterday = today_date - timedelta(days=1)

if fw_max_date == yesterday:
    fw = True
    print(f'FW data is available for {yesterday}')
else:
    fw = False
    missing_file_alert.append(f'Freewheel (FW) data is missing for {yesterday}')


# COMMAND ----------

fw_df = spark.sql("""
          SELECT 
            CAST(from_utc_timestamp(EventTime,'America/New_York') AS DATE) AS ad_delivery_date,
            placementid as external_ad_id,
            SUM(
                CASE
                    WHEN eventname = 'defaultImpression'
                    AND givtdecisionresult = 'Pass'
                    THEN 1 ELSE 0
                END
            ) AS first_party_delivered_impressions,
            NULL AS  third_party_delivered_impressions,
            NULL as first_party_clicks,
            NULL AS  third_party_clicks

        FROM fox_bi_prod.raw_ads.freewheel_s3_v4logs_500763_fox_affiliates

        WHERE EventDate >='2025-10-01' AND  EventDate < to_utc_timestamp(current_date(),'America/New_York')
        GROUP BY all
        """)
fw_df.cache()
fw_df.createOrReplaceTempView("fw_data")

# COMMAND ----------

fnl_query= """
select * from gam_data
union all
select * from madhive_data
union all 
select * from dvps_data
union all
select * from fw_data
"""
fnl_df = spark.sql(fnl_query)
# fnl_df.write.mode("overwrite").option("mergeSchema", "true").saveAsTable("fox_bi_dev.bronze_ads.fts_delivery_val")
fnl_df.cache()
fnl_df.createOrReplaceTempView('delivery_final')

# COMMAND ----------


# if fw:
#     fts_silver_fw_df = spark.sql(f"""
#                 SELECT 
#                   ad_delivery_date,
#                   SUM(COALESCE(first_party_delivered_impressions,0))  AS first_party_delivered_impressions
#               FROM {catalog}.silver_ads.ft_fts_delivery_daily
#               WHERE lower(data_source_name) = 'freewheel' AND ad_delivery_date BETWEEN CURRENT_DATE-8 AND CURRENT_DATE-1
#               GROUP BY  ad_delivery_date
#                   """)

#     fw_df = spark.sql(f"""
#           SELECT
#             CAST(from_utc_timestamp(EventTime,'America/New_York') AS DATE) AS ad_delivery_date,
#             SUM(
#                 CASE
#                     WHEN eventname = 'defaultImpression'
#                     AND givtdecisionresult = 'Pass'
#                     THEN 1 ELSE 0
#                 END
#             ) AS first_party_delivered_impressions

#         FROM fox_bi_prod.raw_ads.freewheel_s3_v4logs_500763_fox_affiliates

#         WHERE EventTime >= to_utc_timestamp(CURRENT_DATE - 8,'America/New_York')
#         AND EventTime <  to_utc_timestamp(CURRENT_DATE,'America/New_York')

#         GROUP BY ad_delivery_date
#     """)

#     fw_compare_df = (
#         fw_df.alias("fw")
#         .join(fts_silver_fw_df.alias("f"),
#             col("f.ad_delivery_date") == col("fw.ad_delivery_date"),
#             "left")
#         .select(
#             col("fw.ad_delivery_date").alias("ad_delivery_date"),

#             col("f.first_party_delivered_impressions").alias("silver_first_party_delivered_impressions"),
#             col("fw.first_party_delivered_impressions").alias("fw_first_party_delivered_impressions"),

#             (col("fw.first_party_delivered_impressions") - col("f.first_party_delivered_impressions")).alias("first_party_delivered_impressions_varience"),


#             when(
#                 col("fw.first_party_delivered_impressions")
#                 !=  col("f.first_party_delivered_impressions"),
#                 "Mismatch"
#             ).otherwise("Match").alias("first_party_delivered_impressions_status")
#         )
#     )

#     fw_df = fw_compare_df.select(
#         col("ad_delivery_date"),
#         col("silver_first_party_delivered_impressions"),
#         col("fw_first_party_delivered_impressions"),
#         col("first_party_delivered_impressions_varience"),
#     )
#     display(fw_df)
#     fw_mismatch_df = fw_compare_df.filter(
#         (col("first_party_delivered_impressions_status") == "Mismatch") 
#     )
#     if fw_mismatch_df.count() > 0:
#         miss_match_count['fw'] = True
# else:
#     empty_schema = StructType([
#         StructField("ad_delivery_date", DateType(), True),
#         StructField("silver_first_party_delivered_impressions", LongType(), True),
#         StructField("fw_first_party_delivered_impressions", LongType(), True),
#         StructField("first_party_delivered_impressions_varience", LongType(), True)
#     ])
#     fw_df = spark.createDataFrame([], empty_schema)

# COMMAND ----------

compare_sql = """WITH fts_gold AS (
    SELECT 
        deal_line_date,
        display_deal_id,
        external_ad_id,
        sum(delivered_impressions_primary) as delivered_impressions_primary,
        sum(delivered_impressions_third_party) as delivered_impressions_third_party,
        sum(first_party_clicks) as first_party_clicks,
        sum(third_party_clicks) as  third_party_clicks
    FROM fox_bi_prod.gold_ad_sales_fts.ft_fts_aos_allocation_data
    group by all
),

fts_delivery AS (
    SELECT  
        ad_delivery_date AS ad_date,
        external_ad_id AS ads_external_ad_id,
        SUM(first_party_delivered_impressions) AS first_party_delivered_impressions,
        SUM(third_party_delivered_impressions) AS third_party_delivered_impressions,
        SUM(first_party_clicks) AS delivery_first_party_clicks,
        SUM(third_party_clicks) AS delivery_third_party_clicks
    FROM delivery_final
    GROUP BY ad_delivery_date, external_ad_id
)

SELECT 
    g.display_deal_id AS `Deal Id`,
    g.external_ad_id AS `External Ad ID`,

    g.delivered_impressions_primary AS `Delivered Impressions Primary`,
    g.delivered_impressions_third_party AS `Delivered Impressions Third Party`,
    g.first_party_clicks AS `First Party Clicks`,
    g.third_party_clicks AS `Third Party Clicks`,

    d.first_party_delivered_impressions AS `Delivery First Party Impressions`,
    d.third_party_delivered_impressions AS `Delivery Third Party Impressions`,
    d.delivery_first_party_clicks AS `Delivery First Party Clicks`,
    d.delivery_third_party_clicks AS `Delivery Third Party Clicks`,

    -- Percentage Variance
    ROUND(
        (COALESCE(g.delivered_impressions_primary, 0) - COALESCE(d.first_party_delivered_impressions, 0))
        / NULLIF(COALESCE(g.delivered_impressions_primary, 0), 0) * 100, 2
    ) AS `Primary Impressions Variance %`,

    ROUND(
        (COALESCE(g.delivered_impressions_third_party, 0) - COALESCE(d.third_party_delivered_impressions, 0))
        / NULLIF(COALESCE(g.delivered_impressions_third_party, 0), 0) * 100, 2
    ) AS `Third Party Impressions Variance %`,

    ROUND(
        (COALESCE(g.first_party_clicks, 0) - COALESCE(d.delivery_first_party_clicks, 0))
        / NULLIF(COALESCE(g.first_party_clicks, 0), 0) * 100, 2
    ) AS `First Party Clicks Variance %`,

    ROUND(
        (COALESCE(g.third_party_clicks, 0) - COALESCE(d.delivery_third_party_clicks, 0))
        / NULLIF(COALESCE(g.third_party_clicks, 0), 0) * 100, 2
    ) AS `Third Party Clicks Variance %`

FROM fts_delivery d
LEFT JOIN fts_gold g
ON g.external_ad_id = d.ads_external_ad_id
AND g.deal_line_date = d.ad_date
where  g.external_ad_id is not  null
"""
compare_df=spark.sql(compare_sql)
compare_df.cache()

# COMMAND ----------

result_df = compare_df.filter(
    (abs(col("Primary Impressions Variance %")) > 0.1) |
    (abs(col("Third Party Impressions Variance %")) > 0.1) |
    (abs(col("First Party Clicks Variance %")) > 0.1) |
    (abs(col("Third Party Clicks Variance %")) > 0.1)
).select(
      col("Deal ID"),
      col("External Ad ID"),
      
      col("Delivery First Party Impressions"),
      col("Delivered Impressions Primary"),
      col("Primary Impressions Variance %"),

      col("Delivered Impressions Third Party"),
      col("Delivery Third Party Impressions"),
      col("Third Party Impressions Variance %"),

      col("First Party Clicks"),
      col("Delivery First Party Clicks"),
      col("First Party Clicks Variance %"),

      col("Third Party Clicks"),
      col("Delivery Third Party Clicks"),
      col("Third Party Clicks Variance %")
  )

# COMMAND ----------


# primary_df = result_df.select(
#       col("Deal ID"),
#       col("External Ad ID"),
      
#       col("Delivery First Party Impressions"),
#       col("Delivered Impressions Primary"),
#       col("Primary Impressions Variance %")
# )

# third_party_df = result_df.select(
#       col("Deal ID"),
#       col("External Ad ID"),
      
#       col("Delivered Impressions Third Party"),
#       col("Delivery Third Party Impressions"),
#       col("Third Party Impressions Variance %")
# )

# first_party_clicks_df = result_df.select(
#       col("Deal ID"),
#       col("External Ad ID"),

#       col("First Party Clicks"),
#       col("Delivery First Party Clicks"),
#       col("First Party Clicks Variance %")
# )

# third_party_clicks_df = result_df.select(
#       col("Deal ID"),
#       col("External Ad ID"),
      
#       col("Third Party Clicks"),
#       col("Delivery Third Party Clicks"),
#       col("Third Party Clicks Variance %")
# )



# COMMAND ----------

validation_config = {

    "metrics": {
        "df": result_df,
        "sheet": "comparison"
        # "flag": tableau_primary_mismatch_flag
    }
    # ,

    # "third_party": {
    #     "df": third_party_df,
    #     "sheet": "Third Party Impressions"
    #     # "flag": tableau_third_party_mismatch_flag
    # },

    # "first_party_clicks": {
    #     "df": first_party_clicks_df,
    #     "sheet": "First Party Clicks"
    #     # "flag": tableau_first_party_clicks_mismatch_flag
    # },

    # "third_party_clicks": {
    #     "df": third_party_clicks_df,
    #     "sheet": "Third Party Clicks"
    #     # "flag": tableau_third_party_clicks_mismatch_flag
    # }
}


# COMMAND ----------

# fts_df = spark.sql(f"""
# select distinct 
#   fts.display_deal_id as deal_id,
#   del.external_ad_id as ads_external_ad_id
#   ,sum(del.first_party_delivered_impressions) as first_party_delivered_impressions
#   ,sum(del.third_party_delivered_impressions) as third_party_delivered_impressions
#   ,sum(del.first_party_clicks) as first_party_clicks
#   ,sum(del.third_party_clicks) as third_party_clicks
#   from delivery_final del join fox_bi_prod.gold_ad_sales_fts.ft_fts_aos_allocation_data fts
#   on del.ad_delivery_date = fts.deal_line_date and del.external_ad_id=fts.external_ad_id
#   group by all
#   """)


# COMMAND ----------

# MAGIC %md
# MAGIC ## Tableau vs FTS Delivery Silver

# COMMAND ----------

# %run ./fts_delivey_metrics_vs_tableau

# COMMAND ----------

# tableau_df = create_file(lucid_id)

# COMMAND ----------

# fts_del_tab_df = (
#     tableau_df.pivot_table(
#         index=["Deal ID", "External Ad ID"],
#         columns="Measure Names",
#         values="Measure Values",
#         aggfunc="first"
#     ).reset_index()
# )
# # display(fts_del_tab_df)


# COMMAND ----------

# fts_df = spark.sql(f"""
# select distinct 
#   del.external_ad_id as ads_external_ad_id
#   ,sum(del.first_party_delivered_impressions) as first_party_delivered_impressions
#   ,sum(del.third_party_delivered_impressions) as third_party_delivered_impressions
#   ,sum(del.first_party_clicks) as first_party_clicks
#   ,sum(del.third_party_clicks) as third_party_clicks
#   from delivery_final del join fox_bi_prod.gold_ad_sales_fts.ft_fts_aos_allocation_data fts
#   on del.ad_delivery_date = fts.deal_line_date and del.external_ad_id=fts.external_ad_id
#   group by all
#   """)


# COMMAND ----------

# fts_del_tab_df_spark = spark.createDataFrame(fts_del_tab_df)
# fts_del_tab_df_spark = fts_del_tab_df_spark.withColumnRenamed("External Ad ID", "ads_external_ad_id")

# # Join DataFrames on external_ad_id
# joined_df = fts_df.join(
#     fts_del_tab_df_spark,
#     on="ads_external_ad_id",
#     how="inner"
# )

# COMMAND ----------

# from pyspark.sql.functions import regexp_replace, col,lit

# # Compare metric columns and add status columns
# tableau_compare_df = joined_df.select(
#     col('Deal ID'),
#     col("ads_external_ad_id"),

#     coalesce(col("first_party_delivered_impressions"), lit(0)).alias("first_party_delivered_impressions"),
#     coalesce(regexp_replace(col("`Delivered Impressions Primary`"), ",", "").cast("bigint"), lit(0)).alias("tableau_delivered_impressions_primary"),
#     (coalesce(col("first_party_delivered_impressions"), lit(0)) - coalesce(col("tableau_delivered_impressions_primary").cast('bigint'), lit(0))).alias('delivered_impressions_primary_varience'),
#     when(
#         col("first_party_delivered_impressions") != col("tableau_delivered_impressions_primary"),
#         "Mismatch"
#     ).otherwise("Match").alias("delivered_impressions_primary_status"),

    
#     coalesce(col("third_party_delivered_impressions"), lit(0)).alias("third_party_delivered_impressions"),
#     coalesce(regexp_replace(col("`Delivered Impressions Third Party`"), ",", "").cast("bigint"), lit(0)).alias("tableau_delivered_impressions_third_party"),
#     (coalesce(col("third_party_delivered_impressions"), lit(0)) - coalesce(col("tableau_delivered_impressions_third_party"), lit(0))).alias("delivered_impressions_third_party_varience"),
#     when(
#         col("third_party_delivered_impressions") != col("tableau_delivered_impressions_third_party"),
#         "Mismatch"
#     ).otherwise("Match").alias("delivered_impressions_third_party_status"),


#     coalesce(col("first_party_clicks"), lit(0)).alias("first_party_clicks"),
#     coalesce(regexp_replace(col("`First Party Clicks`"), ",", "").cast("bigint"), lit(0)).alias("tableau_first_party_clicks"),
#     (coalesce(col("first_party_clicks"), lit(0)) - coalesce(col("tableau_first_party_clicks"), lit(0))).alias("first_party_clicks_varience"),
#     when(
#         col("first_party_clicks") != col("tableau_first_party_clicks"),
#         "Mismatch"
#     ).otherwise("Match").alias("first_party_clicks_status"),


#     coalesce(col("third_party_clicks"), lit(0)).alias("third_party_clicks"),
#     coalesce(regexp_replace(col("`Third Party Clicks`"), ",", "").cast("bigint"), lit(0)).alias("tableau_third_party_clicks"),
#     (coalesce(col("third_party_clicks"), lit(0)) - coalesce(col("tableau_third_party_clicks"), lit(0))).alias("third_party_clicks_varience"),
#     when(
#         col("third_party_clicks") != col("tableau_third_party_clicks"),
#         "Mismatch"
#     ).otherwise("Match").alias("third_party_clicks_status")

# )



# COMMAND ----------

# tableau_compare_df.cache()

# COMMAND ----------

# tableau_df = tableau_compare_df.select(
#       col("Deal ID"),
#       col("ads_external_ad_id"),
      
#       col("first_party_delivered_impressions"),
#       col("tableau_delivered_impressions_primary"),
#       col("delivered_impressions_primary_varience"),

#       col("third_party_delivered_impressions"),
#       col("tableau_delivered_impressions_third_party"),
#       col("delivered_impressions_third_party_varience"),

#       col("first_party_clicks"),
#       col("tableau_first_party_clicks"),
#       col("first_party_clicks_varience"),

#       col("third_party_clicks"),
#       col("tableau_third_party_clicks"),
#       col("third_party_clicks_varience")
#   )

# COMMAND ----------

# tableau_primary_mismatch_df = tableau_compare_df.select(
#       col("Deal ID"),
#       col("ads_external_ad_id"),
      
#       col("first_party_delivered_impressions"),
#       col("tableau_delivered_impressions_primary"),
#       col("delivered_impressions_primary_varience")
# )

# tableau_third_party_mismatch_df = tableau_compare_df.select(
#       col("Deal ID"),
#       col("ads_external_ad_id"),
      
#       col("third_party_delivered_impressions"),
#       col("tableau_delivered_impressions_third_party"),
#       col("delivered_impressions_third_party_varience")
# )

# tableau_first_party_clicks_mismatch_df = tableau_compare_df.select(
#       col("Deal ID"),
#       col("ads_external_ad_id"),
      
#       col("first_party_clicks"),
#       col("tableau_first_party_clicks"),
#       col("first_party_clicks_varience")
# )

# tableau_third_party_clicks_mismatch_df = tableau_compare_df.select(
#       col("Deal ID"),
#       col("ads_external_ad_id"),
      
#       col("third_party_clicks"),
#       col("tableau_third_party_clicks"),
#       col("third_party_clicks_varience")
# )

# # if tableau_primary_mismatch_df.count() > 0:
# #     tableau_primary_mismatch_flag = True
# # else:
# #     tableau_primary_mismatch_flag = False

# # if tableau_third_party_mismatch_df.count() > 0:
# #     tableau_third_party_mismatch_flag = True
# # else:
# #     tableau_third_party_mismatch_flag = False

# # if tableau_first_party_clicks_mismatch_df.count() > 0:
# #     tableau_first_party_clicks_mismatch_flag = True
# # else:
# #     tableau_first_party_clicks_mismatch_flag = False

# # if tableau_third_party_clicks_mismatch_df.count() > 0:
# #     tableau_third_party_clicks_mismatch_flag = True
# # else:
# #     tableau_third_party_clicks_mismatch_flag = False



# COMMAND ----------

# MAGIC %md
# MAGIC ##Mail Sending

# COMMAND ----------

# source_validation_config = {

#     "gam_637": {
#         "df": gam_df_637,
#         "sheet": "Gam_Network_63790564",
#         "flag": miss_match_count.get("gam_637"),
#         "message": "GAM Network 63790564 mismatches found"
#     },

#     "gam_4145": {
#         "df": gam_df_4145,
#         "sheet": "Gam_Network_4145",
#         "flag": miss_match_count.get("gam_4145"),
#         "message": "GAM Network 4145 mismatches found"
#     },

#     "madhive": {
#         "df": madhive_df,
#         "sheet": "Madhive",
#         "flag": miss_match_count.get("madhive"),
#         "message": "Madhive data mismatches found"
#     },

#     "dvps": {
#         "df": dvps_df,
#         "sheet": "DVPS",
#         "flag": miss_match_count.get("dvps"),
#         "message": "DVPS data mismatches found"
#     },

#     "fw": {
#         "df": fw_df,
#         "sheet": "FW",
#         "flag": miss_match_count.get("fw"),
#         "message": "Freewheel data mismatches found"
#     }
# }


# COMMAND ----------

# tableau_validation_config = {

#     "tableau_primary": {
#         "df": tableau_primary_mismatch_df,
#         "sheet": "Delivered Impressions Primary"
#         # "flag": tableau_primary_mismatch_flag
#     },

#     "tableau_third_party": {
#         "df": tableau_third_party_mismatch_df,
#         "sheet": "Third Party Impressions"
#         # "flag": tableau_third_party_mismatch_flag
#     },

#     "tableau_first_party_clicks": {
#         "df": tableau_first_party_clicks_mismatch_df,
#         "sheet": "First Party Clicks"
#         # "flag": tableau_first_party_clicks_mismatch_flag
#     },

#     "tableau_third_party_clicks": {
#         "df": tableau_third_party_clicks_mismatch_df,
#         "sheet": "Third Party Clicks"
#         # "flag": tableau_third_party_clicks_mismatch_flag
#     }
# }


# COMMAND ----------

build_excel_and_send_mail(
    # source_validation_config,
    validation_config,
    missing_file_alert,
    from_email,
    to_mail,
    cc_mail,
    aws_profile,
    cpe_s3_bucket
)
