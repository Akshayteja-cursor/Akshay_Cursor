# Databricks notebook source
from datetime import datetime,timedelta
import pytz
import configparser

# COMMAND ----------

# MAGIC %run ./fts_delivery_config

# COMMAND ----------

event_end_date = (datetime.now() - timedelta(days=7)).strftime('%Y-%m-%d')
event_start_date = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d') 
print(event_start_date)
print(event_end_date)

# COMMAND ----------

dbutils.widgets.text("env", "")
env = dbutils.widgets.get("env")

# COMMAND ----------

config = configparser.ConfigParser()
config = fts_delivery_config[env]
display(config)
catalog=config['catalog']
silver_schema=config['silver_schema']
gold_schema=config['gold_schema']
bronze_schema = config['bronze_schema']

# COMMAND ----------

timezone = pytz.timezone("UTC")
event_start_date = dbutils.widgets.text('event_start_date','', '')
start_date = dbutils.widgets.get('event_start_date')
if start_date:
  start_date = datetime.strptime(start_date, '%Y-%m-%d')
  start_date = start_date + timedelta(days=1)
  
  event_start_date = start_date.replace(tzinfo=timezone).strftime('%Y-%m-%d')
  event_end_date = (start_date - timedelta(days=6)).strftime('%Y-%m-%d')

print(event_start_date)
print(event_end_date)
file_name = f's3://bi-lz-analytics-import/fts/double-verify/FTS - Operative - S3 Report_{event_end_date}_{event_start_date}.csv'
print(file_name)

# COMMAND ----------


df = spark.read.format("csv") \
    .option("header", "true") \
    .load(file_name)

# COMMAND ----------

df.write.format("delta") \
    .option("delta.columnMapping.mode", "name") \
    .mode("overwrite") \
.saveAsTable(f"{catalog}.{bronze_schema}.fts_delivery_double_verify")
