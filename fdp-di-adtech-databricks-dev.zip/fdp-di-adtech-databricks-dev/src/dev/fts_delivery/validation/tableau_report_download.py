# Databricks notebook source
#%pip install --upgrade typing_extensions
#import tableauserverclient as TSC
import os
import zipfile
import sys
from os.path import basename
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from email.mime.text import MIMEText
from email.utils import COMMASPACE, formatdate
from datetime import datetime, date,timedelta
from email.mime.image import MIMEImage
from email.message import EmailMessage
from email.utils import make_msgid
import pandas as pd
import argparse
import requests
import json
import logging

st_time=datetime.now()

# COMMAND ----------

# MAGIC %run ../fts_delivery_config

# COMMAND ----------

# MAGIC %sh
# MAGIC aws --version
# MAGIC aws configure set region us-west-2 --profile databricks-fng-prod
# MAGIC aws configure set s3.signature_version s3v4 --profile databricks-fng-prod
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile databricks-fng-prod
# MAGIC aws configure set role_arn arn:aws:iam::640862407089:role/fng-dmo-prod-databricks-ec2-role --profile databricks-fng-prod

# COMMAND ----------

class cls_ssm(object):
    def __init__(self, aws_profile='default'):    
        import boto3
        try:
            session = boto3.Session(profile_name = aws_profile)
            client = session.client('ssm')

            self.client=client
            self.aws_profile=aws_profile

        except Exception as e:
            raise Exception('ERROR: '+ str(e))
        
    def get_ssm_param_by_path(self, path, full_path_dict_key=False, next_token=' ', keyvalue_dict={}) :
        # Get all values for all keys from SSM Path as Dictionary
        try:
            #-----------------------------------------------------------------------------------------------------------
            # To reset the keyvalue_dict we need to have below code , if we remove it is having trace of previous calls
            #-----------------------------------------------------------------------------------------------------------
            if next_token==' ':
                keyvalue_dict={}
                response  = self.client.get_parameters_by_path(Path=path, WithDecryption=True, Recursive=True)
            else:
                response  = self.client.get_parameters_by_path(Path=path, NextToken=next_token, WithDecryption=True, Recursive=True)

            for parameter in response['Parameters'] :

                if full_path_dict_key:
                    key = parameter['Name']
                else:
                    key = parameter['Name'].split('/')[-1]

                keyvalue_dict[key] = parameter['Value']
            #---------------------------------------------------------------------------------------------------------------
            # if there is more than 10 param in same path we need to paginate through next sets using next token from response
            #--------------------------------------------------------------------------------------------------------------
            if 'NextToken' in response.keys():
                next_token = response['NextToken']
                keyvalue_dict = self.get_ssm_param_by_path(path, full_path_dict_key, next_token, keyvalue_dict)

            if keyvalue_dict=={}:
                value = self.client.get_parameter(Name = path, WithDecryption = True)['Parameter']['Value']

                if full_path_dict_key:
                    key = path
                else:
                    key = path.split('/')[-1]

                keyvalue_dict[key]=value

            #print(keyvalue_dict)
            return keyvalue_dict
        except Exception as e:
            raise Exception('ERROR: '+ str(e))


# COMMAND ----------

# Tableau Cloud

def retrieve_tableau_cloud_pat():
    ssm_obj = cls_ssm('databricks-fng-prod')
    cred_dict = ssm_obj.get_ssm_param_by_path('/fox/prod/tableau_cloud/', full_path_dict_key=False, next_token=' ', keyvalue_dict={})
    return cred_dict['patpassword']

def establish_tableau_cloud_connection(
        server_name="us-west-2b.online.tableau.com",
        version="3.22",
        site_url_id="foxanalytics",
        personal_access_token_name="Adsales_Jobs"):
    pat = retrieve_tableau_cloud_pat()
    signin_url = "https://{server}/api/{version}/auth/signin".format(server=server_name, version=version)
    payload = {
        "credentials":
            {
                "personalAccessTokenName": personal_access_token_name,
                "personalAccessTokenSecret": pat,
                "site": {
                    "contentUrl": site_url_id
                }
            }
    }
    headers = {
        'accept': 'application/json',
        'content-type': 'application/json'
    }
    print(f"Trying to establish connection to Tableau Cloud. SIGNIN_URL: {signin_url}")
    req = requests.post(signin_url, json=payload, headers=headers)
    req.raise_for_status()

    print(f"Successfully established connection to Tableau Cloud. SIGNIN_URL: {signin_url}")
    response = json.loads(req.content)
    token = response["credentials"]["token"]
    site_id = response["credentials"]["site"]["id"]
    headers['X-tableau-auth'] = token
    return headers, token, site_id

  
def download_tableau_view_as_csv(
        view_luid,
        csv_file_path,
        server_name="us-west-2b.online.tableau.com",
        version="3.22",
        headers=None):
    if not headers:
        headers, token, site_id = establish_tableau_cloud_connection()
    url = f"https://{server_name}/api/{version}/sites/{site_id}/views/{view_luid}/data"
    
    headers = {
        'X-Tableau-Auth': token
    }

    response = requests.get(url, headers=headers)
    response.raise_for_status()
    print("Successfully downloaded tableau view contents.")


    if os.path.isfile(csv_file_path):
        print(f"{csv_file_path} file exists. Deleting currently existing file on file system")
        os.remove(csv_file_path)
        print(f"Successfully removed old file: {csv_file_path}")
    print(f"Dumping tableau view contents into a csv file: {csv_file_path}.")
    with open(csv_file_path, 'wb') as file:
        file.write(response.content)
    print(f"Successfully dumped tableau view contents into a csv file: {csv_file_path}")

    # Sign out from Tableau Cloud
    url = f"https://{server_name}/api/{version}/auth/signout"
    print("Signing out of Tableau Cloud.")
    response = requests.post(url, headers=headers)
    #response.raise_for_status()
    logging.info("Successfully signed out of Tableau Cloud.")

def create_file(view_luid):
  today = date.today()
  current_directory = os.getcwd()
  relative_path = 'tableau_output/'
  PREVIEW_FOLDER_LOCATION = os.path.join(current_directory, relative_path)
  print(PREVIEW_FOLDER_LOCATION)
  if not os.path.exists(PREVIEW_FOLDER_LOCATION):
      os.makedirs(PREVIEW_FOLDER_LOCATION)

  csv_file_path = None
  PREVIEW_FILE_EXTENSION = '.csv'
  csv_file_path = (PREVIEW_FOLDER_LOCATION+'fts_tableau_delivery_report'+PREVIEW_FILE_EXTENSION)

  download_tableau_view_as_csv(view_luid=view_luid, csv_file_path=csv_file_path)
  fts_delivery_metrics_df = pd.read_csv(csv_file_path)
  return fts_delivery_metrics_df
