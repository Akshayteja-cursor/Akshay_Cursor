# Databricks notebook source
spark.conf.set("spark.sql.ansi.enabled", "false")

# COMMAND ----------

import boto3
import email
from datetime import datetime, timezone
from io import BytesIO
import zipfile
import os
import pandas as pd
from pyspark.sql.functions import regexp_extract, col, when, instr, substring, abs
import configparser
from pyspark.sql.functions import col, lit, to_date, to_timestamp, unix_timestamp, datediff, from_unixtime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication

# COMMAND ----------

# MAGIC %run ./tableau_report_download

# COMMAND ----------

# MAGIC %run ../fts_delivery_config

# COMMAND ----------

dbutils.widgets.text("aws_profile", "")
dbutils.widgets.text("aws_arn", "")
dbutils.widgets.text("email_bucket", "")
aws_profile=dbutils.widgets.get('aws_profile')
email_bucket=dbutils.widgets.get('email_bucket')
aws_arn=dbutils.widgets.get('aws_arn')
dbutils.widgets.text("env", "")
env = dbutils.widgets.get("env")

# COMMAND ----------

config = configparser.ConfigParser()
config = fts_delivery_config[env]
display(config)
catalog=config['catalog']
silver_schema=config['silver_schema']
gold_schema=config['gold_schema']
bronze_schema = config['bronze_schema']
from_email = config['from_email']
raw_schema = config['raw_schema']
cc_mail = config['cc_mail']
to_mail = config['to_mail']
lucid_id = config['lucid_id']
ad_sales_catalog = config['ad_sales_catalog']

# COMMAND ----------

import os
os.environ["AWS_PROFILE_VAR"] = aws_profile
os.environ["AWS_ARN"] = aws_arn

# COMMAND ----------

# MAGIC %sh
# MAGIC aws configure set region us-west-2 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set s3.signature_version s3v4 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile $AWS_PROFILE_VAR
# MAGIC aws configure set role_arn $AWS_ARN --profile $AWS_PROFILE_VAR

# COMMAND ----------

# MAGIC %md
# MAGIC ##email sending

# COMMAND ----------

def build_excel_and_send_mail(
        validation_config,
        missing_file_alert,
        from_email,
        to_mail,
        cc_mail,
        aws_profile,
        s3_bucket
):

    session = boto3.Session(profile_name=aws_profile)
    s3 = session.client("s3")
    ses = session.client("ses", region_name="us-west-2")
    def write_sheet(writer, df, sheet_name):
        if df.rdd.isEmpty():
            columns = df.columns   
            pdf = pd.DataFrame(columns=columns)
        else:
            pdf = df.toPandas()
        pdf.to_excel(writer, index=False, sheet_name=sheet_name)

        ws = writer.sheets[sheet_name]
        for i, col in enumerate(pdf.columns):
            if len(pdf) == 0:
                width = len(col) + 2   
            else:
                width = max(pdf[col].astype(str).map(len).max(), len(col))
            ws.set_column(i, i, width)

    
    tableau_file_name = f"Tableau_vs_FTS_Delivery_validation_DVPS_{datetime.today().strftime('%Y-%m-%d')}.xlsx"
    tableau_buffer = BytesIO()

    with pd.ExcelWriter(tableau_buffer, engine="xlsxwriter") as writer:
        for cfg in validation_config.values():
            write_sheet(writer, cfg["df"], cfg["sheet"])

    tableau_buffer.seek(0)

    tableau_key = f"fts_delivery_validation_reports/{tableau_file_name}"
    s3.put_object(Bucket=s3_bucket, Key=tableau_key, Body=tableau_buffer.getvalue())

    html_body = """
            <p>Hi Team,</p>

            <p>Please find attached the latest <b>FTS Delivery Validation(DVPS)</b> report</p>
            """
    
    html_body += "<p><b>📊 Mismatch Summary:</b></p><ul>"

    for name, cfg in validation_config.items():
        if "count" in cfg:
            count = cfg["count"]
            sheet = cfg["sheet"]

            if count > 0:
                color = "red"
                icon = "⚠"
                display_text = f"{count} mismatched records"
            else:
                color = "green"
                icon = "✅"
                display_text = "No Variance Observed"

            html_body += f"""
            <li>
                {icon} <b>{sheet}:</b> 
                <span style='color:{color}; font-weight:bold;'>{display_text}</span>
                 (refer sheet: <b>{sheet}</b>)
            </li>
            """

    html_body += "</ul>"

    # Missing files section
    if missing_file_alert:
        html_body += "<p><b>⚠ Missing Files/Data:</b></p><ul>"
        for msg in missing_file_alert:
            html_body += f"<li><b>{msg}</b></li>"
        html_body += "</ul>"

  

    html_body += "</ul>"

    html_body += """
    <p>This report summarizes any delivery differences identified during today’s validation run.</p>
    <p>Thanks</p>
    <p>Data Ops Support Team</p>
    """

    # --------------------------------------------------
    # SEND EMAIL
    # --------------------------------------------------
    email_message = MIMEMultipart()
    email_message["From"] = from_email
    email_message["To"] = ", ".join(to_mail)
    email_message["Cc"] = ", ".join(cc_mail)
    email_message["Subject"] = f"FTS Delivery Validation – {datetime.today().strftime('%Y-%m-%d')}"

    email_message.attach(MIMEText(html_body, "html"))

    # --------------------------------------------------
    # Function to download file from S3
    # --------------------------------------------------
    def get_s3_file_bytes(s3_client, bucket, key):
        # print(f"Downloading from s3://{bucket}/{key}")
        resp = s3_client.get_object(Bucket=bucket, Key=key)
        return resp["Body"].read()

    tableau_bytes = get_s3_file_bytes(s3, s3_bucket, tableau_key)

    tableau_file = MIMEApplication(tableau_bytes, Name=tableau_file_name)
    tableau_file.add_header("Content-Disposition", f'attachment; filename="{tableau_file_name}"')
    email_message.attach(tableau_file)

    session = boto3.Session(profile_name=aws_profile)
    ses = session.client("ses", region_name="us-west-2")

    ses.send_raw_email(
        Source=from_email,
        Destinations=list(set(to_mail).union(set(cc_mail))),
        RawMessage={"Data": email_message.as_string()}
    )

    print("📧 Validation Email Sent Successfully!")


# COMMAND ----------

# MAGIC
# MAGIC %md
# MAGIC ####Tableau report extraction
# MAGIC

# COMMAND ----------

tableau_df = create_file(lucid_id)

# COMMAND ----------

fts_del_tab_df = (
    tableau_df.pivot_table(
        index=["Deal ID", "Line #","Date","Advertiser","Billing Ad Server","Ad Server Source","Order Line ID"],
        columns="Measure Names",
        values="Measure Values",
        aggfunc="first"
    ).reset_index()
)

# COMMAND ----------

fts_del_tab_df_spark = spark.createDataFrame(fts_del_tab_df)
fts_del_tab_df_spark = fts_del_tab_df_spark.withColumn(
                              "Date",
                              to_date(col("Date"), "M/d/yyyy")
                          )

# COMMAND ----------

fts_del_tab_df_spark.createOrReplaceTempView("tableau_source_data")

# COMMAND ----------

# MAGIC %md
# MAGIC ####DVPS

# COMMAND ----------

session = boto3.Session(profile_name=aws_profile)

s3 = session.client('s3')

bucket = email_bucket #'fdp-dmo-emails-test'
prefix = 'adsales/dev/fts/'

# Step 1: Get today's date (UTC because S3 uses UTC)
today = datetime.now(timezone.utc).date() 
# today = (datetime.now(timezone.utc) - pd.Timedelta(days=1)).date()

response = s3.list_objects_v2(Bucket=bucket, Prefix=prefix)

# Step 2: Filter today's files
today_files = [
    obj for obj in response.get('Contents', [])
    if obj['LastModified'].date() == today
]

print(f"Found {len(today_files)} files for today")

# Step 3: Process each SES email file
for obj in today_files:
    key = obj['Key']
    print(f"\nProcessing: {key}")

    # Get file content
    file_obj = s3.get_object(Bucket=bucket, Key=key)
    raw_email = file_obj['Body'].read()

    # Parse email
    msg = email.message_from_bytes(raw_email)

    # Step 4: Iterate attachments
    for part in msg.walk():
        if part.get_content_disposition() == 'attachment':
            filename = part.get_filename()

            if filename:
                print("Found attachment:", filename)

                # Step 5: Check filename
                if filename == "AOS Delivery Report - DV - 60 day lookback.zip":
                    print("Matched target file ✅")

                    attachment_data = part.get_payload(decode=True)

                    # Step 6: Unzip file
                    with zipfile.ZipFile(BytesIO(attachment_data)) as z:
                        for file_name in z.namelist():
                            print("Inside ZIP:", file_name)

                            if file_name.endswith('.csv'):
                                with z.open(file_name) as f:
                                    dv_df = pd.read_csv(f)

# COMMAND ----------

# Order Name = aos order id /deal id
# Campaign Name = aos line id
# Impressions (3rd Party) - third party deliverd impressions
# Clicks (3rd Party) - third party clicks

# COMMAND ----------

dv_df = spark.createDataFrame(dv_df)

# COMMAND ----------

from pyspark.sql.functions import col, when, instr, substring, regexp_extract


df_deal = dv_df.withColumn(
    "deal_id",
    when(instr(col("Order Name"), "_") == 4,
         substring(col("Order Name"), 1, 3))
    .when(instr(col("Order Name"), "_") == 5,
         substring(col("Order Name"), 1, 4))
)


df_deal_filtered = df_deal.filter(col("deal_id").rlike("^[0-9]+$"))


df_final = df_deal_filtered.withColumn(
    "line_id",
    when(
        col("deal_id").isNotNull(),
        regexp_extract(col("Campaign Name"), r'^(\d+)', 1)
    ).otherwise(None)
)


df_final = df_final.withColumn("deal_id", col("deal_id").cast("bigint")) \
                   .withColumn("line_id", col("line_id").cast("bigint"))


df_final = df_final.select(
    "deal_id",
    "line_id",
    "Order Name",
    "Campaign Name",
    "Impressions (3rd Party)",
    "Clicks (3rd Party)",
    "Report Start Date",
    "Advertiser"
)


df_final.createOrReplaceTempView("dvps_source_data")

# COMMAND ----------

validalion_sql = """WITH dvps AS (
  SELECT 
    deal_id,
    line_id,
    Advertiser,
    TO_DATE(`Report Start Date`, 'MM/dd/yyyy') AS date,

    SUM(CAST(REPLACE(`Impressions (3rd Party)`, ',', '') AS BIGINT)) AS third_party_impressions,
    SUM(CAST(REPLACE(`Clicks (3rd Party)`, ',', '') AS BIGINT)) AS third_party_clicks 

  FROM dvps_source_data
  GROUP BY deal_id, line_id, Advertiser, TO_DATE(`Report Start Date`, 'MM/dd/yyyy')
),

tableau_dvps AS (
  SELECT 
    Date,
    `Line #`,
    Advertiser,
    `Deal Id`,
    `Order Line ID`,
    `Billing Ad Server`,

    SUM(CAST(REPLACE(`Delivered Impressions Third Party`, ',', '') AS BIGINT)) AS delivered_impressions_third_party,
    SUM(CAST(REPLACE(`Third Party Clicks`, ',', '') AS BIGINT)) AS third_party_clicks 

  FROM tableau_source_data
  WHERE Date
          BETWEEN DATE_SUB(current_date(), 60) 
          AND DATE_SUB(current_date(), 1)
  GROUP BY ALL
)
,fnl as (
SELECT 
  d.deal_id AS deal_id,
  `Order Line ID` as order_line_id,
  --f.`Deal ID` AS fts_deal_id,
  --d.line_id,
  f.`Line #` as line_id,

  --d.Advertiser,
  f.Advertiser as advertiser_name,


  d.date as date,
  --f.Date as fts_date,
`Billing Ad Server` as billing_ad_server,
  d.third_party_impressions AS dvps_third_party_impressions,
  f.delivered_impressions_third_party AS tableau_delivered_impressions_third_party,

  (COALESCE(d.third_party_impressions,0) - COALESCE(f.delivered_impressions_third_party,0)) 
    AS third_party_impressions_variance,

  ROUND(
     ((COALESCE(d.third_party_impressions,0) - COALESCE(f.delivered_impressions_third_party,0)) 
    / COALESCE(d.third_party_impressions,0)) * 100, 2
  ) AS third_party_impressions_variance_percentage,

  d.third_party_clicks AS dvps_third_party_clicks,
  f.third_party_clicks AS tableau_third_party_clicks,

  (COALESCE(d.third_party_clicks,0) - COALESCE(f.third_party_clicks,0)) 
    AS third_party_clicks_variance,

  ROUND(
     ((COALESCE(d.third_party_clicks,0) - COALESCE(f.third_party_clicks,0)) 
    / COALESCE(d.third_party_clicks,0)) * 100, 2
  ) AS third_party_clicks_variance_percentage

FROM dvps d
LEFT JOIN tableau_dvps f 
  ON d.deal_id = f.`Deal ID` 
 AND d.date = f.Date 
 --AND d.line_id = f.`Line #`
 AND (
        d.line_id = f.`Line #`
        OR (
             d.line_id = f.`Order Line ID`
             --AND d.line_id NOT IN (
               --     SELECT DISTINCT `Line #`
                 --   FROM tableau_dvps
                 --)
           )
     )
WHERE f.`Deal ID` IS NOT NULL
)
select * from fnl
"""
validation_df = spark.sql(validalion_sql)


# COMMAND ----------

# 🔹 Impressions DF (> 3% variance)
impressions_df = validation_df.filter(
     (
        (col("third_party_impressions_variance") > 10) |
        (col("third_party_impressions_variance") < -10)
    )
).select(
    "deal_id","line_id","order_line_id","billing_ad_server","date","advertiser_name",
    "dvps_third_party_impressions",
    "tableau_delivered_impressions_third_party",
    "third_party_impressions_variance",
    "third_party_impressions_variance_percentage",
    "dvps_third_party_clicks",
    "tableau_third_party_clicks",
    "third_party_clicks_variance",
    "third_party_clicks_variance_percentage"
)


# COMMAND ----------

validation_config = {
    "dvps_validation": {
        "df": validation_df,
        "sheet": "dvps_validation"
    },
    "dvps_third_party_metrics": {
        "df": impressions_df,
        "sheet": "dvps_3rd_party_varience",
        "count":impressions_df.count()
    }
}

# COMMAND ----------

build_excel_and_send_mail(
    validation_config=validation_config,
    missing_file_alert=[],
    from_email=from_email,
    to_mail=to_mail,
    cc_mail=cc_mail,
    aws_profile=aws_profile,
    s3_bucket=f'fox-fdp-bi-{env}'
)
