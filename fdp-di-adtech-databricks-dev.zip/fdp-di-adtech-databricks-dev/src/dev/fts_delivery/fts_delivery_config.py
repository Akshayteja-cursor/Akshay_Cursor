# Databricks notebook source
fts_delivery_config={
"dev": {
'catalog' : 'fox_bi_dev',
'ad_sales_catalog':'fox_bi_qa',
'raw_schema':'raw_ads',
'bronze_schema':'bronze_ads',
'silver_schema':'silver_ads',
'gold_schema' : 'gold_ads',
'from_email':'adtech.dev@data.fox',
'to_mail':["narendra.pedakoleme@fox.com"],
'cc_mail':[],
'lucid_id':'7379994a-790c-45e0-aac2-04432a7187ee'
  },
"prod": {
'catalog' : 'fox_bi_prod',
'ad_sales_catalog':'fox_bi_prod',
'raw_schema':'raw_ads',
'bronze_schema':'bronze_ads',
'silver_schema':'silver_ads',
'gold_schema' : 'gold_ads',
'from_email':'adtech.prod@data.fox',
'to_mail':["yogesh.nageswararao@fox.com","Anitha.Mohanraj@fox.com","data_adtech@fox.com",
                 "alex.lehman@fox.com"
                ],
'cc_mail':["FTSRevenueOps@fox.com",
           "Kyle.Wood@fox.com",
           "Eric.Olivencia@fox.com",
           "Pradeep.Panneerselvam@fox.com",
           "Allison.Katz@fox.com",
           "kimberly.perkins@fox.com",
           "narendra.pedakoleme@fox.com",
           "dani.deritis@fox.com",
           "marissa.demartini@FOX.com",
           "mallory.melody@FOX.com"
           ],
   'lucid_id':'3d510e76-80ce-4d58-9aa7-5b423f91d4b3'
  },
 
}


