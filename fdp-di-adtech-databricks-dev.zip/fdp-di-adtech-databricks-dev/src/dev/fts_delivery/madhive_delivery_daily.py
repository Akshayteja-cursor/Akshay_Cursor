# Databricks notebook source
import configparser
from datetime import datetime,timedelta
import pytz
import boto3
from datetime import datetime
from pyspark.sql import SparkSession

# COMMAND ----------

dbutils.widgets.text("aws_profile", "")
dbutils.widgets.text("aws_arn", "")
aws_profile=dbutils.widgets.get('aws_profile')
aws_arn=dbutils.widgets.get('aws_arn')
dbutils.widgets.text("env", "")
env = dbutils.widgets.get("env")

# COMMAND ----------

import os
os.environ["AWS_PROFILE_VAR"] = aws_profile
os.environ["AWS_ARN"] = aws_arn

# COMMAND ----------

# MAGIC %sh
# MAGIC aws configure set region us-west-2 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set s3.signature_version s3v4 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile $AWS_PROFILE_VAR
# MAGIC aws configure set role_arn $AWS_ARN --profile $AWS_PROFILE_VAR
# MAGIC

# COMMAND ----------

# MAGIC %run ./fts_delivery_config

# COMMAND ----------

config = configparser.ConfigParser()
config = fts_delivery_config[env]
display(config)
catalog=config['catalog']
silver_schema=config['silver_schema']
gold_schema=config['gold_schema']
bronze_schema = config['bronze_schema']

# COMMAND ----------

event_start_date = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')

# COMMAND ----------

timezone = pytz.timezone("UTC")
dbutils.widgets.text("event_start_date", "")
start_date = dbutils.widgets.get('event_start_date')
start_date = datetime.strptime(start_date, '%Y-%m-%d')
start_date = start_date + timedelta(days=2)
print(type(start_date))
print(start_date.replace(tzinfo=timezone).strftime('%Y-%m-%d'))


# COMMAND ----------


timezone = pytz.timezone("UTC")
start_date = dbutils.widgets.get('event_start_date')
if start_date:
  start_date = datetime.strptime(start_date, '%Y-%m-%d')
  start_date = start_date + timedelta(days=2)
  event_start_date = start_date.replace(tzinfo=timezone).strftime('%Y-%m-%d')
  print(event_start_date)
global aws_profile
aws_profile =aws_profile
# Set up boto3 for S3 access (make sure AWS creds are configured)
session = boto3.Session(profile_name=aws_profile)
s3 = session.client('s3')

# Define your S3 details
bucket_name = 'bi-lz-analytics-import'
prefix = 'fts/madhive/'  
if env.lower() == 'prod':
  response = s3.list_objects_v2(Bucket=bucket_name, Prefix=prefix)

  # Extract today's file(s)
  todays_files = [
      f"s3://{bucket_name}/{obj['Key']}"
      for obj in response.get('Contents', [])
      if event_start_date in obj['Key']
  ]
  todays_files.sort()
else:
  response =  dbutils.fs.ls(f"s3://{bucket_name}/{prefix}")
  todays_files = [
      file.path
      for file in response
      if event_start_date in file.name
  ]
  todays_files.sort()
# Read file(s) using Spark
if todays_files:
    #df = spark.read.csv(todays_files[0], header=True)  # or use `.json`, `.parquet`, etc.
    #df.show()
    file_name = todays_files[0]

# file_name = f's3://bi-lz-analytics-import/fts/madhive/Sample_Schema_Output_MadhiveAOSE2EReporting_{event_start_date }.csv'
# file_name = 's3://bi-lz-analytics-import/fts/madhive/delivery_2025-06-02T09:03:11_part_0.csv'
print(file_name)


# COMMAND ----------


# df = spark.read.format("csv") \
#     .option("header", "true") \
#     .load(file_name)

df = spark.read.format("csv") \
    .option("header", True) \
    .option("delimiter", ",") \
    .option("quote", '"') \
    .option("escape", '"') \
    .option("multiLine", True) \
    .load(file_name)

# COMMAND ----------

df.head()

# COMMAND ----------

df.write.format("delta") \
    .option("delta.columnMapping.mode", "name") \
    .mode("overwrite") \
    .saveAsTable(f"{catalog}.{bronze_schema}.fts_delivery_madhive")
