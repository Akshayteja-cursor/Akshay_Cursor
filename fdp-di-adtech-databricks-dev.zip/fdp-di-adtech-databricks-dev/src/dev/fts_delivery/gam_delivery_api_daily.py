# Databricks notebook source
from googleads import ad_manager, oauth2, errors
import boto3
import os
from typing import Any
import json
import tempfile
from datetime import datetime, timedelta
import pytz
import time
import pandas as pd
from pyspark.sql import SparkSession
import pyspark.sql.types as T
import pyspark.sql.functions as F
from pyspark import SparkFiles
import configparser
import os

# COMMAND ----------

dbutils.widgets.text("aws_profile", "")
dbutils.widgets.text("aws_arn", "")
aws_profile=dbutils.widgets.get('aws_profile')
aws_arn=dbutils.widgets.get('aws_arn')
dbutils.widgets.text("env", "")
env = dbutils.widgets.get("env")

# COMMAND ----------

os.environ["AWS_PROFILE_VAR"] = aws_profile
os.environ["AWS_ARN"] = aws_arn

# COMMAND ----------

# MAGIC %run ./fts_delivery_config

# COMMAND ----------

# MAGIC
# MAGIC %sh
# MAGIC aws configure set region us-west-2 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set s3.signature_version s3v4 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile $AWS_PROFILE_VAR
# MAGIC aws configure set role_arn $AWS_ARN --profile $AWS_PROFILE_VAR
# MAGIC

# COMMAND ----------

config = configparser.ConfigParser()
config = fts_delivery_config[env]
display(config)
catalog=config['catalog']
silver_schema=config['silver_schema']
gold_schema=config['gold_schema']
bronze_schema = config['bronze_schema']

# COMMAND ----------

global aws_profile, APPLICATION_NAME, NETWORK_CODE
aws_profile = aws_profile
APPLICATION_NAME = 'AdSales - GAM Data Ingestion'
NETWORK_CODE = 4145
spark = SparkSession.builder.appName('GAM Report Data Load').getOrCreate()
spark.conf.set("spark.sql.session.timeZone", "UTC")

# COMMAND ----------

def get_ad_manager_client(secret_arn: str) -> Any:
    session = boto3.Session(profile_name=aws_profile)
    resp = session.client('secretsmanager').get_secret_value(SecretId=secret_arn)
    secret = json.loads(resp['SecretString'])

    with tempfile.NamedTemporaryFile(mode='w', delete=False) as secret_file:
        json.dump(secret, secret_file, indent=2)
        secret_file.close()

    oauth2_client = oauth2.GoogleServiceAccountClient(secret_file.name, oauth2.GetAPIScope('ad_manager'))
    os.unlink(secret_file.name)
    ad_manager_client = ad_manager.AdManagerClient(oauth2_client, APPLICATION_NAME, NETWORK_CODE)

    return ad_manager_client

# COMMAND ----------

def format_to_datetime(date_dict: Any) -> datetime:
    return datetime(
        date_dict['date']['year'],
        date_dict['date']['month'],
        date_dict['date']['day'],
        date_dict['hour'],
        date_dict['minute'],
        date_dict['second'],
        tzinfo=pytz.timezone(date_dict['timeZoneId'])
    )

def format_datetime_to_obj(datetime_obj: Any) -> Any:
    obj = {}
    obj['year'] = datetime_obj.year
    obj['month'] = datetime_obj.month
    obj['day'] = datetime_obj.day
    return obj

def generate_processing_dates(start_date: datetime, end_date: datetime, step_size: int) -> list:
    processing_dates = []

    batch_start_date = start_date
    while batch_start_date <= end_date:
        batch_end_date = batch_start_date + timedelta(days=step_size - 1)
        if batch_end_date <= end_date:
            processing_dates.append((batch_start_date, batch_end_date))
        else:
            processing_dates.append((batch_start_date, end_date))
            break
        batch_start_date += timedelta(days=step_size)

    return processing_dates

def build_report_query(dimensions: list, columns: list, dimensionAttributes: list, start_date: datetime, end_date: datetime) -> Any:
    baseReportQuery = {
        'dimensions': [],
        'adUnitView': 'FLAT',
        'columns': [],
        'dimensionAttributes': [],
        'customFieldIds': [],
        'cmsMetadataKeyIds': [],
        'customDimensionKeyIds': [],
        'startDate': {},
        'endDate': {},
        'dateRangeType': 'CUSTOM_DATE',
        'statement': None,
        'reportCurrency': 'USD',
        'timeZoneType': 'PUBLISHER'
    }

    report_query = baseReportQuery
    report_query['dimensions'] = dimensions
    report_query['columns'] = columns
    report_query['dimensionAttributes'] = dimensionAttributes
    report_query['startDate'] = format_datetime_to_obj(start_date)
    report_query['endDate'] = format_datetime_to_obj(end_date)
    return report_query


# COMMAND ----------

def format_report(report_data: Any, report_type: str) -> Any:
    if report_type == 'Summary with Impressions and Clicks':
        format_columns = {
            'Dimension.DATE': ('event_date', T.DateType()),
            'Dimension.LINE_ITEM_ID': ('line_item_id', T.LongType()),
            'Dimension.CREATIVE_ID': ('creative_id', T.LongType()),
            'Dimension.ORDER_ID': ('order_id', T.LongType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS': ('total_line_item_level_impressions', T.LongType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_CLICKS': ('total_line_item_level_clicks', T.LongType())
            
        }
        select_cols = [
            'event_date',
            'line_item_id',
            'total_line_item_level_impressions',
            'total_line_item_level_clicks',
            'creative_id',
            'order_id'
            
        ]


    for k, v in format_columns.items():
        report_data = report_data.withColumnRenamed(k, v[0])
        report_data = report_data.withColumn(v[0], F.col(v[0]).cast(v[1]))

    report_data = report_data.select(select_cols)

    return report_data

# COMMAND ----------

if __name__ == '__main__':
    gam_service_account_creds_secret_arn = dbutils.widgets.text('gam_service_account_creds_secret_arn','')
    gam_api_version = dbutils.widgets.text('gam_api_version','')
    event_start_date = dbutils.widgets.text('event_start_date','')
    event_end_date = dbutils.widgets.text('event_end_date','')

    gam_service_account_creds_secret_arn = dbutils.widgets.get('gam_service_account_creds_secret_arn')
    gam_api_version = dbutils.widgets.get('gam_api_version')

    client = get_ad_manager_client(secret_arn=gam_service_account_creds_secret_arn)
    timezone = pytz.timezone("UTC")
    event_start_date_param = dbutils.widgets.get('event_start_date')
    event_end_date_param = dbutils.widgets.get('event_end_date')

    # Default start date = 7 days ago if not provided
    if not event_start_date_param:
        print('no start date ')
        event_start_date = datetime.today() - timedelta(days=7)
        event_start_date = event_start_date.replace(hour=0, minute=0, second=0, microsecond=0)
    else:
        event_start_date = datetime.strptime(event_start_date_param, '%Y-%m-%d')

    # Default end date = today if not provided
    if not event_end_date_param:
        print('no end date ')
        event_end_date = datetime.today().replace(hour=0, minute=0, second=0, microsecond=0)
    else:
        
        event_end_date = datetime.strptime(event_end_date_param, '%Y-%m-%d')
    print(event_start_date)
    print(event_end_date)
    # Apply UTC timezone
    event_start_date = timezone.localize(event_start_date)
    event_end_date = timezone.localize(event_end_date)
    #event_start_date = datetime.strptime(dbutils.widgets.get('event_start_date'), '%Y-%m-%d').replace(tzinfo=timezone)
    #event_end_date = datetime.strptime(dbutils.widgets.get('event_end_date'), '%Y-%m-%d').replace(tzinfo=timezone)

    process_days = (event_end_date-event_start_date).days
    processing_dates = generate_processing_dates(event_start_date, event_end_date, 1)

    # Summary with Impressions and Error Count
    print('Summary with Impressions and Clicks')
    for i, batch in enumerate(processing_dates):
        start_date, end_date = batch
        print(f"Processing {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}, batch - {i}", end=' ')
        report_service = client.GetService('ReportService', version=gam_api_version)
        report_query = build_report_query(
            dimensions = [
                'DATE',
                'LINE_ITEM_ID',
                'CREATIVE_ID',
                'ORDER_ID'
                
            ],
            columns = [
                'TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS',
                'TOTAL_LINE_ITEM_LEVEL_CLICKS'
                
            ],
            dimensionAttributes = [],
            start_date = start_date,
            end_date = end_date
        )
        report_job = report_service.runReportJob({'reportQuery': report_query})

        while True:
            status = report_service.getReportJobStatus(report_job['id'])
            if status == 'COMPLETED':
                break
            elif status == 'FAILED':
                break
            else:
                time.sleep(10)

        if status == 'COMPLETED':
            print('Downloading...', end=' ')
            report_download_url = report_service.getReportDownloadURL(report_job['id'], 'CSV_DUMP')
            report_data = spark.createDataFrame(pd.read_csv(report_download_url, compression='gzip'))
            if i == 0:
                final_df = format_report(report_data, 'Summary with Impressions and Clicks')
            else:
                final_df = final_df.union(format_report(report_data, 'Summary with Impressions and Clicks'))
            print('Completed')
        else:
            raise Exception('Report job failed')

    # final_df = final_df.withColumn('etl_created_timestamp', F.current_timestamp()).withColumn('etl_updated_timestamp', F.current_timestamp())
    # final_df.write.format('delta')\
    #      .partitionBy('event_date')\
    #      .option('mergeSchema', 'true')\
    #      .option('overwriteDynamicPartitions', 'true')\
    #      .option('delta.enableDeletionVectors', 'false')\
    #      .option('delta.enableIcebergCompatV2', 'true')\
    #      .option('delta.universalFormat.enabledFormats', 'iceberg')\
    #      .option('delta.columnMapping.mode', 'name')\
    #      .mode('overwrite')\
    #      .saveAsTable('fox_bi_prod.raw_ads.gam_delivery_api_daily')

    final_df.write.format('delta')\
       .mode('overwrite')\
       .option('partitionOverwriteMode', 'dynamic')\
       .saveAsTable(f'{catalog}.{bronze_schema}.fts_delivery_gam_api_4145')

    # display(final_df)


  

# COMMAND ----------


