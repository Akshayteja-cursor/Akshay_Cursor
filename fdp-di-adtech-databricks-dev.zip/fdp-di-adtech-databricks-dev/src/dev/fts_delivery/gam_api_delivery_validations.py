# Databricks notebook source
from googleads import ad_manager, oauth2, errors
import boto3
import os
from typing import Any
import json
import tempfile
from datetime import datetime, timedelta
import pytz
import time
import pandas as pd
from pyspark.sql import SparkSession
import pyspark.sql.types as T
import pyspark.sql.functions as F
from pyspark import SparkFiles
import io
from email import encoders
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
import configparser



# COMMAND ----------

# MAGIC %run ./fts_delivery_config

# COMMAND ----------

dbutils.widgets.text("aws_profile", "")
dbutils.widgets.text("aws_arn", "")
aws_profile=dbutils.widgets.get('aws_profile')
aws_arn=dbutils.widgets.get('aws_arn')
dbutils.widgets.text("env", "")
env = dbutils.widgets.get("env")

# COMMAND ----------

import os
os.environ["AWS_PROFILE_VAR"] = aws_profile
os.environ["AWS_ARN"] = aws_arn

# COMMAND ----------

# MAGIC %sh
# MAGIC aws configure set region us-west-2 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set s3.signature_version s3v4 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile $AWS_PROFILE_VAR
# MAGIC aws configure set role_arn $AWS_ARN --profile $AWS_PROFILE_VAR

# COMMAND ----------

config = configparser.ConfigParser()
dbutils.widgets.text("env", "")
env = dbutils.widgets.get("env")
config = fts_delivery_config[env]
display(config)
catalog=config['catalog']
silver_schema=config['silver_schema']
gold_schema=config['gold_schema']
bronze_schema = config['bronze_schema']
from_email = config['from_email']
raw_schema = config['raw_schema']
cc_mail = config['cc_mail']
to_mail = config['to_mail']

# COMMAND ----------

global aws_profile, APPLICATION_NAME, NETWORK_CODE
aws_profile = aws_profile
APPLICATION_NAME = 'AdSales - GAM Data Ingestion'
NETWORK_CODE = 63790564
cpe_s3_bucket = f'fox-fdp-bi-{env}'
spark = SparkSession.builder.appName('GAM Report Data Load').getOrCreate()
spark.conf.set("spark.sql.session.timeZone", "UTC")

# COMMAND ----------

def format_report(report_data: Any, report_type: str) -> Any:
    if report_type == 'Summary with Impressions and Clicks':
        format_columns = {
            'Dimension.DATE': ('event_date', T.DateType()),
            'Dimension.ORDER_ID': ('order_id', T.LongType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS': ('total_line_item_level_impressions', T.LongType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_CLICKS': ('total_line_item_level_clicks', T.LongType())
            
        }
        select_cols = [
            'event_date',
            'order_id',
            'total_line_item_level_impressions',
            'total_line_item_level_clicks',
            
            
        ]


    for k, v in format_columns.items():
        report_data = report_data.withColumnRenamed(k, v[0])
        report_data = report_data.withColumn(v[0], F.col(v[0]).cast(v[1]))

    report_data = report_data.select(select_cols)

    return report_data

# COMMAND ----------

def get_ad_manager_client(secret_arn: str,NETWORK_CODE) -> Any:
    session = boto3.Session(profile_name=aws_profile)
    resp = session.client('secretsmanager').get_secret_value(SecretId=secret_arn)
    secret = json.loads(resp['SecretString'])

    with tempfile.NamedTemporaryFile(mode='w', delete=False) as secret_file:
        json.dump(secret, secret_file, indent=2)
        secret_file.close()

    oauth2_client = oauth2.GoogleServiceAccountClient(secret_file.name, oauth2.GetAPIScope('ad_manager'))
    os.unlink(secret_file.name)
    ad_manager_client = ad_manager.AdManagerClient(oauth2_client, APPLICATION_NAME, NETWORK_CODE)

    return ad_manager_client

# COMMAND ----------

def format_to_datetime(date_dict: Any) -> datetime:
    return datetime(
        date_dict['date']['year'],
        date_dict['date']['month'],
        date_dict['date']['day'],
        date_dict['hour'],
        date_dict['minute'],
        date_dict['second'],
        tzinfo=pytz.timezone(date_dict['timeZoneId'])
    )

def format_datetime_to_obj(datetime_obj: Any) -> Any:
    obj = {}
    obj['year'] = datetime_obj.year
    obj['month'] = datetime_obj.month
    obj['day'] = datetime_obj.day
    return obj

def generate_processing_dates(start_date: datetime, end_date: datetime, step_size: int) -> list:
    processing_dates = []

    batch_start_date = start_date
    while batch_start_date <= end_date:
        batch_end_date = batch_start_date + timedelta(days=step_size - 1)
        if batch_end_date <= end_date:
            processing_dates.append((batch_start_date, batch_end_date))
        else:
            processing_dates.append((batch_start_date, end_date))
            break
        batch_start_date += timedelta(days=step_size)

    return processing_dates

def build_report_query(dimensions: list, columns: list, dimensionAttributes: list, start_date: datetime, end_date: datetime) -> Any:
    baseReportQuery = {
        'dimensions': [],
        'adUnitView': 'FLAT',
        'columns': [],
        'dimensionAttributes': [],
        'customFieldIds': [],
        'cmsMetadataKeyIds': [],
        'customDimensionKeyIds': [],
        'startDate': {},
        'endDate': {},
        'dateRangeType': 'CUSTOM_DATE',
        'statement': None,
        'reportCurrency': 'USD',
        'timeZoneType': 'PUBLISHER'
    }

    report_query = baseReportQuery
    report_query['dimensions'] = dimensions
    report_query['columns'] = columns
    report_query['dimensionAttributes'] = dimensionAttributes
    report_query['startDate'] = format_datetime_to_obj(start_date)
    report_query['endDate'] = format_datetime_to_obj(end_date)
    return report_query


# COMMAND ----------


def get_latest_report(report_date: datetime, key_format_string: str):
    session = boto3.Session(profile_name=aws_profile)
    s3 = session.client('s3')
    for delta in range(0, -7, -1):
        date = report_date + timedelta(days=delta)
        key = date.strftime(key_format_string)
        try:
            print(f'Trying object s3://{cpe_s3_bucket}/{key}')
            s3.head_object(Bucket=cpe_s3_bucket, Key=key)
            return key
        except s3.exceptions.ClientError as exc:
            if exc.response['Error']['Code'] == '404':
                continue
            raise
    raise RuntimeError('Could not find report')

# COMMAND ----------

class ReportMailInfo:
    # from_email = 'adtech.prod@data.fox'
    from_email = from_email
    reply_to_address = 'data_adtech@fox.com'
    key = ''
    info = {}
    report_mailing_lists = {
        "GAM Validation Report 1" : {
            "key_format_string" : "gam_analytics_impressions/AD Tech news GAM delivery analytics daily data Impressions validation Report_%d%b%Y.csv",
            "human_readable_name" : "AdTech News GAM Delivery Analytics Daily Data Impressions Validation Report",
            "to" : to_mail,
            "cc" :cc_mail
        },
        "GAM Validation Report 2" : {
            "key_format_string" : "gam_analytics_impressions/AD Tech FTS GAM delivery analytics daily data Impressions validation Report_%d%b%Y.csv",
            "human_readable_name" : "AdTech FTS GAM Delivery Analytics Daily Data Impressions Validation Report",
            "to" : to_mail,
            "cc" : cc_mail
                
        },
        

        
    }

    def __init__(self, report, report_date):
        self.info = self.report_mailing_lists[report]
        self.key = get_latest_report(report_date, self.info['key_format_string'])

    def get_file_name(self):
        return os.path.basename(self.key)
    
    def get_report_body(self, report_date):
        footer = f'<p>This is an automated email. Please direct any questions or concerns to <a href="mailto: {self.reply_to_address}">{self.reply_to_address}</a>.</p>'
        body_text = f"""<p>Hello,</p>

<p>Please find attached the {self.info['human_readable_name']}.</p>

{footer}
"""
        return MIMEText(body_text, 'html')

    def get_report_attachment(self):
        session = boto3.Session(profile_name=aws_profile)
        s3 = session.client('s3')
        resp = s3.get_object(Bucket=cpe_s3_bucket, Key=self.key)
        return resp['Body'].read()



# COMMAND ----------

def send_mail(report_name, report_date):
    
    report = ReportMailInfo(report_name, report_date)

    attachment_ready_html = []
    img_id = 0
    mime_images = []

    msg = MIMEMultipart()
    msg['Subject'] = report.info['human_readable_name'].title()
    msg['From'] = report.from_email
    msg['To'] = ", ".join(report.info['to'])
    msg['Cc'] = ", ".join(report.info['cc'])
    msg.attach(report.get_report_body(report_date))

    part = MIMEApplication(
        report.get_report_attachment(),
        Name=report.get_file_name(),
    )
    part['Content-Disposition'] = f'attachment; filename="{report.get_file_name()}"'
    msg.attach(part)

    session = boto3.Session(profile_name = aws_profile)
    ses = session.client('ses', region_name='us-west-2')
    ses.send_raw_email(
        Source=msg['From'],
        Destinations=list(set(report.info['to']).union(set(report.info['cc']))),
        RawMessage={'Data': msg.as_string()}
    )

    print('Email sent')


# COMMAND ----------

def get_report_send_mail(client,report_name,network_code):
    timezone = pytz.timezone("UTC")
    event_start_date = dbutils.widgets.text("event_start_date", "")
    event_end_date = dbutils.widgets.text("event_end_date", "")
    event_start_date_param = dbutils.widgets.get('event_start_date')
    event_end_date_param = dbutils.widgets.get('event_end_date')

    # Default start date = 7 days ago if not provided
    if not event_start_date_param:
        print('no start date ')
        event_start_date = datetime.today() - timedelta(days=7)
        event_start_date = event_start_date.replace(hour=0, minute=0, second=0, microsecond=0)
    else:
        event_start_date = datetime.strptime(event_start_date_param, '%Y-%m-%d')

    # Default end date = today if not provided
    if not event_end_date_param:
        print('no end date ')
        event_end_date = datetime.today().replace(hour=0, minute=0, second=0, microsecond=0)
    else:
        
        event_end_date = datetime.strptime(event_end_date_param, '%Y-%m-%d')

    # Apply UTC timezone
    event_start_date = timezone.localize(event_start_date)
    event_end_date = timezone.localize(event_end_date)
    #event_start_date = datetime.strptime(dbutils.widgets.get('event_start_date'), '%Y-%m-%d').replace(tzinfo=timezone)
    #event_end_date = datetime.strptime(dbutils.widgets.get('event_end_date'), '%Y-%m-%d').replace(tzinfo=timezone)

    process_days = (event_end_date-event_start_date).days
    processing_dates = generate_processing_dates(event_start_date, event_end_date, 1)

    # Summary with Impressions and Error Count
    print('Summary with Impressions and Clicks')
    for i, batch in enumerate(processing_dates):
        start_date, end_date = batch
        print(f"Processing {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}, batch - {i}", end=' ')
        report_service = client.GetService('ReportService', version=gam_api_version)
        report_query = build_report_query(
            dimensions = [
                'DATE',
                'ORDER_ID'
                
                
            ],
            columns = [
                'TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS',
                'TOTAL_LINE_ITEM_LEVEL_CLICKS'
                
            ],
            dimensionAttributes = [],
            start_date = start_date,
            end_date = end_date
        )
        report_job = report_service.runReportJob({'reportQuery': report_query})

        while True:
            status = report_service.getReportJobStatus(report_job['id'])
            if status == 'COMPLETED':
                break
            elif status == 'FAILED':
                break
            else:
                time.sleep(10)

        if status == 'COMPLETED':
            print('Downloading...', end=' ')
            report_download_url = report_service.getReportDownloadURL(report_job['id'], 'CSV_DUMP')
            report_data_df = pd.read_csv(report_download_url, compression='gzip')
            print(report_data_df.shape)
            
            
            if report_data_df.empty:
                continue
            #print(report_data_df)
            report_data = spark.createDataFrame(report_data_df)
            if i == 0:
                final_df = format_report(report_data, 'Summary with Impressions and Clicks')
            else:
                final_df = final_df.union(format_report(report_data, 'Summary with Impressions and Clicks'))
            print('Completed')
        else:
            raise Exception('Report job failed')

    table_query = f"""
        SELECT ad_delivery_date as event_date, SUM(first_party_delivered_impressions) as first_party_delivered_impressions FROM {catalog}.{silver_schema}.ft_fts_delivery_daily 
        
        where ad_delivery_date >= '{event_start_date}' AND ad_delivery_date <= '{event_end_date}' AND data_source_name = 'GAM' and network_group_id ='{NETWORK_CODE}' GROUP BY 1 ;
    """
    order_query = f"""
        
            select distinct order_id from {catalog}.{raw_schema}.gam_order
            WHERE order_name like '%Google Ad Manager - Fox News'
            """
    table_df = spark.sql(table_query)
    print('code---- ',network_code)
    print('actual count ',final_df.count())
    if network_code == 4145:
        order_df = spark.sql(order_query)
        print('before join ',final_df.count( ))
        final_df = final_df.join(order_df, on='order_id', how='inner')
        


        

        print('after join ',final_df.count())
    final_df = final_df.groupBy("event_date").agg(
            F.sum("TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS").alias("TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS"),
            F.sum("TOTAL_LINE_ITEM_LEVEL_CLICKS").alias("TOTAL_LINE_ITEM_LEVEL_CLICKS")
        )
    print('after grouping ',final_df.count())
    print(final_df.count())

    # Get unique event_date values and count the number of records for each date
    unique_event_dates_count = final_df.groupBy('event_date').count()
    display(unique_event_dates_count)

    unique_event_dates_count = table_df.groupBy('event_date').count()
    #display(unique_event_dates_count)
    display(final_df.head())
    
    final_df = final_df.select('event_date', 'TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS', 'TOTAL_LINE_ITEM_LEVEL_CLICKS')
    print(final_df.head())
    validation_df = table_df.join(final_df, on='event_date', how='left')
    print('valiation prit')
    display(validation_df.count())

    

    validation_df = validation_df.withColumn(
        'first level Impressions Variance %',
        F.round(
            (F.col('first_party_delivered_impressions') - F.col('TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS')) / F.col('TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS') * 100,
            3
        )
    )

    unique_event_dates_count = validation_df.groupBy('event_date').count()
    #display(unique_event_dates_count)
    validation_df = validation_df.sort('event_date')
    validation_df = validation_df.select('event_date', 'first_party_delivered_impressions', 'first level Impressions Variance %')
    
    

    with io.StringIO() as output:
        validation_df.toPandas().to_csv(output, index=False)
        validation_data = output.getvalue()

    
    session = boto3.Session(profile_name=aws_profile)
    s3_client = session.client('s3')
    s3_bucket = cpe_s3_bucket
    s3_key = 'gam_analytics_impressions/' + report_name
    s3_client.put_object(
        Bucket=s3_bucket,
        Body=validation_data.encode('utf-8'),
        Key=s3_key,
    )

    
    return validation_df

# COMMAND ----------

if __name__ == '__main__':
    gam_service_account_creds_secret_arn = dbutils.widgets.text('gam_service_account_creds_secret_arn','')
    gam_api_version = dbutils.widgets.text('gam_api_version','')
    gam_service_account_creds_secret_arn = dbutils.widgets.get('gam_service_account_creds_secret_arn')
    gam_api_version = dbutils.widgets.get('gam_api_version')
    report_name = 'AD Tech FTS GAM delivery analytics daily data Impressions validation Report_' + datetime.today().strftime('%d%b%Y') + '.csv'
    NETWORK_CODE = 63790564
    print('running network ',NETWORK_CODE)
    client = get_ad_manager_client(gam_service_account_creds_secret_arn,NETWORK_CODE)
    get_report_send_mail(client, report_name,NETWORK_CODE)
    send_mail('GAM Validation Report 2', datetime.today())
    NETWORK_CODE = 4145
    report_name = 'AD Tech news GAM delivery analytics daily data Impressions validation Report_' + datetime.today().strftime('%d%b%Y') + '.csv'
    client = get_ad_manager_client(gam_service_account_creds_secret_arn,NETWORK_CODE)
    get_report_send_mail(client, report_name,NETWORK_CODE)
    send_mail('GAM Validation Report 1', datetime.today())
                  
  
