# Databricks notebook source
# COMMAND ----------

# MAGIC %run "/Workspace/Users/prajwal.harikishor@fox.com/fdp-di-adtech-databricks/src/dev/data_reporting_and_operational_processing/core"

# COMMAND ----------

# MAGIC %run "/Workspace/Users/prajwal.harikishor@fox.com/fdp-di-adtech-databricks/src/dev/data_reporting_and_operational_processing/alert"

# COMMAND ----------

from typing import Optional
import re
import io
from datetime import datetime, timedelta
from typing import Any, Set
import pandas as pd
import numpy as np
import boto3

# COMMAND ----------

def find_staq_file(report_date: datetime) -> str:
    session = boto3.Session(profile_name=aws_profile)
    s3 = session.client('s3')

    staq = 'STAQ_Adjuster_Billing_Adjustment_TEST_This_Month_' + report_date.strftime('%Y-%m-%d')

    paginator = s3.get_paginator('list_objects_v2')
    page_iterator = paginator.paginate(Bucket=staq_bucket)

    for page in page_iterator:
        for obj in page.get('Contents', []):
            if staq in obj['Key']:
                return obj['Key']

# COMMAND ----------

def read_fw_billing(billing_master: str, billing_month: datetime, skiprows: int = 0) -> pd.DataFrame:
    fw_billing = pd.read_csv(
        billing_master,
        usecols={
            'Ad Unit ID',
            'Placement ID',
            'Campaign ID',
            'Campaign Name',
            'Series Name',
            'Budget Model',
            'Net Counted Ads',
            'Gross Counted Ads',
            'Booked On-Target Impression Goal',
            'Impression Goal',
            'FFDR (%)',
            'Forced Over Delivery Percent (%)',
            'Creative Duration',
            'Ad Unit Price',
            'Event Month',
        },
        dtype={
            'Ad Unit ID': 'int64',
            'Placement ID': 'int64',
            'Campaign ID': 'int64',
            'Campaign Name': 'object',
            'Series Name': 'object',
            'Budget Model': 'object',
            'Net Counted Ads': 'object',
            'Gross Counted Ads': 'object',
            'Booked On-Target Impression Goal': 'object',
            'Impression Goal': 'object',
            'FFDR (%)': 'float64',
            'Forced Over Delivery Percent (%)': 'object',
            'Creative Duration': 'object',
            'Ad Unit Price': 'object',
        },
        na_values={
            'Forced Over Delivery Percent (%)': [
                'Network Default',
            ],
        },
        parse_dates=[
            'Event Month',
        ],
        thousands=',',
        encoding='utf-8',
        skiprows=skiprows,
        storage_options={'profile': aws_profile}
    )

    int_cols = ['Net Counted Ads', 'Gross Counted Ads', 'Booked On-Target Impression Goal']
    float_cols = ['Impression Goal', 'Creative Duration', 'Ad Unit Price']

    for col in int_cols:
        fw_billing[col] = fw_billing[col].str.replace(',', '').fillna(0).astype('int64')
    for col in float_cols:
        fw_billing[col] = fw_billing[col].str.replace(',', '').fillna(0).astype('float64')

    fw_billing.loc[:, 'In Current Month'] = (fw_billing['Event Month'].dt.month == billing_month.month) & (
        fw_billing['Event Month'].dt.year == billing_month.year)
    fw_billing = fw_billing[fw_billing['In Current Month']]

    fw_billing.loc[:, 'Estimated Impression Goal'] = 0
    return fw_billing


def op_monthly_invoice(op_oms: pd.DataFrame, op_finance_billing: pd.DataFrame, billing_end_date: datetime) -> pd.DataFrame:
    op_monthly = op_finance_billing.loc[
        op_finance_billing.loc[
            :,
            'In Current Month',
        ],
        :,
    ]
    op_finance_bill_agg = op_monthly.groupby(op_monthly.index).agg(
        {
            'Invoice ID': 'max',
            'Billing Notes': 'max',
            'Net Invoice Amount': 'max',
            'Billing Period End Date': 'min',
        },
    )

    op_oms_billing = pd.merge(
        op_oms.drop(['Invoice ID', 'Billing Notes',
                    'Net Invoice Amount', 'Billing Period End Date'], axis=1),
        op_finance_bill_agg,
        left_on=['Parent Sales Line Item ID'],
        right_index=True,
        how='left',
    ).fillna(
        {
            'Billing Period End Date': datetime.combine(billing_end_date, datetime.min.time()),
        },
    )

    op_oms_billing.fillna(
        value={
            'Include on Invoice': '',
            'Billing Notes': '',
        },
        inplace=True)
    op_oms_billing.loc[:, 'Special Billing Instructions'] = op_oms_billing.apply(
        billing_instructions, axis=1)

    order_line_notes = op_oms_billing.groupby(
        'Sales Order ID',
    ).agg(
        {
            'Sales Line Item ID': 'min',
            'Special Billing Instructions': lambda x: x.iloc[0],
        },
    ).reset_index(drop=True)

    op_oms_billing = pd.merge(
        op_oms_billing.reset_index().drop('Special Billing Instructions', axis=1),
        order_line_notes,
        left_on=['Sales Line Item ID'],
        right_on=['Sales Line Item ID'],
        how='left',
    ).set_index('Placement ID')

    return op_oms_billing


def do_billing_adjustment_report(op_oms: pd.DataFrame, billing_pm: pd.DataFrame, billing_month: datetime) -> pd.DataFrame:
    print(billing_pm)
    billing_end_date = pd.to_datetime(billing_month + pd.tseries.offsets.MonthEnd()).date()
    billing_end = datetime.combine(billing_end_date, datetime.max.time())

    global drop_bucket
    s3_dir = f's3://{drop_bucket}/'
    op_invoices_filename = 'FinanceExport_Template.csv'
    operative_invoice = s3_dir + 'operative/' + op_invoices_filename
    pacing_name = 'Ad Ops Pacing (Analytics) Fox New FW Last Month Monthly Agg.csv'
    billing_master = s3_dir + 'freewheel/' + pacing_name

    demo_monthly_name = 'Ad Ops Pacing (Analytics) Fox New FW Demo Monthly Agg.csv'
    demo_daily_name = 'Ad Ops Pacing (Analytics) Fox New FW Demo Daily Agg.csv'

    ad_ops_pacing_demo = s3_dir + 'freewheel/' + demo_monthly_name
    ad_ops_pacing_demo_daily = s3_dir + 'freewheel/' + demo_daily_name

    try:
        fw_billing = read_fw_billing(billing_master, billing_end)
    except:
        fw_billing = read_fw_billing(billing_master, billing_end, skiprows=4)
    (fw_billing_vpvh, vpvh_agg_dict, band_to_vpvh_mean) = merge_vpvh(fw_billing, billing_end)
    # adjuster_billing = read_adjuster(billing_pm, skiprows=8)
    
    staq_billing = read_staq(billing_pm, skiprows=0)

    op_finance_billing = read_op_invoices(operative_invoice, billing_end)
    op_oms_billing = filter_op_orders(op_oms, billing_end, billing_month.replace(day=1) - timedelta(days=1))
    op_oms_billing = op_monthly_invoice(op_oms_billing, op_finance_billing, billing_end_date)

    fw_adj_agg_bill = merge_delivery_data(op_oms_billing, fw_billing, staq_billing, fw_billing_vpvh, vpvh_agg_dict)
    try:
        fw_demo_agg_bill = read_fw_demo(ad_ops_pacing_demo, ad_ops_pacing_demo_daily, billing_end, monthly=True)
    except:
        fw_demo_agg_bill = read_fw_demo(ad_ops_pacing_demo, ad_ops_pacing_demo_daily, billing_end, monthly=True, skiprows=4)

    op_fw_adj_bill = merge_order_delivery(op_oms_billing, fw_adj_agg_bill, fw_demo_agg_bill)
    op_fw_adj_bill = calculate_metrics(op_fw_adj_bill, band_to_vpvh_mean, billing_end)

    return op_fw_adj_bill


def bar_am_override(df: pd.DataFrame, override_file: str) -> pd.DataFrame:
    return df


def filter_programmatic(df: pd.DataFrame) -> pd.DataFrame:
    return df


def cost_method_override(row: pd.Series) -> Any:
    if row['Billable Metric'] == 'Bill on Contract':
        return 'Flat Rate'
    return row['Cost Method']


def format_billing(df: pd.DataFrame) -> pd.DataFrame:
    df['Demo Band'] = df.apply(calc_demo_band, axis=1)
    df = df.loc[
        ~df['Operative Product Type'].isin({'Package'}),
        :,
    ]
    bill_adj_report = df.reindex(
        [
            'Invoice Organization Name',
            'Programmatic Type',
            'Sales Line Item ID',
            'Agency Name',
            'Agency ID',
            'Advertiser ID',
            'Advertiser Name',
            'Sales Order Name',
            'Sales Order ID',
            'Parent Sales Line Item Name',
            'Parent Sales Line Item ID',
            'Sales Line Item Name',
            'Placement ID',
            'Placement Property',
            'Cost Method',
            'Net Unit Cost',
            'Billable Metric',
            'Billable Impressions',
            'Billable Revenue',
            'Price',
            'Revised Billed Impressions',
            'Revised Billed Revenue',
            'Parent Line Item Revenue',
            'Reason for Revision',
            'Special Billing Instructions',
            '1P Imps',
            '3P Imps',
            '1P Demo Imps',
            '3P Demo Imps',
            'Viewability',
            'Demo Comp',
            'Equivalization Factor',
            'Equivalized Imps',
            'Billing Scenario',
            'Rounded Scaled Active Net Invoice Amount',
            'Quantity',
            'Net Cost',
            'Campaign',
            'Campaign ID',
            'Demo Band',
            'External PO Ref',
            'Sales Region',
            'Primary Salesperson Full Name',
            'Sales Line Item Type',
            'Product Name',
            'Invoice ID',
            'Billing Period End Date',
            'Parent Line Item Start Date',
            'Parent Line Item End Date',
            'Buy Type',
            'Previously Billed',
            'Linear Liability',
            'is_magnite_deal',
        ],
        axis='columns',
    )

    bill_adj_report.rename(
        {
            'Invoice Organization Name': 'Invoicing Organization',
            'Agency Name': 'Agency',
            'Advertiser Name': 'Advertiser',
            'Campaign Name': 'Campaign',
            'Sales Order Name': 'Sales Order',
            'Parent Sales Line Item ID': 'Parent Line Item ID',
            'Parent Sales Line Item Name': 'Parent Line Item',
            'Placement ID': 'PS Line Item ID',
            'Sales Line Item Name': 'Sales Line Item',
            'Rounded Scaled Active Net Invoice Amount': 'Net Invoice Amount',
            'Product Name': 'Product',
            'Primary Salesperson Full Name': 'Primary Salesperson',
            'Buy Type': 'Product Category',
        },
        axis=1,
        inplace=True,
    )

    bill_adj_report.fillna(
        {
            'Campaign ID': bill_adj_report['Sales Order ID'],
            'Campaign': bill_adj_report['Sales Order'],
            'Demo Comp': 0,
            'Viewability': 1,
            'Billable Revenue': 0,
            'Billable Impressions': 0,
            'PS Line Item ID': bill_adj_report['Sales Line Item ID'],
        },
        inplace=True,
    )

    bill_adj_report = bill_adj_report.astype(
        {
            'Campaign ID': 'int64',
            'Billable Impressions': 'int64',
        },
    )

    bill_adj_report = bill_adj_report.drop(
        'Sales Line Item ID',
        axis=1,
    )

    bill_adj_report.replace(
        to_replace={'Cost Method': 'SOV-Flat Rate'},
        value='Flat Rate',
        inplace=True,
    )

    bill_adj_report.replace(
        to_replace={'Sales Region': '-'},
        value=' - ',
        regex=True,
        inplace=True,
    )

    bill_adj_report.replace(
        to_replace={'Primary Salesperson': 'Dave Greenberg'},
        value='David Greenberg',
        inplace=True,
    )

    bill_adj_report.replace(
        to_replace={'Primary Salesperson': "Brittany O'Brien"},
        value='Brittany OBrien',
        inplace=True,
    )

    bill_adj_report.replace(
        to_replace={'Primary Salesperson': 'Joseph Murphy'},
        value='Joe Murphy',
        inplace=True,
    )

    bill_adj_report.replace(
        to_replace={'Sales Region': 'Midwest - FOX'},
        value='Mid-West - FOX',
        inplace=True,
    )

    bill_adj_report.replace(
        to_replace={'Placement Property': 'FOXNow'},
        value='Fox.com',
        inplace=True,
    )

    bill_adj_report.replace(
        to_replace={'Placement Property': 'FOX Sports Clips'},
        value='FSEN',
        inplace=True,
    )

    bill_adj_report.replace(
        to_replace={'Placement Property': 'SendToNews'},
        value='FSEN',
        inplace=True,
    )

    bill_adj_report.replace(
        to_replace={'Placement Property': 'Deportes Streaming'},
        value='Deportes',
        inplace=True,
    )

    bill_adj_report.replace(
        to_replace={'Placement Property': 'Deportes Clips'},
        value='FoxDeportes.com',
        inplace=True,
    )

    bill_adj_report.replace(
        to_replace={'Placement Property': 'Deportes Display'},
        value='FoxDeportes.com',
        inplace=True,
    )

    bill_adj_report.replace(
        to_replace={'Placement Property': 'FOX Sports - Facebook/Instagram'},
        value='FOX Sports - FB-Inst',
        inplace=True,
    )

    bill_adj_report.replace(
        to_replace={'Placement Property': 'FOX - Facebook/Instagram'},
        value='Fox - FB-Insta',
        inplace=True,
    )

    bill_adj_report.replace(
        to_replace={'Placement Property': 'Deportes - Facebook/Instagram'},
        value='Deportes - FB-Insta',
        inplace=True,
    )

    bill_adj_report.loc[:, 'Cost Method'] = bill_adj_report.apply(cost_method_override, axis=1)
    bill_adj_report.loc[:, 'Net Unit Cost'] = bill_adj_report['Net Unit Cost'].apply(format_currency)
    bill_adj_report.loc[:, 'Net Cost'] = bill_adj_report['Net Cost'].apply(format_currency)
    bill_adj_report.loc[:, 'Billable Revenue'] = bill_adj_report['Billable Revenue'].apply(format_currency)
    bill_adj_report.loc[:, 'Net Invoice Amount'] = bill_adj_report['Net Invoice Amount'].apply(format_currency)
    bill_adj_report.loc[:, 'Report Date'] = datetime.today()

    return bill_adj_report

def apply_vpvh_elimination(op_fw_adj_bill: pd.DataFrame) -> pd.DataFrame:
    op_fw_adj_bill['Demo Band Temp'] = op_fw_adj_bill.apply(calc_demo_band, axis=1)

    op_fw_adj_bill['Demo Comp Temp'] = np.where(op_fw_adj_bill['Placement Property'] == 'FOX DAI VOD',
                                                -1, op_fw_adj_bill['Demo Comp'])
    
    op_fw_adj_bill['Demo Comp 1'] = np.where(op_fw_adj_bill['Placement Property'] == 'FOX DAI VOD',
                                             op_fw_adj_bill.groupby('Parent Sales Line Item ID')['Demo Comp Temp'].transform('max'), op_fw_adj_bill['Demo Comp'])
    
    op_fw_adj_bill['Demo Comp 2'] = np.where(op_fw_adj_bill['Placement Property'] == 'FOX DAI VOD',
                                             np.where(op_fw_adj_bill['Parent Sales Line Item ID'] == op_fw_adj_bill['Sales Line Item ID'],
                                                      op_fw_adj_bill['Planned Demo Comp'], op_fw_adj_bill['Demo Comp 1']),
                                             op_fw_adj_bill['Demo Comp 1'])
    
    op_fw_adj_bill['count_1'] = op_fw_adj_bill.groupby(['Parent Sales Line Item ID', 'Placement Property'])['Placement Property'].transform(len)
    op_fw_adj_bill['count_2'] = op_fw_adj_bill.groupby(['Parent Sales Line Item ID'])['Parent Sales Line Item ID'].transform(len)

    op_fw_adj_bill['Demo Comp 3'] = np.where(op_fw_adj_bill['Placement Property'] == 'FOX DAI VOD',
                                             np.where(op_fw_adj_bill['count_1']>1,
                                                      np.where(op_fw_adj_bill['count_1'] == op_fw_adj_bill['count_2'],
                                                               op_fw_adj_bill['Planned Demo Comp'], op_fw_adj_bill['Demo Comp 2']),
                                                      op_fw_adj_bill['Demo Comp 2']),
                                             op_fw_adj_bill['Demo Comp 2'])
    
    op_fw_adj_bill['Demo Comp 4'] = np.where(op_fw_adj_bill['Placement Property'] == 'FOX DAI VOD',
                                             np.where(op_fw_adj_bill['Demo Band Temp'] == 'Audience Target',
                                                      0, op_fw_adj_bill['Demo Comp 3']),
                                             op_fw_adj_bill['Demo Comp 3'])
    
    op_fw_adj_bill['Demo Comp 5'] = np.where(op_fw_adj_bill['Placement Property'] == 'FOX DAI VOD',
                                             np.where(op_fw_adj_bill['Billable Metric'] == 'Bill on Contract',
                                                      op_fw_adj_bill['Demo Comp'], op_fw_adj_bill['Demo Comp 4']),
                                             op_fw_adj_bill['Demo Comp 4'])
    
    op_fw_adj_bill['Demo Comp New'] = np.where(op_fw_adj_bill['Placement Property'] == 'FOX DAI VOD',
                                               np.where(op_fw_adj_bill['Billable Metric'] == 'Absolute A',
                                                        1.2, op_fw_adj_bill['Demo Comp 5']),
                                               op_fw_adj_bill['Demo Comp 5'])
    
    op_fw_adj_bill['Demo Comp New'] = op_fw_adj_bill['Demo Comp New'].astype('float64')

    op_fw_adj_bill.fillna(
        {
            'Impression Goal': 0,
            'Demo Comp New': 0,
        },
        inplace=True
    )

    op_fw_adj_bill['check_absA/audT'] = np.where(op_fw_adj_bill['Demo Band Temp'] == 'Audience Target',
                                                 True,
                                                 np.where(op_fw_adj_bill['Billable Metric'] == 'Absolute A',
                                                          True, False))
    
    op_fw_adj_bill['Billable Metric 1'] = np.where(op_fw_adj_bill['Placement Property'] == 'FOX DAI VOD',
                                                   np.where(op_fw_adj_bill['check_absA/audT'] == True,
                                                            np.where(op_fw_adj_bill['Billable Metric'] == 'Absolute A',
                                                                     'Absolute A',
                                                                     np.where(op_fw_adj_bill['Billable Third Party Server'] == '1st Party',
                                                                              '1P Audience Target', '3P Audience Target')),
                                                            np.where(op_fw_adj_bill['Demo Band Temp'] != 'P2+',
                                                                     np.where(op_fw_adj_bill['Billable Third Party Server'] == '1st Party',
                                                                              '1P Demo Imps', '3P Demo Imps'),
                                                                     np.where(op_fw_adj_bill['Billable Third Party Server'] == '1st Party',
                                                                             '1P CoView Imps', '3P CoView Imps'))),
                                                   op_fw_adj_bill['Billable Metric'])
    
    op_fw_adj_bill['Billable Metric New'] = np.where(op_fw_adj_bill['Placement Property'] == 'FOX DAI VOD',
                                                    np.where(op_fw_adj_bill['Billable Metric'] == 'Bill on Contract',
                                                             'Bill on Contract', op_fw_adj_bill['Billable Metric 1']),
                                                    op_fw_adj_bill['Billable Metric 1'])
    
    op_fw_adj_bill['Billable Metric New'] = np.where(op_fw_adj_bill['Implied Billable Metric'].str.contains('CoView', regex=True),
                                                     op_fw_adj_bill['Implied Billable Metric'], op_fw_adj_bill['Billable Metric New'])
    
    op_fw_adj_bill['Billable Metric New'] = np.where(op_fw_adj_bill['Product Name'].str.contains('SOV', regex=True),
                                                     'SOV', op_fw_adj_bill['Billable Metric New'])
    
    op_fw_adj_bill['Billable Impressions 1'] = np.where(op_fw_adj_bill['Placement Property'] == 'FOX DAI VOD',
                                                        np.where(op_fw_adj_bill['Billable Metric'] == 'VPVH Imps',
                                                                 np.where(op_fw_adj_bill['Demo Comp New'] != 0,
                                                                          np.where(op_fw_adj_bill['Billable Third Party Server'] == '1st Party',
                                                                                   op_fw_adj_bill['1P Imps']*op_fw_adj_bill['Demo Comp New'], op_fw_adj_bill['3P Imps']*op_fw_adj_bill['Demo Comp New']),
                                                                          np.where(op_fw_adj_bill['Billable Third Party Server'] == '1st Party',
                                                                                   op_fw_adj_bill['1P Imps'], op_fw_adj_bill['3P Imps'])),
                                                                 op_fw_adj_bill['Billable Impressions Active']),
                                                        op_fw_adj_bill['Billable Impressions Active'])

    op_fw_adj_bill['Billable Impressions 2'] = np.where(op_fw_adj_bill['Is Audience Target'] == True,
                                                        np.where(op_fw_adj_bill['Billable Third Party Server'] == '1st Party',
                                                                 op_fw_adj_bill['1P Imps'], op_fw_adj_bill['3P Imps']),
                                                        np.where(op_fw_adj_bill['Billable Metric New'] == 'Absolute A',
                                                                 np.where(op_fw_adj_bill['Billable Third Party Server'] == '1st Party',
                                                                          1.2*op_fw_adj_bill['1P Imps'], 1.2*op_fw_adj_bill['3P Imps']),
                                                                 op_fw_adj_bill['Billable Impressions 1']))

    op_fw_adj_bill['Billable Impressions New'] = np.where(op_fw_adj_bill['Product Name'].str.contains('SOV', regex=True),
                                                          np.where(op_fw_adj_bill['Impression Goal'] != 0,
                                                                   op_fw_adj_bill['Impression Goal'], op_fw_adj_bill['Billable Impressions 2']),
                                                          op_fw_adj_bill['Billable Impressions 2'])
    
    op_fw_adj_bill['Billable Revenue New'] = np.where(op_fw_adj_bill['Placement Property'] == 'FOX DAI VOD',
                                                      np.where(op_fw_adj_bill['Billable Metric'] == 'VPVH Imps',
                                                               (op_fw_adj_bill['Billable Impressions New']*op_fw_adj_bill['Net Unit Cost'])/1000,
                                                               op_fw_adj_bill['Billable Revenue Active']),
                                                      np.where(op_fw_adj_bill['Billable Metric New'] == 'SOV',
                                                               op_fw_adj_bill['Net Cost'],
                                                               op_fw_adj_bill['Billable Revenue Active']))

    op_fw_adj_bill['Billable Revenue New'] = op_fw_adj_bill['Billable Revenue New'].apply(pd.to_numeric)

    columns_to_drop = ['Demo Comp',
                       'Demo Comp Temp',
                       'Demo Comp 1',
                       'Demo Comp 2',
                       'Demo Comp 3',
                       'Demo Comp 4',
                       'Demo Comp 5',
                       'count_1',
                       'count_2',
                       'Billable Impressions Active',
                       'Billable Impressions 1',
                       'Billable Impressions 2',
                       'check_absA/audT',
                       'Billable Metric',
                       'Billable Metric 1',
                       'Billable Revenue Active',
                       'Demo Band Temp',
                       ]
    
    op_fw_adj_bill.drop(columns=columns_to_drop, inplace=True, axis=1)

    op_fw_adj_bill.rename(
        {
            'Billable Metric New': 'Billable Metric',
            'Billable Impressions New': 'Billable Impressions',
            'Billable Revenue New': 'Billable Revenue',
            'Demo Comp New': 'Demo Comp',
        },
        inplace=True,
        axis=1
    )
    
    return op_fw_adj_bill

def apply_pg_billing(df: pd.DataFrame, billing_month: datetime) -> pd.DataFrame:
    global drop_bucket
    s3_dir = f's3://{drop_bucket}/programmatic/monthly/dt={billing_month.strftime("%Y-%m")}/'
    fw_pg_filename = f"fw_pg_monthly_{billing_month.strftime('%Y-%m')}.parquet"
    fw_pg_file = s3_dir + fw_pg_filename

    pg_billing = pd.read_parquet(fw_pg_file, storage_options={'profile': aws_profile})

    pg_billing.drop(['Event Date'], axis=1, inplace=True)

    pg_billing = pg_billing.groupby(['Deal ID']).sum()

    pg_billing = pg_billing.rename({'Net Counted Ads': 'PG Impressions'}, axis=1)

    df = pd.merge(df, pg_billing, how='left', left_on='Placement ID', right_on='Deal ID', )

    def is_pg_deal(row: pd.Series) -> bool:
        if row['Invoice Organization Name'] in {'FOX Corp Programmatic Guaranteed', 'FOX Corp Programmatic/Reseller Buys', 'FOX Corp Programmatic - Magnite', 'FOX Corp Programmatic - PubMatic'}:
            return True
        return False
    
    def billable_metric(row: pd.Series) -> str:
        if row['is_pg_deal'] and row['Sales Order Name'] is not None and 'evergreen' in row['Sales Order Name'].lower():
            return 'Programmatic Reseller Imps'
        if row['is_pg_deal'] and row['Programmatic Type'] is not None and 'programmatic guaranteed' in row['Programmatic Type'].lower():
            return "Programmatic Guaranteed Imps"
        if row['is_pg_deal'] and row['Invoice Organization Name'] is not None and 'programmatic guaranteed' in row['Invoice Organization Name'].lower():
            return "Programmatic Guaranteed Imps"
        return row['Billable Metric']
    
    df.loc[:, 'is_pg_deal'] = df.apply(is_pg_deal, axis=1)

    df.loc[:, 'Billable Metric'] = df.apply(billable_metric, axis=1)

    df['1P Imps'] = np.where(df['is_pg_deal'] == True,
                             df['PG Impressions'], df['1P Imps'])
    
    df['Billable Impressions'] = np.where(df['is_pg_deal'] == True,
                                          df['PG Impressions'], df['Billable Impressions'])
    
    df['Billable Revenue'] = np.where(df['is_pg_deal'] == True,
                                      df['Net Unit Cost'] * df['Billable Impressions']/1000, df['Billable Revenue'])

    return df

def apply_magnite_billing(df: pd.DataFrame, billing_month: datetime) -> pd.DataFrame:
    global drop_bucket
    s3_dir = f's3://{drop_bucket}/'
    magnite_filename = 'Magnite_Lifetime_Delivery.parquet'
    magnite_file = s3_dir + 'processed/' + magnite_filename

    billing_start_date = billing_month
    billing_end_date = billing_month.replace(day=28) + timedelta(days=4)
    billing_end_date = billing_end_date - timedelta(days=billing_end_date.day)

    magnite_billing = pd.read_parquet(magnite_file, storage_options={'profile': aws_profile})
    magnite_billing.loc[:, 'Deal ID'] = magnite_billing['Deal ID'].str.strip()

    #Filter data for billing month
    magnite_billing = magnite_billing.loc[(magnite_billing['Date'] >= billing_start_date) & (magnite_billing['Date'] <= billing_end_date)]

    magnite_billing.drop(['Date'], axis=1, inplace=True)

    magnite_billing = magnite_billing.groupby(['Deal ID', 'Network']).sum().reset_index()

    magnite_billing.rename({'Deal ID':'Magnite Deal ID', 'Impressions':'Magnite Impressions', 'Total Gross Revenue':'Magnite Revenue'}, axis=1, inplace=True)

    def primary_placement_map(row: pd.Series) -> str:
        network_primary_placement_property_map = {
            'FOX Sports Streaming':'FOX Sports Streaming',
            'Tubi - One Fox':'Fox Sold Tubi',
            'FOX on Hulu':'FOX on Hulu',
            'FOXNow':'FOXNow',
            'FOX Business':'FOXBusiness.com',
            'FOX on Tubi':'FOX on Tubi',
            'FOX News':'FOXNews.com',
            'Fox SpringServe oRTB': '',
            'OneFox SpringServe oRTB brand': '',
            'Fox - Fox Television Stations - OneFox': 'Fox Sold FTS',
            'Fox - Weather - OneFox': 'FoxWeather.com',
            'FOX Weather': 'FoxWeather.com',
            'Tubi - One Fox- AAT Segments': '',
            'Fox Enterainment - OneFox - Segments': '',
            'OneFOX_AAT Segments': '',
        }

        try:
            return network_primary_placement_property_map[row['Network']]
        except:
            print('Unmapped Network - ',row['Network'])
            return ''
    
    def secondary_placement_map(row: pd.Series) -> str:
        network_secondary_placement_property_map = {
            'FOX Sports Streaming':'FOX Sports Clips',
            'Tubi - One Fox':'',
            'FOX on Hulu':'RON - Ent',
            'FOXNow':'RON - Ent',
            'FOX Business':'FOXNews.com',
            'FOX on Tubi':'FOX on Tubi',
            'FOX News':'RON - Ent',
            'Fox SpringServe oRTB': '',
            'OneFox SpringServe oRTB brand': '',
            'Fox - Fox Television Stations - OneFox': '',
            'Fox - Weather - OneFox': '',
            'FOX Weather': '',
            'Tubi - One Fox- AAT Segments': '',
            'Fox Enterainment - OneFox - Segments': '',
            'OneFOX_AAT Segments': '',
        }

        try:
            return network_secondary_placement_property_map[row['Network']]
        except:
            print('Unmapped Network - ',row['Network'])
            return ''

    magnite_billing.loc[:, 'Primary Placement Property'] = magnite_billing.apply(primary_placement_map, axis=1)
    magnite_billing.loc[:, 'Secondary Placement Property'] = magnite_billing.apply(secondary_placement_map, axis=1)

    def is_magnite_deal(row: pd.Series) -> bool:
        if row['Invoice Organization Name'] == 'FOX Corp Programmatic - Magnite':
            return True
        if 'PRG' in row['Product Name'] and 'Non Ad Served' in row['Product Name']:
            return True
        if row['Advertiser Name'] == 'MAGNITE':
            return True
        # if 'PRG' in row['Product Name'] and 'Non-Ad Served' in row['Product Name']:
        #     return True
        return False
    
    df.loc[:, 'is_magnite_deal'] = df.apply(is_magnite_deal, axis=1)

    def join_on_placement(row: pd.Series) -> bool:
        if row['is_magnite_deal'] == False:
            return False
        if row['Magnite Deal ID'] == None:
            return True
        if row['Primary Placement Property'] == '' and row['Secondary Placement Property'] == '':
            return True
        if row['Primary Placement Property'] == row['Placement Property']:
            return True
        if row['Secondary Placement Property'] == row['Placement Property']:
            return True
        return False
    
    magnite_billing = pd.merge(magnite_billing, df, how='left', left_on='Magnite Deal ID', right_on='Deal ID').reset_index(drop=True)
    magnite_billing.loc[:, 'join_on_placement'] = magnite_billing.apply(join_on_placement, axis=1)
    magnite_billing = magnite_billing[magnite_billing['join_on_placement'] == True]
    magnite_billing.rename({'Placement Property':'Magnite Placement Property'}, axis=1, inplace=True)
    magnite_billing = magnite_billing.loc[:, ['Magnite Deal ID', 'Magnite Placement Property', 'Magnite Impressions', 'Magnite Revenue']]
    magnite_billing = magnite_billing.groupby(['Magnite Deal ID', 'Magnite Placement Property']).sum().reset_index()

    df = pd.merge(df, magnite_billing, how='left', left_on=['Deal ID', 'Placement Property'], right_on=['Magnite Deal ID', 'Magnite Placement Property'])

    def billable_metric(row: pd.Series) -> str:
        if row['is_magnite_deal']:
            return 'Programmatic Guaranteed Imps'
        return row['Billable Metric']

    df.loc[:, 'Billable Metric'] = df.apply(billable_metric, axis=1)

    magnite_df = df[df['is_magnite_deal'] == True]

    other_df = df[df['is_magnite_deal'] == False]

    magnite_df.loc[:, '1P Imps'] = magnite_df['Magnite Impressions']
    magnite_df.loc[:, 'Billable Impressions'] = magnite_df['Magnite Impressions']
    magnite_df.loc[:, 'Billable Revenue'] = magnite_df['Net Unit Cost'] * magnite_df['Billable Quantity']/1000

    df = pd.concat([other_df, magnite_df])

    df.fillna(
        {
            '1P Imps': 0,
            'Billable Impressions': 0,
            'Billable Revenue': 0,
        },
        inplace=True,
    )

    return df

def filter_deal_type(bar: pd.DataFrame, types: Set[str]) -> pd.DataFrame:
    def row_filter(row: pd.Series) -> bool:
        for deal_type in types:
            if deal_type == 'Cash' and row['Invoicing Organization'] == 'FOX Sports & Entertainment' and 'BTN' not in row['Placement Property']:
                return True
            if deal_type == 'Fluidity' and row['Invoicing Organization'] == 'FOX Sports & Entertainment Fluidity' and 'BTN' not in row['Placement Property']:
                return True
            if deal_type == 'Fox Next' and row['Invoicing Organization'] in {'FOX Corp Programmatic Guaranteed', 'FOX Corp Programmatic/Reseller Buys'} and row['is_magnite_deal'] == False:
                return True
            if deal_type == 'Magnite' and row['is_magnite_deal'] == True:
                return True
            if deal_type == 'BTN' and 'BTN - Digital' in row['Placement Property']:
                return True
            if deal_type == 'Linear Liability' and row['Linear Liability'] and 'BTN' not in row['Placement Property']:
                return True
        return False
    return bar[bar.apply(row_filter, axis=1)].drop(columns=['Invoicing Organization', 'Linear Liability']).drop(columns=['is_magnite_deal'])


def export_billing(df: pd.DataFrame, billing_month: datetime, override: bool = False) -> str:
    if override:
        bar_filename = billing_month.strftime('%B_%Y_Billing_Adjustment_AM_Overrides')
    else:
        bar_filename = billing_month.strftime('%B_%Y_Billing_Adjustment')

    bar_cancelled = df.loc[
        df['Sales Line Item'].str.contains(
            '.*CANCEL.*',
            regex=True,
            flags=re.IGNORECASE,
            na=False,
        ),
        :,
    ]

    bill_adj_report = df.loc[
        ~df['Sales Line Item'].str.contains(
            '.*CANCEL.*',
            regex=True,
            flags=re.IGNORECASE,
            na=False,
        ),
        :,
    ]

    with io.BytesIO() as output:
        with pd.ExcelWriter(
            output,
            datetime_format='MM/dd/yyyy',
            engine='xlsxwriter',
            engine_kwargs={'options': {'strings_to_numbers': True}},
        ) as writer:
            workbook = writer.book
            money_fmt = workbook.add_format({'num_format': '$#,##0.00'})
            pct_fmt = workbook.add_format({'num_format': '0%'})
            filter_deal_type(bill_adj_report, {'Cash'}).to_excel(writer, sheet_name='Cash', index=False)
            filter_deal_type(bill_adj_report, {'Fluidity', 'Linear Liability'}).to_excel(writer, sheet_name='Fluidity', index=False)
            filter_deal_type(bill_adj_report, {'Fox Next'}).to_excel(writer, sheet_name='Programmatic', index=False)
            filter_deal_type(bill_adj_report, {'Magnite'}).to_excel(writer, sheet_name='Magnite', index=False)
            filter_deal_type(bill_adj_report, {'BTN'}).to_excel(writer, sheet_name='BTN', index=False)
            filter_deal_type(bar_cancelled, {'Cash'}).to_excel(writer, sheet_name='Cancelled Cash', index=False)
            filter_deal_type(bar_cancelled, {'Fluidity'}).to_excel(writer, sheet_name='Cancelled Fluidity', index=False)
            filter_deal_type(bar_cancelled, {'Fox Next'}).to_excel(writer, sheet_name='Cancelled Programmatic', index=False)
            filter_deal_type(bar_cancelled, {'Magnite'}).to_excel(writer, sheet_name='Cancelled Magnite', index=False)
            filter_deal_type(bar_cancelled, {'BTN'}).to_excel(writer, sheet_name='Cancelled BTN', index=False)
            for tab in ['Cash', 'Fluidity', 'Programmatic', 'Magnite', 'Cancelled Cash', 'Cancelled Fluidity', 'Cancelled Programmatic', 'Cancelled Magnite']:
                worksheet = writer.sheets[tab]
                [worksheet.set_column(col, 12, money_fmt)
                 for col in ['M:M', 'P:P', 'AI:AI', 'AK:AK']]
                worksheet.set_column('AA:AC', 8, pct_fmt)
        bar_data = output.getvalue()

    session = boto3.Session(profile_name=aws_profile)
    s3_client = session.client('s3')
    global drop_bucket
    s3_bucket = drop_bucket
    assert s3_bucket is not None
    report_dir = 'reports/'
    s3_key = report_dir + bar_filename + '.xlsx'
    s3_client.put_object(
        Bucket=s3_bucket,
        Body=bar_data,
        Key=s3_key,
    )

    return s3_key

# COMMAND ----------

def billing_adjustment_report(date: datetime, staq: str, override: Optional[str]) -> None:
    report_date = datetime.combine(date, datetime.min.time())
    # adj_pm = adjuster
    global drop_bucket
    s3_dir = f's3://{drop_bucket}/'
    staq_s3_dir = f's3://{staq_bucket}/'
    billing_pm = staq_s3_dir + staq

    prev_month = report_date.month - 1 if report_date.month != 1 else 12
    bill_year = report_date.year - 1 if prev_month == 12 else report_date.year

    billing_month = report_date.replace(year=bill_year, month=prev_month, day=1)
    print('Billing Month: ', billing_month)
    operative_filename = 'Operative_OMS.parquet'
    op_oms_file = s3_dir + 'processed/' + operative_filename
    op_oms = pd.read_parquet(op_oms_file, storage_options={'profile': aws_profile}).set_index('Placement ID')
    op_fw_adj_bill = filter_programmatic(
        do_billing_adjustment_report(
            op_oms,
            billing_pm,
            billing_month,
        ),
    )

    op_fw_adj_bill_vpvh_elim = apply_vpvh_elimination(op_fw_adj_bill)

    op_fw_adj_pg_bill = apply_pg_billing(op_fw_adj_bill_vpvh_elim, billing_month)

    op_fw_adj_pg_mag_bill = apply_magnite_billing(op_fw_adj_pg_bill, billing_month)

    op_fw_adj_pg_mag_bill = equivalize(op_fw_adj_pg_mag_bill, 'bar')

    if override is not None:
        op_fw_adj_pg_mag_bill = bar_am_override(op_fw_adj_pg_mag_bill, override)
    bill_adj_report = format_billing(op_fw_adj_pg_mag_bill).drop(['Programmatic Type'], axis=1)
    if override is not None:
        output_file = export_billing(bill_adj_report, billing_month, override=True)
    else:
        output_file = export_billing(bill_adj_report, billing_month)

    write_xcom_value('Billing Adjustment Report', output_file)

# COMMAND ----------

if __name__ == '__main__':
    report_date = dbutils.widgets.get('date')
    staq_file_date = dbutils.widgets.get('staq_file_date')
    global drop_bucket, aws_profile, staq_bucket
    drop_bucket = dbutils.widgets.get('drop_bucket')
    aws_profile = dbutils.widgets.get('aws_profile')
    staq_bucket = dbutils.widgets.get('staq_bucket')

    def parse_date(date: str) -> bool:
        format = "%Y-%m-%d"
        try:
            res = bool(datetime.strptime(date, format))
        except ValueError:
            res = False
        return res

    staq = find_staq_file(datetime.strptime(staq_file_date, "%Y-%m-%d"))

    assert parse_date(report_date), "Invalid date format, should be in YYYY-MM-DD format"
    assert staq, "Staq file not found"

    try:
        billing_adjustment_report(datetime.strptime(report_date, "%Y-%m-%d"), staq, override=None)
    except Exception as error:
        alert = Alert()
        alert.send('Billing Adjustment Report', f'{type(error).__name__}: {error}')
        dbutils.notebook.exit(f'ERROR!!! - {error}')