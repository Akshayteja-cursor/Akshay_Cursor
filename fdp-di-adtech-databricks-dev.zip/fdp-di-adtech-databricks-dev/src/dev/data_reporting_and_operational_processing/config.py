# Databricks notebook source
# MAGIC %sh
# MAGIC aws configure set region us-west-2 --profile databricks-cpe-dev
# MAGIC aws configure set s3.signature_version s3v4 --profile databricks-cpe-dev
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile databricks-cpe-dev
# MAGIC aws configure set role_arn arn:aws:iam::393000359662:role/data-infra-astro-bi-adtech-dev --profile databricks-cpe-dev
# MAGIC
# MAGIC aws configure set region us-west-2 --profile fox-datahub-nonprod
# MAGIC aws configure set s3.signature_version s3v4 --profile fox-datahub-nonprod
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile fox-datahub-nonprod
# MAGIC aws configure set role_arn arn:aws:iam::734701191032:role/fng-fox-datahub-nonprod-databricks-ec2-role --profile fox-datahub-nonprod