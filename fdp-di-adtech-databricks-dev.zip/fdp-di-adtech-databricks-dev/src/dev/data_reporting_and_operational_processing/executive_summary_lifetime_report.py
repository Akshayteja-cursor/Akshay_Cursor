# Databricks notebook source
# COMMAND ----------

# MAGIC %run "/Workspace/Users/prajwal.harikishor@fox.com/fdp-di-adtech-databricks/src/dev/data_reporting_and_operational_processing/core"

# COMMAND ----------

# MAGIC %run "/Workspace/Users/prajwal.harikishor@fox.com/fdp-di-adtech-databricks/src/dev/data_reporting_and_operational_processing/alert"

# COMMAND ----------

import re
import io
from datetime import datetime
import pandas as pd
import boto3

# COMMAND ----------

def cap_overdelivery(amount: float, capped_amount: float) -> float:
    # cap at 10% above Net Cost or Quantity
    overdelivery_cap = 1.1 * capped_amount
    if amount > overdelivery_cap:
        return overdelivery_cap
    return amount

def projected_rev_lifetime(row: pd.Series) -> float:
    proj_rev = row['Daily Pacing Rate'] * row['Remaining Flight Days in Lifetime']
    return cap_overdelivery(proj_rev, row['Net Cost'])

def total_projected_rev_lifetime(row: pd.Series) -> float:
    total_proj_rev = row['Earned Revenue'] + row['Projected Revenue in Lifetime']
    capped_amt = cap_overdelivery(total_proj_rev, row['Net Cost'])
    if capped_amt < row['Earned Revenue']:
        return float(row['Earned Revenue'])
    return capped_amt

def do_exec_sum_lifetime(report_date: datetime) -> str:
    global drop_bucket
    lifetime = pd.read_parquet(
        f's3://{drop_bucket}/processed/AdOps_Reporting_Lifetime_Delivery.parquet',
        storage_options={'profile': aws_profile}
    )

    lifetime.loc[:, 'Projected Revenue in Lifetime', ] = lifetime.apply(
        projected_rev_lifetime,
        axis=1,
    )

    lifetime.loc[:, 'Total Projected Revenue in Lifetime'] = lifetime.apply(
        total_projected_rev_lifetime,
        axis=1,
    )

    lifetime = lifetime.rename(
        {
            # 'Sales Line Item Run Rate (Capped)': 'Projected Revenue in Lifetime',
            'Billable Quantity': 'Billable Quantity in Lifetime',
            'Earned Revenue': 'Earned Revenue in Lifetime',
            'Billable Impressions Lifetime': 'Billable Impressions in Lifetime',
            'Billable Revenue Lifetime': 'Billable Revenue in Lifetime',
            'Billable Revenue Lifetime - Uncapped': 'Billable Revenue - Uncapped in Lifetime',
        },
        axis=1,
    )

    es_cols = [
        'Invoice Organization Name',
        'VP Sales',
        'Primary Salesperson Full Name',
        'Agency Name',
        'Agency ID',
        'Trafficker/Campaign Manager',
        'Advertiser Name',
        'Marketplace Type',
        'Sales Line Item Type',
        'Opportunity Unique ID',
        'Campaign ID',
        'Campaign Name',
        'Sales Order ID',
        'Sales Order Name',
        'Sales Order Start Date',
        'Sales Order End Date',
        'Total Net',
        'Placement Property',
        'Buy Type',
        'Sales Line Item ID',
        'Placement ID',
        'Sales Line Item Name',
        'Sales Line Item Start Date',
        'Sales Line Item End Date',
        'Demo Band',
        'Quantity',
        'Net Unit Cost',
        'Net Cost',
        'Billable Third Party Server',
        'Billing Scenario',
        'Billable Metric',
        'Launch Date',
        'Days in Flight',
        'Days Elapsed',
        'Remaining Days in Flight',
        'Flight %',
        'Demo Comp',
        'Viewability',
        'Billable Impressions in Lifetime',
        'Billable Revenue in Lifetime',
        'Billable Revenue - Uncapped in Lifetime',
        'Billable Quantity in Lifetime',
        'Earned Revenue in Lifetime',
        'Projected Revenue in Lifetime',
        'Total Projected Revenue in Lifetime',
        'Sales Line Item Revenue at Risk',
        'Sales Line Item Risk Category',
        'Impressions (3rd Party)',
        'Product Name',
        'Product Type',
    ]

    lf_df = lifetime[es_cols]
    lf_df = lf_df.loc[
        ~lf_df['Sales Line Item Name'].str.contains(
            '.*CANCEL.*',
            regex=True,
            flags=re.IGNORECASE,
            na=False,
        ),
        :,
    ]

    lf_df.rename(
        {
            'Primary Salesperson Full Name': 'Primary Salesperson',
            'Agency Name': 'Agency',
            'Advertiser Name': 'Advertiser',
            'Campaign Name': 'Campaign',
            'Sales Order Name': 'Sales Order',
            'Total Net': 'Sales Order Total Net Cost',
            'Placement ID': 'PS Line Item ID',
            'Sales Line Item Name': 'Sales Line Item',
            '1P vs 3P Var in Period': '1P Vs 3P Var',
            'Demo Comp': 'Demo Comp (Lifetime)',
            'Viewability': 'Viewability (Lifetime)',
            'Billable Revenue - Uncapped in Lifetime': 'Billable Revenue - Uncapped (Lifetime)',
            'Billable Quantity in Lifetime': 'Earned Impressions - Uncapped (Lifetime)',
            'Earned Revenue in Lifetime': 'Earned Revenue - Uncapped (Lifetime)',
            'Sales Line Item Revenue at Risk': 'Sales Line Item Revenue at Risk (Lifetime)',
            'Sales Line Item Risk Category': 'Sales Line Item Risk Category (Lifetime)',
            'Invoice Organization Name': 'Organization',
            'Impressions (3rd Party)': '3rd Party Impressions (Lifetime)',
        },
        axis=1,
        inplace=True,
    )

    sales_order = file_to_df('Sales_Order.parquet')
    sales_order = sales_order.rename(columns={'Sales_Order_ID': 'Sales Order ID', 'Invoice_Organization_Name': 'Invoice Organization Name'})
    sales_order = sales_order.drop_duplicates(subset=['Sales Order ID'])
    sales_order['Sales Order ID'] = sales_order['Sales Order ID'].astype('int64')

    lf_df = lf_df.merge(sales_order, how='left', on=['Sales Order ID'])

    lf_df.fillna(
        {
            'Campaign ID': lf_df['Sales Order ID'],
            'Campaign': lf_df['Sales Order'],
            'Demo Comp (Lifetime)': 0,
            'Viewability (Lifetime)': 1,
            'Billable Impressions in Lifetime': 0,
            'Earned Impressions - Uncapped (Lifetime)': 0,
            '3rd Party Impressions (Lifetime)': 0,
        },
        inplace=True,
    )

    lf_df['Billable Quantity'] = lf_df['Earned Impressions - Uncapped (Lifetime)']

    lf_df = lf_df.astype(
        {
            'Campaign ID': 'int64',
            'Billable Impressions in Lifetime': 'int64',
            'Earned Impressions - Uncapped (Lifetime)': 'int64',
            'Billable Quantity': 'int64',
        },
    )

    with io.StringIO() as output:
        lf_df.to_csv(output, index=False)
        exec_sum_data = output.getvalue().encode('utf8')

    exec_sum_file = 'Executive_Summary_Lifetime_' + report_date.strftime('_%Y%m%d') + '.csv'
    session = boto3.Session(profile_name=aws_profile)
    s3_client = session.client('s3')
    s3_bucket = drop_bucket
    s3_key = 'foxai_billing/' + exec_sum_file
    s3_client.put_object(
        Bucket=s3_bucket,
        Body=exec_sum_data,
        Key=s3_key,
    )

    return 's3://' + s3_bucket + '/' + s3_key

# COMMAND ----------

def exec_sum_lifetime(date: datetime) -> None:
    report_date = datetime.combine(date, datetime.min.time())
    output_file = do_exec_sum_lifetime(report_date)
    write_xcom_value('Executive Summary Lifetime', output_file)

# COMMAND ----------

if __name__ == '__main__':
    report_date = dbutils.widgets.get('date')
    global drop_bucket, aws_profile
    drop_bucket = dbutils.widgets.get('drop_bucket')
    aws_profile = dbutils.widgets.get('aws_profile')

    def parse_date(date: str) -> bool:
        format = "%Y-%m-%d"
        try:
            res = bool(datetime.strptime(date, format))
        except ValueError:
            res = False
        return res

    assert parse_date(report_date), "Invalid date format, should be in YYYY-MM-DD format"

    try:
        exec_sum_lifetime(datetime.strptime(report_date, "%Y-%m-%d"))
    except Exception as error:
        alert = Alert()
        alert.send('Executive Summary Lifetime', f'{type(error).__name__}: {error}')
        dbutils.notebook.exit(f'ERROR!!! - {error}')
    