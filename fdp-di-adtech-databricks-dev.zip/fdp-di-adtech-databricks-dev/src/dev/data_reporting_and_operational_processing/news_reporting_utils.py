"""Pure-pandas helpers for News/Podcast pacing and lifetime delivery reports.

Extracted from ad_operations_news_lifetime_data_load so the logic can be
imported by both the notebook and the unit-test suite.
"""
from __future__ import annotations

from datetime import datetime, timedelta
from typing import Any

import numpy as np
import pandas as pd

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

PODCAST_COLUMN_MAP: dict[str, str] = {
    'advertiser_name': 'Advertiser',
    'deal_name': 'Order',
    'deal_line_item_name': 'Line Item Name',
    'line_item_start_date': 'Line Item Start Date',
    'line_item_end_date': 'Line Item End Date',
    'rate': 'Rate',
    'goal_quantity': 'Goal Quantity',
    'contracted_quantity': 'Contracted Quantity',
    'account_executive': 'Salesperson',
    'delivered_impressions': 'Ad Server Impressions',
}

REPORT_COLUMNS: list[str] = [
    'Instance', 'Advertiser', 'Order', 'Line Item Name',
    'Line Item Start Date', 'Line Item End Date', 'Rate',
    'Goal Quantity', 'Contracted Quantity', 'Delivery Indicator', 'Salesperson',
    'Ad Server Impressions', 'Impressions (3rd Party)', 'Clicks (3rd Party)',
    '3rd Party CTR', 'Buffer', 'Discrepancy',
    'Current First Party OSI', 'Current Third Party OSI',
    'Total Error Count', 'Total Error Rate',
]

# ---------------------------------------------------------------------------
# Metric helpers
# ---------------------------------------------------------------------------

def osi(row: pd.Series, report_date: datetime, type: str) -> float:
    """On-Schedule Index: ratio of actual delivery pace to contracted pace.

    Parameters
    ----------
    row         : Series with Ad Server Impressions / Impressions (3rd Party),
                  Contracted Quantity, Line Item Start Date, Line Item End Date.
    report_date : Date of the report (used to measure elapsed flight days).
    type        : '1p' uses Ad Server Impressions; '3p' uses Impressions (3rd Party).
    """
    if type == '1p':
        if row['Ad Server Impressions'] == 0 or row['Contracted Quantity'] == 0:
            return 0
        qty = row['Ad Server Impressions'] / row['Contracted Quantity']
    else:
        if row['Impressions (3rd Party)'] == 0 or row['Contracted Quantity'] == 0:
            return 0
        qty = row['Impressions (3rd Party)'] / row['Contracted Quantity']

    days_elapsed = report_date - row['Line Item Start Date'] + timedelta(days=1)
    flight = row['Line Item End Date'] - row['Line Item Start Date'] + timedelta(days=1)

    if report_date < row['Line Item End Date']:
        return qty / (days_elapsed / flight)
    return qty


def metrics_calculaition(row: pd.Series, calculation: str) -> float:
    """Compute a single named metric for one row."""
    if calculation == 'Total Error Rate':
        if row['Total Impressions'] + row['Total Error Count'] == 0:
            return 0
        return row['Total Error Count'] / (row['Total Impressions'] + row['Total Error Count'])

    if calculation == '3rd Party CTR':
        if row['Impressions (3rd Party)'] == 0:
            return 0
        return row['Clicks (3rd Party)'] / row['Impressions (3rd Party)']

    if calculation == 'Buffer':
        if row['Contracted Quantity'] == 0:
            return 0
        return (row['Ad Server Booked Impressions'] - row['Contracted Quantity']) / row['Contracted Quantity']

    if calculation == 'Discrepancy':
        if row['Impressions (3rd Party)'] == 0:
            return 0
        return (row['Impressions (3rd Party)'] - row['Ad Server Impressions']) / row['Impressions (3rd Party)']

    return 0


def calculate_metrics(df: pd.DataFrame, report_date: datetime) -> pd.DataFrame:
    """Append all derived metric columns to *df* and return it."""
    df.loc[:, 'Total Error Rate'] = df.apply(metrics_calculaition, args=('Total Error Rate',), axis=1)
    df.loc[:, '3rd Party CTR'] = df.apply(metrics_calculaition, args=('3rd Party CTR',), axis=1)
    df.loc[:, 'Ad Server Booked Impressions'] = df['Quantity']
    df.loc[:, 'Buffer'] = df.apply(metrics_calculaition, args=('Buffer',), axis=1)
    df.loc[:, 'Discrepancy'] = df.apply(metrics_calculaition, args=('Discrepancy',), axis=1)
    df.loc[:, 'Current First Party OSI'] = df.apply(osi, args=(report_date, '1p'), axis=1)
    df.loc[:, 'Current Third Party OSI'] = df.apply(osi, args=(report_date, '3p'), axis=1)

    metric_columns = [
        'Total Error Rate',
        '3rd Party CTR',
        'Ad Server Booked Impressions',
        'Buffer',
        'Discrepancy',
        'Current First Party OSI',
        'Current Third Party OSI',
    ]
    df = df.fillna({col: 0 for col in metric_columns})
    for col in metric_columns:
        df[col] = df[col].replace([np.inf, -np.inf], 0)
    return df


# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------

def format_podcast_pacing(feed_df: pd.DataFrame, instance_label: str) -> pd.DataFrame:
    """Rename and enrich a raw Amperwave / Megaphone feed DataFrame.

    Renames columns per PODCAST_COLUMN_MAP, coerces numeric/date types,
    and adds the constant fields required by the pacing report.
    """
    df = feed_df.rename(columns=PODCAST_COLUMN_MAP)
    for col in ['Rate', 'Goal Quantity', 'Contracted Quantity', 'Ad Server Impressions']:
        df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0)
    df['Line Item Start Date'] = pd.to_datetime(df['Line Item Start Date'], errors='coerce')
    df['Line Item End Date'] = pd.to_datetime(df['Line Item End Date'], errors='coerce')
    df['Instance'] = instance_label
    df['Delivery Indicator'] = ''
    df['Quantity'] = df['Goal Quantity']
    df['Total Impressions'] = df['Ad Server Impressions']
    df['Impressions (3rd Party)'] = 0
    df['Clicks (3rd Party)'] = 0
    df['Total Error Count'] = 0
    return df


def format_news_pacing(df: pd.DataFrame, report_date: datetime) -> pd.DataFrame:
    """Filter to current-year lines and select pacing report output columns."""
    df = df[df['Line Item End Date'] >= report_date.replace(month=1, day=1)]
    df = df.loc[:, [
        'Instance',
        'Advertiser',
        'Order',
        'Line Item Name',
        'Line Item Start Date',
        'Line Item End Date',
        'Rate',
        'Goal Quantity',
        'Contracted Quantity',
        'Delivery Indicator',
        'Primary Salesperson Full Name',
        'Ad Server Impressions',
        'Impressions (3rd Party)',
        'Clicks (3rd Party)',
        '3rd Party CTR',
        'Buffer',
        'Discrepancy',
        'Current First Party OSI',
        'Current Third Party OSI',
        'Total Error Count',
        'Total Error Rate',
    ]]
    df = df.dropna(subset=['Line Item Name'])
    df = df.rename(columns={'Primary Salesperson Full Name': 'Salesperson'})
    return df
