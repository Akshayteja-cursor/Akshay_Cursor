# Databricks notebook source
import requests
import json
import boto3

# COMMAND ----------

class Alert:
    def __init__(self):
        # Webhook URL for DROP Alerts
        aws_profile = dbutils.widgets.get('aws_profile')
        slack_webkook_secret_arn = dbutils.widgets.get('slack_webkook_secret_arn')
        session = boto3.Session(profile_name=aws_profile)
        response = session.client('secretsmanager').get_secret_value(SecretId=slack_webkook_secret_arn)
        secret = json.loads(response['SecretString'])
        self.webhook_url = secret['drop_url']
        
        # Header
        self.headers = {'Content-type':'application/json'}

    def send(self, notebook, message, alert_level='Error'):
        # Set alert level
        # Default alert level - Error
        if alert_level == 'Warning':
            payload = {'text':f'{alert_level}:DEV - Process - {notebook}\nDetails - {message}'}
        else:
            payload = {'text':f'{alert_level}:DEV - Notebook failed - {notebook}\nDetails - {message}'}

        response = requests.post(url=self.webhook_url, headers=self.headers, data=json.dumps(payload))

        if response.status_code == 200:
            print('Slack alert sent')
        else:
            print('Failed to send slack alert')