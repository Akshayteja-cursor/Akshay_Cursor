# Databricks notebook source
# COMMAND ----------

# MAGIC %run "/Workspace/Users/prajwal.harikishor@fox.com/fdp-di-adtech-databricks/src/dev/data_reporting_and_operational_processing/core"

# COMMAND ----------

# MAGIC %run "/Workspace/Users/prajwal.harikishor@fox.com/fdp-di-adtech-databricks/src/dev/data_reporting_and_operational_processing/alert"

# COMMAND ----------

from typing import Optional, cast
import io
import re
from datetime import datetime
import pandas as pd
import boto3

# COMMAND ----------

def cs_audit_check(row: pd.Series) -> str:
    audit_value = ''
    if not row['Opportunity Unique ID'] or row['Opportunity Unique ID'] in {'TBD', 'N/A', 'n/a', 'Pending'}:
        audit_value += 'Add Salesforce ID, '
    if row['Sales Line Item Name'].startswith(('LFV', 'SFV', 'Social')):
        audit_value += 'Revise Placement Name, '
    if not row['Advertiser Name'] or not isinstance(row['Advertiser Name'], str) or 'PLACEHOLDER' in row['Advertiser Name']:
        audit_value += 'Add Advertiser, '
    if not row['Agency Name'] or not isinstance(row['Agency Name'], str) or 'PLACEHOLDER' in row['Agency Name']:
        audit_value += 'Add Agency, '
    if not row['Sales Region']:
        audit_value += 'Add Sales Region, '
    if row['Sales Order Status'] != 'closed_lost' and not row['Deal Year']:
        audit_value += 'Add Deal Year, '
    if not row['Billable Third Party Server']:
        audit_value += 'Add Billable Third Party Server,'
    if not row['Viewability']:
        audit_value += 'Add Viewability, '
    if not row['Duration']:
        audit_value += 'Add Duration, '
    if not row['Planned Demo Comp'] and row['Demo Band'] != 'P2+':
        audit_value += 'Add Comp, '
    if not row['Demo Band']:
        audit_value += 'Add Demo Band, '
    if not row['P2+ CPM'] and row['Invoice Organization Name'] != 'FOX Sports & Entertainment Fluidity':
        audit_value += 'Add P2+ CPM, '
    if row['Placement Property'] != 'FOX DAI VOD':
        if row['Demo Band'] != 'P2+':
            if not row['FW - Gross Impression Cap'] or isinstance(row['FW - Gross Impression Cap'], str):
                audit_value += 'Add Gross Impression Cap, '
            if not row['FW - Gross Impression Cap'] or isinstance(row['FW - Gross Impression Cap'], str) or not row['Quantity'] or (row['FW - Gross Impression Cap'] <= row['Quantity']):
                audit_value += 'Make sure Gross Cap is greater than the Quantity, '
    if row['Placement Property'] == 'FOX DAI VOD' and not row['HH Imps']:
        audit_value += 'Add HH Imps, '
    if not row['Account Coordinator'] and row['Invoice Organization Name'] != 'FOX Sports & Entertainment Fluidity':
        audit_value += 'Add Account Coordinator, '
    if not row['Trafficker/Campaign Manager']:
        audit_value += 'Add Campaign Manager, '
    if re.match('.*canceled.*', row['Sales Line Item Name']) or re.match('.*cancelled.*', row['Sales Line Item Name']):
        audit_value += "Add 'CANCELLED' to the line item name, "
    if row['Sales Stage'] in {'0% - Dead/Lost'} and row['Sales Order Status'] != 'closed_lost':
        audit_value += "Sales Stage and Sales Order Status don't align. If order is still working, update sales stage. If order is lost and not active, update sales order status. IF order is lost and already pushed to active at some point, leave as-is."
    if row['Sales Line Item Start Date'] <= datetime.today().date() and row['Sales Order Status'] in {'final_order_creation', 'proposal_creation', 'client_proposal_approval', 'proposal_approvals', 'final_order_approvals'}:
        audit_value += 'Past start date. Plans expire after 5 business days. If lost, move to lost. If working, reavail and touchbase with the client/AE., '
    if row['Suggested Invoice Amount Terms'] in {'manual'}:
        audit_value += 'Revise Suggested Invoice Terms within the Sales Module. If there’s a billing schedule select Prorated, Single Event, or Straightline., '
    if bool(re.match('.*Social.*', str(row['Product Name']))) and row['Unit Type'] in {'Impressions'}:
        audit_value += 'Social buys are not guaranteed on Impressions. In unit type, please select either n/a if views are not guaranteed or Guaranteed Views if the views are guaranteed., '
    if row['Cost Method'] in {'SOV-Flat Rate'} and row['Suggested Invoice Amount Terms'] in {'thirdparty_performance', 'publisher_performance'}:
        audit_value += 'Flat Fee guarantees cannot be billed on performance. Revise Suggested Invoice Terms within the Sales Module, '
    if audit_value and audit_value[-2:] == ', ':
        audit_value = audit_value[:-2]
    return audit_value


def adops_audit_check(row: pd.Series) -> str:
    aud_item_to_band = {
        'Hulu - A18to49, High': 'P18-49',
        'Hulu - FA25to54, High': 'W25-54',
        'Hulu - FA18to49, High': 'W18-49',
        'Hulu - A35up, High': 'P35-64',
        'Hulu Addressable - Acxiom - Demo: A18-34': 'P18-34',
        'Hulu - A25to49, High': 'P25-49',
        'Hulu - A25to54, High': 'P25-54',
        'Hulu - MA25to54, High': 'M25-54',
        'Hulu - FA18to34, High': 'W18-34',
        'Hulu - FA25to49, High': 'W25-49',
        'Hulu - A21up, High': 'P18+',
        'Hulu - MA18-34, High': 'M18-34',
        'Hulu - P13to17, High': 'P13-17',
        'Hulu - A18to34, High': 'P18-34',
        'Hulu - A21to34, High': 'P21-34',

    }
    audit_value = ''
    if not row['Operative Advertiser']:
        audit_value += 'Operative Advertiser is Missing, '
    if not row['FW Advertiser']:
        audit_value += 'FW Advertiser is Missing, '
    if row['FW Advertiser'].strip() != row['Operative Advertiser'].strip():
        audit_value += 'FW Advertiser does not match Operative Advertiser, '
    if row['Operative Advertiser'] == 'Placeholder':
        audit_value += 'Operative Advertiser Needs to be Updated, '
    if row['FW Advertiser'] == 'Placeholder':
        audit_value += 'FW Advertiser Needs to be Updated, '
    if isinstance(row['Operative Advertiser'], str) and re.fullmatch('[a-z0-9\s]*', row['Operative Advertiser']):
        audit_value += 'Incorrect Operative Advertiser (Belongs to Fox News), '
    if isinstance(row['FW Advertiser'], str) and re.fullmatch('[a-z0-9\s]*', row['FW Advertiser']):
        audit_value += 'Incorrect FW Advertiser (Belongs to Fox News), '
    if isinstance(row['Operative Agency'], str) and re.fullmatch('[a-z0-9\s]*', row['Operative Agency']):
        audit_value += 'Incorrect Operative Agency (Belongs to Fox News), '
    if isinstance(row['FW Agency'], str) and re.fullmatch('[a-z0-9\s]*', row['FW Agency']):
        audit_value += 'Incorrect FW Agency (Belongs to Fox News), '
    if row['Placement Start Date'].date() != row['Sales Line Item Start Date'].date():
        audit_value += 'FW Start Date does not match Operative Start Date, '
    if row['Placement End Date'].date() != row['Sales Line Item End Date'].date():
        audit_value += 'FW End Date does not match Operative End Date, '
    if row['FW Budget'] != row['Operative Quantity']:
        audit_value += 'FW Budget does not match Operative Quantity, '
    if row['Placement Property'] == 'Fox on Hulu' and row['Demo Band'] != 'P2+' and not row['Audience Targeting']:
        audit_value += 'Hulu High Needs to be Added, '
    if row['Audience Targeting'] in aud_item_to_band and aud_item_to_band[row['Audience Targeting']] != row['Demo Band']:
        audit_value += 'Hulu High does not match demo band, '
    if row['Scope of Exclusivity'] == 'Full' and row['Budget Model'] != 'All Impression Sponsorship':
        audit_value += 'Scope of Exclusivity should not be Full, '
    if audit_value and audit_value[-2:] == ', ':
        audit_value = audit_value[:-2]
    return audit_value


def fw_budget(row: pd.Series) -> str:
    if row['Budget Model'] == 'Demographic Impression Target':
        return cast(str, row['Booked On-Target Impression Goal'])
    if row['Budget Model'] == 'Impression Target':
        return cast(str, row['Impression Goal'])
    if row['Budget Model'] == 'All Impression Sponsorship':
        return cast(str, row['Estimated Impression Goal'])
    return 'NONE'


def fw_imp_cap(row: pd.Series) -> Optional[str]:
    if row['Budget Model'] == 'Demographic Impression Target':
        return cast(str, row['Impression Goal'])
    return None


def audit_report_df(op_line_items_file: str, fw_meta_file: str, fw_aud_meta_file: str, report_date: datetime) -> pd.DataFrame:
    op_line_items = file_to_df('OMS_Template_Finance Invoice Line Item.csv')
    op_line_items = op_line_items.astype(
        {
            'Parent Sales Line Item ID': 'float64',
            'Sales Line Item ID': 'Int64',
            'Planned Demo Comp': 'object',
            'External PO Ref': 'object',
            'Deal Year': 'object',
            'PS Line Item IDs': 'object',
            'Sales Order Start Date': 'datetime64[us]',
            'Sales Order End Date': 'datetime64[us]',
            'Sales Line Item Start Date': 'datetime64[us]',
            'Sales Line Item End Date': 'datetime64[us]'
        }
    ).loc[
        :,
        [
            'Sales Order ID',
            'PS Line Item IDs',
            'Opportunity Unique ID',
            'Sales Line Item ID',
            'Sales Line Item Name',
            'Sales Line Item Start Date',
            'Sales Line Item End Date',
            'Placement Property',
            'Sales Order Status',
            'Advertiser Name',
            'Agency Name',
            'Sales Region',
            'Billable Third Party Server',
            'Viewability',
            'Duration',
            'Planned Demo Comp',
            'Demo Band',
            'P2+ CPM',
            'Quantity',
            'FW - Gross Impression Cap',
            'HH Imps',
            'Suggested Invoice Amount Terms',
            'Order Owner Full Name',
            'Account Coordinator',
            'Trafficker/Campaign Manager',
            'Deal Year',
            'Invoice Organization Name',   
        ],
    ]

    # Handles case of if PS Line Item IDs are duplicated in Operative
    op_line_items.loc[:, 'PS Line Item IDs'] = op_line_items.loc[:, 'PS Line Item IDs'].str.split(',').apply(lambda x: x[0] if isinstance(x, list) else x)
    quarter_date = report_date.replace(day=15)
    quarter_start = pd.to_datetime(quarter_date).to_period('Q').to_timestamp().to_pydatetime().date()
    quarter_end = (quarter_start + pd.tseries.offsets.QuarterEnd(0)).to_pydatetime().date()
    op_line_items.loc[:, 'In Current Quarter'] = (op_line_items['Sales Line Item Start Date'].dt.date <= quarter_end) & (op_line_items['Sales Line Item End Date'].dt.date >= quarter_start)
    op_line_items = op_line_items.loc[op_line_items.loc[:, 'In Current Quarter'], :]
    op_line_items = op_line_items.loc[~op_line_items.loc[:, 'Placement Property'].isna(), :]

    sales_order_statuses = {
        'proposed_order_modification',
        'active_order',
        'final_modification_approvals',
        'preliminary_modification_approvals',
    }

    op_line_items = op_line_items.loc[op_line_items.loc[:, 'Sales Order Status'].isin(sales_order_statuses), :]

    fw_meta = pd.read_csv(
        fw_meta_file,
        skiprows=0,
        dtype={
            'Placement ID': 'object',
            'Booked On-Target Impression Goal': 'object',
            'Net Counted Ads': 'object',
            'Impression Goal': 'object',
            'Estimated Impression Goal': 'object',
        },
        parse_dates=['Placement Start Date', 'Placement End Date'],
        storage_options={'profile': aws_profile}
    ).drop_duplicates()

    int_cols = ['Booked On-Target Impression Goal', 'Net Counted Ads']
    float_cols = ['Impression Goal', 'Estimated Impression Goal']
    for col in int_cols:
        fw_meta[col] = fw_meta[col].str.replace(',', '').fillna(0).astype('int64')
    for col in float_cols:
        fw_meta[col] = fw_meta[col].str.replace(',', '').astype('float64')

    fw_aud_meta = pd.read_csv(
        fw_aud_meta_file,
        skiprows=0,
        dtype={'Placement ID': 'object'},
        usecols=['Placement ID', 'Matched Audience Item'],
        storage_options={'profile': aws_profile}
    ).drop_duplicates()

    audit_report_df = op_line_items.set_index(
        'PS Line Item IDs',
    ).join(
        fw_meta.set_index('Placement ID').rename(
            {
                'Advertiser Name': 'FW Advertiser',
                'Agency Name': 'FW Agency',
            },
            axis=1,
        ).join(
            fw_aud_meta.set_index('Placement ID'),
        ),
    ).dropna(subset=['Insertion Order ID']).rename_axis('Placement ID').reset_index()

    return audit_report_df


def export_cs_audit_report(df: pd.DataFrame, sli_file: str, report_date: datetime) -> str:
    sli_df = file_to_df('Sales Line Item_Working Orders.csv')
    sli_df = sli_df.loc[
        sli_df['Invoice Organization Name'].isin(
            ['FOX Sports & Entertainment', 'FOX Sports & Entertainment Fluidity']
        ),
        :
    ]
    sli_df = sli_df.loc[
        sli_df['Sales Order Status'].isin(
            [
                'client_proposal_approval',
                'closed_lost',
                'final_order_approvals',
                'final_order_creation',
                'preliminary_order_approvals',
                'proposal_approvals',
                'proposal_creation'
            ]
        ),
        :
    ]
    sli_df.drop(columns=['Invoice Organization Name'], inplace=True)

    sli_df = sli_df.astype(
        {
            'Sales Line Item Start Date': 'datetime64[us]',
            'Sales Line Item End Date': 'datetime64[us]',
        }
    )

    sli_df.dropna(subset=['Sales Order ID'], inplace=True)
    sli_df = sli_df.astype(
        {
            'Sales Order ID': 'int64',
            'Sales Line Item ID': 'int64',
        },
    )

    sli_df = sli_df.loc[
        ~sli_df['Sales Order Name'].str.contains(
            '.*T3ST.*',
            regex=True,
            flags=re.IGNORECASE,
            na=False,
        ),
        :,
    ]

    sli_df = sli_df.reindex(
        [
            'Sales Order ID',
            'Sales Order Name',
            'Opportunity Unique ID',
            'Sales Line Item ID',
            'Sales Line Item Name',
            'Sales Line Item Start Date',
            'Sales Line Item End Date',
            'Placement Property',
            'Product Name',
            'Cost Method',
            'Sales Order Status',
            'Sales Stage',
            'Unit Type',
            'Advertiser Name',
            'Agency Name',
            'Sales Region',
            'Billable Third Party Server',
            'Viewability',
            'Duration',
            'Planned Demo Comp',
            'Demo Band',
            'P2+ CPM',
            'Quantity',
            'FW - Gross Impression Cap',
            'HH Imps',
            'Order Owner Full Name',
            'Account Coordinator',
            'Trafficker/Campaign Manager',
            'Deal Year',
            'Invoice Organization Name',
        ],
        axis=1,
    )

    audit_check_report = df.reindex(
        [
            'Sales Order ID',
            'Opportunity Unique ID',
            'Sales Line Item ID',
            'Sales Line Item Name',
            'Sales Line Item Start Date',
            'Sales Line Item End Date',
            'Placement Property',
            'Sales Order Status',
            'Sales Stage',
            'Suggested Invoice Amount Terms',
            'Advertiser Name',
            'Agency Name',
            'Sales Region',
            'Billable Third Party Server',
            'Viewability',
            'Duration',
            'Planned Demo Comp',
            'Demo Band',
            'P2+ CPM',
            'Quantity',
            'FW - Gross Impression Cap',
            'HH Imps',
            'Order Owner Full Name',
            'Account Coordinator',
            'Trafficker/Campaign Manager',
            'Deal Year',
            'Invoice Organization Name',
        ],
        axis=1,
    )

    audit_check_report = audit_check_report.append(sli_df).drop_duplicates()
    audit_check_report.loc[:, 'Audit Check'] = audit_check_report.apply(cs_audit_check, axis=1)
    audit_check_report = audit_check_report.drop(columns=['Invoice Organization Name'])

    with io.StringIO() as output:
        audit_check_report.to_csv(output, index=False)
        audit_data = output.getvalue()

    report_name = 'Audit_Report_Client_Services_' + report_date.strftime('%d%b%Y') + '.csv'
    session = boto3.Session(profile_name=aws_profile)
    s3_client = session.client('s3')
    global drop_bucket
    s3_bucket = drop_bucket
    s3_key = 'reports/' + report_name
    s3_client.put_object(
        Bucket=s3_bucket,
        Body=audit_data.encode('utf-8'),
        Key=s3_key,
    )

    return report_name


def export_adops_audit_report(df: pd.DataFrame, report_date: datetime) -> str:
    df = df.rename(
        {
            'Advertiser Name': 'Operative Advertiser',
            'Agency Name': 'Operative Agency',
            'Quantity': 'Operative Quantity',
            'FW - Gross Impression Cap': 'Operative Gross Impression Cap',
            'Forced Over Delivery Percent (%)': 'Over-Delivery %',
            'Matched Audience Item': 'Audience Targeting',
            'Level of Exclusivity': 'Scope of Exclusivity',
            'Placement Industry': 'Industry',
            'IO Primary Trafficker': 'Primary Trafficker',
        },
        axis=1,
    )

    df.loc[:, 'FW Budget'] = df.apply(fw_budget, axis=1)
    df.loc[:, 'FW Gross Impression Cap'] = df.apply(fw_imp_cap, axis=1)

    audit_check_report = df.reindex(
        [
            'Operative Advertiser',
            'FW Advertiser',
            'Operative Agency',
            'FW Agency',
            'Insertion Order ID',
            'Insertion Order Name',
            'Sales Line Item ID',
            'Placement ID',
            'Placement Name',
            'Sales Line Item Start Date',
            'Sales Line Item End Date',
            'Placement Start Date',
            'Placement End Date',
            'Operative Quantity',
            'Operative Gross Impression Cap',
            'FW Budget',
            'FW Gross Impression Cap',
            'Over-Delivery %',
            'Audience Targeting',
            'Scope of Exclusivity',
            'Industry',
            'Unified Yield',
            'Trafficker/Campaign Manager',
            'Primary Trafficker',
        ],
        axis=1,
    ).drop_duplicates()

    audit_check_report.loc[:, 'Audit Check'] = df.apply(adops_audit_check, axis=1)

    with io.StringIO() as output:
        audit_check_report.to_csv(output, index=False)
        audit_data = output.getvalue()

    report_name = 'Audit_Report_Ad_Operations_' + report_date.strftime('%d%b%Y') + '.csv'
    session = boto3.Session(profile_name=aws_profile)
    s3_client = session.client('s3')
    global drop_bucket
    s3_bucket = drop_bucket
    s3_key = 'reports/' + report_name
    s3_client.put_object(
        Bucket=s3_bucket,
        Body=audit_data.encode('utf-8'),
        Key=s3_key,
    )

    return report_name

# COMMAND ----------

def audit_report(report: str, date: datetime) -> None:
    global drop_bucket
    op_line_items_file = f's3://{drop_bucket}/operative/OMS_Template_Finance Invoice Line Item.csv'
    fw_meta_file = f's3://{drop_bucket}/freewheel/Ad Ops (Analytics) Fox New FW Metadata.csv'
    fw_aud_meta_file = f's3://{drop_bucket}/freewheel/Ad Ops (Analytics) Fox New FW Audience Item Metadata.csv'
    sli_file = f's3://{drop_bucket}/operative/Sales Line Item_Working Orders.csv'
    df = audit_report_df(op_line_items_file, fw_meta_file, fw_aud_meta_file, date)

    if report == 'cs':
        out = export_cs_audit_report(df, sli_file, date)
    elif report == 'adops':
        out = export_adops_audit_report(df, date)
    else:
        raise ValueError(f'Unknown report type {report}')

    write_xcom_value('Audit Report'+report, out)

# COMMAND ----------

if __name__ == '__main__':
    report_date = dbutils.widgets.get('date')
    report = dbutils.widgets.get('report')
    global drop_bucket, aws_profile
    drop_bucket = dbutils.widgets.get('drop_bucket')
    aws_profile = dbutils.widgets.get('aws_profile')

    def parse_date(date: str) -> bool:
        format = "%Y-%m-%d"
        try:
            res = bool(datetime.strptime(date, format))
        except ValueError:
            res = False
        return res

    assert parse_date(report_date), "Invalid date format, should be in YYYY-MM-DD format"
    assert report != '', "Report type must be specified"

    try:
        audit_report(report, datetime.strptime(report_date, "%Y-%m-%d"))
    except Exception as error:
        alert = Alert()
        alert.send('Audit Report', f'Failed for report {report}.\n{type(error).__name__}: {error}')
        dbutils.notebook.exit(f'ERROR!!! - {error}')