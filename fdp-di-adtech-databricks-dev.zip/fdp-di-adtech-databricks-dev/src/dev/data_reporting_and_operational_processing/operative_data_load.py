# Databricks notebook source
# COMMAND ----------

# MAGIC %run "/Workspace/Users/prajwal.harikishor@fox.com/fdp-di-adtech-databricks/src/dev/data_reporting_and_operational_processing/core"

# COMMAND ----------

# MAGIC %run "/Workspace/Users/prajwal.harikishor@fox.com/fdp-di-adtech-databricks/src/dev/data_reporting_and_operational_processing/alert"

# COMMAND ----------

from typing import Any, Union
import io
import re
from datetime import datetime
import numpy as np
import pandas as pd
import boto3
import pyarrow as pa
import pyarrow.parquet as pq
import traceback

# COMMAND ----------

def operative_join(date: datetime) -> None:
    """
    Command line interface to join OMS Finance Line Item, Ad Ops,
    and Invoice data from Operative for reporting.
    """

    global drop_bucket
    data_dir = f's3://{drop_bucket}/operative/'
    op_line_items = 'OMS_Template_Finance Invoice Line Item.csv'
    adops = 'Operative_OMS_AdOps_PLI.parquet'
    op_line_items_file = data_dir + op_line_items
    adops_file = data_dir + adops
    invoice_file = data_dir + 'FinanceExport_Template.csv'
    report_date = datetime.combine(date, datetime.min.time())
    out = do_operative_join(
        op_line_items_file,
        adops_file,
        invoice_file,
        report_date,
    )
    write_xcom_value('Operative Join', out)


def op_id_override(row: pd.Series) -> Any:
    override_ids = {
        27264: 38703996,
        27263: 38704240,
        27241: 38704237,
        27240: 38704234,
        24506: 37890502,
        27061: 38691896,
        27959: 38800781,
        27958: 38698437,
        27697: 38705105,
        27696: 38705037,
        27690: 38704820,
        27689: 38704666,
    }
    try:
        return override_ids[row['Sales Line Item ID']]
    except KeyError:
        return row['Placement ID']


def do_operative_join(
        op_line_items_file: str,
        adops_file: str,
        invoice_file: str,
        report_date: datetime,
) -> str:
    op_line_items = op_adops_join(
        op_line_items_file,
        adops_file,
    ).loc[
        :,
        [
            'Agency Name',
            'Agency ID',
            'Advertiser ID',
            'Advertiser Name',
            'Sales Order ID',
            'Sales Order Name',
            'Opportunity Unique ID',
            'Parent Sales Line Item ID',
            'Parent Sales Line Item Name',
            'Net Cost',
            'Total Net',
            'Remaining Net Invoice Amount',
            'PS Line Item IDs',
            'Sales Line Item ID',
            'Sales Line Item Name',
            'Sales Order Start Date',
            'Sales Order End Date',
            'Sales Line Item Start Date',
            'Sales Line Item End Date',
            'Billable Third Party Server',
            'Quantity',
            'Push Quantity',
            'Net Unit Cost',
            'Placement Property',
            'Demo Band',
            'Planned Demo Comp',
            'Viewability',
            'Viewability GroupM',
            'Viewability MRC',
            'Equivalize?',
            'Viewability Vendor',
            'Trafficker/Campaign Manager',
            'Primary Salesperson Full Name',
            'Cost Method',
            'Product Name',
            'Programmatic Type',
            'FW - Target Demographics - Nielsen DAR',
            'FW - Target Demographics - comScore vCE',
            'Buy Type',
            'Makegood',
            'Added Value',
            'External PO Ref',
            'Sales Region',
            'Order Owner Full Name',
            'VP Sales',
            'Marketplace Type',
            'Third-Party Earliest Delivery Date',
            'Primary Earliest Delivery Date',
            'Pending Message Name',
            'Include on Invoice',
            'Deal Year',
            'Deal ID',
            'Parent Deal ID',
            'Invoice Organization Name',
            'Linear Liability',
            'Liability Type',
            'Product Billing ID',
            'Full PS Line Item IDs',
            'FW - RBP Advanced',
            'FW - Budget Model',
            'Product Type',
        ],
    ]

    op_line_items['Is Audience Target'] = op_line_items['Demo Band'] == 'Audience Target'

    op_line_items.replace(
        {
            'Equivalize?': {'No': False, 'Yes': True},
            'Viewability': {'No': False, 'Yes': True},
            'Linear Liability': {0: False, 1: True},
            'Demo Band': {'Audience Target': 'P2+'},
        },
        inplace=True,
    )

    op_line_items.rename(
        {
            'PS Line Item IDs': 'Placement ID',
            'Viewability': 'Is Viewability Placement',
            'Product Type': 'Operative Product Type',
            'Product Billing ID': 'Product Type',
        },
        axis=1,
        inplace=True,
    )

    op_line_items.replace(
        to_replace={'Billable Third Party Server': 'DCM'},
        value='DFA',
        inplace=True,
    )

    op_line_items.loc[:, 'Placement ID'] = op_line_items.apply(
        op_id_override,
        axis=1,
    )

    op_finance = read_op_invoices(invoice_file, report_date)
    op_finance = op_finance.sort_values('Billing Period Name', ascending=False)
    op_finance_agg = op_finance.groupby(op_finance.index).agg(
        {
            'Invoice ID': 'max',
            'Net Invoice Amount Terms': lambda x: x.iloc[0],
            'Billing Notes': lambda x: x.iloc[0],
            'Net Line Item Cost': 'max',
            'Billing Period End Date': 'min',
        },
    ).rename(
        {
            'Net Line Item Cost': 'Net Invoice Amount',
        },
        axis=1,
    ).fillna(
        value={
            'Billing Notes': '',
        },
    )

    op_oms = pd.merge(
        op_line_items,
        op_finance_agg,
        left_on=['Parent Sales Line Item ID'],
        right_index=True,
        how='left',
    )

    parent_line_inherit = op_oms.groupby(
        'Parent Sales Line Item ID',
        as_index=False,
    ).agg(
        {
            'Sales Line Item Start Date': 'min',
            'Sales Line Item End Date': 'max',
        },
    ).rename(
        {
            'Sales Line Item Start Date': 'Parent Line Item Start Date',
            'Sales Line Item End Date': 'Parent Line Item End Date',
        },
        axis=1,
    )

    op_oms = pd.merge(
        op_oms,
        parent_line_inherit,
        on=['Parent Sales Line Item ID'],
        how='left',
    )

    op_oms[['Include on Invoice', 'Billing Notes']] = op_oms[['Include on Invoice', 'Billing Notes']].replace('NONE', None)
    op_oms.fillna(
        value={
            'Include on Invoice': '',
            'Billing Notes': '',
        },
        inplace=True
    )

    op_oms.loc[:, 'Special Billing Instructions'] = op_oms.apply(billing_instructions, axis=1)
    op_oms['Placement ID'] = pd.to_numeric(op_oms['Placement ID'], errors='coerce')

    op_production_system = file_to_df('Production_Systems.csv')

    op_production_system['Sales Line Item ID'] = op_production_system['Sales Line Item ID'].astype('Int64')
    op_production_system = op_production_system[~op_production_system['Sales Line Item ID'].isna()]
    op_production_system['Sales Line Item ID'] = op_production_system['Sales Line Item ID'].astype('int64')
    op_oms = op_oms.merge(op_production_system, on=['Sales Line Item ID'], how='left')

    with io.BytesIO() as output:
        # Pandas infers the wrong parquet type for the FW - RBP Advanced field so we have to manually correct the schema...
        sch = pa.Schema.from_pandas(op_oms, preserve_index=False)
        fW_rbp_field = pa.field('FW - RBP Advanced', pa.map_(pa.string(), pa.string()))
        fw_rbp_field_index = sch.get_field_index('FW - RBP Advanced')
        sch = sch.set(fw_rbp_field_index, fW_rbp_field)
        tbl = pa.Table.from_pandas(op_oms, schema=sch)
        pq.write_table(tbl, output)
        op_oms_data = output.getvalue()

    session = boto3.Session(profile_name=aws_profile)
    s3_client = session.client('s3')
    global drop_bucket
    s3_bucket = drop_bucket
    s3_key = 'processed/' + 'Operative_OMS.parquet'
    s3_client.put_object(
        Bucket=s3_bucket,
        Body=op_oms_data,
        Key=s3_key,
    )

    return s3_key


def op_adops_join(op_line_items_file: str, adops_file: str) -> pd.DataFrame:
    """
    Join OMS Finance Line Item and Ad Ops data from Operative for reporting
    """
    try:
        operative_raw = file_to_df('OMS_Template_Finance Invoice Line Item.csv')
        operative_raw = operative_raw.astype(
            {
                'Parent Sales Line Item ID': 'float64',
                'Sales Line Item ID': 'Int64',
                'Planned Demo Comp': 'object',
                'External PO Ref': 'object',
                'Deal Year': 'object',
                'PS Line Item IDs': 'object',
                'Sales Order Start Date': 'datetime64[us]',
                'Sales Order End Date': 'datetime64[us]',
                'Sales Line Item Start Date': 'datetime64[us]',
                'Sales Line Item End Date': 'datetime64[us]'
            }
        )

        operative_raw.loc[:, 'Makegood'] = operative_raw.apply(cast_to_boolean, args=('Makegood',), axis=1)
        operative_raw.loc[:, 'Added Value'] = operative_raw.apply(cast_to_boolean, args=('Added Value',), axis=1)

        operative_raw = operative_raw[~operative_raw['Sales Line Item ID'].isna()]
        operative_raw['Sales Line Item ID'] = operative_raw['Sales Line Item ID'].astype('int64', errors='ignore')
        operative_raw['Full PS Line Item IDs'] = operative_raw['PS Line Item IDs'].str.split(',')

        # Handles case of if PS Line Item IDs are duplicated in Operative
        # The 'PS Line Item IDs' for each SLI'ID are sorted in Operative Analytics Reports but not in the UC DROP table hence this code.
        # This is a temporary fix and will be removed once the UC DROP table is updated.
        operative_raw.loc[:, 'PS Line Item IDs'] = operative_raw.loc[:, 'PS Line Item IDs'].str.split(',').map(lambda x: ','.join(sorted(x)) if isinstance(x, list) else x)
        operative_raw.loc[:, 'PS Line Item IDs'] = operative_raw.loc[:, 'PS Line Item IDs'].str.split(',').apply(lambda x: x[0] if isinstance(x, list) else x)

        def parse_fw_rbp_advanced(rbp: Union[str, float]) -> Any:
            if isinstance(rbp, float):
                return None
            if rbp is None or rbp == '':
                return None
            fields = rbp.lstrip('[').rstrip(']').split('||')
            # We need to store the field as a list of tuples so that Pyarrow
            # can convert it to a map(string, string) later on.
            return [(field.split('=')[0].strip(), field.split('=')[1].strip()) for field in fields]

        # Parse the FW - RBP Advanced field
        operative_raw['FW - RBP Advanced'] = operative_raw['FW - RBP Advanced'].apply(parse_fw_rbp_advanced)

        adops_raw = file_to_df('Operative_OMS_AdOps_PLI.parquet')
        adops_raw = adops_raw.astype(
            {
                'Sales Line Item ID': 'Int64',
                'Pending Message Name': 'object',
                'Push Quantity': 'Int64',
                'Primary Earliest Delivery Date': 'datetime64[us]',
                'Third-Party Earliest Delivery Date': 'datetime64[us]',
            }
        )
        adops_raw = adops_raw[~adops_raw['Sales Line Item ID'].isna()]
        adops_raw['Sales Line Item ID'] = adops_raw['Sales Line Item ID'].astype('int64', errors='ignore')

        # adops_raw = pd.read_parquet(adops_file)

        operative_raw = operative_raw.join(adops_raw.set_index('Sales Line Item ID').fillna(value=np.nan), on='Sales Line Item ID')
        operative_raw = operative_raw[~operative_raw.index.duplicated(keep='first')]
    except (pd.errors.ParserError, ValueError):
        raise Exception(f"""
            File could not be parsed.
            Please check that the correct Operative report is exported:
            Operative | Analytics | OMS_Template_Finance Invoice Line Item
            """)
    
    operative_raw = drop_inactive(operative_raw)
    operative = inherit_parent_terms(operative_raw)

    operative.replace(
        {
            'External PO Ref': {
                'TBD': np.nan,
                'Upfront': np.nan,
                'Pending': np.nan,
                0: np.nan,
                '###-####': np.nan,
                'Attached': np.nan,
                'Order Letter': np.nan,
                'NA': np.nan,
            },
        },
        inplace=True,
    )

    operative['Billable Third Party Server'].fillna('1st Party', inplace=True)
    operative['Equivalize?'].fillna('No', inplace=True)

    operative = set_viewability(operative)
    operative = amt_terms_to_billing(operative)
    unique_operative = operative.drop_duplicates(subset=['Sales Line Item ID'], keep='last')

    return unique_operative


def drop_inactive(operative_df: pd.DataFrame) -> pd.DataFrame:
    """
    Remove all rows that are considered inactive. This includes:
    * Rows that are test orders
    * Rows whose sales order status is not active or in modification
    """
    filtered = operative_df.loc[operative_df['Sales Order End Date'] >= datetime(2019, 12, 31, 0, 0), :]

    filtered = filtered.loc[
        ~filtered['Sales Order Name'].str.contains(
            '.*T3ST.*',
            regex=True,
            flags=re.IGNORECASE,
            na=False,
        ) | filtered['Sales Order ID'].isin(WHITELISTED_TEST_ORDERS),
        :,
    ]

    # Sales Order Status format for aos is different from op1
    sales_order_statuses = {
        'active_order',
        'final_modification_approvals',
        'preliminary_modification_approvals',
        'proposed_order_modification',
    }

    filtered = filtered.loc[filtered['Sales Order Status'].isin(sales_order_statuses), :]
    return filtered


def inherit_parent_terms(operative_df: pd.DataFrame) -> pd.DataFrame:
    """
    For children line items of a order package, inherit the 'Deal ID' and
    'Suggested Invoice Amount Terms' from the parent order package.
    """
    operative_df = operative_df.copy()
    packages = operative_df.loc[pd.isna(operative_df['Placement Property']), :].copy()
    line_items = operative_df.loc[pd.notna(operative_df['Placement Property']), :].copy()
    packages_dict = packages.set_index('Sales Line Item ID').to_dict()
    slid_to_terms = packages_dict['Suggested Invoice Amount Terms']
    slid_to_deal_id = packages_dict['Deal ID']
    line_items.loc[:, 'Parent Deal ID'] = line_items.loc[:, 'Parent Sales Line Item ID'].map(slid_to_deal_id)
    parent_terms = line_items.loc[:, 'Parent Sales Line Item ID'].map(slid_to_terms)
    line_items.fillna(
        {
            'Suggested Invoice Amount Terms': parent_terms,
            'Parent Sales Line Item ID': line_items.loc[:, 'Sales Line Item ID'],
            'Parent Sales Line Item Name': line_items.loc[:, 'Sales Line Item Name'],
            'Parent Deal ID': line_items.loc[:, 'Deal ID'],
        },
        inplace=True,
    )

    return line_items


def set_viewability(operative_df: pd.DataFrame) -> pd.DataFrame:
    """
    Convert 'Viewability' column into a binary 'Yes' or 'No'.
    """
    view_to_bin = {
        'Guaranteed, Apply GroupM'+chr(8217)+'s Standard': 'Yes',
        "Guaranteed, Apply GroupM's Standard": 'Yes',
        'Guaranteed, Apply the MRC Standard': 'Yes',
        'Benchmark, GroupM': 'No',
        'Benchmark, MRC': 'No',
        'No': 'No',
    }
    view_df = operative_df.fillna({'Viewability': 'No'})
    def viewability_group_m(row: pd.Series) -> str:
        if row['Viewability'] == 'Guaranteed, Apply GroupM'+chr(8217)+'s Standard':
            return True
        if row['Viewability'] == "Guaranteed, Apply GroupM's Standard":
            return True
        return False
    # view_df.loc[:, 'Viewability GroupM'] = view_df['Viewability'] == 'Guaranteed, Apply GroupM'+chr(8217)+'s Standard' or "Guaranteed, Apply GroupM's Standard"
    view_df.loc[:, 'Viewability GroupM'] = view_df.apply(viewability_group_m, axis=1)
    view_df.loc[:, 'Viewability MRC'] = view_df['Viewability'] == 'Guaranteed, Apply the MRC Standard'
    view_df.loc[:, 'Viewability'] = view_df['Viewability'].map(view_to_bin)
    return view_df


def amt_terms_to_billing(operative_df: pd.DataFrame) -> pd.DataFrame:
    """
    Using the 'Suggested Invoice Amount Terms', determine the
    'Line Billing Scenario' and 'Line Bill on Whose Numbers' columns.
    """
    billing_df = operative_df.copy()
    billing_df.loc[:, 'Line Billing Scenario'] = billing_df.loc[:, 'Suggested Invoice Amount Terms'].map(amt_terms_to_scenario)
    amt_terms_to_whose_numbers = {
        'Primary Performance': 'INTERNAL',
        'Third Party Performance': 'THIRD_PARTY',
        'publisher_performance': 'INTERNAL',
        'thirdparty_performance': 'THIRD_PARTY',
    }
    billing_df.loc[:, 'Line Bill on Whose Numbers'] = billing_df.loc[:, 'Suggested Invoice Amount Terms'].map(amt_terms_to_whose_numbers)
    first_p_mask = billing_df['Billable Third Party Server'] == '1st Party'
    first_p_num = billing_df.loc[first_p_mask, 'Line Bill on Whose Numbers']
    billing_df.loc[:, 'Line Bill on Whose Numbers'] = first_p_num.fillna('INTERNAL')
    billing_df['Line Bill on Whose Numbers'].fillna('THIRD_PARTY', inplace=True)
    return billing_df


def amt_terms_to_scenario(key: str) -> str:
    """
    A dictionary with not found values imputing the value into a stringly error
    that maps 'Suggested Invoice Amount Terms' to 'Line Billing Scenario'.
    """
    amt_terms_to_scen = {
        'Contract - Pro-rated Daily': 'Bill on Contract',
        'Contract - Straightline by billing period': 'Bill on Contract',
        'Single Period': 'Bill on Contract',
        'Primary Performance': 'Bill on Actuals',
        'Third Party Performance': 'Bill on Actuals',
        # Below dictionary keys were part of Operative
        # and can be inferred on 12-18-2019
        'thirdparty_performance': 'Bill on Actuals',
        'publisher_performance': 'Bill on Actuals',
        'straightline': 'Bill on Contract',
        'prorated': 'Bill on Contract',
        'single_month': 'Bill on Contract',
        # Below dictionary keys were part of Operative on 12-18-2019
        'Pro-rated Daily if Third Party Performance is within 10% of Contract'
        ' - Pro-rated Daily': 'Bill on Contract',
        'Straight-lined by billing period if '
        'Primary Performance is within 10% of Contract'
        ' - Straight-lined by billing period': 'Bill on Contract',
        'Bill on Primary Performance over Third Party Performance'
        ' if discrepancy is over 10%': 'Bill on Actuals',
        'Bill on 3rd Party Performance over Primary Performance'
        ' if discrepancy is over 10%': 'Bill on Actuals',
        'manual': 'Bill on Contract',
    }
    try:
        return amt_terms_to_scen[key]
    except KeyError:
        return f'ERROR - {key} key not mapped'

# COMMAND ----------

if __name__ == '__main__':
    date = dbutils.widgets.get('date')
    global drop_bucket, aws_profile
    drop_bucket = dbutils.widgets.get('drop_bucket')
    aws_profile = dbutils.widgets.get('aws_profile')

    def parse_date(date: str) -> bool:
        format = "%Y-%m-%d"
        try:
            res = bool(datetime.strptime(date, format))
        except ValueError:
            res = False
        return res

    assert parse_date(date), "Invalid date format, should be in YYYY-MM-DD format"

    try:
        operative_join(datetime.strptime(date, "%Y-%m-%d"))
    except Exception as error:
        alert = Alert()
        #alert.send('Operative Join', f'{type(error).__name__}: {error}')
        #dbutils.notebook.exit(f'ERROR!!! - {error}')
        error_details = traceback.format_exc()
        dbutils.notebook.exit(error_details)