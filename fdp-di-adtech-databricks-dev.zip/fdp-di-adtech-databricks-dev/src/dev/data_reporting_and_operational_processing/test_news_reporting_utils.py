"""Unit tests for news_reporting_utils.

Run with:
    pytest /Workspace/Users/kranthi.kommineni@fox.com/fdp-di-adtech-databricks-dev/\
           src/dev/data_reporting_and_operational_processing/test_news_reporting_utils.py -v
"""
from __future__ import annotations

import os
import sys

import numpy as np
import pandas as pd
import pytest
from datetime import datetime, timedelta

# Ensure the module directory is on the path when running via pytest
sys.path.insert(
    0,
    os.path.join(
        os.path.dirname(os.path.abspath(__file__))
        if '__file__' in dir()
        else '/Workspace/Users/kranthi.kommineni@fox.com/'
               'fdp-di-adtech-databricks-dev/src/dev/data_reporting_and_operational_processing'
    )
)

from news_reporting_utils import (  # noqa: E402
    PODCAST_COLUMN_MAP,
    REPORT_COLUMNS,
    calculate_metrics,
    format_podcast_pacing,
    metrics_calculaition,
    osi,
)

# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _feed_row(**overrides) -> pd.DataFrame:
    """One-row DataFrame matching the raw Amperwave / Megaphone schema."""
    defaults = {
        'advertiser_name': 'Test Advertiser',
        'deal_name': 'Test Deal',
        'deal_line_item_name': 'Test Line Item',
        'line_item_start_date': '2026-01-01',
        'line_item_end_date': '2026-12-31',
        'rate': '10.50',
        'goal_quantity': '1000000',
        'contracted_quantity': '900000',
        'account_executive': 'Jane AE',
        'delivered_impressions': '500000',
    }
    defaults.update(overrides)
    return pd.DataFrame([defaults])


def _metric_row(**overrides) -> pd.Series:
    """pd.Series with all columns consumed by metrics_calculaition."""
    defaults = {
        'Total Impressions': 1_000,
        'Total Error Count': 0,
        'Impressions (3rd Party)': 0,
        'Clicks (3rd Party)': 0,
        'Contracted Quantity': 1_000,
        'Ad Server Booked Impressions': 1_000,
        'Ad Server Impressions': 900,
    }
    defaults.update(overrides)
    return pd.Series(defaults)


# ---------------------------------------------------------------------------
# format_podcast_pacing
# ---------------------------------------------------------------------------

class TestFormatPodcastPacing:
    """Covers the rename + type-coerce + constant-fill logic."""

    def test_output_columns_renamed(self):
        result = format_podcast_pacing(_feed_row(), 'Amperwave')
        for src, dst in PODCAST_COLUMN_MAP.items():
            assert dst in result.columns, f"Expected '{dst}' after rename"

    def test_amperwave_instance_label(self):
        assert format_podcast_pacing(_feed_row(), 'Amperwave')['Instance'].iloc[0] == 'Amperwave'

    def test_megaphone_instance_label(self):
        assert format_podcast_pacing(_feed_row(), 'Megaphone')['Instance'].iloc[0] == 'Megaphone'

    def test_numeric_columns_cast_correctly(self):
        result = format_podcast_pacing(_feed_row(), 'Amperwave')
        assert result['Rate'].iloc[0] == pytest.approx(10.50)
        assert result['Goal Quantity'].iloc[0] == 1_000_000
        assert result['Contracted Quantity'].iloc[0] == 900_000
        assert result['Ad Server Impressions'].iloc[0] == 500_000

    def test_date_columns_are_datetime64(self):
        result = format_podcast_pacing(_feed_row(), 'Amperwave')
        assert pd.api.types.is_datetime64_any_dtype(result['Line Item Start Date'])
        assert pd.api.types.is_datetime64_any_dtype(result['Line Item End Date'])

    def test_quantity_equals_goal_quantity(self):
        result = format_podcast_pacing(_feed_row(), 'Amperwave')
        assert result['Quantity'].iloc[0] == result['Goal Quantity'].iloc[0]

    def test_total_impressions_equals_ad_server_impressions(self):
        result = format_podcast_pacing(_feed_row(), 'Amperwave')
        assert result['Total Impressions'].iloc[0] == result['Ad Server Impressions'].iloc[0]

    def test_3p_fields_are_zero(self):
        result = format_podcast_pacing(_feed_row(), 'Amperwave')
        assert result['Impressions (3rd Party)'].iloc[0] == 0
        assert result['Clicks (3rd Party)'].iloc[0] == 0
        assert result['Total Error Count'].iloc[0] == 0

    def test_delivery_indicator_empty_string(self):
        assert format_podcast_pacing(_feed_row(), 'Amperwave')['Delivery Indicator'].iloc[0] == ''

    def test_invalid_numeric_coerced_to_zero(self):
        result = format_podcast_pacing(
            _feed_row(rate='N/A', goal_quantity=None, delivered_impressions='bad'),
            'Amperwave',
        )
        assert result['Rate'].iloc[0] == 0
        assert result['Goal Quantity'].iloc[0] == 0
        assert result['Ad Server Impressions'].iloc[0] == 0

    def test_empty_dataframe_returns_empty(self):
        empty = pd.DataFrame(columns=list(PODCAST_COLUMN_MAP.keys()))
        assert len(format_podcast_pacing(empty, 'Amperwave')) == 0

    def test_multiple_rows_all_get_instance_label(self):
        feed = pd.concat([_feed_row(), _feed_row(advertiser_name='Another')], ignore_index=True)
        result = format_podcast_pacing(feed, 'Megaphone')
        assert (result['Instance'] == 'Megaphone').all()


# ---------------------------------------------------------------------------
# osi
# ---------------------------------------------------------------------------

class TestOsi:
    """Covers OSI for 1p vs 3p impressions, zero guards, in-flight vs ended."""

    def _row(self, start: str, end: str, ad_imps: int, contracted: int, p3_imps: int = 0) -> pd.Series:
        return pd.Series({
            'Ad Server Impressions': ad_imps,
            'Impressions (3rd Party)': p3_imps,
            'Contracted Quantity': contracted,
            'Line Item Start Date': pd.Timestamp(start),
            'Line Item End Date': pd.Timestamp(end),
        })

    def test_1p_on_pace_mid_flight(self):
        # Day 182 of 365-day flight, 182 of 365 delivered → OSI ≈ 1.0
        row = self._row('2026-01-01', '2026-12-31', ad_imps=182, contracted=365)
        assert osi(row, datetime(2026, 7, 1), '1p') == pytest.approx(1.0, abs=0.05)

    def test_1p_zero_impressions_returns_zero(self):
        row = self._row('2026-01-01', '2026-12-31', ad_imps=0, contracted=1_000)
        assert osi(row, datetime(2026, 7, 1), '1p') == 0

    def test_1p_zero_contracted_returns_zero(self):
        row = self._row('2026-01-01', '2026-12-31', ad_imps=500, contracted=0)
        assert osi(row, datetime(2026, 7, 1), '1p') == 0

    def test_3p_uses_3p_impressions(self):
        # 1p impressions are 0 but 3p are set — OSI should be > 0
        row = self._row('2026-01-01', '2026-12-31', ad_imps=0, contracted=365, p3_imps=182)
        assert osi(row, datetime(2026, 7, 1), '3p') > 0

    def test_3p_zero_3p_impressions_returns_zero(self):
        row = self._row('2026-01-01', '2026-12-31', ad_imps=500, contracted=365, p3_imps=0)
        assert osi(row, datetime(2026, 7, 1), '3p') == 0

    def test_after_flight_end_returns_delivery_ratio(self):
        # Campaign ended March 31; report date July → no pacing divisor
        row = self._row('2026-01-01', '2026-03-31', ad_imps=90, contracted=90)
        assert osi(row, datetime(2026, 7, 1), '1p') == pytest.approx(1.0, abs=0.01)

    def test_over_pacing_osi_exceeds_one(self):
        row = self._row('2026-01-01', '2026-12-31', ad_imps=500, contracted=365)
        assert osi(row, datetime(2026, 7, 1), '1p') > 1.0

    def test_under_pacing_osi_below_one(self):
        # Only 10 of 365 delivered, halfway through flight → very low OSI
        row = self._row('2026-01-01', '2026-12-31', ad_imps=10, contracted=365)
        assert osi(row, datetime(2026, 7, 1), '1p') < 1.0


# ---------------------------------------------------------------------------
# metrics_calculaition
# ---------------------------------------------------------------------------

class TestMetricsCalculaition:
    """Tests each named calculation branch individually."""

    def test_total_error_rate_no_errors(self):
        assert metrics_calculaition(_metric_row(), 'Total Error Rate') == 0

    def test_total_error_rate_calculated(self):
        row = _metric_row(**{'Total Impressions': 900, 'Total Error Count': 100})
        assert metrics_calculaition(row, 'Total Error Rate') == pytest.approx(0.1)

    def test_total_error_rate_zero_denominator(self):
        row = _metric_row(**{'Total Impressions': 0, 'Total Error Count': 0})
        assert metrics_calculaition(row, 'Total Error Rate') == 0

    def test_3rd_party_ctr_zero_impressions(self):
        row = _metric_row(**{'Impressions (3rd Party)': 0})
        assert metrics_calculaition(row, '3rd Party CTR') == 0

    def test_3rd_party_ctr_calculated(self):
        row = _metric_row(**{'Impressions (3rd Party)': 1_000, 'Clicks (3rd Party)': 50})
        assert metrics_calculaition(row, '3rd Party CTR') == pytest.approx(0.05)

    def test_buffer_zero_contracted(self):
        row = _metric_row(**{'Contracted Quantity': 0})
        assert metrics_calculaition(row, 'Buffer') == 0

    def test_buffer_on_pace(self):
        row = _metric_row(**{'Ad Server Booked Impressions': 1_000, 'Contracted Quantity': 1_000})
        assert metrics_calculaition(row, 'Buffer') == pytest.approx(0.0)

    def test_buffer_over_delivery(self):
        row = _metric_row(**{'Ad Server Booked Impressions': 1_100, 'Contracted Quantity': 1_000})
        assert metrics_calculaition(row, 'Buffer') == pytest.approx(0.1)

    def test_discrepancy_zero_3p_impressions(self):
        row = _metric_row(**{'Impressions (3rd Party)': 0})
        assert metrics_calculaition(row, 'Discrepancy') == 0

    def test_discrepancy_calculated(self):
        row = _metric_row(**{'Impressions (3rd Party)': 1_000, 'Ad Server Impressions': 900})
        assert metrics_calculaition(row, 'Discrepancy') == pytest.approx(0.1)


# ---------------------------------------------------------------------------
# calculate_metrics + format_podcast_pacing  (full Amperwave / Megaphone pipeline)
# ---------------------------------------------------------------------------

class TestCalculateMetricsPodcast:
    """End-to-end: raw feed → format_podcast_pacing → calculate_metrics."""

    REPORT_DATE = datetime(2026, 7, 13)

    def _pipeline(self, feed_df: pd.DataFrame, label: str = 'Amperwave') -> pd.DataFrame:
        return calculate_metrics(format_podcast_pacing(feed_df, label).copy(), self.REPORT_DATE)

    def test_all_report_columns_present(self):
        result = self._pipeline(_feed_row()).loc[:, REPORT_COLUMNS]
        assert list(result.columns) == REPORT_COLUMNS

    def test_no_infinities_in_any_numeric_column(self):
        result = self._pipeline(_feed_row())
        num_cols = result.select_dtypes(include=[np.number]).columns
        assert not result[num_cols].isin([np.inf, -np.inf]).any().any()

    def test_zero_inputs_produce_zero_metrics_not_errors(self):
        feed = _feed_row(rate='0', goal_quantity='0', contracted_quantity='0', delivered_impressions='0')
        result = self._pipeline(feed)
        assert result['Buffer'].iloc[0] == 0
        assert result['Discrepancy'].iloc[0] == 0
        assert result['Current First Party OSI'].iloc[0] == 0
        assert result['Current Third Party OSI'].iloc[0] == 0

    def test_osi_positive_for_active_campaign(self):
        feed = _feed_row(
            line_item_start_date='2026-01-01',
            line_item_end_date='2026-12-31',
            delivered_impressions='500000',
            contracted_quantity='1000000',
        )
        result = self._pipeline(feed)
        assert result['Current First Party OSI'].iloc[0] > 0

    def test_amperwave_and_megaphone_instances_distinguished(self):
        amp = self._pipeline(_feed_row(), 'Amperwave')
        meg = self._pipeline(_feed_row(), 'Megaphone')
        assert amp['Instance'].iloc[0] == 'Amperwave'
        assert meg['Instance'].iloc[0] == 'Megaphone'

    def test_na_nulls_filled_in_metric_columns(self):
        """NaN in metric columns must be replaced with 0, not propagated."""
        feed = _feed_row(delivered_impressions='0', contracted_quantity='0')
        result = self._pipeline(feed)
        metric_cols = [
            'Total Error Rate', '3rd Party CTR', 'Buffer',
            'Discrepancy', 'Current First Party OSI', 'Current Third Party OSI',
        ]
        assert not result[metric_cols].isna().any().any()

    def test_report_columns_subset_matches_constant(self):
        result = self._pipeline(_feed_row()).loc[:, REPORT_COLUMNS]
        assert set(result.columns) == set(REPORT_COLUMNS)
