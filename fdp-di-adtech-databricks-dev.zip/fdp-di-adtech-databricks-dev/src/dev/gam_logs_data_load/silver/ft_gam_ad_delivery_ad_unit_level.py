# Databricks notebook source
event_start_date = dbutils.jobs.taskValues.get("Set_Job_Parameters", "event_start_date_gam")
event_end_date = dbutils.jobs.taskValues.get("Set_Job_Parameters", "event_end_date_gam")
skip_gam = dbutils.jobs.taskValues.get("Set_Job_Parameters", "skip_gam")

# COMMAND ----------

spark.conf.set("spark.sql.shuffle.partitions", "auto")

# COMMAND ----------

print(f"Running for {event_start_date} to {event_end_date}")

# COMMAND ----------

if skip_gam == "true":
    dbutils.notebook.exit("Skipping GAM Silver Ad Unit Level Daily")

# COMMAND ----------

# MAGIC %md PROCESSING LOGIC

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql import types as T
from datetime import datetime, timedelta

# COMMAND ----------

# Load data sources from Unity Catalog
def load_table(schema_name, table_name):
    return spark.read.table(f"fox_bi_dev.{schema_name}.{table_name}")

# COMMAND ----------

# Load data sources from Unity Catalog
def load_table(table_name, schema_name="silver_ads"):
    return spark.read.table(f"fox_bi_dev.{schema_name}.{table_name}")

# COMMAND ----------

# Load data sources from Unity Catalog
def load_table_with_dates(table_name, schema_name="silver_ads",event_start_date=None, event_end_date=None):
    return spark.read.table(f"fox_bi_dev.{schema_name}.{table_name}").filter((F.col("event_date") >= event_start_date) & (F.col("event_date") <= event_end_date))

# COMMAND ----------

# LOAD GAM LOGS
gam_backfill_clicks = load_table_with_dates("news_gam_network_backfill_clicks",schema_name="bronze_ads", event_start_date=event_start_date, event_end_date= event_end_date)
gam_backfill_code_serves = load_table_with_dates("news_gam_network_backfill_code_serves",schema_name="bronze_ads", event_start_date=event_start_date, event_end_date= event_end_date)
gam_backfill_impressions = load_table_with_dates("news_gam_network_backfill_impressions",schema_name="bronze_ads", event_start_date=event_start_date, event_end_date= event_end_date)
gam_backfill_requests = load_table_with_dates("news_gam_network_backfill_requests",schema_name="bronze_ads", event_start_date=event_start_date, event_end_date= event_end_date)
gam_clicks = load_table_with_dates("news_gam_network_clicks",schema_name="bronze_ads", event_start_date=event_start_date, event_end_date= event_end_date)
gam_code_serves = load_table_with_dates("news_gam_network_code_serves",schema_name="bronze_ads", event_start_date=event_start_date, event_end_date= event_end_date)
gam_impressions = load_table_with_dates("news_gam_network_impressions",schema_name="bronze_ads", event_start_date=event_start_date, event_end_date= event_end_date)
gam_requests = load_table_with_dates("news_gam_network_requests",schema_name="bronze_ads", event_start_date=event_start_date, event_end_date= event_end_date)
gam_backfill_video_conversions = load_table_with_dates("news_gam_network_backfill_video_conversions",schema_name="bronze_ads", event_start_date=event_start_date, event_end_date= event_end_date)


# COMMAND ----------

## LOAD DIMS
gam_content = load_table_with_dates("dim_content",schema_name='silver_ads',event_start_date=event_start_date, event_end_date= event_end_date);
gam_line_item_rate = load_table_with_dates("dim_line_item_rate",schema_name='silver_ads',event_start_date=event_start_date, event_end_date= event_end_date);

gam_line_item = load_table("dim_line_item",schema_name='silver_ads');
gam_advertiser=load_table("dim_advertiser",schema_name='silver_ads');
gam_ad_unit=load_table("dim_ad_unit",schema_name='silver_ads');
gam_order=load_table("dim_orders",schema_name='silver_ads');
gam_creative=load_table("dim_ad_creative",schema_name='silver_ads');

# COMMAND ----------

# MAGIC %md TRANSFORMATION BELOW

# COMMAND ----------

gam_requests=gam_requests.withColumn('event_type',F.lit('requests')).withColumn('network_group_id',F.lit(4145).cast('bigint'))
gam_backfill_requests=gam_backfill_requests.withColumn('event_type',F.lit('backfill_requests')).withColumn('network_group_id',F.lit(4145).cast('bigint'))

gam_code_serves=gam_code_serves.withColumn('event_type',F.lit('code_serves')).withColumn('network_group_id',F.lit(4145).cast('bigint'))
gam_backfill_code_serves=gam_backfill_code_serves.withColumn('event_type',F.lit('backfill_code_serves')).withColumn('network_group_id',F.lit(4145).cast('bigint'))

gam_impressions=gam_impressions.withColumn('event_type',F.lit('impressions')).withColumn('network_group_id',F.lit(4145).cast('bigint'))
gam_backfill_impressions=gam_backfill_impressions.withColumn('event_type',F.lit('backfill_impressions')).withColumn('network_group_id',F.lit(4145).cast('bigint'))

gam_clicks=gam_clicks.withColumn('event_type',F.lit('clicks')).withColumn('network_group_id',F.lit(4145).cast('bigint'))
gam_backfill_clicks=gam_backfill_clicks.withColumn('event_type',F.lit('backfill_clicks')).withColumn('network_group_id',F.lit(4145).cast('bigint'))


gam_backfill_video_conversions=gam_backfill_video_conversions.withColumn('event_type',F.lit('backfill_video_conversions')).withColumn('network_group_id',F.lit(4145).cast('bigint')).select('event_date','event_keypart','keypart')

# COMMAND ----------

# TEMP VIEW ON LOGS DATA
gam_req = gam_requests.union(gam_backfill_requests)
gam_res = gam_code_serves.union(gam_backfill_code_serves)
gam_imp = gam_impressions.union(gam_backfill_impressions)



gam_req.createOrReplaceTempView("gam_req")
gam_res.createOrReplaceTempView("gam_res")
gam_imp.createOrReplaceTempView("gam_imp")

gam_backfill_clicks.createOrReplaceTempView("gam_backfill_clk")
gam_backfill_video_conversions.createOrReplaceTempView("gam_backfill_video_conversions")

# COMMAND ----------

from pyspark.sql import functions as F

gam_line_item_rate.filter(F.col("event_date").isNotNull()).createOrReplaceTempView("gam_line_item_rate")
gam_content.filter(F.col("event_date").isNotNull()).createOrReplaceTempView("gam_content")

# COMMAND ----------

gam_line_item.createOrReplaceTempView("gam_line_item");
gam_content.createOrReplaceTempView("gam_content");
gam_advertiser.createOrReplaceTempView("gam_advertiser");
gam_ad_unit.createOrReplaceTempView("gam_ad_unit")
gam_creative.createOrReplaceTempView("gam_creative");
gam_order.createOrReplaceTempView("gam_order");

# COMMAND ----------

# #FETCH THE MAX RATE FOR EACH LINE ITEM ID 
# spark.sql("""
#     SELECT 
#     line_item_id,
#     network_group_id,
#     cost_type,
#     MAX(cost_per_unit) AS cost_per_unit
#     FROM
#     gam_line_item_rate
#     group by 1,2,3
# """).createOrReplaceTempView("gam_line_item_rate_modified")


gam_backfill_clicks_filtered=spark.sql("""
    SELECT 
        clk.*
    FROM 
        gam_backfill_clk clk
    LEFT ANTI JOIN 
        gam_backfill_video_conversions vc
    ON 
        clk.event_keypart = vc.event_keypart
        and clk.event_date = vc.event_date
    WHERE 
        clk.event_type = 'backfill_clicks'
""")


# COMMAND ----------

gam_clk = gam_clicks.union(gam_backfill_clicks_filtered)
gam_clk.createOrReplaceTempView("gam_clk")



# COMMAND ----------

query1 = """
SELECT
    'gam' AS authority_code,
    req.network_group_id,
    req.event_date,
    COALESCE(req.keypart, 'N/A') AS transaction_id,
    COALESCE(res.impression_id, 'N/A') AS impression_id,
    COALESCE(res.line_item_id, -1) AS line_item_id,
    li_r.cost_per_unit AS cost_per_unit,
    li_r.cost_type as cost_type,
    imp.event_type as event_type,
    imp.estimated_backfill_revenue as estimated_backfill_revenue,
    COALESCE(res.order_id, -1) AS order_id,
    COALESCE(req.referer_url, 'N/A') AS referrer_url,
    COALESCE(req.country, 'N/A') AS country_name,
    COALESCE(req.region, 'N/A') AS region_name,
    COALESCE(req.metro, 'N/A') AS metro_name,
    COALESCE(req.city, 'N/A') AS city_name,
    COALESCE(req.postal_code, 'N/A') AS postal_code,
    COALESCE(req.ad_unit_id, -1) AS ad_unit_id,
    COALESCE(req.ad_unit_id, -1) AS distribution_partner_id,
    COALESCE(res.advertiser_id, -1) AS advertiser_id,
    COALESCE(res.creative_id, -1) AS creative_id,
    COALESCE(res.creative_size, 'N/A') AS creative_pixel_size,
    req.is_video_fallback_request AS is_video_ad_fallback_request,
    COALESCE(res.video_fallback_position, -1) AS video_ad_fallback_position,
    req.is_companion AS is_companion_ad,
    COALESCE(req.gfp_content_id, -1) AS content_id,
    COALESCE(content.content_name, 'N/A') AS video_asset_name,
    COALESCE(content.content_name, 'N/A') AS series_name,
    COALESCE(req.pod_position, -1) AS slot_index,
    CASE
        WHEN req.pod_position IS NULL OR req.pod_position = -1 THEN 'N/A'
        WHEN req.pod_position = 0 THEN 'Position Unknown'
        WHEN req.pod_position = 1 THEN 'Pre-roll'
        WHEN req.pod_position = 3 THEN 'Post-roll'
        ELSE 'Mid-roll'
    END AS slot_type,
    CASE
        WHEN position('xid=', req.custom_targeting) = 0 THEN NULL
        ELSE COALESCE(split_part(substring(req.custom_targeting, position('xid=', req.custom_targeting) + 4), ';', 1), 'N/A')
    END AS xid,
    CASE
        WHEN position('us_privacy=', req.custom_targeting) = 0 THEN NULL
        ELSE COALESCE(split_part(substring(req.custom_targeting, position('us_privacy=', req.custom_targeting) + 11), ';', 1), 'N/A')
    END AS us_privacy,
    COALESCE(NULLIF(split_part(regexp_substr(req.custom_targeting, 'fp_td=([^;]*)'), '=', 2), ''), 'N/A') AS fp_td,
    COALESCE(NULLIF(split_part(regexp_substr(req.custom_targeting, 'fp_lr=([^;]*)'), '=', 2), ''), 'N/A') AS fp_lr,

    -- metrics
    COUNT(DISTINCT req.keypart) AS ad_requests,
    COUNT(res.keypart) AS ad_responses,
    SUM(CASE
            WHEN imp.event_type = 'backfill_impressions' THEN 1
            WHEN imp.event_type = 'impressions' AND imp.line_item_id != 0 THEN 1
            ELSE 0
        END) AS ad_impressions,
    SUM(CASE
            WHEN (NOT req.is_companion) AND (NOT req.is_video_fallback_request) AND (NOT req.is_filled_request) THEN 1
            ELSE 0
        END) AS unfilled_impressions,
    COUNT(clk.keypart || clk.impression_id) AS ad_clicks,


    -- content-level aggregations
    AVG(content.total_video_opportunities)::BIGINT AS max_ads,
    AVG(content.total_video_duration_secs)::BIGINT AS max_duration_secs,
    AVG(content.total_video_matched_opportunities)::BIGINT AS ads_selected,
    AVG(content.total_video_matched_duration_secs)::BIGINT AS ad_duration_secs,
    AVG(content.total_video_matched_duration_secs)::BIGINT AS time_filled_secs,
    SUM(content.total_video_opportunities)::bigint AS total_ads_allowed,
    SUM(content.total_video_matched_opportunities)::bigint AS total_ads_availed,
    SUM(content.total_video_duration_secs)::bigint AS total_ad_duration_allowed_secs,
    SUM(content.total_video_matched_duration_secs)::bigint AS total_ad_duration_availed_secs,
    SUM(content.total_video_matched_duration_secs)::bigint AS total_ad_time_filled_secs,
    SUM(content.total_video_duration_secs - content.total_video_matched_duration_secs)::bigint AS total_slate_duration_secs,
    AVG(content.total_video_duration_secs - content.total_video_matched_duration_secs)::DECIMAL(20,0) AS avg_slate_duration_secs,
    AVG(1.0 - (content.total_video_matched_duration_secs::double / NULLIF(content.total_video_duration_secs, 0)::double))::double AS slate_percentage,
    SUM(content.total_video_opportunities - content.total_video_matched_opportunities)::bigint AS total_breaks_complete_unfilled,
    SUM(content.total_video_opportunities)::bigint AS total_breaks,
    SUM(content.total_video_error_count)::bigint AS total_error_count

FROM gam_req req
LEFT JOIN gam_res res
    ON req.timeusec2 = res.timeusec2 AND req.keypart = res.keypart
LEFT JOIN gam_imp imp
    ON res.timeusec2 = imp.timeusec2
    AND res.keypart = imp.keypart
    AND res.impression_id = imp.impression_id
LEFT JOIN gam_clk clk
    ON res.timeusec2 = clk.timeusec2
    AND res.keypart = clk.keypart
    AND res.impression_id = clk.impression_id
LEFT JOIN gam_content content
    ON req.event_date = content.event_date
    AND req.gfp_content_id = content.content_id
    AND req.network_group_id = content.network_group_id
LEFT JOIN gam_line_item_rate li_r
    ON res.line_item_id = li_r.line_item_id
    AND req.event_date = li_r.event_date
    AND req.network_group_id = li_r.network_group_id

GROUP BY
    req.network_group_id,
    req.event_date,
    req.keypart,
    res.impression_id,
    res.line_item_id,
    res.order_id,
    req.referer_url,
    req.country,
    req.region,
    req.metro,
    req.city,
    req.postal_code,
    req.ad_unit_id,
    res.advertiser_id,
    res.creative_id,
    res.creative_size,
    req.is_companion,
    req.is_video_fallback_request,
    req.is_filled_request,
    res.video_fallback_position,
    req.gfp_content_id,
    req.pod_position,
    req.custom_targeting,
    imp.event_type,
    li_r.cost_per_unit,
    li_r.cost_type,
    imp.event_type,
    imp.estimated_backfill_revenue,
    content.content_name
"""


spark.sql(query1).createOrReplaceTempView("gam_fact_agg");

# COMMAND ----------

query_cpd_ine_item_impressions="""
SELECT
    network_group_id,
    event_date,
    line_item_id,
    SUM(ad_impressions) AS total_line_item_impressions
FROM gam_fact_agg
WHERE cost_type = 'CPD'
GROUP BY network_group_id, event_date, line_item_id
"""

spark.sql(query_cpd_ine_item_impressions).createOrReplaceTempView("cpd_lineitem_impressions");

# COMMAND ----------

query_revenue = """
SELECT /*+ BROADCAST(cpd_lineitem_impressions) */
  g.*,
  CASE
    WHEN g.event_type = 'backfill_impressions' THEN g.estimated_backfill_revenue
    WHEN g.cost_type = 'CPM' THEN g.ad_impressions * (g.cost_per_unit / 1000000.0) / 1000
    WHEN g.cost_type = 'CPC' THEN g.ad_clicks * (g.cost_per_unit / 1000000.0)
    WHEN g.cost_type = 'CPD' THEN 
         CASE 
            WHEN c.total_line_item_impressions > 0 THEN 
                 (g.ad_impressions * 1.0 / c.total_line_item_impressions) * (0.95 * g.cost_per_unit / 1000000.0)
            ELSE 0
         END
    ELSE 0
  END AS ad_revenue_usd
FROM gam_fact_agg g
LEFT JOIN cpd_lineitem_impressions c
  ON g.network_group_id = c.network_group_id
  AND g.event_date = c.event_date
  AND g.line_item_id = c.line_item_id
"""



spark.sql(query_revenue).createOrReplaceTempView("gam_fact_agg_with_revenue");

# COMMAND ----------

query2 = """
SELECT
gfawr.*
,CASE
        WHEN ad_impressions = 0 THEN 0
        ELSE (ad_impressions/ad_requests)*100
END AS fill_rate
,CASE
        WHEN ad_clicks = 0 THEN 0
        ELSE (ad_revenue_usd/ad_clicks)
END AS ad_cost_per_click
,CASE
        WHEN ad_impressions = 0 THEN 0
        ELSE (ad_clicks/ad_impressions)*100
END AS ad_click_through_rate
,CASE
        WHEN ad_impressions = 0 THEN 0
        ELSE (ad_revenue_usd/ad_impressions)*1000
END AS ad_cost_per_mile
,(ad_requests - ad_responses) AS unmatched_ad_requests
,max_duration_secs - ad_duration_secs AS time_unfilled_secs
FROM 
gam_fact_agg_with_revenue gfawr

"""

spark.sql(query2).createOrReplaceTempView("gam_fact_agg2");

# COMMAND ----------

query3 = """
SELECT
gfa2.*,
COALESCE(au.ad_unit_name, 'N/A') AS site_section_detail,
COALESCE(au.site_name, 'N/A') AS network,
COALESCE(au.distributor_name, 'N/A') AS app_name,
COALESCE(au.ownership_type, 'N/A') AS ownership_type,
COALESCE(au.platform_name, 'N/A') AS device_type_detail,
COALESCE(au.platform_group, 'N/A') AS device_type,
COALESCE(au.business_unit, 'N/A') AS business_unit,
COALESCE(au.distributor_name, 'N/A') AS distributor,
COALESCE(au.page_type_name, 'N/A') AS page_type_detail,
COALESCE(au.ad_category_name, 'N/A') AS ad_unit_category,
COALESCE(au.ad_format_name, 'N/A') AS ad_unit_format,
COALESCE(au.ad_detail_name, 'N/A') AS ad_unit_detail_name,
COALESCE(adv.advertiser_name, 'N/A') AS advertiser_name,
COALESCE(cr.creative_name, 'N/A') AS creative_name,
COALESCE(li.line_item_type, 'N/A') AS sales_channel_type,
COALESCE(li.line_item_type, 'N/A') AS line_item_type,
COALESCE(li.line_item_name, 'N/A') AS line_item_name,
COALESCE(ord.order_name, 'N/A') AS order_name,


xxhash64(concat_ws('||', cast(gfa2.content_id AS string), cast(4145 AS string))) AS content_key_hash,
xxhash64(concat_ws('||', cast(gfa2.line_item_id AS string), cast(4145 AS string))) AS line_item_key_hash

FROM
gam_fact_agg2 gfa2
LEFT JOIN gam_ad_unit au
ON gfa2.ad_unit_id = au.ad_unit_id
LEFT JOIN gam_advertiser adv
ON gfa2.advertiser_id = adv.advertiser_id
AND gfa2.network_group_id=adv.network_group_id 
LEFT JOIN gam_creative cr
ON gfa2.creative_id = cr.creative_id
AND gfa2.network_group_id = cr.network_group_id
LEFT JOIN gam_line_item li 
ON gfa2.line_item_id = li.line_item_id
AND gfa2.network_group_id=li.network_group_id
LEFT JOIN gam_order ord
ON gfa2.order_id = ord.order_id
AND gfa2.network_group_id = ord.network_group_id 
"""

spark.sql(query3).createOrReplaceTempView("gam_fact_agg3");

# COMMAND ----------

temp_df=spark.sql(query2)

# COMMAND ----------

final_query="""
SELECT
authority_code,
network_group_id,
event_date,
"EST" AS time_zone,
transaction_id,
impression_id,
advertiser_id,
advertiser_name,
line_item_id,
line_item_name,
line_item_type,
sales_channel_type,
order_id,
order_name,
referrer_url,
country_name,
region_name,
metro_name,
city_name,
postal_code,
ad_unit_id,
site_section_detail,
network,
app_name,
ownership_type,
device_type_detail,
device_type,
distribution_partner_id,
distributor,
page_type_detail,
ad_unit_category,
ad_unit_format,
ad_unit_detail_name,
creative_id,
creative_name,
creative_pixel_size,
is_video_ad_fallback_request,
video_ad_fallback_position,
is_companion_ad,
content_id as video_asset_id,
video_asset_name,
content_id as series_id,
series_name,
business_unit,
slot_index,
slot_type,
COALESCE(xid,'N/A') as xid,
COALESCE(us_privacy,'N/A') as us_privacy,
fp_td,
fp_lr,
content_key_hash,
line_item_key_hash,

ad_requests,
unmatched_ad_requests,
ad_responses,
ad_impressions,
unfilled_impressions,
ad_clicks,
CAST(ROUND(ad_click_through_rate,8) AS DOUBLE) as ad_click_through_rate,
CAST(round(ad_cost_per_click,8) AS DOUBLE) as ad_cost_per_click_usd,
CAST(round(ad_revenue_usd,8) AS DOUBLE) as ad_revenue_usd,
CAST(round(ad_cost_per_mile,8) AS DOUBLE) as ad_cost_per_mile_usd,
max_ads,
max_duration_secs,
ads_selected,
ad_duration_secs,
time_unfilled_secs,
time_filled_secs,
total_ads_allowed,
total_ads_availed,
total_ad_duration_allowed_secs,
total_ad_duration_availed_secs,
total_ad_time_filled_secs,
total_slate_duration_secs,
CAST(round(avg_slate_duration_secs,14) as DOUBLE) as avg_slate_duration_secs,
CAST(round(slate_percentage,14) as DOUBLE) as slate_percentage,
CAST(ROUND(fill_rate,14) AS DOUBLE) as fill_rate,
total_breaks_complete_unfilled,
total_breaks,
total_error_count,

CURRENT_TIMESTAMP() AS etl_created_at_timestamp_utc,
CURRENT_TIMESTAMP() AS etl_updated_at_timestamp_utc

FROM
gam_fact_agg3
"""

df=spark.sql(final_query)

# COMMAND ----------

df.write.format('delta')\
    .mode('overwrite')\
    .option('partitionOverwriteMode', 'dynamic')\
    .saveAsTable('fox_bi_dev.silver_ads.ft_gam_ad_delivery_ad_unit_level_daily')
