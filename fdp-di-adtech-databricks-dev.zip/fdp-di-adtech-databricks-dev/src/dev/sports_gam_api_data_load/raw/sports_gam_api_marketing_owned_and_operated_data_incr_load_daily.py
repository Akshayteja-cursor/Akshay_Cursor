# Databricks notebook source
# MAGIC %run ../Utilities

# COMMAND ----------

# Load configuration values
event_start_date_param = dbutils.widgets.get("event_start_date")
event_end_date_param = dbutils.widgets.get("event_end_date")
gam_service_account_creds_secret_arn = dbutils.widgets.get('gam_service_account_creds_secret_arn')
gam_api_version = dbutils.widgets.get('gam_api_version')

# COMMAND ----------

def format_report(report_data: Any, report_type: str) -> Any:
    if report_type == 'Summary with Impressions and Viewability':
        format_columns = {
            'Dimension.DATE': ('event_date', T.DateType()),
            'Dimension.LINE_ITEM_ID': ('line_item_id', T.LongType()),
            'Dimension.AD_UNIT_ID': ('ad_unit_id', T.LongType()),
            'Dimension.ADVERTISER_ID': ('advertiser_id', T.LongType()),
            'Dimension.PROGRAMMATIC_CHANNEL_NAME': ('programmatic_channel_name', T.StringType()),
            'Dimension.COUNTRY_NAME': ('country_name', T.StringType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS': ('total_line_item_level_impressions', T.LongType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_CLICKS': ('total_line_item_level_clicks', T.LongType()),
            'DimensionAttribute.CREATIVE_CLICK_THROUGH_URL': ("creative_click_through_url",T.StringType()),
            'Dimension.CREATIVE_NAME': ("creative_name", T.StringType()),

        }
        select_cols = [
            'event_date',
            'line_item_id',
            'ad_unit_id',
            'advertiser_id',
            'programmatic_channel_name',       
            'country_name',
            'total_line_item_level_impressions',
            'total_line_item_level_clicks',
            'creative_click_through_url',
            'creative_name',
        ]


    for k, v in format_columns.items():
        report_data = report_data.withColumnRenamed(k, v[0])
        report_data = report_data.withColumn(v[0], F.col(v[0]).cast(v[1]))

    report_data = report_data.select(select_cols)

    return report_data

# COMMAND ----------

if __name__ == '__main__':

    client = get_ad_manager_client(secret_arn=gam_service_account_creds_secret_arn)    
    timezone = pytz.timezone("UTC")
    

    # Default start date = 7 days ago if not provided
    if not event_start_date_param:
        print('no start date ')
        event_start_date = datetime.today() - timedelta(days=7)
        event_start_date = event_start_date.replace(hour=0, minute=0, second=0, microsecond=0)
    else:
        event_start_date = datetime.strptime(event_start_date_param, '%Y-%m-%d')

    # Default end date = today if not provided
    if not event_end_date_param:
        print('no end date ')
        event_end_date = datetime.today().replace(hour=0, minute=0, second=0, microsecond=0)
    else:
        event_end_date = datetime.strptime(event_end_date_param, '%Y-%m-%d')

    # Apply UTC timezone
    event_start_date = timezone.localize(event_start_date)
    event_end_date = timezone.localize(event_end_date)

    process_days = (event_end_date - event_start_date).days
    processing_dates = generate_processing_dates(event_start_date, event_end_date, 1)

    # Initialize final_df
    final_df = None

    # Summary with Impressions and Error Count
    for i, batch in enumerate(processing_dates):
        start_date, end_date = batch
        print(f"Processing {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}, batch - {i}", end=' ')
        report_service = client.GetService('ReportService', version=gam_api_version)
        report_query = build_report_query(
            dimensions=[
                'DATE',
                'COUNTRY_NAME',
                'LINE_ITEM_ID',
                'AD_UNIT_ID',
                'ADVERTISER_ID',
                'PROGRAMMATIC_CHANNEL_NAME',
                "CREATIVE_NAME",
                ],
            columns=[
                'TOTAL_LINE_ITEM_LEVEL_CLICKS',
                'TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS'
            ],
            dimensionAttributes=["CREATIVE_CLICK_THROUGH_URL"],
            start_date=start_date,
            end_date=end_date
        )
        report_job = report_service.runReportJob({'reportQuery': report_query})

        while True:
            status = report_service.getReportJobStatus(report_job['id'])
            if status == 'COMPLETED':
                break
            elif status == 'FAILED':
                break
            else:
                time.sleep(10)

        if status == 'COMPLETED':
            start_time = time.time()
            print('Downloading...', end=' ')
            report_download_url = report_service.getReportDownloadURL(report_job['id'], 'CSV_DUMP')
            report_data_df = pd.read_csv(report_download_url, compression='gzip')

            if report_data_df.empty:
                print(f"No data for {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}")
                continue
        
            report_data = spark.createDataFrame(report_data_df)
            if final_df is None:
                final_df = format_report(report_data, 'Summary with Impressions and Viewability')
            else:
                final_df = final_df.union(format_report(report_data, 'Summary with Impressions and Viewability'))
            

            end_time = time.time()
            duration = end_time - start_time
            print(f"Completed in {duration:.2f} seconds")
        else:
            raise Exception('Report job failed')

    if final_df is not None:
        
        final_df = final_df.withColumn('etl_created_at_timestamp_utc', F.current_timestamp()).withColumn('etl_updated_at_timestamp_utc', F.current_timestamp())

        # final_df.write.format('delta')\
        #     .partitionBy('event_date')\
        #     .option('mergeSchema', 'true')\
        #     .option('overwriteDynamicPartitions', 'true')\
        #     .option('delta.enableDeletionVectors', 'false')\
        #     .option('delta.enableIcebergCompatV2', 'true')\
        #     .option('delta.universalFormat.enabledFormats', 'iceberg')\
        #     .option('delta.columnMapping.mode', 'name')\
        #     .mode('overwrite')\
        #     .saveAsTable('fox_bi_dev.raw_ads.sports_gam_api_marketing_owned_operated_summary_with_impressions_and_viewability')

        final_df.write.format('delta')\
            .mode('overwrite')\
            .option('partitionOverwriteMode', 'dynamic')\
            .saveAsTable(f'{catalog}.{raw_schema}.sports_gam_api_marketing_owned_operated_summary_with_impressions_and_viewability')  

        print(f"Data written to final table.")
    else:
        print('No data processed.')
