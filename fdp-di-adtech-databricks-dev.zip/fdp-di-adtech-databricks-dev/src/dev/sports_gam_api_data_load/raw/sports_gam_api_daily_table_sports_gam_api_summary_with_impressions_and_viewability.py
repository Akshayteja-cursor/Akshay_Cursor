# Databricks notebook source
# MAGIC %run ../Utilities

# COMMAND ----------

# Load configuration values
event_start_date_param = dbutils.widgets.get("event_start_date")
event_end_date_param = dbutils.widgets.get("event_end_date")

gam_service_account_creds_secret_arn = dbutils.widgets.get('gam_service_account_creds_secret_arn')
gam_api_version = dbutils.widgets.get('gam_api_version')

# COMMAND ----------

def format_report(report_data: Any, report_type: str) -> Any:
    if report_type == 'Summary with Impressions and Viewability':
        format_columns = {
            'Dimension.DATE': ('event_date', T.DateType()),
            'Dimension.COUNTRY_CODE': ('country_CODE', T.StringType()),
            'Dimension.LINE_ITEM_ID': ('line_item_id', T.LongType()),
            'Dimension.AD_UNIT_ID': ('ad_unit_id', T.LongType()),
            'Dimension.ADVERTISER_ID': ('advertiser_id', T.LongType()),
            'Dimension.ORDER_ID': ('order_id', T.LongType()),
            'Dimension.PROGRAMMATIC_CHANNEL_NAME': ('programmatic_channel_name', T.StringType()),
            'Dimension.COUNTRY_NAME': ('country_name', T.StringType()),
            'Dimension.DEMAND_CHANNEL_NAME': ('demand_channel_name', T.StringType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS': ('total_line_item_level_impressions', T.LongType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_CPM_AND_CPC_REVENUE': ('total_line_item_level_cpm_and_cpc_revenue', T.LongType()),
            'Column.TOTAL_ACTIVE_VIEW_MEASURABLE_IMPRESSIONS': ('total_active_view_measurable_impressions', T.LongType()),
            'Column.TOTAL_ACTIVE_VIEW_VIEWABLE_IMPRESSIONS': ('total_active_view_viewable_impressions', T.LongType()),
            'Column.TOTAL_ACTIVE_VIEW_ELIGIBLE_IMPRESSIONS': ('total_active_view_eligible_impressions', T.LongType())
        }
        select_cols = [
            'event_date',
            'line_item_id',
            'ad_unit_id',
            'advertiser_id',
            'order_id',
            'programmatic_channel_name',
            'demand_channel_name',
            'country_code',         
            'country_name',
            'total_line_item_level_impressions',
            'total_line_item_level_cpm_and_cpc_revenue',
            'total_active_view_measurable_impressions',
            'total_active_view_viewable_impressions',
            'total_active_view_eligible_impressions'   
        ]


    for k, v in format_columns.items():
        report_data = report_data.withColumnRenamed(k, v[0])
        report_data = report_data.withColumn(v[0], F.col(v[0]).cast(v[1]))

    report_data = report_data.select(select_cols)

    return report_data

# COMMAND ----------

if __name__ == '__main__':

    client = get_ad_manager_client(secret_arn=gam_service_account_creds_secret_arn)    
    timezone = pytz.timezone("UTC")
    

    # Default start date = 7 days ago if not provided
    if not event_start_date_param:
        print('no start date ')
        event_start_date = datetime.today() - timedelta(days=7)
        event_start_date = event_start_date.replace(hour=0, minute=0, second=0, microsecond=0)
    else:
        event_start_date = datetime.strptime(event_start_date_param, '%Y-%m-%d')

    # Default end date = today if not provided
    if not event_end_date_param:
        print('no end date ')
        event_end_date = datetime.today().replace(hour=0, minute=0, second=0, microsecond=0)
    else:
        event_end_date = datetime.strptime(event_end_date_param, '%Y-%m-%d')

    # Apply UTC timezone
    event_start_date = timezone.localize(event_start_date)
    event_end_date = timezone.localize(event_end_date)

    process_days = (event_end_date - event_start_date).days
    processing_dates = generate_processing_dates(event_start_date, event_end_date, 1)

    # Initialize final_df
    final_df = None

    # Summary with Impressions and Error Count
    for i, batch in enumerate(processing_dates):
        start_date, end_date = batch
        print(f"Processing {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}, batch - {i}", end=' ')
        report_service = client.GetService('ReportService', version=gam_api_version)
        report_query = build_report_query(
            dimensions=[
                'DATE',
                'COUNTRY_NAME',
                'COUNTRY_CODE',
                'LINE_ITEM_ID',
                'AD_UNIT_ID',
                'ADVERTISER_ID',
                'ORDER_ID',
                'PROGRAMMATIC_CHANNEL_NAME',
                'DEMAND_CHANNEL_NAME',
                ],
            columns=[
                'TOTAL_LINE_ITEM_LEVEL_CPM_AND_CPC_REVENUE',
                'TOTAL_ACTIVE_VIEW_MEASURABLE_IMPRESSIONS',
                'TOTAL_ACTIVE_VIEW_VIEWABLE_IMPRESSIONS',
                'TOTAL_ACTIVE_VIEW_ELIGIBLE_IMPRESSIONS',
                'TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS'
            ],
            dimensionAttributes=[],
            start_date=start_date,
            end_date=end_date
        )
        report_job = report_service.runReportJob({'reportQuery': report_query})

        while True:
            status = report_service.getReportJobStatus(report_job['id'])
            if status == 'COMPLETED':
                break
            elif status == 'FAILED':
                break
            else:
                time.sleep(10)

        if status == 'COMPLETED':
            start_time = time.time()
            print('Downloading...', end=' ')
            report_download_url = report_service.getReportDownloadURL(report_job['id'], 'CSV_DUMP')
            report_data_df = pd.read_csv(report_download_url, compression='gzip')

            if report_data_df.empty:
                print(f"No data for {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}")
                continue
        
            report_data = spark.createDataFrame(report_data_df)
            if final_df is None:
                final_df = format_report(report_data, 'Summary with Impressions and Viewability')
            else:
                final_df = final_df.union(format_report(report_data, 'Summary with Impressions and Viewability'))
            

            end_time = time.time()
            duration = end_time - start_time
            print(f"Completed in {duration:.2f} seconds")
        else:
            raise Exception('Report job failed')

    if final_df is not None:
        
        final_df = final_df.withColumn('etl_created_at_timestamp_utc', F.current_timestamp()).withColumn('etl_updated_at_timestamp_utc', F.current_timestamp())
      
        final_df.write.format('delta')\
            .mode('overwrite')\
            .option('partitionOverwriteMode', 'dynamic')\
            .saveAsTable(f'{catalog}.{raw_schema}.sports_gam_api_summary_with_impressions_and_viewability')  

        print(f"Data written to final table.")
    else:
        print('No data processed.')
