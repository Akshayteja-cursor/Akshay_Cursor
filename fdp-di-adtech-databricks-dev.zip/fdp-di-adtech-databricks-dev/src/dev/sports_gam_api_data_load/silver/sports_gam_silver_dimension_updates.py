# Databricks notebook source
# MAGIC %sql
# MAGIC MERGE INTO fox_bi_dev.silver_ads.ft_sports_gam_ad_delivery_and_capacity AS tgt
# MAGIC USING fox_bi_dev.silver_ads.dim_sports_gam_line_item AS src
# MAGIC ON tgt.line_item_id = src.line_item_id
# MAGIC AND tgt.network_group_id = src.network_group_id
# MAGIC WHEN MATCHED AND (
# MAGIC     COALESCE(tgt.line_item_name, 'N/A') != COALESCE(src.line_item_name, 'N/A')
# MAGIC     OR COALESCE(tgt.line_item_start_timestamp, 'N/A') != COALESCE(src.line_item_start_timestamp, 'N/A')
# MAGIC     OR COALESCE(tgt.line_item_end_timestamp, 'N/A') != COALESCE(src.line_item_end_timestamp, 'N/A')
# MAGIC     OR COALESCE(tgt.line_item_type, 'N/A') != COALESCE(src.line_item_type, 'N/A')
# MAGIC ) THEN UPDATE SET
# MAGIC     tgt.line_item_name = src.line_item_name,
# MAGIC     tgt.line_item_start_timestamp = src.line_item_start_timestamp,
# MAGIC     tgt.line_item_end_timestamp = src.line_item_end_timestamp,
# MAGIC     tgt.line_item_type = src.line_item_type

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO fox_bi_dev.silver_ads.ft_sports_gam_ad_delivery_and_capacity AS tgt
# MAGIC USING fox_bi_dev.silver_ads.dim_sports_gam_advertiser AS src
# MAGIC ON tgt.advertiser_id = src.advertiser_id
# MAGIC AND tgt.network_group_id = src.network_group_id
# MAGIC WHEN MATCHED AND (
# MAGIC     COALESCE(tgt.advertiser_name, 'N/A') != COALESCE(src.advertiser_name, 'N/A')
# MAGIC ) THEN UPDATE SET
# MAGIC     tgt.advertiser_name = src.advertiser_name

# COMMAND ----------

# Fix multiple Advertiser names on line items with -1 / NULL advertiser_id
line_items_with_multiple_advertiser_query = """
    SELECT
        line_item_id,
        COUNT(*)
    FROM (
        SELECT
            line_item_id,
            advertiser_name
        FROM fox_bi_dev.silver_ads.ft_sports_gam_ad_delivery_and_capacity
        GROUP BY ALL
    )
    GROUP BY ALL
    HAVING COUNT(*) > 1;
"""

line_items = spark.sql(line_items_with_multiple_advertiser_query)

line_items_to_be_fixed = [row['line_item_id'] for row in line_items.select('line_item_id').collect()]

if len(line_items_to_be_fixed) > 0:
    # Get a single advertiser name for each affected line_item_id
    unique_advertiser_query = """
        SELECT
            line_item_id,
            MAX(advertiser_name) AS advertiser_name
        FROM fox_bi_dev.silver_ads.ft_sports_gam_ad_delivery_and_capacity
        WHERE line_item_id IN {}
        AND (advertiser_name != 'N/A' AND advertiser_name IS NOT NULL AND advertiser_name != '-')
        GROUP BY ALL
    """.format(tuple(line_items_to_be_fixed) if len(line_items_to_be_fixed) > 1 else f'({line_items_to_be_fixed[0]})')

    spark.sql(unique_advertiser_query).createOrReplaceTempView('unique_advertiser_names')

    advertiser_fix_query = """
        MERGE INTO fox_bi_dev.silver_ads.ft_sports_gam_ad_delivery_and_capacity AS tgt
            USING (
                SELECT
                    line_item_id,
                    advertiser_name
                FROM unique_advertiser_names
                GROUP BY ALL
            ) AS src
            ON COALESCE(src.line_item_id, -1) = COALESCE(tgt.line_item_id, -1)
            WHEN MATCHED AND (
                COALESCE(src.advertiser_name, 'N/A') != COALESCE(tgt.advertiser_name, 'N/A')
            ) THEN UPDATE SET
                tgt.advertiser_name = src.advertiser_name
    """

    spark.sql(advertiser_fix_query)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO fox_bi_dev.silver_ads.ft_sports_gam_ad_delivery_and_capacity AS tgt
# MAGIC USING (
# MAGIC     SELECT DISTINCT
# MAGIC         advertiser_id
# MAGIC         , advertiser_name
# MAGIC         , network_group_id
# MAGIC     FROM fox_bi_dev.silver_ads.dim_sports_gam_advertiser
# MAGIC     WHERE (advertiser_name != 'N/A' AND advertiser_name IS NOT NULL AND advertiser_name != '-')
# MAGIC ) AS src
# MAGIC ON UPPER(COALESCE(tgt.advertiser_name, 'N/A')) = UPPER(COALESCE(src.advertiser_name, 'N/A'))
# MAGIC AND tgt.network_group_id = src.network_group_id
# MAGIC WHEN MATCHED AND (
# MAGIC     COALESCE(tgt.advertiser_id, -1) != COALESCE(src.advertiser_id, -1)
# MAGIC ) THEN UPDATE SET
# MAGIC     tgt.advertiser_id = src.advertiser_id