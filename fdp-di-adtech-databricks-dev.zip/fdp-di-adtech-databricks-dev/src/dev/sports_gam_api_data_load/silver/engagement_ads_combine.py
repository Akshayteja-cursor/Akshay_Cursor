# Databricks notebook source
# COMMAND ----------

# Load configuration values
event_start_date = dbutils.widgets.get("event_start_date")
event_end_date = dbutils.widgets.get("event_end_date")

# COMMAND ----------

# MAGIC %run ../Utilities

# COMMAND ----------

#Check Avaialability of last 7 dates in Engagement Table 

query=f"""select 
event_date,
count(*)
from
{catalog}.{engagement_bronze_schema}.ADOBE_CORP_HOURLY
where event_date between '{0}' and '{1}'
group by event_date
""".format(event_start_date,event_end_date)

df=spark.sql(query)

try:
  # Normalize event_date to DATE and keep only distinct dates that actually have rows
    have_dates_df = df.select(F.to_date("event_date").alias("event_date")).distinct()

    # Build expected date list (inclusive)
    start = datetime.strptime(event_start_date, "%Y-%m-%d").date()
    end = datetime.strptime(event_end_date, "%Y-%m-%d").date()
    expected_dates = [(start + timedelta(days=i)).isoformat() for i in range((end - start).days + 1)]

    # Create a DF of expected dates
    expected_df = spark.createDataFrame([(d,) for d in expected_dates], ["event_date"]) \
                       .select(F.to_date("event_date").alias("event_date"))

    # Find missing dates (expected but not present in data)
    missing_df = expected_df.join(have_dates_df, on="event_date", how="left_anti")
    missing = [r.event_date.strftime("%Y-%m-%d") for r in missing_df.collect()]
except Exception as e:
  print(f"Data not available for all days: Missing dates: {e}")
  sys.exit(1)


# COMMAND ----------

# DBTITLE 1,LOAD ENGAGEMENT TABLE
query=f"""select
    event_date,
    case
        when detail_content_data_source ilike '%Athlete%' then 'Athlete'
        when detail_content_data_source ilike '%Special Event%' then 'Special Event'
        when detail_content_data_source ilike '%Home%' then 'Home Page'
        when detail_content_data_source ilike '%league%' then 'League'
        when detail_content_data_source ilike '%odds%' then 'Odds'
        when detail_content_data_source ilike '%Personality%' then 'Personality'
        when detail_content_data_source ilike '%Scores%' then 'Scores'
        when detail_content_data_source ilike '%super-6%' then 'Super 6'
        when detail_content_data_source ilike '%Watch%' then 'Watch'
        when detail_content_data_source ilike '%Event%' then 'Event'
        when detail_content_data_source ilike '%Show%' then 'Show'
        when detail_content_data_source ilike '%Topic%' then 'Topic'
        else 'Unknown'
        end as page_type_derived,
    case
        when device_type is null and platform ilike '%web%' then 'Desktop Web'
        when device_type is not null and platform ilike '%web%' then 'Mobile/Tablet Web'
        when platform = 'android' or platform='ios' then 'Mobile Apps'
        else 'Unknown'
    end  as platform_group_derived,
   case
        when distribution_amp ilike '%amp%' then 'AMP'
        when device_type is null and platform ilike '%web%' then 'Desktop Web'
        when device_type ilike '%tablet%' and platform ilike '%web%' then 'Tablet Web'
        when device_type ilike '%mobile phone%' and platform ilike '%web%' then 'Mobile Web'       
        when platform = 'android' then 'Android Apps'
        when platform = 'ios' then 'IOS Apps'
        else 'Unknown'
    end
    as platform_derived,
    sum(page_views) as page_views
from {catalog}.{engagement_bronze_schema}.ADOBE_CORP_HOURLY
where event_date>='{event_start_date}' and event_date<='{event_end_date}' and secondary_business_unit ilike '%sports%'
group by 1,2,3,4"""



spark.sql(query).withColumn('authority_code',F.lit('Sports Gam'))\
               .withColumn('network_group_id',F.lit(20893548).cast("bigint")).createOrReplaceTempView('engagement_tbl')

# COMMAND ----------

# MAGIC %md
# MAGIC ft_sports_gam_ad_delivery_and_capacity + engagement data 

# COMMAND ----------

query=f"""select 
authority_code,
network_group_id,
event_date,
business_unit,
page_type_name,
platform_name,
platform_group,
SUM(total_impressions) as total_impressions,
sum(total_cpm_and_cpc_revenue_usd) as total_cpm_and_cpc_revenue_usd,
SUM(total_unmatched_ad_requests) AS total_unmatched_ad_requests,
SUM(sold_impressions) AS sold_impressions,
SUM(capacity) AS capacity,
AVG(m_cpm) as m_cpm,
NULL as total_page_views,
CURRENT_TIMESTAMP() AS etl_created_at_timestamp_utc,
CURRENT_TIMESTAMP() AS etl_updated_at_timestamp_utc
from 
{catalog}.{silver_schema}.ft_sports_gam_ad_delivery_and_capacity
where event_date >='{event_start_date}' and event_date<='{event_end_date}'
and ad_unit_name ilike '%fsp%'
group by 
event_date,
authority_code,
network_group_id,
business_unit,
page_type_name,
platform_name,
platform_group

UNION

SELECT
authority_code,
network_group_id,
event_date,
'Sports' as business_unit,
page_type_derived as page_type_name,
platform_derived as platform_name,
platform_group_derived as platform_group,
NULL as total_impressions,
NULL as total_cpm_and_cpc_revenue_usd,
NULL AS total_unmatched_ad_requests,
NULL AS sold_impressions,
NULL AS capacity,
NULL as m_cpm,
SUM(page_views) as total_page_views,
CURRENT_TIMESTAMP() AS etl_created_at_timestamp_utc,
CURRENT_TIMESTAMP() AS etl_updated_at_timestamp_utc
from
engagement_tbl
GROUP BY 
event_date,
authority_code,
network_group_id,
business_unit,
page_type_derived,
platform_derived,
platform_group_derived

""".format(event_start_date,event_end_date)



df=spark.sql(query)


# COMMAND ----------

try:
  df.write.format('delta')\
           .mode('overwrite')\
           .option('partitionOverwriteMode', 'dynamic')\
           .saveAsTable(f'{catalog}.{business_analytics_schema}.ft_sports_gam_ad_delivery_and_capacity_plus_engagement')
except Exception as e:
  print(f"Write failed with Exception{e}")
  sys.exit(-1)

# COMMAND ----------

# MAGIC %md
# MAGIC ft_sports_gam_viewability + engagement data 

# COMMAND ----------

query=f"""select 
authority_code,
network_group_id,
event_date,
business_unit,
page_type_name,
platform_name,
platform_group,
SUM(total_impressions) as total_impressions,
SUM(total_active_view_measurable_impressions) as total_active_view_measurable_impressions,
SUM(total_active_view_viewable_impressions) AS total_active_view_viewable_impressions,
SUM(total_active_view_eligible_impressions) AS total_active_view_eligible_impressions,
AVG(viewability) AS viewability,
AVG(measurable_impressions) AS  measurable_impressions,
NULL as total_page_views,
CURRENT_TIMESTAMP() AS etl_created_at_timestamp_utc,
CURRENT_TIMESTAMP() AS etl_updated_at_timestamp_utc
from 
{catalog}.{silver_schema}.ft_sports_gam_viewability
where event_date >='{event_start_date}' and event_date<='{event_end_date}'
and ad_unit_name ilike '%fsp%'
group by 
event_date,
authority_code,
network_group_id,
business_unit,
page_type_name,
platform_name,
platform_group

UNION

SELECT
authority_code,
network_group_id,
event_date,
'Sports' as business_unit,
page_type_derived as page_type_name,
platform_derived as platform_name,
platform_group_derived as platform_group,
NULL as total_impressions,
NULL as total_active_view_measurable_impressions,
NULL AS total_active_view_viewable_impressions,
NULL AS total_active_view_eligible_impressions,
NULL AS viewability,
NULL AS  measurable_impressions,
SUM(page_views) as total_page_views,
CURRENT_TIMESTAMP() AS etl_created_at_timestamp_utc,
CURRENT_TIMESTAMP() AS etl_updated_at_timestamp_utc
from
engagement_tbl
GROUP BY 
event_date,
authority_code,
network_group_id,
business_unit,
page_type_derived,
platform_derived,
platform_group_derived

""".format(event_start_date,event_end_date)



df=spark.sql(query)


# COMMAND ----------

try:
  df.write.format('delta')\
           .mode('overwrite')\
           .option('partitionOverwriteMode', 'dynamic')\
           .saveAsTable(f'{catalog}.{business_analytics_schema}.ft_sports_gam_viewability_plus_engagement')
except Exception as e:
  print(f"Write failed with Exception{e}")
  sys.exit(-1)