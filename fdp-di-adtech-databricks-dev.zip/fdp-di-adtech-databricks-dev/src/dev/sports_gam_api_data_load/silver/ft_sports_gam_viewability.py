# Databricks notebook source
# MAGIC %run ../Utilities

# COMMAND ----------

# COMMAND ----------

# Load configuration values
event_start_date = dbutils.widgets.get("event_start_date")
event_end_date = dbutils.widgets.get("event_end_date")

# COMMAND ----------

src_df_1=spark.read.table(f"{catalog}.{raw_schema}.sports_gam_api_summary_with_impressions_and_viewability").\
  filter(F.col('event_date')>=F.lit(event_start_date)).\
  filter(F.col('event_date')<=F.lit(event_end_date))

# COMMAND ----------

src_df_1=src_df_1.withColumn('authority_code',F.lit('Sports Gam'))\
               .withColumn('network_group_id',F.lit(20893548).cast("bigint"))

# COMMAND ----------

src_df_1.createOrReplaceTempView('summarry_impression_and_viewability')

# COMMAND ----------

query=query = f"""
SELECT /*+ BROADCAST({catalog}.{silver_schema}.dim_sports_ad_unit) */ 
  COALESCE(ft.authority_code, 'N/A') AS authority_code,
  COALESCE(ft.network_group_id, -1) AS network_group_id,
  ft.event_date,
  'Sports' AS business_unit,
  COALESCE(ft.ad_unit_id, -1) AS ad_unit_id,
  COALESCE(ad_unit.ad_unit_name, 'N/A') AS ad_unit_name,
  COALESCE(ad_unit.ad_category_name, 'N/A') AS ad_category_name,
  COALESCE(ad_unit.ad_detail_name, 'N/A') AS ad_detail_name,
  COALESCE(ad_unit.page_type_name, 'N/A') AS page_type_name,
  COALESCE(ad_unit.site_name, 'N/A') AS site_name,
  COALESCE(ad_unit.platform_name, 'N/A') AS platform_name,
  COALESCE(ad_unit.platform_group, 'N/A') AS platform_group,
  COALESCE(ad_unit.top_level_platform, 'N/A') AS top_level_platform,
  COALESCE(ad_unit.platform_breakout, 'N/A') AS platform_breakout,
  COALESCE(ft.programmatic_channel_name, 'N/A') AS programmatic_channel_name,
  COALESCE(ft.demand_channel_name, 'N/A') AS demand_channel_name,
  SUM(total_line_item_level_impressions) AS total_impressions,
  SUM(total_active_view_measurable_impressions) AS total_active_view_measurable_impressions,
  SUM(total_active_view_viewable_impressions) AS total_active_view_viewable_impressions,
  SUM(total_active_view_eligible_impressions) AS total_active_view_eligible_impressions,
  CAST(SUM(total_active_view_viewable_impressions)/SUM(total_active_view_measurable_impressions) AS DOUBLE) as viewability,
  CAST(SUM(total_active_view_measurable_impressions)/SUM(total_active_view_eligible_impressions) AS DOUBLE) AS measurable_impressions,
  CURRENT_TIMESTAMP() as etl_created_at_timestamp_utc,
  CURRENT_TIMESTAMP() as etl_updated_at_timestamp_utc
FROM summarry_impression_and_viewability ft 

LEFT JOIN {catalog}.{silver_schema}.dim_sports_gam_ad_unit ad_unit 
  ON ft.ad_unit_id = ad_unit.ad_unit_id
  AND ft.network_group_id = ad_unit.network_group_id


GROUP BY
  COALESCE(ft.authority_code, 'N/A'),
  COALESCE(ft.network_group_id, -1),
  ft.event_date,
  COALESCE(ft.ad_unit_id, -1),
  COALESCE(ad_unit.ad_unit_name, 'N/A'),
  COALESCE(ad_unit.ad_category_name, 'N/A'),
  COALESCE(ad_unit.ad_detail_name, 'N/A'),
  COALESCE(ad_unit.page_type_name, 'N/A'),
  COALESCE(ad_unit.site_name, 'N/A'),
  COALESCE(ad_unit.platform_name, 'N/A'),
  COALESCE(ad_unit.platform_group, 'N/A'),
  COALESCE(ad_unit.top_level_platform, 'N/A'),
  COALESCE(ad_unit.platform_breakout, 'N/A'),
  COALESCE(ft.programmatic_channel_name, 'N/A'),
  COALESCE(ft.demand_channel_name, 'N/A')
"""


result_df_1=spark.sql(query)

# COMMAND ----------

try:
  result_df_1.write.format('delta')\
           .mode('overwrite')\
           .option('partitionOverwriteMode', 'dynamic')\
           .saveAsTable(f'{catalog}.{silver_schema}.ft_sports_gam_viewability')
except Exception as e:
  print(f"Write failed with Exception{e}")
  sys.exit(-1)