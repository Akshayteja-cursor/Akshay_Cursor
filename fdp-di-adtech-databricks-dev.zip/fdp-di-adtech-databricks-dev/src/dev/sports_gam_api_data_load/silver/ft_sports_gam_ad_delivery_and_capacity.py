# Databricks notebook source
# MAGIC %run ../Utilities

# COMMAND ----------

# Load configuration values
event_start_date = dbutils.widgets.get("event_start_date")
event_end_date = dbutils.widgets.get("event_end_date")

# COMMAND ----------

def _tag_authority(df):
    return (df.withColumn('authority_code', F.lit('Sports Gam'))
              .withColumn('network_group_id', F.lit(20893548).cast('bigint')))

src_df_1 = (
    spark.read.table(f"{catalog}.{raw_schema}.sports_gam_api_summary_with_impressions_and_viewability")
         .filter(F.col('event_date').between(event_start_date, event_end_date))
         .transform(_tag_authority)
)

src_df_2 = (
    spark.read.table(f"{catalog}.{raw_schema}.sports_gam_api_summary_with_unmatched_ad_requests")
         .filter(F.col('event_date').between(event_start_date, event_end_date))
         .select('event_date', 'ad_unit_id', 'country_code', 'country_name', 'total_unmatched_ad_requests')
         .transform(_tag_authority)
)

src_df_1.createOrReplaceTempView('summary_impression_and_viewability')
src_df_2.createOrReplaceTempView('summary_unmatched_ad_requests')

# COMMAND ----------

query = f"""
WITH agg AS (
  SELECT
    /*+ BROADCAST(ad_unit, line_item, adv, orders) */
    ft.authority_code,
    ft.network_group_id,
    ft.event_date,
    'Sports'                                         AS business_unit,
    COALESCE(ft.advertiser_id, -1)                   AS advertiser_id,
    COALESCE(adv.advertiser_name, 'N/A')             AS advertiser_name,
    COALESCE(line_item.line_item_id, -1)             AS line_item_id,
    COALESCE(line_item.line_item_name, 'N/A')        AS line_item_name,
    COALESCE(line_item.line_item_type, 'N/A')        AS line_item_type,
    line_item.line_item_start_timestamp,
    line_item.line_item_end_timestamp,
    COALESCE(ft.order_id, -1)                        AS order_id,
    COALESCE(orders.order_name, 'N/A')               AS order_name,
    COALESCE(ft.ad_unit_id, -1)                      AS ad_unit_id,
    COALESCE(ad_unit.ad_unit_name, 'N/A')            AS ad_unit_name,
    COALESCE(ad_unit.ad_category_name, 'N/A')        AS ad_category_name,
    COALESCE(ad_unit.ad_detail_name, 'N/A')          AS ad_detail_name,
    COALESCE(ad_unit.page_type_name, 'N/A')          AS page_type_name,
    COALESCE(ad_unit.site_name, 'N/A')               AS site_name,
    COALESCE(ad_unit.platform_name, 'N/A')           AS platform_name,
    COALESCE(ad_unit.platform_group, 'N/A')          AS platform_group,
    COALESCE(ad_unit.top_level_platform, 'N/A')      AS top_level_platform,
    COALESCE(ad_unit.platform_breakout, 'N/A')       AS platform_breakout,
    COALESCE(ft.programmatic_channel_name, 'N/A')    AS programmatic_channel_name,
    COALESCE(ft.demand_channel_name, 'N/A')          AS demand_channel_name,
    SUM(ft.total_line_item_level_impressions)        AS total_impressions,
    CAST(SUM(ft.total_line_item_level_cpm_and_cpc_revenue) AS DOUBLE) AS total_cpm_and_cpc_revenue_usd,
    SUM(
      CASE
        WHEN line_item.line_item_type IS NULL
          OR line_item.line_item_type RLIKE 'SPONSORSHIP|STANDARD|PREFERRED_DEAL|AD_EXCHANGE|PRICE_PRIORITY|PROGRAMMATIC|BULK'
        THEN ft.total_line_item_level_impressions
        ELSE 0
      END
    )                                                AS sold_impressions
  FROM summary_impression_and_viewability ft
  LEFT JOIN {catalog}.{silver_schema}.dim_sports_gam_ad_unit ad_unit
    ON ft.ad_unit_id = ad_unit.ad_unit_id
   AND ft.network_group_id = ad_unit.network_group_id
  LEFT JOIN {catalog}.{silver_schema}.dim_sports_gam_line_item line_item
    ON ft.line_item_id = line_item.line_item_id
   AND ft.network_group_id = line_item.network_group_id
  LEFT JOIN {catalog}.{silver_schema}.dim_sports_gam_advertiser adv
    ON ft.advertiser_id = adv.advertiser_id
   AND ft.network_group_id = adv.network_group_id
  LEFT JOIN {catalog}.{silver_schema}.dim_sports_gam_orders orders
    ON ft.order_id = orders.order_id
  GROUP BY
    ft.authority_code,
    ft.network_group_id,
    ft.event_date,
    COALESCE(ft.advertiser_id, -1),
    COALESCE(adv.advertiser_name, 'N/A'),
    COALESCE(line_item.line_item_id, -1),
    COALESCE(line_item.line_item_name, 'N/A'),
    COALESCE(line_item.line_item_type, 'N/A'),
    line_item.line_item_start_timestamp,
    line_item.line_item_end_timestamp,
    COALESCE(ft.order_id, -1),
    COALESCE(orders.order_name, 'N/A'),
    COALESCE(ft.ad_unit_id, -1),
    COALESCE(ad_unit.ad_unit_name, 'N/A'),
    COALESCE(ad_unit.ad_category_name, 'N/A'),
    COALESCE(ad_unit.ad_detail_name, 'N/A'),
    COALESCE(ad_unit.page_type_name, 'N/A'),
    COALESCE(ad_unit.site_name, 'N/A'),
    COALESCE(ad_unit.platform_name, 'N/A'),
    COALESCE(ad_unit.platform_group, 'N/A'),
    COALESCE(ad_unit.top_level_platform, 'N/A'),
    COALESCE(ad_unit.platform_breakout, 'N/A'),
    COALESCE(ft.programmatic_channel_name, 'N/A'),
    COALESCE(ft.demand_channel_name, 'N/A')
)
SELECT
  authority_code,
  network_group_id,
  event_date,
  business_unit,
  advertiser_id,
  advertiser_name,
  line_item_id,
  line_item_name,
  line_item_type,
  line_item_start_timestamp,
  line_item_end_timestamp,
  order_id,
  order_name,
  ad_unit_id,
  ad_unit_name,
  ad_category_name,
  ad_detail_name,
  page_type_name,
  site_name,
  platform_name,
  platform_group,
  top_level_platform,
  platform_breakout,
  programmatic_channel_name,
  demand_channel_name,
  total_impressions,
  total_cpm_and_cpc_revenue_usd,
  CAST(NULL AS BIGINT) AS total_unmatched_ad_requests,
  sold_impressions,
  total_impressions AS capacity,
  CAST(total_cpm_and_cpc_revenue_usd * 1000.0 / NULLIF(sold_impressions, 0) AS DOUBLE) AS m_cpm
FROM agg
"""

summary_impressions_agg = spark.sql(query)
summary_impressions_agg.createOrReplaceTempView('summary_impressions_agg')

# COMMAND ----------

query = f"""
SELECT
  ft.authority_code,
  ft.network_group_id,
  'Sports'                                     AS business_unit,
  ft.event_date,
  COALESCE(ft.ad_unit_id, -1)                  AS ad_unit_id,
  COALESCE(ad_unit.ad_unit_name, 'N/A')        AS ad_unit_name,
  COALESCE(ad_unit.ad_category_name, 'N/A')    AS ad_category_name,
  COALESCE(ad_unit.ad_detail_name, 'N/A')      AS ad_detail_name,
  COALESCE(ad_unit.page_type_name, 'N/A')      AS page_type_name,
  COALESCE(ad_unit.site_name, 'N/A')           AS site_name,
  COALESCE(ad_unit.platform_name, 'N/A')       AS platform_name,
  COALESCE(ad_unit.platform_group, 'N/A')      AS platform_group,
  COALESCE(ad_unit.top_level_platform, 'N/A')  AS top_level_platform,
  COALESCE(ad_unit.platform_breakout, 'N/A')   AS platform_breakout,
  CAST(NULL AS STRING)                         AS programmatic_channel_name,
  CAST(NULL AS STRING)                         AS demand_channel_name,
  CAST(NULL AS BIGINT)                         AS total_impressions,
  CAST(NULL AS DOUBLE)                         AS total_cpm_and_cpc_revenue_usd,
  SUM(ft.total_unmatched_ad_requests)          AS total_unmatched_ad_requests,
  CAST(NULL AS BIGINT)                         AS sold_impressions,
  SUM(ft.total_unmatched_ad_requests)          AS capacity,
  CAST(NULL AS DOUBLE)                         AS m_cpm
FROM summary_unmatched_ad_requests ft
LEFT JOIN {catalog}.{silver_schema}.dim_sports_gam_ad_unit ad_unit
  ON ft.ad_unit_id       = ad_unit.ad_unit_id
 AND ft.network_group_id = ad_unit.network_group_id
GROUP BY
  ft.authority_code,
  ft.network_group_id,
  ft.event_date,
  COALESCE(ft.ad_unit_id, -1),
  COALESCE(ad_unit.ad_unit_name, 'N/A'),
  COALESCE(ad_unit.ad_category_name, 'N/A'),
  COALESCE(ad_unit.ad_detail_name, 'N/A'),
  COALESCE(ad_unit.page_type_name, 'N/A'),
  COALESCE(ad_unit.site_name, 'N/A'),
  COALESCE(ad_unit.platform_name, 'N/A'),
  COALESCE(ad_unit.platform_group, 'N/A'),
  COALESCE(ad_unit.top_level_platform, 'N/A'),
  COALESCE(ad_unit.platform_breakout, 'N/A')
"""

summary_unmatched_ad_requests_agg = spark.sql(query)
summary_unmatched_ad_requests_agg.createOrReplaceTempView('summary_unmatched_ad_requests_agg')

# COMMAND ----------

query = """
SELECT
  authority_code,
  network_group_id,
  business_unit,
  event_date,
  CAST(NULL AS BIGINT)             AS line_item_id,
  'N/A'                            AS line_item_name,
  'N/A'                            AS line_item_type,
  CAST(NULL AS TIMESTAMP)          AS line_item_start_timestamp,
  CAST(NULL AS TIMESTAMP)          AS line_item_end_timestamp,
  CAST(NULL AS BIGINT)             AS order_id,
  'N/A'                            AS order_name,
  -1                               AS advertiser_id,
  'N/A'                            AS advertiser_name,
  ad_unit_id,
  ad_unit_name,
  ad_category_name,
  ad_detail_name,
  page_type_name,
  site_name,
  platform_name,
  platform_group,
  top_level_platform,
  platform_breakout,
  programmatic_channel_name,
  demand_channel_name,
  total_impressions,
  total_cpm_and_cpc_revenue_usd,
  total_unmatched_ad_requests,
  sold_impressions,
  capacity,
  m_cpm,
  CURRENT_TIMESTAMP() AS etl_created_at_timestamp_utc,
  CURRENT_TIMESTAMP() AS etl_updated_at_timestamp_utc
FROM summary_unmatched_ad_requests_agg

UNION ALL

SELECT
  authority_code,
  network_group_id,
  business_unit,
  event_date,
  line_item_id,
  line_item_name,
  line_item_type,
  line_item_start_timestamp,
  line_item_end_timestamp,
  order_id,
  order_name,
  advertiser_id,
  advertiser_name,
  ad_unit_id,
  ad_unit_name,
  ad_category_name,
  ad_detail_name,
  page_type_name,
  site_name,
  platform_name,
  platform_group,
  top_level_platform,
  platform_breakout,
  programmatic_channel_name,
  demand_channel_name,
  total_impressions,
  total_cpm_and_cpc_revenue_usd,
  total_unmatched_ad_requests,
  sold_impressions,
  capacity,
  m_cpm,
  CURRENT_TIMESTAMP() AS etl_created_at_timestamp_utc,
  CURRENT_TIMESTAMP() AS etl_updated_at_timestamp_utc
FROM summary_impressions_agg
"""

summary_delivery_and_capacity = spark.sql(query)

# COMMAND ----------

if not spark.catalog.tableExists(f'{catalog}.{silver_schema}.ft_sports_gam_ad_delivery_and_capacity'): #Add the table name for First time load 
    summary_delivery_and_capacity.write.format('delta')\
        .mode('overwrite')\
        .partitionBy('event_date')\
        .option('mergeSchema', 'true')\
        .option('overwriteDynamicPartitions', 'true')\
        .option('delta.enableDeletionVectors', 'false')\
        .option('delta.enableIcebergCompatV2', 'true')\
        .option('delta.universalFormat.enabledFormats', 'iceberg')\
        .option('delta.columnMapping.mode', 'name')\
        .saveAsTable(f'{catalog}.{silver_schema}.ft_sports_gam_ad_delivery_and_capacity')
else:
    summary_delivery_and_capacity.write.format('delta')\
        .mode('overwrite')\
        .option('partitionOverwriteMode', 'dynamic')\
        .saveAsTable(f'{catalog}.{silver_schema}.ft_sports_gam_ad_delivery_and_capacity')