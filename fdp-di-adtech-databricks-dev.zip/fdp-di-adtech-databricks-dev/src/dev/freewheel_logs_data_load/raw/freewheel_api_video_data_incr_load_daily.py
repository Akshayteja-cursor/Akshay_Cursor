# Databricks notebook source
aws_profile=dbutils.widgets.get('aws_profile')
aws_arn=dbutils.widgets.get('aws_arn')

# COMMAND ----------

# make the variable available to shell
import os
os.environ["AWS_PROFILE_VAR"] = aws_profile
os.environ["AWS_ARN"] = aws_arn

# COMMAND ----------

# MAGIC %sh
# MAGIC aws configure set region us-west-2 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set s3.signature_version s3v4 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile $AWS_PROFILE_VAR
# MAGIC aws configure set role_arn $AWS_ARN --profile $AWS_PROFILE_VAR

# COMMAND ----------

from typing import Any, Dict, Iterator, List, Optional
from dataclasses import dataclass
from dataclasses_json import DataClassJsonMixin
import json
from datetime import datetime, timezone
import time
import requests
import boto3
import pyspark.sql.types as T
import pyspark.sql.functions as F

# COMMAND ----------

@dataclass
class VideoItem:
    id: str
    network_id: str
    external_id: Optional[str]
    title1: Optional[str]
    description: Optional[str]
    rating: Optional[str]
    duration: int
    status: Optional[str]
    secondary_ids: List[str]
    content_owner_id: Optional[str]
    updated_at: datetime
    created_at: datetime

    @staticmethod
    def _parse_timestamp(timestamp: str) -> datetime:
        return datetime.strptime(timestamp, "%Y-%m-%dT%H:%M:%SZ").replace(
            tzinfo=timezone.utc
        )

    @classmethod
    def from_api_response(cls, response: Any) -> "VideoItem":
        return cls(
            id=str(response["id"]),
            network_id=str(response["network_id"]),
            external_id=response["external_id"] or None,
            title1=response["title1"] or None,
            description=response["description"] or None,
            rating=response["rating"] or None,
            duration=response["duration"],
            status=response["status"] or None,
            secondary_ids=response["secondary_ids"],
            content_owner_id=(
                str(response["content_owner_id"])
                if response["content_owner_id"] is not None
                else None
            ),
            updated_at=cls._parse_timestamp(response["updated_at"]),
            created_at=cls._parse_timestamp(response["created_at"]),
        )

@dataclass
class VideosPage:
    page_number: int
    total_pages: int
    items: List[VideoItem]

    @classmethod
    def from_api_response(cls, response: Any) -> "VideosPage":
        return cls(
            page_number=response["page"],
            total_pages=response["total_page"],
            items=[VideoItem.from_api_response(item) for item in response["items"]],
        )

# COMMAND ----------

class FreewheelBreakerTimeoutException(BaseException):
    pass

class FreewheelApiClient:
    def __init__(self, fw_ssm_key: str, max_timeout: int, max_tries: int) -> None:

        self._access_token = FreewheelApiClient._get_fw_access_token(fw_ssm_key)

        self._session = requests.Session()
        self._session.headers.update({"Authorization": f"Bearer {self._access_token}"})
        self._max_timeout = max_timeout
        self._max_tries = max_tries

    @staticmethod
    def _get_fw_access_token(fw_ssm_key: str) -> str:
        session = boto3.Session(profile_name='databricks-cpe-dev')
        client = session.client("secretsmanager")

        try:
            get_secret_value_response = client.get_secret_value(SecretId=fw_ssm_key)
            secrets = json.loads(get_secret_value_response["SecretString"])
            username = secrets["username"]
            password = secrets["password"]

        except Exception as e:
            print(f"Failed to get api credentials with Error: {e}")
            return ""

        if username != None and username != "" and password != None and password != "":
            pass
        else:
            raise Exception("Failed to get api credentials")

        resp = requests.post(
            "https://api.freewheel.tv/auth/token",
            data={
                "grant_type": "password",
                "username": username,
                "password": password,
            },
        )

        resp.raise_for_status()

        access_token = resp.json()["access_token"]

        assert isinstance(access_token, str)

        return access_token

    def _try_get_videos_page(self, page_number: int, updated_at: Optional[datetime]) -> VideosPage:
        # As of this writing (2022-10-06), the Freewheel videos API is somewhat broken.
        # Every successive page takes longer until eventually the API starts timing out.
        # Apparently it's possible to work around this by (1) submitting an API request
        # and letting it time out (2) waiting a sufficiently long amount of time
        # (3) resubmitting the same request. Presumably there's some kind of caching
        # going on on the backend.
        params: Dict[str, Any] = {"per_page": 500, "page": page_number}
        if updated_at is not None:
            params["updated_at"] = (
                datetime.strptime(updated_at, "%Y-%m-%dT%H:%M:%SZ")
                .astimezone(timezone.utc)
                .strftime("%Y-%m-%dT%H:%M:%SZ..")
            )
        resp = self._session.get("https://api.freewheel.tv/services/v4/videos", params=params)
        resp.raise_for_status()
        data = resp.json()
        errors = data.get("errors")
        if errors is not None:
            if any(error["code"] == 5000 for error in errors):
                raise FreewheelBreakerTimeoutException
            raise RuntimeError(f"Error from Freewheel API: {json.dumps(errors)}")
        return VideosPage.from_api_response(data)

    def _get_videos_page(self, page_num: int, updated_at: Optional[datetime]) -> VideosPage:
        sleep_seconds = 10
        for try_ in range(0, self._max_tries):
            try:
                return self._try_get_videos_page(page_num, updated_at)
            except:
                print('Timeout getting page', ', page_num=', page_num, ', sleep_seconds=', sleep_seconds, ', try_=', try_, sep='')
                time.sleep(sleep_seconds)
                sleep_seconds *= 2
                sleep_seconds = min(sleep_seconds, self._max_timeout)
        print('Giving up on getting page', ', page_num=', page_num, sep='')
        raise FreewheelBreakerTimeoutException

    def get_video_pages(self, start_page: int = 1, updated_at: Optional[datetime] = None) -> Iterator[VideosPage]:
        first_page = self._get_videos_page(start_page, updated_at)
        pages_done = 1
        total_pages = first_page.total_pages - start_page + 1
        print('Got page', ', page_num=', start_page, ', total_pages=', total_pages, ', progress_pct=', round((100 * pages_done / total_pages), 2), sep='')
        yield first_page
        for page_num in range(first_page.page_number + 1, first_page.total_pages + 1):
            try:
                page = self._get_videos_page(page_num, updated_at)
                pages_done += 1
            except Exception as exc:
                print('Failed getting page---stopping and writing out what we have', ', page_num=', page_num, ', exc_info=', exc, sep='')
                return
            end = datetime.now()
            print('Got page', ', page_num=', page_num, ', total_pages=', total_pages, ', progress_pct=', round((100 * pages_done / total_pages), 2), sep='')
            yield page

    def get_video_items(self, start_page: int = 1, updated_at: Optional[datetime] = None) -> Iterator[VideoItem]:
        for page in self.get_video_pages(start_page, updated_at):
            yield from page.items

# COMMAND ----------

def format_video_items(video_items: Any, schema) -> Any:
    video_items_list = []

    for video_item in video_items:
        video_items_list.append(
            [
                -1 if getattr(video_item, 'id') == None else int(getattr(video_item, 'id')),
                int(getattr(video_item, 'network_id')),
                getattr(video_item, 'external_id'),
                getattr(video_item, 'title1'),
                getattr(video_item, 'description'),
                getattr(video_item, 'rating'),
                0 if getattr(video_item, 'duration') == None else int(getattr(video_item, 'duration')),
                getattr(video_item, 'status'),
                getattr(video_item, 'secondary_ids'),
                getattr(video_item, 'content_owner_id'),
                getattr(video_item, 'updated_at'),
                getattr(video_item, 'created_at')
            ]
        )
    
    video_items_data = spark.createDataFrame(video_items_list, schema)
    return video_items_data

# COMMAND ----------

if __name__ == "__main__":
    fw_api_creds_secret_key = dbutils.widgets.get('fw_api_creds_secret_key')
    last_updated_timestamp = datetime.strptime(dbutils.widgets.get('current_date'), '%Y-%m-%d')
    max_timeout = 100
    max_tries = 5
    first_page = 1

    client = FreewheelApiClient(
        fw_api_creds_secret_key,
        max_timeout,
        max_tries,
    )

    video_items = client.get_video_items(first_page, last_updated_timestamp.strftime("%Y-%m-%dT%H:%M:%SZ"))

    schema = T.StructType(
        [
            T.StructField('id', T.LongType(), True,),
            T.StructField('network_id', T.LongType(), True,),
            T.StructField('external_id', T.StringType(), True,),
            T.StructField('title1', T.StringType(), True,),
            T.StructField('description', T.StringType(), True,),
            T.StructField('rating', T.StringType(), True,),
            T.StructField('duration', T.LongType(), True,),
            T.StructField('status', T.StringType(), True,),
            T.StructField('secondary_ids', T.StringType(), True,),
            T.StructField('content_owner_id', T.StringType(), True,),
            T.StructField('updated_at', T.TimestampType(), True,),
            T.StructField('created_at', T.TimestampType(), True,),
        ]
    )

    video_items_data = format_video_items(video_items, schema)

    video_items_data = video_items_data.withColumn('etl_created_timestamp', F.current_timestamp()).withColumn('etl_updated_timestamp', F.current_timestamp())
    video_items_data.write.mode('overwrite').option('mergeSchema', 'true').saveAsTable('fox_bi_dev.raw_ads.freewheel_api_videos')
