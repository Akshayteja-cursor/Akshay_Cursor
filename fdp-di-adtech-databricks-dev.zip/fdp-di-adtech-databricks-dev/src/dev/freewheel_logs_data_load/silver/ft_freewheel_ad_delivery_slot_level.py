# Databricks notebook source
event_start_date = dbutils.jobs.taskValues.get("Set_Job_Parameters", "event_start_date_freewheel")
event_end_date = dbutils.jobs.taskValues.get("Set_Job_Parameters", "event_end_date_freewheel")
skip_freewheel = dbutils.jobs.taskValues.get("Set_Job_Parameters", "skip_freewheel")

# COMMAND ----------

spark.conf.set("spark.sql.shuffle.partitions", "auto")

# COMMAND ----------

print(f"Running for {event_start_date} to {event_end_date}")

# COMMAND ----------

if skip_freewheel == "true":
    dbutils.notebook.exit("Skipping Freewheel Slot Level Daily")

# COMMAND ----------

# MAGIC %md
# MAGIC PROCESSING LOGIC

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql import types as T
from datetime import datetime, timedelta

# COMMAND ----------

# Load data sources from Unity Catalog
def load_table(table_name, schema_name="silver_ads"):
    return spark.read.table(f"fox_bi_dev.{schema_name}.{table_name}")

# COMMAND ----------

# DBTITLE 1,LOAD_DIMENSION_TABLES

# Calls with schema specified
# fw_logs_516429 = load_table("freewheel_v4_logs_516429_fox_corp", "bronze_ads")
fw_logs_500763 = load_table("freewheel_v4_logs_500763_fox_affiliates", "bronze_ads")
site_section = load_table("dim_site_section")
video_series = load_table("dim_video_series")
video_asset = load_table("dim_video_asset")
partner_network = load_table("dim_partner_network")
mrm_rule = load_table("dim_mrm_rule")
listing = load_table("dim_listing")
creative = load_table("dim_ad_creative")
orders = load_table("dim_orders")
ad_unit = load_table("dim_ad_unit")
advertiser = load_table("dim_advertiser")
campaign_and_placement = load_table("dim_campaign_and_placement")
content = load_table("dim_content")
line_item = load_table("dim_line_item")
network = load_table("dim_network")
sold_order = load_table("dim_sold_order")
market_deal=load_table("dim_market_deal")

# COMMAND ----------

from pyspark.sql.functions import col, lit

# fw_logs_516429 = fw_logs_516429.withColumn('authority_code', lit('freewheel')) \
    # .withColumn('network_group_id', lit(516429).cast("bigint"))

fw_logs_500763 = fw_logs_500763.withColumn('authority_code', lit('freewheel')) \
    .withColumn('network_group_id', lit(500763).cast("bigint"))

fw_logs=fw_logs_500763 #fw_logs_516429.union(fw_logs_500763);

# COMMAND ----------

# DBTITLE 1,LOAD FW SOURCES
from datetime import datetime, timedelta
from pyspark.sql.functions import col, lit


def load_fw(event_start_date=None, event_end_date=None):
    fw = (
        fw_logs
        .filter((col("event_date") >= lit(event_start_date)) & (col("event_date") <= lit(event_end_date)))
    )

    print(f"FW DT Range: '{event_start_date}' to '{event_start_date}'")
    return fw


def load_ad_request(event_start_date=None, event_end_date=None):
    """
    Loads 'fw_ad_request' with partition filters.
    """

    ad_req = (
        load_table("ft_freewheel_ad_request_daily")
        .filter((col("event_date") >= lit(event_start_date)) & (col("event_date") <= lit(event_end_date)))
    )

    print(f"Ad Request Range: '{event_start_date}' to '{event_end_date}'")
    return ad_req

# COMMAND ----------


#Example Usage:
fw = load_fw(event_start_date, event_end_date)
ad_req_df = load_ad_request(event_start_date, event_end_date)

# COMMAND ----------

fw = fw.filter(
    col('event_type').isin('RS', 'I', 'R','C') &
    ((col('market_advertiser_id').rlike('^[0-9]+$')) | col('market_advertiser_id').isNull()) &
    ((col('event_name').isin('response', 'slotImpression', 'defaultImpression', 'resellerNoAd','defaultClick')) | col('event_name').isNull())
).filter(col("event_date").isNotNull())

# COMMAND ----------

from pyspark.sql import functions as F

fw_selected = fw.select(
    F.col("authority_code"),
    F.col("network_group_id"),
    F.coalesce(F.col("site_section_id"), F.lit(-1)).alias("site_section_id"),
    F.when(F.col("event_type") == "R", 
           F.regexp_extract(F.col("all_request_kv"), "(fnl-affiliate=)([^&?]*)", 2)
          ).otherwise('N/A').cast("STRING").alias("fnl_affiliate_station"),
    F.when(F.col("event_type") == "R", 
           F.regexp_extract(F.col("all_request_kv"), "(fs-affiliate=)([^&?]*)", 2)
          ).otherwise('N/A').cast("STRING").alias("fs_affiliate_station"),
    F.coalesce(F.col("placement_id"), F.lit(-1)).alias("placement_id"),
    F.coalesce(F.col("sales_channel_type"), F.lit("N/A")).alias("sales_channel_type"),
    F.coalesce(F.col("selling_partner_id"), F.lit(-1)).alias("selling_partner_id"),
    F.coalesce(F.col("video_asset_id"), F.lit(-1)).alias("video_asset_id"),
    F.coalesce(F.col("sold_order_id"), F.lit(-1)).alias("sold_order_id"),
    F.coalesce(F.col("market_deal_id"), F.lit('-1')).alias("market_deal_id"),
    F.coalesce(F.col("series_id"), F.lit(-1)).alias("series_id"),
    F.coalesce(F.col("distribution_partner_id"), F.lit(-1)).alias("distribution_partner_id"),
    F.coalesce(F.col("transaction_id"), F.lit("N/A")).alias("transaction_id"),
    F.coalesce(F.col("time_position_class"), F.lit("N/A")).alias("slot_type"),
    F.coalesce(F.col("slot_index"), F.lit(-1)).alias("slot_index"),
    F.coalesce(F.col("creative_id"), F.lit(-1)).alias("creative_id"),
    F.coalesce(F.col("creative_duration"), F.lit(-1)).alias("creative_duration_secs"),
    F.coalesce(F.col("ad_unit_id"), F.lit(-1)).alias("ad_unit_id"),
    F.coalesce(F.col("global_advertiser_id"), F.lit("-1")).alias("global_advertiser_id"),
    F.coalesce(F.col("mrm_rule_id"), F.lit(-1)).alias("mrm_rule_id"),
    F.coalesce(F.col("listing_id"), F.lit("-1")).alias("listing_id"),
    F.coalesce(F.col("unique_identifier"), F.lit("N/A")).alias("unique_user_identifier"),
    F.coalesce(F.col("event_type"), F.lit("N/A")).alias("event_type"),
    F.coalesce(F.col("event_name"), F.lit("N/A")).alias("event_name"),
    F.coalesce(F.col("event_time"), F.lit("N/A")).alias("event_timestamp_utc"),
    F.coalesce(F.col("net_value"),F.lit(0)).alias("net_value_usd"),
    F.coalesce(F.col("max_ads"),F.lit(0)).alias("max_ads"),
    F.coalesce(F.col("max_duration"),F.lit(0)).alias("max_duration_secs"),
    F.coalesce(F.col("time_unfilled"),F.lit(0)).alias("time_unfilled_secs"),
    F.coalesce(F.col("ads_selected"),F.lit(0)).alias("ads_selected"),
    F.coalesce(F.col("ad_duration"),F.lit(0)).alias("ad_duration_secs"),
    F.coalesce(F.col("content_duration"),F.lit(0)).alias("content_duration_secs"),
    F.coalesce(F.col("referrer_url"), F.lit("N/A")).alias("referrer_url"),
    F.coalesce(F.col("visitor_country"), F.lit("N/A")).alias("visitor_country"),
    F.coalesce(F.col("visitor_state_province"), F.lit("N/A")).alias("visitor_state_province"),
    F.coalesce(F.col("visitor_dma"), F.lit("N/A")).alias("visitor_dma"),
    F.coalesce(F.col("visitor_postal_code"), F.lit("N/A")).alias("visitor_postal_code"),
    F.coalesce(F.col("visitor_city"), F.lit("N/A")).alias("visitor_city"),
    F.coalesce(F.col("platform_os_id"), F.lit("-1")).alias("platform_os_id"),
    F.coalesce(F.col("givt_decision_result"), F.lit("N/A")).alias("givt_decision_result"),
    F.col("event_date").alias("event_date"),
    F.col("event_time").alias("event_time"),
    F.col("event_hour").alias("event_hour")
);

# COMMAND ----------

# FreeWheel Transformations
fw_group_by_cols = [
    'authority_code',
    'network_group_id',
    'global_advertiser_id',
    'placement_id',
    'site_section_id',
    'creative_id',
    'creative_duration_secs',
    'ad_unit_id',
    'fnl_affiliate_station',
    'fs_affiliate_station',
    'sales_channel_type',
    'selling_partner_id',
    'video_asset_id',
    "sold_order_id",
    "market_deal_id",
    'series_id',
    'distribution_partner_id',
    'transaction_id',
    'slot_type',
    'slot_index',
    'mrm_rule_id',
    'listing_id',
    'content_duration_secs',
    'referrer_url',
    'visitor_country',
    'visitor_state_province',
    'visitor_dma',
    'visitor_postal_code',
    'visitor_city',
    'platform_os_id',
    'event_date'
]

# COMMAND ----------

# Step 1: Precompute ratios per row
fw_selected = fw_selected.withColumn(
    'slate_ratio',
    F.when(fw_selected.max_duration_secs > 0,
           fw_selected.time_unfilled_secs / fw_selected.max_duration_secs)
)

fw_selected = fw_selected.withColumn(
    'fill_ratio',
    F.when(fw_selected.max_duration_secs > 0,
           (fw_selected.max_duration_secs - fw_selected.time_unfilled_secs) / fw_selected.max_duration_secs)
)

# COMMAND ----------

# Step 2: GroupBy and Aggregate
fw_agg = fw_selected.groupBy(fw_group_by_cols).agg(
    F.sum(F.when(fw_selected.event_type == 'R', 1).otherwise(0)).alias('ad_requests'),
    F.sum(F.when(fw_selected.event_type == 'RS', 1).otherwise(0)).alias('ad_responses'),
    F.sum(F.when((fw_selected.event_type == 'C') & (fw_selected.givt_decision_result == 'Pass'),1).otherwise(0)).alias('ad_clicks'),
    F.max(fw_selected.max_ads).alias('max_ads'),
    F.max(fw_selected.max_duration_secs).alias('max_duration_secs'),
    F.max(fw_selected.ads_selected).alias('ads_selected'),
    F.max(fw_selected.ad_duration_secs).alias('ad_duration_secs'),
    F.max(fw_selected.time_unfilled_secs).alias('time_unfilled_secs'),
    F.max(fw_selected.max_duration_secs - fw_selected.time_unfilled_secs).alias('time_filled_secs'),
    F.sum(F.when(fw_selected.event_name == 'slotImpression', 1).otherwise(0)).alias('slot_impressions'),
    F.sum(F.when(fw_selected.event_name == 'defaultImpression', 1).otherwise(0)).alias('ad_impressions'),
    F.sum(F.when((fw_selected.event_name == 'defaultImpression') & (fw_selected.givt_decision_result == 'Pass'), 1).otherwise(0)).alias('net_counted_ads'),
    ((F.max(fw_selected.max_duration_secs) / 15) - 
     F.sum(F.when((fw_selected.event_name == 'defaultImpression') &
                  (fw_selected.givt_decision_result == 'Pass'), 1).otherwise(0))
    ).alias('unfilled_impressions'),
    F.max(F.when(fw_selected.event_name == 'defaultImpression', fw_selected.net_value_usd)).alias('ad_revenue_usd'),
    F.sum(F.when(fw_selected.event_name == 'resellerNoAd', 1).otherwise(0)).alias('unfilled_reseller_ad_slots'),
    F.max(F.col('slate_ratio') * 100).alias('slate_percentage'),
    F.max(F.col('fill_ratio') * 100).alias('fill_rate'),
).drop('slate_ratio', 'fill_ratio')

# Step 3: Compute additional metrics
fw_agg = fw_agg.withColumn('unfilled_impressions', fw_agg.unfilled_impressions.cast('bigint'))
fw_agg = fw_agg.withColumn('ad_cpm', (fw_agg.ad_revenue_usd / fw_agg.ad_impressions) * 1000)
fw_agg = fw_agg.withColumn('ad_ctr', (fw_agg.ad_clicks / fw_agg.ad_impressions) * 100)
fw_agg = fw_agg.withColumn('ad_cpc', (fw_agg.ad_revenue_usd / fw_agg.ad_clicks) * 100)

# COMMAND ----------

# -------------------------------
# STEP 1: Direct Sold Advertiser Join
# -------------------------------
# Filter for fw_direct_sold_advertiser and deduplicate
direct_sold_advertiser = advertiser.filter(col("data_source_code") == "fw_direct_sold_advertiser") \
    .withColumnRenamed('advertiser_id', 'direct_sold_advertiser_id') \
    .withColumnRenamed('advertiser_name', 'direct_sold_advertiser_name') \
    .select('direct_sold_advertiser_id', 'direct_sold_advertiser_name', 'placement_id', 'network_group_id') \
    .dropDuplicates()

# Join with fw_agg
fw_agg_joined = fw_agg.join(
    direct_sold_advertiser,
    ['placement_id', 'network_group_id'],
    'left'
)

# Set advertiser_id using direct_sold_id only when global is -1
fw_agg_joined = fw_agg_joined.withColumn(
    'advertiser_id',
    F.when(col('global_advertiser_id') == '-1', col('direct_sold_advertiser_id'))
    .otherwise(col('global_advertiser_id'))
)



# Initialize advertiser_name from direct sold
fw_agg_joined = fw_agg_joined.withColumn(
    'advertiser_name',
    col('direct_sold_advertiser_name')
)

# Clean up
fw_agg_joined = fw_agg_joined.drop('direct_sold_advertiser_id', 'direct_sold_advertiser_name', 'global_advertiser_id')

# COMMAND ----------

# Filter fw_global_advertiser and deduplicate by advertiser_id + network_group_id
global_advertiser_deduped = advertiser.filter(col("data_source_code") == "fw_global_advertiser") \
    .select('advertiser_id', 'advertiser_name', 'network_group_id').dropDuplicates()


# Join to get fallback advertiser_name
fw_agg_joined = fw_agg_joined.join(
    global_advertiser_deduped.withColumnRenamed("advertiser_name", "fallback_advertiser_name"),
    on=['advertiser_id', 'network_group_id'],
    how='left'
)

# Use fallback name only if advertiser_name is still null
fw_agg_joined = fw_agg_joined.withColumn(
    'advertiser_name',
    F.when((col('advertiser_name')=='N/A') | col('advertiser_name').isNull(), col('fallback_advertiser_name'))
    .otherwise(col('advertiser_name'))
).drop('fallback_advertiser_name')

# COMMAND ----------

#JOIN WITH SITE SECTION
fw_agg_joined = fw_agg_joined.join(
    site_section.selectExpr(
        'site_section_id',
        'network_group_id',
        'site_section_name as site_section_detail',
        'stream_type as stream_type',
        'app as app_name',
        'ownership_type as ownership_type',
        'device_type as device_type',
        'device_type_detail as device_type_detail'
    ),
    ['site_section_id', 'network_group_id'], 'left'
);

# COMMAND ----------

# JOIN video_series data
fw_agg_joined = fw_agg_joined.join(
    video_series.selectExpr(
        'series_id',
        'network_group_id',
        'series_name as series_name',
        'business_unit as business_unit',
        'group_series_type as group_series_type'
    ),
    ['series_id', 'network_group_id'], 'left'
)

# COMMAND ----------

fw_agg_joined = fw_agg_joined.withColumn('ad_unit_category', F.lit('Videos'))\
    .withColumn(
        'ad_unit_format',
        F.when(fw_agg_joined.content_duration_secs == 1, 'Short Form')
         .when(fw_agg_joined.content_duration_secs == 2, 'Mid Form')
         .when(fw_agg_joined.content_duration_secs == 3, 'Long Form')
    )

# COMMAND ----------

# JOIN network data
fw_agg_joined = fw_agg_joined.join(
    network.selectExpr(
        'site_section_name as site_section_detail',
        'series_name as series_name',
        'network'
    ),
    ['site_section_detail', 'series_name'], 'left'
)

# COMMAND ----------

# JOIN video_asset data
fw_agg_joined = fw_agg_joined.join(
    video_asset.selectExpr(
        'video_asset_id',
        'network_group_id',
        'video_asset_name'
    ),
    ['video_asset_id', 'network_group_id'], 'left'
)

# COMMAND ----------

# JOIN campaign_and_placement data
fw_agg_joined = fw_agg_joined.join(
    campaign_and_placement.selectExpr(
        'placement_id',
        'network_group_id',
        'insertion_order_id',
        'insertion_order_name',
        'placement_name',
        'campaign_id',
        'campaign_name',
        'placement_type'
    ),
    ['placement_id', 'network_group_id'], 'left'
);

# COMMAND ----------

# JOIN partner_network data
fw_agg_joined = fw_agg_joined.join(
    partner_network.selectExpr(
        'network_id as distribution_partner_id',
        'network_group_id',
        'network_group_name as distributor'
    ),
    ['distribution_partner_id', 'network_group_id'], 'left'
);

# COMMAND ----------

# Add new computed columns
fw_agg_joined = fw_agg_joined.withColumn('ad_unit_category', F.lit('Videos'))\
    .withColumn(
        'ad_unit_format',
        F.when(fw_agg_joined.content_duration_secs == 1, 'Short Form')
         .when(fw_agg_joined.content_duration_secs == 2, 'Mid Form')
         .when(fw_agg_joined.content_duration_secs == 3, 'Long Form')
    )

# COMMAND ----------

# JOIN creative data
fw_agg_joined =fw_agg_joined .join(
    creative.selectExpr(
        'creative_id',
        'network_group_id',
        'creative_name',
        'creative_size'
    ),
    ['creative_id', 'network_group_id'], 'left'
)

# COMMAND ----------

# JOIN ad_req data
fw_agg_joined = fw_agg_joined.join(
    ad_req_df.selectExpr(
        'transaction_id',
        'freewheel_network_id as freewheel_network_id_ad_req',
        'ad_response_type as ad_response_type_ad_req',
        'additional_ad_response_type as additional_ad_response_type_ad_req',
        'player_profile as player_profile_ad_req',
        'custom_site_section_id as custom_site_section_id_ad_req',
        'video_asset as video_asset_ad_req',
        'asset_network_id as asset_network_id_ad_req',
        'site_section_network_id as site_section_network_id_ad_req',
        'page_view_random as page_view_random_ad_req',
        'video_player_random as video_player_random_ad_req',
        'video_player_capabilities as video_player_capabilities_ad_req',
        'default_metrics as default_metrics_ad_req',
        'kvp as kvp_ad_req',
        'asset_fallback_id as asset_fallback_id_ad_req',
        'site_section_fallback_id as site_section_fallback_id_ad_req',
        'end_user_ip as end_user_ip_ad_req',
        'request_mode as request_mode_ad_req',
        'video_asset_duration_type as video_asset_duration_type_ad_req',
        'content_video_duration_secs as content_video_duration_ad_req',
        'video_request_duration_secs as video_request_duration_ad_req',
        'server_side_vendor_indicator as server_side_vendor_indicator_ad_req',
        'nielsen_app_id as nielsen_app_id_ad_req',
        'user_agent as user_agent_ad_req',
        'http_referer as http_referer_ad_req',
        'mvpd_provider as mvpd_provider_ad_req',
        'hylda as hylda_ad_req',
        'ccpa_compliance as ccpa_compliance_ad_req',
        'limited_ad_tracking as limited_ad_tracking_ad_req',
        'device_id as device_id_ad_req',
        'custom_visitor_id as custom_visitor_id_ad_req',
        'slot_custom_id as slot_custom_id_ad_req',
        'slot_time_position as slot_time_position_ad_req',
        'type_of_slot as type_of_slot_ad_req',
        'slot_max_duration_secs as slot_max_duration_ad_req',
        'specify_custom_ad_unit as specify_custom_ad_unit_ad_req',
        'cue_point_position as cue_point_position_ad_req',
        'minimum_duration_of_slot_secs as minimum_duration_of_slot_ad_req',
        'yospace_transaction_id as yospace_transaction_id_ad_req',
        'bundle_id as bundle_id_req',
        'ifa as ifa_req',
        'app_store_url as app_store_url_req',
        'genre as genre_req',
        'rating as rating_req',
        'network_ad_req as network_req',
        'channel as channel_req'
    ),
    ['transaction_id'], 'left'
);

# COMMAND ----------

# JOIN mrm_rule data
fw_agg_joined = fw_agg_joined.join(
    mrm_rule.selectExpr(
        'mrm_rule_id',
        'mrm_rule_name',
        'network_group_id'
    ),
    ['mrm_rule_id','network_group_id'], 'left'
)

# COMMAND ----------

# JOIN listing data
fw_agg_joined = fw_agg_joined.join(
    listing.selectExpr(
        'listing_id',
        'listing_name',
        'network_group_id'
    ),
    ['listing_id','network_group_id'], 'left'
)

# COMMAND ----------

# JOIN sold_order data
fw_agg_joined = fw_agg_joined.join(
    sold_order.selectExpr(
        'sold_order_id',
        'sold_order_name',
        'network_group_id'
    ),
    ['sold_order_id','network_group_id'], 'left'
)

# COMMAND ----------

# JOIN sold_order data
fw_agg_joined = fw_agg_joined.join(
    market_deal.selectExpr(
        'market_deal_id',
        'market_deal_name',
        'network_group_id'
    ),
    ['market_deal_id','network_group_id'], 'left'
)

# COMMAND ----------

fw_cols_renamed = {
        'visitor_country': 'country_name',
        'visitor_state_province': 'region_name',
        'visitor_dma': 'metro_name',
        'visitor_postal_code': 'zip_code',
        'visitor_city': 'city_name'
    }
for key, value in fw_cols_renamed.items():
  fw_agg_joined = fw_agg_joined.withColumnRenamed(key, value)

# COMMAND ----------

#add the hash keys from pyspark.sql.functions import col, concat_ws, xxhash64 for SCD
from pyspark.sql.functions import col, concat_ws, xxhash64,coalesce

fw_agg_joined = fw_agg_joined.withColumn(
    'mrm_key_hash',
    xxhash64(
        concat_ws('||', col('mrm_rule_id').cast('string'), col('network_group_id').cast('string'))
    )
);


fw_agg_joined = fw_agg_joined.withColumn(
    'series_key_hash',
    xxhash64(
        concat_ws(
            '||',
            col('series_id').cast('string'),
            col('network_group_id').cast('string')
        )
    )
);



fw_agg_joined = fw_agg_joined.withColumn(
    'site_section_key_hash',
    xxhash64(
        concat_ws(
            '||',
            col('site_section_id').cast('string'),
            col('network_group_id').cast('string')
        )
    )
);

# COMMAND ----------

fw_agg_joined = fw_agg_joined.selectExpr(
    
    "authority_code",
    "network_group_id",
    "event_date",
    "'UTC' as time_zone",
    "transaction_id",

    # ad request metrics
    'freewheel_network_id_ad_req as freewheel_network_id',
    'ad_response_type_ad_req as ad_response_type',
    'additional_ad_response_type_ad_req as additional_ad_response_type',
    'player_profile_ad_req as player_profile',
    'custom_site_section_id_ad_req as custom_site_section_id',
    'video_asset_ad_req as video_asset',
    'asset_network_id_ad_req as asset_network_id',
    'site_section_network_id_ad_req as site_section_network_id',
    'page_view_random_ad_req as page_view_random',
    'video_player_random_ad_req as video_player_random',
    'video_player_capabilities_ad_req as video_player_capabilities',
    'default_metrics_ad_req as default_metrics',
    'kvp_ad_req as kvp',
    'asset_fallback_id_ad_req as asset_fallback_id',
    'site_section_fallback_id_ad_req as site_section_fallback_id',
    'end_user_ip_ad_req as end_user_ip',
    'request_mode_ad_req as request_mode',
    'video_asset_duration_type_ad_req as video_asset_duration_type',
    'content_video_duration_ad_req as content_video_duration_secs',
    'video_request_duration_ad_req as video_request_duration_secs',
    'server_side_vendor_indicator_ad_req as server_side_vendor_indicator',
    'nielsen_app_id_ad_req as nielsen_app_id',
    'user_agent_ad_req as user_agent',
    'http_referer_ad_req as http_referer',
    'mvpd_provider_ad_req as mvpd_provider',
    'hylda_ad_req as hylda',
    'ccpa_compliance_ad_req as ccpa_compliance',
    'limited_ad_tracking_ad_req as limited_ad_tracking',
    'device_id_ad_req as device_id',
    'custom_visitor_id_ad_req as custom_visitor_id',
    'slot_custom_id_ad_req as slot_custom_id',
    'slot_time_position_ad_req as slot_time_position',
    'type_of_slot_ad_req as type_of_slot',
    'slot_max_duration_ad_req as slot_max_duration_secs',
    'specify_custom_ad_unit_ad_req as specify_custom_ad_unit',
    'cue_point_position_ad_req as cue_point_position',
    'minimum_duration_of_slot_ad_req as minimum_duration_of_slot_secs',
    'yospace_transaction_id_ad_req as yospace_transaction_id',
    'bundle_id_req as bundle_id',
    'ifa_req as ifa',
    'app_store_url_req as app_store_url',
    'genre_req as genre',
    'rating_req as rating',
    'network_req as network_ad_req',
    'channel_req as channel',

    # dimensions
    "fnl_affiliate_station",
    "fs_affiliate_station",
    "slot_type",
    "slot_index",
    "COALESCE(advertiser_id,'-1') as advertiser_id",
    "COALESCE(advertiser_name,'N/A') as advertiser_name",
    "COALESCE(insertion_order_id,-1) as insertion_order_id",
    "COALESCE(insertion_order_name, 'N/A') as insertion_order_name",
    "COALESCE(campaign_id,-1) as campaign_id",
    "COALESCE(campaign_name,'N/A') as campaign_name",
    "site_section_key_hash",
    "site_section_id",
    "COALESCE(site_section_detail, 'N/A') as site_section_detail",
    "COALESCE(stream_type, 'N/A') as stream_type",
    "COALESCE(app_name, 'N/A') as app_name",
    "COALESCE(network, 'N/A') as network",
    "COALESCE(ownership_type, 'N/A') as ownership_type",
    "COALESCE(device_type, 'N/A') as device_type",
    "COALESCE(device_type_detail, 'N/A') as device_type_detail",
    "COALESCE(business_unit, 'N/A') as business_unit",
    "listing_id",
    "COALESCE(listing_name,'N/A') as listing_name",
    "mrm_key_hash",
    "mrm_rule_id",
    "COALESCE(mrm_rule_name,'N/A') as mrm_rule_name",
    "placement_id",
    "COALESCE(placement_name,'N/A') as placement_name",
    "COALESCE(placement_type,'N/A') as placement_type",
    "selling_partner_id",
    "series_key_hash",
    "series_id",
    "COALESCE(series_name,'N/A') as series_name",
    "COALESCE(group_series_type,'N/A') as group_series_type",
    "video_asset_id",
    "COALESCE(video_asset_name,'N/A') as video_asset_name",
    "creative_id",
    "COALESCE(creative_size,'N/A') as creative_pixel_size",
    "COALESCE(creative_name,'N/A') as creative_name",
    "COALESCE(creative_duration_secs,0) as creative_duration_secs",
    "sold_order_id",
    "COALESCE(sold_order_name,'N/A') as sold_order_name",
    "market_deal_id",
    "COALESCE(market_deal_name,'N/A') as market_deal_name",
    "sales_channel_type",
    "distribution_partner_id",
    "ad_unit_category",
    "ad_unit_format",
    "referrer_url",
    "country_name",
    "region_name",
    "metro_name",
    "city_name",
    "zip_code",
    "COALESCE(distributor,'N/A') as distributor",

    # metrics
    "ad_requests AS ad_requests",
    "ad_responses AS ad_responses",
    "ad_impressions AS ad_impressions",
    "net_counted_ads as net_counted_ads",
    "unfilled_impressions AS unfilled_impressions",
    "slot_impressions AS slot_impressions",
    "ad_clicks AS ad_clicks",
    "CAST(ROUND(ad_ctr, 14) AS DOUBLE) as ad_click_through_rate",
    "CAST(ROUND(ad_cpc,14) AS DOUBLE) as ad_cost_per_click_usd",
    "CAST(ROUND(ad_revenue_usd, 14) as DOUBLE) as ad_revenue_usd",
    "CAST(ROUND(ad_cpm,14) as DOUBLE) as ad_cost_per_mile_usd",
    "unfilled_reseller_ad_slots AS unfilled_reseller_ad_slots",
    "CAST(max_ads AS BIGINT) AS max_ads",
    "CAST(max_duration_secs AS BIGINT) AS max_duration_secs",
    "CAST(ads_selected AS BIGINT) ads_selected",
    "CAST(ad_duration_secs AS BIGINT) AS ad_duration_secs",
    "CAST(time_unfilled_secs AS BIGINT) AS time_unfilled_secs",
    "CAST(time_filled_secs AS BIGINT) AS time_filled_secs",
    "CAST(ROUND(slate_percentage, 14) as DOUBLE) as slate_percentage",
    "CAST(ROUND(fill_rate, 14) as DOUBLE) as fill_rate",

    # Audit columns
    "CURRENT_TIMESTAMP() AS etl_created_at_timestamp_utc",
    "CURRENT_TIMESTAMP() AS etl_updated_at_timestamp_utc"
);

# COMMAND ----------

fw_agg_joined.write.format("delta") \
    .mode('overwrite')\
    .option('partitionOverwriteMode', 'dynamic')\
    .saveAsTable("fox_bi_dev.silver_ads.ft_freewheel_ad_delivery_slot_level_daily")