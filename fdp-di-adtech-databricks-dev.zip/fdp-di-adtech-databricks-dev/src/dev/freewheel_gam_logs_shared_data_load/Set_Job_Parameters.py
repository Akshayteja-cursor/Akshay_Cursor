# Databricks notebook source
# Read widgets
skip_freewheel = dbutils.widgets.get("skip_freewheel")
skip_freewheel_ad_request = dbutils.widgets.get("skip_freewheel_ad_request")
skip_gam = dbutils.widgets.get("skip_gam")
skip_bronze = dbutils.widgets.get("skip_bronze")
from_email= dbutils.widgets.get("from_email")
aws_profile = dbutils.widgets.get("aws_profile")
aws_arn = dbutils.widgets.get("aws_arn")

# COMMAND ----------

from datetime import datetime, timedelta

current_date_str = dbutils.widgets.get("current_date")
run_type = dbutils.widgets.get("run_type")

# COMMAND ----------

#
if dbutils.widgets.get("run_type") == "regular":
  ## then populate event_start_date_freewheel , event_end_date_freewheel , event_start_date_gam and event_end_date_gam from current_date,

    # Parse current_date string to datetime object
    current_date = datetime.strptime(current_date_str, "%Y-%m-%d")

    # Set Freewheel dates to current_date - 1
    event_start_date_freewheel = (current_date - timedelta(days=1)).strftime("%Y-%m-%d")
    event_end_date_freewheel = (current_date -  timedelta(days=1)).strftime("%Y-%m-%d")

    # Set GAM dates to current_date - 2
    event_start_date_gam = (current_date - timedelta(days=2)).strftime("%Y-%m-%d")
    event_end_date_gam = (current_date - timedelta(days=2)).strftime("%Y-%m-%d")

elif dbutils.widgets.get("run_type") == "backfill":
  ## fetch the provided values of event_start_date_freewheel , event_end_date_freewheel , event_start_date_gam and event_end_date_gam from the widgets
  event_start_date_freewheel = dbutils.widgets.get("event_start_date_freewheel")
  event_end_date_freewheel = dbutils.widgets.get("event_end_date_freewheel")
  event_start_date_gam = dbutils.widgets.get("event_start_date_gam")
  event_end_date_gam = dbutils.widgets.get("event_end_date_gam")

else:
  raise Exception("run_type must be either regular or backfill")

# COMMAND ----------

# Always set the task values so downstream notebooks can read them
dbutils.jobs.taskValues.set("event_start_date_freewheel", event_start_date_freewheel)
dbutils.jobs.taskValues.set("event_end_date_freewheel", event_end_date_freewheel)
dbutils.jobs.taskValues.set("event_start_date_gam", event_start_date_gam)
dbutils.jobs.taskValues.set("event_end_date_gam", event_end_date_gam)
dbutils.jobs.taskValues.set("skip_freewheel", skip_freewheel)
dbutils.jobs.taskValues.set("skip_freewheel_ad_request", skip_freewheel_ad_request)
dbutils.jobs.taskValues.set("skip_gam", skip_gam)
dbutils.jobs.taskValues.set("skip_bronze", skip_bronze)
dbutils.jobs.taskValues.set("from_email", from_email)
dbutils.jobs.taskValues.set("aws_profile", aws_profile)
dbutils.jobs.taskValues.set("aws_arn", aws_arn)