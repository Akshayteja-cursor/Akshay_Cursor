# Databricks notebook source
event_start_date_freewheel=dbutils.jobs.taskValues.get("Set_Job_Parameters",'event_start_date_freewheel')
event_end_date_freewheel=dbutils.jobs.taskValues.get("Set_Job_Parameters",'event_end_date_freewheel')

event_start_date_gam=dbutils.jobs.taskValues.get("Set_Job_Parameters",'event_start_date_gam')
event_end_date_gam=dbutils.jobs.taskValues.get("Set_Job_Parameters",'event_end_date_gam')

skip_freewheel=dbutils.jobs.taskValues.get("Set_Job_Parameters",'skip_freewheel')
skip_gam=dbutils.widgets.get('skip_gam')

# COMMAND ----------

spark.conf.set("spark.sql.shuffle.partitions", "auto")

# COMMAND ----------

query_freewheel_select=f""" 

SELECT
ft.authority_code,
ft.network_group_id,
ft.event_date,
'UTC' as time_zone,
ft.transaction_id,
ft.freewheel_network_id,
ft.ad_response_type,
ft.additional_ad_response_type,
ft.player_profile,
ft.custom_site_section_id,
ft.video_asset,
ft.asset_network_id,
ft.site_section_network_id,
ft.page_view_random,
ft.video_player_random,
ft.video_player_capabilities,
ft.default_metrics,
ft.kvp,
ft.asset_fallback_id,
ft.site_section_fallback_id,
ft.end_user_ip,
ft.request_mode,
ft.video_asset_duration_type,
ft.content_video_duration_secs,
ft.video_request_duration_secs,
ft.server_side_vendor_indicator,
ft.nielsen_app_id,
ft.user_agent,
ft.http_referer,
ft.mvpd_provider,
ft.hylda,
ft.ccpa_compliance,
ft.limited_ad_tracking,
ft.device_id,
ft.custom_visitor_id,
ft.slot_custom_id,
ft.slot_time_position,
ft.type_of_slot,
ft.slot_max_duration_secs,
ft.specify_custom_ad_unit,
ft.cue_point_position,
ft.minimum_duration_of_slot_secs,
ft.yospace_transaction_id,
ft.bundle_id,
ft.ifa,
ft.app_store_url,
ft.genre,
ft.rating,
ft.network_ad_req,
ft.channel,
ft.fnl_affiliate_station,
ft.fs_affiliate_station,
ft.slot_type,
ft.slot_index,
ft.advertiser_id,
ft.advertiser_name,
ft.insertion_order_id,
ft.insertion_order_name,
ft.campaign_id as campaign_or_order_id,
ft.campaign_name as campaign_or_order_name,
ft.site_section_id as site_section_or_ad_unit_id,
ft.site_section_detail,
ft.stream_type,
ft.app_name,
ft.network as network_name,
ft.ownership_type,
ft.device_type,
ft.device_type_detail,
ft.business_unit,
ft.listing_id,
ft.listing_name,
ft.mrm_rule_id,
ft.mrm_rule_name,
ft.placement_id as placement_or_line_item_id,
ft.placement_name as placement_or_line_item_name,
ft.placement_type as placement_or_line_item_type,
ft.selling_partner_id,
ft.series_id,
ft.series_name,
group_series_type,
video_asset_id,
video_asset_name,
creative_id,
creative_pixel_size,
creative_name,
creative_duration_secs,
sold_order_id,
sold_order_name,
market_deal_id,
market_deal_name,
sales_channel_type,
distribution_partner_id,
'N/A' as impression_id,
'N/A' as user_identity_status,
'N/A' as page_type_detail,
ad_unit_category,
ad_unit_format,
'N/A' as ad_unit_detail_name,
referrer_url,
country_name,
region_name,
metro_name,
city_name,
zip_code,
distributor as distributor_name,
NULL:: BOOLEAN is_video_ad_fallback_request,
-1 AS video_ad_fallback_position,
NULL:: BOOLEAN is_companion_ad,
NULL:: STRING as us_privacy,
NULL:: STRING as xid,
NULL:: STRING as fp_td,
NULL:: STRING as fp_lr,
-1 as line_item_key_hash,
-1 as content_key_hash,
ft.site_section_key_hash,
ft.mrm_key_hash,
ft.series_key_hash,

--METRICS
ad_requests,
NULL:: BIGINT as unmatched_ad_requests,
ad_responses,
ad_impressions,
unfilled_impressions,
net_counted_ads,
slot_impressions,
ad_clicks,
ad_click_through_rate,
ad_cost_per_click_usd,
ad_revenue_usd,
ad_cost_per_mile_usd,
unfilled_reseller_ad_slots,
max_ads,
max_duration_secs,
ads_selected,
ad_duration_secs,
time_unfilled_secs,
time_filled_secs,
slate_percentage,
fill_rate,
NULL:: BIGINT AS total_error_count,
CURRENT_TIMESTAMP AS etl_created_at_timestamp_utc,
CURRENT_TIMESTAMP AS etl_updated_at_timestamp_utc

from
fox_bi_dev.silver_ads.FT_FREEWHEEL_AD_DELIVERY_SLOT_LEVEL_daily ft 

WHERE event_date>='{event_start_date_freewheel}' and event_date<='{event_end_date_freewheel}'
"""


if skip_freewheel=='true':
  query_freewheel_filter=""" AND 1=0 """
else:
  query_freewheel_filter =""" AND 1=1 """

query_freewheel_final=query_freewheel_select+query_freewheel_filter

# COMMAND ----------

query_gam_select=f"""

SELECT
ft.authority_code,
ft.network_group_id,
ft.event_date,
'EST' as time_zone,
ft.transaction_id,
-1 as freewheel_network_id,
'N/A' as ad_response_type,
'N/A' as additional_ad_response_type,
'N/A' as player_profile,
-1 as custom_site_section_id,
'N/A' as video_asset,
-1 as asset_network_id,
-1 as site_section_network_id,
'N/A' as page_view_random,
'N/A' as video_player_random,
'N/A' as video_player_capabilities,
-1 as default_metrics,
'N/A' as kvp,
-1 as asset_fallback_id,
-1 as site_section_fallback_id,
'N/A' as end_user_ip,
'N/A' as request_mode,
'N/A' as video_asset_duration_type,
'N/A' as content_video_duration_secs,
'N/A' as video_request_duration_secs,
'N/A' as server_side_vendor_indicator,
'N/A' as nielsen_app_id,
'N/A' as user_agent,
'N/A' as http_referer,
'N/A' as mvpd_provider,
'N/A' as hylda,
'N/A' as ccpa_compliance,
'N/A' as limited_ad_tracking,
'N/A' as device_id,
'N/A' as custom_visitor_id,
'N/A' as slot_custom_id,
'N/A' as slot_time_position,
'N/A' as type_of_slot,
'N/A' as slot_max_duration_secs,
'N/A' as specify_custom_ad_unit,
'N/A' as cue_point_position,
'N/A' as minimum_duration_of_slot_secs,
'N/A' as yospace_transaction_id,
'N/A' as bundle_id,
'N/A' as ifa,
'N/A' as app_store_url,
'N/A' as genre,
'N/A' as rating,
'N/A' as network_ad_req,
'N/A' as channel,
'N/A' as fnl_affiliate_station,
'N/A' as fs_affiliate_station,
ft.slot_type,
ft.slot_index,
ft.advertiser_id,
ft.advertiser_name,
-1 as insertion_order_id,
'N/A' as insertion_order_name,
ft.order_id as campaign_or_order_id,
ft.order_name as campaign_or_order_name,
ft.ad_unit_id as site_section_or_ad_unit_id,
ft.site_section_detail,
'N/A' as stream_type,
ft.app_name,
ft.network as network_name,
ft.ownership_type,
ft.device_type,
ft.device_type_detail,
ft.business_unit,
'-1' as listing_id,
'N/A' AS listing_name,
-1 AS mrm_rule_id,
'N/A' as mrm_rule_name,
ft.line_item_id as placement_or_line_item_id,
ft.line_item_name as placement_or_line_item_name,
ft.line_item_type as placement_or_line_item_type,
-1 as selling_partner_id,
ft.series_id,
ft.series_name,
'N/A' as group_series_type,
ft.video_asset_id,
ft.video_asset_name,
ft.creative_id,
ft.creative_pixel_size,
ft.creative_name,
-1 as creative_duration_secs,
-1 as sold_order_id,
'N/A' AS sold_order_name,
-1 AS market_deal_id,
'N/A' as market_deal_name,
ft.line_item_type as sales_channel_type,
ft.distribution_partner_id,
ft.impression_id,
'N/A' as user_identity_status,
'N/A' as page_type_detail,
ft.ad_unit_category,
ft.ad_unit_format,
ft.ad_unit_detail_name,
ft.referrer_url,
ft.country_name,
ft.region_name,
ft.metro_name,
ft.city_name,
ft.postal_code as zip_code,
ft.distributor as distributor_name,
ft.is_video_ad_fallback_request,
ft.video_ad_fallback_position,
ft.is_companion_ad,
ft.us_privacy,
ft.xid,
ft.fp_td,
ft.fp_lr,
ft.line_item_key_hash,
ft.content_key_hash,
-1 as site_section_key_hash,
-1 as mrm_key_hash,
-1 as series_key_hash,


--METRICS
ad_requests,
unmatched_ad_requests,
ad_responses,
ad_impressions,
unfilled_impressions,
NULL::BIGINT AS net_counted_ads,
NULL::BIGINT AS slot_impressions,
ad_clicks,
ad_click_through_rate,
ad_cost_per_click_usd,
ad_revenue_usd,
ad_cost_per_mile_usd,
NULL:: BIGINT AS unfilled_reseller_ad_slots,
max_ads,
max_duration_secs,
ads_selected,
ad_duration_secs,
time_unfilled_secs,
time_filled_secs,
slate_percentage,
fill_rate,
total_error_count,
CURRENT_TIMESTAMP AS etl_created_at_timestamp_utc,
CURRENT_TIMESTAMP AS etl_updated_at_timestamp_utc
from
fox_bi_dev.silver_ads.FT_GAM_AD_DELIVERY_AD_UNIT_LEVEL_DAILY ft

WHERE event_date>='{event_start_date_gam}' and event_date<='{event_end_date_gam}'
"""


# if skip_gam=='true':
#   query_gam_filter=""" AND 1=0 """
# else:
#   query_gam_filter =""" AND 1=1 """

# query_gam_final=query_gam_select+query_gam_filter

# COMMAND ----------

query_final=query_freewheel_final #+""" 

# UNION 

# """+query_gam_final

# COMMAND ----------

print(query_final)

# COMMAND ----------

df=spark.sql(query_final)

# COMMAND ----------

df.write.format('delta') \
  .mode('overwrite')\
  .option('partitionOverwriteMode', 'dynamic')\
  .saveAsTable("fox_bi_dev.gold_ads.ft_ad_delivery_slot_ad_unit_level_daily")