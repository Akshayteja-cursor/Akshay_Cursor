# Databricks notebook source
from googleads import ad_manager, oauth2, errors
import boto3
import os
from typing import Any
import json
import tempfile
from datetime import datetime, timedelta
import pytz
import time
import pandas as pd
from pyspark.sql import SparkSession
import pyspark.sql.types as T
import pyspark.sql.functions as F
from pyspark import SparkFiles

# COMMAND ----------

global aws_profile, APPLICATION_NAME, NETWORK_CODE

# COMMAND ----------

def get_widget_or_none(name):
    try:
        return dbutils.widgets.get(name)
    except Exception:
        return None
      
timezone = pytz.timezone("UTC")

env = dbutils.widgets.get('env')
role_arn = dbutils.widgets.get('role_arn')
gam_service_account_creds_secret_arn=dbutils.widgets.get('gam_service_account_creds_secret_arn')
gam_api_version = dbutils.widgets.get('gam_api_version')
max_threads = int(dbutils.widgets.get('max_threads'))

geo_report_name = get_widget_or_none('geo_report_name')
geo_raw_event_start_date = get_widget_or_none('geo_raw_event_start_date')
geo_raw_event_end_date = get_widget_or_none('geo_raw_event_end_date')
if geo_report_name:
    geo_raw_event_start_date = datetime.strptime(geo_raw_event_start_date, '%Y-%m-%d').replace(tzinfo=timezone)
    geo_raw_event_end_date = datetime.strptime(geo_raw_event_end_date, '%Y-%m-%d').replace(tzinfo=timezone)

hourly_report_name = get_widget_or_none('hourly_report_name')
hourly_raw_event_start_date = get_widget_or_none('hourly_raw_event_start_date')
hourly_raw_event_end_date = get_widget_or_none('hourly_raw_event_end_date')
if hourly_report_name:
    hourly_raw_event_start_date = datetime.strptime(hourly_raw_event_start_date, '%Y-%m-%d').replace(tzinfo=timezone)
    hourly_raw_event_end_date = datetime.strptime(hourly_raw_event_end_date, '%Y-%m-%d').replace(tzinfo=timezone)

imps_error_report_name = get_widget_or_none('imps_error_report_name')
imps_error_raw_event_start_date = get_widget_or_none('imps_error_raw_event_start_date')
imps_error_raw_event_end_date = get_widget_or_none('imps_error_raw_event_end_date')
if imps_error_report_name:
    imps_error_raw_event_start_date = datetime.strptime(imps_error_raw_event_start_date, '%Y-%m-%d').replace(tzinfo=timezone)
    imps_error_raw_event_end_date = datetime.strptime(imps_error_raw_event_end_date, '%Y-%m-%d').replace(tzinfo=timezone)

dim_report_name = get_widget_or_none('dim_report_name')
dim_raw_event_start_date = get_widget_or_none('dim_raw_event_start_date')
dim_raw_event_end_date = get_widget_or_none('dim_raw_event_end_date')
if dim_report_name:
    dim_raw_event_start_date = datetime.strptime(dim_raw_event_start_date, '%Y-%m-%d').replace(tzinfo=timezone)
    dim_raw_event_end_date = datetime.strptime(dim_raw_event_end_date, '%Y-%m-%d').replace(tzinfo=timezone)

# COMMAND ----------

import subprocess
PROFILE  = "databricks-cpe"

subprocess.run(["aws","configure","set","region","us-west-2","--profile",PROFILE], check=True)
subprocess.run(["aws","configure","set","s3.signature_version","s3v4","--profile",PROFILE], check=True)
subprocess.run(["aws","configure","set","credential_source","Ec2InstanceMetadata","--profile",PROFILE], check=True)
subprocess.run(["aws","configure","set","role_arn",role_arn,"--profile",PROFILE], check=True)

# COMMAND ----------

aws_profile = f'databricks-cpe'
APPLICATION_NAME = 'AdSales - GAM Data Ingestion'
NETWORK_CODE = 4145
spark.conf.set("spark.sql.session.timeZone", "UTC")

# COMMAND ----------

def get_ad_manager_client(secret_arn: str) -> Any:
    session = boto3.Session(profile_name=aws_profile)
    print("Starting AWS Secret Retrieval Process")
    resp = session.client('secretsmanager').get_secret_value(SecretId=secret_arn)
    secret = json.loads(resp['SecretString'])
    print("Retrieved AWS Secret")
    with tempfile.NamedTemporaryFile(mode='w', delete=False) as secret_file:
        json.dump(secret, secret_file, indent=2)
        secret_file.close()

    oauth2_client = oauth2.GoogleServiceAccountClient(secret_file.name, oauth2.GetAPIScope('ad_manager'))
    os.unlink(secret_file.name)
    ad_manager_client = ad_manager.AdManagerClient(oauth2_client, APPLICATION_NAME, NETWORK_CODE)
    print("Created Ad Manager Client")
    return ad_manager_client

# COMMAND ----------

def format_to_datetime(date_dict: Any) -> datetime:
    return datetime(
        date_dict['date']['year'],
        date_dict['date']['month'],
        date_dict['date']['day'],
        date_dict['hour'],
        date_dict['minute'],
        date_dict['second'],
        tzinfo=pytz.timezone(date_dict['timeZoneId'])
    )

def format_datetime_to_obj(datetime_obj: Any) -> Any:
    obj = {}
    obj['year'] = datetime_obj.year
    obj['month'] = datetime_obj.month
    obj['day'] = datetime_obj.day
    return obj

def generate_processing_dates(start_date: datetime, end_date: datetime, step_size: int) -> list:
    processing_dates = []

    batch_start_date = start_date
    while batch_start_date <= end_date:
        batch_end_date = batch_start_date + timedelta(days=step_size - 1)
        if batch_end_date <= end_date:
            processing_dates.append((batch_start_date, batch_end_date))
        else:
            processing_dates.append((batch_start_date, end_date))
            break
        batch_start_date += timedelta(days=step_size)

    return processing_dates

def build_report_query(dimensions: list, columns: list, dimensionAttributes: list, start_date: datetime, end_date: datetime) -> Any:
    baseReportQuery = {
        'dimensions': [],
        'adUnitView': 'FLAT',
        'columns': [],
        'dimensionAttributes': [],
        'customFieldIds': [],
        'cmsMetadataKeyIds': [],
        'customDimensionKeyIds': [],
        'startDate': {},
        'endDate': {},
        'dateRangeType': 'CUSTOM_DATE',
        'statement': None,
        'reportCurrency': 'USD',
        'timeZoneType': 'PUBLISHER'
    }

    report_query = baseReportQuery
    report_query['dimensions'] = dimensions
    report_query['columns'] = columns
    report_query['dimensionAttributes'] = dimensionAttributes
    report_query['startDate'] = format_datetime_to_obj(start_date)
    report_query['endDate'] = format_datetime_to_obj(end_date)
    return report_query


# COMMAND ----------

def format_report(report_data: Any, report_type: str) -> Any:
    if report_type == 'Summary with Geo Impressions and Clicks (no city)':
        format_columns = {
            'Dimension.LINE_ITEM_ID': ('line_item_id', T.LongType()),
            'Dimension.LINE_ITEM_NAME': ('line_item_name', T.StringType()),
            'Dimension.DATE': ('event_date', T.DateType()),
            
            'Column.TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS': ('total_line_item_level_impressions', T.LongType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_CLICKS': ('total_line_item_level_clicks', T.LongType())
        }
        select_cols = [
            'line_item_id',
            'line_item_name',
            'event_date',
            'total_line_item_level_impressions',
            'total_line_item_level_clicks'
        ]

    elif report_type == 'Summary with Geo Impressions and Clicks':
        format_columns = {
            'Dimension.CITY_CRITERIA_ID': ('city_criteria_id', T.LongType()),
            'Dimension.LINE_ITEM_ID': ('line_item_id', T.LongType()),
            'Dimension.LINE_ITEM_NAME': ('line_item_name', T.StringType()),
            'Dimension.DATE': ('event_date', T.DateType()),
            
            'Column.TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS': ('total_line_item_level_impressions', T.LongType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_CLICKS': ('total_line_item_level_clicks', T.LongType())
        }
        select_cols = [
            'city_criteria_id',
            'line_item_id',
            'line_item_name',
            'event_date',
            'total_line_item_level_impressions',
            'total_line_item_level_clicks'
        ]
    
    elif report_type == 'Summary with Hourly Impressions and Clicks':
        format_columns = {
            'Dimension.LINE_ITEM_ID': ('line_item_id', T.LongType()),
            'Dimension.LINE_ITEM_NAME': ('line_item_name', T.StringType()),
            'Dimension.DATE': ('event_date', T.DateType()),
            'Dimension.HOUR': ('hour', T.LongType()),

            'Column.TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS': ('total_line_item_level_impressions', T.LongType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_CLICKS': ('total_line_item_level_clicks', T.LongType())
        }
        select_cols = [
            'line_item_id',
            'line_item_name',
            'event_date',
            'hour',
            'total_line_item_level_impressions',
            'total_line_item_level_clicks'
        ]
    
    elif report_type == 'Summary with Impressions and Error Count':
        format_columns = {
            'Dimension.DATE': ('event_date', T.DateType()),
            'Dimension.ADVERTISER_ID': ('advertiser_id', T.LongType()),
            'Dimension.LINE_ITEM_ID': ('line_item_id', T.LongType()),
            'Dimension.AD_UNIT_ID': ('ad_unit_id', T.LongType()),
            'Dimension.COUNTRY_CRITERIA_ID': ('country_id', T.LongType()),
            'Dimension.COUNTRY_NAME': ('country_name', T.StringType()),
            'Dimension.REQUESTED_AD_SIZES': ('requested_ad_sizes', T.StringType()),
            'Dimension.PROGRAMMATIC_CHANNEL_NAME': ('programmatic_channel_name', T.StringType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS': ('total_line_item_level_impressions', T.LongType()),
            'Column.VIDEO_ERRORS_VAST_ERROR_303_COUNT': ('video_errors_vast_error_303_count', T.LongType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_CPM_AND_CPC_REVENUE': ('total_line_item_level_cpm_and_cpc_revenue', T.LongType()),
            'Column.VIDEO_VIEWERSHIP_START': ('video_viewership_start', T.LongType()),
            'Column.VIDEO_VIEWERSHIP_COMPLETE': ('video_viewership_complete', T.LongType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_CLICKS': ('total_line_item_level_clicks', T.LongType()),
        }
        select_cols = [
            'event_date',
            'advertiser_id',
            'line_item_id',
            'ad_unit_id',
            'country_id',
            'country_name',
            'requested_ad_sizes',
            'programmatic_channel_name',
            'total_line_item_level_impressions',
            'video_errors_vast_error_303_count',
            'total_line_item_level_cpm_and_cpc_revenue',
            'video_viewership_start',
            'video_viewership_complete',
            'total_line_item_level_clicks'
        ]

    elif report_type == 'Dimensions line item level':
        format_columns = {
            'Dimension.LINE_ITEM_ID': ('line_item_id', T.LongType()),
            'Dimension.LINE_ITEM_NAME': ('line_item_name', T.StringType()),
            'Dimension.LINE_ITEM_TYPE': ('line_item_type', T.StringType()),
            'Dimension.ORDER_ID': ('order_id', T.LongType()),
            'Dimension.ORDER_NAME': ('order_name', T.StringType()),
            'Dimension.ADVERTISER_ID': ('advertiser_id', T.LongType()),
            'Dimension.ADVERTISER_NAME': ('advertiser_name', T.StringType()),
            
            'Column.TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS': ('total_line_item_level_impressions', T.LongType())
        }
        select_cols = [
            'line_item_id',
            'line_item_name',
            'line_item_type',
            'order_id',
            'order_name',
            'advertiser_id',
            'advertiser_name',
            'total_line_item_level_impressions'
        ]

    for k, v in format_columns.items():
        report_data = report_data.withColumnRenamed(k, v[0])
        report_data = report_data.withColumn(v[0], F.col(v[0]).cast(v[1]))

    report_data = report_data.select(select_cols)

    return report_data

# COMMAND ----------

spark.conf.set("spark.sql.execution.arrow.pyspark.fallback.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")

# COMMAND ----------

import concurrent.futures
import pandas as pd
from pyspark.sql import functions as F
import time

def process_batch(batch, client, gam_api_version, i, dim_list, col_list, report_name, line_item_names=None):
    start_date, end_date = batch
    print(f"Processing {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}, batch - {i}")
    report_service = client.GetService('ReportService', version=gam_api_version)
    
    report_query = build_report_query(
        dimensions=dim_list,
        columns=col_list,
        dimensionAttributes=[],
        start_date=start_date,
        end_date=end_date
    )

    if report_name == 'Summary with Geo Impressions and Clicks' and line_item_names is not None:
        placeholders = [f':lin{i}' for i in range(len(line_item_names))]
        report_query['statement'] = {
            'query': f'WHERE LINE_ITEM_NAME IN ({",".join(placeholders)})',
            'values': [
                {'key': f'lin{i}', 'value': {'xsi_type': 'TextValue', 'value': name}}
                for i, name in enumerate(line_item_names)
            ]
        }

    report_job = report_service.runReportJob({'reportQuery': report_query})

    while True:
        status = report_service.getReportJobStatus(report_job['id'])
        if status == 'COMPLETED':
            break
        elif status == 'FAILED':
            raise Exception('Report job failed')
        else:
            time.sleep(10)

    #print('Downloading...', end=' ')
    report_download_url = report_service.getReportDownloadURL(report_job['id'], 'CSV_DUMP')
    report_data = spark.createDataFrame(pd.read_csv(report_download_url, compression='gzip'))
    formatted_report = format_report(report_data, report_name)
    #print('Completed')
    return formatted_report

def run_parallel_batches(processing_dates, client, gam_api_version, dim_list, col_list, report_name, line_item_name_batches=None):
    final_df = None
    if line_item_name_batches is not None:
        #for batch_names in line_item_name_batches:
            batch=processing_dates[0]
            with concurrent.futures.ThreadPoolExecutor(max_workers=max_threads) as executor:
                futures = {
                    executor.submit(process_batch, batch, client, gam_api_version, i, dim_list, col_list, report_name, batch_names): i
                    for i, batch_names in enumerate(line_item_name_batches)
                }
                for future in concurrent.futures.as_completed(futures):
                    batch_index = futures[future]
                    try:
                        report_df = future.result()
                        if final_df is None:
                            final_df = report_df
                        else:
                            final_df = final_df.union(report_df)
                    except Exception as e:
                        print(f"Batch {batch_index} generated an exception: {e}")
    else:
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_threads) as executor:
            futures = {
                executor.submit(process_batch, batch, client, gam_api_version, i, dim_list, col_list, report_name): i
                for i, batch in enumerate(processing_dates)
            }
            for future in concurrent.futures.as_completed(futures):
                batch_index = futures[future]
                try:
                    report_df = future.result()
                    if final_df is None:
                        final_df = report_df
                    else:
                        final_df = final_df.union(report_df)
                except Exception as e:
                    print(f"Batch {batch_index} generated an exception: {e}")

    final_df = final_df.withColumn('etl_created_timestamp', F.current_timestamp()).withColumn('etl_updated_timestamp', F.current_timestamp())

    return final_df

def delta_table_write(final_df, report_name, dt=None):
    if report_name == 'Summary with Hourly Impressions and Clicks':
        tbl='gam_api_summary_with_hourly_impressions_and_clicks'
        final_df.write.format('delta')\
            .mode('overwrite')\
            .option('partitionOverwriteMode', 'dynamic')\
            .saveAsTable(f'fox_bi_{env}.raw_ads.{tbl}')

    elif report_name == 'Summary with Geo Impressions and Clicks':
        tbl='gam_api_summary_with_geo_impressions_and_clicks'
        final_df.write.format('delta')\
            .mode('overwrite')\
            .option("replaceWhere", f"event_date = '{dt}'")\
            .saveAsTable(f'fox_bi_{env}.raw_ads.{tbl}')

    elif report_name=='Summary with Impressions and Error Count':
        tbl='gam_api_summary_with_impressions_and_error_count'
        final_df.write.format('delta')\
            .mode('overwrite')\
            .option('partitionOverwriteMode', 'dynamic')\
            .saveAsTable(f'fox_bi_{env}.raw_ads.{tbl}')

    elif report_name=='Dimensions line item level':
        tbl='gam_api_dimensions_line_item_level'
        final_df.createOrReplaceTempView("gam_api_dimensions_df")
        df_sql=f'''MERGE INTO fox_bi_{env}.raw_ads.{tbl} AS target
            USING gam_api_dimensions_df AS source
            ON target.order_id = source.order_id
            AND target.line_item_id = source.line_item_id
            WHEN MATCHED THEN UPDATE SET
                target.order_id = source.order_id,
                target.order_name = source.order_name,
                target.line_item_id = source.line_item_id,
                target.line_item_name = source.line_item_name,
                target.line_item_type = source.line_item_type,
                target.advertiser_id = source.advertiser_id,
                target.advertiser_name = source.advertiser_name,
                target.etl_updated_timestamp = source.etl_updated_timestamp
            WHEN NOT MATCHED THEN INSERT *
            '''
        spark.sql(df_sql)
    

if __name__ == '__main__':

    if geo_report_name=='Summary with Geo Impressions and Clicks':
        print(f'Processing {geo_report_name}...')
        report_name = geo_report_name
        event_start_date = geo_raw_event_start_date
        event_end_date = geo_raw_event_end_date

        # Step 1: Get all line_item_name by running report without CITY_CRITERIA_ID
        dim_list_no_city = [
            'LINE_ITEM_ID',
            'LINE_ITEM_NAME',
            'DATE'
        ]
        col_list = [
            'TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS',
            'TOTAL_LINE_ITEM_LEVEL_CLICKS'
        ]
        client = get_ad_manager_client(secret_arn=gam_service_account_creds_secret_arn)
        
        processing_dates = generate_processing_dates(event_start_date, event_end_date, 1)

        print("List of dates to process: ",processing_dates)

        for date_to_process in processing_dates:
            date_to_process_list = [date_to_process]
            print(date_to_process_list)
            # Run initial report to get all line_item_name
            initial_df = run_parallel_batches(date_to_process_list, client, gam_api_version, dim_list_no_city, col_list, report_name='Summary with Geo Impressions and Clicks (no city)')
            line_item_names = [row['line_item_name'] for row in initial_df.select('line_item_name').distinct().collect()]
            print("Pulled list of line item names to process")
            print("No of line items to process: ", len(line_item_names))
            # Step 2: Batch line_item_names in chunks of given number
            no_of_line_items_to_filter = int(dbutils.widgets.get('no_of_line_items_to_filter'))
            def chunk_list(lst, n):
                for i in range(0, len(lst), n):
                    yield lst[i:i + n]
            line_item_name_batches = list(chunk_list(line_item_names, no_of_line_items_to_filter))
            print("No of batches to process: ", len(line_item_name_batches))

            # Step 3: Run report for each batch of line_item_names with CITY_CRITERIA_ID
            dim_list = [
                'CITY_CRITERIA_ID',
                'LINE_ITEM_ID',
                'LINE_ITEM_NAME',
                'DATE'
            ]
            final_df = None
            #for batch_names in line_item_name_batches:
            if True:
                print("Started processing batch of line items using multi threading")
                batch_df = run_parallel_batches(date_to_process_list, client, gam_api_version, dim_list, col_list, report_name, line_item_name_batches=line_item_name_batches)
                if final_df is None:
                    final_df = batch_df
                else:
                    final_df = final_df.union(batch_df)

                dt=date_to_process_list[0][0].strftime('%Y-%m-%d')
                print(dt)
                current_timestmap = datetime.now()
                print(f'Table loading started at: {current_timestmap}')
                delta_table_write(final_df, report_name, dt)
                print(f'Table loading completed at: {datetime.now()-current_timestmap}')
    else:
        if hourly_report_name=='Summary with Hourly Impressions and Clicks':
            print(f'Processing {hourly_report_name}...')
            report_name = hourly_report_name
            event_start_date = hourly_raw_event_start_date
            event_end_date = hourly_raw_event_end_date

            dim_list=[
                'LINE_ITEM_ID',
                'LINE_ITEM_NAME',
                'DATE',
                'HOUR'
            ]
            col_list = [
                'TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS',
                'TOTAL_LINE_ITEM_LEVEL_CLICKS'
            ]
        elif imps_error_report_name=='Summary with Impressions and Error Count':
            print(f'Processing {imps_error_report_name}...')
            report_name = imps_error_report_name
            event_start_date = imps_error_raw_event_start_date
            event_end_date = imps_error_raw_event_end_date

            dim_list=[
                'DATE',
                'ADVERTISER_ID',
                'LINE_ITEM_ID',
                'AD_UNIT_ID',
                'COUNTRY_CRITERIA_ID',
                'COUNTRY_NAME',
                'REQUESTED_AD_SIZES',
                'PROGRAMMATIC_CHANNEL_NAME'
            ]
            col_list = [
                'TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS',
                'VIDEO_ERRORS_VAST_ERROR_303_COUNT',
                'TOTAL_LINE_ITEM_LEVEL_CPM_AND_CPC_REVENUE',
                'VIDEO_VIEWERSHIP_START',
                'VIDEO_VIEWERSHIP_COMPLETE',
                'TOTAL_LINE_ITEM_LEVEL_CLICKS'
            ]
        elif dim_report_name=='Dimensions line item level':
            print(f'Processing {dim_report_name}...')
            report_name = dim_report_name
            event_start_date = dim_raw_event_start_date
            event_end_date = dim_raw_event_end_date

            dim_list=[
                'LINE_ITEM_ID',
                'LINE_ITEM_NAME',
                'LINE_ITEM_TYPE',
                'ORDER_ID',
                'ORDER_NAME',
                'ADVERTISER_ID',
                'ADVERTISER_NAME'
            ]
            col_list = [
                'TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS'
            ]
        client = get_ad_manager_client(secret_arn=gam_service_account_creds_secret_arn)

        if report_name=='Dimensions line item level':
            batch=(event_start_date, event_end_date)
            final_df = process_batch(batch, client, gam_api_version, 0, dim_list, col_list, report_name)
            final_df = final_df.withColumn('etl_created_timestamp', F.current_timestamp()).withColumn('etl_updated_timestamp', F.current_timestamp())
        else:
            processing_dates = generate_processing_dates(event_start_date, event_end_date, 1)
            print("Starting parallel processing")
            final_df = run_parallel_batches(processing_dates, client, gam_api_version, dim_list, col_list, report_name)

        current_timestmap = datetime.now()
        print(f'Table loading started at: {current_timestmap}')
        delta_table_write(final_df, report_name)
        print(f'Table loading completed at: {datetime.now()-current_timestmap}')
