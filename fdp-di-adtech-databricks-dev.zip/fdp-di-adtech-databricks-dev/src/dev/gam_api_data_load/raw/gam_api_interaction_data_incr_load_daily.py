# Databricks notebook source
# MAGIC %sh
# MAGIC aws configure set region us-west-2 --profile databricks-cpe-dev
# MAGIC aws configure set s3.signature_version s3v4 --profile databricks-cpe-dev
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile databricks-cpe-dev
# MAGIC aws configure set role_arn arn:aws:iam::393000359662:role/data-infra-astro-bi-adtech-dev --profile databricks-cpe-dev

# COMMAND ----------

from googleads import ad_manager, oauth2, errors
import boto3
import os
from typing import Any
import json
import tempfile
from datetime import datetime, timedelta
import pytz
import time
import pandas as pd
from pyspark.sql import SparkSession
import pyspark.sql.types as T
import pyspark.sql.functions as F
from pyspark import SparkFiles
from concurrent.futures import ThreadPoolExecutor, as_completed

# COMMAND ----------

global aws_profile, APPLICATION_NAME, NETWORK_CODE
aws_profile = 'databricks-cpe-dev'
APPLICATION_NAME = 'AdSales - GAM Data Ingestion'
NETWORK_CODE = 4145
spark = SparkSession.builder.appName('GAM Report Data Load').getOrCreate()
spark.conf.set("spark.sql.session.timeZone", "UTC")

# COMMAND ----------

def get_ad_manager_client(secret_arn: str) -> Any:
    session = boto3.Session(profile_name=aws_profile)
    resp = session.client('secretsmanager').get_secret_value(SecretId=secret_arn)
    secret = json.loads(resp['SecretString'])

    with tempfile.NamedTemporaryFile(mode='w', delete=False) as secret_file:
        json.dump(secret, secret_file, indent=2)
        secret_file.close()

    oauth2_client = oauth2.GoogleServiceAccountClient(secret_file.name, oauth2.GetAPIScope('ad_manager'))
    os.unlink(secret_file.name)
    ad_manager_client = ad_manager.AdManagerClient(oauth2_client, APPLICATION_NAME, NETWORK_CODE)

    return ad_manager_client

# COMMAND ----------

def format_to_datetime(date_dict: Any) -> datetime:
    return datetime(
        date_dict['date']['year'],
        date_dict['date']['month'],
        date_dict['date']['day'],
        date_dict['hour'],
        date_dict['minute'],
        date_dict['second'],
        tzinfo=pytz.timezone(date_dict['timeZoneId'])
    )

def format_datetime_to_obj(datetime_obj: Any) -> Any:
    obj = {}
    obj['year'] = datetime_obj.year
    obj['month'] = datetime_obj.month
    obj['day'] = datetime_obj.day
    return obj

def generate_processing_dates(start_date: datetime, end_date: datetime, step_size: int) -> list:
    processing_dates = []

    batch_start_date = start_date
    while batch_start_date <= end_date:
        batch_end_date = batch_start_date + timedelta(days=step_size - 1)
        if batch_end_date <= end_date:
            processing_dates.append((batch_start_date, batch_end_date))
        else:
            processing_dates.append((batch_start_date, end_date))
            break
        batch_start_date += timedelta(days=step_size)

    return processing_dates

def build_report_query(dimensions: list, columns: list, dimensionAttributes: list, start_date: datetime, end_date: datetime) -> Any:
    baseReportQuery = {
        'dimensions': [],
        'adUnitView': 'FLAT',
        'columns': [],
        'dimensionAttributes': [],
        'customFieldIds': [],
        'cmsMetadataKeyIds': [],
        'customDimensionKeyIds': [],
        'startDate': {},
        'endDate': {},
        'dateRangeType': 'CUSTOM_DATE',
        'statement': None,
        'reportCurrency': 'USD',
        'timeZoneType': 'PUBLISHER'
    }

    report_query = baseReportQuery
    report_query['dimensions'] = dimensions
    report_query['columns'] = columns
    report_query['dimensionAttributes'] = dimensionAttributes
    report_query['startDate'] = format_datetime_to_obj(start_date)
    report_query['endDate'] = format_datetime_to_obj(end_date)
    return report_query


# COMMAND ----------

def format_report(report_data: Any, report_type: str) -> Any:
    if report_type == 'Summary with Interactions and Viewership':
        format_columns = {
            'Dimension.DATE': ('event_date', T.DateType()),
            'Dimension.ADVERTISER_ID': ('advertiser_id', T.LongType()),
            'Dimension.LINE_ITEM_ID': ('line_item_id', T.LongType()),
            'Dimension.AD_UNIT_ID': ('ad_unit_id', T.LongType()),
            'Dimension.COUNTRY_CRITERIA_ID': ('country_id', T.LongType()),
            'Dimension.COUNTRY_NAME': ('country_name', T.StringType()),
            'Dimension.REQUESTED_AD_SIZES': ('requested_ad_sizes', T.StringType()),
            'Dimension.PROGRAMMATIC_CHANNEL_NAME': ('programmatic_channel_name', T.StringType()),
            'Column.VIDEO_INTERACTION_PAUSE': ('video_interaction_pause', T.LongType()),
            'Column.VIDEO_INTERACTION_RESUME': ('video_interaction_resume', T.LongType()),
            'Column.VIDEO_INTERACTION_REWIND': ('video_interaction_rewind', T.LongType()),
            'Column.VIDEO_INTERACTION_MUTE': ('video_interaction_mute', T.LongType()),
            'Column.VIDEO_INTERACTION_UNMUTE': ('video_interaction_unmute', T.LongType()),
            'Column.VIDEO_INTERACTION_FULL_SCREEN': ('video_interaction_full_screen', T.LongType()),
            'Column.AD_EXCHANGE_ACTIVE_VIEW_VIEWABLE_IMPRESSIONS': ('ad_exchange_active_view_viewable_impressions', T.LongType()),
            'Column.AD_EXCHANGE_ACTIVE_VIEW_MEASURABLE_IMPRESSIONS': ('ad_exchange_active_view_measurable_impressions', T.LongType()),
            'Column.VIDEO_VIEWERSHIP_FIRST_QUARTILE': ('video_viewership_first_quartile', T.LongType()),
            'Column.VIDEO_VIEWERSHIP_MIDPOINT': ('video_viewership_midpoint', T.LongType()),
            'Column.VIDEO_VIEWERSHIP_THIRD_QUARTILE': ('video_viewership_third_quartile', T.LongType()),
        }
        select_cols = [
            'event_date',
            'advertiser_id',
            'line_item_id',
            'ad_unit_id',
            'country_id',
            'country_name',
            'requested_ad_sizes',
            'programmatic_channel_name',
            'video_interaction_pause',
            'video_interaction_resume',
            'video_interaction_rewind',
            'video_interaction_mute',
            'video_interaction_unmute',
            'video_interaction_full_screen',
            'ad_exchange_active_view_viewable_impressions',
            'ad_exchange_active_view_measurable_impressions',
            'video_viewership_first_quartile',
            'video_viewership_midpoint',
            'video_viewership_third_quartile'
        ]
    
    if report_type == 'Summary with Code Served':
        format_columns = {
            'Dimension.DATE': ('event_date', T.DateType()),
            'Dimension.ADVERTISER_ID': ('advertiser_id', T.LongType()),
            'Dimension.LINE_ITEM_ID': ('line_item_id', T.LongType()),
            'Dimension.AD_UNIT_ID': ('ad_unit_id', T.LongType()),
            'Dimension.COUNTRY_CRITERIA_ID': ('country_id', T.LongType()),
            'Dimension.COUNTRY_NAME': ('country_name', T.StringType()),
            'Dimension.REQUESTED_AD_SIZES': ('requested_ad_sizes', T.StringType()),
            'Dimension.PROGRAMMATIC_CHANNEL_NAME': ('programmatic_channel_name', T.StringType()),
            'Column.TOTAL_CODE_SERVED_COUNT': ('total_code_served_count', T.LongType()),  
        }
        select_cols = [
            'event_date',
            'advertiser_id',
            'line_item_id',
            'ad_unit_id',
            'country_id',
            'country_name',
            'requested_ad_sizes',
            'programmatic_channel_name',
            'total_code_served_count'
        ]

    for k, v in format_columns.items():
        report_data = report_data.withColumnRenamed(k, v[0])
        report_data = report_data.withColumn(v[0], F.col(v[0]).cast(v[1]))

    report_data = report_data.select(select_cols)

    return report_data

def download_report(job):

    downloader = client.GetDataDownloader(version=gam_api_version)
    local_path = f"/dbfs/tmp/gam_report_batch_{job['batch_no']}.csv.gz"
    print(f"Downloading Batch {job['batch_no']} "
        f"({job['start_date']:%Y-%m-%d} -> {job['end_date']:%Y-%m-%d})")

    with open(local_path, "wb") as f:
        downloader.DownloadReportToFile(job["job_id"],"CSV_DUMP",f)

    return local_path

# COMMAND ----------

if __name__ == '__main__':
    gam_service_account_creds_secret_arn = dbutils.widgets.get('gam_service_account_creds_secret_arn')
    gam_api_version = dbutils.widgets.get('gam_api_version')

    client = get_ad_manager_client(secret_arn=gam_service_account_creds_secret_arn)
    timezone = pytz.timezone("UTC")
    event_start_date = datetime.strptime(dbutils.widgets.get('event_start_date'), '%Y-%m-%d').replace(tzinfo=timezone)
    event_end_date = datetime.strptime(dbutils.widgets.get('event_end_date'), '%Y-%m-%d').replace(tzinfo=timezone)

    process_days = (event_end_date-event_start_date).days
    processing_dates = generate_processing_dates(event_start_date, event_end_date, 1)

    # Summary with Interactions and Viewership
    print('Summary with Interactions and Viewership')
    jobs = []
    final_df = None
    for i, batch in enumerate(processing_dates):
        start_date, end_date = batch
        #print(f"Processing {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}, batch - {i}", end=' ')
        print(f"Submitting Batch {i}: {start_date:%Y-%m-%d} -> {end_date:%Y-%m-%d}")
        report_service = client.GetService('ReportService', version=gam_api_version)
        data_downloader  = client.GetDataDownloader(version=gam_api_version)
        report_query = build_report_query(
            dimensions = [
                'DATE',
                'ADVERTISER_ID',
                'LINE_ITEM_ID',
                'AD_UNIT_ID',
                'COUNTRY_CRITERIA_ID',
                'COUNTRY_NAME',
                'REQUESTED_AD_SIZES',
                'PROGRAMMATIC_CHANNEL_NAME'
            ],
            columns = [
                'VIDEO_INTERACTION_PAUSE',
                'VIDEO_INTERACTION_RESUME',
                'VIDEO_INTERACTION_REWIND',
                'VIDEO_INTERACTION_MUTE',
                'VIDEO_INTERACTION_UNMUTE',
                'VIDEO_INTERACTION_FULL_SCREEN',
                'AD_EXCHANGE_ACTIVE_VIEW_VIEWABLE_IMPRESSIONS',
                'AD_EXCHANGE_ACTIVE_VIEW_MEASURABLE_IMPRESSIONS',
                'VIDEO_VIEWERSHIP_FIRST_QUARTILE',
                'VIDEO_VIEWERSHIP_MIDPOINT',
                'VIDEO_VIEWERSHIP_THIRD_QUARTILE'
            ],
            dimensionAttributes = [],
            start_date = start_date,
            end_date = end_date
        )
        report_job = report_service.runReportJob({'reportQuery': report_query})
        
        jobs.append({
        "batch_no": i,
        "job_id": report_job["id"],
        "start_date": start_date,
        "end_date": end_date,
        "status": "IN_PROGRESS"
            })

    
    while True:

        completed = 0
        for job in jobs:

            if job["status"] == "COMPLETED":
                completed += 1
                continue
            if job["status"] == "FAILED":
                continue

            status = report_service.getReportJobStatus(job["job_id"])

            if status == "COMPLETED":
                job["status"] = "COMPLETED"
                completed += 1
                print(f"Batch {job['batch_no']} completed")
            elif status == "FAILED":
                job["status"] = "FAILED"
                print(f"Batch {job['batch_no']} FAILED")

        if completed == len(jobs):
            break

        time.sleep(30)

    print("All reports generated.")

    with ThreadPoolExecutor(max_workers=4) as executor:

        future_to_job = {executor.submit(download_report, job): job for job in jobs}

        for future in as_completed(future_to_job):
            job = future_to_job[future]
            local_path = future.result()
            job["file_path"] = local_path
            print(f"\nBatch {job['batch_no']} download completed")


    for job in jobs:

        print(f"Reading Batch {job['batch_no']}")
        report_data = spark.read.option("header", "true").option("inferSchema", "true").option("nullValue", "-").csv(f"dbfs:/tmp/gam_report_batch_{job['batch_no']}.csv.gz")
        formatted_df = format_report(report_data,"Summary with Interactions and Viewership")

        if final_df is None:
            final_df = formatted_df
        else:
            final_df = final_df.unionByName(formatted_df)

        print("Completed")

    final_df = final_df.withColumn('etl_created_timestamp', F.current_timestamp()).withColumn('etl_updated_timestamp', F.current_timestamp())

    final_df.write.format('delta')\
        .mode('overwrite')\
        .option('partitionOverwriteMode', 'dynamic')\
        .option("mergeSchema", "true")\
        .saveAsTable('fox_bi_dev.raw_ads.gam_api_summary_with_intractions_and_viewership')


    print('Summary with Code Served')
    jobs = []
    final_df = None
    for i, batch in enumerate(processing_dates):
        start_date, end_date = batch
        #print(f"Processing {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}, batch - {i}", end=' ')
        print(f"Submitting Batch {i}: {start_date:%Y-%m-%d} -> {end_date:%Y-%m-%d}")
        report_service = client.GetService('ReportService', version=gam_api_version)
        data_downloader  = client.GetDataDownloader(version=gam_api_version)
        report_query = build_report_query(
            dimensions = [
                'DATE',
                'ADVERTISER_ID',
                'LINE_ITEM_ID',
                'AD_UNIT_ID',
                'COUNTRY_CRITERIA_ID',
                'COUNTRY_NAME',
                'REQUESTED_AD_SIZES',
                'PROGRAMMATIC_CHANNEL_NAME'
            ],
            columns = [
                 'TOTAL_CODE_SERVED_COUNT'
            ],
            dimensionAttributes = [],
            start_date = start_date,
            end_date = end_date
        )
        report_job = report_service.runReportJob({'reportQuery': report_query})
        
        jobs.append({
        "batch_no": i,
        "job_id": report_job["id"],
        "start_date": start_date,
        "end_date": end_date,
        "status": "IN_PROGRESS"
            })

    while True:

        completed = 0
        for job in jobs:

            if job["status"] == "COMPLETED":
                completed += 1
                continue
            if job["status"] == "FAILED":
                continue

            status = report_service.getReportJobStatus(job["job_id"])

            if status == "COMPLETED":
                job["status"] = "COMPLETED"
                completed += 1
                print(f"Batch {job['batch_no']} completed")
            elif status == "FAILED":
                job["status"] = "FAILED"
                print(f"Batch {job['batch_no']} FAILED")

        if completed == len(jobs):
            break

        time.sleep(30)

    print("All reports generated.")

    with ThreadPoolExecutor(max_workers=4) as executor:

        future_to_job = {executor.submit(download_report, job): job for job in jobs}
        for future in as_completed(future_to_job):
            job = future_to_job[future]
            local_path = future.result()
            job["file_path"] = local_path
            print(f"\nBatch {job['batch_no']} download completed")

    for job in jobs:

        print(f"Reading Batch {job['batch_no']}")
        report_data = spark.read.option("header", "true").option("inferSchema", "true").option("nullValue", "-").csv(f"dbfs:/tmp/gam_report_batch_{job['batch_no']}.csv.gz")
        formatted_df = format_report(report_data,"Summary with Code Served")

        if final_df is None:
            final_df = formatted_df
        else:
            final_df = final_df.unionByName(formatted_df)

        print("Completed")


    final_df = final_df.withColumn('etl_created_timestamp', F.current_timestamp()).withColumn('etl_updated_timestamp', F.current_timestamp())

    final_df.write.format('delta')\
        .mode('overwrite')\
        .option('partitionOverwriteMode', 'dynamic')\
        .option("mergeSchema", "true")\
        .saveAsTable('fox_bi_dev.raw_ads.gam_api_summary_with_code_served')