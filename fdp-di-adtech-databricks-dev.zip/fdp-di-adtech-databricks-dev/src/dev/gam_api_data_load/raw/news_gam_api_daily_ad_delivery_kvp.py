# Databricks notebook source
from concurrent.futures import ThreadPoolExecutor, as_completed
from googleads import ad_manager, oauth2, errors
import boto3
import os
import sys
from typing import Any
import json
import tempfile
from datetime import datetime, timedelta
import pytz
import time
import pandas as pd
from pyspark.sql import SparkSession
import pyspark.sql.types as T
import pyspark.sql.functions as F
from pyspark import SparkFiles

# COMMAND ----------

# dbutils.widgets.text("aws_profile", "")
# dbutils.widgets.text("aws_arn", "")
dbutils.widgets.text("env", "")
dbutils.widgets.text("gam_service_account_creds_secret_arn", "")
dbutils.widgets.text("gam_api_version", "")
dbutils.widgets.text("event_start_date", "")
dbutils.widgets.text("event_end_date", "")

# COMMAND ----------

# Load configuration values
event_start_date_param = dbutils.widgets.get("event_start_date")
event_end_date_param = dbutils.widgets.get("event_end_date")
gam_service_account_creds_secret_arn = dbutils.widgets.get('gam_service_account_creds_secret_arn')
gam_api_version = dbutils.widgets.get('gam_api_version')
# aws_profile=  dbutils.widgets.get('aws_profile')
# aws_arn=  dbutils.widgets.get('aws_arn')

# COMMAND ----------

# MAGIC %sh
# MAGIC aws configure set region us-west-2 --profile databricks-cpe-dev
# MAGIC aws configure set s3.signature_version s3v4 --profile databricks-cpe-dev
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile databricks-cpe-dev
# MAGIC aws configure set role_arn arn:aws:iam::393000359662:role/data-infra-astro-bi-adtech-dev --profile databricks-cpe-dev

# COMMAND ----------

global aws_profile, NETWORK_CODE
aws_profile = "databricks-cpe-dev"
APPLICATION_NAME='News - GAM Data'
NETWORK_CODE = 4145
spark.conf.set("spark.sql.session.timeZone", "UTC")

# COMMAND ----------

catalog='fox_bi_dev'
raw_schema='raw_ads'
silver_schema='silver_ads'

# COMMAND ----------

def get_ad_manager_client(secret_arn: str) -> Any:
    session = boto3.Session(profile_name=aws_profile)
    resp = session.client('secretsmanager').get_secret_value(SecretId=secret_arn)
    #print(resp)
    secret = json.loads(resp['SecretString'])

    with tempfile.NamedTemporaryFile(mode='w', delete=False) as secret_file:
        json.dump(secret, secret_file, indent=2)
        secret_file.close()

    oauth2_client = oauth2.GoogleServiceAccountClient(secret_file.name, oauth2.GetAPIScope('ad_manager'))
    os.unlink(secret_file.name)
    ad_manager_client = ad_manager.AdManagerClient(oauth2_client, APPLICATION_NAME, NETWORK_CODE)

    return ad_manager_client

# COMMAND ----------

def format_to_datetime(date_dict: Any) -> datetime:
    return datetime(
        date_dict['date']['year'],
        date_dict['date']['month'],
        date_dict['date']['day'],
        date_dict['hour'],
        date_dict['minute'],
        date_dict['second'],
        tzinfo=pytz.timezone(date_dict['timeZoneId'])
    )

def format_datetime_to_obj(datetime_obj: Any) -> Any:
    obj = {}
    obj['year'] = datetime_obj.year
    obj['month'] = datetime_obj.month
    obj['day'] = datetime_obj.day
    return obj

def generate_processing_dates(start_date: datetime, end_date: datetime, step_size: int) -> list:
    processing_dates = []

    batch_start_date = start_date
    while batch_start_date <= end_date:
        batch_end_date = batch_start_date + timedelta(days=step_size - 1)
        if batch_end_date <= end_date:
            processing_dates.append((batch_start_date, batch_end_date))
        else:
            processing_dates.append((batch_start_date, end_date))
            break
        batch_start_date += timedelta(days=step_size)

    return processing_dates

def build_report_query(dimensions: list, columns: list, dimensionAttributes: list, start_date: datetime, end_date: datetime) -> Any:
    baseReportQuery = {
        'dimensions': [],
        'adUnitView': 'FLAT',
        'columns': [],
        'dimensionAttributes': [],
        'customFieldIds': [],
        'cmsMetadataKeyIds': [],
        'customDimensionKeyIds': [],
        'startDate': {},
        'endDate': {},
        'dateRangeType': 'CUSTOM_DATE',
        'statement': None,
        'reportCurrency': 'USD',
        'timeZoneType': 'PUBLISHER'
    }

    report_query = baseReportQuery
    report_query['dimensions'] = dimensions
    report_query['columns'] = columns
    report_query['dimensionAttributes'] = dimensionAttributes
    report_query['startDate'] = format_datetime_to_obj(start_date)
    report_query['endDate'] = format_datetime_to_obj(end_date)
    return report_query


# COMMAND ----------

value_lookup = {}
# required_keys = {'c', 'people', 'app_version', 'categories', 'url'}
client = get_ad_manager_client(secret_arn=gam_service_account_creds_secret_arn)
custom_targeting_service = client.GetService('CustomTargetingService', version=gam_api_version)
key_statement = ad_manager.StatementBuilder(version='v202405')
key_response = custom_targeting_service.getCustomTargetingKeysByStatement(key_statement.ToStatement())
for key in key_response.results:
    key_id = key.id
    key_name = key.name
    
    # # Skip unwanted keys
    # if key_name not in required_keys:
    #     continue
    # Step 2: Fetch values under each key
    value_statement = (
        ad_manager.StatementBuilder(version='v202602')
        .Where('customTargetingKeyId = :key_id')
        .WithBindVariable('key_id', key_id)
    )

    while True:
        value_response = custom_targeting_service.getCustomTargetingValuesByStatement(value_statement.ToStatement())

        if hasattr(value_response, 'results') and value_response.results:
            for value in value_response.results:
                value_lookup[value.id] = {
                    'key_name': key_name,
                    'key_id': key_id,
                    'value_name': value.name
                }

        if not value_response.totalResultSetSize or value_statement.offset + value_statement.limit >= value_response.totalResultSetSize:
            break
        else:
            value_statement.offset += value_statement.limit

print(f"\n✅ Total mapping entries collected: {(value_lookup)}")

# COMMAND ----------

def resolve_targeting(val_id):
    entry = value_lookup.get(val_id)
    if entry:
        return pd.Series([entry['key_name'], entry['value_name']])
    else:
        return pd.Series(['UNKNOWN', 'UNKNOWN'])

# COMMAND ----------

def format_report(report_data: Any, report_type: str) -> Any:
    if report_type == 'Summary with Impressions,Viewability and KVP':
        format_columns = {
    'Dimension.DATE': ('event_date', T.DateType()),
    'Dimension.AD_UNIT_ID': ('ad_unit_id', T.LongType()),
    'Dimension.CUSTOM_TARGETING_VALUE_ID': ('custom_targeting_value_id', T.LongType()),

    'Column.TOTAL_ACTIVE_VIEW_MEASURABLE_IMPRESSIONS': ('total_active_view_measurable_impressions', T.LongType()),
    'Column.TOTAL_ACTIVE_VIEW_VIEWABLE_IMPRESSIONS': ('total_active_view_viewable_impressions', T.LongType()),
    'Column.TOTAL_ACTIVE_VIEW_ELIGIBLE_IMPRESSIONS': ('total_active_view_eligible_impressions', T.LongType()),
    'Column.TOTAL_LINE_ITEM_LEVEL_CLICKS': ('total_line_item_level_clicks', T.LongType()),
    'Column.AD_EXCHANGE_ACTIVE_VIEW_MEASURABLE_IMPRESSIONS': ('ad_exchange_active_view_measurable_impressions', T.LongType()),
    'Column.AD_EXCHANGE_ACTIVE_VIEW_VIEWABLE_IMPRESSIONS': ('ad_exchange_active_view_viewable_impressions', T.LongType()),
    'Column.AD_EXCHANGE_ACTIVE_VIEW_ELIGIBLE_IMPRESSIONS': ('ad_exchange_active_view_eligible_impressions', T.LongType()),
    'Column.TOTAL_CODE_SERVED_COUNT': ('total_code_served_count', T.LongType())
}

        select_cols = [
            'event_date',
            'ad_unit_id',
            'custom_targeting_value_id',
            'targeting_key',
            'targeting_value',

            'total_active_view_measurable_impressions',
            'total_active_view_viewable_impressions',
            'total_active_view_eligible_impressions',

            'total_line_item_level_clicks',
            'ad_exchange_active_view_measurable_impressions',
            'ad_exchange_active_view_viewable_impressions',
            'ad_exchange_active_view_eligible_impressions',
            'total_code_served_count'

        ]


    for k, v in format_columns.items():
        report_data = report_data.withColumnRenamed(k, v[0])
        report_data = report_data.withColumn(v[0], F.col(v[0]).cast(v[1]))

    report_data = report_data.select(select_cols)

    return report_data

# COMMAND ----------

def process_single_batch(i, batch):
    start_date, end_date = batch
    batch_log = {
        "batch_id": i,
        "start_date": start_date.strftime('%Y-%m-%d'),
        "end_date": end_date.strftime('%Y-%m-%d'),
        "status": "STARTED",
        "duration_sec": None
    }

    print(
        f"Processing {batch_log['start_date']} "
        f"to {batch_log['end_date']}, batch - {i}"
    )

    report_service = client.GetService(
        'ReportService',
        version=gam_api_version
    )

    report_query = build_report_query(
        dimensions=[
            'DATE',
            'CUSTOM_TARGETING_VALUE_ID',
            'AD_UNIT_ID'
        ],
        columns=[
            "TOTAL_LINE_ITEM_LEVEL_CLICKS",
            "AD_EXCHANGE_ACTIVE_VIEW_MEASURABLE_IMPRESSIONS",
            "AD_EXCHANGE_ACTIVE_VIEW_VIEWABLE_IMPRESSIONS",
            "AD_EXCHANGE_ACTIVE_VIEW_ELIGIBLE_IMPRESSIONS",
            "TOTAL_ACTIVE_VIEW_VIEWABLE_IMPRESSIONS",
            "TOTAL_ACTIVE_VIEW_MEASURABLE_IMPRESSIONS",
            "TOTAL_ACTIVE_VIEW_ELIGIBLE_IMPRESSIONS",
            "TOTAL_CODE_SERVED_COUNT"
        ],
        dimensionAttributes=[],
        start_date=start_date,
        end_date=end_date
    )

    report_job = report_service.runReportJob(
        {'reportQuery': report_query}
    )

    while True:
        status = report_service.getReportJobStatus(report_job['id'])

        if status == 'COMPLETED':
            batch_log["status"] = "COMPLETED"
            break
        elif status == 'FAILED':
            batch_log["status"] = "FAILED"
            break
        else:
            time.sleep(36)

    start_time = time.time()

    print(f'Downloading... batch - {i}')

    time.sleep(36)

    report_download_url = report_service.getReportDownloadURL(
        report_job['id'],
        'CSV_DUMP'
    )

    report_data_df = pd.read_csv(
        report_download_url,
        compression='gzip'
    )

    if report_data_df.empty:
        batch_log["status"] = "EMPTY"
        return None

    report_data = spark.createDataFrame(report_data_df)

    lookup_data = [
        (k, v['key_name'], v['value_name'])
        for k, v in value_lookup.items()
    ]

    lookup_df = spark.createDataFrame(
        lookup_data,
        [
            'Dimension.CUSTOM_TARGETING_VALUE_ID',
            'TARGETING_KEY',
            'TARGETING_VALUE'
        ]
    )

    report_data = report_data.withColumn(
        'Dimension.CUSTOM_TARGETING_VALUE_ID',
        F.col(
            '`Dimension.CUSTOM_TARGETING_VALUE_ID`'
        ).cast('bigint')
    )

    report_data = report_data.join(
        lookup_df,
        on='Dimension.CUSTOM_TARGETING_VALUE_ID',
        how='left'
    )

    result_df = format_report(
        report_data,
        'Summary with Impressions,Viewability and KVP'
    )
    
    end_time = time.time()
    duration = end_time - start_time

    print(f"batch - {i} - Completed in {duration:.2f} seconds")
    batch_log["duration_sec"] = round(duration, 2)

    return result_df,batch_log

# COMMAND ----------

if __name__ == '__main__':

    timezone = pytz.timezone("UTC")

    if not event_start_date_param:
        print('no start date ')
        event_start_date = datetime.today() - timedelta(days=7)
        event_start_date = event_start_date.replace(
            hour=0,
            minute=0,
            second=0,
            microsecond=0
        )
    else:
        event_start_date = datetime.strptime(
            event_start_date_param,
            '%Y-%m-%d'
        )

    if not event_end_date_param:
        print('no end date ')
        event_end_date = datetime.today().replace(
            hour=0,
            minute=0,
            second=0,
            microsecond=0
        )
    else:
        event_end_date = datetime.strptime(
            event_end_date_param,
            '%Y-%m-%d'
        )

    event_start_date = timezone.localize(event_start_date)
    event_end_date = timezone.localize(event_end_date)

    process_days = (
        event_end_date - event_start_date
    ).days

    processing_dates = generate_processing_dates(
        event_start_date,
        event_end_date,
        1
    )

    final_df = None
    all_logs = []
    # Parallel execution
    with ThreadPoolExecutor(max_workers=3) as executor:
        futures = [
            executor.submit(
                process_single_batch,
                i,
                batch
            )
            for i, batch in enumerate(processing_dates)
        ]

        for future in as_completed(futures):
            # result = future.result()
            result, log = future.result()
            all_logs.append(log)
            if result is not None:
                if final_df is None:
                    final_df = result
                else:
                    final_df = final_df.union(result)

    if final_df is not None:
        final_df = final_df.withColumn(
            'etl_created_at_timestamp_utc',
            F.current_timestamp()
        ).withColumn(
            'etl_updated_at_timestamp_utc',
            F.current_timestamp()
        )

        final_df.write.format('delta') \
            .mode('overwrite') \
            .partitionBy('event_date') \
            .option(
                'partitionOverwriteMode',
                'dynamic'
            ) \
            .saveAsTable(
                f'{catalog}.{raw_schema}.news_gam_api_ad_delivery_and_kvp_daily'
            )

        print("Data written to final table")

    else:
        print('No data processed.')

# COMMAND ----------

if all_logs:
    log_df = pd.DataFrame(all_logs)
    display(log_df)
