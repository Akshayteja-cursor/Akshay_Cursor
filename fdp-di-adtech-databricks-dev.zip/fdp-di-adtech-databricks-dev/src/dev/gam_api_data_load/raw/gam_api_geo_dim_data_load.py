# Databricks notebook source
from datetime import datetime
#Code stops if, today is not the start of the month. else it wll load the geo dimension
if datetime.utcnow().day != 1:
  dbutils.notebook.exit("stopped early")

# COMMAND ----------

from googleads import ad_manager, oauth2, errors
import boto3
import os
from typing import Any
import json
import tempfile
from datetime import datetime, timedelta
import pytz
import time
import pandas as pd
from pyspark.sql import SparkSession
import pyspark.sql.types as T
import pyspark.sql.functions as F
from pyspark import SparkFiles

# COMMAND ----------

env = dbutils.widgets.get('env')
role_arn = dbutils.widgets.get('role_arn')
gam_service_account_creds_secret_arn=dbutils.widgets.get('gam_service_account_creds_secret_arn')
gam_api_version = 'v202508'

# COMMAND ----------

import subprocess
PROFILE  = "databricks-cpe"

subprocess.run(["aws","configure","set","region","us-west-2","--profile",PROFILE], check=True)
subprocess.run(["aws","configure","set","s3.signature_version","s3v4","--profile",PROFILE], check=True)
subprocess.run(["aws","configure","set","credential_source","Ec2InstanceMetadata","--profile",PROFILE], check=True)
subprocess.run(["aws","configure","set","role_arn",role_arn,"--profile",PROFILE], check=True)

# COMMAND ----------

global aws_profile, APPLICATION_NAME, NETWORK_CODE
aws_profile = 'databricks-cpe'
APPLICATION_NAME = 'AdSales - GAM Data Ingestion'
NETWORK_CODE = 4145
spark = SparkSession.builder.appName('GAM Report Data Load').getOrCreate()
spark.conf.set("spark.sql.session.timeZone", "UTC")

# COMMAND ----------

def get_ad_manager_client(secret_arn: str) -> Any:
    session = boto3.Session(profile_name=aws_profile)
    resp = session.client('secretsmanager').get_secret_value(SecretId=secret_arn)
    secret = json.loads(resp['SecretString'])

    with tempfile.NamedTemporaryFile(mode='w', delete=False) as secret_file:
        json.dump(secret, secret_file, indent=2)
        secret_file.close()

    oauth2_client = oauth2.GoogleServiceAccountClient(secret_file.name, oauth2.GetAPIScope('ad_manager'))
    os.unlink(secret_file.name)
    ad_manager_client = ad_manager.AdManagerClient(oauth2_client, APPLICATION_NAME, NETWORK_CODE)

    return ad_manager_client

# COMMAND ----------

spark.conf.set("spark.sql.execution.arrow.pyspark.fallback.enabled", "true")
spark.conf.set("spark.sql.adaptive.enabled", "true")

# COMMAND ----------

if __name__ == '__main__':
    # PublisherQueryLanguageService
    client = get_ad_manager_client(secret_arn=gam_service_account_creds_secret_arn)
    statement = ad_manager.StatementBuilder(version=gam_api_version)\
                .Select('ID, CountryCode, Name, Type, CanonicalParentId, ParentIds')\
                .From('Geo_Target')\
                .Limit(1000000)\

    pql_service = client.GetService('PublisherQueryLanguageService', version=gam_api_version)
    print(pql_service)
    batch_number = 0
    if True:
        response = pql_service.select(statement.ToStatement())
        res_dict={}
        for i in response['columnTypes']:
          col=(i['labelName'])
          res_dict[col]=[]

        for i in response['rows']:
          k=0
          for j in i['values']:
            res_dict[list(res_dict.keys())[k]].append(j['value'])
            k+=1
        res_df=spark.createDataFrame(pd.DataFrame(res_dict))

# COMMAND ----------

from pyspark.sql.window import Window

# Filter for CITY and NEIGHBORHOOD rows
# city_df = res_df.filter(F.col('Type') == 'CITY')
# neighborhood_df = res_df.filter(F.col('Type') == 'NEIGHBORHOOD')

# Prepare a lookup dictionary for id -> row as Pandas for iterative join
lookup_df = res_df.select('ID', 'CanonicalParentId', 'Type', 'Name').toPandas()
id_map = lookup_df.set_index('ID').to_dict('index')

def trace_hierarchy(row):
    result = { 'NEIGHBORHOOD':None, 'CITY': None, 'STATE': None, 'PROVINCE':None, 'REGION':None, 'UNION_TERRITORY':None, 'COUNTRY': None, 'NEIGHBORHOOD_ID':None,'CITY_ID': None, 'STATE_ID': None,'PROVINCE_ID':None, 'REGION_ID':None, 'UNION_TERRITORY_ID':None, 'COUNTRY_ID': None}
    current_id = row['ID']
    current_type = row['Type']
    if current_type == 'CITY':
        result['CITY'] = row['Name']
        result['CITY_ID'] = current_id
    elif current_type == 'NEIGHBORHOOD':
        result['NEIGHBORHOOD'] = row['Name']
        result['NEIGHBORHOOD_ID'] = current_id
    parent_id = row['CanonicalParentId']
    while parent_id is not None and parent_id in id_map:
        parent_row = id_map[parent_id]
        parent_type = parent_row['Type']
        if parent_type == 'PROVINCE' and result['PROVINCE'] is None:
            result['PROVINCE'] = parent_row['Name']
            result['PROVINCE_ID'] = parent_id
        elif parent_type == 'REGION' and result['REGION'] is None:
            result['REGION'] = parent_row['Name']
            result['REGION_ID'] = parent_id
        elif parent_type == 'STATE' and result['STATE'] is None:
            result['STATE'] = parent_row['Name']
            result['STATE_ID'] = parent_id
        elif parent_type == 'UNION_TERRITORY' and result['UNION_TERRITORY'] is None:
            result['UNION_TERRITORY'] = parent_row['Name']
            result['UNION_TERRITORY_ID'] = parent_id
        elif parent_type == 'COUNTRY' and result['COUNTRY'] is None:
            result['COUNTRY'] = parent_row['Name']
            result['COUNTRY_ID'] = parent_id
        parent_id = parent_row['CanonicalParentId']
    return pd.Series(result)

# Apply the hierarchy tracing for CITY and NEIGHBORHOOD base
# city_pd = city_df.select('ID', 'Name', 'CanonicalParentId', 'Type').toPandas()
# city_hierarchy_df = city_pd.apply(trace_hierarchy, axis=1)
# final_city_df = pd.concat([city_pd, city_hierarchy_df], axis=1)
# final_city_spark_df = spark.createDataFrame(final_city_df)

# neighborhood_pd = neighborhood_df.select('ID', 'Name', 'CanonicalParentId', 'Type').toPandas()
# neighborhood_hierarchy_df = neighborhood_pd.apply(trace_hierarchy, axis=1)
# final_neighborhood_df = pd.concat([neighborhood_pd, neighborhood_hierarchy_df], axis=1)
# final_neighborhood_spark_df = spark.createDataFrame(final_neighborhood_df)

# county_pd = county_df.select('ID', 'Name', 'CanonicalParentId', 'Type').toPandas()
# county_hierarchy_df = county_pd.apply(trace_hierarchy, axis=1)
# final_county_df = pd.concat([county_pd, county_hierarchy_df], axis=1)
# final_county_spark_df = spark.createDataFrame(final_county_df)


# final_city_neighborhood_df =  final_city_spark_df.unionAll(final_neighborhood_spark_df)
# final_city_neighborhood_df = final_city_neighborhood_df.unionAll(final_county_spark_df)

final_df = res_df.select('ID', 'Name', 'CanonicalParentId', 'Type').toPandas()
city_hierarchy_df = final_df.apply(trace_hierarchy, axis=1)
final_result_df = pd.concat([final_df, city_hierarchy_df], axis=1)
final_result_spark_df = spark.createDataFrame(final_result_df)

# COMMAND ----------

result_df = final_result_spark_df.select('id','city_id','neighborhood_id', 'state_id', 'province_id', 'region_id', 'union_territory_id', 'country_id', 'type', 'city', 'neighborhood', 'state', 'province', 'region', 'union_territory', 'country',F.current_timestamp().alias('etl_created_timestamp'),F.current_timestamp().alias('etl_updated_timestamp'))

result_df.write.format('delta')\
        .mode('overwrite')\
        .saveAsTable(f'fox_bi_{env}.raw_ads.gam_api_geo_data')
