# Databricks notebook source
# MAGIC %sh
# MAGIC aws configure set region us-west-2 --profile databricks-cpe-dev
# MAGIC aws configure set s3.signature_version s3v4 --profile databricks-cpe-dev
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile databricks-cpe-dev
# MAGIC aws configure set role_arn arn:aws:iam::393000359662:role/data-infra-astro-bi-adtech-dev --profile databricks-cpe-dev

# COMMAND ----------

from googleads import ad_manager, oauth2, errors
import boto3
import os
from typing import Any
import json
import tempfile
from datetime import datetime, timedelta
import pytz
import time
import pandas as pd
from pyspark.sql import SparkSession
import pyspark.sql.types as T
import pyspark.sql.functions as F
from pyspark import SparkFiles

# COMMAND ----------

global aws_profile, APPLICATION_NAME, NETWORK_CODE
aws_profile = 'databricks-cpe-dev'
APPLICATION_NAME = 'AdSales - GAM Dimension Ingestion'
NETWORK_CODE = 4145
spark = SparkSession.builder.appName('GAM Match Table Load').getOrCreate()
spark.conf.set("spark.sql.session.timeZone", "UTC")

# COMMAND ----------

def get_ad_manager_client(secret_arn: str) -> Any:
    session = boto3.Session(profile_name=aws_profile)
    resp = session.client('secretsmanager').get_secret_value(SecretId=secret_arn)
    secret = json.loads(resp['SecretString'])

    with tempfile.NamedTemporaryFile(mode='w', delete=False) as secret_file:
        json.dump(secret, secret_file, indent=2)
        secret_file.close()

    oauth2_client = oauth2.GoogleServiceAccountClient(secret_file.name, oauth2.GetAPIScope('ad_manager'))
    os.unlink(secret_file.name)
    ad_manager_client = ad_manager.AdManagerClient(oauth2_client, APPLICATION_NAME, NETWORK_CODE)

    return ad_manager_client

# COMMAND ----------

def format_to_datetime(date_dict: Any) -> datetime:
    return datetime(
        date_dict['date']['year'],
        date_dict['date']['month'],
        date_dict['date']['day'],
        date_dict['hour'],
        date_dict['minute'],
        date_dict['second'],
        tzinfo=pytz.timezone(date_dict['timeZoneId'])
    )

def format_datetime_to_obj(datetime_obj: Any) -> Any:
    obj = {}
    obj['year'] = datetime_obj.year
    obj['month'] = datetime_obj.month
    obj['day'] = datetime_obj.day
    return obj

def build_report_query(dimensions: list, columns: list, dimensionAttributes: list, start_date: datetime, end_date: datetime) -> Any:
    baseReportQuery = {
        'dimensions': [],
        'adUnitView': 'FLAT',
        'columns': [],
        'dimensionAttributes': [],
        'customFieldIds': [],
        'cmsMetadataKeyIds': [],
        'customDimensionKeyIds': [],
        'startDate': {},
        'endDate': {},
        'dateRangeType': 'CUSTOM_DATE',
        'statement': None,
        'reportCurrency': 'USD',
        'timeZoneType': 'PUBLISHER'
    }

    report_query = baseReportQuery
    report_query['dimensions'] = dimensions
    report_query['columns'] = columns
    report_query['dimensionAttributes'] = dimensionAttributes
    report_query['startDate'] = format_datetime_to_obj(start_date)
    report_query['endDate'] = format_datetime_to_obj(end_date)
    return report_query


# COMMAND ----------

def format_ad_unit(response: Any) -> Any:
    if 'results' in response and len(response['results']):
        inventory = response['results']
        inventory_data = []

        for item in inventory:
            if len(item['parentPath']) > 0:
                del item['parentPath'][0]
            item['parentPath'].append({'id': item['id'],'name': item['name'],'adUnitCode': item['adUnitCode']})
            ad_unit_id_level_1, ad_unit_id_level_2, ad_unit_id_level_3, ad_unit_id_level_4, ad_unit_id_level_5 = [item['parentPath'][i]['id'] if len(item['parentPath']) > i else None for i in range(5)]
            ad_unit_name_level_1, ad_unit_name_level_2, ad_unit_name_level_3, ad_unit_name_level_4, ad_unit_name_level_5 = [item['parentPath'][i]['name'] if len(item['parentPath']) > i else None for i in range(5)]

            ad_unit_name = []
            for i in range(len(item['parentPath'])):
                ad_unit_name.append(vars()[f'ad_unit_name_level_{i+1}']+' ('+vars()[f'ad_unit_id_level_{i+1}']+')')
            ad_unit_name = ' Â» '.join(ad_unit_name)

            inventory_data.append(
                [
                    -1 if item['id'] == None else int(item['id']),
                    -1 if item['parentId'] == None else int(item['parentId']),
                    item['hasChildren'],
                    item['description'],
                    item['status'],
                    item['adUnitCode'],
                    ad_unit_id_level_1,
                    ad_unit_id_level_2,
                    ad_unit_id_level_3,
                    ad_unit_id_level_4,
                    ad_unit_id_level_5,
                    ad_unit_name_level_1,
                    ad_unit_name_level_2,
                    ad_unit_name_level_3,
                    ad_unit_name_level_4,
                    ad_unit_name_level_5,
                    ad_unit_name,
                    item['isInterstitial'],
                    item['isNative'],
                    item['isFluid'],
                    item['explicitlyTargeted'],
                    True if 'fxw' in ad_unit_name else True if 'wfast' in ad_unit_name else False,
                    True if 'wfast' in ad_unit_name else False,
                    format_to_datetime(item['lastModifiedDateTime']) if item['lastModifiedDateTime'] else None,
                ]
            )

    schema = T.StructType(
        [
            T.StructField('ad_unit_id', T.LongType(), True),
            T.StructField('parent_id', T.LongType(), True),
            T.StructField('has_children', T.BooleanType(), True),
            T.StructField('description', T.StringType(), True),
            T.StructField('status', T.StringType(), True),
            T.StructField('ad_unit_code', T.StringType(), True),
            T.StructField('ad_unit_id_level_1', T.StringType(), True),
            T.StructField('ad_unit_id_level_2', T.StringType(), True),
            T.StructField('ad_unit_id_level_3', T.StringType(), True),
            T.StructField('ad_unit_id_level_4', T.StringType(), True),
            T.StructField('ad_unit_id_level_5', T.StringType(), True),
            T.StructField('ad_unit_name_level_1', T.StringType(), True),
            T.StructField('ad_unit_name_level_2', T.StringType(), True),
            T.StructField('ad_unit_name_level_3', T.StringType(), True),
            T.StructField('ad_unit_name_level_4', T.StringType(), True),
            T.StructField('ad_unit_name_level_5', T.StringType(), True),
            T.StructField('ad_unit_name', T.StringType(), True),
            T.StructField('is_interstitial', T.BooleanType(), True),
            T.StructField('is_native', T.BooleanType(), True),
            T.StructField('is_fluid', T.BooleanType(), True),
            T.StructField('is_explicitly_targeted', T.BooleanType(), True),
            T.StructField('is_weather', T.BooleanType(), True),
            T.StructField('is_weather_fast', T.BooleanType(), True),
            T.StructField('last_modified_datetime', T.TimestampType(), True),
        ]
    )
    inventory_data = spark.createDataFrame(inventory_data,  schema=schema)
    return inventory_data

def format_advertiser_external(response: Any) -> Any:
    if 'results' in response and len(response['results']):
        advertisers = response['results']
        advertiser_data_external = []

        for advertiser in advertisers:
            advertiser_data_external.append(
                [
                    advertiser['id'],
                    advertiser['externalId']
                ]
            )

        schema = T.StructType(
            [
                T.StructField('advertiser_id', T.LongType(), True),
                T.StructField('external_id', T.StringType(), True)
            ]
        )
        advertiser_data_external = spark.createDataFrame(advertiser_data_external,  schema=schema)
        return advertiser_data_external

def format_advertiser(advertiser_data: Any, advertiser_data_external: Any) -> Any:
    format_columns = {
        'Dimension.ADVERTISER_ID': ('advertiser_id', T.LongType()),
        'Dimension.ADVERTISER_NAME': ('advertiser_name', T.StringType()),
        'Dimension.AD_TYPE_ID': ('ad_type_id', T.StringType()),
        'Dimension.AD_TYPE_NAME': ('ad_type_name', T.StringType()),
        'DimensionAttribute.ADVERTISER_TYPE': ('advertiser_type', T.StringType()),
        'DimensionAttribute.ADVERTISER_CREDIT_STATUS': ('advertiser_credit_status', T.StringType()),
        'Column.TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS': ('total_line_item_level_impressions', T.LongType())
    }

    for k, v in format_columns.items():
        advertiser_data = advertiser_data.withColumnRenamed(k, v[0])
        advertiser_data = advertiser_data.withColumn(v[0], F.col(v[0]).cast(v[1]))
    
    advertiser_data = advertiser_data.join(advertiser_data_external, ['advertiser_id'], how='left')

    return advertiser_data


def format_line_item(response: Any) -> Any:
    if 'results' in response and len(response['results']):
        line_items = response['results']
        line_item_data = []

        for line_item in line_items:
            line_item_data.append(
                [
                    line_item['id'],
                    line_item['name'],
                    line_item['orderId'],
                    line_item['orderName'],
                    format_to_datetime(line_item['startDateTime']) if line_item['startDateTime'] else None,
                    line_item['startDateTime']['timeZoneId'] if line_item['startDateTime'] else None,
                    line_item['startDateTimeType'],
                    format_to_datetime(line_item['endDateTime']) if line_item['endDateTime'] else None,
                    line_item['endDateTime']['timeZoneId'] if line_item['endDateTime'] else None,
                    line_item['unlimitedEndDateTime'],
                    line_item['skippableAdType'],
                    line_item['lineItemType'],
                    line_item['priority'],
                    line_item['costType'],
                    line_item['costPerUnit']['currencyCode'],
                    line_item['costPerUnit']['microAmount'],
                    line_item['valueCostPerUnit']['currencyCode'],
                    line_item['valueCostPerUnit']['microAmount'],
                    line_item['contractedUnitsBought'],
                    line_item['deliveryIndicator']['expectedDeliveryPercentage'] if line_item['deliveryIndicator'] else None,
                    line_item['deliveryIndicator']['actualDeliveryPercentage'] if line_item['deliveryIndicator'] else None,
                    " ".join(str(line_item['deliveryData']).replace(" ","").split('\n')) if line_item['deliveryData'] else None,
                    line_item['budget']['currencyCode'],
                    line_item['budget']['microAmount'],
                    line_item['status'],
                    line_item['isMissingCreatives'],
                    line_item['primaryGoal']['goalType'],
                    line_item['primaryGoal']['unitType'],
                    line_item['primaryGoal']['units'],
                    format_to_datetime(line_item['lastModifiedDateTime']) if line_item['lastModifiedDateTime'] else None,
                ]
            )

    schema = T.StructType(
        [
            T.StructField('line_item_id', T.LongType(), True),
            T.StructField('line_item_name', T.StringType(), True),
            T.StructField('order_id', T.LongType(), True),
            T.StructField('order_name', T.StringType(), True),
            T.StructField('line_item_start_datetime', T.TimestampType(), True),
            T.StructField('line_item_start_datetime_timezone', T.StringType(), True),
            T.StructField('line_item_start_datetime_type', T.StringType(), True),
            T.StructField('line_item_end_datetime', T.TimestampType(), True),
            T.StructField('line_item_end_datetime_timezone', T.StringType(), True),
            T.StructField('is_unlimited_end_datetime', T.BooleanType(), True),
            T.StructField('is_skippable_ad_type', T.StringType(), True),
            T.StructField('line_item_type', T.StringType(), True),
            T.StructField('line_item_priority', T.StringType(), True),
            T.StructField('line_item_cost_type', T.StringType(), True),
            T.StructField('line_item_cost_per_unit_currency_code', T.StringType(), True),
            T.StructField('line_item_cost_per_unit_micro_amt', T.LongType(), True),
            T.StructField('line_item_value_cost_per_unit_currency_code', T.StringType(), True),
            T.StructField('line_item_value_cost_per_unit_micro_amt', T.LongType(), True),
            T.StructField('line_item_contracted_units_bought_qty', T.LongType(), True),
            T.StructField('delivery_indicator_expected_delivery_percentage', T.DoubleType(), True),
            T.StructField('delivery_indicator_actual_delivery_percentage', T.DoubleType(), True),
            T.StructField('delivery_data', T.StringType(), True),
            T.StructField('budget_currency_code', T.StringType(), True),
            T.StructField('budget_micro_amt', T.LongType(), True),
            T.StructField('line_item_status', T.StringType(), True),
            T.StructField('is_missing_creatives', T.BooleanType(), True),
            T.StructField('primary_goal_type', T.StringType(), True),
            T.StructField('primary_goal_unit_type', T.StringType(), True),
            T.StructField('primary_goal_units_qty', T.LongType(), True),
            T.StructField('last_modified_datetime', T.TimestampType(), True),
        ]
    )
    line_item_data = spark.createDataFrame(line_item_data,  schema=schema)
    return line_item_data

def format_order(response: Any) -> Any:
    if 'results' in response and len(response['results']):
        orders = response['results']
        order_data = []

        for order in orders:
            order_data.append(
                [
                    order['id'],
                    order['name'],
                    format_to_datetime(order['startDateTime']) if order['startDateTime'] else None,
                    order['startDateTime']['timeZoneId'] if order['startDateTime'] else None,
                    format_to_datetime(order['endDateTime']) if order['endDateTime'] else None,
                    order['endDateTime']['timeZoneId'] if order['endDateTime'] else None,
                    order['status'],
                    order['advertiserId'],
                    order['salespersonId'],
                    order['unlimitedEndDateTime'],
                    order['totalImpressionsDelivered']
                ]
            )

    schema = T.StructType(
        [
            T.StructField('order_id', T.StringType(), True),
            T.StructField('order_name', T.StringType(), True),
            T.StructField('order_start_datetime', T.TimestampType(), True),
            T.StructField('order_start_datetime_timezone', T.StringType(), True),
            T.StructField('order_end_datetime', T.TimestampType(), True),
            T.StructField('order_end_datetime_timezone', T.StringType(), True),
            T.StructField('order_status', T.StringType(), True),
            T.StructField('order_advertiser_id', T.StringType(), True),
            T.StructField('order_salesperson_id', T.StringType(), True),
            T.StructField('is_unlimited_end_datetime', T.BooleanType(), True),
            T.StructField('total_line_item_level_impressions', T.LongType(), True)
        ]
    )
    order_data = spark.createDataFrame(order_data,  schema=schema)
    return order_data

def format_user(response: Any) -> Any:
    if 'results' in response and len(response['results']):
        users = response['results']
        user_data = []

        for user in users:
            user_data.append(
                [
                    user['id'],
                    user['name'],
                    user['isActive'],
                    user['isServiceAccount']
                ]
            )

    schema = T.StructType(
        [
            T.StructField('user_id', T.StringType(), True),
            T.StructField('user_name', T.StringType(), True),
            T.StructField('is_active', T.BooleanType(), True),
            T.StructField('is_service_account', T.BooleanType(), True)
        ]
    )
    user_data = spark.createDataFrame(user_data,  schema=schema)
    return user_data

# def format_content(content_data: Any) -> Any:
#     format_columns = {
#         'Dimension.CONTENT_NAME': ['content_name', T.StringType()],
#         'Dimension.CONTENT_ID': ['content_id', T.StringType()],
#         'DimensionAttribute.CONTENT_CMS_NAME': ['content_cms_name', T.StringType()],
#         'DimensionAttribute.CONTENT_CMS_VIDEO_ID': ['content_cms_video_id', T.StringType()],
#         'Column.VIDEO_ERRORS_VAST_ERROR_303_COUNT': ['video_errors_vast_error_303_count', T.LongType()],
#         'Column.TOTAL_VIDEO_OPPORTUNITIES': ['total_video_opportunities', T.LongType()],
#         'Column.TOTAL_VIDEO_CAPPED_OPPORTUNITIES': ['total_video_capped_opportunities', T.LongType()],
#         'Column.TOTAL_VIDEO_MATCHED_OPPORTUNITIES': ['total_video_matched_opportunities', T.LongType()],
#         'Column.TOTAL_VIDEO_MATCHED_DURATION': ['total_video_matched_duration', T.LongType()],
#         'Column.TOTAL_VIDEO_DURATION': ['total_video_duration', T.LongType()]
#     }

#     for k, v in format_columns.items():
#         content_data = content_data.withColumnRenamed(k, v[0])
#         content_data = content_data.withColumn(v[0], F.col(v[0]).cast(v[1]))

#     return content_data

# def format_creative(creative_data: Any) -> Any:
#     format_columns = {
#         'Dimension.CREATIVE_ID': ['creative_id', T.StringType()],
#         'Dimension.CREATIVE_NAME': ['creative_name', T.StringType()],
#         'Dimension.CREATIVE_TYPE': ['creative_type', T.StringType()],
#         'Dimension.CREATIVE_SIZE': ['creative_size', T.StringType()],
#         'Dimension.MASTER_COMPANION_CREATIVE_ID': ['master_companion_creative_id', T.StringType()],
#         'Dimension.MASTER_COMPANION_CREATIVE_NAME': ['master_companion_creative_name', T.StringType()],
#         'Column.TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS': ['total_line_item_level_impressions', T.LongType()]
#     }

#     for k, v in format_columns.items():
#         creative_data = creative_data.withColumnRenamed(k, v[0])
#         creative_data = creative_data.withColumn(v[0], F.col(v[0]).cast(v[1]))

#     return creative_data

# def format_delivery(delivery_data: Any) -> Any:
#     format_columns = {
#         'Dimension.PROGRAMMATIC_CHANNEL_NAME': ['programmatic_channel_name', T.StringType()],
#         'Dimension.AD_UNIT_ID': ['ad_unit_id', T.StringType()],
#         'Dimension.LINE_ITEM_ID': ['line_item_id', T.StringType()],
#         'Column.TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS': ['total_line_item_level_impressions', T.LongType()]
#     }

#     for k, v in format_columns.items():
#         delivery_data = delivery_data.withColumnRenamed(k, v[0])
#         delivery_data = delivery_data.withColumn(v[0], F.col(v[0]).cast(v[1]))

#     delivery_data = delivery_data.drop('Dimension.AD_UNIT_NAME')

#     return delivery_data

# COMMAND ----------

if __name__ == '__main__':
    gam_service_account_creds_secret_arn = dbutils.widgets.get('gam_service_account_creds_secret_arn')
    gam_api_version = dbutils.widgets.get('gam_api_version')

    client = get_ad_manager_client(secret_arn=gam_service_account_creds_secret_arn)
    timezone = pytz.timezone("UTC")
    # last_updated_timestamp = (datetime.now()-timedelta(days=800)).replace(tzinfo=timezone)

    # Fetch dimensions one by one from match table api
    # Ad Unit
    last_updated_timestamp = spark.sql('select max(etl_updated_timestamp) as last_updated_timestamp from fox_bi_dev.raw_ads.gam_ad_unit').collect()[0]['last_updated_timestamp'].replace(tzinfo=timezone)
    statement = ad_manager.StatementBuilder(version=gam_api_version)\
                .Where('lastModifiedDateTime >= :lastModifiedDateTime')\
                .WithBindVariable('lastModifiedDateTime', last_updated_timestamp)
    inventory_service = client.GetService('InventoryService', version=gam_api_version)
    response = inventory_service.getAdUnitsByStatement(statement.ToStatement())
    batch_number = 0
    while True:
        response = inventory_service.getAdUnitsByStatement(statement.ToStatement())
        if 'results' in response and len(response['results']) == 0:
            break
        batch_size = len(response['results'])
        if batch_number == 0:
            ad_unit_data = format_ad_unit(response)
        else:
            ad_unit_data = ad_unit_data.union(format_ad_unit(response))
        batch_number += 1
        statement.limit = batch_size
        statement.offset += batch_size

    if batch_number != 0:
        ad_unit_data = ad_unit_data.withColumn('etl_created_timestamp', F.current_timestamp()).withColumn('etl_updated_timestamp', F.current_timestamp())
        ad_unit_data.write.mode('append').option('mergeSchema', 'true').saveAsTable('fox_bi_dev.raw_ads.gam_ad_unit')

    # Advertiser
    last_updated_timestamp = spark.sql('select max(etl_updated_timestamp) as last_updated_timestamp from fox_bi_dev.raw_ads.gam_advertiser').collect()[0]['last_updated_timestamp'].replace(tzinfo=timezone)
    current_timestamp = datetime.now().replace(tzinfo=timezone)
    report_service = client.GetService('ReportService', version=gam_api_version)
    report_query = build_report_query(
        dimensions = [
            'ADVERTISER_ID',
            'ADVERTISER_NAME',
            'AD_TYPE_ID',
            'AD_TYPE_NAME'
        ],
        columns = [
            'TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS'
        ],
        dimensionAttributes = [
            'ADVERTISER_TYPE',
            'ADVERTISER_CREDIT_STATUS'
        ],
        start_date = last_updated_timestamp,
        end_date = current_timestamp
    )
    report_job = report_service.runReportJob({'reportQuery': report_query})

    while True:
        status = report_service.getReportJobStatus(report_job['id'])
        if status == 'COMPLETED':
            break
        elif status == 'FAILED':
            break
        else:
            time.sleep(10)

    if status == 'COMPLETED':
        report_download_url = report_service.getReportDownloadURL(report_job['id'], 'CSV_DUMP')
        df = pd.read_csv(report_download_url, compression='gzip')
        
        statement = ad_manager.StatementBuilder(version=gam_api_version)\
                    .Where('lastModifiedDateTime >= :lastModifiedDateTime')\
                    .WithBindVariable('lastModifiedDateTime', last_updated_timestamp)
        company_service = client.GetService('CompanyService', version=gam_api_version)
        batch_number = 0

        while True:
            response = company_service.getCompaniesByStatement(statement.ToStatement())
            if 'results' in response and len(response['results']) == 0:
                break
            batch_size = len(response['results'])
            if batch_number == 0:
                advertiser_data_external = format_advertiser_external(response)
            else:
                advertiser_data_external = advertiser_data_external.union(format_advertiser_external(response))
            batch_number += 1
            statement.limit = batch_size
            statement.offset += batch_size

        if len(df) != 0 and batch_number != 0:
            advertiser_data = spark.createDataFrame(df)
            advertiser_data = format_advertiser(advertiser_data,  advertiser_data_external)
            advertiser_data = advertiser_data.withColumn('etl_created_timestamp', F.current_timestamp()).withColumn('etl_updated_timestamp', F.current_timestamp())
            advertiser_data.write.mode('append').option('mergeSchema', 'true').saveAsTable('fox_bi_dev.raw_ads.gam_advertiser')
        else:
            print('No new data found for advertiser in the given timerange')

    # Line Item
    last_updated_timestamp = spark.sql('select max(etl_updated_timestamp) as last_updated_timestamp from fox_bi_dev.raw_ads.gam_line_item').collect()[0]['last_updated_timestamp'].replace(tzinfo=timezone)
    statement = ad_manager.StatementBuilder(version=gam_api_version)\
                .Where('lastModifiedDateTime >= :lastModifiedDateTime')\
                .WithBindVariable('lastModifiedDateTime', last_updated_timestamp)
    line_item_service = client.GetService('LineItemService', version=gam_api_version)
    batch_number = 0
    while True:
        response = line_item_service.getLineItemsByStatement(statement.ToStatement())
        if 'results' in response and len(response['results']) == 0:
            break
        batch_size = len(response['results'])
        if batch_number == 0:
            line_item_data = format_line_item(response)
        else:
            line_item_data = line_item_data.union(format_line_item(response))
        batch_number += 1
        statement.limit = batch_size
        statement.offset += batch_size

    if batch_number != 0:
        line_item_data = line_item_data.withColumn('etl_created_timestamp', F.current_timestamp()).withColumn('etl_updated_timestamp', F.current_timestamp())
        line_item_data.write.mode('append').option('mergeSchema', 'true').saveAsTable('fox_bi_dev.raw_ads.gam_line_item')

    # Order
    last_updated_timestamp = spark.sql('select max(etl_updated_timestamp) as last_updated_timestamp from fox_bi_dev.raw_ads.gam_order').collect()[0]['last_updated_timestamp'].replace(tzinfo=timezone)
    statement = ad_manager.StatementBuilder(version=gam_api_version)\
                .Where('lastModifiedDateTime >= :lastModifiedDateTime')\
                .WithBindVariable('lastModifiedDateTime', last_updated_timestamp)
    order_service = client.GetService('OrderService', version=gam_api_version)
    batch_number = 0
    while True:
        response = order_service.getOrdersByStatement(statement.ToStatement())
        if 'results' in response and len(response['results']) == 0:
            break
        batch_size = len(response['results'])
        if batch_number == 0:
            order_data = format_order(response)
        else:
            order_data = order_data.union(format_order(response))
        batch_number += 1
        statement.limit = batch_size
        statement.offset += batch_size

    if batch_number != 0:
        order_data = order_data.withColumn('etl_created_timestamp', F.current_timestamp()).withColumn('etl_updated_timestamp', F.current_timestamp())
        order_data.write.mode('append').option('mergeSchema', 'true').saveAsTable('fox_bi_dev.raw_ads.gam_order')

    # User
    last_updated_timestamp = spark.sql('select max(etl_updated_timestamp) as last_updated_timestamp from fox_bi_dev.raw_ads.gam_user').collect()[0]['last_updated_timestamp'].replace(tzinfo=timezone)
    statement = ad_manager.StatementBuilder(version=gam_api_version)
    user_service = client.GetService('UserService', version=gam_api_version)
    batch_number = 0
    while True:
        response = user_service.getUsersByStatement(statement.ToStatement())
        if 'results' in response and len(response['results']) == 0:
            break
        batch_size = len(response['results'])
        if batch_number == 0:
            user_data = format_user(response)
        else:
            user_data = user_data.union(format_user(response))
        batch_number += 1
        statement.limit = batch_size
        statement.offset += batch_size

    if batch_number != 0:
        user_data = user_data.withColumn('etl_created_timestamp', F.current_timestamp()).withColumn('etl_updated_timestamp', F.current_timestamp())
        user_data.write.mode('append').option('mergeSchema', 'true').saveAsTable('fox_bi_dev.raw_ads.gam_user')

    # # Content
    # # last_updated_timestamp = spark.sql('select max(etl_updated_timestamp) as last_updated_timestamp from fox_bi_dev.raw_ads.adsales_gam_content').collect()[0]['last_updated_timestamp']
    # current_timestamp = datetime.now().replace(tzinfo=timezone)
    # report_service = client.GetService('ReportService', version=gam_api_version)
    # report_query = build_report_query(
    #     dimensions = ['CONTENT_NAME'],
    #     columns = [
    #         'VIDEO_ERRORS_VAST_ERROR_303_COUNT',
    #         'TOTAL_VIDEO_OPPORTUNITIES',
    #         'TOTAL_VIDEO_CAPPED_OPPORTUNITIES',
    #         'TOTAL_VIDEO_MATCHED_OPPORTUNITIES',
    #         'TOTAL_VIDEO_MATCHED_DURATION',
    #         'TOTAL_VIDEO_DURATION'
    #     ],
    #     dimensionAttributes = [
    #         'CONTENT_CMS_NAME',
    #         'CONTENT_CMS_VIDEO_ID'
    #     ],
    #     start_date = last_updated_timestamp,
    #     end_date = current_timestamp
    # )
    # report_job = report_service.runReportJob({'reportQuery': report_query})

    # while True:
    #     status = report_service.getReportJobStatus(report_job['id'])
    #     if status == 'COMPLETED':
    #         break
    #     elif status == 'FAILED':
    #         break
    #     else:
    #         time.sleep(10)

    # if status == 'COMPLETED':
    #     report_download_url = report_service.getReportDownloadURL(report_job['id'], 'CSV_DUMP')
    #     content_data = spark.createDataFrame(pd.read_csv(report_download_url, compression='gzip'))
    #     content_data = format_content(content_data)
    #     content_data = content_data.withColumn('etl_created_timestamp', F.current_timestamp()).withColumn('etl_updated_timestamp', F.current_timestamp())
    #     content_data.write.mode('overwrite').option('mergeSchema', 'true').saveAsTable('fox_bi_dev.raw_ads.adsales_gam_content')

    # # Creative
    # # last_updated_timestamp = spark.sql('select max(etl_updated_timestamp) as last_updated_timestamp from fox_bi_dev.raw_ads.adsales_gam_creative').collect()[0]['last_updated_timestamp']
    # current_timestamp = datetime.now().replace(tzinfo=timezone)
    # report_service = client.GetService('ReportService', version=gam_api_version)
    # report_query = build_report_query(
    #     dimensions = [
    #         'CREATIVE_ID',
    #         'CREATIVE_NAME',
    #         'CREATIVE_TYPE',
    #         'CREATIVE_SIZE',
    #         'MASTER_COMPANION_CREATIVE_ID',
    #         'MASTER_COMPANION_CREATIVE_NAME'
    #     ],
    #     columns = [
    #         'TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS',
    #     ],
    #     dimensionAttributes = [],
    #     start_date = last_updated_timestamp,
    #     end_date = current_timestamp
    # )
    # report_job = report_service.runReportJob({'reportQuery': report_query})

    # while True:
    #     status = report_service.getReportJobStatus(report_job['id'])
    #     if status == 'COMPLETED':
    #         break
    #     elif status == 'FAILED':
    #         break
    #     else:
    #         time.sleep(10)

    # if status == 'COMPLETED':
    #     report_download_url = report_service.getReportDownloadURL(report_job['id'], 'CSV_DUMP')
    #     creative_data = spark.createDataFrame(pd.read_csv(report_download_url, compression='gzip'))
    #     creative_data = format_creative(creative_data)
    #     creative_data = creative_data.withColumn('etl_created_timestamp', F.current_timestamp()).withColumn('etl_updated_timestamp', F.current_timestamp())
    #     creative_data.write.mode('overwrite').option('mergeSchema', 'true').saveAsTable('fox_bi_dev.raw_ads.adsales_gam_creative')
    
    # # Delivery
    # # last_updated_timestamp = spark.sql('select max(etl_updated_timestamp) as last_updated_timestamp from fox_bi_dev.raw_ads.adsales_gam_delivery').collect()[0]['last_updated_timestamp']
    # current_timestamp = datetime.now().replace(tzinfo=timezone)
    # report_service = client.GetService('ReportService', version=gam_api_version)
    # report_query = build_report_query(
    #     dimensions = [
    #         'PROGRAMMATIC_CHANNEL_NAME',
    #         'AD_UNIT_ID',
    #         'LINE_ITEM_ID'
    #     ],
    #     columns = [
    #         'TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS',
    #     ],
    #     dimensionAttributes = [],
    #     start_date = last_updated_timestamp,
    #     end_date = current_timestamp
    # )
    # report_job = report_service.runReportJob({'reportQuery': report_query})

    # while True:
    #     status = report_service.getReportJobStatus(report_job['id'])
    #     if status == 'COMPLETED':
    #         break
    #     elif status == 'FAILED':
    #         break
    #     else:
    #         time.sleep(10)

    # if status == 'COMPLETED':
    #     report_download_url = report_service.getReportDownloadURL(report_job['id'], 'CSV_DUMP')
    #     delivery_data = spark.createDataFrame(pd.read_csv(report_download_url, compression='gzip'))
    #     delivery_data = format_delivery(delivery_data)
    #     delivery_data = delivery_data.withColumn('etl_created_timestamp', F.current_timestamp()).withColumn('etl_updated_timestamp', F.current_timestamp())
    #     delivery_data.write.mode('overwrite').option('mergeSchema', 'true').saveAsTable('fox_bi_dev.raw_ads.adsales_gam_delivery')