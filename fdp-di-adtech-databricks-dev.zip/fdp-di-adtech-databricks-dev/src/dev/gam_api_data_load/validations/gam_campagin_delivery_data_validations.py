# Databricks notebook source
# MAGIC %sh
# MAGIC aws configure set region us-west-2 --profile databricks-cpe-dev
# MAGIC aws configure set s3.signature_version s3v4 --profile databricks-cpe-dev
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile databricks-cpe-dev
# MAGIC aws configure set role_arn arn:aws:iam::393000359662:role/data-infra-astro-bi-adtech-dev --profile databricks-cpe-dev

# COMMAND ----------

# Databricks notebook source
aws_profile=dbutils.widgets.get('aws_profile')
aws_arn=dbutils.widgets.get('aws_arn')
from_email=dbutils.widgets.get('from_email')

# COMMAND ----------

# make the variable available to shell
import os
os.environ["AWS_PROFILE_VAR"] = aws_profile
os.environ["AWS_ARN"] = aws_arn

# COMMAND ----------

# MAGIC %sh
# MAGIC aws configure set region us-west-2 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set s3.signature_version s3v4 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile $AWS_PROFILE_VAR
# MAGIC aws configure set role_arn $AWS_ARN --profile $AWS_PROFILE_VAR

# COMMAND ----------

from googleads import ad_manager, oauth2, errors
import boto3
import os
from datetime import datetime, timedelta
from dataclasses import dataclass
from typing import List, Optional, Any, cast
import json
import tempfile
from datetime import datetime, timedelta
import pytz
import time
import pandas as pd
from pyspark.sql import SparkSession
import pyspark.sql.types as T
import pyspark.sql.functions as F
from pyspark import SparkFiles
import io
from email import encoders
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication

# COMMAND ----------

global aws_profile, APPLICATION_NAME, NETWORK_CODE, cpe_s3_bucket
aws_profile = f'{aws_profile}'
APPLICATION_NAME = 'AdSales - GAM Data Ingestion'
NETWORK_CODE = 4145
cpe_s3_bucket = 'fox-fdp-bi-dev'
spark = SparkSession.builder.appName('GAM Report Data Load').getOrCreate()
spark.conf.set("spark.sql.session.timeZone", "UTC")

# COMMAND ----------

def get_ad_manager_client(secret_arn: str) -> Any:
    session = boto3.Session(profile_name=aws_profile)
    resp = session.client('secretsmanager').get_secret_value(SecretId=secret_arn)
    secret = json.loads(resp['SecretString'])

    with tempfile.NamedTemporaryFile(mode='w', delete=False) as secret_file:
        json.dump(secret, secret_file, indent=2)
        secret_file.close()

    oauth2_client = oauth2.GoogleServiceAccountClient(secret_file.name, oauth2.GetAPIScope('ad_manager'))
    os.unlink(secret_file.name)
    ad_manager_client = ad_manager.AdManagerClient(oauth2_client, APPLICATION_NAME, NETWORK_CODE)

    return ad_manager_client

# COMMAND ----------

def format_to_datetime(date_dict: Any) -> datetime:
    return datetime(
        date_dict['date']['year'],
        date_dict['date']['month'],
        date_dict['date']['day'],
        date_dict['hour'],
        date_dict['minute'],
        date_dict['second'],
        tzinfo=pytz.timezone(date_dict['timeZoneId'])
    )

def format_datetime_to_obj(datetime_obj: Any) -> Any:
    obj = {}
    obj['year'] = datetime_obj.year
    obj['month'] = datetime_obj.month
    obj['day'] = datetime_obj.day
    return obj

def generate_processing_dates(start_date: datetime, end_date: datetime, step_size: int) -> list:
    processing_dates = []

    batch_start_date = start_date
    while batch_start_date <= end_date:
        batch_end_date = batch_start_date + timedelta(days=step_size - 1)
        if batch_end_date <= end_date:
            processing_dates.append((batch_start_date, batch_end_date))
        else:
            processing_dates.append((batch_start_date, end_date))
            break
        batch_start_date += timedelta(days=step_size)

    return processing_dates

def build_report_query(dimensions: list, columns: list, dimensionAttributes: list, start_date: datetime, end_date: datetime) -> Any:
    baseReportQuery = {
        'dimensions': [],
        'adUnitView': 'FLAT',
        'columns': [],
        'dimensionAttributes': [],
        'customFieldIds': [],
        'cmsMetadataKeyIds': [],
        'customDimensionKeyIds': [],
        'startDate': {},
        'endDate': {},
        'dateRangeType': 'CUSTOM_DATE',
        'statement': None,
        'reportCurrency': 'USD',
        'timeZoneType': 'PUBLISHER'
    }

    report_query = baseReportQuery
    report_query['dimensions'] = dimensions
    report_query['columns'] = columns
    report_query['dimensionAttributes'] = dimensionAttributes
    report_query['startDate'] = format_datetime_to_obj(start_date)
    report_query['endDate'] = format_datetime_to_obj(end_date)
    return report_query


# COMMAND ----------

def format_report(report_data: Any, report_type: str) -> Any:
    if report_type == 'GAM API Daily Data Validation Report':
        format_columns = {
            'Dimension.DATE': ('event_date', T.DateType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS': ('total_line_item_level_impressions', T.LongType()),
           
        }
        select_cols = [
            'event_date',
            'total_line_item_level_impressions',
           
        ]

    
    for k, v in format_columns.items():
        report_data = report_data.withColumnRenamed(k, v[0])
        report_data = report_data.withColumn(v[0], F.col(v[0]).cast(v[1]))

    report_data = report_data.select(select_cols)

    return report_data

# COMMAND ----------

class ReportMailInfo:
    from_email = 'adtech.prod@data.fox'
    reply_to_address = 'data_adtech@fox.com'
    key = ''
    info = {}
    report_mailing_lists = {
        "GAM Validation Report 1" : {
            "key_format_string" : "gam_analytics/GAM Campaign Delivery Data Daily Validation Report_%d%b%Y.csv",
            "human_readable_name" : "GAM Campaign Delivery Data Daily Validation Report",
            "to" : [
                "prajwal.harikishor@fox.com",
                "ashwin.sahay@fox.com",
                "alex.lehman@fox.com",
                "SRE_Data_Platform@fox.com",
                "noormahammad.nalband@fox.com",
                "data_adtech@fox.com",
            ],
            "cc" : [
                "alimaafroseshahul.hameed@fox.com",
                "sharath.yalaka@fox.com",
            ]
        },

    }

    def __init__(self, report, report_date,validation_status):
        self.info = self.report_mailing_lists[report]
        self.key = get_latest_report(report_date, self.info['key_format_string'])
        self.validation_status = validation_status

    def get_file_name(self):
        return os.path.basename(self.key)
    
    def get_report_body(self, report_date):
        footer = f'<p>This is an automated email. Please direct any questions or concerns to <a href="mailto: {self.reply_to_address}">{self.reply_to_address}</a>.</p>'
        if self.validation_status:
            body_text = f"""<p>Hello,</p>

<p>The validation status: PASS</p>

<p>Please find attached the {self.info['human_readable_name']}.</p>

{footer}
"""
        else:
            body_text = f"""<p>Hello,</p>

            <p>The validation status: FAILED</p>

{footer}
"""
        return MIMEText(body_text, 'html')

    def get_report_attachment(self):
        session = boto3.Session(profile_name=aws_profile)
        s3 = session.client('s3')
        resp = s3.get_object(Bucket=cpe_s3_bucket, Key=self.key)
        return resp['Body'].read()

# COMMAND ----------

def get_latest_report(report_date: datetime, key_format_string: str):
    session = boto3.Session(profile_name=aws_profile)
    s3 = session.client('s3')
    for delta in range(0, -7, -1):
        date = report_date + timedelta(days=delta)
        key = date.strftime(key_format_string)
        try:
            print(f'Trying object s3://{cpe_s3_bucket}/{key}')
            s3.head_object(Bucket=cpe_s3_bucket, Key=key)
            return key
        except s3.exceptions.ClientError as exc:
            if exc.response['Error']['Code'] == '404':
                continue
            raise
    raise RuntimeError('Could not find report')

# COMMAND ----------

def send_mail(report_name, report_date,validation_status):
    
    report = ReportMailInfo(report_name, report_date,validation_status)

    attachment_ready_html = []
    img_id = 0
    mime_images = []

    msg = MIMEMultipart()
    msg['Subject'] = report.info['human_readable_name'].title()
    msg['From'] = report.from_email
    msg['To'] = ", ".join(report.info['to'])
    msg['Cc'] = ", ".join(report.info['cc'])
    msg.attach(report.get_report_body(report_date))

    part = MIMEApplication(
        report.get_report_attachment(),
        Name=report.get_file_name(),
    )
    part['Content-Disposition'] = f'attachment; filename="{report.get_file_name()}"'
    msg.attach(part)

    session = boto3.Session(profile_name = aws_profile)
    ses = session.client('ses', region_name='us-west-2')
    ses.send_raw_email(
        Source=msg['From'],
        Destinations=list(set(report.info['to']).union(set(report.info['cc']))),
        RawMessage={'Data': msg.as_string()}
    )

    print('Email sent')


# COMMAND ----------




def get_validation_status(validation_df):
    variance_column_list = [
        'Impressions Variance %',
        'Revenue Variance %',
        
    ]
    for col in variance_column_list:
        if col in validation_df.columns:
            variance_values = validation_df.select(col).distinct().rdd.flatMap(lambda x: x).collect()
            if len(variance_values) == 1 and variance_values[0] == 0:
                pass
            else:
                print(f'Variance found in column {col}')
                return False
    return True


# COMMAND ----------


# COMMAND ----------

if __name__ == '__main__':
    gam_service_account_creds_secret_arn = dbutils.widgets.get('gam_service_account_creds_secret_arn')
    gam_api_version = dbutils.widgets.get('gam_api_version')

    client = get_ad_manager_client(secret_arn=gam_service_account_creds_secret_arn)
    timezone = pytz.timezone("UTC")
    event_start_date = datetime.strptime(dbutils.widgets.get('event_start_date'), '%Y-%m-%d').replace(tzinfo=timezone)
    event_end_date = datetime.strptime(dbutils.widgets.get('event_end_date'), '%Y-%m-%d').replace(tzinfo=timezone)

    process_days = (event_end_date-event_start_date).days
    processing_dates = generate_processing_dates(event_start_date, event_end_date, 15)

    # GAM API Daily Data Validation Report
    print('GAM View API Daily Data Validation Report')

    table_query_1 = f"""
        SELECT ad_date as event_date
         ,order_id 
         ,SUM(total_impressions) as delivered_impressions_source
         ,SUM(total_cpm_and_cpc_revenue) as delivered_revenue_source
         from fox_bi_dev.silver_ads.ft_gam_summary_daily_data
    where ad_date >= '{event_start_date}' AND ad_date <= '{event_end_date}' 
    and  line_item_type in ('SPONSORSHIP', 'STANDARD', 'BULK')
    group by 1,2;
    """
    table_df = spark.sql(table_query_1)

    view_query_1 = f"""
        SELECT
            `Event Date` as event_date
            ,`order id` as order_id
            , SUM(`Delivered Impressions`) AS delivered_impressions_target
            , SUM(`Delivered Revenue`) as delivered_revenue_target
        FROM fox_bi_qa.gold_ad_sales.v_ft_gam_campaign_delivery
        WHERE `event date` >= '{event_start_date}' AND `event date` <= '{event_end_date}'
        GROUP BY 1,2
    """
    view_df = spark.sql(view_query_1)

    
    validation_df = table_df.join(view_df, on=['event_date','order_id'], how='left')
    validation_df = (validation_df.withColumn('Impressions Variance %',\
        F.when(
        F.col('delivered_impressions_source') == 0,
        F.lit(0)
        ).otherwise(
        F.round((F.col('delivered_impressions_source') - F.col('delivered_impressions_target'))/F.col('delivered_impressions_source')*100, 3)
    )
    )
    .withColumn('Revenue Variance %',
        F.when(
        F.col('delivered_revenue_source') == 0,
        F.lit(0)
    ).otherwise(
        F.round((F.col('delivered_revenue_source') - F.col('delivered_revenue_target')) / F.col('delivered_revenue_source') * 100, 3)
    )
    )
    )
    
    

    validation_df = validation_df.sort('event_date', 'order_id')
    
    validation_status = get_validation_status(validation_df)
    with io.StringIO() as output:
        validation_df.toPandas().to_csv(output, index=False)
        validation_data = output.getvalue()

    report_name = 'GAM Campaign Delivery Data Daily Validation Report_' + datetime.today().strftime('%d%b%Y') + '.csv'
    session = boto3.Session(profile_name=aws_profile)
    s3_client = session.client('s3')
    s3_bucket = cpe_s3_bucket
    s3_key = 'gam_analytics/' + report_name
    s3_client.put_object(
        Bucket=s3_bucket,
        Body=validation_data.encode('utf-8'),
        Key=s3_key,
    )

    send_mail('GAM Validation Report 1', datetime.today(),validation_status)

   


# COMMAND ----------

