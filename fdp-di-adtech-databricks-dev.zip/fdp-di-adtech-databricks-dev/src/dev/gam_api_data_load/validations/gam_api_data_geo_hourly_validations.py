# Databricks notebook source
from googleads import ad_manager, oauth2, errors
import boto3
import os, requests
from datetime import datetime, timedelta, date
from dataclasses import dataclass
from typing import List, Optional, Any, cast
import json
import tempfile
from datetime import datetime, timedelta
import pytz
import time
import pandas as pd
from pyspark.sql import SparkSession
import pyspark.sql.types as T
import pyspark.sql.functions as F
from pyspark import SparkFiles
import io
from email import encoders
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication

# COMMAND ----------

def get_widget_or_none(name):
    try:
        return dbutils.widgets.get(name)
    except Exception:
        return None
    
timezone = pytz.timezone("UTC")

env = dbutils.widgets.get('env')
role_arn = dbutils.widgets.get('role_arn')
gam_service_account_creds_secret_arn=dbutils.widgets.get('gam_service_account_creds_secret_arn')
gam_api_version = dbutils.widgets.get('gam_api_version')

from_email=f'adsales.{env}@data.fox'

gam_hourly_vs_foxai_validation_view_luid= dbutils.widgets.get('hourly_luid')
gam_geo_vs_foxai_validation_view_luid= dbutils.widgets.get('geo_luid')

event_start_date=datetime.strptime(dbutils.widgets.get('validation_start_date'), '%Y-%m-%d').replace(tzinfo=timezone)
event_end_date=datetime.strptime(dbutils.widgets.get('validation_end_date'), '%Y-%m-%d').replace(tzinfo=timezone)

print(event_start_date, event_end_date)


# COMMAND ----------

import subprocess
PROFILE  = "databricks-cpe"

subprocess.run(["aws","configure","set","region","us-west-2","--profile",PROFILE], check=True)
subprocess.run(["aws","configure","set","s3.signature_version","s3v4","--profile",PROFILE], check=True)
subprocess.run(["aws","configure","set","credential_source","Ec2InstanceMetadata","--profile",PROFILE], check=True)
subprocess.run(["aws","configure","set","role_arn",role_arn,"--profile",PROFILE], check=True)

# COMMAND ----------

# MAGIC %sh
# MAGIC aws configure set region us-west-2 --profile databricks-fng-prod
# MAGIC aws configure set s3.signature_version s3v4 --profile databricks-fng-prod
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile databricks-fng-prod
# MAGIC aws configure set role_arn arn:aws:iam::640862407089:role/fng-dmo-prod-databricks-ec2-role --profile databricks-fng-prod

# COMMAND ----------

global aws_profile, APPLICATION_NAME, NETWORK_CODE, cpe_s3_bucket
aws_profile = PROFILE
APPLICATION_NAME = 'AdSales - GAM Data Ingestion'
NETWORK_CODE = 4145
cpe_s3_bucket = f'fox-fdp-bi-{env}'
spark.conf.set("spark.sql.session.timeZone", "UTC")

# COMMAND ----------

class cls_ssm(object):
    def __init__(self, aws_profile='default'):    
        import boto3
        try:
            session = boto3.Session(profile_name = aws_profile)
            client = session.client('ssm')

            self.client=client
            self.aws_profile=aws_profile

        except Exception as e:
            raise Exception('ERROR: '+ str(e))
        
    def get_ssm_param_by_path(self, path, full_path_dict_key=False, next_token=' ', keyvalue_dict={}) :
        # Get all values for all keys from SSM Path as Dictionary
        try:
            #-----------------------------------------------------------------------------------------------------------
            # To reset the keyvalue_dict we need to have below code , if we remove it is having trace of previous calls
            #-----------------------------------------------------------------------------------------------------------
            if next_token==' ':
                keyvalue_dict={}
                response  = self.client.get_parameters_by_path(Path=path, WithDecryption=True, Recursive=True)
            else:
                response  = self.client.get_parameters_by_path(Path=path, NextToken=next_token, WithDecryption=True, Recursive=True)

            for parameter in response['Parameters'] :

                if full_path_dict_key:
                    key = parameter['Name']
                else:
                    key = parameter['Name'].split('/')[-1]

                keyvalue_dict[key] = parameter['Value']
            #---------------------------------------------------------------------------------------------------------------
            # if there is more than 10 param in same path we need to paginate through next sets using next token from response
            #--------------------------------------------------------------------------------------------------------------
            if 'NextToken' in response.keys():
                next_token = response['NextToken']
                keyvalue_dict = self.get_ssm_param_by_path(path, full_path_dict_key, next_token, keyvalue_dict)

            if keyvalue_dict=={}:
                value = self.client.get_parameter(Name = path, WithDecryption = True)['Parameter']['Value']

                if full_path_dict_key:
                    key = path
                else:
                    key = path.split('/')[-1]

                keyvalue_dict[key]=value

            #print(keyvalue_dict)
            return keyvalue_dict
        except Exception as e:
            raise Exception('ERROR: '+ str(e))


# COMMAND ----------

# MAGIC %md
# MAGIC Tableau Data

# COMMAND ----------

# Tableau Cloud

def retrieve_tableau_cloud_pat():
    ssm_obj = cls_ssm('databricks-fng-prod')
    cred_dict = ssm_obj.get_ssm_param_by_path('/fox/prod/tableau_cloud/', full_path_dict_key=False, next_token=' ', keyvalue_dict={})
    return cred_dict['patpassword']

def establish_tableau_cloud_connection(
        server_name="us-west-2b.online.tableau.com",
        version="3.22",
        site_url_id="foxanalytics",
        personal_access_token_name="Adsales_Jobs"):
    pat = retrieve_tableau_cloud_pat()
    signin_url = "https://{server}/api/{version}/auth/signin".format(server=server_name, version=version)
    payload = {
        "credentials":
            {
                "personalAccessTokenName": personal_access_token_name,
                "personalAccessTokenSecret": pat,
                "site": {
                    "contentUrl": site_url_id
                }
            }
    }
    headers = {
        'accept': 'application/json',
        'content-type': 'application/json'
    }
    print(f"Trying to establish connection to Tableau Cloud. SIGNIN_URL: {signin_url}")
    req = requests.post(signin_url, json=payload, headers=headers)
    req.raise_for_status()

    print(f"Successfully established connection to Tableau Cloud. SIGNIN_URL: {signin_url}")
    response = json.loads(req.content)
    token = response["credentials"]["token"]
    site_id = response["credentials"]["site"]["id"]
    headers['X-tableau-auth'] = token
    return headers, token, site_id

  
def download_tableau_view_as_csv(
        view_luid,
        csv_file_path,
        server_name="us-west-2b.online.tableau.com",
        version="3.22",
        headers=None):
    if not headers:
        headers, token, site_id = establish_tableau_cloud_connection()
    url = f"https://{server_name}/api/{version}/sites/{site_id}/views/{view_luid}/data"
    
    headers = {
        'X-Tableau-Auth': token
    }

    response = requests.get(url, headers=headers)
    response.raise_for_status()
    print("Successfully downloaded tableau view contents.")


    if os.path.isfile(csv_file_path):
        print(f"{csv_file_path} file exists. Deleting currently existing file on file system")
        os.remove(csv_file_path)
        print(f"Successfully removed old file: {csv_file_path}")
    print(f"Dumping tableau view contents into a csv file: {csv_file_path}.")
    with open(csv_file_path, 'wb') as file:
        file.write(response.content)
    print(f"Successfully dumped tableau view contents into a csv file: {csv_file_path}")

    # Sign out from Tableau Cloud
    url = f"https://{server_name}/api/{version}/auth/signout"
    print("Signing out of Tableau Cloud.")
    response = requests.post(url, headers=headers)
    #response.raise_for_status()
    print("Successfully signed out of Tableau Cloud.")

today = date.today()
current_directory = os.getcwd()
relative_path = 'Tableau_output/gam_vs_foxai_validation/'
PREVIEW_FOLDER_LOCATION = os.path.join(current_directory, relative_path)

if not os.path.exists(PREVIEW_FOLDER_LOCATION):
    os.makedirs(PREVIEW_FOLDER_LOCATION)

csv_file_path_hourly = None
PREVIEW_FILE_EXTENSION = '.csv'

csv_file_path_hourly = (PREVIEW_FOLDER_LOCATION+'GAM_Hourly'+PREVIEW_FILE_EXTENSION)

download_tableau_view_as_csv(view_luid=gam_hourly_vs_foxai_validation_view_luid, csv_file_path=csv_file_path_hourly)
hourly_df = pd.read_csv(csv_file_path_hourly)


csv_file_path_geo = (PREVIEW_FOLDER_LOCATION+'GAM_Geo'+PREVIEW_FILE_EXTENSION)

download_tableau_view_as_csv(view_luid=gam_geo_vs_foxai_validation_view_luid, csv_file_path=csv_file_path_geo)
geo_df = pd.read_csv(csv_file_path_geo)

# COMMAND ----------

tar_geo_df = (
    geo_df.pivot_table(
        index=["Event Date", "Country Name"],
        columns="Measure Names",
        values="Measure Values",
        aggfunc="sum",      # handles duplicates by summing
        fill_value=0
    )
    .rename_axis(None, axis=1)  # drop the column index name
    .reset_index()
)
tar_geo_df = tar_geo_df[["Event Date", "Country Name", "Delivered Impressions", "Delivered Clicks"]]

# optional: pretty date format and integer types
tar_geo_df["Event Date"] = pd.to_datetime(tar_geo_df["Event Date"]).dt.strftime("%Y-%m-%d")
tar_geo_df["Delivered Impressions"] = tar_geo_df["Delivered Impressions"].astype(str).str.replace(',', '').astype("Int64")
tar_geo_df["Delivered Clicks"] = tar_geo_df["Delivered Clicks"].astype(str).str.replace(',', '').astype("Int64")

display(tar_geo_df)

# COMMAND ----------

tar_hourly_df = (
    hourly_df.pivot_table(
        index=["Event Date", "Event Hour"],
        columns="Measure Names",
        values="Measure Values",
        aggfunc="sum",      # handles duplicates by summing
        fill_value=0
    )
    .rename_axis(None, axis=1)  # drop the column index name
    .reset_index()
)
tar_hourly_df = tar_hourly_df[["Event Date", "Event Hour", "Delivered Impressions", "Delivered Clicks"]]

# optional: pretty date format and integer types
tar_hourly_df["Event Date"] = pd.to_datetime(tar_hourly_df["Event Date"]).dt.strftime("%Y-%m-%d")
tar_hourly_df["Delivered Impressions"] = tar_hourly_df["Delivered Impressions"].astype(str).str.replace(',', '').astype("Int64")
tar_hourly_df["Delivered Clicks"] = tar_hourly_df["Delivered Clicks"].astype(str).str.replace(',', '').astype("Int64")

display(tar_hourly_df)

# COMMAND ----------

# MAGIC %md
# MAGIC GAM API DATA

# COMMAND ----------

def get_ad_manager_client(secret_arn: str) -> Any:
    session = boto3.Session(profile_name=aws_profile)
    resp = session.client('secretsmanager').get_secret_value(SecretId=secret_arn)
    secret = json.loads(resp['SecretString'])

    with tempfile.NamedTemporaryFile(mode='w', delete=False) as secret_file:
        json.dump(secret, secret_file, indent=2)
        secret_file.close()

    oauth2_client = oauth2.GoogleServiceAccountClient(secret_file.name, oauth2.GetAPIScope('ad_manager'))
    os.unlink(secret_file.name)
    ad_manager_client = ad_manager.AdManagerClient(oauth2_client, APPLICATION_NAME, NETWORK_CODE)

    return ad_manager_client

# COMMAND ----------

def format_to_datetime(date_dict: Any) -> datetime:
    return datetime(
        date_dict['date']['year'],
        date_dict['date']['month'],
        date_dict['date']['day'],
        date_dict['hour'],
        date_dict['minute'],
        date_dict['second'],
        tzinfo=pytz.timezone(date_dict['timeZoneId'])
    )

def format_datetime_to_obj(datetime_obj: Any) -> Any:
    obj = {}
    obj['year'] = datetime_obj.year
    obj['month'] = datetime_obj.month
    obj['day'] = datetime_obj.day
    return obj

def generate_processing_dates(start_date: datetime, end_date: datetime, step_size: int) -> list:
    processing_dates = []

    batch_start_date = start_date
    while batch_start_date <= end_date:
        batch_end_date = batch_start_date + timedelta(days=step_size - 1)
        if batch_end_date <= end_date:
            processing_dates.append((batch_start_date, batch_end_date))
        else:
            processing_dates.append((batch_start_date, end_date))
            break
        batch_start_date += timedelta(days=step_size)

    return processing_dates

def build_report_query(dimensions: list, columns: list, dimensionAttributes: list, start_date: datetime, end_date: datetime) -> Any:
    baseReportQuery = {
        'dimensions': [],
        'adUnitView': 'FLAT',
        'columns': [],
        'dimensionAttributes': [],
        'customFieldIds': [],
        'cmsMetadataKeyIds': [],
        'customDimensionKeyIds': [],
        'startDate': {},
        'endDate': {},
        'dateRangeType': 'CUSTOM_DATE',
        'statement': None,
        'reportCurrency': 'USD',
        'timeZoneType': 'PUBLISHER'
    }

    report_query = baseReportQuery
    report_query['dimensions'] = dimensions
    report_query['columns'] = columns
    report_query['dimensionAttributes'] = dimensionAttributes
    report_query['startDate'] = format_datetime_to_obj(start_date)
    report_query['endDate'] = format_datetime_to_obj(end_date)
    return report_query


# COMMAND ----------

def format_report(report_data: Any, report_type: str) -> Any:
    if report_type == 'GAM API Daily Hour Data Validation Report':
        format_columns = {
            'Dimension.DATE': ('Event Date', T.DateType()),
            'Dimension.HOUR': ('Event Hour', T.LongType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS': ('total_line_item_level_impressions', T.LongType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_CLICKS': ('total_line_item_level_clicks', T.LongType())
        }
        select_cols = [
            'Event Date',
            'Event Hour',
            'total_line_item_level_impressions',
            'total_line_item_level_clicks'
        ]
    elif report_type == 'GAM API Geo Daily Data Validation Report':
        format_columns = {
            'Dimension.DATE': ('Event Date', T.DateType()),
            'Dimension.CITY_CRITERIA_ID': ('city_criteria_id', T.LongType()),
            'Dimension.COUNTRY_NAME': ('Country Name', T.StringType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS': ('total_line_item_level_impressions', T.LongType()),
            'Column.TOTAL_LINE_ITEM_LEVEL_CLICKS': ('total_line_item_level_clicks', T.LongType())
        }
        select_cols = [
            'Event Date',
            'city_criteria_id',
            'Country Name',
            'total_line_item_level_impressions',
            'total_line_item_level_clicks'
        ]

    for k, v in format_columns.items():
        report_data = report_data.withColumnRenamed(k, v[0])
        report_data = report_data.withColumn(v[0], F.col(v[0]).cast(v[1]))

    report_data = report_data.select(select_cols)

    return report_data

# COMMAND ----------

def add_filters(report_query,
                country_names=None,          # list[str]
                line_item_types=None,                 # list[str] e.g. ['DELIVERING','PAUSED']
                join_op=None):                # 'AND' or 'OR'
    preds, vals = [], []

    # helper to build IN (...) safely
    def in_clause(field, items, prefix, xsi_type):
        if not items:
            return None, []
        # de-dup while preserving order
        uniq = []
        seen = set()
        for x in items:
            if x not in seen:
                uniq.append(x); seen.add(x)
        placeholders = [f":{prefix}{i}" for i in range(len(uniq))]
        pred = f"{field} IN ({','.join(placeholders)})"
        vlist = [
            {"key": f"{prefix}{i}", "value": {"xsi_type": xsi_type, "value": str(v)}}
            for i, v in enumerate(uniq)
        ]
        return pred, vlist

    # 1) COUNTRY_NAME (Text)
    if country_names:
        p, v = in_clause("COUNTRY_NAME", country_names, "lin", "TextValue")
        if p: preds.append(f"({p})"); vals.extend(v)

    # 3) LINE_ITEM_TYPE (Text)
    if line_item_types:
        p, v = in_clause("LINE_ITEM_TYPE", line_item_types, "st", "TextValue")
        if p: preds.append(f"({p})"); vals.extend(v)

    if preds and join_op:
        report_query["statement"] = {
            "query": "WHERE " + f" {join_op} ".join(preds),
            "values": vals
        }
    else:
        report_query["statement"] = {
            "query": "WHERE " + f" ".join(preds),
            "values": vals
        }
    return report_query


# COMMAND ----------

def gam_report_fetch(processing_dates, dim_cols, report_name):
    for i, batch in enumerate(processing_dates):
        start_date, end_date = batch
        print(f"Processing {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}, batch - {i}", end=' ')
        report_service = client.GetService('ReportService', version=gam_api_version)
        report_query = build_report_query(
            dimensions = dim_cols,
            columns = [
                'TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS',
                'TOTAL_LINE_ITEM_LEVEL_CLICKS',
            ],
            dimensionAttributes = [],
            start_date = start_date,
            end_date = end_date
        )

        if report_name == 'GAM API Geo Daily Data Validation Report':
            report_query = add_filters(
                                        report_query,
                                        country_names=['United States'],
                                        line_item_types=['BULK','STANDARD','SPONSORSHIP'],
                                        join_op="AND"                        # all conditions must match
                                       )
        elif report_name == 'GAM API Daily Hour Data Validation Report':
            report_query = add_filters(
                                        report_query,
                                        line_item_types=['BULK','STANDARD','SPONSORSHIP'],
                                       )

        report_job = report_service.runReportJob({'reportQuery': report_query})

        while True:
            status = report_service.getReportJobStatus(report_job['id'])
            if status == 'COMPLETED':
                break
            elif status == 'FAILED':
                break
            else:
                time.sleep(10)

        if status == 'COMPLETED':
            print('Downloading...', end=' ')
            report_download_url = report_service.getReportDownloadURL(report_job['id'], 'CSV_DUMP')
            report_data = spark.createDataFrame(pd.read_csv(report_download_url, compression='gzip'))
            
            if i == 0:
                final_df = format_report(report_data, report_name)
            else:
                final_df = final_df.union(format_report(report_data, report_name))
            print('Completed')
        else:
            raise Exception('Report job failed')
    return final_df

# COMMAND ----------

if True:    
    client = get_ad_manager_client(secret_arn=gam_service_account_creds_secret_arn)

    process_days = (event_end_date-event_start_date).days
    processing_dates = generate_processing_dates(event_start_date, event_end_date, 15)

    hourly_report_name='GAM API Daily Hour Data Validation Report'
    print(hourly_report_name)
    src_hourly_dff= gam_report_fetch(processing_dates, ['DATE','HOUR'], hourly_report_name)

    src_hourly_dff.drop('LINE_ITEM_TYPE')
    src_hourly_df = src_hourly_dff.groupBy('`Event Date`','`Event Hour`').agg(
        F.sum('TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS').alias('total_line_item_level_impressions'),
        F.sum('TOTAL_LINE_ITEM_LEVEL_CLICKS').alias('total_line_item_level_clicks')
    )

    geo_report_name='GAM API Geo Daily Data Validation Report'
    print(geo_report_name)
    src_geo_dff= gam_report_fetch(processing_dates, ['DATE', 'COUNTRY_NAME','CITY_CRITERIA_ID'], geo_report_name)
    
    src_geo_df = src_geo_dff.filter('`CITY_CRITERIA_ID`!=0')
    src_geo_df.drop('CITY_CRITERIA_ID')
    src_geo_df = src_geo_df.groupBy('`Event Date`', '`Country Name`').agg(
        F.sum('TOTAL_LINE_ITEM_LEVEL_IMPRESSIONS').alias('total_line_item_level_impressions'),
        F.sum('TOTAL_LINE_ITEM_LEVEL_CLICKS').alias('total_line_item_level_clicks')
    )

    display(src_hourly_df)
    display(src_geo_df)


# COMMAND ----------

# MAGIC %md
# MAGIC VALIDATION

# COMMAND ----------

class ReportMailInfo:
    from_email = f'{from_email}'
    key = ''
    info = {}
    report_mailing_lists = {
        "GAM Validation Report" : {
            "key_format_string" : "gam_analytics/GAM Geo and Hourly Daily Data Validation Report_%d%b%Y.xlsx",
            "human_readable_name" : f"{env} - GAM analytics Geo daily and Hourly data validation report",
            "to" : ["SRE_Data_Platform@fox.com"
            ],
            "cc" : [
                "noormahammad.nalband@fox.com",
                "Anitha.Mohanraj@fox.com",
                "alex.lehman@fox.com",
                "yogesh.nageswararao@fox.com"
            ]

        }
    }

    def __init__(self, report, report_date):
        self.info = self.report_mailing_lists[report]
        self.key = get_latest_report(report_date, self.info['key_format_string'])

    def get_file_name(self):
        return os.path.basename(self.key)

    def get_report_attachment(self):
        session = boto3.Session(profile_name=aws_profile)
        s3 = session.client('s3')
        resp = s3.get_object(Bucket=cpe_s3_bucket, Key=self.key)
        return resp['Body'].read()

# COMMAND ----------

def get_latest_report(report_date: datetime, key_format_string: str):
    session = boto3.Session(profile_name=aws_profile)
    s3 = session.client('s3')
    for delta in range(0, -7, -1):
        date = report_date + timedelta(days=delta)
        key = date.strftime(key_format_string)
        try:
            print(f'Trying object s3://{cpe_s3_bucket}/{key}')
            s3.head_object(Bucket=cpe_s3_bucket, Key=key)
            return key
        except s3.exceptions.ClientError as exc:
            if exc.response['Error']['Code'] == '404':
                continue
            raise
    raise RuntimeError('Could not find report')

# COMMAND ----------

def table_format(df):
    wh_data = "<tr>"
    ky = ''
    for i in df.columns:
        ky += f'<th style="color:white; background-color:#104985; font-weight:400;">{i}</th>'
    t1 = wh_data + ky + '</tr>'

    for j in range(len(df)):
        td = ''
        for k in df.columns:
            td += f'<td>{df.iloc[j][k]}</td>'
        t1 += wh_data + td + '</tr>'

    return t1

# COMMAND ----------

def send_mail(report_name, report_date, hourly_variance_df=None, geo_variance_df=None):
    
    report = ReportMailInfo(report_name, report_date)

    attachment_ready_html = []
    img_id = 0
    mime_images = []

    msg = MIMEMultipart()
    msg['Subject'] = report.info['human_readable_name'].title()
    msg['From'] = report.from_email
    msg['To'] = ", ".join(report.info['to'])
    msg['Cc'] = ", ".join(report.info['cc'])
    #msg.attach(report.get_report_body(report_date))

    part = MIMEApplication(
        report.get_report_attachment(),
        Name=report.get_file_name(),
    )
    part['Content-Disposition'] = f'attachment; filename="{report.get_file_name()}"'
    msg.attach(part)

    if hourly_variance_df.count() > 0 and geo_variance_df.count() > 0:
        a1=table_format(hourly_variance_df.toPandas())
        a2=table_format(geo_variance_df.toPandas())
        html=f'''
            <html>
                <body>
                    <p><b><u>Gam API vs Silver Table Validation:</u></b></p>
                    <p><b>Below is the validation between GAM UI and SIlver layer tables</b></p>

                    <p>The below mentioned dates have variance greater than 0.1%

                    </p>
                    <table border=1>{a1}</table>
                    </p>
                    </p>
                    <table border=1>{a2}</table>
                    </p>
                    <p>Please find attached the {report.info['human_readable_name']}.</p>
                    <p>Regards,<br>
                    Data Ops Support Team</p>
                </body>
            </html>
            '''
    elif hourly_variance_df.count() > 0 :
        a1=table_format(hourly_variance_df.toPandas())
        html=f'''
            <html>
                <body>
                    <p><b><u>Gam API vs Silver Table Validation:</u></b></p>
                    <p><b>Below is the validation between GAM UI and SIlver layer tables</b></p>

                    <p>The below mentioned dates have variance greater than 0.1%

                    </p>
                    <table border=1>{a1}</table>
                    </p>
                    <p>Please find attached the {report.info['human_readable_name']}.</p>
                    <p>Regards,<br>
                    Data Ops Support Team</p>
                </body>
            </html>
            '''
    elif geo_variance_df.count() > 0 :
        a2=table_format(geo_variance_df.toPandas())
        html=f'''
            <html>
                <body>
                    <p><b><u>Gam API vs Silver Table Validation:</u></b></p>
                    <p><b>Below is the validation between GAM UI and SIlver layer tables</b></p>

                    <p>The below mentioned dates have variance greater than 0.1%

                    </p>
                    <table border=1>{a2}</table>
                    </p>
                    <p>Please find attached the {report.info['human_readable_name']}.</p>
                    <p>Regards,<br>
                    Data Ops Support Team</p>
                </body>
            </html>
            '''
    else:
        html=f'''
            <html>
                <body>
                    <p><b><u>Gam API vs Silver Table Validation:</u></b></p>
                    <p><b>No Variance Found</b></p>
                    <p>Regards,<br>
                    Data Ops Support Team</p>
                    <p>Please find attached the {report.info['human_readable_name']}.</p>
                </body>
            </html>
            '''

    msg.attach(MIMEText(html, "html"))

    session = boto3.Session(profile_name = aws_profile)
    ses = session.client('ses', region_name='us-west-2')
    ses.send_raw_email(
        Source=msg['From'],
        Destinations=list(set(report.info['to']).union(set(report.info['cc']))),
        RawMessage={'Data': msg.as_string()}
    )

    print('Email sent')

# COMMAND ----------

def validation_comparison(src_final_df, tar_final_df, joining_cols):
    validation_df = src_final_df.join(spark.createDataFrame(tar_final_df), on=joining_cols, how='left')
    # Replace nulls in Delivered Impressions/Clicks with 0 for calculation
    validation_df = validation_df.withColumn(
        'Delivered Impressions', F.coalesce(F.col('Delivered Impressions'), F.lit(0))
    ).withColumn(
        'Delivered Clicks', F.coalesce(F.col('Delivered Clicks'), F.lit(0))
    )
    # Impressions Variance %
    validation_df = validation_df.withColumn(
        'Impressions Variance %',
        F.when(F.col('Delivered Impressions') == 0,
               F.when(F.col('total_line_item_level_impressions') == 0, F.lit(0.0)).otherwise(F.lit(100.0)))
        .otherwise(F.round((F.col('total_line_item_level_impressions') - F.col('Delivered Impressions')) / F.col('Delivered Impressions') * 100, 3))
    )
    # Clicks Variance %
    validation_df = validation_df.withColumn(
        'Clicks Variance %',
        F.when(F.col('Delivered Clicks') == 0,
               F.when(F.col('total_line_item_level_clicks') == 0, F.lit(0.0)).otherwise(F.lit(100.0)))
        .otherwise(F.round((F.col('total_line_item_level_clicks') - F.col('Delivered Clicks')) / F.col('Delivered Clicks') * 100, 3))
    )
    validation_df = validation_df.sort('Event Date')

    variance_df = validation_df.filter(
        "`Impressions Variance %` >= 0.1 or `Clicks Variance %` >= 0.1 or `Impressions Variance %` <= -0.1 or `Clicks Variance %` <= -0.1"
    )

    return validation_df, variance_df

# COMMAND ----------

if __name__ == '__main__':

    
    hourly_validation_df, hourly_variance_df = validation_comparison(src_hourly_df, tar_hourly_df, ['Event Date', 'Event Hour'])

    geo_validation_df, geo_variance_df = validation_comparison(src_geo_df, tar_geo_df, ['Event Date', 'Country Name'])

    display(hourly_variance_df)
    display(geo_variance_df)
    
    buf = io.BytesIO()

    with pd.ExcelWriter(buf, engine="xlsxwriter") as writer:
        # Save df1 to 'Sheet1'
        geo_validation_df.toPandas().to_excel(writer, sheet_name='geo', index=False)
        # Save df2 to 'Sheet2'
        hourly_validation_df.toPandas().to_excel(writer, sheet_name='hourly', index=False)

    validation_data = buf.getvalue()

    report = 'GAM Geo and Hourly Daily Data Validation Report' +'_' + datetime.today().strftime('%d%b%Y') + '.xlsx'
    session = boto3.Session(profile_name=aws_profile)
    s3_client = session.client('s3')
    s3_bucket = cpe_s3_bucket
    s3_key = 'gam_analytics/' + report
    s3_client.put_object(
        Bucket=s3_bucket,
        Body=validation_data,
        Key=s3_key,
    )

    send_mail('GAM Validation Report', datetime.today(), hourly_variance_df, geo_variance_df)

    
    
