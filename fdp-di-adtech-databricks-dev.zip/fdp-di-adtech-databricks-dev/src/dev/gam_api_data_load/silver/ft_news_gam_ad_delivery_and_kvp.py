# Databricks notebook source
catalog='fox_bi_dev'
raw_schema='raw_ads'
silver_schema='silver_ads'

# COMMAND ----------

dbutils.widgets.text("event_start_date", "")
dbutils.widgets.text("event_end_date", "")

event_start_date = dbutils.widgets.get("event_start_date")
event_end_date = dbutils.widgets.get("event_end_date")

# COMMAND ----------

query=f"""
SELECT 
        event_date,
        COALESCE(ad_unit_id,-1) AS ad_unit_id,
        LOWER(targeting_key) AS targeting_key,
        COALESCE(targeting_value,'N/A') AS targeting_value,
        total_active_view_measurable_impressions,
        total_active_view_viewable_impressions,
        total_active_view_eligible_impressions,
        total_line_item_level_clicks,
        ad_exchange_active_view_measurable_impressions,
        ad_exchange_active_view_viewable_impressions,
        ad_exchange_active_view_eligible_impressions,
        total_code_served_count,
        'News gam' AS authority_code,
        4145 AS network_group_id
    FROM {catalog}.{raw_schema}.news_gam_api_ad_delivery_and_kvp_daily
    WHERE where event_date>='{event_start_date}' and event_date<='{event_end_date}'
    and LOWER(targeting_key) IN (
        'c',
        'people',
        'app_version',
        'categories',
        'url'
    )
"""
df=spark.sql(query)
df.createOrReplaceTempView("src_tbl")

# COMMAND ----------

result_query = f"""
SELECT   /*+ BROADCAST(au) */ 
        ft.event_date,
        COALESCE(ft.authority_code, 'N/A') AS authority_code,
        COALESCE(ft.network_group_id, -1) AS network_group_id,
        COALESCE(ft.ad_unit_id, -1) AS ad_unit_id,
        au.ad_unit_name,
        au.ad_category_name,
        au.ad_format_name,
        au.ad_detail_name,
        au.page_type_name,
        au.section_name,
        au.site_name_abbreviation,
        au.site_name,
        au.distributor_name,
        au.platform_name,
        au.platform_group,
        au.business_unit,
        ft.targeting_key,
        ft.targeting_value,

        SUM(ft.total_active_view_measurable_impressions) AS total_active_view_measurable_impressions,
        SUM(ft.total_active_view_viewable_impressions) AS total_active_view_viewable_impressions,
        SUM(ft.total_active_view_eligible_impressions) AS total_active_view_eligible_impressions,
        SUM(ft.total_line_item_level_clicks) AS total_line_item_level_clicks,
        SUM(ft.ad_exchange_active_view_measurable_impressions) AS ad_exchange_active_view_measurable_impressions,
        SUM(ft.ad_exchange_active_view_viewable_impressions) AS ad_exchange_active_view_viewable_impressions,
        SUM(ft.ad_exchange_active_view_eligible_impressions) AS ad_exchange_active_view_eligible_impressions,
        SUM(ft.total_code_served_count) AS total_code_served_count,
        CURRENT_TIMESTAMP() AS etl_created_at_timestamp_utc,
        CURRENT_TIMESTAMP() AS etl_updated_at_timestamp_utc

    FROM src_tbl ft
    LEFT JOIN {catalog}.{silver_schema}.dim_ad_unit au
        ON ft.ad_unit_id = au.ad_unit_id
        AND au.network_group_id = 4145
    GROUP BY
        all
"""

result_df=spark.sql(result_query)

# COMMAND ----------

result_df.write.format('delta')\
    .mode('overwrite')\
    .partitionBy('event_date') \
    .option('partitionOverwriteMode', 'dynamic')\
    .saveAsTable(f'{catalog}.{silver_schema}.ft_news_gam_ad_delivery_and_kvp')
