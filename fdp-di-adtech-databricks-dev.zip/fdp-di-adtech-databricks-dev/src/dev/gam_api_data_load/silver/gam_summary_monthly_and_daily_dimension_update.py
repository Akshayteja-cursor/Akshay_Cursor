# Databricks notebook source
# MAGIC %sql
# MAGIC MERGE INTO fox_bi_dev.silver_ads.ft_gam_summary_daily_data AS t
# MAGIC USING (
# MAGIC     SELECT DISTINCT
# MAGIC          line_item_id
# MAGIC          , line_item_name
# MAGIC          , line_item_start_timestamp
# MAGIC          , line_item_end_timestamp
# MAGIC          , line_item_type
# MAGIC     FROM fox_bi_dev.silver_ads.dim_line_item
# MAGIC ) AS s
# MAGIC ON t.line_item_id = s.line_item_id
# MAGIC WHEN MATCHED AND (
# MAGIC     t.line_item_name != s.line_item_name OR
# MAGIC     t.line_item_start_timestamp != s.line_item_start_timestamp OR
# MAGIC     t.line_item_end_timestamp != s.line_item_end_timestamp OR
# MAGIC     t.line_item_type != s.line_item_type
# MAGIC )
# MAGIC THEN UPDATE SET
# MAGIC     t.line_item_name = s.line_item_name,
# MAGIC     t.line_item_start_timestamp = s.line_item_start_timestamp,
# MAGIC     t.line_item_end_timestamp = s.line_item_end_timestamp,
# MAGIC     t.line_item_type = s.line_item_type

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO fox_bi_dev.silver_ads.ft_gam_summary_monthly_data AS t
# MAGIC USING (
# MAGIC     SELECT DISTINCT
# MAGIC          line_item_id
# MAGIC          , line_item_name
# MAGIC          , line_item_start_timestamp
# MAGIC          , line_item_end_timestamp
# MAGIC          , line_item_type
# MAGIC     FROM fox_bi_dev.silver_ads.dim_line_item
# MAGIC ) AS s
# MAGIC ON t.line_item_id = s.line_item_id
# MAGIC WHEN MATCHED AND (
# MAGIC     t.line_item_name != s.line_item_name OR
# MAGIC     t.line_item_start_timestamp != s.line_item_start_timestamp OR
# MAGIC     t.line_item_end_timestamp != s.line_item_end_timestamp OR
# MAGIC     t.line_item_type != s.line_item_type
# MAGIC )
# MAGIC THEN UPDATE SET
# MAGIC     t.line_item_name = s.line_item_name,
# MAGIC     t.line_item_start_timestamp = s.line_item_start_timestamp,
# MAGIC     t.line_item_end_timestamp = s.line_item_end_timestamp,
# MAGIC     t.line_item_type = s.line_item_type

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO fox_bi_qa.gold_ad_sales.ft_gam_summary_daily AS t
# MAGIC USING (
# MAGIC     SELECT DISTINCT
# MAGIC         line_item_id
# MAGIC         , line_item_name
# MAGIC         , line_item_start_timestamp
# MAGIC         , line_item_end_timestamp
# MAGIC         , line_item_type
# MAGIC     FROM fox_bi_dev.silver_ads.dim_line_item
# MAGIC ) AS s
# MAGIC ON t.line_item_id = s.line_item_id
# MAGIC WHEN MATCHED AND (
# MAGIC     t.line_item_name != s.line_item_name OR
# MAGIC     t.line_item_start_datetime != s.line_item_start_timestamp OR
# MAGIC     t.line_item_end_datetime != s.line_item_end_timestamp OR
# MAGIC     t.line_item_type != s.line_item_type
# MAGIC )
# MAGIC THEN UPDATE SET
# MAGIC     t.line_item_name = s.line_item_name,
# MAGIC     t.line_item_start_datetime = s.line_item_start_timestamp,
# MAGIC     t.line_item_end_datetime = s.line_item_end_timestamp,
# MAGIC     t.line_item_type = s.line_item_type