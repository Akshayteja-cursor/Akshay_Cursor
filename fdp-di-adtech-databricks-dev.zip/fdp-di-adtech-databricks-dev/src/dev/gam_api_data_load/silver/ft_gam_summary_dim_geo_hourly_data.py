# Databricks notebook source
def get_widget_or_none(name):
    try:
        return dbutils.widgets.get(name)
    except Exception:
        return None
      
env = dbutils.widgets.get('env')
report_name = get_widget_or_none('report_name')

hourly_silver_start_date = get_widget_or_none('hourly_silver_start_date')
hourly_silver_end_date = get_widget_or_none('hourly_silver_end_date')

geo_silver_start_date = get_widget_or_none('geo_silver_start_date')
geo_silver_end_date = get_widget_or_none('geo_silver_end_date')

if report_name == 'Summary with Hourly Impressions and Clicks':
  hourly_silver_start_date = dbutils.widgets.get('hourly_silver_start_date')
  hourly_silver_end_date = dbutils.widgets.get('hourly_silver_end_date')

elif report_name == 'Summary with Geo Impressions and Clicks':
  geo_silver_start_date = dbutils.widgets.get('geo_silver_start_date')
  geo_silver_end_date = dbutils.widgets.get('geo_silver_end_date')

# COMMAND ----------

hourly_qry=f'''
        SELECT
              gam.line_item_id
            , gam.line_item_name
            , gam.event_date
            , gam.hour as event_hour
            , core_data.program_foxipedia_id
            , core_data.program_name AS show_name
            , SUM(gam.total_line_item_level_impressions) AS total_impressions
            , SUM(gam.total_line_item_level_clicks) AS total_clicks
            , CURRENT_TIMESTAMP() as etl_created_timestamp 
            , CURRENT_TIMESTAMP() as etl_updated_timestamp
        FROM fox_bi_{env}.raw_ads.gam_api_summary_with_hourly_impressions_and_clicks gam
        LEFT JOIN (select distinct 
                  from_utc_timestamp(a.air_date_time, 'America/New_York')::DATE as air_date_est,
                  HOUR(from_utc_timestamp(a.air_date_time, 'America/New_York')) as air_hour_est,
                  concat_ws(' | ', array_sort(collect_set(b.title_name))) as program_name,
                  concat_ws(' | ', array_sort(collect_set(CAST(a.program_foxipedia_id AS STRING)))) as program_foxipedia_id
                  from fox_bi_prod.core_data.dm_program_schedule a 
                  inner join fox_bi_prod.core_data.dm_title b
                  on a.program_foxipedia_id = b.title_id 
                  where network_name = 'Fox News' 
                        and upper(status) = 'SCHEDULED' 
                  group by all) core_data
        ON gam.event_date = core_data.air_date_est
        AND core_data.air_hour_est = gam.hour

        WHERE gam.event_date >= '{hourly_silver_start_date}' 
              AND gam.event_date <= '{hourly_silver_end_date}'
        GROUP BY ALL
'''

geo_qry=f'''
        SELECT
              geo_imp.line_item_id
            , geo_imp.city_criteria_id
            , geo_imp.event_date
            , geo_imp.line_item_name
            , geo.city as city_name
            , geo.neighborhood as neighborhood_name
            , coalesce(geo.state, geo.province) as state_province_name
            , geo.country as country_name
            , SUM(geo_imp.total_line_item_level_impressions) AS total_impressions
            , SUM(geo_imp.total_line_item_level_clicks) AS total_clicks
            , CURRENT_TIMESTAMP() as etl_created_timestamp 
            , CURRENT_TIMESTAMP() as etl_updated_timestamp
        FROM      fox_bi_{env}.raw_ads.gam_api_summary_with_geo_impressions_and_clicks as geo_imp
        LEFT JOIN fox_bi_{env}.raw_ads.gam_api_geo_data as geo 
                  ON geo_imp.city_criteria_id = geo.ID 
        WHERE geo_imp.event_date >= '{geo_silver_start_date}' 
              AND geo_imp.event_date <= '{geo_silver_end_date}'
        GROUP BY ALL 
'''

dim_qry=f'''
        SELECT
            coalesce(gam.order_id, -1) as order_id
            , coalesce(gam.line_item_id, -1) as line_item_id
            , coalesce(gam.advertiser_id, -1) as advertiser_id
            , coalesce(gam.order_name, 'N/A') as order_name
            , coalesce(gam.line_item_name, 'N/A') as line_item_name
            , coalesce(gam.line_item_type, 'N/A') as line_item_type
            , coalesce(gam.advertiser_name, 'N/A') as advertiser_name
            , CURRENT_TIMESTAMP() as etl_created_timestamp 
            , CURRENT_TIMESTAMP() as etl_updated_timestamp
        FROM fox_bi_{env}.raw_ads.gam_api_dimensions_line_item_level gam
        GROUP BY ALL
'''

# COMMAND ----------

if report_name == 'Summary with Hourly Impressions and Clicks':
    print(report_name)
    print(hourly_silver_start_date)
    print(hourly_silver_end_date)
    gam_hourly = spark.sql(hourly_qry)

    # Fill in missing values with N/A
    string_cols_with_missing_values = [
        'line_item_name',
        'show_name'
    ]

    id_cols_with_missing_values = [
        'line_item_id'
    ]

    gam_hourly = gam_hourly.fillna('N/A', subset=string_cols_with_missing_values)
    gam_hourly = gam_hourly.fillna(-1, subset=id_cols_with_missing_values)

    gam_hourly.write.format('delta')\
        .mode('overwrite')\
        .option('partitionOverwriteMode', 'dynamic')\
        .saveAsTable(f'fox_bi_{env}.silver_ads.ft_gam_summary_hourly_data')
    print("Updated table ft_gam_summary_hourly_data")

elif report_name == 'Summary with Geo Impressions and Clicks':
    print(report_name)
    print(geo_silver_start_date)
    print(geo_silver_end_date)
    gam_geo_daily = spark.sql(geo_qry)

    # Fill in missing values with N/A
    string_cols_with_missing_values = [
        'line_item_name',
        'city_name',
        'neighborhood_name',
        'state_province_name',
        'country_name'
    ]

    id_cols_with_missing_values = [
        'line_item_id',
        'city_criteria_id'
    ]

    gam_geo_daily = gam_geo_daily.fillna('N/A', subset=string_cols_with_missing_values)
    gam_geo_daily = gam_geo_daily.fillna(-1, subset=id_cols_with_missing_values)

    gam_geo_daily.write.format('delta')\
        .mode('overwrite')\
        .option('partitionOverwriteMode', 'dynamic')\
        .saveAsTable(f'fox_bi_{env}.silver_ads.ft_gam_summary_daily_geo_data')
    print("Updated table ft_gam_summary_daily_geo_data")

elif report_name == 'Dimensions line item level':
    print(report_name)
    gam_dim = spark.sql(dim_qry)

    gam_dim.createOrReplaceTempView("gam_api_dim_df")
    df_sql=f'''MERGE INTO fox_bi_{env}.silver_ads.dim_gam_line_item_data AS target
                USING gam_api_dim_df AS source
                ON target.order_id = source.order_id
                AND target.line_item_id = source.line_item_id
                WHEN MATCHED THEN UPDATE SET
                    target.order_id = source.order_id,
                    target.order_name = source.order_name,
                    target.line_item_id = source.line_item_id,
                    target.line_item_name = source.line_item_name,
                    target.line_item_type = source.line_item_type,
                    target.advertiser_id = source.advertiser_id,
                    target.advertiser_name = source.advertiser_name,
                    target.etl_updated_timestamp = source.etl_updated_timestamp
                WHEN NOT MATCHED THEN INSERT *
                '''
    spark.sql(df_sql)
    print("Updated table dim_gam_line_item_data")


