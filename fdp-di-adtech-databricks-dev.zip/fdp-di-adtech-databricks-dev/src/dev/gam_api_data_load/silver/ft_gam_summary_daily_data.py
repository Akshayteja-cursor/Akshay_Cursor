# Databricks notebook source
from pyspark.sql import functions as F
from pyspark.sql import types as T
from datetime import datetime, timedelta

# COMMAND ----------

# Load configuration values
event_start_date = dbutils.widgets.get("event_start_date")
event_end_date = dbutils.widgets.get("event_end_date")

# COMMAND ----------

query = f"""
    SELECT
        /*+ BROADCAST(adv, li, or, au) */
        summary_impressions.line_item_id
        , li.line_item_name
        , li.line_item_start_timestamp
        , li.line_item_start_timestamp_type
        , li.line_item_end_timestamp
        , li.line_item_type
        , li.contracted_units_bought_qty
        , summary_impressions.advertiser_id
        , adv.advertiser_name
        , COALESCE(summary_impressions.country_id, summary_unmatched_ad_requests.country_id) AS country_id
        , COALESCE(summary_impressions.country_name, summary_unmatched_ad_requests.country_name) as location
        , li.order_id
        , or.order_name
        , or.salesperson_id
        , or.salesperson_name
        , summary_impressions.programmatic_channel_name
        , COALESCE(summary_impressions.ad_unit_id, summary_unmatched_ad_requests.ad_unit_id) AS ad_unit_id
        , au.ad_unit_name
        , au.ad_category_name
        , au.ad_format_name
        , au.ad_detail_name
        , au.page_type_name
        , au.section_name
        , au.site_name_abbreviation
        , au.site_name
        , au.distributor_name
        , au.platform_name
        , au.platform_group
        , au.business_unit
        , COALESCE(summary_impressions.requested_ad_sizes, summary_unmatched_ad_requests.requested_ad_sizes) AS requested_ad_sizes
        , COALESCE(summary_impressions.ad_unit_id, summary_unmatched_ad_requests.ad_unit_id) AS site_section_id
        , au.ad_unit_name AS site_section_name
        , SUM(summary_impressions.total_line_item_level_impressions) AS total_impressions
        , SUM(total_line_item_level_cpm_and_cpc_revenue) AS total_cpm_and_cpc_revenue
        , SUM(video_errors_vast_error_303_count) AS vast_error_303_count
        , summary_unmatched_ad_requests.total_unmatched_ad_requests
        , summary_unmatched_ad_requests.video_viewership_total_error_count
        , SUM(
            COALESCE(summary_impressions.total_line_item_level_impressions, 0) + COALESCE(summary_unmatched_ad_requests.total_unmatched_ad_requests, 0)
        ) AS capacity_without_vast_error_303_count
        , SUM(video_viewership_start) AS video_viewership_start
        , SUM(video_viewership_complete) AS video_viewership_complete
        , SUM(total_line_item_level_clicks) AS total_clicks
        , SUM(ad_exchange_active_view_viewable_impressions) AS ad_exchange_active_view_viewable_impressions
        , SUM(ad_exchange_active_view_measurable_impressions) AS ad_exchange_active_view_measurable_impressions
        , SUM(video_viewership_first_quartile) AS video_viewership_first_quartile
        , SUM(video_viewership_midpoint) AS video_viewership_midpoint
        , SUM(video_viewership_third_quartile) AS video_viewership_third_quartile
        , SUM(video_interaction_pause) AS video_interaction_pause
        , SUM(video_interaction_resume) AS video_interaction_resume
        , SUM(video_interaction_rewind) AS video_interaction_rewind
        , SUM(video_interaction_mute) AS video_interaction_mute
        , SUM(video_interaction_unmute) AS video_interaction_unmute
        , SUM(video_interaction_full_screen) AS video_interaction_full_screen
        , SUM(total_code_served_count) AS total_code_served_count
        , COALESCE(summary_impressions.event_date, summary_unmatched_ad_requests.event_date) AS ad_date
        , DATE_FORMAT(ad_date, 'MM') as ad_month
        , DATE_FORMAT(ad_date, "y-'Q'Q") as ad_quarter
        , DATE_FORMAT(ad_date, 'y') as ad_year
        , ad_year||ad_month as ad_month_id
        , DATE_FORMAT(ad_date, 'MMMM-y') as ad_month_year
        , TO_DATE(DATE_FORMAT(CURRENT_TIMESTAMP(), 'yyyy-MM-dd'), 'yyyy-MM-dd') AS etl_load_date
        , CURRENT_TIMESTAMP() AS etl_load_timestamp_utc
    FROM (
        SELECT
            COALESCE(imps.event_date, ints.event_date, cd.event_date) AS event_date
            , COALESCE(imps.advertiser_id, ints.advertiser_id, cd.advertiser_id) AS advertiser_id
            , COALESCE(imps.line_item_id, ints.line_item_id, cd.line_item_id) AS line_item_id
            , COALESCE(imps.ad_unit_id, ints.ad_unit_id, cd.ad_unit_id) AS ad_unit_id
            , COALESCE(imps.country_id, ints.country_id, cd.country_id) AS country_id
            , COALESCE(imps.country_name, ints.country_name, cd.country_name) AS country_name
            , COALESCE(imps.programmatic_channel_name, ints.programmatic_channel_name, cd.programmatic_channel_name) AS programmatic_channel_name
            , COALESCE(imps.requested_ad_sizes, ints.requested_ad_sizes, cd.requested_ad_sizes) AS requested_ad_sizes
            , SUM(imps.total_line_item_level_impressions) AS total_line_item_level_impressions 
            , SUM(imps.video_errors_vast_error_303_count) AS video_errors_vast_error_303_count
            , SUM(imps.total_line_item_level_cpm_and_cpc_revenue) AS total_line_item_level_cpm_and_cpc_revenue
            , SUM(imps.video_viewership_start) AS video_viewership_start
            , SUM(imps.video_viewership_complete) AS video_viewership_complete
            , SUM(imps.total_line_item_level_clicks) AS total_line_item_level_clicks
            , SUM(ints.ad_exchange_active_view_viewable_impressions) AS ad_exchange_active_view_viewable_impressions
            , SUM(ints.ad_exchange_active_view_measurable_impressions) AS ad_exchange_active_view_measurable_impressions
            , SUM(ints.video_viewership_first_quartile) AS video_viewership_first_quartile
            , SUM(ints.video_viewership_midpoint) AS video_viewership_midpoint
            , SUM(ints.video_viewership_third_quartile) AS video_viewership_third_quartile
            , SUM(ints.video_interaction_pause) AS video_interaction_pause
            , SUM(ints.video_interaction_resume) AS video_interaction_resume
            , SUM(ints.video_interaction_rewind) AS video_interaction_rewind
            , SUM(ints.video_interaction_mute) AS video_interaction_mute
            , SUM(ints.video_interaction_unmute) AS video_interaction_unmute
            , SUM(ints.video_interaction_full_screen) AS video_interaction_full_screen
            , SUM(cd.total_code_served_count) AS total_code_served_count
        FROM fox_bi_dev.raw_ads.gam_api_summary_with_impressions_and_error_count imps
        FULL OUTER JOIN fox_bi_dev.raw_ads.gam_api_summary_with_intractions_and_viewership ints
        ON imps.event_date = ints.event_date
        AND imps.ad_unit_id = ints.ad_unit_id
        AND imps.requested_ad_sizes = ints.requested_ad_sizes
        AND imps.country_id = ints.country_id
        AND imps.line_item_id = ints.line_item_id
        AND imps.programmatic_channel_name = ints.programmatic_channel_name
        FULL OUTER JOIN fox_bi_dev.raw_ads.gam_api_summary_with_code_served cd
        ON imps.event_date = cd.event_date
        AND imps.ad_unit_id = cd.ad_unit_id
        AND imps.requested_ad_sizes = cd.requested_ad_sizes
        AND imps.country_id = cd.country_id
        AND imps.line_item_id = cd.line_item_id
        AND imps.programmatic_channel_name = cd.programmatic_channel_name
        WHERE imps.event_date >= '{event_start_date}' AND imps.event_date <= '{event_end_date}'
        GROUP BY
            COALESCE(imps.event_date, ints.event_date, cd.event_date)
            , COALESCE(imps.advertiser_id, ints.advertiser_id, cd.advertiser_id)
            , COALESCE(imps.line_item_id, ints.line_item_id, cd.line_item_id)
            , COALESCE(imps.ad_unit_id, ints.ad_unit_id, cd.ad_unit_id)
            , COALESCE(imps.country_id, ints.country_id, cd.country_id)
            , COALESCE(imps.country_name, ints.country_name, cd.country_name)
            , COALESCE(imps.programmatic_channel_name, ints.programmatic_channel_name, cd.programmatic_channel_name)
            , COALESCE(imps.requested_ad_sizes, ints.requested_ad_sizes, cd.requested_ad_sizes)
    ) as summary_impressions
    FULL OUTER JOIN (
        SELECT
            event_date
            , ad_unit_id
            , country_id
            , country_name
            , requested_ad_sizes
            , SUM(total_unmatched_ad_requests) AS total_unmatched_ad_requests
            , SUM(video_viewership_total_error_count) AS video_viewership_total_error_count
        FROM fox_bi_dev.raw_ads.gam_api_summary_with_unmatched_ad_requests
        WHERE event_date >= '{event_start_date}' AND event_date <= '{event_end_date}'
        GROUP BY
            event_date
            , ad_unit_id
            , country_id
            , country_name
            , requested_ad_sizes
    ) as summary_unmatched_ad_requests
    ON summary_impressions.event_date = summary_unmatched_ad_requests.event_date
    AND summary_impressions.ad_unit_id = summary_unmatched_ad_requests.ad_unit_id
    AND summary_impressions.country_id = summary_unmatched_ad_requests.country_id
    AND summary_impressions.requested_ad_sizes = summary_unmatched_ad_requests.requested_ad_sizes
    LEFT JOIN fox_bi_dev.silver_ads.dim_advertiser adv
    ON summary_impressions.advertiser_id = adv.advertiser_id
    AND adv.network_group_id = 4145
    LEFT JOIN fox_bi_dev.silver_ads.dim_line_item li
    ON summary_impressions.line_item_id = li.line_item_id
    AND li.network_group_id = 4145
    LEFT JOIN fox_bi_dev.silver_ads.dim_orders or
    ON li.order_id = or.order_id
    AND or.network_group_id = 4145
    LEFT JOIN fox_bi_dev.silver_ads.dim_ad_unit au
    ON COALESCE(summary_impressions.ad_unit_id, summary_unmatched_ad_requests.ad_unit_id) = au.ad_unit_id
    AND au.network_group_id = 4145
    GROUP BY
        summary_impressions.line_item_id
        , li.line_item_name
        , li.line_item_start_timestamp
        , li.line_item_start_timestamp_type
        , li.line_item_end_timestamp
        , li.line_item_type
        , li.contracted_units_bought_qty
        , summary_impressions.advertiser_id
        , adv.advertiser_name
        , COALESCE(summary_impressions.country_id, summary_unmatched_ad_requests.country_id)
        , location
        , li.order_id
        , or.order_name
        , or.salesperson_id
        , or.salesperson_name
        , summary_impressions.programmatic_channel_name
        , COALESCE(summary_impressions.ad_unit_id, summary_unmatched_ad_requests.ad_unit_id)
        , au.ad_unit_name
        , au.ad_category_name
        , au.ad_format_name
        , au.ad_detail_name
        , au.page_type_name
        , au.section_name
        , au.site_name_abbreviation
        , au.site_name
        , au.distributor_name
        , au.platform_name
        , au.platform_group
        , au.business_unit
        , COALESCE(summary_impressions.requested_ad_sizes, summary_unmatched_ad_requests.requested_ad_sizes)
        , ad_date
        , summary_unmatched_ad_requests.total_unmatched_ad_requests
        , summary_unmatched_ad_requests.video_viewership_total_error_count
"""

# COMMAND ----------

gam_daily = spark.sql(query)

# Fill in missing values with N/A
string_cols_with_missing_values = [
    'line_item_name',
    'line_item_start_timestamp_type',
    'line_item_type',
    'advertiser_name',
    'location',
    'order_name',
    # 'salesperson_name',
    'programmatic_channel_name',
    'ad_unit_name',
    'site_section_name',
    'ad_category_name',
    'ad_format_name',
    'ad_detail_name',
    'page_type_name',
    'section_name',
    'site_name_abbreviation',
    'site_name',
    'distributor_name',
    'platform_name',
    'platform_group'
]

id_cols_with_missing_values = [
    'line_item_id',
    'advertiser_id',
    'country_id',
    'order_id',
    'ad_unit_id',
    'site_section_id',
    'salesperson_id'
]

gam_daily = gam_daily.fillna('N/A', subset=string_cols_with_missing_values)
gam_daily = gam_daily.fillna(-1, subset=id_cols_with_missing_values)

# COMMAND ----------

# gam_daily.write.format('delta')\
#     .mode('overwrite')\
#     .partitionBy('ad_date')\
#     .option('mergeSchema', 'true')\
#     .option('overwriteDynamicPartitions', 'true')\
#     .option('delta.enableDeletionVectors', 'false')\
#     .option('delta.enableIcebergCompatV2', 'true')\
#     .option('delta.universalFormat.enabledFormats', 'iceberg')\
#     .option('delta.columnMapping.mode', 'name')\
#     .saveAsTable('fox_bi_dev.silver_ads.ft_gam_summary_daily_data')

gam_daily.write.format('delta')\
    .mode('overwrite')\
    .option('partitionOverwriteMode', 'dynamic')\
    .option("mergeSchema", "true")\
    .saveAsTable('fox_bi_dev.silver_ads.ft_gam_summary_daily_data')

# COMMAND ----------

# spark.sql('select ad_date, count(*) from fox_bi_dev.silver_ads.ft_gam_summary_daily_data group by 1 order by 1').show()