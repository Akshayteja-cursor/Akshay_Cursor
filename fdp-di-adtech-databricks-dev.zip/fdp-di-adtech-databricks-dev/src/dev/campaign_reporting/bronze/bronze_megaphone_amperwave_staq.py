# Databricks notebook source
env = dbutils.widgets.get('env')

if env == 'dev':
  catalog_name = 'fox_bi_dev'
  raw_schema_name = 'raw_ads'
  bronze_schema_name = 'bronze_ads'
elif env == 'prod':
  catalog_name = 'fox_bi_prod'
  raw_schema_name = 'raw_ads'
  bronze_schema_name = 'bronze_ads'

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql import types as T
from datetime import datetime, timedelta

# COMMAND ----------

def load_format_table(table_name):
    """
    Loads 'raw fw tables' and formats the columns names and types.
    """

    third_party_table = spark.read.table(f'{catalog_name}.{raw_schema_name}.{table_name}')
    
    column_format_info = {
        'event_date': ['event_date', T.DateType()],
        'partner_server_name': ['partner_server_name', T.StringType()],
        'advertiser_category': ['advertiser_category', T.StringType()],
        'advertiser': ['advertiser', T.StringType()],
        'order_title': ['order_title', T.StringType()],
        'order_id': ['order_id', T.StringType()],
        'order_start': ['order_start', T.DateType()],
        'order_end': ['order_end', T.DateType()],
        'order_goal': ['order_goal', T.LongType()],
        'order_cap': ['order_cap', T.StringType()],
        'order_revenue': ['order_revenue', T.LongType()],
        'campaign_title': ['campaign_title', T.StringType()],
        'campaign_id': ['campaign_id', T.StringType()],
        'campaign_budget_currency': ['campaign_budget_currency', T.StringType()],
        'network_name': ['network_name', T.StringType()],
        'ad_location': ['ad_location', T.StringType()],
        'network_id': ['network_id', T.StringType()],
        'podcast_title': ['podcast_title', T.StringType()],
        'ad_title': ['ad_title', T.StringType()],
        'advertisement_id': ['advertisement_id', T.StringType()],
        'ad_position': ['ad_position', T.DoubleType()],
        'delivered_impressions': ['delivered_impressions', T.LongType()],
        'available_impressions': ['available_impressions', T.LongType()],
        'direct_sold_impressions': ['direct_sold_impressions', T.LongType()],
        'span_impressions': ['span_impressions', T.LongType()],
        'promo_impressions': ['promo_impressions', T.LongType()],
    }

    cols_to_be_formated_to_int = [
        'Uniques',
        'order_goal',
        'order_revenue',
        'delivered_impressions',
        'available_impressions',
        'direct_sold_impressions',
        'span_impressions',
        'promo_impressions',
    ]

    cols_to_be_formated_to_float = [

    ]

    select_cols = []
    for col in third_party_table.columns:
        # if col != 'created_at' and col != 'updated_at':
        if col in column_format_info:
            select_cols.append(column_format_info[col][0])
            if col in cols_to_be_formated_to_int:
                third_party_table = third_party_table.withColumn(col,
                    F#.when(third_party_table[col] == 'N/A', F.lit(None).cast(T.LongType()))\
                    .when(third_party_table[col].isNull(), F.lit(0).cast(T.LongType()))\
                    .when(third_party_table[col].contains('.'), F.to_number(F.split(F.col(col), '\\.', 2)[0], F.lit('99999999999')))\
                    .when(third_party_table[col].contains(','), F.to_number(F.col(col), F.lit('999,999,999,999,999')))\
                    .otherwise(F.to_number(F.col(col), F.lit('999999999999999')))
                )
            elif col in cols_to_be_formated_to_float:
                third_party_table = third_party_table.withColumn(col,
                    F#.when(third_party_table[col] == 'N/A', F.lit(None).cast(T.DoubleType()))\
                    .when(third_party_table[col].isNull(), F.lit(0).cast(T.DoubleType()))\
                    .otherwise(F.to_number(F.trim(F.col(col)), F.lit('S999,999,999,999,999.99999')))
                )
            elif col in ['order_start', 'order_end', 'date']:
                third_party_table = third_party_table.withColumn(col, F.when(F.col(col).isNull(), F.lit(None)).otherwise(F.to_date(F.col(col), 'yyyy-MM-dd')))
            elif col in ['ad_position']:
                pass
            else:
                third_party_table = third_party_table.withColumn(col,
                    F.when(third_party_table[col].isNull(), F.lit('N/A').cast(T.StringType()))\
                    .otherwise(F.col(col).cast(column_format_info[col][1])))
        else:
            print('Column not selected : ', col)
    print('completed')
    return third_party_table.select(select_cols)

# COMMAND ----------

if __name__ == '__main__':
    tables = [
        'megaphone_amperwave_campaign_reporting_delivery'
    ]

    for table_name in tables:
        print(f'Processing table: {table_name}')
        formated_table = load_format_table(table_name)
        formated_table =formated_table.withColumnRenamed('partner name', 'partner_name') \
                            .withColumnRenamed('order_start', 'order_start_date') \
                            .withColumnRenamed('order_end', 'order_end_date') \
                            .withColumnRenamed('order_goal', 'order_goal_amount') \
                            .withColumnRenamed('order_revenue', 'order_revenue_amount')
        display(formated_table)
        if not spark.catalog.tableExists(f'{catalog_name}.{bronze_schema_name}.{table_name}'):
            formated_table.write.format('delta')\
                .mode('overwrite')\
                .partitionBy('event_date')\
                .option('mergeSchema', 'true')\
                .option('overwriteDynamicPartitions', 'true')\
                .option('delta.enableDeletionVectors', 'false')\
                .option('delta.enableIcebergCompatV2', 'true')\
                .option('delta.universalFormat.enabledFormats', 'iceberg')\
                .option('delta.columnMapping.mode', 'name')\
                .saveAsTable(f"{catalog_name}.{bronze_schema_name}.{table_name}")
        else:
            formated_table.write.format('delta')\
                .mode('overwrite')\
                .option('partitionOverwriteMode', 'dynamic')\
                .option('mergeSchema', 'true')\
                .saveAsTable(f"{catalog_name}.{bronze_schema_name}.{table_name}")
