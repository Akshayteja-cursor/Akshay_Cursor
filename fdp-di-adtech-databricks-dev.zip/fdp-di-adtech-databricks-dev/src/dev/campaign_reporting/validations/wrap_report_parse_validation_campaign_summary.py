# Databricks notebook source
spark.conf.set("spark.databricks.remoteFiltering.blockSelfJoins", "false")

# COMMAND ----------

# MAGIC %md
# MAGIC # Parse for Campaign_Summary Validation
# MAGIC

# COMMAND ----------

# Databricks notebook Target
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from datetime import datetime, date
import os
import pandas as pd

# COMMAND ----------

# Configuration
catalog_name = 'fox_bi_qa'
env = 'dev'  # or 'qa' or 'prod'


# Target: Aggregate field10 from wrap_detailed_unified_report_sections_by_deal
# Filter for CAMPAIGN_SUMMARY data_type and sum field10 (which contains Total_Delivered_Impressions as string)
tar_df_cs = spark.sql(f"""
    SELECT 
        AOS_Deal_ID,
        field2 as `Target AOS_Deal_Name`,
        field3 as `Target Advertiser Name`,
        field4 as `Target Agency Name`,
        field5 as `Target AOS Deal Start Date`,
        field6 as `Target AOS Deal End Date`,     
        SUM(try_cast(field7 AS BIGINT)) as `Target Total Placements`,
        SUM(try_cast(field8 AS BIGINT)) as `Target Total Creatives`,
        SUM(try_cast(field9 AS BIGINT)) as `Target Total Shows`,        
        SUM(try_cast(field10 AS BIGINT)) as `Target Total Delivered Impressions`,
        SUM(try_cast(field11 AS DECIMAL(19,2))) as `Target Total Delivered Revenue`,
        SUM(try_cast(field12 AS BIGINT)) as `Target Total Delivered Clicks`,
        SUM(try_cast(field13 AS BIGINT)) as `Target Total Guaranteed Impressions`,
        SUM(try_cast(field14 AS DECIMAL(19,2))) as `Target Budget`,
        SUM(try_cast(field15 AS DECIMAL(19,2))) as `Target CPM`,
        SUM(try_cast(field16 AS DECIMAL(19,2))) as `Target CTR`,
        SUM(try_cast(field17 AS BIGINT)) as `Target Total Countries`,
        SUM(try_cast(field18 AS BIGINT)) as `Target Total States`,
        SUM(try_cast(field19 AS BIGINT)) as `Target Total Geo Ads`,        
        SUM(try_cast(field20 AS DECIMAL(19,2))) as `Target Impression Pacing`,
        SUM(try_cast(field21 AS DECIMAL(19,2))) as `Target Revenue Pacing`,
        SUM(try_cast(field23 AS BIGINT)) as `Target Total Third Party Impressions`,
        SUM(try_cast(field24 AS DECIMAL(19,2))) as `Target Total Third Party Revenue`,
        SUM(try_cast(field28 AS DECIMAL(19,2))) as `Target Third Party Revenue Pacing`,
        SUM(try_cast(field29 AS DECIMAL(19,2))) as `Target Third Party CPM`
    FROM {catalog_name}.gold_ad_sales.v_wrap_detailed_unified_report_sections_by_deal
    WHERE data_type = 'CAMPAIGN_SUMMARY'
    GROUP BY AOS_Deal_ID, field2, field3, field4, field5, field6
""")

display(tar_df_cs)


# Source: Get Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
src_df_cs = spark.sql(f"""
    SELECT 
        `AOS Deal ID` as AOS_Deal_ID,
        `AOS Deal Name` as `Source AOS_Deal_Name`,
        `Advertiser Name` as `Source Advertiser Name`,
        `Agency Name` as `Source Agency Name`,
        `AOS Deal Start Date` as `Source AOS Deal Start Date`,
        `AOS Deal End Date` as `Source AOS Deal End Date`,
        `Total Placements` as `Source Total Placements`,
        `Total Creatives` as `Source Total Creatives`,
        `Total Shows` as `Source Total Shows`,
        `Total First Party Delivered Impressions` as `Source Total Delivered Impressions`,
        `Total First Party Delivered Revenue` as `Source Total Delivered Revenue`,
        `Total Delivered Clicks` as `Source Total Delivered Clicks`,
        `Total Guaranteed Impressions` as `Source Total Guaranteed Impressions`,
        `Budget` as `Source Budget`,
        `First Party CPM` as `Source CPM`,
        `CTR` as `Source CTR`,
        `Total Countries` as `Source Total Countries`,
        `Total States` as `Source Total States`,
        `Total Geo Ads` as `Source Total Geo Ads`,
        `First Party Revenue Pacing` as `Source Revenue Pacing`,
        `Impression Pacing` as `Source Impression Pacing`,
        `Total Third Party Impressions` as `Source Total Third Party Impressions`,
        `Total Third Party Revenue` as `Source Total Third Party Revenue`,
        `Third Party Revenue Pacing` as `Source Third Party Revenue Pacing`,
        `Third Party CPM` as `Source Third Party CPM`
    FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal
    WHERE `AOS Deal ID` IS NOT NULL
        AND `AOS Deal ID` != -1
""")

display(src_df_cs)

### Validation Comparison

from pyspark.sql.functions import col, when, expr, nvl, abs, lit

# Join source and target on AOS_Deal_ID
joined_df_cs = src_df_cs.join(
    tar_df_cs,
    on="AOS_Deal_ID",
    how="full_outer"
)

display(joined_df_cs)


# Add comparison columns
validation_df_cs = joined_df_cs.withColumn(
    "Source_Total_Delivered_Impressions",
    nvl(col("`Source Total Delivered Impressions`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Impressions",
    nvl(col("`Target Total Delivered Impressions`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Revenue",
    nvl(col("`Source Total Delivered Revenue`"), lit(0))
).withColumn(
  "Target_Total_Delivered_Revenue",
  nvl(col("`Target Total Delivered Revenue`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Clicks",
    nvl(col("`Source Total Delivered Clicks`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Clicks",
    nvl(col("`Target Total Delivered Clicks`"), lit(0))
).withColumn(
    "Source_Total_Guaranteed_Impressions",
    nvl(col("`Source Total Guaranteed Impressions`"), lit(0))
).withColumn(
    "Target_Total_Guaranteed_Impressions",
    nvl(col("`Target Total Guaranteed Impressions`"), lit(0))
).withColumn(
    "Source_Budget",
    nvl(col("`Source Budget`"), lit(0))
).withColumn(
    "Target_Budget",
    nvl(col("`Target Budget`"), lit(0))
).withColumn(
    "Source_CPM",
    nvl(col("`Source CPM`"), lit(0))
).withColumn(
    "Target_CPM",
    nvl(col("`Target CPM`"), lit(0))
).withColumn(
    "Source_CTR",
    nvl(col("`Source CTR`"), lit(0))
).withColumn(
    "Target_CTR",
    nvl(col("`Target CTR`"), lit(0))
).withColumn(
    "Source_Total_Countries",
    nvl(col("`Source Total Countries`"), lit(0))
).withColumn(
    "Target_Total_Countries",
    nvl(col("`Target Total Countries`"), lit(0))
).withColumn(
    "Source_Total_States",
    nvl(col("`Source Total States`"), lit(0))
).withColumn(
    "Target_Total_States",
    nvl(col("`Target Total States`"), lit(0))
).withColumn(
    "Source_Total_Geo_Ads",
    nvl(col("`Source Total Geo Ads`"), lit(0))
).withColumn(
    "Target_Total_Geo_Ads",
    nvl(col("`Target Total Geo Ads`"), lit(0))
).withColumn(
    "Source_Revenue_Pacing",
    nvl(col("`Source Revenue Pacing`"), lit(0))
).withColumn(
    "Target_Revenue_Pacing",
    nvl(col("`Target Revenue Pacing`"), lit(0))
).withColumn(
    "Source_Impression_Pacing",
    nvl(col("`Source Impression Pacing`"), lit(0))
).withColumn(
    "Target_Impression_Pacing",
    nvl(col("`Target Impression Pacing`"), lit(0))
).withColumn(
    "Source_Total_Third_Party_Impressions",
    nvl(col("`Source Total Third Party Impressions`"), lit(0))
).withColumn(
    "Target_Total_Third_Party_Impressions",
    nvl(col("`Target Total Third Party Impressions`"), lit(0))
).withColumn(
    "Source_Total_Third_Party_Revenue",
    nvl(col("`Source Total Third Party Revenue`"), lit(0))
).withColumn(
    "Target_Total_Third_Party_Revenue",
    nvl(col("`Target Total Third Party Revenue`"), lit(0))
).withColumn(
    "Source_Third_Party_Revenue_Pacing",
    nvl(col("`Source Third Party Revenue Pacing`"), lit(0))
).withColumn(
    "Target_Third_Party_Revenue_Pacing",
    nvl(col("`Target Third Party Revenue Pacing`"), lit(0))
).withColumn(
    "Source_Third_Party_CPM",
    nvl(col("`Source Third Party CPM`"), lit(0))
).withColumn(
    "Target_Third_Party_CPM",
    nvl(col("`Target Third Party CPM`"), lit(0))
).withColumn(
    "Variance_Impressions",
    col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")
).withColumn(
    "Variance_Clicks",
    col("Source_Total_Delivered_Clicks") - col("Target_Total_Delivered_Clicks")
).withColumn(
    "Variance_Guaranteed_Impressions",
    col("Source_Total_Guaranteed_Impressions") - col("Target_Total_Guaranteed_Impressions")
).withColumn(
    "Variance_Budget",
    col("Source_Budget") - col("Target_Budget")
).withColumn(
    "Variance_CPM",
    col("Source_CPM") - col("Target_CPM")
).withColumn(
    "Variance_CTR",
    col("Source_CTR") - col("Target_CTR")
).withColumn(
    "Variance_Total_Countries",
    col("Source_Total_Countries") - col("Target_Total_Countries")
).withColumn(
    "Variance_Total_States",
    col("Source_Total_States") - col("Target_Total_States")
).withColumn(
    "Variance_Total_Geo_Ads",
    col("Source_Total_Geo_Ads") - col("Target_Total_Geo_Ads")
).withColumn(
    "Variance_Revenue_Pacing",
    col("Source_Revenue_Pacing") - col("Target_Revenue_Pacing")
).withColumn(
    "Variance_Revenue",
    col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")
).withColumn(
    "Variance_Impression_Pacing",
    col("Source_Impression_Pacing") - col("Target_Impression_Pacing")
).withColumn(
    "Variance_Total_Third_Party_Impressions",
    col("Source_Total_Third_Party_Impressions") - col("Target_Total_Third_Party_Impressions")
).withColumn(
    "Variance_Total_Third_Party_Revenue",
    col("Source_Total_Third_Party_Revenue") - col("Target_Total_Third_Party_Revenue")
).withColumn(
    "Variance_Third_Party_Revenue_Pacing",
    col("Source_Third_Party_Revenue_Pacing") - col("Target_Third_Party_Revenue_Pacing")
).withColumn(
    "Variance_Third_Party_CPM",
    col("Source_Third_Party_CPM") - col("Target_Third_Party_CPM")
).withColumn(
    "Impressions_Match",
    when(
        abs(col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Clicks_Match",
    when(
        abs(col("Source_Total_Delivered_Clicks") - col("Target_Total_Delivered_Clicks")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Guaranteed_Impressions_Match",
    when(
        abs(col("Source_Total_Guaranteed_Impressions") - col("Target_Total_Guaranteed_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Budget_Match",
    when(
        abs(col("Source_Budget") - col("Target_Budget")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "CPM_Match",
    when(
        abs(col("Source_CPM") - col("Target_CPM")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "CTR_Match",
    when(
        abs(col("Source_CTR") - col("Target_CTR")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Total_Countries_Match",
    when(
        abs(col("Source_Total_Countries") - col("Target_Total_Countries")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Total_States_Match",
    when(
        abs(col("Source_Total_States") - col("Target_Total_States")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Total_Geo_Ads_Match",
    when(
        abs(col("Source_Total_Geo_Ads") - col("Target_Total_Geo_Ads")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Revenue_Pacing_Match",
    when(
        abs(col("Source_Revenue_Pacing") - col("Target_Revenue_Pacing")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Impression_Pacing_Match",
    when(
        abs(col("Source_Impression_Pacing") - col("Target_Impression_Pacing")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Total_Third_Party_Impressions_Match",
    when(
        abs(col("Source_Total_Third_Party_Impressions") - col("Target_Total_Third_Party_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Total_Third_Party_Revenue_Match",
    when(
        abs(col("Source_Total_Third_Party_Revenue") - col("Target_Total_Third_Party_Revenue")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Revenue_Match",
    when(
        abs(col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Third_Party_Revenue_Pacing_Match",
    when(
        abs(col("Source_Third_Party_Revenue_Pacing") - col("Target_Third_Party_Revenue_Pacing")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Third_Party_CPM_Match",
    when(
        abs(col("Source_Third_Party_CPM") - col("Target_Third_Party_CPM")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Status",
    when(
        (col("Impressions_Match") == True) &
        (col("Clicks_Match") == True) &
        (col("Guaranteed_Impressions_Match") == True) &
        (col("Budget_Match") == True) &
        (col("CPM_Match") == True) &
        (col("CTR_Match") == True) &
        (col("Total_Countries_Match") == True) &
        (col("Total_States_Match") == True) &
        (col("Total_Geo_Ads_Match") == True) &
        (col("Revenue_Pacing_Match") == True) &
        (col("Impression_Pacing_Match") == True) &
        (col("Total_Third_Party_Impressions_Match") == True) &
        (col("Total_Third_Party_Revenue_Match") == True) &
        (col("Revenue_Match") == True) &
        (col("Third_Party_Revenue_Pacing_Match") == True) &
        (col("Third_Party_CPM_Match") == True),
        True
    ).otherwise(False)
).select(
    col("AOS_Deal_ID"),
    col("Source AOS_Deal_Name"),
    col("Target AOS_Deal_Name"),
    col("Source_Total_Delivered_Impressions"),
    col("Target_Total_Delivered_Impressions"),
    col("Variance_Impressions"),
    col("Impressions_Match"),
    col("Source_Total_Delivered_Revenue"),
    col("Source_Total_Delivered_Clicks"),
    col("Target_Total_Delivered_Clicks"),
    col("Variance_Clicks"),
    col("Clicks_Match"),
    col("Source_Total_Guaranteed_Impressions"),
    col("Target_Total_Guaranteed_Impressions"),
    col("Variance_Guaranteed_Impressions"),
    col("Guaranteed_Impressions_Match"),
    col("Source_Budget"),
    col("Target_Budget"),
    col("Variance_Budget"),
    col("Budget_Match"),
    col("Source_CPM"),
    col("Target_CPM"),
    col("Variance_CPM"),
    col("CPM_Match"),
    col("Source_CTR"),
    col("Target_CTR"),
    col("Variance_CTR"),
    col("CTR_Match"),
    col("Source_Total_Countries"),
    col("Target_Total_Countries"),
    col("Variance_Total_Countries"),
    col("Total_Countries_Match"),
    col("Source_Total_States"),
    col("Target_Total_States"),
    col("Variance_Total_States"),
    col("Total_States_Match"),
    col("Source_Total_Geo_Ads"),
    col("Target_Total_Geo_Ads"),
    col("Variance_Total_Geo_Ads"),
    col("Total_Geo_Ads_Match"),
    col("Source_Revenue_Pacing"),
    col("Target_Revenue_Pacing"),
    col("Variance_Revenue_Pacing"),
    col("Revenue_Pacing_Match"),
    col("Source_Impression_Pacing"),
    col("Target_Impression_Pacing"),
    col("Variance_Impression_Pacing"),
    col("Impression_Pacing_Match"),
    col("Source_Total_Third_Party_Impressions"),
    col("Target_Total_Third_Party_Impressions"),
    col("Variance_Total_Third_Party_Impressions"),
    col("Total_Third_Party_Impressions_Match"),
    col("Source_Total_Third_Party_Revenue"),
    col("Target_Total_Third_Party_Revenue"),
    col("Variance_Total_Third_Party_Revenue"),
    col("Total_Third_Party_Revenue_Match"),
    col("Source_Third_Party_Revenue_Pacing"),
    col("Target_Third_Party_Revenue_Pacing"),
    col("Variance_Third_Party_Revenue_Pacing"),
    col("Third_Party_Revenue_Pacing_Match"),
    col("Source_Third_Party_CPM"),
    col("Target_Third_Party_CPM"),
    col("Variance_Third_Party_CPM"),
    col("Third_Party_CPM_Match"),
    col("Source_Total_Delivered_Revenue"),
    col("Target_Total_Delivered_Revenue"),
    col("Variance_Revenue"),
    col("Revenue_Match"),
    col("Status")
)

display(validation_df_cs)



# Create a dataframe showing which columns have mismatches for deals where Status is False
mismatch_details_df_cs = validation_df_cs.withColumn(
    "Mismatched_Columns_Array",
    array(
        when(col("Impressions_Match") == False, lit("Impressions")).otherwise(lit(None)),
        when(col("Clicks_Match") == False, lit("Clicks")).otherwise(lit(None)),
        when(col("Guaranteed_Impressions_Match") == False, lit("Guaranteed_Impressions")).otherwise(lit(None)),
        when(col("Budget_Match") == False, lit("Budget")).otherwise(lit(None)),
        when(col("CPM_Match") == False, lit("CPM")).otherwise(lit(None)),
        when(col("CTR_Match") == False, lit("CTR")).otherwise(lit(None)),
        when(col("Total_Countries_Match") == False, lit("Total_Countries")).otherwise(lit(None)),
        when(col("Total_States_Match") == False, lit("Total_States")).otherwise(lit(None)),
        when(col("Total_Geo_Ads_Match") == False, lit("Total_Geo_Ads")).otherwise(lit(None)),
        when(col("Revenue_Pacing_Match") == False, lit("Revenue_Pacing")).otherwise(lit(None)),
        when(col("Impression_Pacing_Match") == False, lit("Impression_Pacing")).otherwise(lit(None)),
        when(col("Total_Third_Party_Impressions_Match") == False, lit("Total_Third_Party_Impressions")).otherwise(lit(None)),
        when(col("Total_Third_Party_Revenue_Match") == False, lit("Total_Third_Party_Revenue")).otherwise(lit(None)),
        when(col("Revenue_Match") == False, lit("Revenue")).otherwise(lit(None)),
        when(col("Third_Party_Revenue_Pacing_Match") == False, lit("Third_Party_Revenue_Pacing")).otherwise(lit(None)),
        when(col("Third_Party_CPM_Match") == False, lit("Third_Party_CPM")).otherwise(lit(None))
    )
).withColumn(
    "Mismatched_Columns_Array",
    expr("filter(Mismatched_Columns_Array, x -> x is not null)")
).withColumn(
    "Mismatched_Columns",
    concat_ws(", ", col("Mismatched_Columns_Array"))
).select(
    col("AOS_Deal_ID").alias("deal_id"),
    col("Source AOS_Deal_Name"),
    col("Target AOS_Deal_Name"),
    col("Status"),
    col("Mismatched_Columns")
).distinct()

print("=" * 80)
print(f"Deal Mismatch Details")
print(f"Total Deals with Mismatches: {mismatch_details_df_cs.count()}")
print("=" * 80)

display(mismatch_details_df_cs)



# Find deal_ids that are only in source table and not in target table
source_only_deals_cs = spark.sql(f"""
    SELECT 
        t.`AOS Deal ID` as AOS_Deal_ID,
        t.`AOS Deal Name` as `Target AOS_Deal_Name`,
        t.`Advertiser Name` as `Target Advertiser Name`,
        t.`Agency Name` as `Target Agency Name`,
        t.`AOS Deal Start Date` as `Target AOS Deal Start Date`,
        t.`AOS Deal End Date` as `Target AOS Deal End Date`,
        t.`Total Delivered Impressions` as `Target Total Delivered Impressions`,
        t.`Total Delivered Clicks` as `Target Total Delivered Clicks`,
        t.`Total Guaranteed Impressions` as `Target Total Guaranteed Impressions`,
        t.`Budget` as `Target Budget`,
        t.`CPM` as `Target CPM`,
        t.`CTR` as `Target CTR`
    FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal t
    WHERE t.`AOS Deal ID` IS NOT NULL
        AND t.`AOS Deal ID` != -1
        AND NOT EXISTS (
            SELECT 1
            FROM {catalog_name}.gold_ad_sales.v_wrap_detailed_unified_report_sections_by_deal s
            WHERE s.AOS_Deal_ID = t.`AOS Deal ID`
                AND s.data_type = 'CAMPAIGN_SUMMARY'
        )
    ORDER BY t.`AOS Deal ID`
""")

print("=" * 80)
print(f"Deal IDs only in v_ft_unified_campaign_delivery_by_deal Table (v_ft_unified_campaign_delivery_by_deal)")
print(f"Count: {source_only_deals_cs.count()}")
print("=" * 80)

display(source_only_deals_cs)


# Update mismatch_details_df_cs to include deals from source_only_deals_cs with Status = "missing deals"
# First, convert Status to string in mismatch_details_df_cs to allow "missing deals" value
mismatch_details_df_1_cs = mismatch_details_df_cs.withColumn(
    "Status",
    when(col("Status") == True, lit("True"))
    .when(col("Status") == False, lit("False"))
    .otherwise(col("Status").try_cast("string"))
)

# Create a dataframe for missing deals with the same structure as mismatch_details_df_cs
missing_deals_df_cs = source_only_deals_cs.select(
    col("AOS_Deal_ID").alias("deal_id"),
    lit("null").try_cast("string").alias("Source AOS_Deal_Name"),
    col("Target AOS_Deal_Name"),
    lit("missing deals").alias("Status"),
    lit("Deal not found in source table").alias("Mismatched_Columns")
)

# print("missing_deals")
display(missing_deals_df_cs)

display(mismatch_details_df_1_cs)

# Option 1: Use a broadcast join with a flag, then check if deal_id exists in source_only_deals_cs
from pyspark.sql.functions import broadcast

# Create a set of deal_ids from source_only_deals_cs for efficient lookup
source_only_deal_ids_cs = source_only_deals_cs.select(col("AOS_Deal_ID").alias("deal_id")).distinct()

# Join and check if deal_id exists in source_only_deals_cs
mismatch_details_df_1_cs = mismatch_details_df_1_cs.join(
    broadcast(source_only_deal_ids_cs).withColumn("is_source_only", lit(True)),
    on="deal_id",
    how="left"
).withColumn(
    "Status",
    when(col("is_source_only").isNotNull(), lit("not found in source").cast("string"))
    .otherwise(col("Status").cast("string"))
).select(
    col("deal_id"),
    col("Source AOS_Deal_Name"),
    col("Target AOS_Deal_Name"),
    col("Status").cast("string").alias("Status"),
    col("Mismatched_Columns")
)

# Union with missing_deals_df_cs to include all deals that are only in target table
mismatch_details_df_1_cs = mismatch_details_df_1_cs.unionByName(
    missing_deals_df_cs,
    allowMissingColumns=True
).distinct()

display(mismatch_details_df_1_cs)



# Create a dataframe with deal_id and CAMPAIGN_SUMMARY (True if Status is True, False otherwise)
deal_status_df_cs = mismatch_details_df_1_cs.select(
    col("deal_id"),
    col("Status").alias("CAMPAIGN_SUMMARY")
).distinct()

print("=" * 80)
print(f"Deal Status Summary")
print(f"Total Deals: {deal_status_df_cs.count()}")
print(f"Deals with CAMPAIGN_SUMMARY = True: {deal_status_df_cs.filter(col('CAMPAIGN_SUMMARY') == 'True').count()}")
print(f"Deals with CAMPAIGN_SUMMARY = False: {deal_status_df_cs.filter(col('CAMPAIGN_SUMMARY') == 'False').count()}")
print("=" * 80)

display(deal_status_df_cs)






# COMMAND ----------

deal_status_df_cs.createOrReplaceGlobalTempView("deal_status_df_cs")

# COMMAND ----------

from pyspark.sql.functions import lit, col, when, abs as spark_abs, stack, round as spark_round

# .filter(
#     col("Status") == False
# )

unpivoted_df_cs = validation_df_cs.select(
    lit("CAMPAIGN_SUMMARY").alias("parse_type"),
    col("AOS_Deal_ID").alias("aos_deal_id"),
    stack(
        lit(26),
        lit("Total_Delivered_Impressions"),
        col("Source_Total_Delivered_Impressions").cast("double"),
        col("Target_Total_Delivered_Impressions").cast("double"),
        lit(None).cast("double"),


        lit("Total_Delivered_Revenue"),
        col("Source_Total_Delivered_Revenue").cast("double"),
        col("Target_Total_Delivered_Revenue").cast("double"),
        lit(None).cast("double"),

        lit("Total_Delivered_Clicks"),
        col("Source_Total_Delivered_Clicks").cast("double"),
        col("Target_Total_Delivered_Clicks").cast("double"),
        lit(None).cast("double"),

        lit("Total_Guaranteed_Impressions"),
        col("Source_Total_Guaranteed_Impressions").cast("double"),
        col("Target_Total_Guaranteed_Impressions").cast("double"),
        lit(None).cast("double"),

        lit("Budget"),
        col("Source_Budget").cast("double"),
        col("Target_Budget").cast("double"),
        lit(None).cast("double"),

        lit("CPM"),
        col("Source_CPM").cast("double"),
        col("Target_CPM").cast("double"),
        lit(None).cast("double"),

        lit("CTR"),
        col("Source_CTR").cast("double"),
        col("Target_CTR").cast("double"),
        lit(None).cast("double"),

        lit("Total_Countries"),
        col("Source_Total_Countries").cast("double"),
        col("Target_Total_Countries").cast("double"),
        lit(None).cast("double"),

        lit("Total_States"),
        col("Source_Total_States").cast("double"),
        col("Target_Total_States").cast("double"),
        lit(None).cast("double"),

        lit("Total_Geo_Ads"),
        col("Source_Total_Geo_Ads").cast("double"),
        col("Target_Total_Geo_Ads").cast("double"),
        lit(None).cast("double"),

        lit("Revenue_Pacing"),
        col("Source_Revenue_Pacing").cast("double"),
        col("Target_Revenue_Pacing").cast("double"),
        lit(None).cast("double"),

        lit("Impression_Pacing"),
        col("Source_Impression_Pacing").cast("double"),
        col("Target_Impression_Pacing").cast("double"),
        lit(None).cast("double"),

        lit("Total_Third_Party_Impressions"),
        col("Source_Total_Third_Party_Impressions").cast("double"),
        col("Target_Total_Third_Party_Impressions").cast("double"),
        lit(None).cast("double"),

        lit("Total_Third_Party_Revenue"),
        col("Source_Total_Third_Party_Revenue").cast("double"),
        col("Target_Total_Third_Party_Revenue").cast("double"),
        lit(None).cast("double"),

        lit("Third_Party_Revenue_Pacing"),
        col("Source_Third_Party_Revenue_Pacing").cast("double"),
        col("Target_Third_Party_Revenue_Pacing").cast("double"),
        lit(None).cast("double"),

        lit("Third_Party_CPM"),
        col("Source_Third_Party_CPM").cast("double"),
        col("Target_Third_Party_CPM").cast("double"),
        lit(None).cast("double"),

        lit("threshold_variance_1P_revenue"),
        lit(None).cast("double"),
        lit(None).cast("double"),
        when(
            expr("try_divide((Target_Budget - Target_Total_Delivered_Revenue), Target_Budget) * 100") > 111,
            spark_round(expr("try_divide(Target_Total_Delivered_Revenue, Target_Budget) * 100"), 2)
        ).otherwise(lit(None).cast("double")),


        lit("threshold_variance_1P_impressions"),
        lit(None).cast("double"),
        lit(None).cast("double"),
        when(
            expr("try_divide((Target_Total_Guaranteed_Impressions-Target_Total_Delivered_Impressions), Target_Total_Guaranteed_Impressions) * 100") > 111,
            spark_round(expr("try_divide(Target_Total_Delivered_Impressions, Target_Total_Guaranteed_Impressions) * 100"), 2)
        ).otherwise(lit(None).cast("double")),

        lit("threshold_variance_3P_revenue"),
        lit(None).cast("double"),
        lit(None).cast("double"),
        when(
            expr("try_divide((Target_Budget-Target_Total_Third_Party_Revenue), Target_Budget) * 100") > 111,
            spark_round(expr("try_divide(Target_Total_Third_Party_Revenue, Target_Budget) * 100"), 2)
        ).otherwise(lit(None).cast("double")),

        lit("threshold_variance_3P_impressions"),
        lit(None).cast("double"),
        lit(None).cast("double"),
        when(
            expr("try_divide((Target_Total_Guaranteed_Impressions - Target_Total_Third_Party_Impressions), Target_Total_Guaranteed_Impressions) * 100") > 111,
            spark_round(expr("try_divide(Target_Total_Third_Party_Impressions, Target_Total_Guaranteed_Impressions) * 100"), 2)
        ).otherwise(lit(None).cast("double")),


        lit("threshold_variance_1P_pacing"),
        lit(None).cast("double"),
        lit(None).cast("double"),
        when(
            expr("try_divide(Target_Total_Delivered_Impressions, Target_Total_Guaranteed_Impressions) * 100") > 111,
            spark_round(expr("try_divide(Target_Total_Delivered_Impressions, Target_Total_Guaranteed_Impressions) * 100"), 2)
        ).otherwise(lit(None).cast("double")),

        lit("threshold_variance_3P_pacing"),
        lit(None).cast("double"),
        lit(None).cast("double"),
        when(
            expr("try_divide(Target_Total_Third_Party_Impressions, Target_Total_Guaranteed_Impressions) * 100") > 111,
            spark_round(expr("try_divide(Target_Total_Third_Party_Impressions, Target_Total_Guaranteed_Impressions) * 100"), 2)
        ).otherwise(lit(None).cast("double")),

        lit("threshold_variance_1P_cpm"),
        lit(None).cast("double"),
        lit(None).cast("double"),
        when(
            expr("try_divide(Target_CPM, try_divide(Target_Budget,Target_Total_Guaranteed_Impressions)*1000) * 100") > 111,
            spark_round(expr("try_divide(Target_CPM, try_divide(Target_Budget,Target_Total_Guaranteed_Impressions)*1000) * 100"), 2)
        ).otherwise(lit(None).cast("double")),

        lit("threshold_variance_3P_cpm"),
        lit(None).cast("double"),
        lit(None).cast("double"),
        when(
            expr("try_divide(Target_Third_Party_CPM, try_divide(Target_Budget,Target_Total_Guaranteed_Impressions)*1000) * 100") > 111,
            spark_round(expr("try_divide(Target_Third_Party_CPM, try_divide(Target_Budget,Target_Total_Guaranteed_Impressions)*1000) * 100"), 2)
        ).otherwise(lit(None).cast("double")),

        lit("threshold_variance_1P_budget_utilization"),
        lit(None).cast("double"),
        lit(None).cast("double"),
        when(
            expr("try_divide(Target_Total_Delivered_Revenue, Target_Budget) * 100") > 111,
            spark_round(expr("try_divide(Target_Total_Delivered_Revenue, Target_Budget) * 100"), 2)
        ).otherwise(lit(None).cast("double")),


        lit("threshold_variance_3P_budget_utilization"),
        lit(None).cast("double"),
        lit(None).cast("double"),
        when(
            expr("try_divide(Target_Total_Third_Party_Revenue, Target_Budget) * 100") > 111,
            spark_round(expr("try_divide(Target_Total_Third_Party_Revenue, Target_Budget) * 100"), 2)
        ).otherwise(lit(None).cast("double")),

        # when(((col("Target_Total_Delivered_Revenue")/col("Target_Budget"))*100).cast("double") > 111, spark_round(((col("Target_Total_Delivered_Revenue")/col("Target_Budget"))*100),2).cast("double")).otherwise(lit(None).cast("double")),

        # lit("threshold_variance_1P_impressions"),
        # lit(None).cast("double"),
        # lit(None).cast("double"),
        # when(((col("Target_Total_Delivered_Impressions")/col("Target_Total_Guaranteed_Impressions"))*100).cast("double") > 111, spark_round(((col("Target_Total_Delivered_Impressions")/col("Target_Total_Guaranteed_Impressions"))*100),2).cast("double")).otherwise(lit(None).cast("double")),

        # lit("threshold_variance_3P_revenue"),
        # lit(None).cast("double"),
        # lit(None).cast("double"),
        # when(col("Target_Revenue_Pacing").cast("double") > 111, col("Target_Revenue_Pacing").cast("double")).otherwise(lit(None).cast("double")),

        # lit("threshold_variance_1P_revenue"),
        # when(col("Target_Revenue_Pacing") > 111, col("Target_Revenue_Pacing")).otherwise(lit(None).cast("double")),
    ).alias("metric_name", "source_value", "target_value","threshold_variance")
).withColumn(
    "mismatch_percent_variance",
    when(
        (col("source_value") == 0) & (col("target_value") == 0), lit(0.0)
    ).when(
        col("source_value") == 0, lit(100.0)
    ).otherwise(
        spark_round(
            spark_abs(col("source_value") - col("target_value")) / spark_abs(col("source_value")) * 100,
            2
        )
    )
).filter(
    (col("mismatch_percent_variance") >= 1) | (col("threshold_variance")>111)
)

display(unpivoted_df_cs)

# COMMAND ----------

table_name = "fox_bi_dev.bronze_ads.wrap_report_campaign_summary_mismatches"

if spark.catalog.tableExists(table_name):
    unpivoted_df_cs.write.mode("overwrite").saveAsTable(table_name)
else:
    unpivoted_df_cs.write.saveAsTable(table_name)

# COMMAND ----------

dbutils.notebook.exit("success")