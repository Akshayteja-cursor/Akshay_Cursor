# Databricks notebook source
spark.conf.set("spark.databricks.remoteFiltering.blockSelfJoins", "false")

# COMMAND ----------

# MAGIC %md
# MAGIC # Parse for CREATIVE_PERFORMANCE Validation
# MAGIC

# COMMAND ----------

# Databricks notebook Target
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from datetime import datetime, date
import os
import pandas as pd

# COMMAND ----------

# Configuration
catalog_name = 'fox_bi_qa'
env = 'dev'  # or 'qa' or 'prod'


# Target: Aggregate field10 from wrap_detailed_unified_report_sections_by_deal
# Filter for CREATIVE_PERFORMANCE data_type and sum field10 (which contains Total_Delivered_Impressions as string)
tar_df_cp = spark.sql(f"""
    SELECT 
        AOS_Deal_ID,
        count(distinct try_cast(field1 AS BIGINT)) as `Target Total Creatives`,
        SUM(try_cast(field4 AS BIGINT)) as `Target Total Delivered Impressions`,
        SUM(try_cast(field5 AS DECIMAL(19,2))) as `Target Total Delivered Revenue`,
        SUM(try_cast(field6 AS BIGINT)) as `Target Total Delivered Clicks`,
        CAST(
            CASE
                WHEN SUM(field4) > 0
                THEN ROUND((SUM(field6) / SUM(field4) * 100), 4)
                ELSE 0
            END AS DECIMAL(19,2)
        ) as `Target CTR`,
        MAX(try_cast(field9 AS BIGINT)) as `Target Total Third Party Impressions`,
        MAX(try_cast(field10 AS DECIMAL(19,2))) as `Target Total Third Party Revenue`
    FROM {catalog_name}.gold_ad_sales.v_wrap_detailed_unified_report_sections_by_deal
    WHERE data_type = 'CREATIVE_PERFORMANCE'
    GROUP BY AOS_Deal_ID
""")

display(tar_df_cp)


# Source: Get Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
src_df_cp = spark.sql(f"""
with fw_placement_level as (
    SELECT
        `AOS_Deal Name` AS aos_deal_name,
        `AOS_Deal ID` AS aos_deal_id,
        pl.`Campaign Start Date` AS campaign_start_date,
        pl.`Campaign End Date` AS campaign_end_date,
        pl.`Advertiser Name` AS advertiser_name,
        pl.`Agency Name` AS agency_name,
        pl.`Sales Channel Type` AS line_item_type,
        pl.`Placement ID` AS placement_id,
        pl.`Placement Name` AS placement_name,
        pl.`Package Name` AS package_name,
        pl.`Parent Line Item Name` AS parent_line_item_name,
        pl.`AOS Deal Line Item Name` AS aos_deal_line_item_name,
        pl.`Creative ID` AS creative_id,
        pl.`Creative Name` AS creative_name,
        pl.`Creative Duration` AS creative_duration,
        pl.`Device` AS device,
        pl.`Ad Unit Position` AS ad_unit_position,
        pl.`Video Vertical` AS video_vertical,
        pl.`Show Name` AS show_name,
        pl.`Deal Ad Units` AS deal_ad_units,
        pl.`Demo Band` AS demo_band,
        pl.`Event Date` AS event_date,
        MAX(pl.`Guaranteed Impressions`) as guaranteed_impressions,
        MAX(pl.`Guaranteed Revenue`) as guaranteed_revenue,
        MAX(`Net Unit Cost`) as net_unit_cost,
        SUM(pl.`Delivered Impressions`) as delivered_impressions,
        SUM(pl.`Delivered Clicks`) as delivered_clicks,
        SUM(pl.`Delivered Revenue`) as delivered_revenue,
        SUM(pl.`On Target Net Delivered Impressions`) as on_target_impressions
    FROM fox_bi_qa.gold_ad_sales.v_ft_freewheel_campaign_delivery pl
    -- WHERE `AOS_Deal ID` = 18683
    GROUP BY
        `AOS_Deal ID`,
        `AOS_Deal Name`,
        pl.`Campaign Start Date`,
        pl.`Campaign End Date`,
        pl.`Advertiser Name`,
        pl.`Agency Name`,
        pl.`Sales Channel Type`,
        pl.`Placement ID`,
        pl.`Placement Name`,
        pl.`Package Name`,
        pl.`Parent Line Item Name`,
        pl.`AOS Deal Line Item Name`,
        pl.`Creative ID`,
        pl.`Creative Name`,
        pl.`Creative Duration`,
        pl.`Device`,
        pl.`Ad Unit Position`,
        pl.`Video Vertical`,
        pl.`Show Name`,
        pl.`Deal Ad Units`,
        pl.`Event Date`,
        pl.`Demo Band`
),
gam_placement_level AS (
    SELECT
        pl.`AOS Deal Name` AS aos_deal_name,
        pl.`AOS Deal ID` AS aos_deal_id,
        pl.`Campaign Start Date` AS campaign_start_date,
        pl.`Campaign End Date` AS campaign_end_date,
        pl.`Advertiser Name` AS advertiser_name,
        pl.`Agency Name` AS agency_name,
        pl.`Line Item Type` AS line_item_type,
        pl.`Line Item ID` AS placement_id,
        pl.`Line Item Name` AS placement_name,
        pl.`Package Name` AS package_name,
        pl.`Parent Line Item Name` AS parent_line_item_name,
        pl.`AOS Deal Line Item Name` AS aos_deal_line_item_name,
        CAST(-1 AS STRING) AS creative_id,
        CAST('N/A' AS STRING) AS creative_name,
        CAST(0 AS STRING) AS creative_duration,
        pl.`Device`,
        CAST('N/A' AS STRING) AS ad_unit_position,
        CAST('N/A' AS STRING) AS video_vertical,
        CAST('N/A' AS STRING) AS show_name,
        CAST('N/A' AS STRING) AS deal_ad_units,
        pl.`Demo Band` AS demo_band,
        pl.`Event Date` AS event_date,
        MAX(pl.`Guaranteed Impressions`) AS guaranteed_impressions,
        MAX(pl.`Guaranteed Revenue`) AS guaranteed_revenue,
        MAX(pl.`Net Unit Cost`) AS net_unit_cost,
        SUM(pl.`Delivered Impressions`) AS delivered_impressions,
        SUM(pl.`Delivered Clicks`) AS delivered_clicks,
        CASE
            WHEN MAX(pl.`Line Item Type`) = 'SPONSORSHIP'
            THEN MAX(pl.`Guaranteed Revenue`)/count(pl.`Event Date`) over (partition by pl.`Line Item ID`)
            ELSE (SUM(pl.`Delivered Impressions`) * MAX(pl.`Net Unit Cost`)) / 1000.0
        END as delivered_revenue,
        SUM(0) as on_target_impressions
    FROM fox_bi_qa.gold_ad_sales.v_ft_gam_campaign_delivery pl
    -- WHERE pl.`AOS Deal ID` = 18683
    GROUP BY
        pl.`AOS Deal ID`,
        pl.`AOS Deal Name`,
        pl.`Campaign Start Date`,
        pl.`Campaign End Date`,
        pl.`Advertiser Name`,
        pl.`Agency Name`,
        pl.`Line Item Type`,
        pl.`Line Item ID`,
        pl.`Line Item Name`,
        pl.`Package Name`,
        pl.`Parent Line Item Name`,
        pl.`AOS Deal Line Item Name`,
        pl.`Device`,
        pl.`Demo Band`,
        pl.`Event Date`
),
unified_placement_level as (
    SELECT
         aos_deal_id
        ,aos_deal_name
        ,campaign_start_date
        ,campaign_end_date
        ,advertiser_name
        ,agency_name
        -- ,sales_channel_type
        ,placement_id
        ,placement_name
        ,package_name
        ,parent_line_item_name
        ,aos_deal_line_item_name
        ,line_item_type
        ,creative_id
        ,creative_name
        ,creative_duration
        ,device
        ,ad_unit_position
        ,video_vertical
        ,show_name
        ,deal_ad_units
        ,event_date
        ,demo_band
        ,MAX(net_unit_cost) net_unit_cost
        ,MAX(guaranteed_impressions) AS guaranteed_impressions
        ,MAX(guaranteed_revenue) AS guaranteed_revenue
        ,SUM(delivered_impressions) AS delivered_impressions
        ,SUM(delivered_revenue) delivered_revenue
        ,SUM(delivered_clicks) AS delivered_clicks
        ,SUM(on_target_impressions) AS on_target_impressions
    FROM
        (
            select * from fw_placement_level
            union all
            select * from gam_placement_level
        )
    GROUP BY
            aos_deal_id
            ,aos_deal_name
            ,campaign_start_date
            ,campaign_end_date
            ,advertiser_name
            ,agency_name
            -- ,sales_channel_type
            ,placement_id
            ,package_name
            ,parent_line_item_name
            ,aos_deal_line_item_name
            ,placement_name
            ,creative_id
            ,creative_name
            ,creative_duration
            ,device
            ,ad_unit_position
            ,video_vertical
            ,show_name
            ,deal_ad_units
            ,event_date
            ,demo_band
            ,line_item_type
),                   
unified_creative_third_party as (
    SELECT
         aos_deal_id
        ,creative_id
        ,SUM(third_party_impressions) creative_third_party_impressions
        ,SUM(third_party_revenue) creative_third_party_revenue
    FROM
        (
        SELECT
            `AOS_Deal ID` as aos_deal_id,
            `Creative ID` as creative_id,
            `Event Date` as event_date,
            `Ad Unit Position` as ad_unit_position,
            `Third Party Billable Impressions` as third_party_impressions,
            `Third Party Revenue` as third_party_revenue
        FROM fox_bi_qa.gold_ad_sales.v_ft_freewheel_campaign_delivery
        -- WHERE `AOS_Deal ID` = ?
        GROUP BY ALL
    )
    GROUP BY aos_deal_id, creative_id
)

,fetch_ind_tab as (
select 
AOS_Deal_ID,
CAST(COUNT(`Source Total Creatives`) AS BIGINT) as `Source Total Creatives`,
CAST(SUM(`Source Total Delivered Impressions`) AS BIGINT) as `Source Total Delivered Impressions`,
CAST(SUM(`Source Total Delivered Revenue`) AS DECIMAL(19,2)) as `Source Total Delivered Revenue`,
CAST(SUM(`Source Total Delivered Clicks`) AS BIGINT) as `Source Total Delivered Clicks`,
CAST(SUM(`Source CTR`) AS BIGINT) as `Source CTR`,
CAST(MAX(`Source Total Third Party Impressions`) AS BIGINT) as `Source Total Third Party Impressions`,
CAST(MAX(`Source Total Third Party Revenue`) AS BIGINT) as `Source Total Third Party Revenue`
from (
    SELECT 
        pl.aos_deal_id as AOS_Deal_ID,
        CAST(pl.creative_id AS BIGINT) as `Source Total Creatives`,
        CAST(SUM(pl.delivered_impressions) AS BIGINT) as `Source Total Delivered Impressions`,
        CAST(SUM(pl.delivered_revenue) AS DECIMAL(19,2)) as `Source Total Delivered Revenue`,
        CAST(SUM(pl.delivered_clicks) AS BIGINT) as `Source Total Delivered Clicks`,
        CAST(
            CASE
                WHEN SUM(pl.delivered_impressions) > 0
                THEN ROUND((SUM(pl.delivered_clicks) / SUM(pl.delivered_impressions) * 100), 4)
                ELSE 0
            END AS DECIMAL(19,2)
        ) as `Source CTR`,
        CAST(MAX(ctp.creative_third_party_impressions) AS BIGINT) as `Source Total Third Party Impressions`,
        CAST(MAX(ctp.creative_third_party_revenue) AS BIGINT) as `Source Total Third Party Revenue`
    FROM (select * from unified_placement_level 
    --where creative_name is not null and creative_name != 'N/A' and creative_name != 'Unknown'
    ) pl
    LEFT JOIN unified_creative_third_party ctp
        ON pl.creative_id = ctp.creative_id AND pl.aos_deal_id = ctp.aos_deal_id
    GROUP BY pl.creative_id
        ,pl.creative_name
        ,pl.creative_duration
        ,pl.aos_deal_id
)  
group by AOS_Deal_ID 

)

SELECT
distinct
`AOS Deal ID` as AOS_Deal_ID,
CAST(`Total First Party Delivered Impressions` AS BIGINT) as `Source Total Delivered Impressions`,
pl.`Source Total Delivered Revenue`,
CAST(`Total Delivered Clicks` AS BIGINT) as `Source Total Delivered Clicks`,
pl.`Source Total Third Party Impressions`,
pl.`Source Total Third Party Revenue`,
-- CAST(`Total Third Party Impressions` AS BIGINT) as `Source Total Third Party Impressions`,
-- CAST(`Total Third Party Revenue` AS DECIMAL(19,2)) as `Source Total Third Party Revenue`,
pl.`Source Total Creatives` as `Source Total Creatives`,
pl.`Source CTR` as `Source CTR`
from
(select distinct * from fox_bi_qa.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal) as src
inner join
(select distinct * from fetch_ind_tab) pl
on src.`AOS Deal ID` = pl.aos_deal_id

""")

display(src_df_cp)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Validation Comparison

# COMMAND ----------

from pyspark.sql.functions import col, when, expr, nvl, abs, lit, array, concat_ws

# Join source and target on AOS_Deal_ID
joined_df_cp = src_df_cp.join(
    tar_df_cp,
    on="AOS_Deal_ID",
    how="full_outer"
)

display(joined_df_cp)


# Add comparison columns - only for columns that exist in both src_df_cp and tar_df_cp
validation_df_cp = joined_df_cp.withColumn(
    "Source_Total_Creatives",
    nvl(col("`Source Total Creatives`"), lit(0))
).withColumn(
    "Target_Total_Creatives",
    nvl(col("`Target Total Creatives`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Impressions",
    nvl(col("`Source Total Delivered Impressions`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Impressions",
    nvl(col("`Target Total Delivered Impressions`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Revenue",
    nvl(col("`Source Total Delivered Revenue`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Revenue",
    nvl(col("`Target Total Delivered Revenue`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Clicks",
    nvl(col("`Source Total Delivered Clicks`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Clicks",
    nvl(col("`Target Total Delivered Clicks`"), lit(0))
).withColumn(
    "Source_CTR",
    nvl(col("`Source CTR`"), lit(0))
).withColumn(
    "Target_CTR",
    nvl(col("`Target CTR`"), lit(0))
).withColumn(
    "Source_Total_Third_Party_Impressions",
    nvl(col("`Source Total Third Party Impressions`"), lit(0))
).withColumn(
    "Target_Total_Third_Party_Impressions",
    nvl(col("`Target Total Third Party Impressions`"), lit(0))
).withColumn(
    "Source_Total_Third_Party_Revenue",
    nvl(col("`Source Total Third Party Revenue`"), lit(0))
).withColumn(
    "Target_Total_Third_Party_Revenue",
    nvl(col("`Target Total Third Party Revenue`"), lit(0))
).withColumn(
    "Variance_Total_Creatives",
    col("Source_Total_Creatives") - col("Target_Total_Creatives")
).withColumn(
    "Variance_Impressions",
    col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")
).withColumn(
    "Variance_Revenue",
    col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")
).withColumn(
    "Variance_Clicks",
    col("Source_Total_Delivered_Clicks") - col("Target_Total_Delivered_Clicks")
).withColumn(
    "Variance_CTR",
    col("Source_CTR") - col("Target_CTR")
).withColumn(
    "Variance_Total_Third_Party_Impressions",
    col("Source_Total_Third_Party_Impressions") - col("Target_Total_Third_Party_Impressions")
).withColumn(
    "Variance_Total_Third_Party_Revenue",
    col("Source_Total_Third_Party_Revenue") - col("Target_Total_Third_Party_Revenue")
).withColumn(
    "Total_Creatives_Match",
    when(
        abs(col("Source_Total_Creatives") - col("Target_Total_Creatives")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Impressions_Match",
    when(
        abs(col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Revenue_Match",
    when(
        abs(col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Clicks_Match",
    when(
        abs(col("Source_Total_Delivered_Clicks") - col("Target_Total_Delivered_Clicks")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "CTR_Match",
    when(
        abs(col("Source_CTR") - col("Target_CTR")) <= 5,  # Use smaller threshold for CTR (percentage)
        True
    ).otherwise(False)
).withColumn(
    "Total_Third_Party_Impressions_Match",
    when(
        abs(col("Source_Total_Third_Party_Impressions") - col("Target_Total_Third_Party_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Total_Third_Party_Revenue_Match",
    when(
        abs(col("Source_Total_Third_Party_Revenue") - col("Target_Total_Third_Party_Revenue")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Status",
    when(
        (col("Total_Creatives_Match") == True) &
        (col("Impressions_Match") == True) &
        (col("Revenue_Match") == True) &
        (col("Clicks_Match") == True) &
        (col("CTR_Match") == True) &
        (col("Total_Third_Party_Impressions_Match") == True) &
        (col("Total_Third_Party_Revenue_Match") == True),
        True
    ).otherwise(False)
).select(
    col("AOS_Deal_ID"),
    col("Source_Total_Creatives"),
    col("Target_Total_Creatives"),
    col("Variance_Total_Creatives"),
    col("Total_Creatives_Match"),
    col("Source_Total_Delivered_Impressions"),
    col("Target_Total_Delivered_Impressions"),
    col("Variance_Impressions"),
    col("Impressions_Match"),
    col("Source_Total_Delivered_Revenue"),
    col("Target_Total_Delivered_Revenue"),
    col("Variance_Revenue"),
    col("Revenue_Match"),
    col("Source_Total_Delivered_Clicks"),
    col("Target_Total_Delivered_Clicks"),
    col("Variance_Clicks"),
    col("Clicks_Match"),
    col("Source_CTR"),
    col("Target_CTR"),
    col("Variance_CTR"),
    col("CTR_Match"),
    col("Source_Total_Third_Party_Impressions"),
    col("Target_Total_Third_Party_Impressions"),
    col("Variance_Total_Third_Party_Impressions"),
    col("Total_Third_Party_Impressions_Match"),
    col("Source_Total_Third_Party_Revenue"),
    col("Target_Total_Third_Party_Revenue"),
    col("Variance_Total_Third_Party_Revenue"),
    col("Total_Third_Party_Revenue_Match"),
    col("Status")
)

display(validation_df_cp)



# Create a dataframe showing which columns have mismatches for deals where Status is False
mismatch_details_df_cp = validation_df_cp.withColumn(
    "Mismatched_Columns_Array",
    array(
        when(col("Total_Creatives_Match") == False, lit("Total_Creatives")).otherwise(lit(None)),
        when(col("Impressions_Match") == False, lit("Impressions")).otherwise(lit(None)),
        when(col("Revenue_Match") == False, lit("Revenue")).otherwise(lit(None)),
        when(col("Clicks_Match") == False, lit("Clicks")).otherwise(lit(None)),
        when(col("CTR_Match") == False, lit("CTR")).otherwise(lit(None)),
        when(col("Total_Third_Party_Impressions_Match") == False, lit("Total_Third_Party_Impressions")).otherwise(lit(None)),
        when(col("Total_Third_Party_Revenue_Match") == False, lit("Total_Third_Party_Revenue")).otherwise(lit(None))
    )
).withColumn(
    "Mismatched_Columns_Array",
    expr("filter(Mismatched_Columns_Array, x -> x is not null)")
).withColumn(
    "Mismatched_Columns",
    concat_ws(", ", col("Mismatched_Columns_Array"))
).select(
    col("AOS_Deal_ID").alias("deal_id"),
    when(col("Status") == True, lit("True"))
    .when(col("Status") == False, lit("False"))
    .otherwise(lit("False")).alias("Status"),
    col("Mismatched_Columns")
).distinct()

print("=" * 80)
print(f"Deal Mismatch Details")
print(f"Total Deals with Mismatches: {mismatch_details_df_cp.count()}")
print("=" * 80)

display(mismatch_details_df_cp)



# Find deal_ids that are only in target table and not in source table
source_only_deals_cp = spark.sql(f"""
    SELECT 
        t.`AOS Deal ID` as AOS_Deal_ID,
        t.`Total Creatives` as `Target Total Creatives`,
        t.`Total Delivered Impressions` as `Target Total Delivered Impressions`,
        t.`Total Delivered Revenue` as `Target Total Delivered Revenue`,
        t.`Total Delivered Clicks` as `Target Total Delivered Clicks`,
        t.`CTR` as `Target CTR`,
        t.`Total Third Party Impressions` as `Target Total Third Party Impressions`,
        t.`Total Third Party Revenue` as `Target Total Third Party Revenue`
    FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal t
    WHERE t.`AOS Deal ID` IS NOT NULL
        -- AND t.`AOS Deal ID` != -1
        AND NOT EXISTS (
            SELECT 1
            FROM {catalog_name}.gold_ad_sales.v_wrap_detailed_unified_report_sections_by_deal s
            WHERE s.AOS_Deal_ID = t.`AOS Deal ID`
                AND s.data_type = 'CREATIVE_PERFORMANCE'
        )
    ORDER BY t.`AOS Deal ID`
""")

print("=" * 80)
print(f"Deal IDs only in v_ft_unified_campaign_delivery_by_deal Table (v_ft_unified_campaign_delivery_by_deal)")
print(f"Count: {source_only_deals_cp.count()}")
print("=" * 80)

display(source_only_deals_cp)


# Update mismatch_details_df_cp to include deals from source_only_deals_cp with Status = "missing deals"
# First, convert Status to string in mismatch_details_df_cp to allow "missing deals" value
mismatch_details_df_1_cp = mismatch_details_df_cp.withColumn(
    "Status",
    when(col("Status") == True, lit("True"))
    .when(col("Status") == False, lit("False"))
    .otherwise(col("Status").cast("string"))
)

# Create a dataframe for missing deals with the same structure as mismatch_details_df_cp
missing_deals_df_cp = source_only_deals_cp.select(
    col("AOS_Deal_ID").alias("deal_id"),
    lit("missing deals").alias("Status"),
    lit("Deal not found in source table").alias("Mismatched_Columns")
)

display(missing_deals_df_cp)

display(mismatch_details_df_1_cp)

# Option 1: Use a broadcast join with a flag, then check if deal_id exists in source_only_deals_cp
from pyspark.sql.functions import broadcast

# Create a set of deal_ids from source_only_deals_cp for efficient lookup
source_only_deal_ids_cp = source_only_deals_cp.select(col("AOS_Deal_ID").alias("deal_id")).distinct()

# Join and check if deal_id exists in source_only_deals_cp
mismatch_details_df_1_cp = mismatch_details_df_1_cp.join(
    broadcast(source_only_deal_ids_cp).withColumn("is_source_only", lit(True)),
    on="deal_id",
    how="left"
).withColumn(
    "Status",
    when(col("is_source_only").isNotNull(), lit("not found in source").cast("string"))
    .otherwise(col("Status").cast("string"))
).select(
    col("deal_id"),
    col("Status").cast("string").alias("Status"),
    col("Mismatched_Columns")
)

# Union with missing_deals_df_cp to include all deals that are only in target table
mismatch_details_df_1_cp = mismatch_details_df_1_cp.unionByName(
    missing_deals_df_cp,
    allowMissingColumns=True
).distinct()

display(mismatch_details_df_1_cp)



# Create a dataframe with deal_id and CREATIVE_PERFORMANCE (True if Status is True, False otherwise)
deal_status_df_cp = mismatch_details_df_1_cp.select(
    col("deal_id"),
    when(col("Status") == "True", lit("True"))
    .when(col("Status") == "False", lit("False"))
    .otherwise(col("Status"))
    .alias("CREATIVE_PERFORMANCE")
).distinct()


print("=" * 80)
print(f"Deal Status Summary")
print(f"Total Deals: {deal_status_df_cp.count()}")
print(f"Deals with CREATIVE_PERFORMANCE = True: {deal_status_df_cp.filter(col('CREATIVE_PERFORMANCE') == 'True').count()}")
print(f"Deals with CREATIVE_PERFORMANCE = False: {deal_status_df_cp.filter(col('CREATIVE_PERFORMANCE') == 'False').count()}")
print("=" * 80)

display(deal_status_df_cp)




# COMMAND ----------

deal_status_df_cp.createOrReplaceGlobalTempView("deal_status_df_cp")

# COMMAND ----------

from pyspark.sql.functions import lit, col, when, abs as spark_abs, stack, round as spark_round

unpivoted_df_cp = validation_df_cp.filter(
    col("Status") == False
).select(
    lit("CREATIVE_PERFORMANCE").alias("parse_type"),
    col("AOS_Deal_ID").alias("aos_deal_id"),
    stack(
        lit(7),
        lit("Total_Creatives"),
        col("Source_Total_Creatives").cast("double"),
        col("Target_Total_Creatives").cast("double"),

        lit("Total_Delivered_Impressions"),
        col("Source_Total_Delivered_Impressions").cast("double"),
        col("Target_Total_Delivered_Impressions").cast("double"),

        lit("Total_Delivered_Revenue"),
        col("Source_Total_Delivered_Revenue").cast("double"),
        col("Target_Total_Delivered_Revenue").cast("double"),

        lit("Total_Delivered_Clicks"),
        col("Source_Total_Delivered_Clicks").cast("double"),
        col("Target_Total_Delivered_Clicks").cast("double"),

        lit("CTR"),
        col("Source_CTR").cast("double"),
        col("Target_CTR").cast("double"),

        lit("Total_Third_Party_Impressions"),
        col("Source_Total_Third_Party_Impressions").cast("double"),
        col("Target_Total_Third_Party_Impressions").cast("double"),

        lit("Total_Third_Party_Revenue"),
        col("Source_Total_Third_Party_Revenue").cast("double"),
        col("Target_Total_Third_Party_Revenue").cast("double"),
    ).alias("metric_name", "source_value", "target_value")
).withColumn(
    "mismatch_percent_variance",
    when(
        (col("source_value") == 0) & (col("target_value") == 0), lit(0.0)
    ).when(
        col("source_value") == 0, lit(100.0)
    ).otherwise(
        spark_round(
            spark_abs(col("source_value") - col("target_value")) / spark_abs(col("source_value")) * 100,
            2
        )
    )
).filter(
    col("mismatch_percent_variance") != 0
)

display(unpivoted_df_cp)

# COMMAND ----------

table_name = "fox_bi_dev.bronze_ads.wrap_report_creative_performance_mismatches"

if spark.catalog.tableExists(table_name):
    unpivoted_df_cp.write.mode("overwrite").saveAsTable(table_name)
else:
    unpivoted_df_cp.write.saveAsTable(table_name)

# COMMAND ----------

dbutils.notebook.exit("success")