# Databricks notebook source
# %pip install --upgrade typing_extensions
# import tableauserverclient as TSC
from pyspark.sql import SparkSession
from functools import reduce, partial
from pyspark.sql import DataFrame
from pyspark.sql.functions import *
from email.utils import COMMASPACE, formatdate
from datetime import datetime, date, timedelta
import os
import zipfile
import sys
from os.path import basename
from concurrent.futures import ThreadPoolExecutor, as_completed
from pyspark.sql.types import StructType, StructField, StringType, ArrayType, IntegerType, DoubleType, BooleanType, LongType
import pandas as pd
import argparse
import requests
import json
import logging
import time



st_time = datetime.now()

# COMMAND ----------

# dbutils.widgets.text("env", "")

env = dbutils.widgets.get("env")

# env = 'dev'

if env == 'dev' or env == 'qa':
    print(f"Running in the {env} environment")

elif env == 'prod':
    print("Running in the prod environment")

else:
    print(f"Running in an unknown environment: {env}")


# COMMAND ----------

if env == 'dev':
  catalog_name = 'fox_bi_qa'
  adtech_catalog_name = 'fox_bi_dev'
elif env == 'prod':
  catalog_name = 'fox_bi_prod'
  adtech_catalog_name = 'fox_bi_prod'

# COMMAND ----------

# MAGIC %sh
# MAGIC aws --version
# MAGIC aws configure set region us-west-2 --profile databricks-fng-prod
# MAGIC aws configure set s3.signature_version s3v4 --profile databricks-fng-prod
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile databricks-fng-prod
# MAGIC aws configure set role_arn arn:aws:iam::640862407089:role/fng-dmo-prod-databricks-ec2-role --profile databricks-fng-prod

# COMMAND ----------

class cls_ssm(object):
    def __init__(self, aws_profile="default"):
        import boto3

        try:
            session = boto3.Session(profile_name=aws_profile)
            client = session.client("ssm")

            self.client = client
            self.aws_profile = aws_profile

        except Exception as e:
            raise Exception("ERROR: " + str(e))

    def get_ssm_param_by_path(
        self, path, full_path_dict_key=False, next_token=" ", keyvalue_dict={}
    ):
        # Get all values for all keys from SSM Path as Dictionary
        try:
            # -----------------------------------------------------------------------------------------------------------
            # To reset the keyvalue_dict we need to have below code , if we remove it is having trace of previous calls
            # -----------------------------------------------------------------------------------------------------------
            if next_token == " ":
                keyvalue_dict = {}
                response = self.client.get_parameters_by_path(
                    Path=path, WithDecryption=True, Recursive=True
                )
            else:
                response = self.client.get_parameters_by_path(
                    Path=path, NextToken=next_token, WithDecryption=True, Recursive=True
                )

            for parameter in response["Parameters"]:
                if full_path_dict_key:
                    key = parameter["Name"]
                else:
                    key = parameter["Name"].split("/")[-1]

                keyvalue_dict[key] = parameter["Value"]
            # ---------------------------------------------------------------------------------------------------------------
            # if there is more than 10 param in same path we need to paginate through next sets using next token from response
            # --------------------------------------------------------------------------------------------------------------
            if "NextToken" in response.keys():
                next_token = response["NextToken"]
                keyvalue_dict = self.get_ssm_param_by_path(
                    path, full_path_dict_key, next_token, keyvalue_dict
                )

            if keyvalue_dict == {}:
                value = self.client.get_parameter(Name=path, WithDecryption=True)[
                    "Parameter"
                ]["Value"]

                if full_path_dict_key:
                    key = path
                else:
                    key = path.split("/")[-1]

                keyvalue_dict[key] = value

            # print(keyvalue_dict)
            return keyvalue_dict
        except Exception as e:
            raise Exception("ERROR: " + str(e))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tableau Data

# COMMAND ----------

from pyspark.sql.functions import to_date, trim, regexp_replace, col, first

dff_transposed = spark.sql(f"""select * from {adtech_catalog_name}.bronze_ads.foxai_unified_camping_pacing_delivery""")

tar_campaign_deals_df = dff_transposed.filter(dff_transposed['AOS_Deal_ID'] != '-1')

display(tar_campaign_deals_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ## AOS Data

# COMMAND ----------

ssm_obj = cls_ssm('databricks-fng-prod')
cred_dict = ssm_obj.get_ssm_param_by_path( '/fox/stg/aos/prod/portal/', full_path_dict_key=False, next_token=' ', keyvalue_dict={})
usr=cred_dict['username']
ps=cred_dict['password']
api=cred_dict['apikey']

# COMMAND ----------

#prod
import requests

def request_token():
  response = requests.post(
    "https://api.aos.operative.com/mayiservice/tenant/fox", 
    json={ 
      "expiration":"360",
      "password":ps,
      "userId":usr,
      "apiKey":api
      },
    headers = {'Authorisation':api,'Content-Type': 'application/json'}
    )
  return response

response=request_token()
print(response)

# Token is fetched
token = response.json()["token"]  
headers = {'Authorization': f'Bearer {token}'}

# COMMAND ----------

def common_aos_data_pull(type_of_data, deal_list = None, order_lines_list = None):
# Fetch the grossCost from Digital Lines Api for each Tubi Deals

  # Define a function for a single request
  def fetch_deal_header(plan_id, order_line_id):
      # time.sleep(2)
      if type_of_data == 'plan_header':
        base_url = f"https://api.aos.operative.com/unifiedplanner/v1/{api}/plans/{plan_id}"
        payload = {"Body": {}}
        print(f"Fetching deal: {plan_id}")
        try:
          res = requests.get(base_url, headers=headers, json=payload)
          res.raise_for_status()  # raise error for HTTP codes like 4xx or 5xx
          return [res.json()]
        except Exception as e:
          print(f"Error on deal {plan_id}: {e}")
          return []
        
      elif type_of_data == 'plan_lines':
        base_url = f"https://api.aos.operative.com/unifiedplanner/v1/{api}/plans/{plan_id}/workspace/digital/lines/_search"
        payload = {"Body": {}}
        print(f"Fetching deal: {plan_id}")
        try:
          res = requests.post(base_url, headers=headers, json=payload)
          res.raise_for_status()  # raise error for HTTP codes like 4xx or 5xx
          return res.json()
        except Exception as e:
          print(f"Error on deal {plan_id}: {e}")
          return []
      
      elif type_of_data == 'order_workstream':    
        base_url = f"https://api.aos.operative.com/orders/v1/{api}/workstreams/_search"
        payload = {"dealSequenceId": int(plan_id)}
        print(f"Fetching deal: {plan_id}")
        try:
          res = requests.post(base_url, headers=headers, json=payload)
          res.raise_for_status()  # raise error for HTTP codes like 4xx or 5xx
          return [res.json()]
        except Exception as e:
          print(f"Error on deal {plan_id}: {e}")
          return []
      
      elif type_of_data == 'order_lines':    
        base_url = f"https://api.aos.operative.com/orders/v1/{api}/lines/_search"
        payload = {"orderId": f"{order_line_id}"}
        #print(f"Fetching deal: {order_line_id}")
        try:
          res = requests.post(base_url, headers=headers, json=payload)
          res.raise_for_status()  # raise error for HTTP codes like 4xx or 5xx
          return [res.json()]
        except Exception as e:
          print(f"Error on order line : {e}")
          return []

  # Run requests in parallel
  lst = []
  with ThreadPoolExecutor(max_workers=10) as executor:
      if type_of_data == 'order_lines':
        futures = [
            executor.submit(fetch_deal_header, None, order_line_id)
            for order_line_id in order_lines_list
        ]
      
      else:
        futures = [
            executor.submit(fetch_deal_header, plan_id, None)
            for plan_id in deal_list
        ]
      for future in as_completed(futures):
          lst.append(future.result())

  # Optional: flatten the list if needed
  from itertools import chain

  aos_result_list = list(chain.from_iterable(lst))

  return aos_result_list

# COMMAND ----------

# MAGIC %md
# MAGIC AOS DEAL LEVEL DATA

# COMMAND ----------

# Fetch all Tubi Deals from AOS API

base_url = f"https://api.aos.operative.com/unifiedplanner/v1/{api}/plans/_search"

# Define a function for a single request
def fetch_page(pg_no):
    print(f"Fetching page: {pg_no}")
    payload = {"planStatus": [
        {"statusId": "90"}],
        "invoicingOrg": [{"id": "69"},{"id": "70"},
                                {"id": "71"},{"id": "72"},
                                {"id": "102"},{"id": "105"},
                                {"id": "108"},{"id": "113"}]}


    params = f"?limit=50&offset={pg_no}&sortOrder=1&sortBy"
    url = base_url + params

    try:
        res = requests.post(url, headers=headers, json=payload)
        res.raise_for_status()  # raise error for HTTP codes like 4xx or 5xx
        return res.json()["planResponseList"]
    except Exception as e:
        print(f"Error on page {pg_no}: {e}")
        return []

# Run requests in parallel
l = []
with ThreadPoolExecutor(max_workers=10) as executor:
    futures = [executor.submit(fetch_page, pg_no) for pg_no in range(0, 150)]
    for future in as_completed(futures):
        l.append(future.result())

# Optional: flatten the list 
from itertools import chain
ao_deal_result_list = list(chain.from_iterable(l))


# COMMAND ----------

#ao_deal_result_list = common_aos_data_pull('plan_header', deal_list)

schema = StructType([
    StructField("id", StringType(), True),
    StructField("planId", StringType(), True),
    StructField("planName", StringType(), True),
    StructField("platform", StringType(), True),
    StructField("startDate", StringType(), True),
    StructField("endDate", StringType(), True),
    StructField("advertisers", ArrayType(StructType([StructField("name", StringType(), True)])), True),
    StructField("agencies", ArrayType(StructType([StructField("name", StringType(), True)])), True),
    StructField("primaryVersion",StructType([StructField("dealTotals", StructType([
       StructField("digitalGrossCost", DoubleType(), True),
       StructField("digitalTotalQuantity", LongType(), True)]), True)]), True)
  ])

cols = [
    "id",
    "planId",
    "planName",
    "platform",
    "startDate",
    "endDate",
    "advertisers.name as advertisers",
    "agencies.name as agencies",
    "primaryVersion.dealTotals.digitalGrossCost as budget",
    "primaryVersion.dealTotals.digitalTotalQuantity as total_guaranteed_impressions"
]

deal_df = spark.createDataFrame(ao_deal_result_list, schema=schema)
#display(df)
df_deal_prefinal_aos = deal_df.distinct()
df_deal_prefinal_aos = df_deal_prefinal_aos.selectExpr(*cols)

df_deal_prefinal_aos = df_deal_prefinal_aos.select(
    col("id").alias("plan_id"),
    col("planId").alias("deal_id"),
    col("planName").alias("deal_name"),
    col("platform"),
    col("startDate").alias("start_date"),
    col("endDate").alias("end_date"),
    element_at(col("advertisers"), 1).alias("advertiser_name"),
    element_at(col("agencies"), 1).alias("agency_name"),
    col("budget"),
    col("total_guaranteed_impressions")

)

df_deal_prefinal_aos = df_deal_prefinal_aos[df_deal_prefinal_aos["platform"] == "DIGITAL"]
display(df_deal_prefinal_aos)

# COMMAND ----------

deal_list = df_deal_prefinal_aos.select("deal_id").collect()
deal_list = [row.deal_id for row in deal_list]
#print(deal_list)

# COMMAND ----------

# MAGIC %md
# MAGIC AOS DEAL LINES LEVEL DATA

# COMMAND ----------

# Fetch the grossCost from Digital Lines Api for each Tubi Deals
aos_deal_line_result_list = common_aos_data_pull('plan_lines', deal_list)

schema = StructType([
    StructField("planId", StringType(), True),
    StructField("sequenceId", StringType(), True),
    StructField("name", StringType(), True),
    StructField("period", StructType([
        StructField("startDate", StringType(), True),
        StructField("endDate", StringType(), True)]), True),
    StructField("planWorkspaceProduct", StructType([
        StructField("lineType", StringType(), True)]), True),
    StructField("rates", StructType([
        StructField("quantity", LongType(), True),
        StructField("netUnitCost", DoubleType(), True),
        StructField("netCost", DoubleType(), True)]), True),
    StructField("customFieldValues", StructType([
        StructField("demoband", StringType(), True)]), True),
  ])

cols = [
    "planId as plan_id",
    "sequenceId as deal_line_item_id",
    "name as deal_line_item_name",
    "period.startDate as line_item_start_date",
    "period.endDate as line_item_end_date",
    "planWorkspaceProduct.lineType as line_type",
    "rates.quantity as guaranteed_impressions",
    "rates.netUnitCost as net_unit_cost",
    "rates.netCost as guaranteed_revenue",
    "customFieldValues.demoband as demo_band"
]

df = spark.createDataFrame(aos_deal_line_result_list, schema=schema)
df_prefinal_aos = df.distinct()
print(df_prefinal_aos.count())
df_deal_line_prefinal_aos = df_prefinal_aos.selectExpr(*cols)

#df_deal_line_prefinal_aos = df_deal_line_prefinal_aos[df_deal_line_prefinal_aos["line_type"] == "STANDARD"]
display(df_deal_line_prefinal_aos)

# COMMAND ----------

# MAGIC %md
# MAGIC AOS ORDER LEVEL DATA

# COMMAND ----------

aos_orders_result_list = common_aos_data_pull('order_workstream', deal_list)

schema = StructType([
    StructField(
        "workstreams",
        ArrayType(
            StructType([
                StructField("dealId", StringType(), True),
                StructField("orderId", StringType(), True)
            ])
        ),
        True
    )
])

cols = [
    "workstream.dealId as plan_id",
    "workstream.orderId as order_id"
]

df = spark.createDataFrame(aos_orders_result_list, schema=schema)
df_prefinal_aos = df.distinct()

from pyspark.sql.functions import explode

df_exploded = df_prefinal_aos.withColumn(
    "workstream",
    explode("workstreams")
)

df_order_prefinal_aos = df_exploded.selectExpr(*cols)

display(df_order_prefinal_aos)

# COMMAND ----------

# MAGIC %md
# MAGIC AOS ORDER LINES LEVEL DATA

# COMMAND ----------

order_lines_list = [row["order_id"] for row in df_order_prefinal_aos.select("order_id").distinct().collect()]

aos_order_lines_result_list = common_aos_data_pull('order_lines', [None] ,order_lines_list)

schema = StructType([
        StructField(
            "lineItems",
            ArrayType(
                StructType([
                    StructField("orderId", StringType(), True),
                    # StructField("quantity", LongType(), True),
                    # StructField("grossCost", DoubleType(), True),
                    StructField(
                        "externalAds",
                        ArrayType(
                            StructType([
                                StructField("externalId", StringType(), True),
                            ])
                        ),
                        True
                    ),
                ])
            ),
            True
        )
    ])

res = spark.createDataFrame(aos_order_lines_result_list, schema=schema)


df_order_line_prefinal_aos = (
    res
    .withColumn("li", explode_outer("lineItems"))      # <-- makes li a STRUCT (not array)
    .select(
        col("li.orderId").alias("order_id"),
        # col("li.quantity").cast("long").alias("total_guaranteed_impressions"),
        # col("li.grossCost").cast("double").alias("budget"),
        element_at(col("li.externalAds"), 1)["externalId"].alias("external_ad_id")   # <-- first externalAds.id
    )
)

#display(df_order_line_prefinal_aos)

df_order_line_ext_prefinal_aos = ( 
    df_order_prefinal_aos.join(
        df_order_line_prefinal_aos,
        on="order_id",
        how="left"
    )
)
display(df_order_line_ext_prefinal_aos)

# COMMAND ----------



# COMMAND ----------

from pyspark.sql.functions import collect_list, sort_array, desc

demo_df = spark.sql("""select * from (
    select 
      option_values_option_id,
      option_values_option_name,
      rank() over (partition by id 
                    order by conv_last_modified_date desc, offset desc) as rn
    from {catalog_name}.bronze_ad_sales.customfields_definitions_option_values
    ) where rn=1""".format(catalog_name = catalog_name))

# Left join df_deal_prefinal_aos and df_deal_line_prefinal_aos on plan_id
joined_df = df_deal_prefinal_aos.join(
    df_deal_line_prefinal_aos,
    on="plan_id",
    how="left"
)

# Join with demo_df on demo_band = option_values_option_id
joined_df = joined_df.join(
    demo_df,
    joined_df["demo_band"] == demo_df["option_values_option_id"],
    how="left"
)

# Group by all columns except line_id from df_deal_line_prefinal_aos
group_cols = [c for c in joined_df.columns]
grouped_df = joined_df.groupBy(*group_cols).count()



# Group by relevant columns and collect option_values_option_value into a sorted list (descending)
group_cols = [c for c in grouped_df.columns if c not in ("demo_band",  "option_values_option_id", "option_values_option_name")]
result_df = grouped_df.groupBy(*group_cols).agg(
    sort_array(collect_list("option_values_option_name"), asc=False).alias("target_demo")
)

display(result_df)

# COMMAND ----------

src_df = result_df.join(
    df_order_line_ext_prefinal_aos.select("plan_id", "external_ad_id" #, "total_guaranteed_impressions", "budget"
                                          ),
    on="plan_id",
    how="left"
).distinct()

display(src_df)

# COMMAND ----------

src_df.createOrReplaceTempView("aos_campaign_data_validation")

# COMMAND ----------

src_campaign_deals_df = spark.sql("""
with fw_data as (select AOS_deal_id
  from {catalog_name}.gold_ad_sales.ft_freewheel_delivery_daily
  where 1 = 1
  group by 1)
  , op1 as (SELECT
                 deal_id as aos_deal_id
            FROM aos_campaign_data_validation
            --where sales_order_line_item_name not ilike '%cancelled%'
          group by all)
,freewheel_data as (
  select fw_data.aos_deal_id
  from fw_data 
  join op1 on fw_data.aos_deal_id = op1.aos_deal_id
  group by all)

, oms AS (
    SELECT
                external_ad_id, deal_id as aos_deal_id, end_date as order_end_dt, agency_name
            FROM aos_campaign_data_validation
          group by all
),
gam AS (
    SELECT DISTINCT
        ft.line_item_id
        , ft.line_item_type
        , ft.advertiser_name
        , ft.order_name
        , or.order_end_timestamp
    FROM {adtech_catalog_name}.silver_ads.ft_gam_summary_daily_data ft
    LEFT JOIN {adtech_catalog_name}.silver_ads.dim_orders or
    ON ft.order_id = or.order_id
    WHERE line_item_id <> -1

)
,gam_data as (SELECT DISTINCT
    coalesce(aos_deal_id, -1) as aos_deal_id
FROM gam
JOIN oms
ON gam.line_item_id::string = oms.external_ad_id::string
)
select
distinct 
  deal_id, 
  deal_line_item_id, 
  deal_line_item_name,
  line_item_start_date,
  line_item_end_date,
  line_type,
  guaranteed_impressions,
  net_unit_cost, 
  guaranteed_revenue,
  deal_name, 
  advertiser_name, 
  agency_name, 
  start_date, 
  end_date, 
  replace(cast(target_demo as string), '"','') as target_demo, 
  budget, 
  total_guaranteed_impressions
 from
 aos_campaign_data_validation where deal_id in
 (
select * from freewheel_data
union 
select * from gam_data 
)
order by 1
;
""".format(catalog_name= catalog_name, adtech_catalog_name= adtech_catalog_name))

display(src_campaign_deals_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Comparison between aos and target
# MAGIC

# COMMAND ----------

filtered_src_campaign_deals_df = src_campaign_deals_df.filter((col("line_type") == 'STANDARD'))
#display(filtered_src_campaign_deals_df)

# COMMAND ----------

filtered_tar_campaign_deals_df = tar_campaign_deals_df
#display(filtered_tar_campaign_deals_df)

# COMMAND ----------

cols_to_prefix = [
    c for c in filtered_tar_campaign_deals_df.columns 
    if c not in ("Package_Information") and not c.startswith("AOS_")
]
renamed_cols = [
    col(c).alias(f"AOS_{c}") if c in cols_to_prefix else col(c) 
    for c in filtered_tar_campaign_deals_df.columns
]
filtered_tar_campaign_deals_df = filtered_tar_campaign_deals_df.select(*renamed_cols)

display(filtered_tar_campaign_deals_df)

# COMMAND ----------

from pyspark.sql.functions import col, abs, round, when, upper, coalesce

comparison_df = filtered_src_campaign_deals_df.join(
    filtered_tar_campaign_deals_df,
    (filtered_src_campaign_deals_df.deal_id == filtered_tar_campaign_deals_df.AOS_Deal_ID) &
    (filtered_src_campaign_deals_df.deal_line_item_id == filtered_tar_campaign_deals_df.AOS_Deal_Line_Item_ID),
    how="left"
)

result_df = comparison_df.select(
    col("deal_id"),
    col("deal_line_item_id"),
    col("guaranteed_impressions"),
    col("guaranteed_revenue"),
    col("net_unit_cost"),
    col("deal_name"),
    col("deal_line_item_name"),
    col("start_date").cast('date'),
    col("end_date").cast('date'),
    col("target_demo"),
    # col("product_info"),
    col("AOS_Deal_ID"),
    col("AOS_Deal_Line_Item_ID"),
    col("AOS_Guaranteed_impressions"),
    col("AOS_guaranteed_revenue"),
    col("AOS_net_unit_cost"),
    col("AOS_Deal_Name"),
    col("AOS_Deal_Line_Item_Name"),
    col("AOS_Line_Item_or_Placement_ID"),
    col("AOS_Line_Item_or_Placement_Name"),
    col("AOS_Line_Item_or_Placement_Start_Date"),
    col("AOS_Line_Item_or_Placement_End_Date"),
    col("AOS_Day_of_Campaign_Start_Date"),
    col("AOS_Day_of_Campaign_End_Date"),
    col("AOS_Demo_band").alias("AOS_Target_Demo"),
    # col("Package_Information"),

    round(
        abs(
            coalesce(col("guaranteed_revenue"), col("AOS_guaranteed_revenue")) - coalesce(col("AOS_guaranteed_revenue"), col("guaranteed_revenue"))
        ) / (coalesce(col("guaranteed_revenue"), col("AOS_guaranteed_revenue")) + 1e-9) * 100, 2
    ).alias("variance_guaranteed_revenue_percentage"),
    round(
        abs(
            coalesce(col("guaranteed_impressions"), col("AOS_Guaranteed_impressions")) - coalesce(col("AOS_Guaranteed_impressions"), col("guaranteed_impressions"))
        ) / (coalesce(col("guaranteed_impressions"), col("AOS_Guaranteed_impressions")) + 1e-9) * 100, 2
    ).alias("variance_guaranteed_impressions_percentage"),
    round(
        abs(
            coalesce(col("net_unit_cost"), col("AOS_net_unit_cost")) - coalesce(col("AOS_net_unit_cost"), col("net_unit_cost"))
        ) / (coalesce(col("net_unit_cost"), col("AOS_net_unit_cost")) + 1e-9) * 100, 2
    ).alias("variance_net_unit_cost_percentage"),

    when(
        col("deal_name").isNull() | col("AOS_Deal_Name").isNull(),
        False
    ).otherwise(
        upper(col("deal_name")) == upper(col("AOS_Deal_Name"))
    ).alias("mismatch_deal_name"),

    when(
        col("deal_line_item_name").isNull() | col("AOS_Deal_Line_Item_Name").isNull(),
        False
    ).otherwise(
        upper(col("deal_line_item_name")) == upper(col("AOS_Deal_Line_Item_Name"))
    ).alias("mismatch_deal_line_item_name"),

    when(
        col("AOS_ad_Server").isNull(),
        False
    ).otherwise(
        when(
            upper(col("AOS_ad_Server")) == "NON AD SERVED",
            upper(col("deal_line_item_id")) == upper(col("AOS_Line_Item_or_Placement_ID"))
        ).when(
            upper(col("AOS_ad_Server")) != "NON AD SERVED",
            True
        ).otherwise(False)
    ).alias("mismatch_line_item_id"),

    when(
        col("AOS_ad_Server").isNull(),
        False
    ).otherwise(
        when(
            upper(col("AOS_ad_Server")) == "NON AD SERVED",
            upper(col("deal_line_item_name")) == upper(col("AOS_Line_Item_or_Placement_Name"))
        ).when(
            upper(col("AOS_ad_Server")) != "NON AD SERVED",
            True
        ).otherwise(False)
    ).alias("mismatch_line_item_name"),

    when(
        col("AOS_ad_Server").isNull(),
        False
    ).otherwise(
        when(
            col("AOS_ad_Server") == "NON AD SERVED",
            col("start_date") == col("AOS_Line_Item_or_Placement_Start_Date")
        ).when(
            col("AOS_ad_Server") != "NON AD SERVED",
            True
        ).otherwise(False)
    ).alias("mismatch_line_item_start_date"),

    when(
        col("AOS_ad_Server").isNull(),
        False
    ).otherwise(
        when(
            col("AOS_ad_Server") == "NON AD SERVED",
            col("end_date") == col("AOS_Line_Item_or_Placement_End_Date")
        ).when(
            col("AOS_ad_Server") != "NON AD SERVED",
            True
        ).otherwise(False)
    ).alias("mismatch_line_item_end_date"),

    when(
        col("AOS_ad_Server").isNull(),
        False
    ).otherwise(
        when(
            col("AOS_ad_Server").isin("GAM", "NON AD SERVED"),
            col("start_date") == col("AOS_Day_of_Campaign_Start_Date")
        ).when(
            ~col("AOS_ad_Server").isin("GAM", "NON AD SERVED"),
            True
        ).otherwise(False)
    ).alias("mismatch_start_date"),

    when(
        col("AOS_ad_Server").isNull(),
        False
    ).otherwise(
        when(
            col("AOS_ad_Server").isin("GAM", "NON AD SERVED"),
            col("end_date") == col("AOS_Day_of_Campaign_End_Date")
        ).when(
            ~col("AOS_ad_Server").isin("GAM", "NON AD SERVED"),
            True
        ).otherwise(False)
    ).alias("mismatch_end_date"),

    when(
        col("target_demo").isNull() | col("AOS_Demo_band").isNull(),
        False
    ).otherwise(
        expr("""
        array_join(array_sort(filter(split(regexp_replace(nvl(target_demo,''), '\\\\[|\\\\]|\\\\s', ''), ','), x -> x <> '')), ',') =
        array_join(array_sort(filter(split(regexp_replace(nvl(AOS_Demo_band,''), '\\\\[|\\\\]|\\\\s', ''), ','), x -> x <> '')), ',')
    """)
    ).alias("mismatch_target_demo")
    # (col("product_info") != col("Package_Information")).alias("mismatch_product_info")
)

display(result_df)

# COMMAND ----------

result_df.write.format('delta')\
        .mode('overwrite')\
        .option('mergeSchema', 'true')\
        .saveAsTable(f"{adtech_catalog_name}.bronze_ads.aos_pacing_unified_campaign_validations")
