# Databricks notebook source
spark.conf.set("spark.databricks.remoteFiltering.blockSelfJoins", "false")

# COMMAND ----------

# MAGIC %md
# MAGIC # Parse for PACKAGE_PERFORMANCE Validation
# MAGIC

# COMMAND ----------

# Databricks notebook Target
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from datetime import datetime, date
import os
import pandas as pd

# COMMAND ----------

# Configuration
catalog_name = 'fox_bi_qa'
env = 'dev'  # or 'qa' or 'prod'

# Target: Aggregate field10 from wrap_detailed_unified_report_sections_by_deal
# Filter for PACKAGE_PERFORMANCE data_type and sum field10 (which contains Total_Delivered_Impressions as string)
tar_df_pp = spark.sql(f"""
    SELECT 
        AOS_Deal_ID,
        SUM(try_cast(field2 AS BIGINT)) as `Target Total Delivered Impressions`,
        SUM(try_cast(field3 AS DECIMAL(19,2))) as `Target Total Delivered Revenue`,
        SUM(try_cast(field7 AS BIGINT)) as `Target Total Guaranteed Impressions`,
        SUM(try_cast(field8 AS DECIMAL(19,2))) as `Target Total Guaranteed Revenue`,
        SUM(try_cast(field5 AS BIGINT)) as `Target Total Third Party Impressions`,
        SUM(try_cast(field6 AS DECIMAL(19,2))) as `Target Total Third Party Revenue`
    FROM {catalog_name}.gold_ad_sales.v_wrap_detailed_unified_report_sections_by_deal
    WHERE data_type = 'PACKAGE_PERFORMANCE'
    GROUP BY AOS_Deal_ID
""")

display(tar_df_pp)

# Source: Get Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
src_df_pp = spark.sql(f"""
with fw_placement_level as (
    SELECT
        `AOS_Deal Name` AS aos_deal_name,
        `AOS_Deal ID` AS aos_deal_id,
        pl.`Campaign Start Date` AS campaign_start_date,
        pl.`Campaign End Date` AS campaign_end_date,
        pl.`Advertiser Name` AS advertiser_name,
        pl.`Agency Name` AS agency_name,
        pl.`Sales Channel Type` AS line_item_type,
        pl.`Placement ID` AS placement_id,
        pl.`Placement Name` AS placement_name,
        pl.`Package Name` AS package_name,
        pl.`Parent Line Item Name` AS parent_line_item_name,
        pl.`AOS Deal Line Item Name` AS aos_deal_line_item_name,
        pl.`Creative ID` AS creative_id,
        pl.`Creative Name` AS creative_name,
        pl.`Creative Duration` AS creative_duration,
        pl.`Device` AS device,
        pl.`Ad Unit Position` AS ad_unit_position,
        pl.`Video Vertical` AS video_vertical,
        pl.`Show Name` AS show_name,
        pl.`Deal Ad Units` AS deal_ad_units,
        pl.`Demo Band` AS demo_band,
        pl.`Event Date` AS event_date,
        MAX(pl.`Guaranteed Impressions`) as guaranteed_impressions,
        MAX(pl.`Guaranteed Revenue`) as guaranteed_revenue,
        MAX(`Net Unit Cost`) as net_unit_cost,
        SUM(pl.`Delivered Impressions`) as delivered_impressions,
        SUM(pl.`Delivered Clicks`) as delivered_clicks,
        SUM(pl.`Delivered Revenue`) as delivered_revenue,
        SUM(pl.`On Target Net Delivered Impressions`) as on_target_impressions
    FROM fox_bi_qa.gold_ad_sales.v_ft_freewheel_campaign_delivery pl
    -- WHERE `AOS_Deal ID` = 18683
    GROUP BY
        `AOS_Deal ID`,
        `AOS_Deal Name`,
        pl.`Campaign Start Date`,
        pl.`Campaign End Date`,
        pl.`Advertiser Name`,
        pl.`Agency Name`,
        pl.`Sales Channel Type`,
        pl.`Placement ID`,
        pl.`Placement Name`,
        pl.`Package Name`,
        pl.`Parent Line Item Name`,
        pl.`AOS Deal Line Item Name`,
        pl.`Creative ID`,
        pl.`Creative Name`,
        pl.`Creative Duration`,
        pl.`Device`,
        pl.`Ad Unit Position`,
        pl.`Video Vertical`,
        pl.`Show Name`,
        pl.`Deal Ad Units`,
        pl.`Event Date`,
        pl.`Demo Band`
),
gam_placement_level AS (
    SELECT
        pl.`AOS Deal Name` AS aos_deal_name,
        pl.`AOS Deal ID` AS aos_deal_id,
        pl.`Campaign Start Date` AS campaign_start_date,
        pl.`Campaign End Date` AS campaign_end_date,
        pl.`Advertiser Name` AS advertiser_name,
        pl.`Agency Name` AS agency_name,
        pl.`Line Item Type` AS line_item_type,
        pl.`Line Item ID` AS placement_id,
        pl.`Line Item Name` AS placement_name,
        pl.`Package Name` AS package_name,
        pl.`Parent Line Item Name` AS parent_line_item_name,
        pl.`AOS Deal Line Item Name` AS aos_deal_line_item_name,
        CAST(-1 AS STRING) AS creative_id,
        CAST('N/A' AS STRING) AS creative_name,
        CAST(0 AS STRING) AS creative_duration,
        pl.`Device`,
        CAST('N/A' AS STRING) AS ad_unit_position,
        CAST('N/A' AS STRING) AS video_vertical,
        CAST('N/A' AS STRING) AS show_name,
        CAST('N/A' AS STRING) AS deal_ad_units,
        pl.`Demo Band` AS demo_band,
        pl.`Event Date` AS event_date,
        MAX(pl.`Guaranteed Impressions`) AS guaranteed_impressions,
        MAX(pl.`Guaranteed Revenue`) AS guaranteed_revenue,
        MAX(pl.`Net Unit Cost`) AS net_unit_cost,
        SUM(pl.`Delivered Impressions`) AS delivered_impressions,
        SUM(pl.`Delivered Clicks`) AS delivered_clicks,
        CASE
            WHEN MAX(pl.`Line Item Type`) = 'SPONSORSHIP'
            THEN MAX(pl.`Net Unit Cost`)
            ELSE (MAX(pl.`Delivered Impressions`) * MAX(pl.`Net Unit Cost`)) / 1000.0
        END as delivered_revenue,
        SUM(0) as on_target_impressions
    FROM fox_bi_qa.gold_ad_sales.v_ft_gam_campaign_delivery pl
    -- WHERE pl.`AOS Deal ID` = 18683
    GROUP BY
        pl.`AOS Deal ID`,
        pl.`AOS Deal Name`,
        pl.`Campaign Start Date`,
        pl.`Campaign End Date`,
        pl.`Advertiser Name`,
        pl.`Agency Name`,
        pl.`Line Item Type`,
        pl.`Line Item ID`,
        pl.`Line Item Name`,
        pl.`Package Name`,
        pl.`Parent Line Item Name`,
        pl.`AOS Deal Line Item Name`,
        pl.`Device`,
        pl.`Demo Band`,
        pl.`Event Date`
),
unified_placement_level as (
    SELECT
         aos_deal_id
        ,aos_deal_name
        ,campaign_start_date
        ,campaign_end_date
        ,advertiser_name
        ,agency_name
        -- ,sales_channel_type
        ,placement_id
        ,placement_name
        ,package_name
        ,parent_line_item_name
        ,aos_deal_line_item_name
        ,line_item_type
        ,creative_id
        ,creative_name
        ,creative_duration
        ,device
        ,ad_unit_position
        ,video_vertical
        ,show_name
        ,deal_ad_units
        ,event_date
        ,demo_band
        ,MAX(net_unit_cost) net_unit_cost
        ,MAX(guaranteed_impressions) AS guaranteed_impressions
        ,MAX(guaranteed_revenue) AS guaranteed_revenue
        ,SUM(delivered_impressions) AS delivered_impressions
        ,SUM(delivered_revenue) delivered_revenue
        ,SUM(delivered_clicks) AS delivered_clicks
        ,SUM(on_target_impressions) AS on_target_impressions
    FROM
        (
            select * from fw_placement_level
            union all
            select * from gam_placement_level
        )
    GROUP BY
            aos_deal_id
            ,aos_deal_name
            ,campaign_start_date
            ,campaign_end_date
            ,advertiser_name
            ,agency_name
            -- ,sales_channel_type
            ,placement_id
            ,package_name
            ,parent_line_item_name
            ,aos_deal_line_item_name
            ,placement_name
            ,creative_id
            ,creative_name
            ,creative_duration
            ,device
            ,ad_unit_position
            ,video_vertical
            ,show_name
            ,deal_ad_units
            ,event_date
            ,demo_band
            ,line_item_type
)
, unified_placement_level_packages as (
  select aos_deal_id
        ,placement_id
        ,placement_name
        ,parent_line_item_name
        ,aos_deal_line_item_name
        ,count(distinct creative_id) as creative_id_count
        ,MAX(guaranteed_impressions) as guaranteed_impressions
        ,MAX(guaranteed_revenue) as guaranteed_revenue
        ,SUM(delivered_impressions) delivered_impressions
        -- ,SUM(delivered_revenue) as delivered_revenue
        ,case when sum(delivered_revenue) = 0 then 0
        when sum(delivered_revenue) > 0 then
        CASE 
          WHEN MAX(line_item_type) in ('SPONSORSHIP', 'BULK', 'STANDARD') THEN 
            CASE
                WHEN MAX(line_item_type) = 'SPONSORSHIP' THEN MAX(guaranteed_revenue)
                ELSE (SUM(delivered_impressions) * MAX(net_unit_cost)) / 1000.0
            END 
          ELSE SUM(delivered_revenue)  
          end
        END AS delivered_revenue
        ,SUM(delivered_clicks) as delivered_clicks
    from unified_placement_level
    group by all
  UNION
  SELECT
         aos_deal_id
        ,line_item_or_placement_id
        ,line_item_or_placement_name
        ,parent_line_item_name
        ,aos_deal_line_item_name
        ,SUM(0) as creative_id_count
        ,MAX(guaranteed_impressions) AS guaranteed_impressions
        ,MAX(guaranteed_revenue) AS guaranteed_revenue
        ,SUM(delivered_impressions) AS delivered_impressions
        ,SUM(delivered_revenue) delivered_revenue
        ,SUM(delivered_clicks) AS delivered_clicks
    FROM
            fox_bi_qa.gold_ad_sales.ft_unified_campaign_delivery
    where `Data_Source` = 'Non Ad Served' 
    --and aos_deal_id = ?
    GROUP BY
            aos_deal_id
            ,line_item_or_placement_id
            ,line_item_or_placement_name
            ,parent_line_item_name
            ,aos_deal_line_item_name
)
, unified_placement_third_party as (
    select 
  aos_deal_id
  ,line_item_or_placement_id placement_id
  ,sum(case
        when third_party_revenue = 0 then 0 
        when third_party_revenue > 0 then
        case
          when  nvl(third_party_line_item_id,'-1') = '-1' then 0
          when data_source = 'GAM' then 
              CASE
                  WHEN Demand_Type = 'SPONSORSHIP' THEN guaranteed_revenue
                  ELSE ((third_party_impressions) * net_unit_cost)/1000
              END 
          else (third_party_revenue)
    end
    end) as placement_third_party_revenue
    ,SUM(third_party_impressions) as placement_third_party_impressions
    ,SUM(third_party_clicks) as placement_third_party_clicks
    ,SUM(third_party_video_completes) as placement_third_party_video_completes
    ,SUM(third_party_video_views) as placement_third_party_video_views
 from
    (
SELECT
        pl.aos_deal_id,
        line_item_or_placement_id,
        aos_deal_line_item_id,
        demand_type,
        third_party_line_item_id,
        Data_Source,
        Net_Unit_Cost,
        guaranteed_impressions,
        guaranteed_revenue,
        SUM(third_party_impressions) as third_party_impressions,
        SUM(third_party_revenue) as third_party_revenue,
        SUM(third_party_clicks) as third_party_clicks,
        SUM(third_party_video_completes) as third_party_video_completes,
        SUM(third_party_video_views) as third_party_video_views
FROM (
    SELECT DISTINCT
        `AOS Deal ID` aos_deal_id,
        `Line Item or Placement ID` Line_Item_or_Placement_ID,
        `Third Party Line Item ID` Third_Party_Line_Item_ID,
        `Demand Type` Demand_Type,
        `AOS Deal Line Item ID` AOS_Deal_Line_Item_ID,
        `Event Date` Event_Date,
        `Data Source` Data_Source,
        `Net Unit Cost` Net_Unit_Cost,
        `Guaranteed Impressions` guaranteed_impressions,
        `Guaranteed Revenue` guaranteed_revenue,
        MIN(`Third Party Billable Impressions`) as third_party_impressions,
        MIN(`Third Party Revenue`) as third_party_revenue,
        MIN(`Third Party Clicks`) as third_party_clicks,
        MIN(`Third Party Video Completes`) as third_party_video_completes,
        MIN(`Third Party Video Views`) as third_party_video_views
    FROM fox_bi_qa.gold_ad_sales.v_unified_campaign_delivery
    -- WHERE `AOS Deal ID` = ?
    GROUP BY ALL
) pl
GROUP BY all)
group by all
)


,3p_matrices_fetch as (

SELECT
AOS_Deal_ID,
sum(`Source Total Delivered Impressions`) as `Source Total Delivered Impressions`,
sum(`Source Total Delivered Revenue`) as `Source Total Delivered Revenue`,
sum(`Source Total Guaranteed Impressions`) as `Source Total Guaranteed Impressions`,
sum(`Source Total Guaranteed Revenue`) as `Source Total Guaranteed Revenue`,
sum(`Source Total Third Party Impressions`) as `Source Total Third Party Impressions`,
sum(`Source Total Third Party Revenue`) as `Source Total Third Party Revenue`
from
(
SELECT 
    pl.aos_deal_id as AOS_Deal_ID,
    CAST(SUM(pl.delivered_impressions) AS BIGINT) as `Source Total Delivered Impressions`,
    CAST(SUM(pl.delivered_revenue) AS DECIMAL(19,2)) as `Source Total Delivered Revenue`,
    CAST(SUM(pl.guaranteed_impressions) AS BIGINT) as `Source Total Guaranteed Impressions`,
    CAST(SUM(pl.guaranteed_revenue) AS DECIMAL(19,2)) as `Source Total Guaranteed Revenue`,
    CAST(SUM(ptp.placement_third_party_impressions) AS BIGINT) as `Source Total Third Party Impressions`,
    CAST(SUM(ptp.placement_third_party_revenue) AS DECIMAL(19,2)) as `Source Total Third Party Revenue`
FROM (select * from unified_placement_level_packages) pl
    LEFT JOIN unified_placement_third_party ptp ON pl.placement_id = ptp.placement_id
    GROUP BY (CASE 
            WHEN pl.parent_line_item_name = 'N/A' THEN pl.aos_deal_line_item_name
            ELSE coalesce(pl.parent_line_item_name, pl.aos_deal_line_item_name)
        END), pl.aos_deal_id
)
group by AOS_Deal_ID
)

SELECT
distinct
src.`AOS Deal ID` as AOS_Deal_ID,
CAST(src.`Total First Party Delivered Impressions` AS BIGINT) as `Source Total Delivered Impressions`,
CAST(src.`Total First Party Delivered Revenue` AS DECIMAL(19,2)) as `Source Total Delivered Revenue`,
CAST(src.`Total Guaranteed Impressions` AS BIGINT) as `Source Total Guaranteed Impressions`,
CAST(src.`Budget` AS DECIMAL(19,2)) as `Source Total Guaranteed Revenue`,
CAST(src.`Total Third Party Impressions` AS BIGINT) as `Source Total Third Party Impressions`,
CAST(src.`Total Third Party Revenue` AS DECIMAL(19,2)) as `Source Total Third Party Revenue`
-- pl.`Source Total Third Party Impressions` as `Source Total Third Party Impressions`,
-- pl.`Source Total Third Party Revenue` as `Source Total Third Party Revenue`
from
(select distinct * from fox_bi_qa.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal) as src
inner join
(select distinct * from 3p_matrices_fetch) pl
on src.`AOS Deal ID` = pl.AOS_Deal_ID

""")

display(src_df_pp)


### Validation Comparison

from pyspark.sql.functions import col, when, expr, nvl, abs, lit, array, concat_ws

# Join source and target on AOS_Deal_ID
joined_df_pp = src_df_pp.join(
    tar_df_pp,
    on="AOS_Deal_ID",
    how="full_outer"
)

display(joined_df_pp)


# Add comparison columns - only for columns that exist in both dataframes
validation_df_pp = joined_df_pp.withColumn(
    "Source_Total_Delivered_Impressions",
    nvl(col("`Source Total Delivered Impressions`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Impressions",
    nvl(col("`Target Total Delivered Impressions`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Revenue",
    nvl(col("`Source Total Delivered Revenue`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Revenue",
    nvl(col("`Target Total Delivered Revenue`"), lit(0))
).withColumn(
    "Source_Total_Guaranteed_Impressions",
    nvl(col("`Source Total Guaranteed Impressions`"), lit(0))
).withColumn(
    "Target_Total_Guaranteed_Impressions",
    nvl(col("`Target Total Guaranteed Impressions`"), lit(0))
).withColumn(
    "Source_Total_Guaranteed_Revenue",
    nvl(col("`Source Total Guaranteed Revenue`"), lit(0))
).withColumn(
    "Target_Total_Guaranteed_Revenue",
    nvl(col("`Target Total Guaranteed Revenue`"), lit(0))
).withColumn(
    "Source_Total_Third_Party_Impressions",
    nvl(col("`Source Total Third Party Impressions`"), lit(0))
).withColumn(
    "Target_Total_Third_Party_Impressions",
    nvl(col("`Target Total Third Party Impressions`"), lit(0))
).withColumn(
    "Source_Total_Third_Party_Revenue",
    nvl(col("`Source Total Third Party Revenue`"), lit(0))
).withColumn(
    "Target_Total_Third_Party_Revenue",
    nvl(col("`Target Total Third Party Revenue`"), lit(0))
).withColumn(
    "Variance_Delivered_Impressions",
    col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")
).withColumn(
    "Variance_Delivered_Revenue",
    col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")
).withColumn(
    "Variance_Guaranteed_Impressions",
    col("Source_Total_Guaranteed_Impressions") - col("Target_Total_Guaranteed_Impressions")
).withColumn(
    "Variance_Guaranteed_Revenue",
    col("Source_Total_Guaranteed_Revenue") - col("Target_Total_Guaranteed_Revenue")
).withColumn(
    "Variance_Total_Third_Party_Impressions",
    col("Source_Total_Third_Party_Impressions") - col("Target_Total_Third_Party_Impressions")
).withColumn(
    "Variance_Total_Third_Party_Revenue",
    col("Source_Total_Third_Party_Revenue") - col("Target_Total_Third_Party_Revenue")
).withColumn(
    "Delivered_Impressions_Match",
    when(
        abs(col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Delivered_Revenue_Match",
    when(
        abs(col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Guaranteed_Impressions_Match",
    when(
        abs(col("Source_Total_Guaranteed_Impressions") - col("Target_Total_Guaranteed_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Guaranteed_Revenue_Match",
    when(
        abs(col("Source_Total_Guaranteed_Revenue") - col("Target_Total_Guaranteed_Revenue")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Total_Third_Party_Impressions_Match",
    when(
        abs(col("Source_Total_Third_Party_Impressions") - col("Target_Total_Third_Party_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Total_Third_Party_Revenue_Match",
    when(
        abs(col("Source_Total_Third_Party_Revenue") - col("Target_Total_Third_Party_Revenue")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Status",
    when(
        (col("Delivered_Impressions_Match") == True) &
        (col("Delivered_Revenue_Match") == True) &
        (col("Guaranteed_Impressions_Match") == True) &
        (col("Guaranteed_Revenue_Match") == True) &
        (col("Total_Third_Party_Impressions_Match") == True) &
        (col("Total_Third_Party_Revenue_Match") == True),
        True
    ).otherwise(False)
).select(
    col("AOS_Deal_ID"),
    col("Source_Total_Delivered_Impressions"),
    col("Target_Total_Delivered_Impressions"),
    col("Variance_Delivered_Impressions"),
    col("Delivered_Impressions_Match"),
    col("Source_Total_Delivered_Revenue"),
    col("Target_Total_Delivered_Revenue"),
    col("Variance_Delivered_Revenue"),
    col("Delivered_Revenue_Match"),
    col("Source_Total_Guaranteed_Impressions"),
    col("Target_Total_Guaranteed_Impressions"),
    col("Variance_Guaranteed_Impressions"),
    col("Guaranteed_Impressions_Match"),
    col("Source_Total_Guaranteed_Revenue"),
    col("Target_Total_Guaranteed_Revenue"),
    col("Variance_Guaranteed_Revenue"),
    col("Guaranteed_Revenue_Match"),
    col("Source_Total_Third_Party_Impressions"),
    col("Target_Total_Third_Party_Impressions"),
    col("Variance_Total_Third_Party_Impressions"),
    col("Total_Third_Party_Impressions_Match"),
    col("Source_Total_Third_Party_Revenue"),
    col("Target_Total_Third_Party_Revenue"),
    col("Variance_Total_Third_Party_Revenue"),
    col("Total_Third_Party_Revenue_Match"),
    col("Status")
)

display(validation_df_pp)


# Create a dataframe showing which columns have mismatches for deals where Status is False
mismatch_details_df_pp = validation_df_pp.withColumn(
    "Mismatched_Columns_Array",
    array(
        when(col("Delivered_Impressions_Match") == False, lit("Delivered_Impressions")).otherwise(lit(None)),
        when(col("Delivered_Revenue_Match") == False, lit("Delivered_Revenue")).otherwise(lit(None)),
        when(col("Guaranteed_Impressions_Match") == False, lit("Guaranteed_Impressions")).otherwise(lit(None)),
        when(col("Guaranteed_Revenue_Match") == False, lit("Guaranteed_Revenue")).otherwise(lit(None)),
        when(col("Total_Third_Party_Impressions_Match") == False, lit("Total_Third_Party_Impressions")).otherwise(lit(None)),
        when(col("Total_Third_Party_Revenue_Match") == False, lit("Total_Third_Party_Revenue")).otherwise(lit(None))
    )
).withColumn(
    "Mismatched_Columns_Array",
    expr("filter(Mismatched_Columns_Array, x -> x is not null)")
).withColumn(
    "Mismatched_Columns",
    concat_ws(", ", col("Mismatched_Columns_Array"))
).select(
    col("AOS_Deal_ID").alias("deal_id"),
    when(col("Status") == True, lit("True"))
    .when(col("Status") == False, lit("False"))
    .otherwise(lit("False")).cast("string").alias("Status"),
    col("Mismatched_Columns")
).distinct()

print("=" * 80)
print(f"Deal Mismatch Details")
print(f"Total Deals with Mismatches: {mismatch_details_df_pp.count()}")
print("=" * 80)

display(mismatch_details_df_pp)

# Find deal_ids that are only in target table and not in source table
source_only_deals_pp = spark.sql(f"""
    SELECT 
        t.`AOS Deal ID` as AOS_Deal_ID,
        t.`Total Delivered Impressions` as `Target Total Delivered Impressions`,
        t.`Total Delivered Revenue` as `Target Total Delivered Revenue`,
        t.`Total Guaranteed Impressions` as `Target Total Guaranteed Impressions`,
        t.`Budget` as `Target Total Guaranteed Revenue`,
        t.`Total Third Party Impressions` as `Target Total Third Party Impressions`,
        t.`Total Third Party Revenue` as `Target Total Third Party Revenue`
    FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal t
    WHERE t.`AOS Deal ID` IS NOT NULL
        AND t.`AOS Deal ID` != -1
        AND NOT EXISTS (
            SELECT 1
            FROM {catalog_name}.gold_ad_sales.v_wrap_detailed_unified_report_sections_by_deal s
            WHERE s.AOS_Deal_ID = t.`AOS Deal ID`
                AND s.data_type = 'PACKAGE_PERFORMANCE'
        )
    ORDER BY t.`AOS Deal ID`
""")

print("=" * 80)
print(f"Deal IDs only in v_ft_unified_campaign_delivery_by_deal Table (v_ft_unified_campaign_delivery_by_deal)")
print(f"Count: {source_only_deals_pp.count()}")
print("=" * 80)

display(source_only_deals_pp)


# Update mismatch_details_df_pp to include deals from source_only_deals_pp with Status = "missing deals"
# First, convert Status to string in mismatch_details_df_pp to allow "missing deals" value
mismatch_details_df_1_pp = mismatch_details_df_pp.withColumn(
    "Status",
    when(col("Status") == True, lit("True"))
    .when(col("Status") == False, lit("False"))
    .otherwise(col("Status").cast("string"))
)

# Create a dataframe for missing deals with the same structure as mismatch_details_df_pp
missing_deals_df_pp = source_only_deals_pp.select(
    col("AOS_Deal_ID").alias("deal_id"),
    lit("missing deals").cast("string").alias("Status"),
    lit("Deal not found in source table").cast("string").alias("Mismatched_Columns")
)

display(missing_deals_df_pp)
display(mismatch_details_df_1_pp)

# Option 1: Use a broadcast join with a flag, then check if deal_id exists in source_only_deals_pp
from pyspark.sql.functions import broadcast

# Create a set of deal_ids from source_only_deals_pp for efficient lookup
source_only_deal_ids_pp = source_only_deals_pp.select(col("AOS_Deal_ID").alias("deal_id")).distinct()

# Join and check if deal_id exists in source_only_deals_pp
mismatch_details_df_1_pp = mismatch_details_df_1_pp.join(
    broadcast(source_only_deal_ids_pp).withColumn("is_source_only", lit(True)),
    on="deal_id",
    how="left"
).withColumn(
    "Status",
    when(col("is_source_only").isNotNull(), lit("not found in source").cast("string"))
    .otherwise(col("Status").cast("string"))
).select(
    col("deal_id"),
    col("Status").cast("string").alias("Status"),
    col("Mismatched_Columns")
)

# Union with missing_deals_df_pp to include all deals that are only in target table
mismatch_details_df_1_pp = mismatch_details_df_1_pp.unionByName(
    missing_deals_df_pp,
    allowMissingColumns=True
).distinct()

display(mismatch_details_df_1_pp)


# Create a dataframe with deal_id and PACKAGE_PERFORMANCE (True if Status is True, False otherwise)
deal_status_df_pp = mismatch_details_df_1_pp.select(
    col("deal_id"),
    when(col("Status") == "True", lit("True"))
    .when(col("Status") == "False", lit("False"))
    .otherwise(col("Status"))
    .alias("PACKAGE_PERFORMANCE")
).distinct()

print("=" * 80)
print(f"Deal Status Summary")
print(f"Total Deals: {deal_status_df_pp.count()}")
print(f"Deals with PACKAGE_PERFORMANCE = True: {deal_status_df_pp.filter(col('PACKAGE_PERFORMANCE') == 'True').count()}")
print(f"Deals with PACKAGE_PERFORMANCE = False: {deal_status_df_pp.filter(col('PACKAGE_PERFORMANCE') == 'False').count()}")
print("=" * 80)

display(deal_status_df_pp)

# COMMAND ----------

deal_status_df_pp.createOrReplaceGlobalTempView("deal_status_df_pp")

# COMMAND ----------

from pyspark.sql.functions import lit, col, when, abs as spark_abs, stack, round as spark_round

unpivoted_df_pp = validation_df_pp.filter(
    col("Status") == False
).select(
    lit("PACKAGE_PERFORMANCE").alias("parse_type"),
    col("AOS_Deal_ID").alias("aos_deal_id"),
    stack(
        lit(6),
        lit("Total_Delivered_Impressions"),
        col("Source_Total_Delivered_Impressions").cast("double"),
        col("Target_Total_Delivered_Impressions").cast("double"),

        lit("Total_Delivered_Revenue"),
        col("Source_Total_Delivered_Revenue").cast("double"),
        col("Target_Total_Delivered_Revenue").cast("double"),

        lit("Total_Guaranteed_Impressions"),
        col("Source_Total_Guaranteed_Impressions").cast("double"),
        col("Target_Total_Guaranteed_Impressions").cast("double"),

        lit("Total_Guaranteed_Revenue"),
        col("Source_Total_Guaranteed_Revenue").cast("double"),
        col("Target_Total_Guaranteed_Revenue").cast("double"),

        lit("Total_Third_Party_Impressions"),
        col("Source_Total_Third_Party_Impressions").cast("double"),
        col("Target_Total_Third_Party_Impressions").cast("double"),

        lit("Total_Third_Party_Revenue"),
        col("Source_Total_Third_Party_Revenue").cast("double"),
        col("Target_Total_Third_Party_Revenue").cast("double"),
    ).alias("metric_name", "source_value", "target_value")
).withColumn(
    "mismatch_percent_variance",
    when(
        (col("source_value") == 0) & (col("target_value") == 0), lit(0.0)
    ).when(
        col("source_value") == 0, lit(100.0)
    ).otherwise(
        spark_round(
            spark_abs(col("source_value") - col("target_value")) / spark_abs(col("source_value")) * 100,
            2
        )
    )
).filter(
    col("mismatch_percent_variance") > 1
)

display(unpivoted_df_pp)

# COMMAND ----------

table_name = "fox_bi_dev.bronze_ads.wrap_report_package_performance_mismatches"

if spark.catalog.tableExists(table_name):
    unpivoted_df_pp.write.mode("overwrite").saveAsTable(table_name)
else:
    unpivoted_df_pp.write.saveAsTable(table_name)

# COMMAND ----------

dbutils.widgets.text("threshold_limit", "111", "Delivery Threshold %")
THRESHOLD_LIMIT = int(dbutils.widgets.get("threshold_limit"))

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import row_number

thresh_df_pp = spark.sql(f"""
    SELECT 
        AOS_Deal_ID,
        field1 as `Package_Name`,
        SUM(try_cast(field2 AS BIGINT)) as `Total_Delivered_Impressions`,
        SUM(try_cast(field3 AS DECIMAL(19,2))) as `Total_Delivered_Revenue`,
        SUM(try_cast(field7 AS BIGINT)) as `Total_Guaranteed_Impressions`,
        SUM(try_cast(field8 AS DECIMAL(19,2))) as `Total_Guaranteed_Revenue`,
        SUM(try_cast(field5 AS BIGINT)) as `Total_Third_Party_Impressions`,
        SUM(try_cast(field6 AS DECIMAL(19,2))) as `Total_Third_Party_Revenue`
    FROM {catalog_name}.gold_ad_sales.v_wrap_detailed_unified_report_sections_by_deal
    WHERE data_type = 'PACKAGE_PERFORMANCE'
    GROUP BY AOS_Deal_ID,field1
""")

display(thresh_df_pp)

final_thresh_df_pp = thresh_df_pp\
                                .withColumn("threshold_1P_delivery_percent_variance", round(try_divide((col("Total_Delivered_Impressions") - col("Total_Guaranteed_Impressions")), col("Total_Guaranteed_Impressions")), 2)*100)\
                                .withColumn("threshold_3P_delivery_percent_variance", round(try_divide((col("Total_Third_Party_Impressions") - col("Total_Guaranteed_Impressions")), col("Total_Guaranteed_Impressions")), 2)*100)\
                                .filter((col("threshold_1P_delivery_percent_variance") > THRESHOLD_LIMIT) | (col("threshold_3P_delivery_percent_variance") > THRESHOLD_LIMIT))


display(final_thresh_df_pp)
window_spec = Window.partitionBy("AOS_Deal_ID").orderBy(col("Total_Delivered_Impressions").desc())
final_thresh_df_pp = final_thresh_df_pp.withColumn("rn", row_number().over(window_spec)).filter(col("rn") <= 10).drop("rn")

display(final_thresh_df_pp)

# COMMAND ----------

table_name_th = "fox_bi_dev.bronze_ads.wrap_report_package_performance_threshold_exceed"

if spark.catalog.tableExists(table_name_th):
    final_thresh_df_pp.write.mode("overwrite").saveAsTable(table_name_th)
else:
    final_thresh_df_pp.write.saveAsTable(table_name_th)

# COMMAND ----------

dbutils.notebook.exit("success")