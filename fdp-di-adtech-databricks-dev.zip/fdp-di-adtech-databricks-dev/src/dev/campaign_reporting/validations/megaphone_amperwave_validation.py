# Databricks notebook source
# Megaphone Amperwave Validation
# This notebook validates campaign delivery data by comparing third-party (staq) 
# data against internal gold views for both Megaphone and Amperwave platforms.
# It downloads reports from staq, compares metrics, and sends validation reports via email.

# COMMAND ----------

pip install boto3==1.40.49 s3fs

# COMMAND ----------

import os
from datetime import datetime, timedelta
import pandas as pd
import boto3
from typing import Any
import csv
from pyspark.sql import DataFrame
from pyspark.sql.functions import to_date
from pyspark.sql.types import StructType
import pyspark.sql.functions as F
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from email.mime.text import MIMEText

# COMMAND ----------

env = dbutils.widgets.get('env')
aws_arn = dbutils.widgets.get('aws_arn')
aws_profile = dbutils.widgets.get('aws_profile')

os.environ["AWS_PROFILE_VAR"] = aws_profile
os.environ["AWS_ARN"] = aws_arn

staq_bucket = dbutils.widgets.get('staq_bucket')

validation_type = dbutils.widgets.get('validation_type') #HISTORICAL or DAILY

if validation_type == 'HISTORICAL':
  validation_start_date = dbutils.widgets.get('validation_start_date')  
  validation_end_date = dbutils.widgets.get('validation_end_date')
  days_to_filter = (datetime.strptime(validation_end_date, '%Y-%m-%d') - datetime.strptime(validation_start_date, '%Y-%m-%d')).days
elif validation_type == 'DAILY':
  validation_start_date = dbutils.widgets.get('validation_start_date')  
  validation_end_date = dbutils.widgets.get('validation_end_date')
  days_to_filter = 8


if env == 'dev':
  catalog_name = 'fox_bi_dev'
  raw_schema_name = 'raw_ads'
  gold_schema_name = 'gold_ads'
  # Email configuration for validation report notifications
  from_email = 'adsales.dev@data.fox'
  to_email = ["noormahammad.nalband@fox.com", ]
  fail_email = []
  cc_email = []
elif env == 'prod':
  catalog_name = 'fox_bi_prod'
  raw_schema_name = 'raw_ads'
  gold_schema_name = 'gold_ads'
  # Email configuration for validation report notifications
  from_email = 'adsales.prod@data.fox'
  to_email = ["noormahammad.nalband@fox.com", ]
  fail_email = []
  cc_email = []

print(validation_start_date, validation_end_date, days_to_filter)

# COMMAND ----------

# MAGIC %sh
# MAGIC aws configure set region us-west-2 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set s3.signature_version s3v4 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile $AWS_PROFILE_VAR
# MAGIC aws configure set role_arn $AWS_ARN --profile $AWS_PROFILE_VAR

# COMMAND ----------

def find_staq_file(report_date: datetime) -> str:
    session = boto3.Session(profile_name=aws_profile)
    s3 = session.client('s3')

    staq = 'STAQ_Megaphone_Amperwave_L7_Days_' + report_date.strftime('%Y-%m-%d')
    megaphone_prefix = 'megaphone/'

    paginator = s3.get_paginator('list_objects_v2')
    page_iterator = paginator.paginate(Bucket=staq_bucket, Prefix=megaphone_prefix)

    for page in page_iterator:
        for obj in page.get('Contents', []):
            if staq in obj['Key']:
                return obj['Key']

def generate_dates(validation_start_date: str, validation_end_date: str):
    dates = pd.date_range(datetime.strptime(validation_start_date, '%Y-%m-%d'), datetime.strptime(validation_end_date,  '%Y-%m-%d'), freq='D')
    return dates

def update_daily_breakouts(file_path: str) -> None:
    last_n = pd.read_csv(
        f's3://{staq_bucket}/{file_path}',
        parse_dates=['Date'],
        encoding='utf-8',
        storage_options={'profile': aws_profile},
        quotechar='"',
        doublequote=True,
        quoting=csv.QUOTE_MINIMAL
    )
    return last_n

# COMMAND ----------

def write_to_table(df):
  if not spark.catalog.tableExists(f'{catalog_name}.{raw_schema_name}.megaphone_amperwave_campaign_reporting_delivery_validation'):
    df.write.format('delta')\
        .mode('overwrite')\
        .partitionBy('event_date')\
        .option('mergeSchema', 'true')\
        .option('overwriteDynamicPartitions', 'true')\
        .option('delta.enableDeletionVectors', 'false')\
        .option('delta.enableIcebergCompatV2', 'true')\
        .option('delta.universalFormat.enabledFormats', 'iceberg')\
        .option('delta.columnMapping.mode', 'name')\
        .saveAsTable(f"{catalog_name}.{raw_schema_name}.megaphone_amperwave_campaign_reporting_delivery_validation")
  else:
    df.write.format('delta')\
        .mode('overwrite')\
        .option('partitionOverwriteMode', 'dynamic')\
        .saveAsTable(f"{catalog_name}.{raw_schema_name}.megaphone_amperwave_campaign_reporting_delivery_validation")

# COMMAND ----------

if __name__ == '__main__':
    def parse_date(date: str) -> bool:
        format = "%Y-%m-%d"
        try:
            res = bool(datetime.strptime(date, format))
        except ValueError:
            res = False
        return res

    assert parse_date(validation_start_date), "Invalid date format, should be in YYYY-MM-DD format"
    assert parse_date(validation_end_date), "Invalid date format, should be in YYYY-MM-DD format"
    assert datetime.strptime(validation_start_date, "%Y-%m-%d") <= datetime.strptime(validation_end_date, "%Y-%m-%d"), "validation_start_date should be less than or equal to validation_end_date"

    #report_date = datetime.strptime(report_date, "%Y-%m-%d")
    spark.sql(f"""truncate table {catalog_name}.{raw_schema_name}.megaphone_amperwave_campaign_reporting_delivery_validation""")
              
    if True:
        if validation_start_date != validation_end_date:
            dates_to_process = generate_dates(validation_start_date, validation_end_date)
            print(dates_to_process)
            src_df = spark.createDataFrame([], StructType([]))
            for processing_date in dates_to_process:
                staq = find_staq_file(processing_date)
                print(staq)
                if staq is not None:
                    res = update_daily_breakouts(staq)
                    df = spark.createDataFrame(res)

                    if spark.catalog.tableExists(f"{catalog_name}.{raw_schema_name}.megaphone_amperwave_campaign_reporting_delivery_validation"):
                        df = df.withColumn('event_date', to_date(df['Date']))
                        table_schema = spark.table(f"{catalog_name}.{raw_schema_name}.megaphone_amperwave_campaign_reporting_delivery_validation").schema
                    else:
                        df = df.withColumn('event_date', to_date(df['Date']))
                        table_schema = df.schema

                    df = spark.createDataFrame(df.rdd, schema=table_schema)
                    write_to_table(df)


               
        else:
            report_date = validation_start_date
            print("Processing date: ", report_date)
            staq = find_staq_file(datetime.strptime(report_date, '%Y-%m-%d'))
            print(staq)
            if staq is not None:
                res = update_daily_breakouts(staq)
                df = spark.createDataFrame(res)

                if spark.catalog.tableExists(f"{catalog_name}.{raw_schema_name}.megaphone_amperwave_campaign_reporting_delivery_validation"):
                    df = df.withColumn('event_date', to_date(df['Date']))
                    table_schema = spark.table(f"{catalog_name}.{raw_schema_name}.megaphone_amperwave_campaign_reporting_delivery_validation").schema
                else:
                    df = df.withColumn('event_date', to_date(df['Date']))
                    table_schema = df.schema
                    
                df = spark.createDataFrame(df.rdd, schema=table_schema)
                write_to_table(df)


    src_df = spark.sql(f"""
        SELECT * FROM {catalog_name}.{raw_schema_name}.megaphone_amperwave_campaign_reporting_delivery_validation
    """)                       
    display(src_df)

# COMMAND ----------

# MAGIC %sh
# MAGIC aws configure set region us-west-2 --profile databricks-fng-prod
# MAGIC aws configure set s3.signature_version s3v4 --profile databricks-fng-prod
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile databricks-fng-prod
# MAGIC aws configure set role_arn arn:aws:iam::640862407089:role/fng-dmo-prod-databricks-ec2-role --profile databricks-fng-prod

# COMMAND ----------

class cls_ssm(object):
    def __init__(self, aws_profile='default'):    
        import boto3
        try:
            session = boto3.Session(profile_name = aws_profile)
            client = session.client('ssm')

            self.client=client
            self.aws_profile=aws_profile

        except Exception as e:
            raise Exception('ERROR: '+ str(e))
        
    def get_ssm_param_by_path(self, path, full_path_dict_key=False, next_token=' ', keyvalue_dict={}) :
        # Get all values for all keys from SSM Path as Dictionary
        try:
            #-----------------------------------------------------------------------------------------------------------
            # To reset the keyvalue_dict we need to have below code , if we remove it is having trace of previous calls
            #-----------------------------------------------------------------------------------------------------------
            if next_token==' ':
                keyvalue_dict={}
                response  = self.client.get_parameters_by_path(Path=path, WithDecryption=True, Recursive=True)
            else:
                response  = self.client.get_parameters_by_path(Path=path, NextToken=next_token, WithDecryption=True, Recursive=True)

            for parameter in response['Parameters'] :

                if full_path_dict_key:
                    key = parameter['Name']
                else:
                    key = parameter['Name'].split('/')[-1]

                keyvalue_dict[key] = parameter['Value']
            #---------------------------------------------------------------------------------------------------------------
            # if there is more than 10 param in same path we need to paginate through next sets using next token from response
            #--------------------------------------------------------------------------------------------------------------
            if 'NextToken' in response.keys():
                next_token = response['NextToken']
                keyvalue_dict = self.get_ssm_param_by_path(path, full_path_dict_key, next_token, keyvalue_dict)

            if keyvalue_dict=={}:
                value = self.client.get_parameter(Name = path, WithDecryption = True)['Parameter']['Value']

                if full_path_dict_key:
                    key = path
                else:
                    key = path.split('/')[-1]

                keyvalue_dict[key]=value

            #print(keyvalue_dict)
            return keyvalue_dict
        except Exception as e:
            raise Exception('ERROR: '+ str(e))


# COMMAND ----------

# MAGIC %md
# MAGIC ###Source Data

# COMMAND ----------

# Process source data: Filter and aggregate Amperwave data from staq report
# Remove commas from numeric fields, convert to integers, and aggregate by date
src_amperwave_df = src_df.filter(F.col('partner_server_name') == 'Amperwave') \
    .withColumn('event_date', F.to_date(F.col('event_date'))) \
    .withColumnRenamed('partner_server_name', 'partner_server_name') \
    .withColumn('delivered_impressions_int', F.regexp_replace(F.col('delivered_impressions'), ',', '').cast('double')) \
    .withColumn('available_impressions_int', F.regexp_replace(F.col('available_impressions'), ',', '').cast('double')) \
    .withColumn('direct_sold_impressions_int', F.regexp_replace(F.col('direct_sold_impressions'), ',', '').cast('double')) \
    .withColumn('span_impressions_int', F.regexp_replace(F.col('span_impressions'), ',', '').cast('double')) \
    .withColumn('promo_impressions_int', F.regexp_replace(F.col('promo_impressions'), ',', '').cast('double')) \
    .withColumn('order_revenue_int', F.regexp_replace(F.col('order_revenue'), ',', '').cast('double')) \
    .groupBy('event_date', 'partner_server_name') \
    .agg(
        F.coalesce(F.sum('delivered_impressions_int'), F.lit(0)).alias('staq_delivered_impressions'),
        F.coalesce(F.sum('available_impressions_int'), F.lit(0)).alias('staq_available_impressions'),
        F.coalesce(F.sum('direct_sold_impressions_int'), F.lit(0)).alias('staq_direct_sold_impressions'),
        F.coalesce(F.sum('span_impressions_int'), F.lit(0)).alias('staq_span_impressions'),
        F.coalesce(F.sum('promo_impressions_int'), F.lit(0)).alias('staq_promo_impressions'),
        F.coalesce(F.sum('order_revenue_int'), F.lit(0)).alias('staq_order_revenue')
    ) \
    .withColumnRenamed('event_date', 'src_event_date')

# Process source data: Filter and aggregate Megaphone data from staq report
src_megaphone_df = src_df.filter(F.col('partner_server_name') == 'Megaphone') \
    .withColumn('event_date', F.to_date(F.col('event_date'))) \
    .withColumnRenamed('Local Server Name', 'partner_server_name') \
    .withColumn('delivered_impressions_int', F.regexp_replace(F.col('delivered_impressions'), ',', '').cast('double')) \
    .withColumn('available_impressions_int', F.regexp_replace(F.col('available_impressions'), ',', '').cast('double')) \
    .withColumn('direct_sold_impressions_int', F.regexp_replace(F.col('direct_sold_impressions'), ',', '').cast('double')) \
    .withColumn('span_impressions_int', F.regexp_replace(F.col('span_impressions'), ',', '').cast('double')) \
    .withColumn('promo_impressions_int', F.regexp_replace(F.col('promo_impressions'), ',', '').cast('double')) \
    .withColumn('order_revenue_int', F.regexp_replace(F.col('order_revenue'), ',', '').cast('double')) \
    .groupBy('event_date', 'partner_server_name') \
    .agg(
        F.coalesce(F.sum('delivered_impressions_int'), F.lit(0)).alias('staq_delivered_impressions'),
        F.coalesce(F.sum('available_impressions_int'), F.lit(0)).alias('staq_available_impressions'),
        F.coalesce(F.sum('direct_sold_impressions_int'), F.lit(0)).alias('staq_direct_sold_impressions'),
        F.coalesce(F.sum('span_impressions_int'), F.lit(0)).alias('staq_span_impressions'),
        F.coalesce(F.sum('promo_impressions_int'), F.lit(0)).alias('staq_promo_impressions'),
        F.coalesce(F.sum('order_revenue_int'), F.lit(0)).alias('staq_order_revenue')
    ) \
    .withColumnRenamed('event_date', 'src_event_date')

display(src_amperwave_df)
display(src_megaphone_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Target Data

# COMMAND ----------

# Retrieve target data from gold views: Amperwave campaign delivery metrics
# Data is aggregated by event date for the last 7 days
tar_amperwave_df = spark.sql(
  f"""
  SELECT
    `Event Date` AS tar_event_date,
    coalesce(SUM(`Delivered Impressions`),0) AS gold_delivered_impressions,
    coalesce(SUM(`Available Impressions`),0) AS gold_available_impressions,
    coalesce(SUM(`Order Revenue Amount`),0) AS gold_order_revenue_amount,
    coalesce(SUM(`Direct Sold Impressions`),0) AS gold_direct_sold_impressions,
    coalesce(SUM(`Span Impressions`),0) AS gold_span_impressions,
    coalesce(SUM(`Promo Impressions`),0) AS gold_promo_impressions
  FROM
    {catalog_name}.{gold_schema_name}.v_ft_amperwave_campaign_delivery
  WHERE
    `Event Date`>=current_date()-{days_to_filter}
  GROUP BY
    `Event Date`
  """)
display(tar_amperwave_df)

# Retrieve target data from gold views: Megaphone campaign delivery metrics
tar_megaphone_df = spark.sql(
  f"""
  SELECT
    `Event Date` AS tar_event_date,
    coalesce(SUM(`Delivered Impressions`),0) AS gold_delivered_impressions,
    coalesce(SUM(`Available Impressions`),0) AS gold_available_impressions,
    coalesce(SUM(`Order Revenue Amount`),0) AS gold_order_revenue_amount,
    coalesce(SUM(`Direct Sold Impressions`),0) AS gold_direct_sold_impressions,
    coalesce(SUM(`Span Impressions`),0) AS gold_span_impressions,
    coalesce(SUM(`Promo Impressions`),0) AS gold_promo_impressions
  FROM
    {catalog_name}.{gold_schema_name}.v_ft_megaphone_campaign_delivery
  WHERE
    `Event Date`>=current_date()-{days_to_filter}
  GROUP BY
    `Event Date`
  """)
display(tar_megaphone_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Validation

# COMMAND ----------

# Compare third-party source data with internal gold view data
# Calculates variance percentages and flags discrepancies
# Variance threshold: >5% difference triggers a 'Variance' comment
def compare_data(src_df, tar_df):
    # Left join source and target dataframes on event_date
    joined_df = src_df.join(
        tar_df,
        src_df.src_event_date == tar_df.tar_event_date,
        how='left'
    )

    # Calculate variance percentage for impressions
    # Formula: ((third_party - gold) / gold) * 100
    # If gold is null, variance is set to 100% (missing data)
    compared_df = joined_df.withColumn(
        'delivered_impressions_variance_pct',
        F.when(
            F.col('gold_delivered_impressions').isNull(),
            F.lit(100.0)
        ).when(
            F.col('staq_delivered_impressions').isNotNull() & F.col('gold_delivered_impressions').isNotNull(),
            (F.col('staq_delivered_impressions') - F.col('gold_delivered_impressions')) / F.col('gold_delivered_impressions') * 100
        ).otherwise(None)
    ).withColumn(
        # Calculate variance percentage for clicks
        'available_impressions_variance_pct',
        F.when(
            F.col('gold_available_impressions').isNull(),
            F.lit(100.0)
        ).when(
            F.col('staq_available_impressions').isNotNull() & F.col('gold_available_impressions').isNotNull() & (F.col('gold_available_impressions') != 0),
            (F.col('staq_available_impressions') - F.col('gold_available_impressions')) / F.col('gold_available_impressions') * 100
        ).otherwise(None)
    )

    # Select relevant columns for comparison
    compared_df = compared_df.select('src_event_date', 'partner_server_name', 'staq_delivered_impressions','staq_available_impressions','gold_delivered_impressions','gold_available_impressions','delivered_impressions_variance_pct','available_impressions_variance_pct')

    # Add comment column to flag issues:
    # - 'Missing Date': No data in gold view for this date
    # - 'Variance': Variance exceeds 5% threshold for impressions or clicks
    # - '-': No issues detected
    compared_df = compared_df.withColumn('Comment', 
            F.when(F.col('gold_delivered_impressions').isNull() | F.col('gold_available_impressions').isNull(), 'Missing Date')
             .when((F.abs(F.col('delivered_impressions_variance_pct')) > 5) | (F.abs(F.col('available_impressions_variance_pct')) > 5) 
                    & (F.col('gold_delivered_impressions').isNotNull() & F.col('gold_available_impressions').isNotNull()), 'Variance')
             .otherwise('-')
            )

    # Convert all columns to string for Excel export and order by date
    compared_df= compared_df.select([
    F.coalesce(F.col(c).cast('string'), F.lit('0')).alias(c) for c in compared_df.columns]).orderBy('src_event_date')

    # Filter to only show rows with issues (non-dash comments)
    final_df = compared_df.filter(F.col('Comment') != '-')

    return final_df, compared_df

final_amperwave_variance_df, amperwave_compared_df = compare_data(src_amperwave_df, tar_amperwave_df)
display(final_amperwave_variance_df)

final_megaphone_variance_df, megaphone_compared_df = compare_data(src_megaphone_df, tar_megaphone_df)
display(final_megaphone_variance_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Mail Service

# COMMAND ----------

# Generate Excel report and send email notification
import os
from datetime import date
import pandas as pd

# Set up file paths and directory structure for Excel export
today = date.today()
formatted_date = today.strftime("%m-%d-%Y")

current_directory = os.getcwd()
relative_path = 'Tableau_output/'

PREVIEW_FOLDER_LOCATION = os.path.join(current_directory, relative_path)

# Ensure the directory exists
if not os.path.exists(PREVIEW_FOLDER_LOCATION):
    os.makedirs(PREVIEW_FOLDER_LOCATION)

final_name=f'megaphone_amperwave_validation - {formatted_date}.xlsx'

file_path = PREVIEW_FOLDER_LOCATION + final_name
# Remove existing file if it exists
try:
    if os.path.isfile(file_path):
        os.remove(file_path)
except Exception as e:
    print(f"Error deleting file: {e}")

# Create Excel writer for multi-sheet workbook
writer = pd.ExcelWriter(file_path, engine='xlsxwriter')

# Write Amperwave comparison data to Excel sheet with auto-sized columns
res_df = amperwave_compared_df.toPandas()
res_df.to_excel(writer, index=False, sheet_name='Amperwave')
workbook = writer.book
worksheet = writer.sheets['Amperwave']
for i, col in enumerate(res_df.columns):
    width = max(res_df[col].apply(lambda x: len(str(x))).max(), len(col))
    worksheet.set_column(i, i, width)

# Write Megaphone comparison data to Excel sheet with auto-sized columns
res_df = megaphone_compared_df.toPandas()
res_df.to_excel(writer, index=False, sheet_name='Megaphone')
workbook = writer.book
worksheet = writer.sheets['Megaphone']
for i, col in enumerate(res_df.columns):
    width = max(res_df[col].apply(lambda x: len(str(x))).max(), len(col))
    worksheet.set_column(i, i, width)

writer.close()

print(file_path)

# COMMAND ----------

# Convert DataFrame to HTML table format for email body
def table_format(df):
    wh_data = "<tr>"
    ky = ''
    for i in df.columns:
        ky += f'<th style="color:white; background-color:#104985; font-weight:400;">{i}</th>'
    t1 = wh_data + ky + '</tr>'

    for j in range(len(df)):
        td = ''
        for k in df.columns:
            td += f'<td>{df.iloc[j][k]}</td>'
        t1 += wh_data + td + '</tr>'

    return t1
amp_diff=table_format(final_amperwave_variance_df.toPandas())
mega_diff=table_format(final_megaphone_variance_df.toPandas())


# COMMAND ----------

if src_amperwave_df.count()==0 and src_megaphone_df.count()==0:
    src_df_null = 'There is no data flowing from Amperwave and Megaphone for last one day.'
elif src_amperwave_df.count()==0 :
    src_df_null = 'There is no data flowing from Amperwave for last one day.'
elif src_megaphone_df.count()==0 :
    src_df_null = 'There is no data flowing from Megaphone for last one day.'
else:
    src_df_null = ''

# COMMAND ----------

# Send validation report email with Excel attachment
# Email content varies based on which platforms have variances detected
def send_opendeals_report(final_file_path, environment):
    # Case 1: Both Amperwave and Megaphone have variances
    if final_amperwave_variance_df.count()>0 and final_megaphone_variance_df.count()>0:
        html = f'''
            <html>
                <body>
                    <p><b><u>Megaphone_Amperwave_Validation:</u></b></p>
                    <p><b>Below table contains the mismatch of staq and FoxAi views for Amperwave and Megaphone</b></p>
                    <p><b><u>{src_df_null}</u></b></p>
                    <table border=1>{amp_diff}</table>
                    
                    <table border=1>{mega_diff}</table>
                    <p>Please note that this is an auto-generated validation report. If you have any questions, please reach out to SRE_Data_Platform@fox.com</p>
                    <p>Best Regards,<br>
                    Data Ops Support Team</p>
                </body>
            </html>
            '''
    elif final_amperwave_variance_df.count()>0:
        html = f'''
            <html>
                <body>
                    <p><b><u>Megaphone_Amperwave_Validation:</u></b></p>
                    <p><b>Below table contains the mismatch of staq and FoxAi views for Amperwave</b></p>
                    <p><b><u>{src_df_null}</u></b></p>
                    <table border=1>{amp_diff}</table>
                    
                    <p>Please note that this is an auto-generated validation report. If you have any questions, please reach out to SRE_Data_Platform@fox.com</p>
                    <p>Best Regards,<br>
                    Data Ops Support Team</p>
                </body>
            </html>
            '''
    elif final_megaphone_variance_df.count()>0:
        html = f'''
            <html>
                <body>
                    <p><b><u>Megaphone_Amperwave_Validation:</u></b></p>
                    <p><b>Below table contains the mismatch of staq and FoxAi views for Megaphone</b></p>
                    <p><b><u>{src_df_null}</u></b></p>
                    <table border=1>{mega_diff}</table>
                    
                    <p>Please note that this is an auto-generated validation report. If you have any questions, please reach out to SRE_Data_Platform@fox.com</p>
                    <p>Best Regards,<br>
                    Data Ops Support Team</p>
                </body>
            </html>
            '''
    else:
        html = f'''
            <html>
                <body>
                    <p><b><u>Megaphone_Amperwave_Validation:</u></b></p>
                    <p><b>No Variance</b></p>

                    <p>Please note that this is an auto-generated validation report. If you have any questions, please reach out to SRE_Data_Platform@fox.com</p>
                    <p>Best Regards,<br>
                    Data Ops Support Team</p>
                </body>
            </html>
            '''
    # Helper function to attach Excel file to email
    def attach_file_to_email(email_message, filename):
        with open(filename, "rb") as f:
            file_attachment = MIMEApplication(f.read())
        file_attachment.add_header(
            "Content-Disposition",
            f'attachment; filename= "{final_name}"',
        )

        email_message.attach(file_attachment)

    # Create email message with HTML body and Excel attachment
    email_message = MIMEMultipart()
    email_message['From'] = from_email
    # email_message['To'] = email_to
    if True:
        email_message['To'] = ', '.join(to_email)
        email_message['Cc'] = ', '.join(cc_email)
        send_to=to_email+cc_email
    else:
        email_message['To'] = ', '.join(fail_email)
        email_message['Cc'] = ', '.join(cc_email)
        send_to=to_email+cc_email
    email_message['Subject'] = (f"{environment} - Megaphone_Amperwave_Validation: {formatted_date}")

    # Attach the html doc defined earlier, as a MIMEText html content type to the MIME message
    email_message.attach(MIMEText(html, "html"))

    attach_file_to_email(email_message, final_file_path)

    # Convert email message to string format
    email_string = email_message.as_string()
    
    # Send email via AWS SES (Simple Email Service)
    import boto3
    session = boto3.Session(profile_name = aws_profile)
    ses = session.client('ses', region_name='us-west-2')
    
    ses.send_raw_email(
      Source=from_email,
      Destinations=send_to,
      RawMessage={'Data': email_string})
    print("Sent all the Emails!")

# Set environment for email subject line
environment = env

final_file_path = file_path

# Only send emails on weekdays (Monday-Friday), skip weekends
if (datetime.now().isoweekday()) not in (6,7):
    send_opendeals_report(final_file_path, environment)
else:
    print('Saturday and Sunday, No mails required.')
