# Databricks notebook source
spark.conf.set("spark.databricks.remoteFiltering.blockSelfJoins", "false")

# COMMAND ----------

# MAGIC %md
# MAGIC # Parse for Campaign_Summary Validation
# MAGIC

# COMMAND ----------

# Databricks notebook Target
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from datetime import datetime, date
import os
import pandas as pd

# COMMAND ----------

# Configuration
catalog_name = 'fox_bi_qa'
env = 'dev'  # or 'qa' or 'prod'

# COMMAND ----------

# MAGIC %md
# MAGIC ## Validation: wrap_detailed_unified_report_sections_by_deal vs ft_unified_campaign_delivery_by_deal
# MAGIC
# MAGIC This validation compares:
# MAGIC - Target: Sum of field10 from wrap_detailed_unified_report_sections_by_deal (for CAMPAIGN_SUMMARY data_type)
# MAGIC - Target: Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
# MAGIC
# MAGIC For each aos_deal_id

# COMMAND ----------

# MAGIC %md
# MAGIC ### Target Data: wrap_detailed_unified_report_sections_by_deal

# COMMAND ----------

# Target: Aggregate field10 from wrap_detailed_unified_report_sections_by_deal
# Filter for CAMPAIGN_SUMMARY data_type and sum field10 (which contains Total_Delivered_Impressions as string)
tar_df = spark.sql(f"""
    SELECT 
        AOS_Deal_ID,
        field2 as `Target AOS_Deal_Name`,
        field3 as `Target Advertiser Name`,
        field4 as `Target Agency Name`,
        field5 as `Target AOS Deal Start Date`,
        field6 as `Target AOS Deal End Date`,     
        SUM(try_cast(field7 AS BIGINT)) as `Target Total Placements`,
        SUM(try_cast(field8 AS BIGINT)) as `Target Total Creatives`,
        SUM(try_cast(field9 AS BIGINT)) as `Target Total Shows`,        
        SUM(try_cast(field10 AS BIGINT)) as `Target Total Delivered Impressions`,
        SUM(try_cast(field11 AS DECIMAL(19,2))) as `Target Total Delivered Revenue`,
        SUM(try_cast(field12 AS BIGINT)) as `Target Total Delivered Clicks`,
        SUM(try_cast(field13 AS BIGINT)) as `Target Total Guaranteed Impressions`,
        SUM(try_cast(field14 AS DECIMAL(19,2))) as `Target Budget`,
        SUM(try_cast(field15 AS DECIMAL(19,2))) as `Target CPM`,
        SUM(try_cast(field16 AS DECIMAL(19,2))) as `Target CTR`,
        SUM(try_cast(field17 AS BIGINT)) as `Target Total Countries`,
        SUM(try_cast(field18 AS BIGINT)) as `Target Total States`,
        SUM(try_cast(field19 AS BIGINT)) as `Target Total Geo Ads`,
        SUM(try_cast(field20 AS DECIMAL(19,2))) as `Target Revenue Pacing`,
        SUM(try_cast(field21 AS DECIMAL(19,2))) as `Target Impression Pacing`,
        SUM(try_cast(field23 AS BIGINT)) as `Target Total Third Party Impressions`,
        SUM(try_cast(field24 AS DECIMAL(19,2))) as `Target Total Third Party Revenue`
    FROM {catalog_name}.gold_ad_sales.wrap_detailed_unified_report_sections_by_deal
    WHERE data_type = 'CAMPAIGN_SUMMARY'
    GROUP BY AOS_Deal_ID, field2, field3, field4, field5, field6
""")

display(tar_df)



# COMMAND ----------

# MAGIC %md
# MAGIC ### Source Data: ft_unified_campaign_delivery_by_deal

# COMMAND ----------

# Source: Get Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
src_df = spark.sql(f"""
    SELECT 
        `AOS Deal ID` as AOS_Deal_ID,
        `AOS Deal Name` as `Source AOS_Deal_Name`,
        `Advertiser Name` as `Source Advertiser Name`,
        `Agency Name` as `Source Agency Name`,
        `AOS Deal Start Date` as `Source AOS Deal Start Date`,
        `AOS Deal End Date` as `Source AOS Deal End Date`,
        `Total Placements` as `Source Total Placements`,
        `Total Creatives` as `Source Total Creatives`,
        `Total Shows` as `Source Total Shows`,
        `Total Delivered Impressions` as `Source Total Delivered Impressions`,
        `Total Delivered Revenue` as `Source Total Delivered Revenue`,
        `Total Delivered Clicks` as `Source Total Delivered Clicks`,
        `Total Guaranteed Impressions` as `Source Total Guaranteed Impressions`,
        `Budget` as `Source Budget`,
        `CPM` as `Source CPM`,
        `CTR` as `Source CTR`,
        `Total Countries` as `Source Total Countries`,
        `Total States` as `Source Total States`,
        `Total Geo Ads` as `Source Total Geo Ads`,
        `Revenue Pacing` as `Source Revenue Pacing`,
        `Impression Pacing` as `Source Impression Pacing`,
        `Total Third Party Impressions` as `Source Total Third Party Impressions`,
        `Total Third Party Revenue` as `Source Total Third Party Revenue`
    FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal
    WHERE `AOS Deal ID` IS NOT NULL
        AND `AOS Deal ID` != -1
""")

display(src_df)


# COMMAND ----------

# MAGIC %md
# MAGIC ### Validation Comparison

# COMMAND ----------

from pyspark.sql.functions import col, when, expr, nvl, abs, lit

# Join source and target on AOS_Deal_ID
joined_df = src_df.join(
    tar_df,
    on="AOS_Deal_ID",
    how="full_outer"
)

display(joined_df)


# Add comparison columns
validation_df = joined_df.withColumn(
    "Source_Total_Delivered_Impressions",
    nvl(col("`Source Total Delivered Impressions`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Impressions",
    nvl(col("`Target Total Delivered Impressions`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Revenue",
    nvl(col("`Source Total Delivered Revenue`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Clicks",
    nvl(col("`Source Total Delivered Clicks`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Clicks",
    nvl(col("`Target Total Delivered Clicks`"), lit(0))
).withColumn(
    "Source_Total_Guaranteed_Impressions",
    nvl(col("`Source Total Guaranteed Impressions`"), lit(0))
).withColumn(
    "Target_Total_Guaranteed_Impressions",
    nvl(col("`Target Total Guaranteed Impressions`"), lit(0))
).withColumn(
    "Source_Budget",
    nvl(col("`Source Budget`"), lit(0))
).withColumn(
    "Target_Budget",
    nvl(col("`Target Budget`"), lit(0))
).withColumn(
    "Source_CPM",
    nvl(col("`Source CPM`"), lit(0))
).withColumn(
    "Target_CPM",
    nvl(col("`Target CPM`"), lit(0))
).withColumn(
    "Source_CTR",
    nvl(col("`Source CTR`"), lit(0))
).withColumn(
    "Target_CTR",
    nvl(col("`Target CTR`"), lit(0))
).withColumn(
    "Source_Total_Countries",
    nvl(col("`Source Total Countries`"), lit(0))
).withColumn(
    "Target_Total_Countries",
    nvl(col("`Target Total Countries`"), lit(0))
).withColumn(
    "Source_Total_States",
    nvl(col("`Source Total States`"), lit(0))
).withColumn(
    "Target_Total_States",
    nvl(col("`Target Total States`"), lit(0))
).withColumn(
    "Source_Total_Geo_Ads",
    nvl(col("`Source Total Geo Ads`"), lit(0))
).withColumn(
    "Target_Total_Geo_Ads",
    nvl(col("`Target Total Geo Ads`"), lit(0))
).withColumn(
    "Source_Revenue_Pacing",
    nvl(col("`Source Revenue Pacing`"), lit(0))
).withColumn(
    "Target_Revenue_Pacing",
    nvl(col("`Target Revenue Pacing`"), lit(0))
).withColumn(
    "Source_Impression_Pacing",
    nvl(col("`Source Impression Pacing`"), lit(0))
).withColumn(
    "Target_Impression_Pacing",
    nvl(col("`Target Impression Pacing`"), lit(0))
).withColumn(
    "Source_Total_Third_Party_Impressions",
    nvl(col("`Source Total Third Party Impressions`"), lit(0))
).withColumn(
    "Target_Total_Third_Party_Impressions",
    nvl(col("`Target Total Third Party Impressions`"), lit(0))
).withColumn(
    "Source_Total_Third_Party_Revenue",
    nvl(col("`Source Total Third Party Revenue`"), lit(0))
).withColumn(
    "Target_Total_Third_Party_Revenue",
    nvl(col("`Target Total Third Party Revenue`"), lit(0))
).withColumn(
    "Variance_Impressions",
    col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")
).withColumn(
    "Variance_Clicks",
    col("Source_Total_Delivered_Clicks") - col("Target_Total_Delivered_Clicks")
).withColumn(
    "Variance_Guaranteed_Impressions",
    col("Source_Total_Guaranteed_Impressions") - col("Target_Total_Guaranteed_Impressions")
).withColumn(
    "Variance_Budget",
    col("Source_Budget") - col("Target_Budget")
).withColumn(
    "Variance_CPM",
    col("Source_CPM") - col("Target_CPM")
).withColumn(
    "Variance_CTR",
    col("Source_CTR") - col("Target_CTR")
).withColumn(
    "Variance_Total_Countries",
    col("Source_Total_Countries") - col("Target_Total_Countries")
).withColumn(
    "Variance_Total_States",
    col("Source_Total_States") - col("Target_Total_States")
).withColumn(
    "Variance_Total_Geo_Ads",
    col("Source_Total_Geo_Ads") - col("Target_Total_Geo_Ads")
).withColumn(
    "Variance_Revenue_Pacing",
    col("Source_Revenue_Pacing") - col("Target_Revenue_Pacing")
).withColumn(
    "Variance_Impression_Pacing",
    col("Source_Impression_Pacing") - col("Target_Impression_Pacing")
).withColumn(
    "Variance_Total_Third_Party_Impressions",
    col("Source_Total_Third_Party_Impressions") - col("Target_Total_Third_Party_Impressions")
).withColumn(
    "Variance_Total_Third_Party_Revenue",
    col("Source_Total_Third_Party_Revenue") - col("Target_Total_Third_Party_Revenue")
).withColumn(
    "Impressions_Match",
    when(
        abs(col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Clicks_Match",
    when(
        abs(col("Source_Total_Delivered_Clicks") - col("Target_Total_Delivered_Clicks")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Guaranteed_Impressions_Match",
    when(
        abs(col("Source_Total_Guaranteed_Impressions") - col("Target_Total_Guaranteed_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Budget_Match",
    when(
        abs(col("Source_Budget") - col("Target_Budget")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "CPM_Match",
    when(
        abs(col("Source_CPM") - col("Target_CPM")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "CTR_Match",
    when(
        abs(col("Source_CTR") - col("Target_CTR")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Total_Countries_Match",
    when(
        abs(col("Source_Total_Countries") - col("Target_Total_Countries")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Total_States_Match",
    when(
        abs(col("Source_Total_States") - col("Target_Total_States")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Total_Geo_Ads_Match",
    when(
        abs(col("Source_Total_Geo_Ads") - col("Target_Total_Geo_Ads")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Revenue_Pacing_Match",
    when(
        abs(col("Source_Revenue_Pacing") - col("Target_Revenue_Pacing")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Impression_Pacing_Match",
    when(
        abs(col("Source_Impression_Pacing") - col("Target_Impression_Pacing")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Total_Third_Party_Impressions_Match",
    when(
        abs(col("Source_Total_Third_Party_Impressions") - col("Target_Total_Third_Party_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Total_Third_Party_Revenue_Match",
    when(
        abs(col("Source_Total_Third_Party_Revenue") - col("Target_Total_Third_Party_Revenue")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Status",
    when(
        (col("Impressions_Match") == True) &
        (col("Clicks_Match") == True) &
        (col("Guaranteed_Impressions_Match") == True) &
        (col("Budget_Match") == True) &
        (col("CPM_Match") == True) &
        (col("CTR_Match") == True) &
        (col("Total_Countries_Match") == True) &
        (col("Total_States_Match") == True) &
        (col("Total_Geo_Ads_Match") == True) &
        (col("Revenue_Pacing_Match") == True) &
        (col("Impression_Pacing_Match") == True) &
        (col("Total_Third_Party_Impressions_Match") == True) &
        (col("Total_Third_Party_Revenue_Match") == True),
        True
    ).otherwise(False)
).select(
    col("AOS_Deal_ID"),
    col("Source AOS_Deal_Name"),
    col("Target AOS_Deal_Name"),
    col("Source_Total_Delivered_Impressions"),
    col("Target_Total_Delivered_Impressions"),
    col("Variance_Impressions"),
    col("Impressions_Match"),
    col("Source_Total_Delivered_Revenue"),
    col("Source_Total_Delivered_Clicks"),
    col("Target_Total_Delivered_Clicks"),
    col("Variance_Clicks"),
    col("Clicks_Match"),
    col("Source_Total_Guaranteed_Impressions"),
    col("Target_Total_Guaranteed_Impressions"),
    col("Variance_Guaranteed_Impressions"),
    col("Guaranteed_Impressions_Match"),
    col("Source_Budget"),
    col("Target_Budget"),
    col("Variance_Budget"),
    col("Budget_Match"),
    col("Source_CPM"),
    col("Target_CPM"),
    col("Variance_CPM"),
    col("CPM_Match"),
    col("Source_CTR"),
    col("Target_CTR"),
    col("Variance_CTR"),
    col("CTR_Match"),
    col("Source_Total_Countries"),
    col("Target_Total_Countries"),
    col("Variance_Total_Countries"),
    col("Total_Countries_Match"),
    col("Source_Total_States"),
    col("Target_Total_States"),
    col("Variance_Total_States"),
    col("Total_States_Match"),
    col("Source_Total_Geo_Ads"),
    col("Target_Total_Geo_Ads"),
    col("Variance_Total_Geo_Ads"),
    col("Total_Geo_Ads_Match"),
    col("Source_Revenue_Pacing"),
    col("Target_Revenue_Pacing"),
    col("Variance_Revenue_Pacing"),
    col("Revenue_Pacing_Match"),
    col("Source_Impression_Pacing"),
    col("Target_Impression_Pacing"),
    col("Variance_Impression_Pacing"),
    col("Impression_Pacing_Match"),
    col("Source_Total_Third_Party_Impressions"),
    col("Target_Total_Third_Party_Impressions"),
    col("Variance_Total_Third_Party_Impressions"),
    col("Total_Third_Party_Impressions_Match"),
    col("Source_Total_Third_Party_Revenue"),
    col("Target_Total_Third_Party_Revenue"),
    col("Variance_Total_Third_Party_Revenue"),
    col("Total_Third_Party_Revenue_Match"),
    col("Status")
)

display(validation_df)



# Create a dataframe showing which columns have mismatches for deals where Status is False
mismatch_details_df = validation_df.withColumn(
    "Mismatched_Columns_Array",
    array(
        when(col("Impressions_Match") == False, lit("Impressions")).otherwise(lit(None)),
        when(col("Clicks_Match") == False, lit("Clicks")).otherwise(lit(None)),
        when(col("Guaranteed_Impressions_Match") == False, lit("Guaranteed_Impressions")).otherwise(lit(None)),
        when(col("Budget_Match") == False, lit("Budget")).otherwise(lit(None)),
        when(col("CPM_Match") == False, lit("CPM")).otherwise(lit(None)),
        when(col("CTR_Match") == False, lit("CTR")).otherwise(lit(None)),
        when(col("Total_Countries_Match") == False, lit("Total_Countries")).otherwise(lit(None)),
        when(col("Total_States_Match") == False, lit("Total_States")).otherwise(lit(None)),
        when(col("Total_Geo_Ads_Match") == False, lit("Total_Geo_Ads")).otherwise(lit(None)),
        when(col("Revenue_Pacing_Match") == False, lit("Revenue_Pacing")).otherwise(lit(None)),
        when(col("Impression_Pacing_Match") == False, lit("Impression_Pacing")).otherwise(lit(None)),
        when(col("Total_Third_Party_Impressions_Match") == False, lit("Total_Third_Party_Impressions")).otherwise(lit(None)),
        when(col("Total_Third_Party_Revenue_Match") == False, lit("Total_Third_Party_Revenue")).otherwise(lit(None))
    )
).withColumn(
    "Mismatched_Columns_Array",
    expr("filter(Mismatched_Columns_Array, x -> x is not null)")
).withColumn(
    "Mismatched_Columns",
    concat_ws(", ", col("Mismatched_Columns_Array"))
).select(
    col("AOS_Deal_ID").alias("deal_id"),
    col("Source AOS_Deal_Name"),
    col("Target AOS_Deal_Name"),
    col("Status"),
    col("Mismatched_Columns")
).distinct()

print("=" * 80)
print(f"Deal Mismatch Details")
print(f"Total Deals with Mismatches: {mismatch_details_df.count()}")
print("=" * 80)

display(mismatch_details_df)





# COMMAND ----------

# MAGIC %md
# MAGIC ### Deal IDs Only in Target Table (Not in Source)

# COMMAND ----------

# Find deal_ids that are only in target table and not in source table
target_only_deals = spark.sql(f"""
    SELECT 
        t.`AOS Deal ID` as AOS_Deal_ID,
        t.`AOS Deal Name` as `Target AOS_Deal_Name`,
        t.`Advertiser Name` as `Target Advertiser Name`,
        t.`Agency Name` as `Target Agency Name`,
        t.`AOS Deal Start Date` as `Target AOS Deal Start Date`,
        t.`AOS Deal End Date` as `Target AOS Deal End Date`,
        t.`Total Delivered Impressions` as `Target Total Delivered Impressions`,
        t.`Total Delivered Clicks` as `Target Total Delivered Clicks`,
        t.`Total Guaranteed Impressions` as `Target Total Guaranteed Impressions`,
        t.`Budget` as `Target Budget`,
        t.`CPM` as `Target CPM`,
        t.`CTR` as `Target CTR`
    FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal t
    WHERE t.`AOS Deal ID` IS NOT NULL
        AND t.`AOS Deal ID` != -1
        AND NOT EXISTS (
            SELECT 1
            FROM {catalog_name}.gold_ad_sales.wrap_detailed_unified_report_sections_by_deal s
            WHERE s.AOS_Deal_ID = t.`AOS Deal ID`
                AND s.data_type = 'CAMPAIGN_SUMMARY'
        )
    ORDER BY t.`AOS Deal ID`
""")

print("=" * 80)
print(f"Deal IDs only in v_ft_unified_campaign_delivery_by_deal Table (v_ft_unified_campaign_delivery_by_deal)")
print(f"Count: {target_only_deals.count()}")
print("=" * 80)

display(target_only_deals)




# COMMAND ----------

# MAGIC %md
# MAGIC ### Update mismatch_details_df: Mark missing deals from target_only_deals

# COMMAND ----------

# Update mismatch_details_df to include deals from target_only_deals with Status = "missing deals"
# First, convert Status to string in mismatch_details_df to allow "missing deals" value
mismatch_details_df_1 = mismatch_details_df.withColumn(
    "Status",
    when(col("Status") == True, lit("True"))
    .when(col("Status") == False, lit("False"))
    .otherwise(col("Status").try_cast("string"))
)

# Create a dataframe for missing deals with the same structure as mismatch_details_df
missing_deals_df = target_only_deals.select(
    col("AOS_Deal_ID").alias("deal_id"),
    lit("null").try_cast("string").alias("Source AOS_Deal_Name"),
    col("Target AOS_Deal_Name"),
    lit("missing deals").alias("Status"),
    lit("Deal not found in source table").alias("Mismatched_Columns")
)

display(missing_deals_df)

display(mismatch_details_df_1)

# Option 1: Use a broadcast join with a flag, then check if deal_id exists in target_only_deals
from pyspark.sql.functions import broadcast

# Create a set of deal_ids from target_only_deals for efficient lookup
target_only_deal_ids = target_only_deals.select(col("AOS_Deal_ID").alias("deal_id")).distinct()

# Join and check if deal_id exists in target_only_deals
mismatch_details_df_1 = mismatch_details_df_1.join(
    broadcast(target_only_deal_ids).withColumn("is_target_only", lit(True)),
    on="deal_id",
    how="left"
).withColumn(
    "Status",
    when(col("is_target_only").isNotNull(), lit("not found in source").cast("string"))
    .otherwise(col("Status").cast("string"))
).select(
    col("deal_id"),
    col("Source AOS_Deal_Name"),
    col("Target AOS_Deal_Name"),
    col("Status").cast("string").alias("Status"),
    col("Mismatched_Columns")
)


display(mismatch_details_df_1)



# Create a dataframe with deal_id and CAMPAIGN_SUMMARY (True if Status is True, False otherwise)
deal_status_df_cs = mismatch_details_df_1.select(
    col("deal_id"),
    col("Status").alias("CAMPAIGN_SUMMARY")
).distinct()

print("=" * 80)
print(f"Deal Status Summary")
print(f"Total Deals: {deal_status_df_cs.count()}")
print(f"Deals with CAMPAIGN_SUMMARY = True: {deal_status_df_cs.filter(col('CAMPAIGN_SUMMARY') == 'True').count()}")
print(f"Deals with CAMPAIGN_SUMMARY = False: {deal_status_df_cs.filter(col('CAMPAIGN_SUMMARY') == 'False').count()}")
print("=" * 80)

display(deal_status_df_cs)






# COMMAND ----------

# MAGIC %md
# MAGIC # Parse for Device_Breakdown Validation
# MAGIC

# COMMAND ----------

# Databricks notebook Target
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from datetime import datetime, date
import os
import pandas as pd

# COMMAND ----------

# Configuration
catalog_name = 'fox_bi_qa'
env = 'dev'  # or 'qa' or 'prod'

# COMMAND ----------

# MAGIC %md
# MAGIC ## Validation: wrap_detailed_unified_report_sections_by_deal vs ft_unified_campaign_delivery_by_deal
# MAGIC
# MAGIC This validation compares:
# MAGIC - Target: Sum of field10 from wrap_detailed_unified_report_sections_by_deal (for DEVICE_BREAKDOWN data_type)
# MAGIC - Target: Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
# MAGIC
# MAGIC For each aos_deal_id

# COMMAND ----------

# MAGIC %md
# MAGIC ### Target Data: wrap_detailed_unified_report_sections_by_deal

# COMMAND ----------

# Target: Aggregate field10 from wrap_detailed_unified_report_sections_by_deal
# Filter for DEVICE_BREAKDOWN data_type and sum field10 (which contains Total_Delivered_Impressions as string)
tar_df = spark.sql(f"""
    SELECT 
        AOS_Deal_ID,          
        SUM(cast(field2 AS BIGINT)) as `Target Total Delivered Impressions`,
        SUM(cast(field3 AS DECIMAL(19,2))) as `Target Total Delivered Revenue`,
        SUM(cast(field4 AS BIGINT)) as `Target Total Delivered Clicks`,
        SUM(cast(field5 AS BIGINT)) as `Target Placement Id Count`,
        SUM(cast(field6 AS BIGINT)) as `Target Creative Id Count`,
        CAST(
            CASE
                WHEN SUM(field2) > 0 THEN ROUND((SUM(field3) / SUM(field2) * 1000), 2)
                ELSE 0
            END AS DECIMAL(19,2)) as `Target CPM`,
        SUM(cast(field8 AS BIGINT)) as `Target Total Third Party Impressions`,
        SUM(cast(field9 AS DECIMAL(19,2))) as `Target Total Third Party Revenue`
    FROM {catalog_name}.gold_ad_sales.wrap_detailed_unified_report_sections_by_deal
    WHERE data_type = 'DEVICE_BREAKDOWN'
    GROUP BY AOS_Deal_ID
""")

display(tar_df)



# COMMAND ----------

# MAGIC %md
# MAGIC ### Source Data: ft_unified_campaign_delivery_by_deal

# COMMAND ----------

# Source: Get Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
src_df = spark.sql(f"""
    SELECT 
        `AOS Deal ID` as AOS_Deal_ID,        
        `Total Delivered Impressions` as `Source Total Delivered Impressions`,
        `SPEND` as `Source Total Delivered Revenue`,
        `Total Delivered Clicks` as `Source Total Delivered Clicks`,
        `Total Placements` as `Source Total Placements`,
        `Total Creatives` as `Source Total Creatives`,
        `CPM` as `Source CPM`,
        `Total Third Party Impressions` as `Source Total Third Party Impressions`,
        `Total Third Party Revenue` as `Source Total Third Party Revenue`
    FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal
    WHERE `AOS Deal ID` IS NOT NULL
        AND `AOS Deal ID` != -1
""")

display(src_df)


# COMMAND ----------

# MAGIC %md
# MAGIC ### Validation Comparison

# COMMAND ----------

from pyspark.sql.functions import col, when, expr, nvl, abs, lit, array, concat_ws

# Join source and target on AOS_Deal_ID
joined_df = src_df.join(
    tar_df,
    on="AOS_Deal_ID",
    how="full_outer"
)

display(joined_df)



# Add comparison columns
validation_df = joined_df.withColumn(
    "Source_Total_Delivered_Impressions",
    nvl(col("`Source Total Delivered Impressions`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Impressions",
    nvl(col("`Target Total Delivered Impressions`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Clicks",
    nvl(col("`Source Total Delivered Clicks`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Clicks",
    nvl(col("`Target Total Delivered Clicks`"), lit(0))
).withColumn(
    "Source_CPM",
    nvl(col("`Source CPM`"), lit(0))
).withColumn(
    "Target_CPM",
    nvl(col("`Target CPM`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Revenue",
    nvl(col("`Source Total Delivered Revenue`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Revenue",
    nvl(col("`Target Total Delivered Revenue`"), lit(0))
).withColumn(
    "Source_Total_Third_Party_Impressions",
    nvl(col("`Source Total Third Party Impressions`"), lit(0))
).withColumn(
    "Target_Total_Third_Party_Impressions",
    nvl(col("`Target Total Third Party Impressions`"), lit(0))
).withColumn(
    "Source_Total_Third_Party_Revenue",
    nvl(col("`Source Total Third Party Revenue`"), lit(0))
).withColumn(
    "Target_Total_Third_Party_Revenue",
    nvl(col("`Target Total Third Party Revenue`"), lit(0))
).withColumn(
    "Source_Total_Placements",
    nvl(col("`Source Total Placements`"), lit(0))
).withColumn(
    "Target_Total_Placements",
    nvl(col("`Target Placement Id Count`"), lit(0))
).withColumn(
    "Source_Total_Creatives",
    nvl(col("`Source Total Creatives`"), lit(0))
).withColumn(
    "Target_Total_Creatives",
    nvl(col("`Target Creative Id Count`"), lit(0))
).withColumn(
    "Variance_Impressions",
    col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")
).withColumn(
    "Variance_Clicks",
    col("Source_Total_Delivered_Clicks") - col("Target_Total_Delivered_Clicks")
).withColumn(
    "Variance_CPM",
    col("Source_CPM") - col("Target_CPM")
).withColumn(
    "Variance_Revenue",
    col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")
).withColumn(
    "Variance_Total_Third_Party_Impressions",
    col("Source_Total_Third_Party_Impressions") - col("Target_Total_Third_Party_Impressions")
).withColumn(
    "Variance_Total_Third_Party_Revenue",
    col("Source_Total_Third_Party_Revenue") - col("Target_Total_Third_Party_Revenue")
).withColumn(
    "Variance_Total_Placements",
    col("Source_Total_Placements") - col("Target_Total_Placements")
).withColumn(
    "Variance_Total_Creatives",
    col("Source_Total_Creatives") - col("Target_Total_Creatives")
).withColumn(
    "Impressions_Match",
    when(
        abs(col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Clicks_Match",
    when(
        abs(col("Source_Total_Delivered_Clicks") - col("Target_Total_Delivered_Clicks")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "CPM_Match",
    when(
        abs(col("Source_CPM") - col("Target_CPM")) <= 0.01,
        True
    ).otherwise(False)
).withColumn(
    "Revenue_Match",
    when(
        abs(col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")) <= 0.01,
        True
    ).otherwise(False)
).withColumn(
    "Total_Third_Party_Impressions_Match",
    when(
        abs(col("Source_Total_Third_Party_Impressions") - col("Target_Total_Third_Party_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Total_Third_Party_Revenue_Match",
    when(
        abs(col("Source_Total_Third_Party_Revenue") - col("Target_Total_Third_Party_Revenue")) <= 0.01,
        True
    ).otherwise(False)
).withColumn(
    "Total_Placements_Match",
    when(
        abs(col("Source_Total_Placements") - col("Target_Total_Placements")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Total_Creatives_Match",
    when(
        abs(col("Source_Total_Creatives") - col("Target_Total_Creatives")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Status",
    when(
        (col("Impressions_Match") == True) &
        (col("Clicks_Match") == True) &
        (col("CPM_Match") == True) &
        (col("Revenue_Match") == True) &
        (col("Total_Third_Party_Impressions_Match") == True) &
        (col("Total_Third_Party_Revenue_Match") == True) &
        (col("Total_Placements_Match") == True) &
        (col("Total_Creatives_Match") == True),
        True
    ).otherwise(False)
).select(
    col("AOS_Deal_ID"),
    col("Source_Total_Delivered_Impressions"),
    col("Target_Total_Delivered_Impressions"),
    col("Variance_Impressions"),
    col("Impressions_Match"),
    col("Source_Total_Delivered_Revenue"),
    col("Target_Total_Delivered_Revenue"),
    col("Variance_Revenue"),
    col("Revenue_Match"),
    col("Source_Total_Delivered_Clicks"),
    col("Target_Total_Delivered_Clicks"),
    col("Variance_Clicks"),
    col("Clicks_Match"),
    col("Source_CPM"),
    col("Target_CPM"),
    col("Variance_CPM"),
    col("CPM_Match"),
    col("Source_Total_Third_Party_Impressions"),
    col("Target_Total_Third_Party_Impressions"),
    col("Variance_Total_Third_Party_Impressions"),
    col("Total_Third_Party_Impressions_Match"),
    col("Source_Total_Third_Party_Revenue"),
    col("Target_Total_Third_Party_Revenue"),
    col("Variance_Total_Third_Party_Revenue"),
    col("Total_Third_Party_Revenue_Match"),
    col("Source_Total_Placements"),
    col("Target_Total_Placements"),
    col("Variance_Total_Placements"),
    col("Total_Placements_Match"),
    col("Source_Total_Creatives"),
    col("Target_Total_Creatives"),
    col("Variance_Total_Creatives"),
    col("Total_Creatives_Match"),
    col("Status")
)

display(validation_df)



# Create a dataframe showing which columns have mismatches for deals where Status is False
mismatch_details_df = validation_df.withColumn(
    "Mismatched_Columns_Array",
    array(
        when(col("Impressions_Match") == False, lit("Impressions")).otherwise(lit(None)),
        when(col("Clicks_Match") == False, lit("Clicks")).otherwise(lit(None)),
        when(col("Revenue_Match") == False, lit("Revenue")).otherwise(lit(None)),
        when(col("CPM_Match") == False, lit("CPM")).otherwise(lit(None)),
        when(col("Total_Third_Party_Impressions_Match") == False, lit("Total_Third_Party_Impressions")).otherwise(lit(None)),
        when(col("Total_Third_Party_Revenue_Match") == False, lit("Total_Third_Party_Revenue")).otherwise(lit(None)),
        when(col("Total_Placements_Match") == False, lit("Total_Placements")).otherwise(lit(None)),
        when(col("Total_Creatives_Match") == False, lit("Total_Creatives")).otherwise(lit(None))
    )
).withColumn(
    "Mismatched_Columns_Array",
    expr("filter(Mismatched_Columns_Array, x -> x is not null)")
).withColumn(
    "Mismatched_Columns",
    concat_ws(", ", col("Mismatched_Columns_Array"))
).select(
    col("AOS_Deal_ID").alias("deal_id"),
    when(col("Status") == True, lit("True"))
    .when(col("Status") == False, lit("False"))
    .otherwise(lit("False")).alias("Status"),
    col("Mismatched_Columns")
).distinct()

print("=" * 80)
print(f"Deal Mismatch Details")
print(f"Total Deals with Mismatches: {mismatch_details_df.count()}")
print("=" * 80)

display(mismatch_details_df)





# COMMAND ----------

# MAGIC %md
# MAGIC ### Deal IDs Only in Target Table (Not in Source)

# COMMAND ----------

# Find deal_ids that are only in target table and not in source table
target_only_deals = spark.sql(f"""
    SELECT 
        t.`AOS Deal ID` as AOS_Deal_ID,
        t.`Total Delivered Impressions` as `Target Total Delivered Impressions`,
        t.`SPEND` as `Target Total Delivered Revenue`,
        t.`Total Delivered Clicks` as `Target Total Delivered Clicks`,
        t.`Total Placements` as `Target Total Placements`,
        t.`Total Creatives` as `Target Total Creatives`,
        t.`CPM` as `Target CPM`,
        t.`Total Third Party Impressions` as `Target Total Third Party Impressions`,
        t.`Total Third Party Revenue` as `Target Total Third Party Revenue`
    FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal t
    WHERE t.`AOS Deal ID` IS NOT NULL
        AND t.`AOS Deal ID` != -1
        AND NOT EXISTS (
            SELECT 1
            FROM {catalog_name}.gold_ad_sales.wrap_detailed_unified_report_sections_by_deal s
            WHERE s.AOS_Deal_ID = t.`AOS Deal ID`
                AND s.data_type = 'DEVICE_BREAKDOWN'
        )
    ORDER BY t.`AOS Deal ID`
""")

print("=" * 80)
print(f"Deal IDs only in v_ft_unified_campaign_delivery_by_deal Table (v_ft_unified_campaign_delivery_by_deal)")
print(f"Count: {target_only_deals.count()}")
print("=" * 80)

display(target_only_deals)




# COMMAND ----------

# MAGIC %md
# MAGIC ### Update mismatch_details_df: Mark missing deals from target_only_deals

# COMMAND ----------

# Update mismatch_details_df to include deals from target_only_deals with Status = "missing deals"
# First, convert Status to string in mismatch_details_df to allow "missing deals" value
mismatch_details_df_1 = mismatch_details_df.withColumn(
    "Status",
    when(col("Status") == True, lit("True"))
    .when(col("Status") == False, lit("False"))
    .otherwise(col("Status").cast("string"))
)

# Create a dataframe for missing deals with the same structure as mismatch_details_df
missing_deals_df = target_only_deals.select(
    col("AOS_Deal_ID").alias("deal_id"),
    lit("missing deals").alias("Status"),
    lit("Deal not found in source table").alias("Mismatched_Columns")
)

display(missing_deals_df)

display(mismatch_details_df_1)

# Option 1: Use a broadcast join with a flag, then check if deal_id exists in target_only_deals
from pyspark.sql.functions import broadcast

# Create a set of deal_ids from target_only_deals for efficient lookup
target_only_deal_ids = target_only_deals.select(col("AOS_Deal_ID").alias("deal_id")).distinct()

# Join and check if deal_id exists in target_only_deals
mismatch_details_df_1 = mismatch_details_df_1.join(
    broadcast(target_only_deal_ids).withColumn("is_target_only", lit(True)),
    on="deal_id",
    how="left"
).withColumn(
    "Status",
    when(col("is_target_only").isNotNull(), lit("not found in source").cast("string"))
    .otherwise(col("Status").cast("string"))
).select(
    col("deal_id"),
    col("Status").cast("string").alias("Status"),
    col("Mismatched_Columns")
)


display(mismatch_details_df_1)



# Create a dataframe with deal_id and DEVICE_BREAKDOWN (True if Status is True, False otherwise)
deal_status_df_db = mismatch_details_df_1.select(
    col("deal_id"),
    col("Status").alias("DEVICE_BREAKDOWN")
).distinct()

print("=" * 80)
print(f"Deal Status Summary")
print(f"Total Deals: {deal_status_df_db.count()}")
print(f"Deals with DEVICE_BREAKDOWN = True: {deal_status_df_db.filter(col('DEVICE_BREAKDOWN') == 'True').count()}")
print(f"Deals with DEVICE_BREAKDOWN = False: {deal_status_df_db.filter(col('DEVICE_BREAKDOWN') == 'False').count()}")
print(f"Deals with DEVICE_BREAKDOWN = 'not found in source': {deal_status_df_db.filter(col('DEVICE_BREAKDOWN') == 'not found in source').count()}")
print("=" * 80)

display(deal_status_df_db)


# COMMAND ----------

# MAGIC %md
# MAGIC # Parse for PLACEMENT_DETAIL Validation
# MAGIC

# COMMAND ----------

# Databricks notebook Target
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from datetime import datetime, date
import os
import pandas as pd

# COMMAND ----------

# Configuration
catalog_name = 'fox_bi_qa'
env = 'dev'  # or 'qa' or 'prod'

# COMMAND ----------

# MAGIC %md
# MAGIC ## Validation: wrap_detailed_unified_report_sections_by_deal vs ft_unified_campaign_delivery_by_deal
# MAGIC
# MAGIC This validation compares:
# MAGIC - Target: Sum of field10 from wrap_detailed_unified_report_sections_by_deal (for PLACEMENT_DETAIL data_type)
# MAGIC - Target: Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
# MAGIC
# MAGIC For each aos_deal_id

# COMMAND ----------

# MAGIC %md
# MAGIC ### Target Data: wrap_detailed_unified_report_sections_by_deal

# COMMAND ----------

# Target: Aggregate field10 from wrap_detailed_unified_report_sections_by_deal
# Filter for PLACEMENT_DETAIL data_type and sum field10 (which contains Total_Delivered_Impressions as string)
tar_df = spark.sql(f"""
    SELECT 
        AOS_Deal_ID,   
        SUM(try_cast(field1 AS BIGINT)) as `Target Total Placements`,      
        SUM(try_cast(field3 AS BIGINT)) as `Target Total Delivered Impressions`,
        SUM(try_cast(field4 AS DECIMAL(19,2))) as `Target Total Delivered Revenue`,
        SUM(try_cast(field5 AS BIGINT)) as `Target Total Guaranteed Impressions`,
        SUM(try_cast(field6 AS DECIMAL(19,2))) as `Target Total Guaranteed Revenue`,
        SUM(try_cast(field7 AS BIGINT)) as `Target Total Third Party Impressions`,
        SUM(try_cast(field8 AS DECIMAL(19,2))) as `Target Total Third Party Revenue`
    FROM {catalog_name}.gold_ad_sales.wrap_detailed_unified_report_sections_by_deal
    WHERE data_type = 'PLACEMENT_DETAIL'
    GROUP BY AOS_Deal_ID
""")

display(tar_df)



# COMMAND ----------

# MAGIC %md
# MAGIC ### Source Data: ft_unified_campaign_delivery_by_deal

# COMMAND ----------

# Source: Get Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
src_df = spark.sql(f"""
    SELECT 
        `AOS Deal ID` as AOS_Deal_ID,
        `Total Placements` as `Source Total Placements`,
        `Total Delivered Impressions` as `Source Total Delivered Impressions`,
        `Total Delivered Revenue` as `Source Total Delivered Revenue`,
        `Total Guaranteed Impressions` as `Source Total Guaranteed Impressions`,
        `Budget` as `Source Total Guaranteed Revenue`,
        `Total Third Party Impressions` as `Source Total Third Party Impressions`,
        `Total Third Party Revenue` as `Source Total Third Party Revenue`
    FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal
    WHERE `AOS Deal ID` IS NOT NULL
        AND `AOS Deal ID` != -1
""")

display(src_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Validation Comparison

# COMMAND ----------

from pyspark.sql.functions import col, when, expr, nvl, abs, lit, array, concat_ws

# Join source and target on AOS_Deal_ID
joined_df = src_df.join(
    tar_df,
    on="AOS_Deal_ID",
    how="full_outer"
)

display(joined_df)


# Add comparison columns - only for columns that exist in both dataframes
validation_df = joined_df.withColumn(
    "Source_Total_Placements",
    nvl(col("`Source Total Placements`"), lit(0))
).withColumn(
    "Target_Total_Placements",
    nvl(col("`Target Total Placements`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Impressions",
    nvl(col("`Source Total Delivered Impressions`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Impressions",
    nvl(col("`Target Total Delivered Impressions`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Revenue",
    nvl(col("`Source Total Delivered Revenue`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Revenue",
    nvl(col("`Target Total Delivered Revenue`"), lit(0))
).withColumn(
    "Source_Total_Guaranteed_Impressions",
    nvl(col("`Source Total Guaranteed Impressions`"), lit(0))
).withColumn(
    "Target_Total_Guaranteed_Impressions",
    nvl(col("`Target Total Guaranteed Impressions`"), lit(0))
).withColumn(
    "Source_Total_Guaranteed_Revenue",
    nvl(col("`Source Total Guaranteed Revenue`"), lit(0))
).withColumn(
    "Target_Total_Guaranteed_Revenue",
    nvl(col("`Target Total Guaranteed Revenue`"), lit(0))
).withColumn(
    "Source_Total_Third_Party_Impressions",
    nvl(col("`Source Total Third Party Impressions`"), lit(0))
).withColumn(
    "Target_Total_Third_Party_Impressions",
    nvl(col("`Target Total Third Party Impressions`"), lit(0))
).withColumn(
    "Source_Total_Third_Party_Revenue",
    nvl(col("`Source Total Third Party Revenue`"), lit(0))
).withColumn(
    "Target_Total_Third_Party_Revenue",
    nvl(col("`Target Total Third Party Revenue`"), lit(0))
).withColumn(
    "Variance_Total_Placements",
    col("Source_Total_Placements") - col("Target_Total_Placements")
).withColumn(
    "Variance_Impressions",
    col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")
).withColumn(
    "Variance_Delivered_Revenue",
    col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")
).withColumn(
    "Variance_Guaranteed_Impressions",
    col("Source_Total_Guaranteed_Impressions") - col("Target_Total_Guaranteed_Impressions")
).withColumn(
    "Variance_Guaranteed_Revenue",
    col("Source_Total_Guaranteed_Revenue") - col("Target_Total_Guaranteed_Revenue")
).withColumn(
    "Variance_Total_Third_Party_Impressions",
    col("Source_Total_Third_Party_Impressions") - col("Target_Total_Third_Party_Impressions")
).withColumn(
    "Variance_Total_Third_Party_Revenue",
    col("Source_Total_Third_Party_Revenue") - col("Target_Total_Third_Party_Revenue")
).withColumn(
    "Total_Placements_Match",
    when(
        abs(col("Source_Total_Placements") - col("Target_Total_Placements")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Impressions_Match",
    when(
        abs(col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Delivered_Revenue_Match",
    when(
        abs(col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")) <= 0.01,
        True
    ).otherwise(False)
).withColumn(
    "Guaranteed_Impressions_Match",
    when(
        abs(col("Source_Total_Guaranteed_Impressions") - col("Target_Total_Guaranteed_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Guaranteed_Revenue_Match",
    when(
        abs(col("Source_Total_Guaranteed_Revenue") - col("Target_Total_Guaranteed_Revenue")) <= 0.01,
        True
    ).otherwise(False)
).withColumn(
    "Total_Third_Party_Impressions_Match",
    when(
        abs(col("Source_Total_Third_Party_Impressions") - col("Target_Total_Third_Party_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Total_Third_Party_Revenue_Match",
    when(
        abs(col("Source_Total_Third_Party_Revenue") - col("Target_Total_Third_Party_Revenue")) <= 0.01,
        True
    ).otherwise(False)
).withColumn(
    "Status",
    when(
        (col("Total_Placements_Match") == True) &
        (col("Impressions_Match") == True) &
        (col("Delivered_Revenue_Match") == True) &
        (col("Guaranteed_Impressions_Match") == True) &
        (col("Guaranteed_Revenue_Match") == True) &
        (col("Total_Third_Party_Impressions_Match") == True) &
        (col("Total_Third_Party_Revenue_Match") == True),
        True
    ).otherwise(False)
).select(
    col("AOS_Deal_ID"),
    col("Source_Total_Placements"),
    col("Target_Total_Placements"),
    col("Variance_Total_Placements"),
    col("Total_Placements_Match"),
    col("Source_Total_Delivered_Impressions"),
    col("Target_Total_Delivered_Impressions"),
    col("Variance_Impressions"),
    col("Impressions_Match"),
    col("Source_Total_Delivered_Revenue"),
    col("Target_Total_Delivered_Revenue"),
    col("Variance_Delivered_Revenue"),
    col("Delivered_Revenue_Match"),
    col("Source_Total_Guaranteed_Impressions"),
    col("Target_Total_Guaranteed_Impressions"),
    col("Variance_Guaranteed_Impressions"),
    col("Guaranteed_Impressions_Match"),
    col("Source_Total_Guaranteed_Revenue"),
    col("Target_Total_Guaranteed_Revenue"),
    col("Variance_Guaranteed_Revenue"),
    col("Guaranteed_Revenue_Match"),
    col("Source_Total_Third_Party_Impressions"),
    col("Target_Total_Third_Party_Impressions"),
    col("Variance_Total_Third_Party_Impressions"),
    col("Total_Third_Party_Impressions_Match"),
    col("Source_Total_Third_Party_Revenue"),
    col("Target_Total_Third_Party_Revenue"),
    col("Variance_Total_Third_Party_Revenue"),
    col("Total_Third_Party_Revenue_Match"),
    col("Status")
)

display(validation_df)



# Create a dataframe showing which columns have mismatches for deals where Status is False
mismatch_details_df = validation_df.withColumn(
    "Mismatched_Columns_Array",
    array(
        when(col("Total_Placements_Match") == False, lit("Total_Placements")).otherwise(lit(None)),
        when(col("Impressions_Match") == False, lit("Impressions")).otherwise(lit(None)),
        when(col("Delivered_Revenue_Match") == False, lit("Delivered_Revenue")).otherwise(lit(None)),
        when(col("Guaranteed_Impressions_Match") == False, lit("Guaranteed_Impressions")).otherwise(lit(None)),
        when(col("Guaranteed_Revenue_Match") == False, lit("Guaranteed_Revenue")).otherwise(lit(None)),
        when(col("Total_Third_Party_Impressions_Match") == False, lit("Total_Third_Party_Impressions")).otherwise(lit(None)),
        when(col("Total_Third_Party_Revenue_Match") == False, lit("Total_Third_Party_Revenue")).otherwise(lit(None))
    )
).withColumn(
    "Mismatched_Columns_Array",
    expr("filter(Mismatched_Columns_Array, x -> x is not null)")
).withColumn(
    "Mismatched_Columns",
    concat_ws(", ", col("Mismatched_Columns_Array"))
).select(
    col("AOS_Deal_ID").alias("deal_id"),
    when(col("Status") == True, lit("True"))
    .when(col("Status") == False, lit("False"))
    .otherwise(lit("False")).alias("Status"),
    col("Mismatched_Columns")
).distinct()

print("=" * 80)
print(f"Deal Mismatch Details")
print(f"Total Deals with Mismatches: {mismatch_details_df.count()}")
print("=" * 80)

display(mismatch_details_df)





# COMMAND ----------

# MAGIC %md
# MAGIC ### Deal IDs Only in Target Table (Not in Source)

# COMMAND ----------

# Find deal_ids that are only in target table and not in source table
target_only_deals = spark.sql(f"""
    SELECT 
        t.`AOS Deal ID` as AOS_Deal_ID,
        t.`Total Placements` as `Target Total Placements`,
        t.`Total Delivered Impressions` as `Target Total Delivered Impressions`,
        t.`Total Delivered Revenue` as `Target Total Delivered Revenue`,
        t.`Total Guaranteed Impressions` as `Target Total Guaranteed Impressions`,
        t.`Budget` as `Target Total Guaranteed Revenue`,
        t.`Total Third Party Impressions` as `Target Total Third Party Impressions`,
        t.`Total Third Party Revenue` as `Target Total Third Party Revenue`
    FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal t
    WHERE t.`AOS Deal ID` IS NOT NULL
        AND t.`AOS Deal ID` != -1
        AND NOT EXISTS (
            SELECT 1
            FROM {catalog_name}.gold_ad_sales.wrap_detailed_unified_report_sections_by_deal s
            WHERE s.AOS_Deal_ID = t.`AOS Deal ID`
                AND s.data_type = 'PLACEMENT_DETAIL'
        )
    ORDER BY t.`AOS Deal ID`
""")

print("=" * 80)
print(f"Deal IDs only in v_ft_unified_campaign_delivery_by_deal Table (v_ft_unified_campaign_delivery_by_deal)")
print(f"Count: {target_only_deals.count()}")
print("=" * 80)

display(target_only_deals)




# COMMAND ----------

# MAGIC %md
# MAGIC ### Update mismatch_details_df: Mark missing deals from target_only_deals

# COMMAND ----------

# Update mismatch_details_df to include deals from target_only_deals with Status = "missing deals"
# First, convert Status to string in mismatch_details_df to allow "missing deals" value
mismatch_details_df_1 = mismatch_details_df.withColumn(
    "Status",
    when(col("Status") == True, lit("True"))
    .when(col("Status") == False, lit("False"))
    .otherwise(col("Status").cast("string"))
)

# Create a dataframe for missing deals with the same structure as mismatch_details_df
missing_deals_df = target_only_deals.select(
    col("AOS_Deal_ID").alias("deal_id"),
    lit("missing deals").alias("Status"),
    lit("Deal not found in source table").alias("Mismatched_Columns")
)

display(missing_deals_df)

display(mismatch_details_df_1)

# Option 1: Use a broadcast join with a flag, then check if deal_id exists in target_only_deals
from pyspark.sql.functions import broadcast

# Create a set of deal_ids from target_only_deals for efficient lookup
target_only_deal_ids = target_only_deals.select(col("AOS_Deal_ID").alias("deal_id")).distinct()

# Join and check if deal_id exists in target_only_deals
mismatch_details_df_1 = mismatch_details_df_1.join(
    broadcast(target_only_deal_ids).withColumn("is_target_only", lit(True)),
    on="deal_id",
    how="left"
).withColumn(
    "Status",
    when(col("is_target_only").isNotNull(), lit("not found in source").cast("string"))
    .otherwise(col("Status").cast("string"))
).select(
    col("deal_id"),
    col("Status").cast("string").alias("Status"),
    col("Mismatched_Columns")
)


display(mismatch_details_df_1)



# Create a dataframe with deal_id and PLACEMENT_DETAIL (True if Status is True, False otherwise)
deal_status_df_pd = mismatch_details_df_1.select(
    col("deal_id"),
    col("Status").alias("PLACEMENT_DETAIL")
).distinct()

print("=" * 80)
print(f"Deal Status Summary")
print(f"Total Deals: {deal_status_df_pd.count()}")
print(f"Deals with PLACEMENT_DETAIL = True: {deal_status_df_pd.filter(col('PLACEMENT_DETAIL') == 'True').count()}")
print(f"Deals with PLACEMENT_DETAIL = False: {deal_status_df_pd.filter(col('PLACEMENT_DETAIL') == 'False').count()}")
print(f"Deals with PLACEMENT_DETAIL = 'not found in source': {deal_status_df_pd.filter(col('PLACEMENT_DETAIL') == 'not found in source').count()}")
print("=" * 80)

display(deal_status_df_pd)




# COMMAND ----------

# MAGIC %md
# MAGIC # Parse for LINE_ITEM_TYPE_PERFORMANCE Validation
# MAGIC

# COMMAND ----------

# Databricks notebook Target
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from datetime import datetime, date
import os
import pandas as pd

# COMMAND ----------

# Configuration
catalog_name = 'fox_bi_qa'
env = 'dev'  # or 'qa' or 'prod'

# COMMAND ----------

# MAGIC %md
# MAGIC ## Validation: wrap_detailed_unified_report_sections_by_deal vs ft_unified_campaign_delivery_by_deal
# MAGIC
# MAGIC This validation compares:
# MAGIC - Target: Sum of field10 from wrap_detailed_unified_report_sections_by_deal (for LINE_ITEM_TYPE_PERFORMANCE data_type)
# MAGIC - Target: Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
# MAGIC
# MAGIC For each aos_deal_id

# COMMAND ----------

# MAGIC %md
# MAGIC ### Target Data: wrap_detailed_unified_report_sections_by_deal

# COMMAND ----------

# Target: Aggregate field10 from wrap_detailed_unified_report_sections_by_deal
# Filter for LINE_ITEM_TYPE_PERFORMANCE data_type and sum field10 (which contains Total_Delivered_Impressions as string)
tar_df = spark.sql(f"""
    SELECT 
        AOS_Deal_ID,
        SUM(try_cast(field5 AS BIGINT)) as `Target Total Placements`,      
        SUM(try_cast(field2 AS BIGINT)) as `Target Total Delivered Impressions`,
        SUM(try_cast(field3 AS DECIMAL(19,2))) as `Target Total Delivered Revenue`,
        SUM(try_cast(field4 AS BIGINT)) as `Target Total Delivered Clicks`,
        CAST(CASE
                WHEN SUM(field2) > 0
                THEN ROUND((SUM(field4) / SUM(field2) * 100), 4)
                ELSE 0
            END AS DECIMAL(19,2)
        ) as `Target CTR`,
        SUM(try_cast(field8 AS BIGINT)) as `Target Total Third Party Impressions`,
        SUM(try_cast(field9 AS DECIMAL(19,2))) as `Target Total Third Party Revenue`
    FROM {catalog_name}.gold_ad_sales.wrap_detailed_unified_report_sections_by_deal
    WHERE data_type = 'LINE_ITEM_TYPE_PERFORMANCE'
    GROUP BY AOS_Deal_ID
""")

display(tar_df)



# COMMAND ----------

# MAGIC %md
# MAGIC ### Source Data: ft_unified_campaign_delivery_by_deal

# COMMAND ----------

# Source: Get Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
src_df = spark.sql(f"""
    SELECT 
        `AOS Deal ID` as AOS_Deal_ID,
        `Total Placements` as `Source Total Placements`,
        `Total Delivered Impressions` as `Source Total Delivered Impressions`,
        `Total Delivered Revenue` as `Source Total Delivered Revenue`,
        `Total Delivered Clicks` as `Source Total Delivered Clicks`,
        `CTR` as `Source CTR`,
        `Total Third Party Impressions` as `Source Total Third Party Impressions`,
        `Total Third Party Revenue` as `Source Total Third Party Revenue`
    FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal
    WHERE `AOS Deal ID` IS NOT NULL
        AND `AOS Deal ID` != -1
""")

display(src_df)


# COMMAND ----------

# MAGIC %md
# MAGIC ### Validation Comparison

# COMMAND ----------

from pyspark.sql.functions import col, when, expr, nvl, abs, lit, array, concat_ws

# Join source and target on AOS_Deal_ID
joined_df = src_df.join(
    tar_df,
    on="AOS_Deal_ID",
    how="full_outer"
)

display(joined_df)


# Add comparison columns - only for columns that exist in both dataframes
validation_df = joined_df.withColumn(
    "Source_Total_Placements",
    nvl(col("`Source Total Placements`"), lit(0))
).withColumn(
    "Target_Total_Placements",
    nvl(col("`Target Total Placements`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Impressions",
    nvl(col("`Source Total Delivered Impressions`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Impressions",
    nvl(col("`Target Total Delivered Impressions`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Revenue",
    nvl(col("`Source Total Delivered Revenue`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Revenue",
    nvl(col("`Target Total Delivered Revenue`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Clicks",
    nvl(col("`Source Total Delivered Clicks`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Clicks",
    nvl(col("`Target Total Delivered Clicks`"), lit(0))
).withColumn(
    "Source_CTR",
    nvl(col("`Source CTR`"), lit(0))
).withColumn(
    "Target_CTR",
    nvl(col("`Target CTR`"), lit(0))
).withColumn(
    "Source_Total_Third_Party_Impressions",
    nvl(col("`Source Total Third Party Impressions`"), lit(0))
).withColumn(
    "Target_Total_Third_Party_Impressions",
    nvl(col("`Target Total Third Party Impressions`"), lit(0))
).withColumn(
    "Source_Total_Third_Party_Revenue",
    nvl(col("`Source Total Third Party Revenue`"), lit(0))
).withColumn(
    "Target_Total_Third_Party_Revenue",
    nvl(col("`Target Total Third Party Revenue`"), lit(0))
).withColumn(
    "Variance_Placements",
    col("Source_Total_Placements") - col("Target_Total_Placements")
).withColumn(
    "Variance_Impressions",
    col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")
).withColumn(
    "Variance_Revenue",
    col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")
).withColumn(
    "Variance_Clicks",
    col("Source_Total_Delivered_Clicks") - col("Target_Total_Delivered_Clicks")
).withColumn(
    "Variance_CTR",
    col("Source_CTR") - col("Target_CTR")
).withColumn(
    "Variance_Total_Third_Party_Impressions",
    col("Source_Total_Third_Party_Impressions") - col("Target_Total_Third_Party_Impressions")
).withColumn(
    "Variance_Total_Third_Party_Revenue",
    col("Source_Total_Third_Party_Revenue") - col("Target_Total_Third_Party_Revenue")
).withColumn(
    "Placements_Match",
    when(
        abs(col("Source_Total_Placements") - col("Target_Total_Placements")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Impressions_Match",
    when(
        abs(col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Revenue_Match",
    when(
        abs(col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Clicks_Match",
    when(
        abs(col("Source_Total_Delivered_Clicks") - col("Target_Total_Delivered_Clicks")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "CTR_Match",
    when(
        abs(col("Source_CTR") - col("Target_CTR")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Total_Third_Party_Impressions_Match",
    when(
        abs(col("Source_Total_Third_Party_Impressions") - col("Target_Total_Third_Party_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Total_Third_Party_Revenue_Match",
    when(
        abs(col("Source_Total_Third_Party_Revenue") - col("Target_Total_Third_Party_Revenue")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Status",
    when(
        (col("Placements_Match") == True) &
        (col("Impressions_Match") == True) &
        (col("Revenue_Match") == True) &
        (col("Clicks_Match") == True) &
        (col("CTR_Match") == True) &
        (col("Total_Third_Party_Impressions_Match") == True) &
        (col("Total_Third_Party_Revenue_Match") == True),
        True
    ).otherwise(False)
).select(
    col("AOS_Deal_ID"),
    col("Source_Total_Placements"),
    col("Target_Total_Placements"),
    col("Variance_Placements"),
    col("Placements_Match"),
    col("Source_Total_Delivered_Impressions"),
    col("Target_Total_Delivered_Impressions"),
    col("Variance_Impressions"),
    col("Impressions_Match"),
    col("Source_Total_Delivered_Revenue"),
    col("Target_Total_Delivered_Revenue"),
    col("Variance_Revenue"),
    col("Revenue_Match"),
    col("Source_Total_Delivered_Clicks"),
    col("Target_Total_Delivered_Clicks"),
    col("Variance_Clicks"),
    col("Clicks_Match"),
    col("Source_CTR"),
    col("Target_CTR"),
    col("Variance_CTR"),
    col("CTR_Match"),
    col("Source_Total_Third_Party_Impressions"),
    col("Target_Total_Third_Party_Impressions"),
    col("Variance_Total_Third_Party_Impressions"),
    col("Total_Third_Party_Impressions_Match"),
    col("Source_Total_Third_Party_Revenue"),
    col("Target_Total_Third_Party_Revenue"),
    col("Variance_Total_Third_Party_Revenue"),
    col("Total_Third_Party_Revenue_Match"),
    col("Status")
)

display(validation_df)



# Create a dataframe showing which columns have mismatches for deals where Status is False
mismatch_details_df = validation_df.withColumn(
    "Mismatched_Columns_Array",
    array(
        when(col("Placements_Match") == False, lit("Placements")).otherwise(lit(None)),
        when(col("Impressions_Match") == False, lit("Impressions")).otherwise(lit(None)),
        when(col("Revenue_Match") == False, lit("Revenue")).otherwise(lit(None)),
        when(col("Clicks_Match") == False, lit("Clicks")).otherwise(lit(None)),
        when(col("CTR_Match") == False, lit("CTR")).otherwise(lit(None)),
        when(col("Total_Third_Party_Impressions_Match") == False, lit("Total_Third_Party_Impressions")).otherwise(lit(None)),
        when(col("Total_Third_Party_Revenue_Match") == False, lit("Total_Third_Party_Revenue")).otherwise(lit(None))
    )
).withColumn(
    "Mismatched_Columns_Array",
    expr("filter(Mismatched_Columns_Array, x -> x is not null)")
).withColumn(
    "Mismatched_Columns",
    concat_ws(", ", col("Mismatched_Columns_Array"))
).select(
    col("AOS_Deal_ID").alias("deal_id"),
    when(col("Status") == True, lit("True"))
    .when(col("Status") == False, lit("False"))
    .otherwise(lit("False")).alias("Status"),
    col("Mismatched_Columns")
).distinct()

print("=" * 80)
print(f"Deal Mismatch Details")
print(f"Total Deals with Mismatches: {mismatch_details_df.count()}")
print("=" * 80)

display(mismatch_details_df)



# COMMAND ----------

# MAGIC %md
# MAGIC ### Deal IDs Only in Target Table (Not in Source)

# COMMAND ----------

# Find deal_ids that are only in target table and not in source table
target_only_deals = spark.sql(f"""
    SELECT 
        t.`AOS Deal ID` as AOS_Deal_ID,
        t.`Total Placements` as `Target Total Placements`,
        t.`Total Delivered Impressions` as `Target Total Delivered Impressions`,
        t.`Total Delivered Revenue` as `Target Total Delivered Revenue`,
        t.`Total Delivered Clicks` as `Target Total Delivered Clicks`,
        t.`CTR` as `Target CTR`,
        t.`Total Third Party Impressions` as `Target Total Third Party Impressions`,
        t.`Total Third Party Revenue` as `Target Total Third Party Revenue`
    FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal t
    WHERE t.`AOS Deal ID` IS NOT NULL
        AND t.`AOS Deal ID` != -1
        AND NOT EXISTS (
            SELECT 1
            FROM {catalog_name}.gold_ad_sales.wrap_detailed_unified_report_sections_by_deal s
            WHERE s.AOS_Deal_ID = t.`AOS Deal ID`
                AND s.data_type = 'LINE_ITEM_TYPE_PERFORMANCE'
        )
    ORDER BY t.`AOS Deal ID`
""")

print("=" * 80)
print(f"Deal IDs only in v_ft_unified_campaign_delivery_by_deal Table (v_ft_unified_campaign_delivery_by_deal)")
print(f"Count: {target_only_deals.count()}")
print("=" * 80)

display(target_only_deals)




# COMMAND ----------

# MAGIC %md
# MAGIC ### Update mismatch_details_df: Mark missing deals from target_only_deals

# COMMAND ----------

# Update mismatch_details_df to include deals from target_only_deals with Status = "missing deals"
# First, convert Status to string in mismatch_details_df to allow "missing deals" value
mismatch_details_df_1 = mismatch_details_df.withColumn(
    "Status",
    when(col("Status") == True, lit("True"))
    .when(col("Status") == False, lit("False"))
    .otherwise(col("Status").cast("string"))
)

# Create a dataframe for missing deals with the same structure as mismatch_details_df
missing_deals_df = target_only_deals.select(
    col("AOS_Deal_ID").alias("deal_id"),
    lit("missing deals").alias("Status"),
    lit("Deal not found in source table").alias("Mismatched_Columns")
)

display(missing_deals_df)

display(mismatch_details_df_1)

# Option 1: Use a broadcast join with a flag, then check if deal_id exists in target_only_deals
from pyspark.sql.functions import broadcast

# Create a set of deal_ids from target_only_deals for efficient lookup
target_only_deal_ids = target_only_deals.select(col("AOS_Deal_ID").alias("deal_id")).distinct()

# Join and check if deal_id exists in target_only_deals
mismatch_details_df_1 = mismatch_details_df_1.join(
    broadcast(target_only_deal_ids).withColumn("is_target_only", lit(True)),
    on="deal_id",
    how="left"
).withColumn(
    "Status",
    when(col("is_target_only").isNotNull(), lit("not found in source").cast("string"))
    .otherwise(col("Status").cast("string"))
).select(
    col("deal_id"),
    col("Status").cast("string").alias("Status"),
    col("Mismatched_Columns")
)


display(mismatch_details_df_1)



# Create a dataframe with deal_id and LINE_ITEM_TYPE_PERFORMANCE (True if Status is True, False otherwise)
deal_status_df_ltp = mismatch_details_df_1.select(
    col("deal_id"),
    when(col("Status") == "True", lit(True))
    .when(col("Status") == "False", lit(False))
    .otherwise(lit(False))
    .alias("LINE_ITEM_TYPE_PERFORMANCE")
).distinct()

print("=" * 80)
print(f"Deal Status Summary")
print(f"Total Deals: {deal_status_df_ltp.count()}")
print(f"Deals with LINE_ITEM_TYPE_PERFORMANCE = True: {deal_status_df_ltp.filter(col('LINE_ITEM_TYPE_PERFORMANCE') == True).count()}")
print(f"Deals with LINE_ITEM_TYPE_PERFORMANCE = False: {deal_status_df_ltp.filter(col('LINE_ITEM_TYPE_PERFORMANCE') == False).count()}")
print("=" * 80)

display(deal_status_df_ltp)





# COMMAND ----------

# MAGIC %md
# MAGIC # Parse for AD_POSITION_ANALYSIS Validation
# MAGIC

# COMMAND ----------

# Databricks notebook Target
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from datetime import datetime, date
import os
import pandas as pd

# COMMAND ----------

# Configuration
catalog_name = 'fox_bi_qa'
env = 'dev'  # or 'qa' or 'prod'

# COMMAND ----------

# MAGIC %md
# MAGIC ## Validation: wrap_detailed_unified_report_sections_by_deal vs ft_unified_campaign_delivery_by_deal
# MAGIC
# MAGIC This validation compares:
# MAGIC - Target: Sum of field10 from wrap_detailed_unified_report_sections_by_deal (for AD_POSITION_ANALYSIS data_type)
# MAGIC - Target: Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
# MAGIC
# MAGIC For each aos_deal_id

# COMMAND ----------

# MAGIC %md
# MAGIC ### Target Data: wrap_detailed_unified_report_sections_by_deal

# COMMAND ----------

# Target: Aggregate field10 from wrap_detailed_unified_report_sections_by_deal
# Filter for AD_POSITION_ANALYSIS data_type and sum field10 (which contains Total_Delivered_Impressions as string)
tar_df = spark.sql(f"""
    SELECT 
        AOS_Deal_ID,   
        SUM(try_cast(field4 AS BIGINT)) as `Target Total Placements`,
        SUM(try_cast(field2 AS BIGINT)) as `Target Total Delivered Impressions`,
        SUM(try_cast(field3 AS DECIMAL(19,2))) as `Target Total Delivered Revenue`
    FROM {catalog_name}.gold_ad_sales.wrap_detailed_unified_report_sections_by_deal
    WHERE data_type = 'AD_POSITION_ANALYSIS'
    GROUP BY AOS_Deal_ID
""")

display(tar_df)


# COMMAND ----------

# MAGIC %md
# MAGIC ### Validation Comparison

# COMMAND ----------

from pyspark.sql.functions import col, when, expr, nvl, abs, lit, array, concat_ws

# Join source and target on AOS_Deal_ID
joined_df = src_df.join(
    tar_df,
    on="AOS_Deal_ID",
    how="full_outer"
)

display(joined_df)


# Add comparison columns
validation_df = joined_df.withColumn(
    "Source_Total_Placements",
    nvl(col("`Source Total Placements`"), lit(0))
).withColumn(
    "Target_Total_Placements",
    nvl(col("`Target Total Placements`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Impressions",
    nvl(col("`Source Total Delivered Impressions`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Impressions",
    nvl(col("`Target Total Delivered Impressions`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Revenue",
    nvl(col("`Source Total Delivered Revenue`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Revenue",
    nvl(col("`Target Total Delivered Revenue`"), lit(0))
).withColumn(
    "Variance_Placements",
    col("Source_Total_Placements") - col("Target_Total_Placements")
).withColumn(
    "Variance_Impressions",
    col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")
).withColumn(
    "Variance_Revenue",
    col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")
).withColumn(
    "Placements_Match",
    when(
        abs(col("Source_Total_Placements") - col("Target_Total_Placements")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Impressions_Match",
    when(
        abs(col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Revenue_Match",
    when(
        abs(col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Status",
    when(
        (col("Placements_Match") == True) &
        (col("Impressions_Match") == True) &
        (col("Revenue_Match") == True),
        True
    ).otherwise(False)
).select(
    col("AOS_Deal_ID"),
    col("Source_Total_Placements"),
    col("Target_Total_Placements"),
    col("Variance_Placements"),
    col("Placements_Match"),
    col("Source_Total_Delivered_Impressions"),
    col("Target_Total_Delivered_Impressions"),
    col("Variance_Impressions"),
    col("Impressions_Match"),
    col("Source_Total_Delivered_Revenue"),
    col("Target_Total_Delivered_Revenue"),
    col("Variance_Revenue"),
    col("Revenue_Match"),
    col("Status")
)

display(validation_df)


# COMMAND ----------

# MAGIC %md
# MAGIC ### Deal Mismatch Details: Which columns failed validation for each deal_id

# COMMAND ----------

# Create a dataframe showing which columns have mismatches for deals where Status is False
mismatch_details_df = validation_df.withColumn(
    "Mismatched_Columns_Array",
    array(
        when(col("Placements_Match") == False, lit("Placements")).otherwise(lit(None)),
        when(col("Impressions_Match") == False, lit("Impressions")).otherwise(lit(None)),
        when(col("Revenue_Match") == False, lit("Revenue")).otherwise(lit(None))
    )
).withColumn(
    "Mismatched_Columns_Array",
    expr("filter(Mismatched_Columns_Array, x -> x is not null)")
).withColumn(
    "Mismatched_Columns",
    concat_ws(", ", col("Mismatched_Columns_Array"))
).select(
    col("AOS_Deal_ID").alias("deal_id"),
    when(col("Status") == True, lit("True"))
    .when(col("Status") == False, lit("False"))
    .otherwise(lit("False")).alias("Status"),
    col("Mismatched_Columns")
).distinct()

print("=" * 80)
print(f"Deal Mismatch Details")
print(f"Total Deals with Mismatches: {mismatch_details_df.count()}")
print("=" * 80)

display(mismatch_details_df)


# COMMAND ----------

# MAGIC %md
# MAGIC ### Deal IDs Only in Target Table (Not in Source)

# COMMAND ----------

# Find deal_ids that are only in target table and not in source table
target_only_deals = spark.sql(f"""
    SELECT 
        t.`AOS Deal ID` as AOS_Deal_ID,
        t.`Total Placements` as `Target Total Placements`,
        t.`Total Delivered Impressions` as `Target Total Delivered Impressions`,
        t.`Total Delivered Revenue` as `Target Total Delivered Revenue`
    FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal t
    WHERE t.`AOS Deal ID` IS NOT NULL
        AND t.`AOS Deal ID` != -1
        AND NOT EXISTS (
            SELECT 1
            FROM {catalog_name}.gold_ad_sales.wrap_detailed_unified_report_sections_by_deal s
            WHERE s.AOS_Deal_ID = t.`AOS Deal ID`
                AND s.data_type = 'AD_POSITION_ANALYSIS'
        )
    ORDER BY t.`AOS Deal ID`
""")

print("=" * 80)
print(f"Deal IDs only in v_ft_unified_campaign_delivery_by_deal Table (Not in Source)")
print(f"Count: {target_only_deals.count()}")
print("=" * 80)

display(target_only_deals)


# COMMAND ----------

# MAGIC %md
# MAGIC ### Update mismatch_details_df: Mark missing deals from target_only_deals

# COMMAND ----------

# Update mismatch_details_df to include deals from target_only_deals with Status = "missing deals"
# First, convert Status to string in mismatch_details_df to allow "missing deals" value
mismatch_details_df_1 = mismatch_details_df.withColumn(
    "Status",
    when(col("Status") == True, lit("True"))
    .when(col("Status") == False, lit("False"))
    .otherwise(col("Status").cast("string"))
)

# Create a dataframe for missing deals with the same structure as mismatch_details_df
missing_deals_df = target_only_deals.select(
    col("AOS_Deal_ID").alias("deal_id"),
    lit("missing deals").alias("Status"),
    lit("Deal not found in source table").alias("Mismatched_Columns")
)

display(missing_deals_df)

display(mismatch_details_df_1)

# Option 1: Use a broadcast join with a flag, then check if deal_id exists in target_only_deals
from pyspark.sql.functions import broadcast

# Create a set of deal_ids from target_only_deals for efficient lookup
target_only_deal_ids = target_only_deals.select(col("AOS_Deal_ID").alias("deal_id")).distinct()

# Join and check if deal_id exists in target_only_deals
mismatch_details_df_1 = mismatch_details_df_1.join(
    broadcast(target_only_deal_ids).withColumn("is_target_only", lit(True)),
    on="deal_id",
    how="left"
).withColumn(
    "Status",
    when(col("is_target_only").isNotNull(), lit("not found in source").cast("string"))
    .otherwise(col("Status").cast("string"))
).select(
    col("deal_id"),
    col("Status").cast("string").alias("Status"),
    col("Mismatched_Columns")
)


display(mismatch_details_df_1)


# Create a dataframe with deal_id and AD_POSITION_ANALYSIS (True if Status is True, False otherwise)
deal_status_df_adp = mismatch_details_df_1.select(
    col("deal_id"),
    when(col("Status") == "True", lit(True))
    .when(col("Status") == "False", lit(False))
    .otherwise(lit(False))
    .alias("AD_POSITION_ANALYSIS")
).distinct()

print("=" * 80)
print(f"Deal Status Summary")
print(f"Total Deals: {deal_status_df_adp.count()}")
print(f"Deals with AD_POSITION_ANALYSIS = True: {deal_status_df_adp.filter(col('AD_POSITION_ANALYSIS') == True).count()}")
print(f"Deals with AD_POSITION_ANALYSIS = False: {deal_status_df_adp.filter(col('AD_POSITION_ANALYSIS') == False).count()}")
print("=" * 80)

display(deal_status_df_adp)





# COMMAND ----------

# MAGIC %md
# MAGIC # Parse for CREATIVE_PERFORMANCE Validation
# MAGIC

# COMMAND ----------

# Databricks notebook Target
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from datetime import datetime, date
import os
import pandas as pd

# COMMAND ----------

# Configuration
catalog_name = 'fox_bi_qa'
env = 'dev'  # or 'qa' or 'prod'

# COMMAND ----------

# MAGIC %md
# MAGIC ## Validation: wrap_detailed_unified_report_sections_by_deal vs ft_unified_campaign_delivery_by_deal
# MAGIC
# MAGIC This validation compares:
# MAGIC - Target: Sum of field10 from wrap_detailed_unified_report_sections_by_deal (for CREATIVE_PERFORMANCE data_type)
# MAGIC - Target: Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
# MAGIC
# MAGIC For each aos_deal_id

# COMMAND ----------

# MAGIC %md
# MAGIC ### Target Data: wrap_detailed_unified_report_sections_by_deal

# COMMAND ----------

# Target: Aggregate field10 from wrap_detailed_unified_report_sections_by_deal
# Filter for CREATIVE_PERFORMANCE data_type and sum field10 (which contains Total_Delivered_Impressions as string)
tar_df = spark.sql(f"""
    SELECT 
        AOS_Deal_ID,
        SUM(try_cast(field6 AS BIGINT)) as `Target Total Creatives`,
        SUM(try_cast(field4 AS BIGINT)) as `Target Total Delivered Impressions`,
        SUM(try_cast(field5 AS DECIMAL(19,2))) as `Target Total Delivered Revenue`,
        SUM(try_cast(field6 AS BIGINT)) as `Target Total Delivered Clicks`,
        CAST(
            CASE
                WHEN SUM(field4) > 0
                THEN ROUND((SUM(field6) / SUM(field4) * 100), 4)
                ELSE 0
            END AS DECIMAL(19,2)
        ) as `Target CTR`,
        SUM(try_cast(field9 AS BIGINT)) as `Target Total Third Party Impressions`,
        SUM(try_cast(field10 AS DECIMAL(19,2))) as `Target Total Third Party Revenue`
    FROM {catalog_name}.gold_ad_sales.wrap_detailed_unified_report_sections_by_deal
    WHERE data_type = 'CREATIVE_PERFORMANCE'
    GROUP BY AOS_Deal_ID
""")

display(tar_df)



# COMMAND ----------

# MAGIC %md
# MAGIC ### Source Data: ft_unified_campaign_delivery_by_deal

# COMMAND ----------

# Source: Get Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
src_df = spark.sql(f"""
    SELECT 
        `AOS Deal ID` as AOS_Deal_ID,
        `Total Creatives` as `Source Total Creatives`,
        `Total Delivered Impressions` as `Source Total Delivered Impressions`,
        `Total Delivered Revenue` as `Source Total Delivered Revenue`,
        `Total Delivered Clicks` as `Source Total Delivered Clicks`,
        `CTR` as `Source CTR`,
        `Total Third Party Impressions` as `Source Total Third Party Impressions`,
        `Total Third Party Revenue` as `Source Total Third Party Revenue`
    FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal
    WHERE `AOS Deal ID` IS NOT NULL
        AND `AOS Deal ID` != -1
""")

display(src_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Validation Comparison

# COMMAND ----------

from pyspark.sql.functions import col, when, expr, nvl, abs, lit, array, concat_ws

# Join source and target on AOS_Deal_ID
joined_df = src_df.join(
    tar_df,
    on="AOS_Deal_ID",
    how="full_outer"
)

display(joined_df)


# Add comparison columns - only for columns that exist in both src_df and tar_df
validation_df = joined_df.withColumn(
    "Source_Total_Creatives",
    nvl(col("`Source Total Creatives`"), lit(0))
).withColumn(
    "Target_Total_Creatives",
    nvl(col("`Target Total Creatives`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Impressions",
    nvl(col("`Source Total Delivered Impressions`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Impressions",
    nvl(col("`Target Total Delivered Impressions`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Revenue",
    nvl(col("`Source Total Delivered Revenue`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Revenue",
    nvl(col("`Target Total Delivered Revenue`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Clicks",
    nvl(col("`Source Total Delivered Clicks`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Clicks",
    nvl(col("`Target Total Delivered Clicks`"), lit(0))
).withColumn(
    "Source_CTR",
    nvl(col("`Source CTR`"), lit(0))
).withColumn(
    "Target_CTR",
    nvl(col("`Target CTR`"), lit(0))
).withColumn(
    "Source_Total_Third_Party_Impressions",
    nvl(col("`Source Total Third Party Impressions`"), lit(0))
).withColumn(
    "Target_Total_Third_Party_Impressions",
    nvl(col("`Target Total Third Party Impressions`"), lit(0))
).withColumn(
    "Source_Total_Third_Party_Revenue",
    nvl(col("`Source Total Third Party Revenue`"), lit(0))
).withColumn(
    "Target_Total_Third_Party_Revenue",
    nvl(col("`Target Total Third Party Revenue`"), lit(0))
).withColumn(
    "Variance_Total_Creatives",
    col("Source_Total_Creatives") - col("Target_Total_Creatives")
).withColumn(
    "Variance_Impressions",
    col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")
).withColumn(
    "Variance_Revenue",
    col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")
).withColumn(
    "Variance_Clicks",
    col("Source_Total_Delivered_Clicks") - col("Target_Total_Delivered_Clicks")
).withColumn(
    "Variance_CTR",
    col("Source_CTR") - col("Target_CTR")
).withColumn(
    "Variance_Total_Third_Party_Impressions",
    col("Source_Total_Third_Party_Impressions") - col("Target_Total_Third_Party_Impressions")
).withColumn(
    "Variance_Total_Third_Party_Revenue",
    col("Source_Total_Third_Party_Revenue") - col("Target_Total_Third_Party_Revenue")
).withColumn(
    "Total_Creatives_Match",
    when(
        abs(col("Source_Total_Creatives") - col("Target_Total_Creatives")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Impressions_Match",
    when(
        abs(col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Revenue_Match",
    when(
        abs(col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Clicks_Match",
    when(
        abs(col("Source_Total_Delivered_Clicks") - col("Target_Total_Delivered_Clicks")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "CTR_Match",
    when(
        abs(col("Source_CTR") - col("Target_CTR")) <= 0.0001,  # Use smaller threshold for CTR (percentage)
        True
    ).otherwise(False)
).withColumn(
    "Total_Third_Party_Impressions_Match",
    when(
        abs(col("Source_Total_Third_Party_Impressions") - col("Target_Total_Third_Party_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Total_Third_Party_Revenue_Match",
    when(
        abs(col("Source_Total_Third_Party_Revenue") - col("Target_Total_Third_Party_Revenue")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Status",
    when(
        (col("Total_Creatives_Match") == True) &
        (col("Impressions_Match") == True) &
        (col("Revenue_Match") == True) &
        (col("Clicks_Match") == True) &
        (col("CTR_Match") == True) &
        (col("Total_Third_Party_Impressions_Match") == True) &
        (col("Total_Third_Party_Revenue_Match") == True),
        True
    ).otherwise(False)
).select(
    col("AOS_Deal_ID"),
    col("Source_Total_Creatives"),
    col("Target_Total_Creatives"),
    col("Variance_Total_Creatives"),
    col("Total_Creatives_Match"),
    col("Source_Total_Delivered_Impressions"),
    col("Target_Total_Delivered_Impressions"),
    col("Variance_Impressions"),
    col("Impressions_Match"),
    col("Source_Total_Delivered_Revenue"),
    col("Target_Total_Delivered_Revenue"),
    col("Variance_Revenue"),
    col("Revenue_Match"),
    col("Source_Total_Delivered_Clicks"),
    col("Target_Total_Delivered_Clicks"),
    col("Variance_Clicks"),
    col("Clicks_Match"),
    col("Source_CTR"),
    col("Target_CTR"),
    col("Variance_CTR"),
    col("CTR_Match"),
    col("Source_Total_Third_Party_Impressions"),
    col("Target_Total_Third_Party_Impressions"),
    col("Variance_Total_Third_Party_Impressions"),
    col("Total_Third_Party_Impressions_Match"),
    col("Source_Total_Third_Party_Revenue"),
    col("Target_Total_Third_Party_Revenue"),
    col("Variance_Total_Third_Party_Revenue"),
    col("Total_Third_Party_Revenue_Match"),
    col("Status")
)

display(validation_df)



# Create a dataframe showing which columns have mismatches for deals where Status is False
mismatch_details_df = validation_df.withColumn(
    "Mismatched_Columns_Array",
    array(
        when(col("Total_Creatives_Match") == False, lit("Total_Creatives")).otherwise(lit(None)),
        when(col("Impressions_Match") == False, lit("Impressions")).otherwise(lit(None)),
        when(col("Revenue_Match") == False, lit("Revenue")).otherwise(lit(None)),
        when(col("Clicks_Match") == False, lit("Clicks")).otherwise(lit(None)),
        when(col("CTR_Match") == False, lit("CTR")).otherwise(lit(None)),
        when(col("Total_Third_Party_Impressions_Match") == False, lit("Total_Third_Party_Impressions")).otherwise(lit(None)),
        when(col("Total_Third_Party_Revenue_Match") == False, lit("Total_Third_Party_Revenue")).otherwise(lit(None))
    )
).withColumn(
    "Mismatched_Columns_Array",
    expr("filter(Mismatched_Columns_Array, x -> x is not null)")
).withColumn(
    "Mismatched_Columns",
    concat_ws(", ", col("Mismatched_Columns_Array"))
).select(
    col("AOS_Deal_ID").alias("deal_id"),
    when(col("Status") == True, lit("True"))
    .when(col("Status") == False, lit("False"))
    .otherwise(lit("False")).alias("Status"),
    col("Mismatched_Columns")
).distinct()

print("=" * 80)
print(f"Deal Mismatch Details")
print(f"Total Deals with Mismatches: {mismatch_details_df.count()}")
print("=" * 80)

display(mismatch_details_df)





# COMMAND ----------

# MAGIC %md
# MAGIC ### Deal IDs Only in Target Table (Not in Source)

# COMMAND ----------

# Find deal_ids that are only in target table and not in source table
target_only_deals = spark.sql(f"""
    SELECT 
        t.`AOS Deal ID` as AOS_Deal_ID,
        t.`Total Creatives` as `Target Total Creatives`,
        t.`Total Delivered Impressions` as `Target Total Delivered Impressions`,
        t.`Total Delivered Revenue` as `Target Total Delivered Revenue`,
        t.`Total Delivered Clicks` as `Target Total Delivered Clicks`,
        t.`CTR` as `Target CTR`,
        t.`Total Third Party Impressions` as `Target Total Third Party Impressions`,
        t.`Total Third Party Revenue` as `Target Total Third Party Revenue`
    FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal t
    WHERE t.`AOS Deal ID` IS NOT NULL
        AND t.`AOS Deal ID` != -1
        AND NOT EXISTS (
            SELECT 1
            FROM {catalog_name}.gold_ad_sales.wrap_detailed_unified_report_sections_by_deal s
            WHERE s.AOS_Deal_ID = t.`AOS Deal ID`
                AND s.data_type = 'CREATIVE_PERFORMANCE'
        )
    ORDER BY t.`AOS Deal ID`
""")

print("=" * 80)
print(f"Deal IDs only in v_ft_unified_campaign_delivery_by_deal Table (v_ft_unified_campaign_delivery_by_deal)")
print(f"Count: {target_only_deals.count()}")
print("=" * 80)

display(target_only_deals)




# COMMAND ----------

# MAGIC %md
# MAGIC ### Update mismatch_details_df: Mark missing deals from target_only_deals

# COMMAND ----------

# Update mismatch_details_df to include deals from target_only_deals with Status = "missing deals"
# First, convert Status to string in mismatch_details_df to allow "missing deals" value
mismatch_details_df_1 = mismatch_details_df.withColumn(
    "Status",
    when(col("Status") == True, lit("True"))
    .when(col("Status") == False, lit("False"))
    .otherwise(col("Status").cast("string"))
)

# Create a dataframe for missing deals with the same structure as mismatch_details_df
missing_deals_df = target_only_deals.select(
    col("AOS_Deal_ID").alias("deal_id"),
    lit("missing deals").alias("Status"),
    lit("Deal not found in source table").alias("Mismatched_Columns")
)

display(missing_deals_df)

display(mismatch_details_df_1)

# Option 1: Use a broadcast join with a flag, then check if deal_id exists in target_only_deals
from pyspark.sql.functions import broadcast

# Create a set of deal_ids from target_only_deals for efficient lookup
target_only_deal_ids = target_only_deals.select(col("AOS_Deal_ID").alias("deal_id")).distinct()

# Join and check if deal_id exists in target_only_deals
mismatch_details_df_1 = mismatch_details_df_1.join(
    broadcast(target_only_deal_ids).withColumn("is_target_only", lit(True)),
    on="deal_id",
    how="left"
).withColumn(
    "Status",
    when(col("is_target_only").isNotNull(), lit("not found in source").cast("string"))
    .otherwise(col("Status").cast("string"))
).select(
    col("deal_id"),
    col("Status").cast("string").alias("Status"),
    col("Mismatched_Columns")
)


display(mismatch_details_df_1)



# Create a dataframe with deal_id and CREATIVE_PERFORMANCE (True if Status is True, False otherwise)
deal_status_df_cp = mismatch_details_df_1.select(
    col("deal_id"),
    when(col("Status") == "True", lit(True))
    .when(col("Status") == "False", lit(False))
    .otherwise(lit(False))
    .alias("CREATIVE_PERFORMANCE")
).distinct()

print("=" * 80)
print(f"Deal Status Summary")
print(f"Total Deals: {deal_status_df_cp.count()}")
print(f"Deals with CREATIVE_PERFORMANCE = True: {deal_status_df_cp.filter(col('CREATIVE_PERFORMANCE') == True).count()}")
print(f"Deals with CREATIVE_PERFORMANCE = False: {deal_status_df_cp.filter(col('CREATIVE_PERFORMANCE') == False).count()}")
print("=" * 80)

display(deal_status_df_cp)




# COMMAND ----------

# MAGIC %md
# MAGIC # Parse for DURATION_BUCKET_ANALYSIS Validation
# MAGIC

# COMMAND ----------

# Databricks notebook Target
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from datetime import datetime, date
import os
import pandas as pd

# COMMAND ----------

# Configuration
catalog_name = 'fox_bi_qa'
env = 'dev'  # or 'qa' or 'prod'

# COMMAND ----------

# MAGIC %md
# MAGIC ## Validation: wrap_detailed_unified_report_sections_by_deal vs ft_unified_campaign_delivery_by_deal
# MAGIC
# MAGIC This validation compares:
# MAGIC - Target: Sum of field10 from wrap_detailed_unified_report_sections_by_deal (for DURATION_BUCKET_ANALYSIS data_type)
# MAGIC - Target: Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
# MAGIC
# MAGIC For each aos_deal_id

# COMMAND ----------

# MAGIC %md
# MAGIC ### Target Data: wrap_detailed_unified_report_sections_by_deal

# COMMAND ----------

# Target: Aggregate field10 from wrap_detailed_unified_report_sections_by_deal
# Filter for DURATION_BUCKET_ANALYSIS data_type and sum field10 (which contains Total_Delivered_Impressions as string)
tar_df = spark.sql(f"""
    SELECT 
        AOS_Deal_ID,      
        SUM(try_cast(field4 AS BIGINT)) as `Target Total Delivered Impressions`,
        SUM(try_cast(field5 AS DECIMAL(19,2))) as `Target Total Delivered Revenue`,
        CAST(
            CASE
                WHEN SUM(field4) > 0
                THEN ROUND((SUM(field5) / SUM(field4) * 1000), 4)
                ELSE 0
            END AS DECIMAL(19,2)
        ) as `Target CPM`
    FROM {catalog_name}.gold_ad_sales.wrap_detailed_unified_report_sections_by_deal
    WHERE data_type = 'DURATION_BUCKET_ANALYSIS'
    GROUP BY AOS_Deal_ID
""")

display(tar_df)



# COMMAND ----------

# MAGIC %md
# MAGIC ### Source Data: ft_unified_campaign_delivery_by_deal

# COMMAND ----------

# Source: Get Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
src_df = spark.sql(f"""
    SELECT 
        `AOS Deal ID` as AOS_Deal_ID,
        `Total Delivered Impressions` as `Source Total Delivered Impressions`,
        `Total Delivered Revenue` as `Source Total Delivered Revenue`,
        `CPM` as `Source CPM`      
    FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal
    WHERE `AOS Deal ID` IS NOT NULL
        AND `AOS Deal ID` != -1
""")

display(src_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Validation Comparison

# COMMAND ----------

from pyspark.sql.functions import col, when, expr, nvl, abs, lit, array, concat_ws

# Join source and target on AOS_Deal_ID
joined_df = src_df.join(
    tar_df,
    on="AOS_Deal_ID",
    how="full_outer"
)

display(joined_df)


# Add comparison columns - only for the columns that actually exist
validation_df = joined_df.withColumn(
    "Source_Total_Delivered_Impressions",
    nvl(col("`Source Total Delivered Impressions`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Impressions",
    nvl(col("`Target Total Delivered Impressions`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Revenue",
    nvl(col("`Source Total Delivered Revenue`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Revenue",
    nvl(col("`Target Total Delivered Revenue`"), lit(0))
).withColumn(
    "Source_CPM",
    nvl(col("`Source CPM`"), lit(0))
).withColumn(
    "Target_CPM",
    nvl(col("`Target CPM`"), lit(0))
).withColumn(
    "Variance_Impressions",
    col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")
).withColumn(
    "Variance_Revenue",
    col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")
).withColumn(
    "Variance_CPM",
    col("Source_CPM") - col("Target_CPM")
).withColumn(
    "Impressions_Match",
    when(
        abs(col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Revenue_Match",
    when(
        abs(col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "CPM_Match",
    when(
        abs(col("Source_CPM") - col("Target_CPM")) <= 0.01,  # Use smaller threshold for CPM (decimal)
        True
    ).otherwise(False)
).withColumn(
    "Status",
    when(
        (col("Impressions_Match") == True) &
        (col("Revenue_Match") == True) &
        (col("CPM_Match") == True),
        True
    ).otherwise(False)
).select(
    col("AOS_Deal_ID"),
    col("Source_Total_Delivered_Impressions"),
    col("Target_Total_Delivered_Impressions"),
    col("Variance_Impressions"),
    col("Impressions_Match"),
    col("Source_Total_Delivered_Revenue"),
    col("Target_Total_Delivered_Revenue"),
    col("Variance_Revenue"),
    col("Revenue_Match"),
    col("Source_CPM"),
    col("Target_CPM"),
    col("Variance_CPM"),
    col("CPM_Match"),
    col("Status")
)

display(validation_df)


# Create a dataframe showing which columns have mismatches for deals where Status is False
mismatch_details_df = validation_df.withColumn(
    "Mismatched_Columns_Array",
    array(
        when(col("Impressions_Match") == False, lit("Impressions")).otherwise(lit(None)),
        when(col("Revenue_Match") == False, lit("Revenue")).otherwise(lit(None)),
        when(col("CPM_Match") == False, lit("CPM")).otherwise(lit(None))
    )
).withColumn(
    "Mismatched_Columns_Array",
    expr("filter(Mismatched_Columns_Array, x -> x is not null)")
).withColumn(
    "Mismatched_Columns",
    concat_ws(", ", col("Mismatched_Columns_Array"))
).select(
    col("AOS_Deal_ID").alias("deal_id"),
    col("Status"),
    col("Mismatched_Columns")
).distinct()

print("=" * 80)
print(f"Deal Mismatch Details")
print(f"Total Deals with Mismatches: {mismatch_details_df.count()}")
print("=" * 80)

display(mismatch_details_df)




# COMMAND ----------

# MAGIC %md
# MAGIC ### Deal IDs Only in Target Table (Not in Source)

# COMMAND ----------

# Find deal_ids that are only in target table and not in source table
target_only_deals = spark.sql(f"""
    SELECT 
        t.`AOS Deal ID` as AOS_Deal_ID,
        t.`Total Delivered Impressions` as `Target Total Delivered Impressions`,
        t.`Total Delivered Revenue` as `Target Total Delivered Revenue`,
        t.`CPM` as `Target CPM`
    FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal t
    WHERE t.`AOS Deal ID` IS NOT NULL
        AND t.`AOS Deal ID` != -1
        AND NOT EXISTS (
            SELECT 1
            FROM {catalog_name}.gold_ad_sales.wrap_detailed_unified_report_sections_by_deal s
            WHERE s.AOS_Deal_ID = t.`AOS Deal ID`
                AND s.data_type = 'DURATION_BUCKET_ANALYSIS'
        )
    ORDER BY t.`AOS Deal ID`
""")

print("=" * 80)
print(f"Deal IDs only in v_ft_unified_campaign_delivery_by_deal Table (v_ft_unified_campaign_delivery_by_deal)")
print(f"Count: {target_only_deals.count()}")
print("=" * 80)

display(target_only_deals)




# COMMAND ----------

# MAGIC %md
# MAGIC ### Update mismatch_details_df: Mark missing deals from target_only_deals

# COMMAND ----------

# Update mismatch_details_df to include deals from target_only_deals with Status = "missing deals"
# First, convert Status to string in mismatch_details_df to allow "missing deals" value
mismatch_details_df_1 = mismatch_details_df.withColumn(
    "Status",
    when(col("Status") == True, lit("True"))
    .when(col("Status") == False, lit("False"))
    .otherwise(col("Status").cast("string"))
)

# Create a dataframe for missing deals with the same structure as mismatch_details_df
missing_deals_df = target_only_deals.select(
    col("AOS_Deal_ID").alias("deal_id"),
    lit("missing deals").alias("Status"),
    lit("Deal not found in source table").alias("Mismatched_Columns")
)

display(missing_deals_df)

display(mismatch_details_df_1)

# Option 1: Use a broadcast join with a flag, then check if deal_id exists in target_only_deals
from pyspark.sql.functions import broadcast

# Create a set of deal_ids from target_only_deals for efficient lookup
target_only_deal_ids = target_only_deals.select(col("AOS_Deal_ID").alias("deal_id")).distinct()

# Join and check if deal_id exists in target_only_deals
mismatch_details_df_1 = mismatch_details_df_1.join(
    broadcast(target_only_deal_ids).withColumn("is_target_only", lit(True)),
    on="deal_id",
    how="left"
).withColumn(
    "Status",
    when(col("is_target_only").isNotNull(), lit("not found in source").cast("string"))
    .otherwise(col("Status").cast("string"))
).select(
    col("deal_id"),
    col("Status").cast("string").alias("Status"),
    col("Mismatched_Columns")
)


display(mismatch_details_df_1)



# Create a dataframe with deal_id and DURATION_BUCKET_ANALYSIS (True if Status is True, False otherwise)
deal_status_df_dba = mismatch_details_df_1.select(
    col("deal_id"),
    when(col("Status") == "True", lit(True))
    .otherwise(lit(False))
    .alias("DURATION_BUCKET_ANALYSIS")
).distinct()

print("=" * 80)
print(f"Deal Status Summary")
print(f"Total Deals: {deal_status_df_dba.count()}")
print(f"Deals with DURATION_BUCKET_ANALYSIS = True: {deal_status_df_dba.filter(col('DURATION_BUCKET_ANALYSIS') == True).count()}")
print(f"Deals with DURATION_BUCKET_ANALYSIS = False: {deal_status_df_dba.filter(col('DURATION_BUCKET_ANALYSIS') == False).count()}")
print("=" * 80)

display(deal_status_df_dba)





# COMMAND ----------

# MAGIC %md
# MAGIC # Parse for DEVICE_AD_POSITION_MATRIX Validation
# MAGIC

# COMMAND ----------

# Databricks notebook Target
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from datetime import datetime, date
import os
import pandas as pd

# COMMAND ----------

# Configuration
catalog_name = 'fox_bi_qa'
env = 'dev'  # or 'qa' or 'prod'

# COMMAND ----------

# MAGIC %md
# MAGIC ## Validation: wrap_detailed_unified_report_sections_by_deal vs ft_unified_campaign_delivery_by_deal
# MAGIC
# MAGIC This validation compares:
# MAGIC - Target: Sum of field10 from wrap_detailed_unified_report_sections_by_deal (for DEVICE_AD_POSITION_MATRIX data_type)
# MAGIC - Target: Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
# MAGIC
# MAGIC For each aos_deal_id

# COMMAND ----------

# MAGIC %md
# MAGIC ### Target Data: wrap_detailed_unified_report_sections_by_deal

# COMMAND ----------

# Target: Aggregate field10 from wrap_detailed_unified_report_sections_by_deal
# Filter for DEVICE_AD_POSITION_MATRIX data_type and sum field10 (which contains Total_Delivered_Impressions as string)
tar_df = spark.sql(f"""
    SELECT 
        AOS_Deal_ID,     
        SUM(try_cast(field3 AS BIGINT)) as `Target Total Delivered Impressions`,
        SUM(try_cast(field4 AS DECIMAL(19,2))) as `Target Total Delivered Revenue`,
        SUM(try_cast(field5 AS BIGINT)) as `Target Total Delivered Clicks`
    FROM {catalog_name}.gold_ad_sales.wrap_detailed_unified_report_sections_by_deal
    WHERE data_type = 'DEVICE_AD_POSITION_MATRIX'
    GROUP BY AOS_Deal_ID
""")

display(tar_df)



# COMMAND ----------

# MAGIC %md
# MAGIC ### Source Data: ft_unified_campaign_delivery_by_deal

# COMMAND ----------

# Source: Get Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
src_df = spark.sql(f"""
    SELECT 
        `AOS Deal ID` as AOS_Deal_ID,
        `Total Delivered Impressions` as `Source Total Delivered Impressions`,
        `Total Delivered Revenue` as `Source Total Delivered Revenue`,
        `Total Delivered Clicks` as `Source Total Delivered Clicks`
    FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal
    WHERE `AOS Deal ID` IS NOT NULL
        AND `AOS Deal ID` != -1
""")

display(src_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Validation Comparison

# COMMAND ----------

from pyspark.sql.functions import col, when, expr, nvl, abs, lit, array, concat_ws

# Join source and target on AOS_Deal_ID
joined_df = src_df.join(
    tar_df,
    on="AOS_Deal_ID",
    how="full_outer"
)

display(joined_df)


# Add comparison columns - only for the columns that actually exist
validation_df = joined_df.withColumn(
    "Source_Total_Delivered_Impressions",
    nvl(col("`Source Total Delivered Impressions`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Impressions",
    nvl(col("`Target Total Delivered Impressions`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Revenue",
    nvl(col("`Source Total Delivered Revenue`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Revenue",
    nvl(col("`Target Total Delivered Revenue`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Clicks",
    nvl(col("`Source Total Delivered Clicks`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Clicks",
    nvl(col("`Target Total Delivered Clicks`"), lit(0))
).withColumn(
    "Variance_Impressions",
    col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")
).withColumn(
    "Variance_Revenue",
    col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")
).withColumn(
    "Variance_Clicks",
    col("Source_Total_Delivered_Clicks") - col("Target_Total_Delivered_Clicks")
).withColumn(
    "Impressions_Match",
    when(
        abs(col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Revenue_Match",
    when(
        abs(col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Clicks_Match",
    when(
        abs(col("Source_Total_Delivered_Clicks") - col("Target_Total_Delivered_Clicks")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Status",
    when(
        (col("Impressions_Match") == True) &
        (col("Revenue_Match") == True) &
        (col("Clicks_Match") == True),
        True
    ).otherwise(False)
).select(
    col("AOS_Deal_ID"),
    col("Source_Total_Delivered_Impressions"),
    col("Target_Total_Delivered_Impressions"),
    col("Variance_Impressions"),
    col("Impressions_Match"),
    col("Source_Total_Delivered_Revenue"),
    col("Target_Total_Delivered_Revenue"),
    col("Variance_Revenue"),
    col("Revenue_Match"),
    col("Source_Total_Delivered_Clicks"),
    col("Target_Total_Delivered_Clicks"),
    col("Variance_Clicks"),
    col("Clicks_Match"),
    col("Status")
)

display(validation_df)


# COMMAND ----------

# MAGIC %md
# MAGIC ### Deal Mismatch Details

# COMMAND ----------

# Create a dataframe showing which columns have mismatches
mismatch_details_df = validation_df.withColumn(
    "Mismatched_Columns_Array",
    array(
        when(col("Impressions_Match") == False, lit("Impressions")).otherwise(lit(None)),
        when(col("Revenue_Match") == False, lit("Revenue")).otherwise(lit(None)),
        when(col("Clicks_Match") == False, lit("Clicks")).otherwise(lit(None))
    )
).withColumn(
    "Mismatched_Columns_Array",
    expr("filter(Mismatched_Columns_Array, x -> x is not null)")
).withColumn(
    "Mismatched_Columns",
    concat_ws(", ", col("Mismatched_Columns_Array"))
).select(
    col("AOS_Deal_ID").alias("deal_id"),
    when(col("Status") == True, lit("True"))
    .when(col("Status") == False, lit("False"))
    .otherwise(lit("False")).cast("string").alias("Status"),
    col("Mismatched_Columns")
).distinct()

print("=" * 80)
print(f"Deal Mismatch Details")
print(f"Total Deals: {mismatch_details_df.count()}")
print(f"Deals with Status = True: {mismatch_details_df.filter(col('Status') == 'True').count()}")
print(f"Deals with Status = False: {mismatch_details_df.filter(col('Status') == 'False').count()}")
print("=" * 80)

display(mismatch_details_df)


# COMMAND ----------

# MAGIC %md
# MAGIC ### Deal IDs Only in Target Table (Not in Source)

# COMMAND ----------

# Find deal_ids that are only in target table and not in source table
target_only_deals = spark.sql(f"""
    SELECT 
        t.`AOS Deal ID` as AOS_Deal_ID,
        t.`Total Delivered Impressions` as `Target Total Delivered Impressions`,
        t.`Total Delivered Revenue` as `Target Total Delivered Revenue`,
        t.`Total Delivered Clicks` as `Target Total Delivered Clicks`
    FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal t
    WHERE t.`AOS Deal ID` IS NOT NULL
        AND t.`AOS Deal ID` != -1
        AND NOT EXISTS (
            SELECT 1
            FROM {catalog_name}.gold_ad_sales.wrap_detailed_unified_report_sections_by_deal s
            WHERE s.AOS_Deal_ID = t.`AOS Deal ID`
                AND s.data_type = 'DEVICE_AD_POSITION_MATRIX'
        )
    ORDER BY t.`AOS Deal ID`
""")

print("=" * 80)
print(f"Deal IDs only in v_ft_unified_campaign_delivery_by_deal Table (not in source)")
print(f"Count: {target_only_deals.count()}")
print("=" * 80)

display(target_only_deals)


# COMMAND ----------

# MAGIC %md
# MAGIC ### Update mismatch_details_df: Mark missing deals from target_only_deals

# COMMAND ----------

# Update mismatch_details_df to include deals from target_only_deals with Status = "missing deals"
# First, convert Status to string in mismatch_details_df
mismatch_details_df_1 = mismatch_details_df.withColumn(
    "Status",
    when(col("Status") == True, lit("True"))
    .when(col("Status") == False, lit("False"))
    .otherwise(col("Status").cast("string"))
)

# Create a dataframe for missing deals with the same structure as mismatch_details_df
missing_deals_df = target_only_deals.select(
    col("AOS_Deal_ID").alias("deal_id"),
    lit("missing deals").cast("string").alias("Status"),
    lit("Deal not found in source table").cast("string").alias("Mismatched_Columns")
)

display(missing_deals_df)
display(mismatch_details_df_1)

# Option 1: Use a broadcast join with a flag, then check if deal_id exists in target_only_deals
from pyspark.sql.functions import broadcast

# Create a set of deal_ids from target_only_deals for efficient lookup
target_only_deal_ids = target_only_deals.select(col("AOS_Deal_ID").alias("deal_id")).distinct()

# Join and check if deal_id exists in target_only_deals
mismatch_details_df_1 = mismatch_details_df_1.join(
    broadcast(target_only_deal_ids).withColumn("is_target_only", lit(True)),
    on="deal_id",
    how="left"
).withColumn(
    "Status",
    when(col("is_target_only").isNotNull(), lit("not found in source").cast("string"))
    .otherwise(col("Status").cast("string"))
).select(
    col("deal_id"),
    col("Status").cast("string").alias("Status"),
    col("Mismatched_Columns")
)

display(mismatch_details_df_1)


# Create a dataframe with deal_id and DEVICE_AD_POSITION_MATRIX (True if Status is True, False otherwise)
deal_status_df_dapm = mismatch_details_df_1.withColumn(
    "DEVICE_AD_POSITION_MATRIX",
    when(col("Status") == "True", lit(True))
    .when(col("Status") == "False", lit(False))
    .otherwise(lit(False))
).select(
    col("deal_id"),
    col("DEVICE_AD_POSITION_MATRIX")
).distinct()

print("=" * 80)
print(f"Deal Status Summary")
print(f"Total Deals: {deal_status_df_dapm.count()}")
print(f"Deals with DEVICE_AD_POSITION_MATRIX = True: {deal_status_df_dapm.filter(col('DEVICE_AD_POSITION_MATRIX') == True).count()}")
print(f"Deals with DEVICE_AD_POSITION_MATRIX = False: {deal_status_df_dapm.filter(col('DEVICE_AD_POSITION_MATRIX') == False).count()}")
print("=" * 80)

display(deal_status_df_dapm)

# COMMAND ----------

# MAGIC %md
# MAGIC # Parse for DEAL_AD_UNITS_PERFORMANCE Validation
# MAGIC

# COMMAND ----------

# Databricks notebook Target
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from datetime import datetime, date
import os
import pandas as pd

# COMMAND ----------

# Configuration
catalog_name = 'fox_bi_qa'
env = 'dev'  # or 'qa' or 'prod'

# COMMAND ----------

# MAGIC %md
# MAGIC ## Validation: wrap_detailed_unified_report_sections_by_deal vs ft_unified_campaign_delivery_by_deal
# MAGIC
# MAGIC This validation compares:
# MAGIC - Target: Sum of field10 from wrap_detailed_unified_report_sections_by_deal (for DEAL_AD_UNITS_PERFORMANCE data_type)
# MAGIC - Target: Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
# MAGIC
# MAGIC For each aos_deal_id

# COMMAND ----------

# MAGIC %md
# MAGIC ### Target Data: wrap_detailed_unified_report_sections_by_deal

# COMMAND ----------

# Target: Aggregate field10 from wrap_detailed_unified_report_sections_by_deal
# Filter for DEAL_AD_UNITS_PERFORMANCE data_type and sum field10 (which contains Total_Delivered_Impressions as string)
tar_df = spark.sql(f"""
    SELECT 
        AOS_Deal_ID,
        SUM(try_cast(field5 AS BIGINT)) as `Target Total Creatives`,
        SUM(try_cast(field2 AS BIGINT)) as `Target Total Delivered Impressions`,
        SUM(try_cast(field3 AS DECIMAL(19,2))) as `Target Total Delivered Revenue`
    FROM {catalog_name}.gold_ad_sales.wrap_detailed_unified_report_sections_by_deal
    WHERE data_type = 'DEAL_AD_UNITS_PERFORMANCE'
    GROUP BY AOS_Deal_ID
""")

display(tar_df)



# COMMAND ----------

# MAGIC %md
# MAGIC ### Source Data: ft_unified_campaign_delivery_by_deal

# COMMAND ----------

# Source: Get Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
src_df = spark.sql(f"""
    SELECT 
        `AOS Deal ID` as AOS_Deal_ID,
        `Total Creatives` as `Source Total Creatives`,
        `Total Delivered Impressions` as `Source Total Delivered Impressions`,
        `Total Delivered Revenue` as `Source Total Delivered Revenue`
    FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal
    WHERE `AOS Deal ID` IS NOT NULL
        AND `AOS Deal ID` != -1
""")

display(src_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Validation Comparison

# COMMAND ----------

from pyspark.sql.functions import col, when, expr, nvl, abs, lit, array, concat_ws

# Join source and target on AOS_Deal_ID
joined_df = src_df.join(
    tar_df,
    on="AOS_Deal_ID",
    how="full_outer"
)

display(joined_df)


# Add comparison columns - only for the columns that exist
validation_df = joined_df.withColumn(
    "Source_Total_Creatives",
    nvl(col("`Source Total Creatives`"), lit(0))
).withColumn(
    "Target_Total_Creatives",
    nvl(col("`Target Total Creatives`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Impressions",
    nvl(col("`Source Total Delivered Impressions`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Impressions",
    nvl(col("`Target Total Delivered Impressions`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Revenue",
    nvl(col("`Source Total Delivered Revenue`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Revenue",
    nvl(col("`Target Total Delivered Revenue`"), lit(0))
).withColumn(
    "Variance_Creatives",
    col("Source_Total_Creatives") - col("Target_Total_Creatives")
).withColumn(
    "Variance_Impressions",
    col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")
).withColumn(
    "Variance_Revenue",
    col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")
).withColumn(
    "Creatives_Match",
    when(
        abs(col("Source_Total_Creatives") - col("Target_Total_Creatives")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Impressions_Match",
    when(
        abs(col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Revenue_Match",
    when(
        abs(col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Status",
    when(
        (col("Creatives_Match") == True) &
        (col("Impressions_Match") == True) &
        (col("Revenue_Match") == True),
        True
    ).otherwise(False)
).select(
    col("AOS_Deal_ID"),
    col("Source_Total_Creatives"),
    col("Target_Total_Creatives"),
    col("Variance_Creatives"),
    col("Creatives_Match"),
    col("Source_Total_Delivered_Impressions"),
    col("Target_Total_Delivered_Impressions"),
    col("Variance_Impressions"),
    col("Impressions_Match"),
    col("Source_Total_Delivered_Revenue"),
    col("Target_Total_Delivered_Revenue"),
    col("Variance_Revenue"),
    col("Revenue_Match"),
    col("Status")
)

display(validation_df)



# Create a dataframe showing which columns have mismatches for deals where Status is False
mismatch_details_df = validation_df.withColumn(
    "Mismatched_Columns_Array",
    array(
        when(col("Creatives_Match") == False, lit("Creatives")).otherwise(lit(None)),
        when(col("Impressions_Match") == False, lit("Impressions")).otherwise(lit(None)),
        when(col("Revenue_Match") == False, lit("Revenue")).otherwise(lit(None))
    )
).withColumn(
    "Mismatched_Columns_Array",
    expr("filter(Mismatched_Columns_Array, x -> x is not null)")
).withColumn(
    "Mismatched_Columns",
    concat_ws(", ", col("Mismatched_Columns_Array"))
).select(
    col("AOS_Deal_ID").alias("deal_id"),
    col("Status"),
    col("Mismatched_Columns")
).distinct()

print("=" * 80)
print(f"Deal Mismatch Details")
print(f"Total Deals with Mismatches: {mismatch_details_df.filter(col('Status') == False).count()}")
print("=" * 80)

display(mismatch_details_df)




# COMMAND ----------

# MAGIC %md
# MAGIC ### Deal IDs Only in Target Table (Not in Source)

# COMMAND ----------

# Find deal_ids that are only in target table and not in source table
target_only_deals = spark.sql(f"""
    SELECT 
        t.`AOS Deal ID` as AOS_Deal_ID,
        t.`Total Creatives` as `Target Total Creatives`,
        t.`Total Delivered Impressions` as `Target Total Delivered Impressions`,
        t.`Total Delivered Revenue` as `Target Total Delivered Revenue`
    FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal t
    WHERE t.`AOS Deal ID` IS NOT NULL
        AND t.`AOS Deal ID` != -1
        AND NOT EXISTS (
            SELECT 1
            FROM {catalog_name}.gold_ad_sales.wrap_detailed_unified_report_sections_by_deal s
            WHERE s.AOS_Deal_ID = t.`AOS Deal ID`
                AND s.data_type = 'DEAL_AD_UNITS_PERFORMANCE'
        )
    ORDER BY t.`AOS Deal ID`
""")

print("=" * 80)
print(f"Deal IDs only in v_ft_unified_campaign_delivery_by_deal Table (v_ft_unified_campaign_delivery_by_deal)")
print(f"Count: {target_only_deals.count()}")
print("=" * 80)

display(target_only_deals)




# COMMAND ----------

# MAGIC %md
# MAGIC ### Update mismatch_details_df: Mark missing deals from target_only_deals

# COMMAND ----------

# Update mismatch_details_df to include deals from target_only_deals with Status = "missing deals"
# First, convert Status to string in mismatch_details_df to allow "missing deals" value
mismatch_details_df_1 = mismatch_details_df.withColumn(
    "Status",
    when(col("Status") == True, lit("True"))
    .when(col("Status") == False, lit("False"))
    .otherwise(col("Status").cast("string"))
)

# Create a dataframe for missing deals with the same structure as mismatch_details_df
missing_deals_df = target_only_deals.select(
    col("AOS_Deal_ID").alias("deal_id"),
    lit("missing deals").alias("Status"),
    lit("Deal not found in source table").alias("Mismatched_Columns")
)

display(missing_deals_df)

display(mismatch_details_df_1)

# Option 1: Use a broadcast join with a flag, then check if deal_id exists in target_only_deals
from pyspark.sql.functions import broadcast

# Create a set of deal_ids from target_only_deals for efficient lookup
target_only_deal_ids = target_only_deals.select(col("AOS_Deal_ID").alias("deal_id")).distinct()

# Join and check if deal_id exists in target_only_deals
mismatch_details_df_1 = mismatch_details_df_1.join(
    broadcast(target_only_deal_ids).withColumn("is_target_only", lit(True)),
    on="deal_id",
    how="left"
).withColumn(
    "Status",
    when(col("is_target_only").isNotNull(), lit("not found in source").cast("string"))
    .otherwise(col("Status").cast("string"))
).select(
    col("deal_id"),
    col("Status").cast("string").alias("Status"),
    col("Mismatched_Columns")
)

# Union with missing_deals_df to include all deals that are only in target table
mismatch_details_df_1 = mismatch_details_df_1.unionByName(
    missing_deals_df,
    allowMissingColumns=True
).distinct()

display(mismatch_details_df_1)



# Create a dataframe with deal_id and DEAL_AD_UNITS_PERFORMANCE (True if Status is True, False otherwise)
deal_status_df_daup = mismatch_details_df_1.select(
    col("deal_id"),
    when(col("Status") == "True", lit(True))
    .when(col("Status") == "False", lit(False))
    .otherwise(lit(False))
    .alias("DEAL_AD_UNITS_PERFORMANCE")
).distinct()

print("=" * 80)
print(f"Deal Status Summary")
print(f"Total Deals: {deal_status_df_daup.count()}")
print(f"Deals with DEAL_AD_UNITS_PERFORMANCE = True: {deal_status_df_daup.filter(col('DEAL_AD_UNITS_PERFORMANCE') == True).count()}")
print(f"Deals with DEAL_AD_UNITS_PERFORMANCE = False: {deal_status_df_daup.filter(col('DEAL_AD_UNITS_PERFORMANCE') == False).count()}")
print("=" * 80)

display(deal_status_df_daup)

# COMMAND ----------

# MAGIC %md
# MAGIC # Parse for DEMO_BAND_PERFORMANCE Validation
# MAGIC

# COMMAND ----------

# Databricks notebook Target
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from datetime import datetime, date
import os
import pandas as pd

# COMMAND ----------

# Configuration
catalog_name = 'fox_bi_qa'
env = 'dev'  # or 'qa' or 'prod'

# COMMAND ----------

# MAGIC %md
# MAGIC ## Validation: wrap_detailed_unified_report_sections_by_deal vs ft_unified_campaign_delivery_by_deal
# MAGIC
# MAGIC This validation compares:
# MAGIC - Target: Sum of field10 from wrap_detailed_unified_report_sections_by_deal (for DEMO_BAND_PERFORMANCE data_type)
# MAGIC - Target: Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
# MAGIC
# MAGIC For each aos_deal_id

# COMMAND ----------

# MAGIC %md
# MAGIC ### Target Data: wrap_detailed_unified_report_sections_by_deal

# COMMAND ----------

# Target: Aggregate field10 from wrap_detailed_unified_report_sections_by_deal
# Filter for DEMO_BAND_PERFORMANCE data_type and sum field10 (which contains Total_Delivered_Impressions as string)
tar_df = spark.sql(f"""
    SELECT 
        AOS_Deal_ID,
        SUM(try_cast(field3 AS BIGINT)) as `Target Total Placements`,
        SUM(try_cast(field2 AS BIGINT)) as `Target Total Delivered Impressions`
    FROM {catalog_name}.gold_ad_sales.wrap_detailed_unified_report_sections_by_deal
    WHERE data_type = 'DEMO_BAND_PERFORMANCE'
    GROUP BY AOS_Deal_ID
""")

display(tar_df)



# COMMAND ----------

# MAGIC %md
# MAGIC ### Source Data: ft_unified_campaign_delivery_by_deal

# COMMAND ----------

# Source: Get Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
src_df = spark.sql(f"""
    SELECT 
        `AOS Deal ID` as AOS_Deal_ID,
        `Total Placements` as `Source Total Placements`,
        `Total Delivered Impressions` as `Source Total Delivered Impressions`
    FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal
    WHERE `AOS Deal ID` IS NOT NULL
        AND `AOS Deal ID` != -1
""")

display(src_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Validation Comparison

# COMMAND ----------

from pyspark.sql.functions import col, when, expr, nvl, abs, lit, array, concat_ws

# Join source and target on AOS_Deal_ID
joined_df = src_df.join(
    tar_df,
    on="AOS_Deal_ID",
    how="full_outer"
)

display(joined_df)


# Add comparison columns - only for columns that exist
validation_df = joined_df.withColumn(
    "Source_Total_Placements",
    nvl(col("`Source Total Placements`"), lit(0))
).withColumn(
    "Target_Total_Placements",
    nvl(col("`Target Total Placements`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Impressions",
    nvl(col("`Source Total Delivered Impressions`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Impressions",
    nvl(col("`Target Total Delivered Impressions`"), lit(0))
).withColumn(
    "Variance_Placements",
    col("Source_Total_Placements") - col("Target_Total_Placements")
).withColumn(
    "Variance_Impressions",
    col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")
).withColumn(
    "Placements_Match",
    when(
        abs(col("Source_Total_Placements") - col("Target_Total_Placements")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Impressions_Match",
    when(
        abs(col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Status",
    when(
        (col("Placements_Match") == True) &
        (col("Impressions_Match") == True),
        True
    ).otherwise(False)
).select(
    col("AOS_Deal_ID"),
    col("Source_Total_Placements"),
    col("Target_Total_Placements"),
    col("Variance_Placements"),
    col("Placements_Match"),
    col("Source_Total_Delivered_Impressions"),
    col("Target_Total_Delivered_Impressions"),
    col("Variance_Impressions"),
    col("Impressions_Match"),
    col("Status")
)

display(validation_df)


# Create a dataframe showing which columns have mismatches for deals where Status is False
mismatch_details_df = validation_df.withColumn(
    "Mismatched_Columns_Array",
    array(
        when(col("Placements_Match") == False, lit("Placements")).otherwise(lit(None)),
        when(col("Impressions_Match") == False, lit("Impressions")).otherwise(lit(None))
    )
).withColumn(
    "Mismatched_Columns_Array",
    expr("filter(Mismatched_Columns_Array, x -> x is not null)")
).withColumn(
    "Mismatched_Columns",
    concat_ws(", ", col("Mismatched_Columns_Array"))
).select(
    col("AOS_Deal_ID").alias("deal_id"),
    col("Status"),
    col("Mismatched_Columns")
).distinct()

print("=" * 80)
print(f"Deal Mismatch Details")
print(f"Total Deals with Mismatches: {mismatch_details_df.filter(col('Status') == False).count()}")
print("=" * 80)

display(mismatch_details_df)


# COMMAND ----------

# MAGIC %md
# MAGIC ### Deal IDs Only in Target Table (Not in Source)

# COMMAND ----------

# Find deal_ids that are only in target table and not in source table
target_only_deals = spark.sql(f"""
    SELECT 
        t.`AOS Deal ID` as AOS_Deal_ID,
        t.`Total Placements` as `Target Total Placements`,
        t.`Total Delivered Impressions` as `Target Total Delivered Impressions`
    FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal t
    WHERE t.`AOS Deal ID` IS NOT NULL
        AND t.`AOS Deal ID` != -1
        AND NOT EXISTS (
            SELECT 1
            FROM {catalog_name}.gold_ad_sales.wrap_detailed_unified_report_sections_by_deal s
            WHERE s.AOS_Deal_ID = t.`AOS Deal ID`
                AND s.data_type = 'DEMO_BAND_PERFORMANCE'
        )
    ORDER BY t.`AOS Deal ID`
""")

print("=" * 80)
print(f"Deal IDs only in v_ft_unified_campaign_delivery_by_deal Table (v_ft_unified_campaign_delivery_by_deal)")
print(f"Count: {target_only_deals.count()}")
print("=" * 80)

display(target_only_deals)


# COMMAND ----------

# MAGIC %md
# MAGIC ### Update mismatch_details_df: Mark missing deals from target_only_deals

# COMMAND ----------

# Update mismatch_details_df to include deals from target_only_deals with Status = "missing deals"
# First, convert Status to string in mismatch_details_df to allow "missing deals" value
mismatch_details_df_1 = mismatch_details_df.withColumn(
    "Status",
    when(col("Status") == True, lit("True"))
    .when(col("Status") == False, lit("False"))
    .otherwise(col("Status").cast("string"))
)

# Create a dataframe for missing deals with the same structure as mismatch_details_df
missing_deals_df = target_only_deals.select(
    col("AOS_Deal_ID").alias("deal_id"),
    lit("missing deals").alias("Status"),
    lit("Deal not found in source table").alias("Mismatched_Columns")
)

display(missing_deals_df)
display(mismatch_details_df_1)

# Option 1: Use a broadcast join with a flag, then check if deal_id exists in target_only_deals
from pyspark.sql.functions import broadcast

# Create a set of deal_ids from target_only_deals for efficient lookup
target_only_deal_ids = target_only_deals.select(col("AOS_Deal_ID").alias("deal_id")).distinct()

# Join and check if deal_id exists in target_only_deals
mismatch_details_df_1 = mismatch_details_df_1.join(
    broadcast(target_only_deal_ids).withColumn("is_target_only", lit(True)),
    on="deal_id",
    how="left"
).withColumn(
    "Status",
    when(col("is_target_only").isNotNull(), lit("not found in source").cast("string"))
    .otherwise(col("Status").cast("string"))
).select(
    col("deal_id"),
    col("Status").cast("string").alias("Status"),
    col("Mismatched_Columns")
)

display(mismatch_details_df_1)


# Create a dataframe with deal_id and DEMO_BAND_PERFORMANCE (True if Status is True, False otherwise)
deal_status_df_dbp = mismatch_details_df_1.withColumn(
    "DEMO_BAND_PERFORMANCE",
    when(col("Status") == "True", lit(True))
    .otherwise(lit(False))
).select(
    col("deal_id"),
    col("DEMO_BAND_PERFORMANCE")
).distinct()

print("=" * 80)
print(f"Deal Status Summary")
print(f"Total Deals: {deal_status_df_dbp.count()}")
print(f"Deals with DEMO_BAND_PERFORMANCE = True: {deal_status_df_dbp.filter(col('DEMO_BAND_PERFORMANCE') == True).count()}")
print(f"Deals with DEMO_BAND_PERFORMANCE = False: {deal_status_df_dbp.filter(col('DEMO_BAND_PERFORMANCE') == False).count()}")
print("=" * 80)

display(deal_status_df_dbp)

# COMMAND ----------

# MAGIC %md
# MAGIC # Parse for PACKAGE_PERFORMANCE Validation
# MAGIC

# COMMAND ----------

# Databricks notebook Target
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from datetime import datetime, date
import os
import pandas as pd

# COMMAND ----------

# Configuration
catalog_name = 'fox_bi_qa'
env = 'dev'  # or 'qa' or 'prod'

# COMMAND ----------

# MAGIC %md
# MAGIC ## Validation: wrap_detailed_unified_report_sections_by_deal vs ft_unified_campaign_delivery_by_deal
# MAGIC
# MAGIC This validation compares:
# MAGIC - Target: Sum of field10 from wrap_detailed_unified_report_sections_by_deal (for PACKAGE_PERFORMANCE data_type)
# MAGIC - Target: Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
# MAGIC
# MAGIC For each aos_deal_id

# COMMAND ----------

# MAGIC %md
# MAGIC ### Target Data: wrap_detailed_unified_report_sections_by_deal

# COMMAND ----------

# Target: Aggregate field10 from wrap_detailed_unified_report_sections_by_deal
# Filter for PACKAGE_PERFORMANCE data_type and sum field10 (which contains Total_Delivered_Impressions as string)
tar_df = spark.sql(f"""
    SELECT 
        AOS_Deal_ID,
        SUM(try_cast(field2 AS BIGINT)) as `Target Total Delivered Impressions`,
        SUM(try_cast(field3 AS DECIMAL(19,2))) as `Target Total Delivered Revenue`,
        SUM(try_cast(field7 AS BIGINT)) as `Target Total Guaranteed Impressions`,
        SUM(try_cast(field8 AS DECIMAL(19,2))) as `Target Total Guaranteed Revenue`,
        SUM(try_cast(field5 AS BIGINT)) as `Target Total Third Party Impressions`,
        SUM(try_cast(field6 AS DECIMAL(19,2))) as `Target Total Third Party Revenue`
    FROM {catalog_name}.gold_ad_sales.wrap_detailed_unified_report_sections_by_deal
    WHERE data_type = 'PACKAGE_PERFORMANCE'
    GROUP BY AOS_Deal_ID, field2, field3, field4, field5, field6
""")

display(tar_df)



# COMMAND ----------

# MAGIC %md
# MAGIC ### Source Data: ft_unified_campaign_delivery_by_deal

# COMMAND ----------

# Source: Get Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
src_df = spark.sql(f"""
    SELECT 
        `AOS Deal ID` as AOS_Deal_ID,
        `Total Delivered Impressions` as `Source Total Delivered Impressions`,
        `Total Delivered Revenue` as `Source Total Delivered Revenue`,
        `Total Guaranteed Impressions` as `Source Total Guaranteed Impressions`,
        `Budget` as `Source Total Guaranteed Revenue`,
        `Total Third Party Impressions` as `Source Total Third Party Impressions`,
        `Total Third Party Revenue` as `Source Total Third Party Revenue`
    FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal
    WHERE `AOS Deal ID` IS NOT NULL
        AND `AOS Deal ID` != -1
""")

display(src_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Validation Comparison

# COMMAND ----------

from pyspark.sql.functions import col, when, expr, nvl, abs, lit, array, concat_ws

# Join source and target on AOS_Deal_ID
joined_df = src_df.join(
    tar_df,
    on="AOS_Deal_ID",
    how="full_outer"
)

display(joined_df)


# Add comparison columns - only for columns that exist in both dataframes
validation_df = joined_df.withColumn(
    "Source_Total_Delivered_Impressions",
    nvl(col("`Source Total Delivered Impressions`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Impressions",
    nvl(col("`Target Total Delivered Impressions`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Revenue",
    nvl(col("`Source Total Delivered Revenue`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Revenue",
    nvl(col("`Target Total Delivered Revenue`"), lit(0))
).withColumn(
    "Source_Total_Guaranteed_Impressions",
    nvl(col("`Source Total Guaranteed Impressions`"), lit(0))
).withColumn(
    "Target_Total_Guaranteed_Impressions",
    nvl(col("`Target Total Guaranteed Impressions`"), lit(0))
).withColumn(
    "Source_Total_Guaranteed_Revenue",
    nvl(col("`Source Total Guaranteed Revenue`"), lit(0))
).withColumn(
    "Target_Total_Guaranteed_Revenue",
    nvl(col("`Target Total Guaranteed Revenue`"), lit(0))
).withColumn(
    "Source_Total_Third_Party_Impressions",
    nvl(col("`Source Total Third Party Impressions`"), lit(0))
).withColumn(
    "Target_Total_Third_Party_Impressions",
    nvl(col("`Target Total Third Party Impressions`"), lit(0))
).withColumn(
    "Source_Total_Third_Party_Revenue",
    nvl(col("`Source Total Third Party Revenue`"), lit(0))
).withColumn(
    "Target_Total_Third_Party_Revenue",
    nvl(col("`Target Total Third Party Revenue`"), lit(0))
).withColumn(
    "Variance_Delivered_Impressions",
    col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")
).withColumn(
    "Variance_Delivered_Revenue",
    col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")
).withColumn(
    "Variance_Guaranteed_Impressions",
    col("Source_Total_Guaranteed_Impressions") - col("Target_Total_Guaranteed_Impressions")
).withColumn(
    "Variance_Guaranteed_Revenue",
    col("Source_Total_Guaranteed_Revenue") - col("Target_Total_Guaranteed_Revenue")
).withColumn(
    "Variance_Total_Third_Party_Impressions",
    col("Source_Total_Third_Party_Impressions") - col("Target_Total_Third_Party_Impressions")
).withColumn(
    "Variance_Total_Third_Party_Revenue",
    col("Source_Total_Third_Party_Revenue") - col("Target_Total_Third_Party_Revenue")
).withColumn(
    "Delivered_Impressions_Match",
    when(
        abs(col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Delivered_Revenue_Match",
    when(
        abs(col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")) <= 0.01,
        True
    ).otherwise(False)
).withColumn(
    "Guaranteed_Impressions_Match",
    when(
        abs(col("Source_Total_Guaranteed_Impressions") - col("Target_Total_Guaranteed_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Guaranteed_Revenue_Match",
    when(
        abs(col("Source_Total_Guaranteed_Revenue") - col("Target_Total_Guaranteed_Revenue")) <= 0.01,
        True
    ).otherwise(False)
).withColumn(
    "Total_Third_Party_Impressions_Match",
    when(
        abs(col("Source_Total_Third_Party_Impressions") - col("Target_Total_Third_Party_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Total_Third_Party_Revenue_Match",
    when(
        abs(col("Source_Total_Third_Party_Revenue") - col("Target_Total_Third_Party_Revenue")) <= 0.01,
        True
    ).otherwise(False)
).withColumn(
    "Status",
    when(
        (col("Delivered_Impressions_Match") == True) &
        (col("Delivered_Revenue_Match") == True) &
        (col("Guaranteed_Impressions_Match") == True) &
        (col("Guaranteed_Revenue_Match") == True) &
        (col("Total_Third_Party_Impressions_Match") == True) &
        (col("Total_Third_Party_Revenue_Match") == True),
        True
    ).otherwise(False)
).select(
    col("AOS_Deal_ID"),
    col("Source_Total_Delivered_Impressions"),
    col("Target_Total_Delivered_Impressions"),
    col("Variance_Delivered_Impressions"),
    col("Delivered_Impressions_Match"),
    col("Source_Total_Delivered_Revenue"),
    col("Target_Total_Delivered_Revenue"),
    col("Variance_Delivered_Revenue"),
    col("Delivered_Revenue_Match"),
    col("Source_Total_Guaranteed_Impressions"),
    col("Target_Total_Guaranteed_Impressions"),
    col("Variance_Guaranteed_Impressions"),
    col("Guaranteed_Impressions_Match"),
    col("Source_Total_Guaranteed_Revenue"),
    col("Target_Total_Guaranteed_Revenue"),
    col("Variance_Guaranteed_Revenue"),
    col("Guaranteed_Revenue_Match"),
    col("Source_Total_Third_Party_Impressions"),
    col("Target_Total_Third_Party_Impressions"),
    col("Variance_Total_Third_Party_Impressions"),
    col("Total_Third_Party_Impressions_Match"),
    col("Source_Total_Third_Party_Revenue"),
    col("Target_Total_Third_Party_Revenue"),
    col("Variance_Total_Third_Party_Revenue"),
    col("Total_Third_Party_Revenue_Match"),
    col("Status")
)

display(validation_df)


# Create a dataframe showing which columns have mismatches for deals where Status is False
mismatch_details_df = validation_df.filter(
    col("Status") == False
).withColumn(
    "Mismatched_Columns_Array",
    array(
        when(col("Delivered_Impressions_Match") == False, lit("Delivered_Impressions")).otherwise(lit(None)),
        when(col("Delivered_Revenue_Match") == False, lit("Delivered_Revenue")).otherwise(lit(None)),
        when(col("Guaranteed_Impressions_Match") == False, lit("Guaranteed_Impressions")).otherwise(lit(None)),
        when(col("Guaranteed_Revenue_Match") == False, lit("Guaranteed_Revenue")).otherwise(lit(None)),
        when(col("Total_Third_Party_Impressions_Match") == False, lit("Total_Third_Party_Impressions")).otherwise(lit(None)),
        when(col("Total_Third_Party_Revenue_Match") == False, lit("Total_Third_Party_Revenue")).otherwise(lit(None))
    )
).withColumn(
    "Mismatched_Columns_Array",
    expr("filter(Mismatched_Columns_Array, x -> x is not null)")
).withColumn(
    "Mismatched_Columns",
    concat_ws(", ", col("Mismatched_Columns_Array"))
).select(
    col("AOS_Deal_ID").alias("deal_id"),
    when(col("Status") == True, lit("True"))
    .when(col("Status") == False, lit("False"))
    .otherwise(lit("False")).cast("string").alias("Status"),
    col("Mismatched_Columns")
).distinct()

print("=" * 80)
print(f"Deal Mismatch Details")
print(f"Total Deals with Mismatches: {mismatch_details_df.count()}")
print("=" * 80)

display(mismatch_details_df)


# COMMAND ----------

# MAGIC %md
# MAGIC ### Deal IDs Only in Target Table (Not in Source)

# COMMAND ----------

# Find deal_ids that are only in target table and not in source table
target_only_deals = spark.sql(f"""
    SELECT 
        t.`AOS Deal ID` as AOS_Deal_ID,
        t.`Total Delivered Impressions` as `Target Total Delivered Impressions`,
        t.`Total Delivered Revenue` as `Target Total Delivered Revenue`,
        t.`Total Guaranteed Impressions` as `Target Total Guaranteed Impressions`,
        t.`Budget` as `Target Total Guaranteed Revenue`,
        t.`Total Third Party Impressions` as `Target Total Third Party Impressions`,
        t.`Total Third Party Revenue` as `Target Total Third Party Revenue`
    FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal t
    WHERE t.`AOS Deal ID` IS NOT NULL
        AND t.`AOS Deal ID` != -1
        AND NOT EXISTS (
            SELECT 1
            FROM {catalog_name}.gold_ad_sales.wrap_detailed_unified_report_sections_by_deal s
            WHERE s.AOS_Deal_ID = t.`AOS Deal ID`
                AND s.data_type = 'PACKAGE_PERFORMANCE'
        )
    ORDER BY t.`AOS Deal ID`
""")

print("=" * 80)
print(f"Deal IDs only in v_ft_unified_campaign_delivery_by_deal Table (v_ft_unified_campaign_delivery_by_deal)")
print(f"Count: {target_only_deals.count()}")
print("=" * 80)

display(target_only_deals)


# COMMAND ----------

# MAGIC %md
# MAGIC ### Update mismatch_details_df: Mark missing deals from target_only_deals

# COMMAND ----------

# Update mismatch_details_df to include deals from target_only_deals with Status = "missing deals"
# First, convert Status to string in mismatch_details_df to allow "missing deals" value
mismatch_details_df_1 = mismatch_details_df.withColumn(
    "Status",
    when(col("Status") == True, lit("True"))
    .when(col("Status") == False, lit("False"))
    .otherwise(col("Status").cast("string"))
)

# Create a dataframe for missing deals with the same structure as mismatch_details_df
missing_deals_df = target_only_deals.select(
    col("AOS_Deal_ID").alias("deal_id"),
    lit("missing deals").cast("string").alias("Status"),
    lit("Deal not found in source table").cast("string").alias("Mismatched_Columns")
)

display(missing_deals_df)
display(mismatch_details_df_1)

# Option 1: Use a broadcast join with a flag, then check if deal_id exists in target_only_deals
from pyspark.sql.functions import broadcast

# Create a set of deal_ids from target_only_deals for efficient lookup
target_only_deal_ids = target_only_deals.select(col("AOS_Deal_ID").alias("deal_id")).distinct()

# Join and check if deal_id exists in target_only_deals
mismatch_details_df_1 = mismatch_details_df_1.join(
    broadcast(target_only_deal_ids).withColumn("is_target_only", lit(True)),
    on="deal_id",
    how="left"
).withColumn(
    "Status",
    when(col("is_target_only").isNotNull(), lit("not found in source").cast("string"))
    .otherwise(col("Status").cast("string"))
).select(
    col("deal_id"),
    col("Status").cast("string").alias("Status"),
    col("Mismatched_Columns")
)

display(mismatch_details_df_1)


# Create a dataframe with deal_id and PACKAGE_PERFORMANCE (True if Status is True, False otherwise)
deal_status_df_pp = mismatch_details_df_1.select(
    col("deal_id"),
    when(col("Status") == "True", lit(True))
    .when(col("Status") == "False", lit(False))
    .otherwise(lit(False))
    .alias("PACKAGE_PERFORMANCE")
).distinct()

print("=" * 80)
print(f"Deal Status Summary")
print(f"Total Deals: {deal_status_df_pp.count()}")
print(f"Deals with PACKAGE_PERFORMANCE = True: {deal_status_df_pp.filter(col('PACKAGE_PERFORMANCE') == True).count()}")
print(f"Deals with PACKAGE_PERFORMANCE = False: {deal_status_df_pp.filter(col('PACKAGE_PERFORMANCE') == False).count()}")
print("=" * 80)

display(deal_status_df_pp)

# COMMAND ----------

# MAGIC %md
# MAGIC # Parse for CONTENT_PERFORMANCE Validation
# MAGIC

# COMMAND ----------

# Databricks notebook Target
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from datetime import datetime, date
import os
import pandas as pd

# COMMAND ----------

# Configuration
catalog_name = 'fox_bi_qa'
env = 'dev'  # or 'qa' or 'prod'

# COMMAND ----------

# MAGIC %md
# MAGIC ## Validation: wrap_detailed_unified_report_sections_by_deal vs ft_unified_campaign_delivery_by_deal
# MAGIC
# MAGIC This validation compares:
# MAGIC - Target: Sum of field10 from wrap_detailed_unified_report_sections_by_deal (for CONTENT_PERFORMANCE data_type)
# MAGIC - Target: Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
# MAGIC
# MAGIC For each aos_deal_id

# COMMAND ----------

# MAGIC %md
# MAGIC ### Target Data: wrap_detailed_unified_report_sections_by_deal

# COMMAND ----------

# Target: Aggregate field10 from wrap_detailed_unified_report_sections_by_deal
# Filter for CONTENT_PERFORMANCE data_type and sum field10 (which contains Total_Delivered_Impressions as string)
tar_df = spark.sql(f"""
    SELECT 
        AOS_Deal_ID,
        -- SUM(try_cast(field2 AS VARCHAR(100))) as `Target Total Shows`,
        size(collect_list(field2)) as `Target Total Shows`, 
        -- field2 as `Target Total Shows`,        
        SUM(try_cast(field3 AS BIGINT)) as `Target Total Delivered Impressions`,
        SUM(try_cast(field4 AS DECIMAL(19,2))) as `Target Total Delivered Revenue`
    FROM {catalog_name}.gold_ad_sales.wrap_detailed_unified_report_sections_by_deal
    WHERE data_type = 'CONTENT_PERFORMANCE'
    GROUP BY AOS_Deal_ID
""")

display(tar_df)



# COMMAND ----------

# MAGIC %md
# MAGIC ### Source Data: ft_unified_campaign_delivery_by_deal

# COMMAND ----------

# Source: Get Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
src_df = spark.sql(f"""
    SELECT 
        `AOS Deal ID` as AOS_Deal_ID,
        `Total Shows` as `Source Total Shows`,
        `Total Delivered Impressions` as `Source Total Delivered Impressions`,
        `Total Delivered Revenue` as `Source Total Delivered Revenue`
    FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal
    WHERE `AOS Deal ID` IS NOT NULL
        AND `AOS Deal ID` != -1
""")

display(src_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Validation Comparison

# COMMAND ----------

from pyspark.sql.functions import col, when, expr, nvl, abs, lit, array, concat_ws

# Join source and target on AOS_Deal_ID
joined_df = src_df.join(
    tar_df,
    on="AOS_Deal_ID",
    how="full_outer"
)

display(joined_df)


# Add comparison columns - only for the columns that exist in src_df and tar_df
validation_df = joined_df.withColumn(
    "Source_Total_Shows",
    nvl(col("`Source Total Shows`"), lit(0))
).withColumn(
    "Target_Total_Shows",
    nvl(col("`Target Total Shows`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Impressions",
    nvl(col("`Source Total Delivered Impressions`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Impressions",
    nvl(col("`Target Total Delivered Impressions`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Revenue",
    nvl(col("`Source Total Delivered Revenue`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Revenue",
    nvl(col("`Target Total Delivered Revenue`"), lit(0))
).withColumn(
    "Variance_Shows",
    col("Source_Total_Shows") - col("Target_Total_Shows")
).withColumn(
    "Variance_Impressions",
    col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")
).withColumn(
    "Variance_Revenue",
    col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")
).withColumn(
    "Shows_Match",
    when(
        abs(col("Source_Total_Shows") - col("Target_Total_Shows")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Impressions_Match",
    when(
        abs(col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Revenue_Match",
    when(
        abs(col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Status",
    when(
        (col("Shows_Match") == True) &
        (col("Impressions_Match") == True) &
        (col("Revenue_Match") == True),
        True
    ).otherwise(False)
).select(
    col("AOS_Deal_ID"),
    col("Source_Total_Shows"),
    col("Target_Total_Shows"),
    col("Variance_Shows"),
    col("Shows_Match"),
    col("Source_Total_Delivered_Impressions"),
    col("Target_Total_Delivered_Impressions"),
    col("Variance_Impressions"),
    col("Impressions_Match"),
    col("Source_Total_Delivered_Revenue"),
    col("Target_Total_Delivered_Revenue"),
    col("Variance_Revenue"),
    col("Revenue_Match"),
    col("Status")
)

display(validation_df)



# Create a dataframe showing which columns have mismatches for deals where Status is False
mismatch_details_df = validation_df.withColumn(
    "Mismatched_Columns_Array",
    array(
        when(col("Shows_Match") == False, lit("Shows")).otherwise(lit(None)),
        when(col("Impressions_Match") == False, lit("Impressions")).otherwise(lit(None)),
        when(col("Revenue_Match") == False, lit("Revenue")).otherwise(lit(None))
    )
).withColumn(
    "Mismatched_Columns_Array",
    expr("filter(Mismatched_Columns_Array, x -> x is not null)")
).withColumn(
    "Mismatched_Columns",
    concat_ws(", ", col("Mismatched_Columns_Array"))
).select(
    col("AOS_Deal_ID").alias("deal_id"),
    col("Status"),
    col("Mismatched_Columns")
).distinct()

print("=" * 80)
print(f"Deal Mismatch Details")
print(f"Total Deals with Mismatches: {mismatch_details_df.filter(col('Status') == False).count()}")
print("=" * 80)

display(mismatch_details_df)





# COMMAND ----------

# MAGIC %md
# MAGIC ### Deal IDs Only in Target Table (Not in Source)

# COMMAND ----------

# Find deal_ids that are only in target table and not in source table
target_only_deals = spark.sql(f"""
    SELECT 
        t.`AOS Deal ID` as AOS_Deal_ID,
        t.`Total Shows` as `Target Total Shows`,
        t.`Total Delivered Impressions` as `Target Total Delivered Impressions`,
        t.`Total Delivered Revenue` as `Target Total Delivered Revenue`
    FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal t
    WHERE t.`AOS Deal ID` IS NOT NULL
        AND t.`AOS Deal ID` != -1
        AND NOT EXISTS (
            SELECT 1
            FROM {catalog_name}.gold_ad_sales.wrap_detailed_unified_report_sections_by_deal s
            WHERE s.AOS_Deal_ID = t.`AOS Deal ID`
                AND s.data_type = 'CONTENT_PERFORMANCE'
        )
    ORDER BY t.`AOS Deal ID`
""")

print("=" * 80)
print(f"Deal IDs only in v_ft_unified_campaign_delivery_by_deal Table (v_ft_unified_campaign_delivery_by_deal)")
print(f"Count: {target_only_deals.count()}")
print("=" * 80)

display(target_only_deals)




# COMMAND ----------

# MAGIC %md
# MAGIC ### Update mismatch_details_df: Mark missing deals from target_only_deals

# COMMAND ----------

# Update mismatch_details_df to include deals from target_only_deals with Status = "missing deals"
# First, convert Status to string in mismatch_details_df to allow "missing deals" value
mismatch_details_df_1 = mismatch_details_df.withColumn(
    "Status",
    when(col("Status") == True, lit("True"))
    .when(col("Status") == False, lit("False"))
    .otherwise(col("Status").cast("string"))
)

# Create a dataframe for missing deals with the same structure as mismatch_details_df
missing_deals_df = target_only_deals.select(
    col("AOS_Deal_ID").alias("deal_id"),
    lit("missing deals").alias("Status"),
    lit("Deal not found in source table").alias("Mismatched_Columns")
)

display(missing_deals_df)

display(mismatch_details_df_1)

# Option 1: Use a broadcast join with a flag, then check if deal_id exists in target_only_deals
from pyspark.sql.functions import broadcast

# Create a set of deal_ids from target_only_deals for efficient lookup
target_only_deal_ids = target_only_deals.select(col("AOS_Deal_ID").alias("deal_id")).distinct()

# Join and check if deal_id exists in target_only_deals
mismatch_details_df_1 = mismatch_details_df_1.join(
    broadcast(target_only_deal_ids).withColumn("is_target_only", lit(True)),
    on="deal_id",
    how="left"
).withColumn(
    "Status",
    when(col("is_target_only").isNotNull(), lit("not found in source").cast("string"))
    .otherwise(col("Status").cast("string"))
).select(
    col("deal_id"),
    col("Status").cast("string").alias("Status"),
    col("Mismatched_Columns")
)


display(mismatch_details_df_1)



# Create a dataframe with deal_id and CONTENT_PERFORMANCE (True if Status is True, False otherwise)
deal_status_df_cp = mismatch_details_df_1.withColumn(
    "CONTENT_PERFORMANCE",
    when(col("Status") == "True", lit(True))
    .otherwise(lit(False))
).select(
    col("deal_id"),
    col("CONTENT_PERFORMANCE")
).distinct()

print("=" * 80)
print(f"Deal Status Summary")
print(f"Total Deals: {deal_status_df_cp.count()}")
print(f"Deals with CONTENT_PERFORMANCE = True: {deal_status_df_cp.filter(col('CONTENT_PERFORMANCE') == True).count()}")
print(f"Deals with CONTENT_PERFORMANCE = False: {deal_status_df_cp.filter(col('CONTENT_PERFORMANCE') == False).count()}")
print("=" * 80)

display(deal_status_df_cp)

# COMMAND ----------

# MAGIC %md
# MAGIC # Parse for IMPRESSIONS_OVER_TIME Validation
# MAGIC

# COMMAND ----------

# Databricks notebook Target
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from datetime import datetime, date
import os
import pandas as pd

# COMMAND ----------

# Configuration
catalog_name = 'fox_bi_qa'
env = 'dev'  # or 'qa' or 'prod'

# COMMAND ----------

# MAGIC %md
# MAGIC ## Validation: wrap_detailed_unified_report_sections_by_deal vs ft_unified_campaign_delivery_by_deal
# MAGIC
# MAGIC This validation compares:
# MAGIC - Target: Sum of field10 from wrap_detailed_unified_report_sections_by_deal (for IMPRESSIONS_OVER_TIME data_type)
# MAGIC - Target: Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
# MAGIC
# MAGIC For each aos_deal_id

# COMMAND ----------

# MAGIC %md
# MAGIC ### Target Data: wrap_detailed_unified_report_sections_by_deal

# COMMAND ----------

# Target: Aggregate field10 from wrap_detailed_unified_report_sections_by_deal
# Filter for IMPRESSIONS_OVER_TIME data_type and sum field10 (which contains Total_Delivered_Impressions as string)
tar_df = spark.sql(f"""
    SELECT 
        AOS_Deal_ID,
        SUM(try_cast(field2 AS BIGINT)) as `Target Total Delivered Impressions`,
        SUM(try_cast(field3 AS DECIMAL(19,2))) as `Target Total Delivered Revenue`
    FROM {catalog_name}.gold_ad_sales.wrap_detailed_unified_report_sections_by_deal
    WHERE data_type = 'IMPRESSIONS_OVER_TIME'
    GROUP BY AOS_Deal_ID
""")

display(tar_df)



# COMMAND ----------

# MAGIC %md
# MAGIC ### Source Data: ft_unified_campaign_delivery_by_deal

# COMMAND ----------

# Source: Get Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
src_df = spark.sql(f"""
    SELECT 
        `AOS Deal ID` as AOS_Deal_ID,
        `Total Delivered Impressions` as `Source Total Delivered Impressions`,
        `Total Delivered Revenue` as `Source Total Delivered Revenue`
    FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal
    WHERE `AOS Deal ID` IS NOT NULL
        AND `AOS Deal ID` != -1
""")

display(src_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Validation Comparison

# COMMAND ----------

from pyspark.sql.functions import col, when, expr, nvl, abs, lit, array, concat_ws

# Join source and target on AOS_Deal_ID
joined_df = src_df.join(
    tar_df,
    on="AOS_Deal_ID",
    how="full_outer"
)

display(joined_df)


# Add comparison columns - only for columns that exist
validation_df = joined_df.withColumn(
    "Source_Total_Delivered_Impressions",
    nvl(col("`Source Total Delivered Impressions`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Impressions",
    nvl(col("`Target Total Delivered Impressions`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Revenue",
    nvl(col("`Source Total Delivered Revenue`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Revenue",
    nvl(col("`Target Total Delivered Revenue`"), lit(0))
).withColumn(
    "Variance_Impressions",
    col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")
).withColumn(
    "Variance_Revenue",
    col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")
).withColumn(
    "Impressions_Match",
    when(
        abs(col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Revenue_Match",
    when(
        abs(col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")) <= 0.01,
        True
    ).otherwise(False)
).withColumn(
    "Status",
    when(
        (col("Impressions_Match") == True) &
        (col("Revenue_Match") == True),
        True
    ).otherwise(False)
).select(
    col("AOS_Deal_ID"),
    col("Source_Total_Delivered_Impressions"),
    col("Target_Total_Delivered_Impressions"),
    col("Variance_Impressions"),
    col("Impressions_Match"),
    col("Source_Total_Delivered_Revenue"),
    col("Target_Total_Delivered_Revenue"),
    col("Variance_Revenue"),
    col("Revenue_Match"),
    col("Status")
)

display(validation_df)



# Create a dataframe showing which columns have mismatches for deals where Status is False
mismatch_details_df = validation_df.filter(
    col("Status") == False
).withColumn(
    "Mismatched_Columns_Array",
    array(
        when(col("Impressions_Match") == False, lit("Impressions")).otherwise(lit(None)),
        when(col("Revenue_Match") == False, lit("Revenue")).otherwise(lit(None))
    )
).withColumn(
    "Mismatched_Columns_Array",
    expr("filter(Mismatched_Columns_Array, x -> x is not null)")
).withColumn(
    "Mismatched_Columns",
    concat_ws(", ", col("Mismatched_Columns_Array"))
).select(
    col("AOS_Deal_ID").alias("deal_id"),
    when(col("Status") == True, lit("True"))
    .when(col("Status") == False, lit("False"))
    .otherwise(lit("False")).cast("string").alias("Status"),
    col("Mismatched_Columns")
).distinct()

print("=" * 80)
print(f"Deal Mismatch Details")
print(f"Total Deals with Mismatches: {mismatch_details_df.count()}")
print("=" * 80)

display(mismatch_details_df)




# COMMAND ----------

# MAGIC %md
# MAGIC ### Deal IDs Only in Target Table (Not in Source)

# COMMAND ----------

# Find deal_ids that are only in target table and not in source table
target_only_deals = spark.sql(f"""
    SELECT 
        t.`AOS Deal ID` as AOS_Deal_ID,
        t.`Total Delivered Impressions` as `Target Total Delivered Impressions`,
        t.`Total Delivered Revenue` as `Target Total Delivered Revenue`
    FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal t
    WHERE t.`AOS Deal ID` IS NOT NULL
        AND t.`AOS Deal ID` != -1
        AND NOT EXISTS (
            SELECT 1
            FROM {catalog_name}.gold_ad_sales.wrap_detailed_unified_report_sections_by_deal s
            WHERE s.AOS_Deal_ID = t.`AOS Deal ID`
                AND s.data_type = 'IMPRESSIONS_OVER_TIME'
        )
    ORDER BY t.`AOS Deal ID`
""")

print("=" * 80)
print(f"Deal IDs only in v_ft_unified_campaign_delivery_by_deal Table (v_ft_unified_campaign_delivery_by_deal)")
print(f"Count: {target_only_deals.count()}")
print("=" * 80)

display(target_only_deals)




# COMMAND ----------

# MAGIC %md
# MAGIC ### Update mismatch_details_df: Mark missing deals from target_only_deals

# COMMAND ----------

# Update mismatch_details_df to include deals from target_only_deals with Status = "missing deals"
# First, convert Status to string in mismatch_details_df to allow "missing deals" value
mismatch_details_df_1 = mismatch_details_df.withColumn(
    "Status",
    col("Status").cast("string")
)

# Create a dataframe for missing deals with the same structure as mismatch_details_df
missing_deals_df = target_only_deals.select(
    col("AOS_Deal_ID").alias("deal_id"),
    lit("missing deals").cast("string").alias("Status"),
    lit("Deal not found in source table").cast("string").alias("Mismatched_Columns")
)

display(missing_deals_df)

display(mismatch_details_df_1)

# Option 1: Use a broadcast join with a flag, then check if deal_id exists in target_only_deals
from pyspark.sql.functions import broadcast

# Create a set of deal_ids from target_only_deals for efficient lookup
target_only_deal_ids = target_only_deals.select(col("AOS_Deal_ID").alias("deal_id")).distinct()

# Join and check if deal_id exists in target_only_deals
mismatch_details_df_1 = mismatch_details_df_1.join(
    broadcast(target_only_deal_ids).withColumn("is_target_only", lit(True)),
    on="deal_id",
    how="left"
).withColumn(
    "Status",
    when(col("is_target_only").isNotNull(), lit("not found in source").cast("string"))
    .otherwise(col("Status").cast("string"))
).select(
    col("deal_id"),
    col("Status").cast("string").alias("Status"),
    col("Mismatched_Columns")
)

# Union with missing_deals_df to include all deals that are only in target table
mismatch_details_df_1 = mismatch_details_df_1.unionByName(
    missing_deals_df,
    allowMissingColumns=True
).select(
    col("deal_id"),
    col("Status").cast("string").alias("Status"),
    col("Mismatched_Columns").cast("string").alias("Mismatched_Columns")
).distinct()

display(mismatch_details_df_1)



# Create a dataframe with deal_id and IMPRESSIONS_OVER_TIME (True if Status is True, False otherwise)
deal_status_df_iot = mismatch_details_df_1.select(
    col("deal_id"),
    when(col("Status") == "True", lit(True))
    .when(col("Status") == "False", lit(False))
    .otherwise(lit(False))
    .alias("IMPRESSIONS_OVER_TIME")
).distinct()

print("=" * 80)
print(f"Deal Status Summary")
print(f"Total Deals: {deal_status_df_iot.count()}")
print(f"Deals with IMPRESSIONS_OVER_TIME = True: {deal_status_df_iot.filter(col('IMPRESSIONS_OVER_TIME') == True).count()}")
print(f"Deals with IMPRESSIONS_OVER_TIME = False: {deal_status_df_iot.filter(col('IMPRESSIONS_OVER_TIME') == False).count()}")
print("=" * 80)

display(deal_status_df_iot)

# COMMAND ----------

# MAGIC %md
# MAGIC # Parse for GEO_PERFORMANCE Validation
# MAGIC

# COMMAND ----------

# Databricks notebook Target
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from datetime import datetime, date
import os
import pandas as pd

# COMMAND ----------

# Configuration
catalog_name = 'fox_bi_qa'
env = 'dev'  # or 'qa' or 'prod'

# COMMAND ----------

# MAGIC %md
# MAGIC ## Validation: wrap_detailed_unified_report_sections_by_deal vs ft_unified_campaign_delivery_by_deal
# MAGIC
# MAGIC This validation compares:
# MAGIC - Target: Sum of field10 from wrap_detailed_unified_report_sections_by_deal (for GEO_PERFORMANCE data_type)
# MAGIC - Target: Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
# MAGIC
# MAGIC For each aos_deal_id

# COMMAND ----------

# MAGIC %md
# MAGIC ### Target Data: wrap_detailed_unified_report_sections_by_deal

# COMMAND ----------

# Target: Aggregate field10 from wrap_detailed_unified_report_sections_by_deal
# Filter for GEO_PERFORMANCE data_type and sum field10 (which contains Total_Delivered_Impressions as string)
tar_df = spark.sql(f"""
    SELECT 
        AOS_Deal_ID,
        SUM(try_cast(field3 AS BIGINT)) as `Target Total Delivered Impressions`,
        size(collect_list(field1)) as `Target Total Countries`,
        size(collect_list(field2)) as `Target Total States`
    FROM {catalog_name}.gold_ad_sales.wrap_detailed_unified_report_sections_by_deal
    WHERE data_type = 'GEO_PERFORMANCE'
    GROUP BY AOS_Deal_ID
""")

display(tar_df)



# COMMAND ----------

# MAGIC %md
# MAGIC ### Source Data: ft_unified_campaign_delivery_by_deal

# COMMAND ----------

# Source: Get Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
src_df = spark.sql(f"""
    SELECT 
        `AOS Deal ID` as AOS_Deal_ID,
        `Total Delivered Impressions` as `Source Total Delivered Impressions`,
        `Total Countries` as `Source Total Countries`,
        `Total States` as `Source Total States`
    FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal
    WHERE `AOS Deal ID` IS NOT NULL
        AND `AOS Deal ID` != -1
""")

display(src_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Validation Comparison

# COMMAND ----------

from pyspark.sql.functions import col, when, expr, nvl, abs, lit, array, concat_ws

# Join source and target on AOS_Deal_ID
joined_df = src_df.join(
    tar_df,
    on="AOS_Deal_ID",
    how="full_outer"
)

display(joined_df)


# Add comparison columns - only for the columns that exist
validation_df = joined_df.withColumn(
    "Source_Total_Delivered_Impressions",
    nvl(col("`Source Total Delivered Impressions`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Impressions",
    nvl(col("`Target Total Delivered Impressions`"), lit(0))
).withColumn(
    "Source_Total_Countries",
    nvl(col("`Source Total Countries`"), lit(0))
).withColumn(
    "Target_Total_Countries",
    nvl(col("`Target Total Countries`"), lit(0))
).withColumn(
    "Source_Total_States",
    nvl(col("`Source Total States`"), lit(0))
).withColumn(
    "Target_Total_States",
    nvl(col("`Target Total States`"), lit(0))
).withColumn(
    "Variance_Impressions",
    col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")
).withColumn(
    "Variance_Total_Countries",
    col("Source_Total_Countries") - col("Target_Total_Countries")
).withColumn(
    "Variance_Total_States",
    col("Source_Total_States") - col("Target_Total_States")
).withColumn(
    "Impressions_Match",
    when(
        abs(col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Total_Countries_Match",
    when(
        abs(col("Source_Total_Countries") - col("Target_Total_Countries")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Total_States_Match",
    when(
        abs(col("Source_Total_States") - col("Target_Total_States")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Status",
    when(
        (col("Impressions_Match") == True) &
        (col("Total_Countries_Match") == True) &
        (col("Total_States_Match") == True),
        True
    ).otherwise(False)
).select(
    col("AOS_Deal_ID"),
    col("Source_Total_Delivered_Impressions"),
    col("Target_Total_Delivered_Impressions"),
    col("Variance_Impressions"),
    col("Impressions_Match"),
    col("Source_Total_Countries"),
    col("Target_Total_Countries"),
    col("Variance_Total_Countries"),
    col("Total_Countries_Match"),
    col("Source_Total_States"),
    col("Target_Total_States"),
    col("Variance_Total_States"),
    col("Total_States_Match"),
    col("Status")
)

display(validation_df)



# Create a dataframe showing which columns have mismatches for deals where Status is False
mismatch_details_df = validation_df.withColumn(
    "Mismatched_Columns_Array",
    array(
        when(col("Impressions_Match") == False, lit("Impressions")).otherwise(lit(None)),
        when(col("Total_Countries_Match") == False, lit("Total_Countries")).otherwise(lit(None)),
        when(col("Total_States_Match") == False, lit("Total_States")).otherwise(lit(None))
    )
).withColumn(
    "Mismatched_Columns_Array",
    expr("filter(Mismatched_Columns_Array, x -> x is not null)")
).withColumn(
    "Mismatched_Columns",
    concat_ws(", ", col("Mismatched_Columns_Array"))
).select(
    col("AOS_Deal_ID").alias("deal_id"),
    col("Status"),
    col("Mismatched_Columns")
).distinct()

print("=" * 80)
print(f"Deal Mismatch Details")
print(f"Total Deals with Mismatches: {mismatch_details_df.count()}")
print("=" * 80)

display(mismatch_details_df)




# COMMAND ----------

# MAGIC %md
# MAGIC ### Deal IDs Only in Target Table (Not in Source)

# COMMAND ----------

# Find deal_ids that are only in target table and not in source table
target_only_deals = spark.sql(f"""
    SELECT 
        t.`AOS Deal ID` as AOS_Deal_ID,
        t.`Total Delivered Impressions` as `Target Total Delivered Impressions`,
        t.`Total Countries` as `Target Total Countries`,
        t.`Total States` as `Target Total States`
    FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal t
    WHERE t.`AOS Deal ID` IS NOT NULL
        AND t.`AOS Deal ID` != -1
        AND NOT EXISTS (
            SELECT 1
            FROM {catalog_name}.gold_ad_sales.wrap_detailed_unified_report_sections_by_deal s
            WHERE s.AOS_Deal_ID = t.`AOS Deal ID`
                AND s.data_type = 'GEO_PERFORMANCE'
        )
    ORDER BY t.`AOS Deal ID`
""")

print("=" * 80)
print(f"Deal IDs only in v_ft_unified_campaign_delivery_by_deal Table (v_ft_unified_campaign_delivery_by_deal)")
print(f"Count: {target_only_deals.count()}")
print("=" * 80)

display(target_only_deals)




# COMMAND ----------

# MAGIC %md
# MAGIC ### Update mismatch_details_df: Mark missing deals from target_only_deals

# COMMAND ----------

# Update mismatch_details_df to include deals from target_only_deals with Status = "missing deals"
# First, convert Status to string in mismatch_details_df to allow "missing deals" value
mismatch_details_df_1 = mismatch_details_df.withColumn(
    "Status",
    when(col("Status") == True, lit("True"))
    .when(col("Status") == False, lit("False"))
    .otherwise(col("Status").cast("string"))
)

# Create a dataframe for missing deals with the same structure as mismatch_details_df
missing_deals_df = target_only_deals.select(
    col("AOS_Deal_ID").alias("deal_id"),
    lit("missing deals").alias("Status"),
    lit("Deal not found in source table").alias("Mismatched_Columns")
)

display(missing_deals_df)

display(mismatch_details_df_1)

# Option 1: Use a broadcast join with a flag, then check if deal_id exists in target_only_deals
from pyspark.sql.functions import broadcast

# Create a set of deal_ids from target_only_deals for efficient lookup
target_only_deal_ids = target_only_deals.select(col("AOS_Deal_ID").alias("deal_id")).distinct()

# Join and check if deal_id exists in target_only_deals
mismatch_details_df_1 = mismatch_details_df_1.join(
    broadcast(target_only_deal_ids).withColumn("is_target_only", lit(True)),
    on="deal_id",
    how="left"
).withColumn(
    "Status",
    when(col("is_target_only").isNotNull(), lit("not found in source").cast("string"))
    .otherwise(col("Status").cast("string"))
).select(
    col("deal_id"),
    col("Status").cast("string").alias("Status"),
    col("Mismatched_Columns")
)


display(mismatch_details_df_1)



# Create a dataframe with deal_id and GEO_PERFORMANCE (True if Status is True, False otherwise)
deal_status_df_gp = mismatch_details_df_1.withColumn(
    "GEO_PERFORMANCE",
    when(col("Status") == "True", lit(True))
    .when(col("Status") == "False", lit(False))
    .otherwise(lit(False))
).select(
    col("deal_id"),
    col("GEO_PERFORMANCE")
).distinct()

print("=" * 80)
print(f"Deal Status Summary")
print(f"Total Deals: {deal_status_df_gp.count()}")
print(f"Deals with GEO_PERFORMANCE = True: {deal_status_df_gp.filter(col('GEO_PERFORMANCE') == True).count()}")
print(f"Deals with GEO_PERFORMANCE = False: {deal_status_df_gp.filter(col('GEO_PERFORMANCE') == False).count()}")
print("=" * 80)

display(deal_status_df_gp)

# COMMAND ----------

# COMMAND ----------

# MAGIC %md
# MAGIC ### Merge All Deal Status DataFrames (Alternative Approach)

# COMMAND ----------

from pyspark.sql.functions import col
from functools import reduce

# Define the mapping of dataframe names to output column names
# Adjust these based on your actual column names in each dataframe
dataframe_mapping = {
    "deal_status_df_cs": "campaign_summary_validation",
    "deal_status_df_db": "duration_bucket_analysis_validation", 
    "deal_status_df_pd": "placement_details_validation",
    "deal_status_df_ltp": "line_item_performance_validation",
    "deal_status_df_adp": "ad_position_validation",
    "deal_status_df_cp": "creative_performance_validation",
    "deal_status_df_dba": "device_bucket_analysis_validation",
    "deal_status_df_dapm": "device_ad_position_matrix_validation",
    "deal_status_df_dbp": "demo_band_performance_validation",
    "deal_status_df_pp": "package_performance_validation",
    "deal_status_df_cp": "content_performance_validation",
    "deal_status_df_iot": "impressions_over_time_validation",
    "deal_status_df_gp": "geo_performance_validation"
}

# Get all dataframes as a list of tuples (dataframe, column_name)
dataframes_to_merge = [
    (deal_status_df_cs, "campaign_summary_validation"),
    (deal_status_df_db, "duration_bucket_analysis_validation"),
    (deal_status_df_pd, "placement_details_validation"),
    (deal_status_df_ltp, "line_item_performance_validation"),
    (deal_status_df_adp, "ad_position_validation"),
    (deal_status_df_cp, "creative_performance_validation"),
    (deal_status_df_dba, "device_bucket_analysis_validation"),
    (deal_status_df_dapm, "device_ad_position_matrix_validation"),
    (deal_status_df_dbp, "demo_band_performance_validation"),
    (deal_status_df_pp, "package_performance_validation"),
    (deal_status_df_cp, "content_performance_validation"),
    (deal_status_df_iot, "impressions_over_time_validation"),
    (deal_status_df_gp, "geo_performance_validation")

]

# Rename the status column in each dataframe and prepare for merge
renamed_dfs = []
for df, output_col in dataframes_to_merge:
    # Get the actual status column name from the dataframe
    # Assuming it's the second column (first is deal_id)
    status_col = df.columns[1]  # Adjust if needed
    
    renamed_df = df.select(
        col("deal_id"),
        col(status_col).alias(output_col)
    )
    renamed_dfs.append(renamed_df)

# Merge all dataframes using reduce with full_outer join to preserve all deals
merged_deal_status_df = reduce(
    lambda df1, df2: df1.join(df2, on="deal_id", how="full_outer"),
    renamed_dfs
)

# Select all columns as-is without any transformation to preserve original values
# This will keep all original values including strings like "not found in source", True, False, etc.
select_exprs = [col("deal_id")]
for _, output_col in dataframes_to_merge:
    select_exprs.append(col(output_col))

merged_deal_status_df = merged_deal_status_df.select(*select_exprs)

print("=" * 80)
print(f"Merged Deal Status Summary")
print(f"Total Deals: {merged_deal_status_df.count()}")
print("=" * 80)

display(merged_deal_status_df)

# COMMAND ----------

# COMMAND ----------

# MAGIC %md
# MAGIC ### Write Merged Deal Status to Table (Overwrite Specific Partition)

# COMMAND ----------

from pyspark.sql.functions import current_date
from datetime import datetime

# Add current_date column for partitioning
merged_deal_status_df_with_date = merged_deal_status_df.withColumn(
    "load_date",
    current_date()
)


# COMMAND ----------

# MAGIC %md
# MAGIC ### Replace 'not found in source' with 'missing' and convert to uppercase (Alternative)

# COMMAND ----------

from pyspark.sql.functions import col, upper

# Get all column names except deal_id and load_date
status_columns = [col_name for col_name in merged_deal_status_df_with_date.columns 
                  if col_name not in ['deal_id', 'load_date']]

# Replace 'not found in source' with 'missing' and convert to uppercase for all status columns
for col_name in status_columns:
    merged_deal_status_df_with_date = merged_deal_status_df_with_date.withColumn(
        col_name,
        upper(
            regexp_replace(col(col_name), "not found in source", "missing")
        )
    )

display(merged_deal_status_df_with_date)

print("=" * 80)
print(f"Replaced 'not found in source' with 'missing' and converted all values to uppercase")
print("=" * 80)

# Write to table with overwrite mode for specific partition
merged_deal_status_df_with_date.write \
    .mode("overwrite") \
    .option("partitionOverwriteMode", "dynamic") \
    .partitionBy("load_date") \
    .option("mergeSchema", "true")\
    .saveAsTable("fox_bi_dev.bronze_ads.campaign_detailed_report_validation")

print("=" * 80)
print(f"Successfully wrote merged_deal_status_df to fox_bi_dev.bronze_ads.campaign_detailed_report_validation")
print(f"Total records written: {merged_deal_status_df_with_date.count()}")
print(f"Partition overwritten: load_date = {datetime.now().strftime('%Y-%m-%d')}")
print("=" * 80)

# COMMAND ----------

# %sql
# drop table fox_bi_dev.bronze_ads.campaign_detailed_report_validation

# COMMAND ----------

