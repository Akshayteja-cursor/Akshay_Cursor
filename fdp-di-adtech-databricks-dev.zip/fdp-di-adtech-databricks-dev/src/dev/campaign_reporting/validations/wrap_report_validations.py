# Databricks notebook source
spark.conf.set("spark.databricks.remoteFiltering.blockSelfJoins", "false")

# COMMAND ----------

from concurrent.futures import ThreadPoolExecutor, as_completed

# Path to the validations folder (relative paths work within the same repo)
BASE_PATH = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
BASE_PATH = "/".join(BASE_PATH.split("/")[:-1])  # strip the current notebook name

NOTEBOOKS = [
    "wrap_report_parse_validation_ad_position_analysis",
    "wrap_report_parse_validation_campaign_summary",
    "wrap_report_parse_validation_content_performance",
    "wrap_report_parse_validation_creative_performance",
    "wrap_report_parse_validation_deal_ad_units_performance",
    "wrap_report_parse_validation_demo_band_performance",
    "wrap_report_parse_validation_device_ad_position_matrix",
    "wrap_report_parse_validation_device_breakdown",
    "wrap_report_parse_validation_duration_bucket_analysis",
    "wrap_report_parse_validation_geo_performance",
    "wrap_report_parse_validation_impressions_over_time",
    "wrap_report_parse_validation_line_item_type_performance",
    "wrap_report_parse_validation_package_performance",
    "wrap_report_parse_validation_target_audience_distribution"
]

def run_notebook(name):
    try:
        result = dbutils.notebook.run(f"{BASE_PATH}/{name}", timeout_seconds=3600)
        return name, result, None
    except Exception as e:
        return name, None, str(e)

print("Starting parallel notebook execution...")
with ThreadPoolExecutor(max_workers=len(NOTEBOOKS)+2) as executor:
    futures = {executor.submit(run_notebook, name): name for name in NOTEBOOKS}
    for future in as_completed(futures):
        name, result, error = future.result()
        if error:
            print(f"  FAILED : {name} -> {error}")
        else:
            print(f"  SUCCESS: {name} -> {result}")

print("\nAll notebooks complete. Reading results from global temp views...")

# Assign global temp views back to the expected Python variable names
deal_status_df_cs   = spark.table("global_temp.deal_status_df_cs")
deal_status_df_db   = spark.table("global_temp.deal_status_df_db")
deal_status_df_ltp  = spark.table("global_temp.deal_status_df_ltp")
deal_status_df_adp  = spark.table("global_temp.deal_status_df_adp")
deal_status_df_cp   = spark.table("global_temp.deal_status_df_cp")
deal_status_df_dba  = spark.table("global_temp.deal_status_df_dba")
deal_status_df_dapm = spark.table("global_temp.deal_status_df_dapm")
deal_status_df_daup = spark.table("global_temp.deal_status_df_daup")
deal_status_df_dbp  = spark.table("global_temp.deal_status_df_dbp")
deal_status_df_pp   = spark.table("global_temp.deal_status_df_pp")
deal_status_df_cpv  = spark.table("global_temp.deal_status_df_cpv")
deal_status_df_iot  = spark.table("global_temp.deal_status_df_iot")
deal_status_df_gp   = spark.table("global_temp.deal_status_df_gp")
deal_status_df_tad  = spark.table("global_temp.deal_status_df_tad")

print("All dataframes ready.")

# COMMAND ----------

# COMMAND ----------

# MAGIC %md
# MAGIC ### Merge All Deal Status DataFrames (Alternative Approach)

# COMMAND ----------

from pyspark.sql.functions import col
from functools import reduce

# Define the mapping of dataframe names to output column names
# Adjust these based on your actual column names in each dataframe
dataframe_mapping = {
    "deal_status_df_cs": "campaign_summary_validation",
    "deal_status_df_db": "device_breakdown_validation", 
    # "deal_status_df_pd": "placement_details_validation",
    "deal_status_df_ltp": "line_item_performance_validation",
    "deal_status_df_adp": "ad_position_analysis_validation",
    "deal_status_df_cp": "creative_performance_validation",
    "deal_status_df_dba": "duration_bucket_analysis_validation",
    "deal_status_df_dapm": "device_ad_position_matrix_validation",
    "deal_status_df_daup": "deal_ad_units_performance_validation",
    "deal_status_df_dbp": "demo_band_performance_validation",
    "deal_status_df_pp": "package_performance_validation",
    "deal_status_df_cpv": "content_performance_validation",
    "deal_status_df_iot": "impressions_over_time_validation",
    "deal_status_df_gp": "geo_performance_validation",
    "deal_status_df_tad": "targeted_audience_distribution_validation"
}

# Get all dataframes as a list of tuples (dataframe, column_name)
dataframes_to_merge = [
    (deal_status_df_cs, "campaign_summary_validation"),
    (deal_status_df_db, "device_breakdown_validation"),
    # (deal_status_df_pd, "placement_details_validation"),
    (deal_status_df_ltp, "line_item_performance_validation"),
    (deal_status_df_adp, "ad_position_analysis_validation"),
    (deal_status_df_cp, "creative_performance_validation"),
    (deal_status_df_dba, "duration_bucket_analysis_validation"),
    (deal_status_df_dapm, "device_ad_position_matrix_validation"),
    (deal_status_df_daup, "deal_ad_units_performance_validation"),
    (deal_status_df_dbp, "demo_band_performance_validation"),
    (deal_status_df_pp, "package_performance_validation"),
    (deal_status_df_cpv, "content_performance_validation"),
    (deal_status_df_iot, "impressions_over_time_validation"),
    (deal_status_df_gp, "geo_performance_validation"),
    (deal_status_df_tad, "targeted_audience_distribution_validation")

]

# Rename the status column in each dataframe and prepare for merge
renamed_dfs = []
for df, output_col in dataframes_to_merge:
    # Get the actual status column name from the dataframe
    # Assuming it's the second column (first is deal_id)
    status_col = df.columns[1]  # Adjust if needed
    
    renamed_df = df.select(
        col("deal_id"),
        col(status_col).alias(output_col)
    )
    renamed_dfs.append(renamed_df)

# Merge all dataframes using reduce with full_outer join to preserve all deals
merged_deal_status_df = reduce(
    lambda df1, df2: df1.join(df2, on="deal_id", how="full_outer"),
    renamed_dfs
)

# Select all columns as-is without any transformation to preserve original values
# This will keep all original values including strings like "not found in source", True, False, etc.
select_exprs = [col("deal_id")]
for _, output_col in dataframes_to_merge:
    select_exprs.append(col(output_col))

merged_deal_status_df = merged_deal_status_df.select(*select_exprs)

print("=" * 80)
print(f"Merged Deal Status Summary")
print(f"Total Deals: {merged_deal_status_df.count()}")
print("=" * 80)

display(merged_deal_status_df)

# COMMAND ----------

# COMMAND ----------

# MAGIC %md
# MAGIC ### Write Merged Deal Status to Table (Overwrite Specific Partition)

# COMMAND ----------

from pyspark.sql.functions import current_date
from datetime import datetime

# Add current_date column for partitioning
merged_deal_status_df_with_date = merged_deal_status_df.withColumn(
    "load_date",
    current_date()
)


# COMMAND ----------

# MAGIC %md
# MAGIC ### Replace 'not found in source' with 'missing' and convert to uppercase (Alternative)

# COMMAND ----------

from pyspark.sql.functions import col, upper, regexp_replace

# Get all column names except deal_id and load_date
status_columns = [col_name for col_name in merged_deal_status_df_with_date.columns 
                  if col_name not in ['deal_id', 'load_date']]

# Replace 'not found in source' with 'missing' and convert to uppercase for all status columns
for col_name in status_columns:
    merged_deal_status_df_with_date = merged_deal_status_df_with_date.withColumn(
        col_name,
        upper(
            # regexp_replace(col(col_name), "not found in source", "missing")
            regexp_replace(col(col_name), "missing deals", "missing")
        )
    )

display(merged_deal_status_df_with_date)

print("=" * 80)
print(f"Replaced 'not found in source' with 'missing' and converted all values to uppercase")
print("=" * 80)

# Write to table with overwrite mode for specific partition
merged_deal_status_df_with_date.write \
    .mode("overwrite") \
    .option("mergeSchema", "true") \
    .saveAsTable("fox_bi_dev.bronze_ads.campaign_detailed_report_validation")

print("=" * 80)
print(f"Successfully wrote merged_deal_status_df to fox_bi_dev.bronze_ads.campaign_detailed_report_validation")
print(f"Total records written: {merged_deal_status_df_with_date.count()}")
print(f"Partition overwritten: load_date = {datetime.now().strftime('%Y-%m-%d')}")
print("=" * 80)