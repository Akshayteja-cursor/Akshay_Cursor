# Databricks notebook source
spark.conf.set("spark.databricks.remoteFiltering.blockSelfJoins", "false")

# COMMAND ----------

# MAGIC %md
# MAGIC # Parse for DEVICE_AD_POSITION_MATRIX Validation
# MAGIC

# COMMAND ----------

# Databricks notebook Target
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from datetime import datetime, date
import os
import pandas as pd

# COMMAND ----------

# Configuration
catalog_name = 'fox_bi_qa'
env = 'dev'  # or 'qa' or 'prod'


# Target: Aggregate field10 from wrap_detailed_unified_report_sections_by_deal
# Filter for DEVICE_AD_POSITION_MATRIX data_type and sum field10 (which contains Total_Delivered_Impressions as string)
tar_df_dapm = spark.sql(f"""
    SELECT 
        AOS_Deal_ID,     
        SUM(try_cast(field3 AS BIGINT)) as `Target Total Delivered Impressions`,
        SUM(try_cast(field4 AS DECIMAL(19,2))) as `Target Total Delivered Revenue`,
        SUM(try_cast(field5 AS BIGINT)) as `Target Total Delivered Clicks`
    FROM {catalog_name}.gold_ad_sales.v_wrap_detailed_unified_report_sections_by_deal
    WHERE data_type = 'DEVICE_AD_POSITION_MATRIX'
    GROUP BY AOS_Deal_ID
""")

display(tar_df_dapm)


# Source: Get Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
src_df_dapm = spark.sql(f"""
with fw_placement_level as (
    SELECT
        `AOS_Deal Name` AS aos_deal_name,
        `AOS_Deal ID` AS aos_deal_id,
        pl.`Campaign Start Date` AS campaign_start_date,
        pl.`Campaign End Date` AS campaign_end_date,
        pl.`Advertiser Name` AS advertiser_name,
        pl.`Agency Name` AS agency_name,
        pl.`Sales Channel Type` AS line_item_type,
        pl.`Placement ID` AS placement_id,
        pl.`Placement Name` AS placement_name,
        pl.`Package Name` AS package_name,
        pl.`Parent Line Item Name` AS parent_line_item_name,
        pl.`AOS Deal Line Item Name` AS aos_deal_line_item_name,
        pl.`Creative ID` AS creative_id,
        pl.`Creative Name` AS creative_name,
        pl.`Creative Duration` AS creative_duration,
        pl.`Device` AS device,
        pl.`Ad Unit Position` AS ad_unit_position,
        pl.`Video Vertical` AS video_vertical,
        pl.`Show Name` AS show_name,
        pl.`Deal Ad Units` AS deal_ad_units,
        pl.`Demo Band` AS demo_band,
        pl.`Event Date` AS event_date,
        MAX(pl.`Guaranteed Impressions`) as guaranteed_impressions,
        MAX(pl.`Guaranteed Revenue`) as guaranteed_revenue,
        MAX(`Net Unit Cost`) as net_unit_cost,
        SUM(pl.`Delivered Impressions`) as delivered_impressions,
        SUM(pl.`Delivered Clicks`) as delivered_clicks,
        SUM(pl.`Delivered Revenue`) as delivered_revenue,
        SUM(pl.`On Target Net Delivered Impressions`) as on_target_impressions
    FROM fox_bi_qa.gold_ad_sales.v_ft_freewheel_campaign_delivery pl
    -- WHERE `AOS_Deal ID` = 18683
    GROUP BY
        `AOS_Deal ID`,
        `AOS_Deal Name`,
        pl.`Campaign Start Date`,
        pl.`Campaign End Date`,
        pl.`Advertiser Name`,
        pl.`Agency Name`,
        pl.`Sales Channel Type`,
        pl.`Placement ID`,
        pl.`Placement Name`,
        pl.`Package Name`,
        pl.`Parent Line Item Name`,
        pl.`AOS Deal Line Item Name`,
        pl.`Creative ID`,
        pl.`Creative Name`,
        pl.`Creative Duration`,
        pl.`Device`,
        pl.`Ad Unit Position`,
        pl.`Video Vertical`,
        pl.`Show Name`,
        pl.`Deal Ad Units`,
        pl.`Event Date`,
        pl.`Demo Band`
),
gam_placement_level AS (
    SELECT
        pl.`AOS Deal Name` AS aos_deal_name,
        pl.`AOS Deal ID` AS aos_deal_id,
        pl.`Campaign Start Date` AS campaign_start_date,
        pl.`Campaign End Date` AS campaign_end_date,
        pl.`Advertiser Name` AS advertiser_name,
        pl.`Agency Name` AS agency_name,
        pl.`Line Item Type` AS line_item_type,
        pl.`Line Item ID` AS placement_id,
        pl.`Line Item Name` AS placement_name,
        pl.`Package Name` AS package_name,
        pl.`Parent Line Item Name` AS parent_line_item_name,
        pl.`AOS Deal Line Item Name` AS aos_deal_line_item_name,
        CAST(-1 AS STRING) AS creative_id,
        CAST('N/A' AS STRING) AS creative_name,
        CAST(0 AS STRING) AS creative_duration,
        pl.`Device`,
        CAST('N/A' AS STRING) AS ad_unit_position,
        CAST('N/A' AS STRING) AS video_vertical,
        CAST('N/A' AS STRING) AS show_name,
        CAST('N/A' AS STRING) AS deal_ad_units,
        pl.`Demo Band` AS demo_band,
        pl.`Event Date` AS event_date,
        MAX(pl.`Guaranteed Impressions`) AS guaranteed_impressions,
        MAX(pl.`Guaranteed Revenue`) AS guaranteed_revenue,
        MAX(pl.`Net Unit Cost`) AS net_unit_cost,
        SUM(pl.`Delivered Impressions`) AS delivered_impressions,
        SUM(pl.`Delivered Clicks`) AS delivered_clicks,
        CASE
            WHEN MAX(pl.`Line Item Type`) = 'SPONSORSHIP'
            THEN MAX(pl.`Guaranteed Revenue`)/count(pl.`Event Date`) over (partition by pl.`Line Item ID`)
            ELSE (SUM(pl.`Delivered Impressions`) * MAX(pl.`Net Unit Cost`)) / 1000.0
        END as delivered_revenue,
        SUM(0) as on_target_impressions
    FROM fox_bi_qa.gold_ad_sales.v_ft_gam_campaign_delivery pl
    -- WHERE pl.`AOS Deal ID` = 18683
    GROUP BY
        pl.`AOS Deal ID`,
        pl.`AOS Deal Name`,
        pl.`Campaign Start Date`,
        pl.`Campaign End Date`,
        pl.`Advertiser Name`,
        pl.`Agency Name`,
        pl.`Line Item Type`,
        pl.`Line Item ID`,
        pl.`Line Item Name`,
        pl.`Package Name`,
        pl.`Parent Line Item Name`,
        pl.`AOS Deal Line Item Name`,
        pl.`Device`,
        pl.`Demo Band`,
        pl.`Event Date`
),
unified_placement_level as (
    SELECT
         aos_deal_id
        ,aos_deal_name
        ,campaign_start_date
        ,campaign_end_date
        ,advertiser_name
        ,agency_name
        -- ,sales_channel_type
        ,placement_id
        ,placement_name
        ,package_name
        ,parent_line_item_name
        ,aos_deal_line_item_name
        ,line_item_type
        ,creative_id
        ,creative_name
        ,creative_duration
        ,device
        ,ad_unit_position
        ,video_vertical
        ,show_name
        ,deal_ad_units
        ,event_date
        ,demo_band
        ,MAX(net_unit_cost) net_unit_cost
        ,MAX(guaranteed_impressions) AS guaranteed_impressions
        ,MAX(guaranteed_revenue) AS guaranteed_revenue
        ,SUM(delivered_impressions) AS delivered_impressions
        ,SUM(delivered_revenue) delivered_revenue
        ,SUM(delivered_clicks) AS delivered_clicks
        ,SUM(on_target_impressions) AS on_target_impressions
    FROM
        (
            select * from fw_placement_level
            union all
            select * from gam_placement_level
        )
    GROUP BY
            aos_deal_id
            ,aos_deal_name
            ,campaign_start_date
            ,campaign_end_date
            ,advertiser_name
            ,agency_name
            -- ,sales_channel_type
            ,placement_id
            ,package_name
            ,parent_line_item_name
            ,aos_deal_line_item_name
            ,placement_name
            ,creative_id
            ,creative_name
            ,creative_duration
            ,device
            ,ad_unit_position
            ,video_vertical
            ,show_name
            ,deal_ad_units
            ,event_date
            ,demo_band
            ,line_item_type
)                                      
,fetch_device_ad_pos_matrix as (
    SELECT 
        aos_deal_id as AOS_Deal_ID,
        CAST(SUM(delivered_impressions) AS BIGINT) as `Source Total Delivered Impressions`,
        CAST(SUM(delivered_revenue) AS DECIMAL(19,2)) as `Source Total Delivered Revenue`,
        CAST(SUM(delivered_clicks) AS BIGINT) as `Source Total Delivered Clicks`
    FROM unified_placement_level
    group by aos_deal_id
)
SELECT
distinct
`AOS Deal ID` as AOS_Deal_ID,
CAST(`Total First Party Delivered Impressions` AS BIGINT) as `Source Total Delivered Impressions`,
CAST(`Total First Party Delivered Revenue` AS DECIMAL(19,2)) as `Source Total Delivered Revenue`,
-- pl.`Source Total Delivered Revenue`,
-- pl.`Source Total Delivered Clicks`
CAST(`Total Delivered Clicks` AS BIGINT) as `Source Total Delivered Clicks`
-- pl.`Source Total Third Party Impressions`,
-- pl.`Source Total Third Party Revenue`,
-- CAST(`Total Third Party Impressions` AS BIGINT) as `Source Total Third Party Impressions`,
-- CAST(`Total Third Party Revenue` AS DECIMAL(19,2)) as `Source Total Third Party Revenue`,
-- pl.`Source Total Creatives` as `Source Total Creatives`,
-- pl.`Source CTR` as `Source CTR`
from
(select distinct * from fox_bi_qa.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal) as src
inner join
(select distinct * from fetch_device_ad_pos_matrix) pl
on src.`AOS Deal ID` = pl.AOS_Deal_ID

""")

display(src_df_dapm)

### Validation Comparison


from pyspark.sql.functions import col, when, expr, nvl, abs, lit, array, concat_ws

# Join source and target on AOS_Deal_ID
joined_df_dapm = src_df_dapm.join(
    tar_df_dapm,
    on="AOS_Deal_ID",
    how="full_outer"
)

display(joined_df_dapm)


# Add comparison columns - only for the columns that actually exist
validation_df_dapm = joined_df_dapm.withColumn(
    "Source_Total_Delivered_Impressions",
    nvl(col("`Source Total Delivered Impressions`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Impressions",
    nvl(col("`Target Total Delivered Impressions`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Revenue",
    nvl(col("`Source Total Delivered Revenue`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Revenue",
    nvl(col("`Target Total Delivered Revenue`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Clicks",
    nvl(col("`Source Total Delivered Clicks`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Clicks",
    nvl(col("`Target Total Delivered Clicks`"), lit(0))
).withColumn(
    "Variance_Impressions",
    col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")
).withColumn(
    "Variance_Revenue",
    col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")
).withColumn(
    "Variance_Clicks",
    col("Source_Total_Delivered_Clicks") - col("Target_Total_Delivered_Clicks")
).withColumn(
    "Impressions_Match",
    when(
        abs(col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Revenue_Match",
    when(
        abs(col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Clicks_Match",
    when(
        abs(col("Source_Total_Delivered_Clicks") - col("Target_Total_Delivered_Clicks")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Status",
    when(
        (col("Impressions_Match") == True) &
        (col("Revenue_Match") == True) &
        (col("Clicks_Match") == True),
        True
    ).otherwise(False)
).select(
    col("AOS_Deal_ID"),
    col("Source_Total_Delivered_Impressions"),
    col("Target_Total_Delivered_Impressions"),
    col("Variance_Impressions"),
    col("Impressions_Match"),
    col("Source_Total_Delivered_Revenue"),
    col("Target_Total_Delivered_Revenue"),
    col("Variance_Revenue"),
    col("Revenue_Match"),
    col("Source_Total_Delivered_Clicks"),
    col("Target_Total_Delivered_Clicks"),
    col("Variance_Clicks"),
    col("Clicks_Match"),
    col("Status")
)

display(validation_df_dapm)


# Create a dataframe showing which columns have mismatches
mismatch_details_df_dapm = validation_df_dapm.withColumn(
    "Mismatched_Columns_Array",
    array(
        when(col("Impressions_Match") == False, lit("Impressions")).otherwise(lit(None)),
        when(col("Revenue_Match") == False, lit("Revenue")).otherwise(lit(None)),
        when(col("Clicks_Match") == False, lit("Clicks")).otherwise(lit(None))
    )
).withColumn(
    "Mismatched_Columns_Array",
    expr("filter(Mismatched_Columns_Array, x -> x is not null)")
).withColumn(
    "Mismatched_Columns",
    concat_ws(", ", col("Mismatched_Columns_Array"))
).select(
    col("AOS_Deal_ID").alias("deal_id"),
    when(col("Status") == True, lit("True"))
    .when(col("Status") == False, lit("False"))
    .otherwise(lit("False")).cast("string").alias("Status"),
    col("Mismatched_Columns")
).distinct()

print("=" * 80)
print(f"Deal Mismatch Details")
print(f"Total Deals: {mismatch_details_df_dapm.count()}")
print(f"Deals with Status = True: {mismatch_details_df_dapm.filter(col('Status') == 'True').count()}")
print(f"Deals with Status = False: {mismatch_details_df_dapm.filter(col('Status') == 'False').count()}")
print("=" * 80)

display(mismatch_details_df_dapm)


# Find deal_ids that are only in target table and not in source table
source_only_deals_dapm = spark.sql(f"""
    SELECT 
        t.`AOS Deal ID` as AOS_Deal_ID,
        t.`Total Delivered Impressions` as `Target Total Delivered Impressions`,
        t.`Total Delivered Revenue` as `Target Total Delivered Revenue`,
        t.`Total Delivered Clicks` as `Target Total Delivered Clicks`
    FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal t
    WHERE t.`AOS Deal ID` IS NOT NULL
        AND t.`AOS Deal ID` != -1
        AND NOT EXISTS (
            SELECT 1
            FROM {catalog_name}.gold_ad_sales.v_wrap_detailed_unified_report_sections_by_deal s
            WHERE s.AOS_Deal_ID = t.`AOS Deal ID`
                AND s.data_type = 'DEVICE_AD_POSITION_MATRIX'
        )
    ORDER BY t.`AOS Deal ID`
""")

print("=" * 80)
print(f"Deal IDs only in v_ft_unified_campaign_delivery_by_deal Table (not in source)")
print(f"Count: {source_only_deals_dapm.count()}")
print("=" * 80)

display(source_only_deals_dapm)


# Update mismatch_details_df_dapm to include deals from source_only_deals_dapm with Status = "missing deals"
# First, convert Status to string in mismatch_details_df_dapm
mismatch_details_df_1_dapm = mismatch_details_df_dapm.withColumn(
    "Status",
    when(col("Status") == True, lit("True"))
    .when(col("Status") == False, lit("False"))
    .otherwise(col("Status").cast("string"))
)

# Create a dataframe for missing deals with the same structure as mismatch_details_df_dapm
missing_deals_df_dapm = source_only_deals_dapm.select(
    col("AOS_Deal_ID").alias("deal_id"),
    lit("missing deals").cast("string").alias("Status"),
    lit("Deal not found in source table").cast("string").alias("Mismatched_Columns")
)

display(missing_deals_df_dapm)
display(mismatch_details_df_1_dapm)

# Option 1: Use a broadcast join with a flag, then check if deal_id exists in source_only_deals_dapm
from pyspark.sql.functions import broadcast

# Create a set of deal_ids from source_only_deals_dapm for efficient lookup
source_only_deal_ids_dapm = source_only_deals_dapm.select(col("AOS_Deal_ID").alias("deal_id")).distinct()

# Join and check if deal_id exists in source_only_deals_dapm
mismatch_details_df_1_dapm = mismatch_details_df_1_dapm.join(
    broadcast(source_only_deal_ids_dapm).withColumn("is_source_only", lit(True)),
    on="deal_id",
    how="left"
).withColumn(
    "Status",
    when(col("is_source_only").isNotNull(), lit("not found in source").cast("string"))
    .otherwise(col("Status").cast("string"))
).select(
    col("deal_id"),
    col("Status").cast("string").alias("Status"),
    col("Mismatched_Columns")
)

# Union with missing_deals_df_dapm to include all deals that are only in target table
mismatch_details_df_1_dapm = mismatch_details_df_1_dapm.unionByName(
    missing_deals_df_dapm,
    allowMissingColumns=True
).distinct()

display(mismatch_details_df_1_dapm)


# Create a dataframe with deal_id and DEVICE_AD_POSITION_MATRIX (True if Status is True, False otherwise)
deal_status_df_dapm = mismatch_details_df_1_dapm.withColumn(
    "DEVICE_AD_POSITION_MATRIX",
    when(col("Status") == "True", lit("True"))
    .when(col("Status") == "False", lit("False"))
    .otherwise(col("Status"))
).select(
    col("deal_id"),
    col("DEVICE_AD_POSITION_MATRIX")
).distinct()

print("=" * 80)
print(f"Deal Status Summary")
print(f"Total Deals: {deal_status_df_dapm.count()}")
print(f"Deals with DEVICE_AD_POSITION_MATRIX = True: {deal_status_df_dapm.filter(col('DEVICE_AD_POSITION_MATRIX') == 'True').count()}")
print(f"Deals with DEVICE_AD_POSITION_MATRIX = False: {deal_status_df_dapm.filter(col('DEVICE_AD_POSITION_MATRIX') == 'False').count()}")
print("=" * 80)

display(deal_status_df_dapm)

# COMMAND ----------

deal_status_df_dapm.createOrReplaceGlobalTempView("deal_status_df_dapm")

# COMMAND ----------

from pyspark.sql.functions import lit, col, when, abs as spark_abs, stack, round as spark_round

unpivoted_df_dapm = validation_df_dapm.filter(
    col("Status") == False
).select(
    lit("DEVICE_AD_POSITION_MATRIX").alias("parse_type"),
    col("AOS_Deal_ID").alias("aos_deal_id"),
    stack(
        lit(3),
        lit("Total_Delivered_Impressions"),
        col("Source_Total_Delivered_Impressions").cast("double"),
        col("Target_Total_Delivered_Impressions").cast("double"),

        lit("Total_Delivered_Revenue"),
        col("Source_Total_Delivered_Revenue").cast("double"),
        col("Target_Total_Delivered_Revenue").cast("double"),

        lit("Total_Delivered_Clicks"),
        col("Source_Total_Delivered_Clicks").cast("double"),
        col("Target_Total_Delivered_Clicks").cast("double"),
    ).alias("metric_name", "source_value", "target_value")
).withColumn(
    "mismatch_percent_variance",
    when(
        (col("source_value") == 0) & (col("target_value") == 0), lit(0.0)
    ).when(
        col("source_value") == 0, lit(100.0)
    ).otherwise(
        spark_round(
            spark_abs(col("source_value") - col("target_value")) / spark_abs(col("source_value")) * 100,
            2
        )
    )
).filter(
    col("mismatch_percent_variance") != 0
)

display(unpivoted_df_dapm)

# COMMAND ----------

table_name = "fox_bi_dev.bronze_ads.wrap_report_device_ad_position_matrix_mismatches"

if spark.catalog.tableExists(table_name):
    unpivoted_df_dapm.write.mode("overwrite").saveAsTable(table_name)
else:
    unpivoted_df_dapm.write.saveAsTable(table_name)

# COMMAND ----------

dbutils.notebook.exit("success")