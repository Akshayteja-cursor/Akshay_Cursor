# Databricks notebook source
spark.conf.set("spark.databricks.remoteFiltering.blockSelfJoins", "false")

# COMMAND ----------

# MAGIC %md
# MAGIC # Parse for GEO_PERFORMANCE Validation
# MAGIC

# COMMAND ----------

# Databricks notebook Target
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from datetime import datetime, date
import os
import pandas as pd

# COMMAND ----------

# Configuration
catalog_name = 'fox_bi_qa'
env = 'dev'  # or 'qa' or 'prod'

# Target: Aggregate field10 from wrap_detailed_unified_report_sections_by_deal
# Filter for GEO_PERFORMANCE data_type and sum field10 (which contains Total_Delivered_Impressions as string)
tar_df_gp = spark.sql(f"""
    SELECT 
        AOS_Deal_ID,
        SUM(try_cast(field3 AS BIGINT)) as `Target Total Delivered Impressions`,
        COUNT(DISTINCT field1) as `Target Total Countries`,
        COUNT(DISTINCT field2) as `Target Total States`
    FROM {catalog_name}.gold_ad_sales.v_wrap_detailed_unified_report_sections_by_deal
    WHERE data_type = 'GEO_PERFORMANCE'
    GROUP BY AOS_Deal_ID
""")

display(tar_df_gp)

# Source: Get Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
src_df_gp = spark.sql(f"""
with unified_geo_performance as (
    select 
                aos_deal_id, 
                country_name, 
                state_province_name, 
                SUM(`Delivered_Impressions`) as delivered_impressions, 
                SUM(`Delivered_Clicks`) as delivered_clicks,
                CASE
                    WHEN SUM(`Delivered_Impressions`) > 0 THEN ROUND((SUM(`Delivered_Clicks`) / SUM(`Delivered_Impressions`) * 100), 4)
                    ELSE 0
                END AS field5
            from 
                fox_bi_qa.gold_ad_sales.ft_unified_campaign_geo_delivery
            -- where aos_deal_id = 18381
            group by all
)                   

    SELECT 
        aos_deal_id as AOS_Deal_ID,
        CAST(SUM(delivered_impressions) AS BIGINT) as `Source Total Delivered Impressions`,
        CAST(COUNT(DISTINCT country_name) AS BIGINT) as `Source Total Countries`,
        CAST(COUNT(DISTINCT state_province_name) AS BIGINT) as `Source Total States`
    FROM unified_geo_performance
    inner join {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal src on src.`AOS Deal ID` = unified_geo_performance.aos_deal_id
    where country_name IS NOT NULL AND state_province_name IS NOT NULL
        and country_name <> 'N/A' and country_name <> 'Unknown'
        and state_province_name <> 'N/A' and state_province_name <> 'Unknown'
    group by aos_deal_id
    -- WHERE `AOS Deal ID` IS NOT NULL
    --     AND `AOS Deal ID` != -1
""")

display(src_df_gp)

### Validation Comparison

from pyspark.sql.functions import col, when, expr, nvl, abs, lit, array, concat_ws

# Join source and target on AOS_Deal_ID
joined_df_gp = src_df_gp.join(
    tar_df_gp,
    on="AOS_Deal_ID",
    how="full_outer"
)

display(joined_df_gp)


# Add comparison columns - only for the columns that exist
validation_df_gp = joined_df_gp.withColumn(
    "Source_Total_Delivered_Impressions",
    nvl(col("`Source Total Delivered Impressions`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Impressions",
    nvl(col("`Target Total Delivered Impressions`"), lit(0))
).withColumn(
    "Source_Total_Countries",
    nvl(col("`Source Total Countries`"), lit(0))
).withColumn(
    "Target_Total_Countries",
    nvl(col("`Target Total Countries`"), lit(0))
).withColumn(
    "Source_Total_States",
    nvl(col("`Source Total States`"), lit(0))
).withColumn(
    "Target_Total_States",
    nvl(col("`Target Total States`"), lit(0))
).withColumn(
    "Variance_Impressions",
    col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")
).withColumn(
    "Variance_Total_Countries",
    col("Source_Total_Countries") - col("Target_Total_Countries")
).withColumn(
    "Variance_Total_States",
    col("Source_Total_States") - col("Target_Total_States")
).withColumn(
    "Impressions_Match",
    when(
        abs(col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Total_Countries_Match",
    when(
        abs(col("Source_Total_Countries") - col("Target_Total_Countries")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Total_States_Match",
    when(
        abs(col("Source_Total_States") - col("Target_Total_States")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Status",
    when(
        (col("Impressions_Match") == True) &
        (col("Total_Countries_Match") == True) &
        (col("Total_States_Match") == True),
        True
    ).otherwise(False)
).select(
    col("AOS_Deal_ID"),
    col("Source_Total_Delivered_Impressions"),
    col("Target_Total_Delivered_Impressions"),
    col("Variance_Impressions"),
    col("Impressions_Match"),
    col("Source_Total_Countries"),
    col("Target_Total_Countries"),
    col("Variance_Total_Countries"),
    col("Total_Countries_Match"),
    col("Source_Total_States"),
    col("Target_Total_States"),
    col("Variance_Total_States"),
    col("Total_States_Match"),
    col("Status")
)

display(validation_df_gp)



# Create a dataframe showing which columns have mismatches for deals where Status is False
mismatch_details_df_gp = validation_df_gp.withColumn(
    "Mismatched_Columns_Array",
    array(
        when(col("Impressions_Match") == False, lit("Impressions")).otherwise(lit(None)),
        when(col("Total_Countries_Match") == False, lit("Total_Countries")).otherwise(lit(None)),
        when(col("Total_States_Match") == False, lit("Total_States")).otherwise(lit(None))
    )
).withColumn(
    "Mismatched_Columns_Array",
    expr("filter(Mismatched_Columns_Array, x -> x is not null)")
).withColumn(
    "Mismatched_Columns",
    concat_ws(", ", col("Mismatched_Columns_Array"))
).select(
    col("AOS_Deal_ID").alias("deal_id"),
    col("Status"),
    col("Mismatched_Columns")
).distinct()

print("=" * 80)
print(f"Deal Mismatch Details")
print(f"Total Deals with Mismatches: {mismatch_details_df_gp.count()}")
print("=" * 80)

display(mismatch_details_df_gp)

# Find deal_ids that are only in target table and not in source table
source_only_deals_gp = spark.sql(f"""
    SELECT 
        t.`AOS Deal ID` as AOS_Deal_ID,
        t.`Total Delivered Impressions` as `Target Total Delivered Impressions`,
        t.`Total Countries` as `Target Total Countries`,
        t.`Total States` as `Target Total States`
    FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal t
    WHERE t.`AOS Deal ID` IS NOT NULL
        AND t.`AOS Deal ID` != -1
        AND t.`Total Countries`!=0
        AND t.`Total States`!=0
        AND NOT EXISTS (
            SELECT 1
            FROM {catalog_name}.gold_ad_sales.v_wrap_detailed_unified_report_sections_by_deal s
            WHERE s.AOS_Deal_ID = t.`AOS Deal ID`
                AND s.data_type = 'GEO_PERFORMANCE'
        )
    ORDER BY t.`AOS Deal ID`
""")

print("=" * 80)
print(f"Deal IDs only in v_ft_unified_campaign_delivery_by_deal Table (v_ft_unified_campaign_delivery_by_deal)")
print(f"Count: {source_only_deals_gp.count()}")
print("=" * 80)

display(source_only_deals_gp)

# Update mismatch_details_df_gp to include deals from source_only_deals_gp with Status = "missing deals"
# First, convert Status to string in mismatch_details_df_gp to allow "missing deals" value
mismatch_details_df_1_gp = mismatch_details_df_gp.withColumn(
    "Status",
    when(col("Status") == True, lit("True"))
    .when(col("Status") == False, lit("False"))
    .otherwise(col("Status").cast("string"))
)

# Create a dataframe for missing deals with the same structure as mismatch_details_df_gp
missing_deals_df_gp = source_only_deals_gp.select(
    col("AOS_Deal_ID").alias("deal_id"),
    lit("missing deals").alias("Status"),
    lit("Deal not found in source table").alias("Mismatched_Columns")
)

display(missing_deals_df_gp)

display(mismatch_details_df_1_gp)

# Option 1: Use a broadcast join with a flag, then check if deal_id exists in source_only_deals_gp
from pyspark.sql.functions import broadcast

# Create a set of deal_ids from source_only_deals_gp for efficient lookup
source_only_deal_ids_gp = source_only_deals_gp.select(col("AOS_Deal_ID").alias("deal_id")).distinct()

# Join and check if deal_id exists in source_only_deals_gp
mismatch_details_df_1_gp = mismatch_details_df_1_gp.join(
    broadcast(source_only_deal_ids_gp).withColumn("is_source_only", lit(True)),
    on="deal_id",
    how="left"
).withColumn(
    "Status",
    when(col("is_source_only").isNotNull(), lit("not found in source").cast("string"))
    .otherwise(col("Status").cast("string"))
).select(
    col("deal_id"),
    col("Status").cast("string").alias("Status"),
    col("Mismatched_Columns")
)

# Union with missing_deals_df_gp to include all deals that are only in target table
mismatch_details_df_1_gp = mismatch_details_df_1_gp.unionByName(
    missing_deals_df_gp,
    allowMissingColumns=True
).distinct()

display(mismatch_details_df_1_gp)



# Create a dataframe with deal_id and GEO_PERFORMANCE (True if Status is True, False otherwise)
deal_status_df_gp = mismatch_details_df_1_gp.withColumn(
    "GEO_PERFORMANCE",
    when(col("Status") == "True", lit("True"))
    .when(col("Status") == "False", lit("False"))
    .otherwise(col("Status"))
).select(
    col("deal_id"),
    col("GEO_PERFORMANCE")
).distinct()

print("=" * 80)
print(f"Deal Status Summary")
print(f"Total Deals: {deal_status_df_gp.count()}")
print(f"Deals with GEO_PERFORMANCE = True: {deal_status_df_gp.filter(col('GEO_PERFORMANCE') == 'True').count()}")
print(f"Deals with GEO_PERFORMANCE = False: {deal_status_df_gp.filter(col('GEO_PERFORMANCE') == 'False').count()}")
print("=" * 80)

display(deal_status_df_gp)

# COMMAND ----------

deal_status_df_gp.createOrReplaceGlobalTempView("deal_status_df_gp")

# COMMAND ----------

from pyspark.sql.functions import lit, col, when, abs as spark_abs, stack, round as spark_round

unpivoted_df_gp = validation_df_gp.filter(
    col("Status") == False
).select(
    lit("GEO_PERFORMANCE").alias("parse_type"),
    col("AOS_Deal_ID").alias("aos_deal_id"),
    stack(
        lit(3),
        lit("Total_Delivered_Impressions"),
        col("Source_Total_Delivered_Impressions").cast("double"),
        col("Target_Total_Delivered_Impressions").cast("double"),

        lit("Total_Countries"),
        col("Source_Total_Countries").cast("double"),
        col("Target_Total_Countries").cast("double"),

        lit("Total_States"),
        col("Source_Total_States").cast("double"),
        col("Target_Total_States").cast("double"),
    ).alias("metric_name", "source_value", "target_value")
).withColumn(
    "mismatch_percent_variance",
    when(
        (col("source_value") == 0) & (col("target_value") == 0), lit(0.0)
    ).when(
        col("source_value") == 0, lit(100.0)
    ).otherwise(
        spark_round(
            spark_abs(col("source_value") - col("target_value")) / spark_abs(col("source_value")) * 100,
            2
        )
    )
).filter(
    col("mismatch_percent_variance") != 0
)

display(unpivoted_df_gp)

# COMMAND ----------

table_name = "fox_bi_dev.bronze_ads.wrap_report_geo_performance_mismatches"

if spark.catalog.tableExists(table_name):
    unpivoted_df_gp.write.mode("overwrite").saveAsTable(table_name)
else:
    unpivoted_df_gp.write.saveAsTable(table_name)

# COMMAND ----------

dbutils.notebook.exit("success")