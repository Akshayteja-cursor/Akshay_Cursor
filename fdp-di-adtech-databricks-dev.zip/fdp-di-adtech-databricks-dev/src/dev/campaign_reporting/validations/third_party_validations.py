# Databricks notebook source
global s3_bucket, aws_profile
catalog_name = dbutils.widgets.get('catalog_name')
raw_schema_name = dbutils.widgets.get('raw_schema_name')
aws_arn = dbutils.widgets.get('aws_arn')
aws_profile = dbutils.widgets.get('aws_profile')
from_email = dbutils.widgets.get('from_email')

# COMMAND ----------

import os
os.environ["AWS_PROFILE_VAR"] = aws_profile
os.environ["AWS_ARN"] = aws_arn

# COMMAND ----------

# MAGIC %sh
# MAGIC aws configure set region us-west-2 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set s3.signature_version s3v4 --profile $AWS_PROFILE_VAR
# MAGIC aws configure set credential_source Ec2InstanceMetadata --profile $AWS_PROFILE_VAR
# MAGIC aws configure set role_arn $AWS_ARN --profile $AWS_PROFILE_VAR

# COMMAND ----------

from typing import Any
import json
import time
from datetime import datetime, timedelta
from dataclasses import dataclass
import requests
import boto3
import pyspark.sql.functions as F
import pyspark.sql.types as T
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
import io

# COMMAND ----------

@dataclass
class AdjusterCredentials:
    public_key: str
    private_key: str

    @classmethod
    def from_secret(cls, secret_arn: str) -> 'AdjusterCredentials':
        try:
            session = boto3.Session(profile_name=aws_profile)
            resp = session.client('secretsmanager').get_secret_value(SecretId=secret_arn)
            secret = json.loads(resp['SecretString'])
            ajuster_creds_cls = cls(public_key=secret['public_key'], private_key=secret['private_key'])
            return ajuster_creds_cls
        except:
            raise Exception(f'Could not load Adjuster credentials from secret {secret_arn}')

# COMMAND ----------

def download_report_to_s3(adjuster_credentials: AdjusterCredentials, report_name: str, report_date: datetime) -> str:
    # Report IDs from Ad-juster API:
    # https://pub.doubleverify.com/campaign-delivery/adjuster-api/reports
    reports_to_id = {
        'campaign_delivery': 37298, #37329,
    }
    report_id = reports_to_id[report_name]

    # Run Report by ID
    report_run = f'https://pub.doubleverify.com/campaign-delivery/adjuster-api/reports/run/{report_id}?email=false'
    report_run_r = requests.get(report_run, auth=(adjuster_credentials.public_key, adjuster_credentials.private_key))
    if report_run_r.status_code != 200:
        raise requests.HTTPError(
            report_run_r.status_code,
            'Report could not be run',
            report_name,
        )
    
    # Wait for completion or failure
    report_run_status = -1
    while report_run_status != 3:
        report_status = f'https://pub.doubleverify.com/campaign-delivery/adjuster-api/reports/runs/{report_id}?count=1'
        report_status_r = requests.get(report_status, auth=(adjuster_credentials.public_key, adjuster_credentials.private_key))
        content = report_status_r.content.decode('utf8')
        print(f'report status = {content}')
        for report in report_status_r.json()['data']:
            report_run_id = report['runId']
            report_run_status = report['status']
        if report_run_status not in {0, 1, 3}:
            # 0 = queued/triggered/requested
            # 1 = running
            # 3 = completed
            raise requests.HTTPError(
                report_run_status,
                'Report failed to complete run',
                report_name,
            )
        if report_run_status != 3:
            time.sleep(40)

    # Download report
    reports_to_key = {
        'campaign_delivery': 'Campaign_Delivery_Daily_validation',
    }
    report_s3_pfx = 'adtech/adjuster/'
    report_name_base = reports_to_key[report_name]

    report_dl = f'https://pub.doubleverify.com/campaign-delivery/adjuster-api/reports/download/{report_run_id}'
    report_dl_r = requests.get(report_dl, auth=(adjuster_credentials.public_key, adjuster_credentials.private_key))

    s3_key = report_s3_pfx + report_name_base + report_date.strftime('_%Y%m%d') + '.csv.gz'

    session = boto3.Session(profile_name=aws_profile)
    s3_client = session.client('s3')
    s3_client.put_object(
        Bucket=s3_bucket,
        Body=report_dl_r.content,
        Key=s3_key,
    )
    return s3_key

# COMMAND ----------

def load_format_df(third_party_df):
    
    column_format_info = {
        'Ad Unit Id': ['ad_unit_id', T.LongType()],
        'Ad Unit Name': ['ad_unit_name', T.StringType()],
        'Creative Name': ['creative_name', T.StringType()],
        'Creative Identifier': ['creative_id', T.StringType()],
        'Order ID': ['order_id', T.LongType()],
        'Order Name': ['order_name', T.StringType()],
        'Mapped Local Creative Name': ['mapped_local_creative_name', T.StringType()],
        'Mapped Local Creative Id': ['mapped_local_creative_id', T.StringType()],
        '3rd Party Name': ['third_party_name', T.StringType()],
        '3rd Party Creative Name': ['third_party_creative_name', T.StringType()],
        '3rd Party Creative Id': ['third_party_creative_id', T.StringType()],
        'Impressions': ['impressions', T.LongType()],
        'Impressions (3rd Party)': ['impressions_third_party', T.LongType()],
        'Clicks': ['clicks', T.LongType()],
        'Clicks (3rd Party)': ['clicks_third_party', T.LongType()],
        'Report Start Date': ['report_start_date', T.DateType()],
        'Report End Date': ['report_end_date', T.DateType()],
        'Report Start Date (3rd Party)': ['report_start_date_third_party', T.DateType()],
        'Report End Date (3rd Party)': ['report_end_date_third_party', T.DateType()],
        'Campaign Start': ['campaign_start_date', T.DateType()],
        'Campaign End': ['campaign_end_date', T.DateType()],
        '3rd Party Video 0': ['third_party_video_0_percent_complete', T.LongType()],
        '3rd Party Video 100': ['third_party_video_100_percent_complete', T.LongType()],
        '3rd Party Video 25': ['third_party_video_25_percent_complete', T.LongType()],
        '3rd Party Video 50': ['third_party_video_50_percent_complete', T.LongType()],
        '3rd Party Video 75': ['third_party_video_75_percent_complete', T.LongType()],
        '3rd Party Video Views': ['third_party_video_views', T.LongType()],
        '3rd Party Total Video Plays': ['third_party_total_video_plays', T.LongType()],
        '3rd Party Advertiser Id': ['third_party_advertiser_id', T.LongType()],
        '3rd Party Advertiser Name': ['third_party_advertiser_name', T.StringType()],
        '3rd Party Agency Id': ['third_party_agency_id', T.StringType()],
        '3rd Party Agency Name': ['third_party_agency_name', T.StringType()],
        'Unsplit 3rd Party Clicks': ['unsplit_third_party_clicks', T.LongType()],
        'Unsplit 3rd Party Impressions': ['unsplit_third_party_impressions', T.LongType()],
        '3rd Party In Target Impressions': ['third_party_in_target_impressions', T.LongType()],
        '3rd Party On Target Imps': ['third_party_on_target_impressions', T.LongType()],
        '3rd Party Billable Impressions': ['third_party_billable_impressions', T.LongType()],
        '3rd Party Non-Billable Impressions': ['third_party_non-billable_impressions', T.LongType()],
        '3rd Party Non-Billable Clicks': ['third_party_non-billable_clicks', T.LongType()],
        '3rd Party Billable Clicks': ['third_party_billable_clicks', T.LongType()],
        '3rd Party Billable Server': ['third_party_billable_server', T.StringType()],
        '3rd Party Campaign Id': ['third_party_campaign_id', T.StringType()],
        '3rd Party Campaign Name': ['third_party_campaign_name', T.StringType()],
        '3rd Party Cost': ['third_party_cost', T.DoubleType()],
        '3rd Party Impressions Analyzed': ['third_party_impressions_analyzed', T.LongType()],
        '3rd Party Placement ID': ['third_party_placement_id', T.StringType()],
        '3rd Party Placement Name': ['third_party_placement_name', T.StringType()],
        '3rd Party Revenue': ['third_party_revenue', T.DoubleType()],
        '3rd Party Requests': ['third_party_requests', T.LongType()],
        '3rd Party Server': ['third_party_server', T.StringType()],
        '3rd Party Targeting Description': ['third_party_targeting_description', T.StringType()],
        '3rd Party Timezone': ['third_party_timezone', T.StringType()],
        '3rd Party Total Demo Impressions': ['third_party_total_demo_impressions', T.LongType()],
        '3rd Party Views': ['third_party_views', T.LongType()],
        'Views': ['views', T.LongType()],
        'Total Video Plays': ['total_video_plays', T.LongType()],
        'Video 75': ['video_75_percent_complete', T.LongType()],
        'Video 50': ['video_50_percent_complete', T.LongType()],
        'Video 25': ['video_25_percent_complete', T.LongType()],
        'Video 100': ['video_100_percent_complete', T.LongType()],
        'Video 0': ['video_0_percent_complete', T.LongType()],
        'Video 25 Rate': ['video_25_rate', T.DoubleType()],
        'Video Completion Rate': ['video_completion_rate', T.DoubleType()],
        'Video Views': ['video_views', T.LongType()],
        'Viewable Impressions': ['viewable_impressions', T.LongType()],
        'Net Cost': ['net_cost', T.DoubleType()],
        'Agency Id': ['agency_id', T.StringType()],
        'Agency Name': ['agency_name', T.StringType()],
        'Advertiser': ['advertiser_name', T.StringType()],
        'Advertiser ID': ['advertiser_id', T.LongType()],
        'Campaign Identifier': ['campaign_id', T.StringType()],
        'Campaign Name': ['campaign_name', T.StringType()],
        'Contracted Impressions': ['contracted_impressions', T.LongType()],
        'Contracted Revenue': ['contracted_revenue', T.DoubleType()],
        'Demographic Target': ['demographic_target', T.StringType()],
        'Impressions Analyzed': ['impressions_analyzed', T.LongType()],
        'In Target Impressions': ['in_target_impressions', T.LongType()],
        'Local Server': ['local_server_type', T.StringType()],
        'Local Server Name': ['local_server_name', T.StringType()],
        'On Target Impressions': ['on_target_impressions', T.LongType()],
        'Placement ID': ['placement_id', T.StringType()],
        'Placement Name': ['placement_name', T.StringType()],
        'Total Revenue': ['total_revenue', T.DoubleType()],
        'Total Spend': ['total_spend', T.DoubleType()],
        'Report Data Date': ['report_data_date', T.DateType()],
        'event_date': ['event_date', T.DateType()],
        'created_timestamp': ['created_timestamp', T.TimestampType()],
        'Primary Trafficker': ['primary_trafficker', T.StringType()],
        'Ad Priority': ['ad_priority', T.StringType()],
        'Ad Slot Size': ['ad_slot_size', T.StringType()],
        'Megaphone Pacing Type': ['megaphone_pacing_type', T.StringType()],
        'Megaphone Priority': ['megaphone_priority', T.StringType()],
        'Audible Impressions': ['audible_impressions', T.StringType()],
        'Uniques': ['uniques', T.LongType()],
        'Campaign Billing Impressions': ['campaign_billing_impressions', T.LongType()],
        'Creative Type': ['creative_type', T.StringType()],
    }

    cols_to_be_formated_to_int = [
        'Impressions',
        'Impressions (3rd Party)',
        'Clicks',
        'Clicks (3rd Party)',
        '3rd Party Video 0',
        '3rd Party Video 100',
        '3rd Party Video 25',
        '3rd Party Video 50',
        '3rd Party Video 75',
        '3rd Party Video Views',
        '3rd Party Total Video Plays',
        '3rd Party Advertiser Id',
        'Unsplit 3rd Party Clicks',
        'Unsplit 3rd Party Impressions',
        '3rd Party In Target Impressions',
        '3rd Party On Target Imps',
        '3rd Party Billable Impressions',
        '3rd Party Non-Billable Impressions',
        '3rd Party Non-Billable Clicks',
        '3rd Party Billable Clicks',
        '3rd Party Impressions Analyzed',
        '3rd Party Requests',
        '3rd Party Total Demo Impressions',
        '3rd Party Views',
        'Views',
        'Total Video Plays',
        'Video 75',
        'Video 50',
        'Video 25',
        'Video 100',
        'Video 0',
        'Video Views',
        'Viewable Impressions',
        'Advertiser ID',
        'Contracted Impressions',
        'Impressions Analyzed',
        'In Target Impressions',
        'On Target Impressions',
        'Ad Priority',
        'Megaphone Priority',
        'Audible Impressions',
        'Uniques',
        'Campaign Billing Impressions',
        'Order ID',
    ]

    cols_to_be_formated_to_float = [
        '3rd Party Cost',
        '3rd Party Revenue',
        'Video 25 Rate',
        'Video Completion Rate',
        'Net Cost',
        'Contracted Revenue',
        'Total Revenue',
        'Total Spend',
    ]

    select_cols = []
    for col in third_party_df.columns:
        # if col != 'created_at' and col != 'updated_at':
        if col in column_format_info:
            select_cols.append(column_format_info[col][0])
            if col in cols_to_be_formated_to_int and '_id' not in column_format_info[col][0]:
                third_party_df = third_party_df.withColumn(col,
                    F.when(third_party_df[col] == 'N/A', F.lit(None).cast(T.LongType()))\
                    .when(third_party_df[col].isNull(), F.lit(None).cast(T.LongType()))\
                    .when(third_party_df[col].contains('.'), F.to_number(F.split(F.col(col), '[.]', 2)[0], F.lit('999,999,999,999,999')))\
                    .when(third_party_df[col].contains(','), F.to_number(F.col(col), F.lit('999,999,999,999,999')))\
                    .otherwise(F.to_number(F.col(col), F.lit('999999999999999')))
                )
            elif col in cols_to_be_formated_to_int and '_id' in column_format_info[col][0]:
                third_party_df = third_party_df.withColumn(col,
                    F.when(third_party_df[col] == 'N/A', F.lit(-1).cast(T.LongType()))\
                    .when(third_party_df[col].isNull(), F.lit(-1).cast(T.LongType()))\
                    .when(third_party_df[col].rlike("[a-zA-Z]"), F.lit(-2).cast(T.LongType()))\
                    .otherwise(F.to_number(F.col(col), F.lit('999999999999999')))
                )
            elif col in cols_to_be_formated_to_float:
                third_party_df = third_party_df.withColumn(col,
                    F.when(third_party_df[col] == 'N/A', F.lit(None).cast(T.DoubleType()))\
                    .when(third_party_df[col].isNull(), F.lit(None).cast(T.DoubleType()))\
                    .when(third_party_df[col].contains('$'), F.to_number(F.trim(F.regexp_replace(col, r'\$', '')), F.lit('S999,999,999,999,999.99999')))\
                    .when(third_party_df[col].contains('%'), F.to_number(F.trim(F.regexp_replace(col, r'\%', '')), F.lit('S999,999,999,999,999.99999')))\
                    .otherwise(F.to_number(F.trim(F.col(col)), F.lit('S999,999,999,999,999.99999')))
                )
            elif '_date' in column_format_info[col][0]:
                third_party_df = third_party_df.withColumn(col, F.to_date(F.col(col), 'MM/dd/yyyy'))
            else:
                if '_id' in column_format_info[col][0]:
                    third_party_df = third_party_df.withColumn(col,
                        F.when(third_party_df[col] == 'N/A', F.lit(-1).cast(T.StringType()))\
                        .when(third_party_df[col].isNull(), F.lit(-1).cast(T.StringType()))\
                        .otherwise(F.col(col).cast(column_format_info[col][1])))
                else:
                    third_party_df = third_party_df.withColumn(col,
                        F.when(third_party_df[col].isNull(), F.lit('N/A').cast(T.StringType()))\
                        .otherwise(F.col(col).cast(column_format_info[col][1])))

            third_party_df = third_party_df.withColumnRenamed(col, column_format_info[col][0])
            if '_date' not in column_format_info[col][0]:
                third_party_df = third_party_df.withColumn(column_format_info[col][0], F.col(column_format_info[col][0]).cast(column_format_info[col][1]))
        else:
            print('Column not selected : ', col)

    return third_party_df.select(select_cols)

# COMMAND ----------

def get_validation_status(validation_df):
    flag = True
    variance_column_list = [
        "Video Completes Variance %",
        "Video Views Variance %",
        "Impressions Variance %",
        "Clicks Variance %",
        "Revenue Variance %",
    ]
    for col in variance_column_list:
        if col in validation_df.columns:
            variance_values = validation_df.select(col).distinct().rdd.flatMap(lambda x: x).collect()
            for value in variance_values:
                if value is not None and value >= -0.5 and value <= 0.5:
                    pass
                else:
                    print(f'Variance found in column {col}')
                    flag = False
    return flag

# COMMAND ----------

class ReportMailInfo:
    from_email = f'{from_email}'
    reply_to_address = 'data_adtech@fox.com'
    key = ''
    info = {}
    validation_status = False
    report_mailing_lists = {
        "Third Party Delivery Data Validation Report" : {
            "key_format_string" : "third_party/AD Tech Third Party Delivery Data Validation Report_%d%b%Y.csv",
            "human_readable_name" : "ad tech third party delivery data validation report",
            "to" : [
                "prajwal.harikishor@fox.com",
                "Pradeep.Panneerselvam@fox.com",
                "Anitha.Mohanraj@fox.com",
                "yogesh.nageswararao@fox.com",
                "alimaafroseshahul.hameed@fox.com",
                "Deepthi.Chunduru@fox.com",
            ],
            "cc" : [
                "Ramesh.Madepalli@fox.com",
            ]
        }
    }

    def __init__(self, report, validation_status, report_date):
        self.info = self.report_mailing_lists[report]
        self.key = get_latest_report(report_date, self.info['key_format_string'])
        self.validation_status = validation_status

    def get_file_name(self):
        return os.path.basename(self.key)
    
    def get_report_body(self, report_date):
        footer = f'<p>This is an automated email. Please direct any questions or concerns to <a href="mailto: {self.reply_to_address}">{self.reply_to_address}</a>.</p>'
        if self.validation_status:
            body_text = f"""<p>Hello,</p>

<p>The validation status: PASS</p>

<p>Please find attached the {self.info['human_readable_name']}.</p>

{footer}
"""
        else:
            body_text = f"""<p>Hello,</p>

<p>The validation status: FAILED</p>

<p>Please find attached the {self.info['human_readable_name']}.</p>

{footer}
"""
        return MIMEText(body_text, 'html')

    def get_report_attachment(self):
        session = boto3.Session(profile_name=aws_profile)
        s3 = session.client('s3')
        resp = s3.get_object(Bucket=s3_bucket, Key=self.key)
        return resp['Body'].read()

def get_latest_report(report_date: datetime, key_format_string: str):
    session = boto3.Session(profile_name=aws_profile)
    s3 = session.client('s3')
    for delta in range(0, -7, -1):
        date = report_date + timedelta(days=delta)
        key = date.strftime(key_format_string)
        try:
            print(f'Trying object s3://{s3_bucket}/{key}')
            s3.head_object(Bucket=s3_bucket, Key=key)
            return key
        except s3.exceptions.ClientError as exc:
            if exc.response['Error']['Code'] == '404':
                continue
            raise
    raise RuntimeError('Could not find report')

def send_mail(report_name, validation_status, report_date):
    
    report = ReportMailInfo(report_name, validation_status, report_date)

    attachment_ready_html = []
    img_id = 0
    mime_images = []

    msg = MIMEMultipart()
    msg['Subject'] = report.info['human_readable_name'].title()
    msg['From'] = report.from_email
    msg['To'] = ", ".join(report.info['to'])
    msg['Cc'] = ", ".join(report.info['cc'])
    msg.attach(report.get_report_body(report_date))

    part = MIMEApplication(
        report.get_report_attachment(),
        Name=report.get_file_name(),
    )
    part['Content-Disposition'] = f'attachment; filename="{report.get_file_name()}"'
    msg.attach(part)

    session = boto3.Session(profile_name = aws_profile)
    ses = session.client('ses', region_name='us-west-2')
    ses.send_raw_email(
        Source=msg['From'],
        Destinations=list(set(report.info['to']).union(set(report.info['cc']))),
        RawMessage={'Data': msg.as_string()}
    )

    print('Email sent')

# COMMAND ----------

if __name__ == '__main__':
    date = dbutils.widgets.get('date')
    s3_bucket = dbutils.widgets.get('s3_bucket')
    aws_profile = dbutils.widgets.get('aws_profile')
    adjuster_credentials_secret_arn = dbutils.widgets.get('adjuster_credentials_secret_arn')

    REPORT_CHOICES = [
        'campaign_delivery',
    ]

    reports = ['campaign_delivery']

    def parse_date(date: str) -> bool:
        format = "%Y-%m-%d"
        try:
            res = bool(datetime.strptime(date, format))
        except ValueError:
            res = False
        return res

    assert parse_date(date), "Invalid date format, should be in YYYY-MM-DD format"
    assert adjuster_credentials_secret_arn != '', "Invalid adjuster_credentials_secret_arn"

    # Fetch Adjuster API Credentials
    adjuster_credentials = AdjusterCredentials.from_secret(adjuster_credentials_secret_arn)

    # Run report via api and download to s3
    for report in reports:
        s3_key = download_report_to_s3(adjuster_credentials, report, datetime.strptime(date, "%Y-%m-%d"))
        print('File downloaded. File path: ', s3_key)

        mount_path = f'/mnt/{s3_bucket}/'
        df = spark.read.format('csv').option('header', 'true').option('inferSchema', 'false').option('multiLine', 'true').load(f'{mount_path}/{s3_key}', skipRows=8, quote='"', escape='"')

        df = df.withColumn('event_date', F.to_date(F.col('Report End Date'), 'MM/dd/yyyy'))
        df = df.withColumn('created_timestamp', F.current_timestamp())

        df = load_format_df(df)
        df.createOrReplaceTempView('formated_third_party_data')

        source_query = """
            SELECT
                event_date
                , SUM(third_party_video_100_percent_complete) AS third_party_video_completes_source
                , SUM(third_party_video_views) AS third_party_video_views_source
                , SUM(third_party_billable_impressions) AS third_party_billable_impressions_source
                , SUM(clicks_third_party) AS third_party_clicks_source
                , SUM(third_party_revenue) AS third_party_revenue_source
            FROM formated_third_party_data
            GROUP BY ALL
        """
        source_df = spark.sql(source_query)

        # select distinct event dates
        distinct_dates = (
            df.select("event_date")
            .distinct()
            .rdd.flatMap(lambda x: x)
            .collect()
        )
        date_list_str = ",".join([f"'{d}'" for d in distinct_dates])

        table_query = f"""
            SELECT
                event_date
                , SUM(third_party_video_completes) AS third_party_video_completes_table
                , SUM(third_party_video_views) AS third_party_video_views_table
                , SUM(third_party_billable_impressions) AS third_party_billable_impressions_table
                , SUM(third_party_clicks) AS third_party_clicks_table
                , SUM(third_party_revenue) AS third_party_revenue_table
            FROM {catalog_name}.silver_ads.ft_third_party_campaign_delivery_daily_data
            WHERE event_date IN ({date_list_str})
            GROUP BY ALL
        """

        table_df = spark.sql(table_query)

        # TODO: Validate silver table against this source df
        validation_df = source_df.join(table_df, on=['event_date'], how='full_outer')
        pairs = [
            ("third_party_video_completes_source", "third_party_video_completes_table", "Video Completes Variance %"),
            ("third_party_video_views_source", "third_party_video_views_table", "Video Views Variance %"),
            ("third_party_billable_impressions_source", "third_party_billable_impressions_table", "Impressions Variance %"),
            ("third_party_clicks_source", "third_party_clicks_table", "Clicks Variance %"),
            ("third_party_revenue_source", "third_party_revenue_table", "Revenue Variance %")
        ]

        print('Performing campaign reporting source vs view validtions')
        for source_col, view_col, out_col in pairs:
            if '%' in out_col:
                validation_df = validation_df.withColumn(out_col,\
                    F.when(F.col(source_col) == 0, F.col(view_col))\
                    .otherwise(F.round((F.col(source_col) - F.col(view_col))/F.col(source_col)*100, 3))
                )
            else:
                validation_df = validation_df.withColumn(out_col,\
                    F.when(F.col(source_col) == 0, F.col(view_col))\
                    .otherwise(F.round(F.col(source_col) - F.col(view_col), 3))
                )

    validation_status = get_validation_status(validation_df)
    
    with io.StringIO() as output:
        validation_df.toPandas().to_csv(output, index=False)
        validation_data = output.getvalue()

    report_name = 'AD Tech Third Party Delivery Data Validation Report_' + datetime.today().strftime('%d%b%Y') + '.csv'
    session = boto3.Session(profile_name=aws_profile)
    s3_client = session.client('s3')
    s3_bucket = s3_bucket
    s3_key = 'third_party/' + report_name
    s3_client.put_object(
        Bucket=s3_bucket,
        Body=validation_data.encode('utf-8'),
        Key=s3_key,
    )

    send_mail('Third Party Delivery Data Validation Report', validation_status, datetime.today())