# Databricks notebook source
spark.conf.set("spark.databricks.remoteFiltering.blockSelfJoins", "false")

# COMMAND ----------

# MAGIC %md
# MAGIC # Parse for TARGET_AUDIENCE_DISTRIBUTION Validation
# MAGIC

# COMMAND ----------

# Databricks notebook Target
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from datetime import datetime, date
import os
import pandas as pd


# COMMAND ----------

# Configuration
catalog_name = 'fox_bi_qa'
env = 'dev'  # or 'qa' or 'prod'

# Target: Aggregate field10 from wrap_detailed_unified_report_sections_by_deal
# Filter for PLACEMENT_PERFORMANCE data_type and sum field10 (which contains Total_Delivered_Impressions as string)
tar_df_tad = spark.sql(f"""
    SELECT 
        AOS_Deal_ID,
        SUM(try_cast(field2 AS BIGINT)) as `Target Total Delivered Impressions`,
        CAST(COUNT(DISTINCT field1) as BIGINT) as `Target Audience_Segment Count`,
        SUM(try_cast(field3 AS DECIMAL(19,2))) as `Target Total Delivered Revenue`,
        SUM(try_cast(field4 AS BIGINT)) as `Target Total Third Party Impressions`,
        SUM(try_cast(field5 AS DECIMAL(19,2))) as `Target Total Third Party Revenue`
        -- SUM(try_cast(field7 AS BIGINT)) as `Target Total Guaranteed Impressions`,
        -- SUM(try_cast(field8 AS DECIMAL(19,2))) as `Target Total Guaranteed Revenue`,
        -- SUM(try_cast(field6 AS BIGINT)) as `Target Total Third Party Impressions`,
        -- SUM(try_cast(field7 AS DECIMAL(19,2))) as `Target Total Third Party Revenue`
    FROM {catalog_name}.gold_ad_sales.v_wrap_detailed_unified_report_sections_by_deal
    WHERE data_type = 'TARGET_AUDIENCE_DISTRIBUTION'
    GROUP BY AOS_Deal_ID
""")

display(tar_df_tad)

# Source: Get Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
src_df_tad = spark.sql(f"""

with target_audience_distribution as (
    SELECT 
        `AOS_deal ID` AS aos_deal_id
        ,`FW Audience Segment` AS fw_audience_segment
        ,sum(`Delivered Impressions`) AS delivered_impressions
        ,sum(`Delivered Revenue`) AS delivered_revenue
    FROM fox_bi_qa.gold_ad_sales.v_ft_freewheel_campaign_delivery
    -- WHERE `AOS_Deal ID` = ?
    GROUP BY 1,2  
)
, fw_third_party_at_target_audience as (
    SELECT
                    pl.`AOS_Deal ID` as aos_deal_id
                    , pl.`FW Audience Segment` as target_audience
                    , SUM(third_party_impressions) as placement_third_party_impressions
                    , SUM(third_party_revenue) as placement_third_party_revenue
                FROM (
                    SELECT DISTINCT
                        `AOS_Deal ID`,
                        `Placement ID`,
                        `Creative ID`,
                        `Event Date`,
                        `Ad Unit Position`,
                        `FW Audience Segment`,
                        MIN(`Third Party Billable Impressions`) as third_party_impressions,
                        MIN(`Third Party Revenue`) as third_party_revenue
                    FROM fox_bi_qa.gold_ad_sales.v_ft_freewheel_campaign_delivery
                    GROUP BY
                        `AOS_Deal ID`,
                        `Placement ID`,
                        `Creative ID`,
                        `Event Date`,
                        `Ad Unit Position`,
                        `FW Audience Segment`
                ) pl
                GROUP BY pl.`AOS_Deal ID`, pl.`FW Audience Segment`
)
select 
1p.aos_deal_id as AOS_Deal_ID,
CAST(count(DISTINCT fw_audience_segment) AS BIGINT) as `Source Audience_Segment Count`,
CAST(sum(delivered_impressions) AS BIGINT) as `Source Total Delivered Impressions`,
sum(delivered_revenue) as `Source Total Delivered Revenue`,
sum(3p.placement_third_party_impressions) as `Source Third Party Impressions`,
sum(3p.placement_third_party_revenue) as `Source Third Party Revenue`
from target_audience_distribution 1p
left join fw_third_party_at_target_audience 3p
on 1p.aos_deal_id = 3p.aos_deal_id and upper(1p.fw_audience_segment) = upper(3p.target_audience)
group by 1p.AOS_Deal_ID

""")

display(src_df_tad)


### Validation Comparison
from pyspark.sql.functions import col, when, expr, nvl, abs, lit, array, concat_ws

# Join source and target on AOS_Deal_ID
joined_df_tad = src_df_tad.join(
    tar_df_tad,
    on="AOS_Deal_ID",
    how="full_outer"
)

display(joined_df_tad)


# Add comparison columns
validation_df_tad = joined_df_tad.withColumn(
    "Source_Total_Delivered_Impressions",
    nvl(col("`Source Total Delivered Impressions`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Impressions",
    nvl(col("`Target Total Delivered Impressions`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Revenue",
    nvl(col("`Source Total Delivered Revenue`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Revenue",
    nvl(col("`Target Total Delivered Revenue`"), lit(0))
).withColumn(
    "Source_Audience_Segment_Count",
    nvl(col("`Source Audience_Segment Count`"), lit(0))
).withColumn(
    "Target_Audience_Segment_Count",
    nvl(col("`Target Audience_Segment Count`"), lit(0))
).withColumn(
    "Source_Third_Party_Impressions",
    nvl(col("`Source Third Party Impressions`"), lit(0))
).withColumn(
    "Target_Third_Party_Impressions",
    nvl(col("`Target Total Third Party Impressions`"), lit(0))
).withColumn(
    "Source_Third_Party_Revenue",
    nvl(col("`Source Third Party Revenue`"), lit(0))
).withColumn(
    "Target_Third_Party_Revenue",
    nvl(col("`Target Total Third Party Revenue`"), lit(0))
).withColumn(
    "Variance_Delivered_Impressions",
    col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")
).withColumn(
    "Variance_Delivered_Revenue",
    col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")
).withColumn(
    "Variance_Audience_Segment_Count",
    col("Source_Audience_Segment_Count") - col("Target_Audience_Segment_Count")
).withColumn(
    "Variance_Third_Party_Impressions",
    col("Source_Third_Party_Impressions") - col("Target_Third_Party_Impressions")
).withColumn(
    "Variance_Third_Party_Revenue",
    col("Source_Third_Party_Revenue") - col("Target_Third_Party_Revenue")
).withColumn(
    "Delivered_Impressions_Match",
    when(
        abs(col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Delivered_Revenue_Match",
    when(
        abs(col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Audience_Segment_Count_Match",
    when(
        abs(col("Source_Audience_Segment_Count") - col("Target_Audience_Segment_Count")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Third_Party_Impressions_Match",
    when(
        abs(col("Source_Third_Party_Impressions") - col("Target_Third_Party_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Third_Party_Revenue_Match",
    when(
        abs(col("Source_Third_Party_Revenue") - col("Target_Third_Party_Revenue")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Status",
    when(
        (col("Delivered_Impressions_Match") == True) &
        (col("Delivered_Revenue_Match") == True) &
        (col("Audience_Segment_Count_Match") == True) &
        (col("Third_Party_Impressions_Match") == True) &
        (col("Third_Party_Revenue_Match") == True),
        True
    ).otherwise(False)
).select(
    col("AOS_Deal_ID"),
    col("Source_Total_Delivered_Impressions"),
    col("Target_Total_Delivered_Impressions"),
    col("Variance_Delivered_Impressions"),
    col("Delivered_Impressions_Match"),
    col("Source_Total_Delivered_Revenue"),
    col("Target_Total_Delivered_Revenue"),
    col("Variance_Delivered_Revenue"),
    col("Delivered_Revenue_Match"),
    col("Source_Audience_Segment_Count"),
    col("Target_Audience_Segment_Count"),
    col("Variance_Audience_Segment_Count"),
    col("Audience_Segment_Count_Match"),
    col("Source_Third_Party_Impressions"),
    col("Target_Third_Party_Impressions"),
    col("Variance_Third_Party_Impressions"),
    col("Third_Party_Impressions_Match"),
    col("Source_Third_Party_Revenue"),
    col("Target_Third_Party_Revenue"),
    col("Variance_Third_Party_Revenue"),
    col("Third_Party_Revenue_Match"),
    col("Status")
)

display(validation_df_tad)


# Create a dataframe showing which columns have mismatches for deals where Status is False
mismatch_details_df_tad = validation_df_tad.withColumn(
    "Mismatched_Columns_Array",
    array(
        when(col("Delivered_Impressions_Match") == False, lit("Delivered_Impressions")).otherwise(lit(None)),
        when(col("Delivered_Revenue_Match") == False, lit("Delivered_Revenue")).otherwise(lit(None)),
        when(col("Audience_Segment_Count_Match") == False, lit("Audience_Segment_Count")).otherwise(lit(None)),
        when(col("Third_Party_Impressions_Match") == False, lit("Third_Party_Impressions")).otherwise(lit(None)),
        when(col("Third_Party_Revenue_Match") == False, lit("Third_Party_Revenue")).otherwise(lit(None))
    )
).withColumn(
    "Mismatched_Columns_Array",
    expr("filter(Mismatched_Columns_Array, x -> x is not null)")
).withColumn(
    "Mismatched_Columns",
    concat_ws(", ", col("Mismatched_Columns_Array"))
).select(
    col("AOS_Deal_ID").alias("deal_id"),
    when(col("Status") == True, lit("True"))
    .when(col("Status") == False, lit("False"))
    .otherwise(lit("False")).cast("string").alias("Status"),
    col("Mismatched_Columns")
).distinct()

print("=" * 80)
print(f"Deal Mismatch Details")
print(f"Total Deals with Mismatches: {mismatch_details_df_tad.count()}")
print("=" * 80)

display(mismatch_details_df_tad)


# Find deal_ids that are only in tar_df (wrap report) and not in src_df (freewheel)
source_only_deals_tad = spark.sql(f"""
    SELECT 
        t.AOS_Deal_ID,
        SUM(try_cast(t.field2 AS BIGINT)) AS `Target Total Delivered Impressions`,
        CAST(COUNT(DISTINCT t.field1) AS BIGINT) AS `Target Audience_Segment Count`,
        SUM(try_cast(t.field3 AS DECIMAL(19,2))) AS `Target Total Delivered Revenue`,
        SUM(try_cast(t.field4 AS BIGINT)) AS `Target Total Third Party Impressions`,
        SUM(try_cast(t.field5 AS DECIMAL(19,2))) AS `Target Total Third Party Revenue`
    FROM {catalog_name}.gold_ad_sales.v_wrap_detailed_unified_report_sections_by_deal t
    WHERE t.data_type = 'TARGET_AUDIENCE_DISTRIBUTION'
        AND t.AOS_Deal_ID IS NOT NULL
        AND NOT EXISTS (
            SELECT 1
            FROM fox_bi_qa.gold_ad_sales.v_ft_freewheel_campaign_delivery s
            WHERE s.`AOS_deal ID` = t.AOS_Deal_ID
        )
    GROUP BY t.AOS_Deal_ID
    ORDER BY t.AOS_Deal_ID
""")

print("=" * 80)
print(f"Deal IDs only in v_wrap_detailed_unified_report_sections_by_deal (TARGET_AUDIENCE_DISTRIBUTION) Table")
print(f"Count: {source_only_deals_tad.count()}")
print("=" * 80)

display(source_only_deals_tad)


# Update mismatch_details_df_tad to include missing deals
mismatch_details_df_1_tad = mismatch_details_df_tad.withColumn(
    "Status",
    when(col("Status") == True, lit("True"))
    .when(col("Status") == False, lit("False"))
    .otherwise(col("Status").cast("string"))
)

# Create a dataframe for missing deals with the same structure
missing_deals_df_tad = source_only_deals_tad.select(
    col("AOS_Deal_ID").alias("deal_id"),
    lit("missing deals").cast("string").alias("Status"),
    lit("Deal not found in source table").cast("string").alias("Mismatched_Columns")
)

display(missing_deals_df_tad)
display(mismatch_details_df_1_tad)

from pyspark.sql.functions import broadcast

source_only_deal_ids_tad = source_only_deals_tad.select(col("AOS_Deal_ID").alias("deal_id")).distinct()

mismatch_details_df_1_tad = mismatch_details_df_1_tad.join(
    broadcast(source_only_deal_ids_tad).withColumn("is_source_only", lit(True)),
    on="deal_id",
    how="left"
).withColumn(
    "Status",
    when(col("is_source_only").isNotNull(), lit("not found in source").cast("string"))
    .otherwise(col("Status").cast("string"))
).select(
    col("deal_id"),
    col("Status").cast("string").alias("Status"),
    col("Mismatched_Columns")
)

mismatch_details_df_1_tad = mismatch_details_df_1_tad.unionByName(
    missing_deals_df_tad,
    allowMissingColumns=True
).distinct()

display(mismatch_details_df_1_tad)


# Create a dataframe with deal_id and TARGET_AUDIENCE_DISTRIBUTION status
deal_status_df_tad = mismatch_details_df_1_tad.select(
    col("deal_id"),
    when(col("Status") == "True", lit("True"))
    .when(col("Status") == "False", lit("False"))
    .otherwise(col("Status"))
    .alias("TARGET_AUDIENCE_DISTRIBUTION")
).distinct()

print("=" * 80)
print(f"Deal Status Summary")
print(f"Total Deals: {deal_status_df_tad.count()}")
print(f"Deals with TARGET_AUDIENCE_DISTRIBUTION = True: {deal_status_df_tad.filter(col('TARGET_AUDIENCE_DISTRIBUTION') == 'True').count()}")
print(f"Deals with TARGET_AUDIENCE_DISTRIBUTION = False: {deal_status_df_tad.filter(col('TARGET_AUDIENCE_DISTRIBUTION') == 'False').count()}")
print("=" * 80)

display(deal_status_df_tad)

# COMMAND ----------

deal_status_df_tad.createOrReplaceGlobalTempView("deal_status_df_tad")

# COMMAND ----------

from pyspark.sql.functions import lit, col, when, abs as spark_abs, stack, round as spark_round

unpivoted_df_tad = validation_df_tad.filter(
    col("Status") == False
).select(
    lit("TARGET_AUDIENCE_DISTRIBUTION").alias("parse_type"),
    col("AOS_Deal_ID").alias("aos_deal_id"),
    stack(
        lit(5),
        lit("Total_Delivered_Impressions"),
        col("Source_Total_Delivered_Impressions").cast("double"),
        col("Target_Total_Delivered_Impressions").cast("double"),

        lit("Total_Delivered_Revenue"),
        col("Source_Total_Delivered_Revenue").cast("double"),
        col("Target_Total_Delivered_Revenue").cast("double"),

        lit("Audience_Segment_Count"),
        col("Source_Audience_Segment_Count").cast("double"),
        col("Target_Audience_Segment_Count").cast("double"),

        lit("Third_Party_Impressions"),
        col("Source_Third_Party_Impressions").cast("double"),
        col("Target_Third_Party_Impressions").cast("double"),

        lit("Third_Party_Revenue"),
        col("Source_Third_Party_Revenue").cast("double"),
        col("Target_Third_Party_Revenue").cast("double"),
    ).alias("metric_name", "source_value", "target_value")
).withColumn(
    "mismatch_percent_variance",
    when(
        (col("source_value") == 0) & (col("target_value") == 0), lit(0.0)
    ).when(
        col("source_value") == 0, lit(100.0)
    ).otherwise(
        spark_round(
            spark_abs(col("source_value") - col("target_value")) / spark_abs(col("source_value")) * 100,
            2
        )
    )
).filter(
    col("mismatch_percent_variance") != 0
)

display(unpivoted_df_tad)

# COMMAND ----------

table_name = "fox_bi_dev.bronze_ads.wrap_report_target_audience_distribution_mismatches"

if spark.catalog.tableExists(table_name):
    unpivoted_df_tad.write.mode("overwrite").saveAsTable(table_name)
else:
    unpivoted_df_tad.write.saveAsTable(table_name)

    

# COMMAND ----------

dbutils.notebook.exit("success")