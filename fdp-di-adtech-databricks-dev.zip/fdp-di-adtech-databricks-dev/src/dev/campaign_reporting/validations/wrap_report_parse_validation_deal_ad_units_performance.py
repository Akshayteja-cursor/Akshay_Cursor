# Databricks notebook source
spark.conf.set("spark.databricks.remoteFiltering.blockSelfJoins", "false")

# COMMAND ----------

# MAGIC %md
# MAGIC # Parse for DEAL_AD_UNITS_PERFORMANCE Validation
# MAGIC

# COMMAND ----------

# Databricks notebook Target
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from datetime import datetime, date
import os
import pandas as pd

# COMMAND ----------

# Configuration
catalog_name = 'fox_bi_qa'
env = 'dev'  # or 'qa' or 'prod'


# Target: Aggregate field10 from wrap_detailed_unified_report_sections_by_deal
# Filter for DEAL_AD_UNITS_PERFORMANCE data_type and sum field10 (which contains Total_Delivered_Impressions as string)
tar_df_daup = spark.sql(f"""
    SELECT 
        AOS_Deal_ID,
        SUM(try_cast(field5 AS BIGINT)) as `Target Total Creatives`,
        SUM(try_cast(field2 AS BIGINT)) as `Target Total Delivered Impressions`,
        SUM(try_cast(field3 AS DECIMAL(19,2))) as `Target Total Delivered Revenue`
    FROM {catalog_name}.gold_ad_sales.v_wrap_detailed_unified_report_sections_by_deal
    WHERE data_type = 'DEAL_AD_UNITS_PERFORMANCE'
    GROUP BY AOS_Deal_ID
""")

display(tar_df_daup)


# Source: Get Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
src_df_daup = spark.sql(f"""
with fw_placement_level as (
    SELECT
        `AOS_Deal Name` AS aos_deal_name,
        `AOS_Deal ID` AS aos_deal_id,
        pl.`Campaign Start Date` AS campaign_start_date,
        pl.`Campaign End Date` AS campaign_end_date,
        pl.`Advertiser Name` AS advertiser_name,
        pl.`Agency Name` AS agency_name,
        pl.`Sales Channel Type` AS line_item_type,
        pl.`Placement ID` AS placement_id,
        pl.`Placement Name` AS placement_name,
        pl.`Package Name` AS package_name,
        pl.`Parent Line Item Name` AS parent_line_item_name,
        pl.`AOS Deal Line Item Name` AS aos_deal_line_item_name,
        pl.`Creative ID` AS creative_id,
        pl.`Creative Name` AS creative_name,
        pl.`Creative Duration` AS creative_duration,
        pl.`Device` AS device,
        pl.`Ad Unit Position` AS ad_unit_position,
        pl.`Video Vertical` AS video_vertical,
        pl.`Show Name` AS show_name,
        pl.`Deal Ad Units` AS deal_ad_units,
        pl.`Demo Band` AS demo_band,
        pl.`Event Date` AS event_date,
        MAX(pl.`Guaranteed Impressions`) as guaranteed_impressions,
        MAX(pl.`Guaranteed Revenue`) as guaranteed_revenue,
        MAX(`Net Unit Cost`) as net_unit_cost,
        SUM(pl.`Delivered Impressions`) as delivered_impressions,
        SUM(pl.`Delivered Clicks`) as delivered_clicks,
        SUM(pl.`Delivered Revenue`) as delivered_revenue,
        SUM(pl.`On Target Net Delivered Impressions`) as on_target_impressions
    FROM fox_bi_qa.gold_ad_sales.v_ft_freewheel_campaign_delivery pl
    -- WHERE `AOS_Deal ID` = 18683
    GROUP BY
         `AOS_Deal ID`,
        `AOS_Deal Name`,
        pl.`Campaign Start Date`,
        pl.`Campaign End Date`,
        pl.`Advertiser Name`,
        pl.`Agency Name`,
        pl.`Sales Channel Type`,
        pl.`Placement ID`,
        pl.`Placement Name`,
        pl.`Package Name`,
        pl.`Parent Line Item Name`,
        pl.`AOS Deal Line Item Name`,
        pl.`Creative ID`,
        pl.`Creative Name`,
        pl.`Creative Duration`,
        pl.`Device`,
        pl.`Ad Unit Position`,
        pl.`Video Vertical`,
        pl.`Show Name`,
        pl.`Deal Ad Units`,
        pl.`Event Date`,
        pl.`Demo Band`
)                   


    SELECT 
        aos_deal_id as AOS_Deal_ID,
        CAST(COUNT(DISTINCT creative_id) AS BIGINT) as `Source Total Creatives`,
        CAST(SUM(delivered_impressions) AS BIGINT) as `Source Total Delivered Impressions`,
        CAST(SUM(delivered_revenue) AS DECIMAL(19,2)) as `Source Total Delivered Revenue`
    FROM fw_placement_level
    GROUP BY
        aos_deal_id
""")

display(src_df_daup)


### Validation Comparison

from pyspark.sql.functions import col, when, expr, nvl, abs, lit, array, concat_ws

# Join source and target on AOS_Deal_ID
joined_df_daup = src_df_daup.join(
    tar_df_daup,
    on="AOS_Deal_ID",
    how="full_outer"
)

display(joined_df_daup)


# Add comparison columns - only for the columns that exist
validation_df_daup = joined_df_daup.withColumn(
    "Source_Total_Creatives",
    nvl(col("`Source Total Creatives`"), lit(0))
).withColumn(
    "Target_Total_Creatives",
    nvl(col("`Target Total Creatives`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Impressions",
    nvl(col("`Source Total Delivered Impressions`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Impressions",
    nvl(col("`Target Total Delivered Impressions`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Revenue",
    nvl(col("`Source Total Delivered Revenue`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Revenue",
    nvl(col("`Target Total Delivered Revenue`"), lit(0))
).withColumn(
    "Variance_Creatives",
    col("Source_Total_Creatives") - col("Target_Total_Creatives")
).withColumn(
    "Variance_Impressions",
    col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")
).withColumn(
    "Variance_Revenue",
    col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")
).withColumn(
    "Creatives_Match",
    when(
        abs(col("Source_Total_Creatives") - col("Target_Total_Creatives")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Impressions_Match",
    when(
        abs(col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Revenue_Match",
    when(
        abs(col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Status",
    when(
        (col("Creatives_Match") == True) &
        (col("Impressions_Match") == True) &
        (col("Revenue_Match") == True),
        True
    ).otherwise(False)
).select(
    col("AOS_Deal_ID"),
    col("Source_Total_Creatives"),
    col("Target_Total_Creatives"),
    col("Variance_Creatives"),
    col("Creatives_Match"),
    col("Source_Total_Delivered_Impressions"),
    col("Target_Total_Delivered_Impressions"),
    col("Variance_Impressions"),
    col("Impressions_Match"),
    col("Source_Total_Delivered_Revenue"),
    col("Target_Total_Delivered_Revenue"),
    col("Variance_Revenue"),
    col("Revenue_Match"),
    col("Status")
)

display(validation_df_daup)



# Create a dataframe showing which columns have mismatches for deals where Status is False
mismatch_details_df_daup = validation_df_daup.withColumn(
    "Mismatched_Columns_Array",
    array(
        when(col("Creatives_Match") == False, lit("Creatives")).otherwise(lit(None)),
        when(col("Impressions_Match") == False, lit("Impressions")).otherwise(lit(None)),
        when(col("Revenue_Match") == False, lit("Revenue")).otherwise(lit(None))
    )
).withColumn(
    "Mismatched_Columns_Array",
    expr("filter(Mismatched_Columns_Array, x -> x is not null)")
).withColumn(
    "Mismatched_Columns",
    concat_ws(", ", col("Mismatched_Columns_Array"))
).select(
    col("AOS_Deal_ID").alias("deal_id"),
    col("Status"),
    col("Mismatched_Columns")
).distinct()

print("=" * 80)
print(f"Deal Mismatch Details")
print(f"Total Deals with Mismatches: {mismatch_details_df_daup.filter(col('Status') == False).count()}")
print("=" * 80)

display(mismatch_details_df_daup)

### Deal IDs Only in Target Table (Not in Source)

# Find deal_ids that are only in target table and not in source table
source_only_deals_daup = spark.sql(f"""
    SELECT 
        t.`AOS_Deal ID` as AOS_Deal_ID
    FROM {catalog_name}.gold_ad_sales.v_ft_freewheel_campaign_delivery t
    WHERE t.`AOS_Deal ID` IS NOT NULL
        AND t.`AOS_Deal ID` != -1
        AND NOT EXISTS (
            SELECT 1
            FROM {catalog_name}.gold_ad_sales.v_wrap_detailed_unified_report_sections_by_deal s
            WHERE s.AOS_Deal_ID = t.`AOS_Deal ID`
                AND s.data_type = 'DEAL_AD_UNITS_PERFORMANCE'
        )
    ORDER BY t.`AOS_Deal ID`
""")

print("=" * 80)
print(f"Deal IDs only in v_ft_unified_campaign_delivery_by_deal Table (v_ft_unified_campaign_delivery_by_deal)")
print(f"Count: {source_only_deals_daup.count()}")
print("=" * 80)

display(source_only_deals_daup)


# Update mismatch_details_df_daup to include deals from source_only_deals_daup with Status = "missing deals"
# First, convert Status to string in mismatch_details_df_daup to allow "missing deals" value
mismatch_details_df_1_daup = mismatch_details_df_daup.withColumn(
    "Status",
    when(col("Status") == True, lit("True"))
    .when(col("Status") == False, lit("False"))
    .otherwise(col("Status").cast("string"))
)

# Create a dataframe for missing deals with the same structure as mismatch_details_df_daup
missing_deals_df_daup = source_only_deals_daup.select(
    col("AOS_Deal_ID").alias("deal_id"),
    lit("missing deals").alias("Status"),
    lit("Deal not found in source table").alias("Mismatched_Columns")
)

display(missing_deals_df_daup)

display(mismatch_details_df_1_daup)

# Option 1: Use a broadcast join with a flag, then check if deal_id exists in source_only_deals_daup
from pyspark.sql.functions import broadcast

# Create a set of deal_ids from source_only_deals_daup for efficient lookup
source_only_deal_ids_daup = source_only_deals_daup.select(col("AOS_Deal_ID").alias("deal_id")).distinct()

# Join and check if deal_id exists in source_only_deals_daup
mismatch_details_df_1_daup = mismatch_details_df_1_daup.join(
    broadcast(source_only_deal_ids_daup).withColumn("is_source_only", lit(True)),
    on="deal_id",
    how="left"
).withColumn(
    "Status",
    when(col("is_source_only").isNotNull(), lit("not found in source").cast("string"))
    .otherwise(col("Status").cast("string"))
).select(
    col("deal_id"),
    col("Status").cast("string").alias("Status"),
    col("Mismatched_Columns")
)

# Union with missing_deals_df_daup to include all deals that are only in target table
mismatch_details_df_1_daup = mismatch_details_df_1_daup.unionByName(
    missing_deals_df_daup,
    allowMissingColumns=True
).distinct()

display(mismatch_details_df_1_daup)



# Create a dataframe with deal_id and DEAL_AD_UNITS_PERFORMANCE (True if Status is True, False otherwise)
deal_status_df_daup = mismatch_details_df_1_daup.select(
    col("deal_id"),
    when(col("Status") == "True", lit("True"))
    .when(col("Status") == "False", lit("False"))
    .otherwise(col("Status"))
    .alias("DEAL_AD_UNITS_PERFORMANCE")
).distinct()

print("=" * 80)
print(f"Deal Status Summary")
print(f"Total Deals: {deal_status_df_daup.count()}")
print(f"Deals with DEAL_AD_UNITS_PERFORMANCE = True: {deal_status_df_daup.filter(col('DEAL_AD_UNITS_PERFORMANCE') == 'True').count()}")
print(f"Deals with DEAL_AD_UNITS_PERFORMANCE = False: {deal_status_df_daup.filter(col('DEAL_AD_UNITS_PERFORMANCE') == 'False').count()}")
print("=" * 80)

display(deal_status_df_daup)

# COMMAND ----------

deal_status_df_daup.createOrReplaceGlobalTempView("deal_status_df_daup")

# COMMAND ----------

from pyspark.sql.functions import lit, col, when, abs as spark_abs, stack, round as spark_round

unpivoted_df_daup = validation_df_daup.filter(
    col("Status") == False
).select(
    lit("DEAL_AD_UNITS_PERFORMANCE").alias("parse_type"),
    col("AOS_Deal_ID").alias("aos_deal_id"),
    stack(
        lit(3),
        lit("Total_Creatives"),
        col("Source_Total_Creatives").cast("double"),
        col("Target_Total_Creatives").cast("double"),

        lit("Total_Delivered_Impressions"),
        col("Source_Total_Delivered_Impressions").cast("double"),
        col("Target_Total_Delivered_Impressions").cast("double"),

        lit("Total_Delivered_Revenue"),
        col("Source_Total_Delivered_Revenue").cast("double"),
        col("Target_Total_Delivered_Revenue").cast("double"),
    ).alias("metric_name", "source_value", "target_value")
).withColumn(
    "mismatch_percent_variance",
    when(
        (col("source_value") == 0) & (col("target_value") == 0), lit(0.0)
    ).when(
        col("source_value") == 0, lit(100.0)
    ).otherwise(
        spark_round(
            spark_abs(col("source_value") - col("target_value")) / spark_abs(col("source_value")) * 100,
            2
        )
    )
).filter(
    col("mismatch_percent_variance") != 0
)

display(unpivoted_df_daup)

# COMMAND ----------

table_name = "fox_bi_dev.bronze_ads.wrap_report_deal_ad_units_performance_mismatches"

if spark.catalog.tableExists(table_name):
    unpivoted_df_daup.write.mode("overwrite").saveAsTable(table_name)
else:
    unpivoted_df_daup.write.saveAsTable(table_name)

# COMMAND ----------

dbutils.notebook.exit("success")