# Databricks notebook source
spark.conf.set("spark.databricks.remoteFiltering.blockSelfJoins", "false")

# COMMAND ----------

# MAGIC %md
# MAGIC # Parse for DURATION_BUCKET_ANALYSIS Validation
# MAGIC

# COMMAND ----------

# Databricks notebook Target
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from datetime import datetime, date
import os
import pandas as pd

# COMMAND ----------

# Configuration
catalog_name = 'fox_bi_qa'
env = 'dev'  # or 'qa' or 'prod'


# Target: Aggregate field10 from wrap_detailed_unified_report_sections_by_deal
# Filter for DURATION_BUCKET_ANALYSIS data_type and sum field10 (which contains Total_Delivered_Impressions as string)
tar_df_dba = spark.sql(f"""
    SELECT 
        AOS_Deal_ID,      
        SUM(try_cast(field4 AS BIGINT)) as `Target Total Delivered Impressions`,
        SUM(try_cast(field5 AS DECIMAL(19,2))) as `Target Total Delivered Revenue`,
        CAST(
            CASE
                WHEN SUM(field4) > 0
                THEN ROUND((SUM(field5) / SUM(field4) * 1000), 4)
                ELSE 0
            END AS DECIMAL(19,2)
        ) as `Target CPM`
    FROM {catalog_name}.gold_ad_sales.v_wrap_detailed_unified_report_sections_by_deal
    WHERE data_type = 'DURATION_BUCKET_ANALYSIS'
    GROUP BY AOS_Deal_ID
""")

display(tar_df_dba)


# Source: Get Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
src_df_dba = spark.sql(f"""
with fw_placement_level as (
    SELECT
        `AOS_Deal Name` AS aos_deal_name,
        `AOS_Deal ID` AS aos_deal_id,
        pl.`Campaign Start Date` AS campaign_start_date,
        pl.`Campaign End Date` AS campaign_end_date,
        pl.`Advertiser Name` AS advertiser_name,
        pl.`Agency Name` AS agency_name,
        pl.`Sales Channel Type` AS line_item_type,
        pl.`Placement ID` AS placement_id,
        pl.`Placement Name` AS placement_name,
        pl.`Package Name` AS package_name,
        pl.`Parent Line Item Name` AS parent_line_item_name,
        pl.`AOS Deal Line Item Name` AS aos_deal_line_item_name,
        pl.`Creative ID` AS creative_id,
        pl.`Creative Name` AS creative_name,
        pl.`Creative Duration` AS creative_duration,
        pl.`Device` AS device,
        pl.`Ad Unit Position` AS ad_unit_position,
        pl.`Video Vertical` AS video_vertical,
        pl.`Show Name` AS show_name,
        pl.`Deal Ad Units` AS deal_ad_units,
        pl.`Demo Band` AS demo_band,
        pl.`Event Date` AS event_date,
        MAX(pl.`Guaranteed Impressions`) as guaranteed_impressions,
        MAX(pl.`Guaranteed Revenue`) as guaranteed_revenue,
        MAX(`Net Unit Cost`) as net_unit_cost,
        SUM(pl.`Delivered Impressions`) as delivered_impressions,
        SUM(pl.`Delivered Clicks`) as delivered_clicks,
        SUM(pl.`Delivered Revenue`) as delivered_revenue,
        SUM(pl.`On Target Net Delivered Impressions`) as on_target_impressions
    FROM fox_bi_qa.gold_ad_sales.v_ft_freewheel_campaign_delivery pl
    GROUP BY
        `AOS_Deal ID`,
        `AOS_Deal Name`,
        pl.`Campaign Start Date`,
        pl.`Campaign End Date`,
        pl.`Advertiser Name`,
        pl.`Agency Name`,
        pl.`Sales Channel Type`,
        pl.`Placement ID`,
        pl.`Placement Name`,
        pl.`Package Name`,
        pl.`Parent Line Item Name`,
        pl.`AOS Deal Line Item Name`,
        pl.`Creative ID`,
        pl.`Creative Name`,
        pl.`Creative Duration`,
        pl.`Device`,
        pl.`Ad Unit Position`,
        pl.`Video Vertical`,
        pl.`Show Name`,
        pl.`Deal Ad Units`,
        pl.`Event Date`,
        pl.`Demo Band`
)                   

select
AOS_Deal_ID,
sum(`Source Total Delivered Impressions`) as `Source Total Delivered Impressions`,
sum(`Source Total Delivered Revenue`) as `Source Total Delivered Revenue`,
CAST(
        CASE
            WHEN sum(`Source Total Delivered Impressions`) > 0
            THEN ROUND((sum(`Source Total Delivered Revenue`) / sum(`Source Total Delivered Impressions`) * 1000), 4)
            ELSE 0
        END AS DECIMAL(19,2)
    ) as `Source CPM`
from
(
    SELECT 
        aos_deal_id as AOS_Deal_ID,
        CAST(SUM(delivered_impressions) AS BIGINT) as `Source Total Delivered Impressions`,
        CAST(SUM(delivered_revenue) AS DECIMAL(19,2)) as `Source Total Delivered Revenue`,
        CAST(
            CASE
                WHEN SUM(delivered_impressions) > 0
                THEN ROUND((SUM(delivered_revenue) / SUM(delivered_impressions) * 1000), 2)
                ELSE 0
            END AS DECIMAL(19,2)
        ) as `Source CPM`      
    FROM fw_placement_level
    WHERE creative_duration IS NOT NULL
    and device is not null and device != 'N/A' and device != 'Unknown'
    GROUP BY
        CASE
            WHEN CAST(creative_duration AS DOUBLE) <= 15 THEN '0-15s'
            WHEN CAST(creative_duration AS DOUBLE) <= 30 THEN '16-30s'
            WHEN CAST(creative_duration AS DOUBLE) <= 45 THEN '31-45s'
            WHEN CAST(creative_duration AS DOUBLE) <= 60 THEN '46-60s'
            ELSE '60s+'
        END,
        device,
        ad_unit_position,
        aos_deal_id
)
group by AOS_Deal_ID        
""")

display(src_df_dba)

### Validation Comparison

from pyspark.sql.functions import col, when, expr, nvl, abs, lit, array, concat_ws

# Join source and target on AOS_Deal_ID
joined_df_dba = src_df_dba.join(
    tar_df_dba,
    on="AOS_Deal_ID",
    how="full_outer"
)

display(joined_df_dba)


# Add comparison columns - only for the columns that actually exist
validation_df_dba = joined_df_dba.withColumn(
    "Source_Total_Delivered_Impressions",
    nvl(col("`Source Total Delivered Impressions`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Impressions",
    nvl(col("`Target Total Delivered Impressions`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Revenue",
    nvl(col("`Source Total Delivered Revenue`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Revenue",
    nvl(col("`Target Total Delivered Revenue`"), lit(0))
).withColumn(
    "Source_CPM",
    nvl(col("`Source CPM`"), lit(0))
).withColumn(
    "Target_CPM",
    nvl(col("`Target CPM`"), lit(0))
).withColumn(
    "Variance_Impressions",
    col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")
).withColumn(
    "Variance_Revenue",
    col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")
).withColumn(
    "Variance_CPM",
    col("Source_CPM") - col("Target_CPM")
).withColumn(
    "Impressions_Match",
    when(
        abs(col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Revenue_Match",
    when(
        abs(col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "CPM_Match",
    when(
        abs(col("Source_CPM") - col("Target_CPM")) <= 5,  # Use smaller threshold for CPM (decimal)
        True
    ).otherwise(False)
).withColumn(
    "Status",
    when(
        (col("Impressions_Match") == True) &
        (col("Revenue_Match") == True) &
        (col("CPM_Match") == True),
        True
    ).otherwise(False)
).select(
    col("AOS_Deal_ID"),
    col("Source_Total_Delivered_Impressions"),
    col("Target_Total_Delivered_Impressions"),
    col("Variance_Impressions"),
    col("Impressions_Match"),
    col("Source_Total_Delivered_Revenue"),
    col("Target_Total_Delivered_Revenue"),
    col("Variance_Revenue"),
    col("Revenue_Match"),
    col("Source_CPM"),
    col("Target_CPM"),
    col("Variance_CPM"),
    col("CPM_Match"),
    col("Status")
)

display(validation_df_dba)


# Create a dataframe showing which columns have mismatches for deals where Status is False
mismatch_details_df_dba = validation_df_dba.withColumn(
    "Mismatched_Columns_Array",
    array(
        when(col("Impressions_Match") == False, lit("Impressions")).otherwise(lit(None)),
        when(col("Revenue_Match") == False, lit("Revenue")).otherwise(lit(None)),
        when(col("CPM_Match") == False, lit("CPM")).otherwise(lit(None))
    )
).withColumn(
    "Mismatched_Columns_Array",
    expr("filter(Mismatched_Columns_Array, x -> x is not null)")
).withColumn(
    "Mismatched_Columns",
    concat_ws(", ", col("Mismatched_Columns_Array"))
).select(
    col("AOS_Deal_ID").alias("deal_id"),
    col("Status"),
    col("Mismatched_Columns")
).distinct()

print("=" * 80)
print(f"Deal Mismatch Details")
print(f"Total Deals with Mismatches: {mismatch_details_df_dba.count()}")
print("=" * 80)

display(mismatch_details_df_dba)

print("missing deals")

# Find deal_ids that are only in target table and not in source table
source_only_deals_dba = spark.sql(f"""
    SELECT 
        t.`AOS_Deal ID` as AOS_Deal_ID
    -- FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal t
    FROM {catalog_name}.gold_ad_sales.v_ft_freewheel_campaign_delivery t
    WHERE t.`AOS_Deal ID` IS NOT NULL
        AND t.`AOS_Deal ID` != -1
        AND NOT EXISTS (
            SELECT 1
            FROM {catalog_name}.gold_ad_sales.v_wrap_detailed_unified_report_sections_by_deal s
            WHERE s.AOS_Deal_ID = t.`AOS_Deal ID`
                AND s.data_type = 'DURATION_BUCKET_ANALYSIS'
        )
    ORDER BY t.`AOS_Deal ID`
""")

print("=" * 80)
print(f"Deal IDs only in v_ft_unified_campaign_delivery_by_deal Table (v_ft_unified_campaign_delivery_by_deal)")
print(f"Count: {source_only_deals_dba.count()}")
print("=" * 80)

display(source_only_deals_dba)


# Update mismatch_details_df_dba to include deals from source_only_deals_dba with Status = "missing deals"
# First, convert Status to string in mismatch_details_df_dba to allow "missing deals" value
mismatch_details_df_1_dba = mismatch_details_df_dba.withColumn(
    "Status",
    when(col("Status") == True, lit("True"))
    .when(col("Status") == False, lit("False"))
    .otherwise(col("Status").cast("string"))
)

# Create a dataframe for missing deals with the same structure as mismatch_details_df_dba
missing_deals_df_dba = source_only_deals_dba.select(
    col("AOS_Deal_ID").alias("deal_id"),
    lit("missing deals").alias("Status"),
    lit("Deal not found in source table").alias("Mismatched_Columns")
)

display(missing_deals_df_dba)

display(mismatch_details_df_1_dba)

# Option 1: Use a broadcast join with a flag, then check if deal_id exists in source_only_deals_dba
from pyspark.sql.functions import broadcast

# Create a set of deal_ids from source_only_deals_dba for efficient lookup
source_only_deal_ids_dba = source_only_deals_dba.select(col("AOS_Deal_ID").alias("deal_id")).distinct()

# Join and check if deal_id exists in source_only_deals_dba
mismatch_details_df_1_dba = mismatch_details_df_1_dba.join(
    broadcast(source_only_deal_ids_dba).withColumn("is_source_only", lit(True)),
    on="deal_id",
    how="left"
).withColumn(
    "Status",
    when(col("is_source_only").isNotNull(), lit("not found in source").cast("string"))
    .otherwise(col("Status").cast("string"))
).select(
    col("deal_id"),
    col("Status").cast("string").alias("Status"),
    col("Mismatched_Columns")
)

# Union with missing_deals_df_dba to include all deals that are only in target table
mismatch_details_df_1_dba = mismatch_details_df_1_dba.unionByName(
    missing_deals_df_dba,
    allowMissingColumns=True
).distinct()


display(mismatch_details_df_1_dba)



# Create a dataframe with deal_id and DURATION_BUCKET_ANALYSIS (True if Status is True, False otherwise)
deal_status_df_dba = mismatch_details_df_1_dba.select(
    col("deal_id"),
    when(col("Status") == "True", lit("True"))\
    .when(col("Status") == "False", lit("False"))\
    .otherwise(col("Status"))
    .alias("DURATION_BUCKET_ANALYSIS")
).distinct()

print("=" * 80)
print(f"Deal Status Summary")
print(f"Total Deals: {deal_status_df_dba.count()}")
print(f"Deals with DURATION_BUCKET_ANALYSIS = True: {deal_status_df_dba.filter(col('DURATION_BUCKET_ANALYSIS') == 'True').count()}")
print(f"Deals with DURATION_BUCKET_ANALYSIS = False: {deal_status_df_dba.filter(col('DURATION_BUCKET_ANALYSIS') == 'False').count()}")
print("=" * 80)

display(deal_status_df_dba)





# COMMAND ----------

deal_status_df_dba.createOrReplaceGlobalTempView("deal_status_df_dba")

# COMMAND ----------

from pyspark.sql.functions import lit, col, when, abs as spark_abs, stack, round as spark_round

unpivoted_df_dba = validation_df_dba.filter(
    col("Status") == False
).select(
    lit("DURATION_BUCKET_ANALYSIS").alias("parse_type"),
    col("AOS_Deal_ID").alias("aos_deal_id"),
    stack(
        lit(3),
        lit("Total_Delivered_Impressions"),
        col("Source_Total_Delivered_Impressions").cast("double"),
        col("Target_Total_Delivered_Impressions").cast("double"),

        lit("Total_Delivered_Revenue"),
        col("Source_Total_Delivered_Revenue").cast("double"),
        col("Target_Total_Delivered_Revenue").cast("double"),

        lit("CPM"),
        col("Source_CPM").cast("double"),
        col("Target_CPM").cast("double"),
    ).alias("metric_name", "source_value", "target_value")
).withColumn(
    "mismatch_percent_variance",
    when(
        (col("source_value") == 0) & (col("target_value") == 0), lit(0.0)
    ).when(
        col("source_value") == 0, lit(100.0)
    ).otherwise(
        spark_round(
            spark_abs(col("source_value") - col("target_value")) / spark_abs(col("source_value")) * 100,
            2
        )
    )
).filter(
    col("mismatch_percent_variance") != 0
)

display(unpivoted_df_dba)

# COMMAND ----------

table_name = "fox_bi_dev.bronze_ads.wrap_report_duration_bucket_analysis_mismatches"

if spark.catalog.tableExists(table_name):
    unpivoted_df_dba.write.mode("overwrite").saveAsTable(table_name)
else:
    unpivoted_df_dba.write.saveAsTable(table_name)

# COMMAND ----------

dbutils.notebook.exit("success")