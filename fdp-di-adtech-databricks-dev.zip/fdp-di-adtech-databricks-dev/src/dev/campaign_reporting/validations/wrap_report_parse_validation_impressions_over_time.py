# Databricks notebook source
spark.conf.set("spark.databricks.remoteFiltering.blockSelfJoins", "false")

# COMMAND ----------

# MAGIC %md
# MAGIC # Parse for IMPRESSIONS_OVER_TIME Validation
# MAGIC

# COMMAND ----------

# Databricks notebook Target
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from datetime import datetime, date
import os
import pandas as pd

# COMMAND ----------

# Configuration
catalog_name = 'fox_bi_qa'
env = 'dev'  # or 'qa' or 'prod'


# Target: Aggregate field10 from wrap_detailed_unified_report_sections_by_deal
# Filter for IMPRESSIONS_OVER_TIME data_type and sum field10 (which contains Total_Delivered_Impressions as string)
tar_df_iot = spark.sql(f"""
    SELECT 
        AOS_Deal_ID,
        SUM(try_cast(field2 AS BIGINT)) as `Target Total Delivered Impressions`,
        SUM(try_cast(field3 AS DECIMAL(19,2))) as `Target Total Delivered Revenue`,
        SUM(try_cast(field6 AS BIGINT)) as `Target Total Third Party Impressions`,
        SUM(try_cast(field7 AS DECIMAL(19,2))) as `Target Total Third Party Revenue`
    FROM {catalog_name}.gold_ad_sales.v_wrap_detailed_unified_report_sections_by_deal
    WHERE data_type = 'IMPRESSIONS_OVER_TIME'
    GROUP BY AOS_Deal_ID
""")

display(tar_df_iot)


# Source: Get Total_Delivered_Impressions from ft_unified_campaign_delivery_by_deal
src_df_iot = spark.sql(f"""
with fw_placement_level as (
    SELECT
        `AOS_Deal Name` AS aos_deal_name,
        `AOS_Deal ID` AS aos_deal_id,
        pl.`Campaign Start Date` AS campaign_start_date,
        pl.`Campaign End Date` AS campaign_end_date,
        pl.`Advertiser Name` AS advertiser_name,
        pl.`Agency Name` AS agency_name,
        pl.`Sales Channel Type` AS line_item_type,
        pl.`Placement ID` AS placement_id,
        pl.`Placement Name` AS placement_name,
        pl.`Package Name` AS package_name,
        pl.`Parent Line Item Name` AS parent_line_item_name,
        pl.`AOS Deal Line Item Name` AS aos_deal_line_item_name,
        pl.`Creative ID` AS creative_id,
        pl.`Creative Name` AS creative_name,
        pl.`Creative Duration` AS creative_duration,
        pl.`Device` AS device,
        pl.`Ad Unit Position` AS ad_unit_position,
        pl.`Video Vertical` AS video_vertical,
        pl.`Show Name` AS show_name,
        pl.`Deal Ad Units` AS deal_ad_units,
        pl.`Demo Band` AS demo_band,
        pl.`Event Date` AS event_date,
        MAX(pl.`Guaranteed Impressions`) as guaranteed_impressions,
        MAX(pl.`Guaranteed Revenue`) as guaranteed_revenue,
        MAX(`Net Unit Cost`) as net_unit_cost,
        SUM(pl.`Delivered Impressions`) as delivered_impressions,
        SUM(pl.`Delivered Clicks`) as delivered_clicks,
        SUM(pl.`Delivered Revenue`) as delivered_revenue,
        SUM(pl.`On Target Net Delivered Impressions`) as on_target_impressions
    FROM fox_bi_qa.gold_ad_sales.v_ft_freewheel_campaign_delivery pl
    -- WHERE `AOS_Deal ID` = 18683
    GROUP BY
        `AOS_Deal ID`,
        `AOS_Deal Name`,
        pl.`Campaign Start Date`,
        pl.`Campaign End Date`,
        pl.`Advertiser Name`,
        pl.`Agency Name`,
        pl.`Sales Channel Type`,
        pl.`Placement ID`,
        pl.`Placement Name`,
        pl.`Package Name`,
        pl.`Parent Line Item Name`,
        pl.`AOS Deal Line Item Name`,
        pl.`Creative ID`,
        pl.`Creative Name`,
        pl.`Creative Duration`,
        pl.`Device`,
        pl.`Ad Unit Position`,
        pl.`Video Vertical`,
        pl.`Show Name`,
        pl.`Deal Ad Units`,
        pl.`Event Date`,
        pl.`Demo Band`
),
gam_placement_level AS (
    SELECT
        pl.`AOS Deal Name` AS aos_deal_name,
        pl.`AOS Deal ID` AS aos_deal_id,
        pl.`Campaign Start Date` AS campaign_start_date,
        pl.`Campaign End Date` AS campaign_end_date,
        pl.`Advertiser Name` AS advertiser_name,
        pl.`Agency Name` AS agency_name,
        pl.`Line Item Type` AS line_item_type,
        pl.`Line Item ID` AS placement_id,
        pl.`Line Item Name` AS placement_name,
        pl.`Package Name` AS package_name,
        pl.`Parent Line Item Name` AS parent_line_item_name,
        pl.`AOS Deal Line Item Name` AS aos_deal_line_item_name,
        CAST(-1 AS STRING) AS creative_id,
        CAST('N/A' AS STRING) AS creative_name,
        CAST(0 AS STRING) AS creative_duration,
        pl.`Device`,
        CAST('N/A' AS STRING) AS ad_unit_position,
        CAST('N/A' AS STRING) AS video_vertical,
        CAST('N/A' AS STRING) AS show_name,
        CAST('N/A' AS STRING) AS deal_ad_units,
        pl.`Demo Band` AS demo_band,
        pl.`Event Date` AS event_date,
        MAX(pl.`Guaranteed Impressions`) AS guaranteed_impressions,
        MAX(pl.`Guaranteed Revenue`) AS guaranteed_revenue,
        MAX(pl.`Net Unit Cost`) AS net_unit_cost,
        SUM(pl.`Delivered Impressions`) AS delivered_impressions,
        SUM(pl.`Delivered Clicks`) AS delivered_clicks,
        CASE
            WHEN MAX(pl.`Line Item Type`) = 'SPONSORSHIP'
            THEN MAX(pl.`Guaranteed Revenue`)/count(pl.`Event Date`) over (partition by pl.`Line Item ID`)
            ELSE (SUM(pl.`Delivered Impressions`) * MAX(pl.`Net Unit Cost`)) / 1000.0
        END as delivered_revenue,
        SUM(0) as on_target_impressions
    FROM fox_bi_qa.gold_ad_sales.v_ft_gam_campaign_delivery pl
    -- WHERE pl.`AOS Deal ID` = 18683
    GROUP BY
        pl.`AOS Deal ID`,
        pl.`AOS Deal Name`,
        pl.`Campaign Start Date`,
        pl.`Campaign End Date`,
        pl.`Advertiser Name`,
        pl.`Agency Name`,
        pl.`Line Item Type`,
        pl.`Line Item ID`,
        pl.`Line Item Name`,
        pl.`Package Name`,
        pl.`Parent Line Item Name`,
        pl.`AOS Deal Line Item Name`,
        pl.`Device`,
        pl.`Demo Band`,
        pl.`Event Date`
),
unified_placement_level as (
    SELECT
         aos_deal_id
        ,aos_deal_name
        ,campaign_start_date
        ,campaign_end_date
        ,advertiser_name
        ,agency_name
        -- ,sales_channel_type
        ,placement_id
        ,placement_name
        ,package_name
        ,parent_line_item_name
        ,aos_deal_line_item_name
        ,line_item_type
        ,creative_id
        ,creative_name
        ,creative_duration
        ,device
        ,ad_unit_position
        ,video_vertical
        ,show_name
        ,deal_ad_units
        ,event_date
        ,demo_band
        ,MAX(net_unit_cost) net_unit_cost
        ,MAX(guaranteed_impressions) AS guaranteed_impressions
        ,MAX(guaranteed_revenue) AS guaranteed_revenue
        ,SUM(delivered_impressions) AS delivered_impressions
        ,SUM(delivered_revenue) delivered_revenue
        ,SUM(delivered_clicks) AS delivered_clicks
        ,SUM(on_target_impressions) AS on_target_impressions
    FROM
        (
            select * from fw_placement_level
            union all
            select * from gam_placement_level
        )
    GROUP BY
            aos_deal_id
            ,aos_deal_name
            ,campaign_start_date
            ,campaign_end_date
            ,advertiser_name
            ,agency_name
            -- ,sales_channel_type
            ,placement_id
            ,package_name
            ,parent_line_item_name
            ,aos_deal_line_item_name
            ,placement_name
            ,creative_id
            ,creative_name
            ,creative_duration
            ,device
            ,ad_unit_position
            ,video_vertical
            ,show_name
            ,deal_ad_units
            ,event_date
            ,demo_band
            ,line_item_type
),

fetch_impress_over_time as (
select 
pl.aos_deal_id as `AOS_Deal_ID`,
CAST(SUM(pl.delivered_revenue) AS DECIMAL(19,2)) as delivered_revenue
from
unified_placement_level pl
group by pl.aos_deal_id
)

    SELECT 
    distinct
        src.`AOS Deal ID` as AOS_Deal_ID,
        CAST(src.`Total First Party Delivered Impressions` AS BIGINT) as `Source Total Delivered Impressions`,
        CAST(src.`Total First Party Delivered Revenue` AS DECIMAL(19,2)) as `Source Total Delivered Revenue`,
        CAST(src.`Total Third Party Impressions` AS BIGINT) as `Source Total Third Party Impressions`,
        CAST(src.`Total Third Party Revenue` AS DECIMAL(19,2)) as `Source Total Third Party Revenue`
    FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal src
    inner join (select distinct * from fetch_impress_over_time) pl on src.`AOS Deal ID` = pl.`AOS_Deal_ID` 
    -- WHERE `AOS Deal ID` IS NOT NULL
    --     AND `AOS Deal ID` != -1
""")

display(src_df_iot)

### Validation Comparison

from pyspark.sql.functions import col, when, expr, nvl, abs, lit, array, concat_ws

# Join source and target on AOS_Deal_ID
joined_df_iot = src_df_iot.join(
    tar_df_iot,
    on="AOS_Deal_ID",
    how="full_outer"
)

display(joined_df_iot)


# Add comparison columns - only for columns that exist
validation_df_iot = joined_df_iot.withColumn(
    "Source_Total_Delivered_Impressions",
    nvl(col("`Source Total Delivered Impressions`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Impressions",
    nvl(col("`Target Total Delivered Impressions`"), lit(0))
).withColumn(
    "Source_Total_Delivered_Revenue",
    nvl(col("`Source Total Delivered Revenue`"), lit(0))
).withColumn(
    "Target_Total_Delivered_Revenue",
    nvl(col("`Target Total Delivered Revenue`"), lit(0))
).withColumn(
    "Source_Total_Third_Party_Impressions",
    nvl(col("`Source Total Third Party Impressions`"), lit(0))
).withColumn(
    "Target_Total_Third_Party_Impressions",
    nvl(col("`Target Total Third Party Impressions`"), lit(0))
).withColumn(
    "Source_Total_Third_Party_Revenue",
    nvl(col("`Source Total Third Party Revenue`"), lit(0))
).withColumn(
    "Target_Total_Third_Party_Revenue",
    nvl(col("`Target Total Third Party Revenue`"), lit(0))
).withColumn(
    "Variance_Impressions",
    col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")
).withColumn(
    "Variance_Revenue",
    col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")
).withColumn(
    "Variance_Third_Party_Impressions",
    col("Source_Total_Third_Party_Impressions") - col("Target_Total_Third_Party_Impressions")
).withColumn(
    "Variance_Third_Party_Revenue",
    col("Source_Total_Third_Party_Revenue") - col("Target_Total_Third_Party_Revenue")
).withColumn(
    "Impressions_Match",
    when(
        abs(col("Source_Total_Delivered_Impressions") - col("Target_Total_Delivered_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Revenue_Match",
    when(
        abs(col("Source_Total_Delivered_Revenue") - col("Target_Total_Delivered_Revenue")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Third_Party_Impressions_Match",
    when(
        abs(col("Source_Total_Third_Party_Impressions") - col("Target_Total_Third_Party_Impressions")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Third_Party_Revenue_Match",
    when(
        abs(col("Source_Total_Third_Party_Revenue") - col("Target_Total_Third_Party_Revenue")) <= 5,
        True
    ).otherwise(False)
).withColumn(
    "Status",
    when(
        (col("Impressions_Match") == True) &
        (col("Revenue_Match") == True) &
        (col("Third_Party_Impressions_Match") == True) &
        (col("Third_Party_Revenue_Match") == True),
        True
    ).otherwise(False)
).select(
    col("AOS_Deal_ID"),
    col("Source_Total_Delivered_Impressions"),
    col("Target_Total_Delivered_Impressions"),
    col("Variance_Impressions"),
    col("Impressions_Match"),
    col("Source_Total_Delivered_Revenue"),
    col("Target_Total_Delivered_Revenue"),
    col("Variance_Revenue"),
    col("Revenue_Match"),
    col("Source_Total_Third_Party_Impressions"),
    col("Target_Total_Third_Party_Impressions"),
    col("Variance_Third_Party_Impressions"),
    col("Third_Party_Impressions_Match"),
    col("Source_Total_Third_Party_Revenue"),
    col("Target_Total_Third_Party_Revenue"),
    col("Variance_Third_Party_Revenue"),
    col("Third_Party_Revenue_Match"),
    col("Status")
)

display(validation_df_iot)



# Create a dataframe showing which columns have mismatches for deals where Status is False
mismatch_details_df_iot = validation_df_iot.withColumn(
    "Mismatched_Columns_Array",
    array(
        when(col("Impressions_Match") == False, lit("Impressions")).otherwise(lit(None)),
        when(col("Revenue_Match") == False, lit("Revenue")).otherwise(lit(None)),
        when(col("Third_Party_Impressions_Match") == False, lit("Third Party Impressions")).otherwise(lit(None)),
        when(col("Third_Party_Revenue_Match") == False, lit("Third Party Revenue")).otherwise(lit(None))
    )
).withColumn(
    "Mismatched_Columns_Array",
    expr("filter(Mismatched_Columns_Array, x -> x is not null)")
).withColumn(
    "Mismatched_Columns",
    concat_ws(", ", col("Mismatched_Columns_Array"))
).select(
    col("AOS_Deal_ID").alias("deal_id"),
    when(col("Status") == True, lit("True"))
    .when(col("Status") == False, lit("False"))
    .otherwise(lit("False")).cast("string").alias("Status"),
    col("Mismatched_Columns")
).distinct()

print("=" * 80)
print(f"Deal Mismatch Details")
print(f"Total Deals with Mismatches: {mismatch_details_df_iot.count()}")
print("=" * 80)

display(mismatch_details_df_iot)

# Find deal_ids that are only in target table and not in source table
source_only_deals_iot = spark.sql(f"""
    SELECT 
        t.`AOS Deal ID` as AOS_Deal_ID,
        t.`Total Delivered Impressions` as `Target Total Delivered Impressions`,
        t.`Total Delivered Revenue` as `Target Total Delivered Revenue`
    FROM {catalog_name}.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal t
    WHERE t.`AOS Deal ID` IS NOT NULL
        AND t.`AOS Deal ID` != -1
        AND NOT EXISTS (
            SELECT 1
            FROM {catalog_name}.gold_ad_sales.v_wrap_detailed_unified_report_sections_by_deal s
            WHERE s.AOS_Deal_ID = t.`AOS Deal ID`
                AND s.data_type = 'IMPRESSIONS_OVER_TIME'
        )
    ORDER BY t.`AOS Deal ID`
""")

print("=" * 80)
print(f"Deal IDs only in v_ft_unified_campaign_delivery_by_deal Table (v_ft_unified_campaign_delivery_by_deal)")
print(f"Count: {source_only_deals_iot.count()}")
print("=" * 80)

display(source_only_deals_iot)

# Update mismatch_details_df_iot to include deals from source_only_deals_iot with Status = "missing deals"
# First, convert Status to string in mismatch_details_df_iot to allow "missing deals" value
mismatch_details_df_iot_1_iot = mismatch_details_df_iot.withColumn(
    "Status",
    col("Status").cast("string")
)

# Create a dataframe for missing deals with the same structure as mismatch_details_df_iot
missing_deals_df_iot = source_only_deals_iot.select(
    col("AOS_Deal_ID").alias("deal_id"),
    lit("missing deals").cast("string").alias("Status"),
    lit("Deal not found in source table").cast("string").alias("Mismatched_Columns")
)

display(missing_deals_df_iot)

display(mismatch_details_df_iot_1_iot)

# Option 1: Use a broadcast join with a flag, then check if deal_id exists in source_only_deals_iot
from pyspark.sql.functions import broadcast

# Create a set of deal_ids from source_only_deals_iot for efficient lookup
source_only_deal_ids_iot = source_only_deals_iot.select(col("AOS_Deal_ID").alias("deal_id")).distinct()

# Join and check if deal_id exists in source_only_deals_iot
mismatch_details_df_iot_1_iot = mismatch_details_df_iot_1_iot.join(
    broadcast(source_only_deal_ids_iot).withColumn("is_source_only", lit(True)),
    on="deal_id",
    how="left"
).withColumn(
    "Status",
    when(col("is_source_only").isNotNull(), lit("not found in source").cast("string"))
    .otherwise(col("Status").cast("string"))
).select(
    col("deal_id"),
    col("Status").cast("string").alias("Status"),
    col("Mismatched_Columns")
)

# Union with missing_deals_df_iot to include all deals that are only in target table
mismatch_details_df_iot_1_iot = mismatch_details_df_iot_1_iot.unionByName(
    missing_deals_df_iot,
    allowMissingColumns=True
).select(
    col("deal_id"),
    col("Status").cast("string").alias("Status"),
    col("Mismatched_Columns").cast("string").alias("Mismatched_Columns")
).distinct()

# Union with missing_deals_df_iot to include all deals that are only in target table
mismatch_details_df_iot_1_iot = mismatch_details_df_iot_1_iot.unionByName(
    missing_deals_df_iot,
    allowMissingColumns=True
).distinct()

display(mismatch_details_df_iot_1_iot)



# Create a dataframe with deal_id and IMPRESSIONS_OVER_TIME (True if Status is True, False otherwise)
deal_status_df_iot = mismatch_details_df_iot_1_iot.select(
    col("deal_id"),
    when(col("Status") == "True", lit("True"))
    .when(col("Status") == "False", lit("False"))
    .otherwise(col("Status"))
    .alias("IMPRESSIONS_OVER_TIME")
).distinct()

print("=" * 80)
print(f"Deal Status Summary")
print(f"Total Deals: {deal_status_df_iot.count()}")
print(f"Deals with IMPRESSIONS_OVER_TIME = True: {deal_status_df_iot.filter(col('IMPRESSIONS_OVER_TIME') == 'True').count()}")
print(f"Deals with IMPRESSIONS_OVER_TIME = False: {deal_status_df_iot.filter(col('IMPRESSIONS_OVER_TIME') == 'False').count()}")
print("=" * 80)

display(deal_status_df_iot)

# COMMAND ----------

deal_status_df_iot.createOrReplaceGlobalTempView("deal_status_df_iot")

# COMMAND ----------

from pyspark.sql.functions import lit, col, when, abs as spark_abs, stack, round as spark_round

unpivoted_df_iot = validation_df_iot.filter(
    col("Status") == False
).select(
    lit("IMPRESSIONS_OVER_TIME").alias("parse_type"),
    col("AOS_Deal_ID").alias("aos_deal_id"),
    stack(
        lit(4),
        lit("Total_Delivered_Impressions"),
        col("Source_Total_Delivered_Impressions").cast("double"),
        col("Target_Total_Delivered_Impressions").cast("double"),

        lit("Total_Delivered_Revenue"),
        col("Source_Total_Delivered_Revenue").cast("double"),
        col("Target_Total_Delivered_Revenue").cast("double"),

        lit("Total_Third_Party_Impressions"),
        col("Source_Total_Third_Party_Impressions").cast("double"),
        col("Target_Total_Third_Party_Impressions").cast("double"),

        lit("Total_Third_Party_Revenue"),
        col("Source_Total_Third_Party_Revenue").cast("double"),
        col("Target_Total_Third_Party_Revenue").cast("double"),
    ).alias("metric_name", "source_value", "target_value")
).withColumn(
    "mismatch_percent_variance",
    when(
        (col("source_value") == 0) & (col("target_value") == 0), lit(0.0)
    ).when(
        col("source_value") == 0, lit(100.0)
    ).otherwise(
        spark_round(
            spark_abs(col("source_value") - col("target_value")) / spark_abs(col("source_value")) * 100,
            2
        )
    )
).filter(
    col("mismatch_percent_variance") != 0
)

display(unpivoted_df_iot)

# COMMAND ----------

table_name = "fox_bi_dev.bronze_ads.wrap_report_impressions_over_time_mismatches"

if spark.catalog.tableExists(table_name):
    unpivoted_df_iot.write.mode("overwrite").saveAsTable(table_name)
else:
    unpivoted_df_iot.write.saveAsTable(table_name)

# COMMAND ----------

dbutils.notebook.exit("success")