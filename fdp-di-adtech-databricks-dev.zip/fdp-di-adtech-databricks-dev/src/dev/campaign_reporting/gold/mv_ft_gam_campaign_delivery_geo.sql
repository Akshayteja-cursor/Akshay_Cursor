CREATE OR REPLACE MATERIALIZED VIEW `fox_bi_dev`.`gold_ad_sales`.`mv_ft_gam_campaign_delivery_geo` (
    line_item_id BIGINT,
    line_item_name STRING,
    campaign_id INT,
    campaign_name STRING,
    order_id BIGINT,
    order_name STRING,
    advertiser_name STRING,
    agency_name STRING,
    account_manager STRING,
    line_item_start_date TIMESTAMP,
    line_item_end_date TIMESTAMP,
    campaign_start_date TIMESTAMP,
    campaign_end_date TIMESTAMP,
    line_item_type STRING,
    event_date DATE,
    city_criteria_id BIGINT,
    city_name STRING,
    neighborhood_name STRING,
    state_province_name STRING,
    country_name STRING,
    total_impressions BIGINT,
    total_clicks BIGINT,
    etl_created_timestamp TIMESTAMP,
    etl_updated_timestamp TIMESTAMP
  ) AS
(
  select
    gam_geo.line_item_id,
    gam_geo.line_item_name,
    coalesce(op_line_detail.campaign_id, -1) as campaign_id,
    coalesce(op_line_detail.campaign_name, 'N/A') as campaign_name,
    coalesce(gam_sum.order_id, -1) as order_id,
    coalesce(gam_sum.order_name, 'N/A') as order_name,
    coalesce(gam_sum.advertiser_name, 'N/A') as advertiser_name,
    coalesce(op_line_detail.agency_name, 'N/A') as agency_name,
    coalesce(op_line_detail.owner_name, 'N/A') as account_manager,
    gam_dim.line_item_start_timestamp as line_item_start_date,
    gam_dim.line_item_end_timestamp as line_item_end_date,
    op_line_detail.campaign_start_date as campaign_start_date,
    op_line_detail.campaign_end_date as campaign_end_date,
    gam_sum.line_item_type as line_item_type,
    gam_geo.event_date as event_date,
    gam_geo.city_criteria_id as city_criteria_id,
    gam_geo.city_name as city_name,
    gam_geo.neighborhood_name as neighborhood_name,
    gam_geo.state_province_name as state_province_name,
    gam_geo.country_name as country_name,
    gam_geo.total_impressions as total_impressions,
    gam_geo.total_clicks as total_clicks,
    gam_geo.etl_created_timestamp as etl_created_timestamp,
    gam_geo.etl_updated_timestamp as etl_updated_timestamp
  from
    fox_bi_prod.silver_ads.ft_gam_summary_daily_geo_data gam_geo
      left join fox_bi_prod.silver_ads.dim_gam_line_item_data gam_sum
        on gam_geo.line_item_id = gam_sum.line_item_id
        and gam_geo.line_item_id <> -1
      left join fox_bi_prod.silver_ads.dim_line_item gam_dim
        on gam_geo.line_item_id = gam_dim.line_item_id
        and gam_geo.line_item_id <> -1
      left join (
        select
          sales_line_item_id,
          agency_name,
          ps_line_item_id,
          sales_order_id as campaign_id,
          sales_order_name as campaign_name,
          sales_order_start_date as campaign_start_date,
          sales_order_end_date as campaign_end_date,
          owner_name
        from
          fox_bi_prod.gold_ad_sales.ft_digital_operative_line_detail
        group by
          all
      ) op_line_detail
        on gam_geo.line_item_id = op_line_detail.ps_line_item_id
        and gam_geo.line_item_id <> -1
  where
    upper(gam_sum.line_item_type) in ('BULK', 'STANDARD', 'SPONSORSHIP')
)
CLUSTER BY
  campaign_id,
  event_date