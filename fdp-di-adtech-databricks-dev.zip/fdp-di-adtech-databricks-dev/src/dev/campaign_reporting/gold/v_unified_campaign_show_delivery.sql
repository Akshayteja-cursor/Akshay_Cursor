  create or replace view fox_bi_qa.gold_ad_sales.v_unified_campaign_show_delivery as
  (
    select
    Data_Source `Data Source`
  ,event_date `Event Date`
  ,nvl(campaign_id,-1) `Campaign ID`
  ,nvl(campaign_name,'N/A') `Campaign Name`
  ,campaign_start_date `Campaign Start Date`
  ,campaign_end_date `Campaign End Date`
  ,nvl(order_id,-1) `Order ID`
  ,nvl(order_name,'N/A') `Order Name`
  ,nvl(advertiser_name,'N/A') `Advertiser Name`
  ,nvl(agency_name,'N/A') `Agency Name`
  ,nvl(line_item_or_placement_id,'N/A')  `Line Item or Placement ID`
  ,nvl(Line_Item_or_Placement_name,'N/A') `Line Item or Placement Name`
  ,nvl(Demand_Type,'N/A') `Demand Type`
  ,Line_Item_or_Placement_Start_Date `Line Item or Placement Start Date`
  ,Line_Item_or_Placement_End_Date `Line Item or Placement End Date`
  ,nvl(show_name,'N/A') `Show Name`
  ,Multiple_Ad_Servers `Multiple_Ad_Servers`
  ,Multiple_Ad_Server_ID `Multiple Ad Server ID`
  ,nvl(Delivered_Impressions,0) `Delivered Impressions`
  ,nvl(Delivered_Clicks,0) `Delivered Clicks`
  ,create_timestamp `Create Timestamp`
  ,modified_timestamp `Modified Timestamp`
 from
    fox_bi_qa.gold_ad_sales.mv_ft_unified_campaign_show_delivery
  )