# Databricks notebook source
from datetime import datetime, timedelta



# COMMAND ----------
query = """
    with gam_show as (
  
select 
 
 'GAM' as `Data_Source`
,`Event Date` as event_date
,`Campaign ID` as campaign_id
,`Campaign Name` as campaign_name
,`Campaign Start Date` as campaign_start_date
,`Campaign End Date` as campaign_end_date
,`Order ID` as order_id
,`Order Name` as order_name
,`Advertiser Name` as advertiser_name
,`Agency Name` as agency_name
,`Line Item Id` as `Line_Item_or_Placement_ID`
,`Line Item Name` as `Line_Item_or_Placement_Name`
,`Line Item Type` as `Demand_Type`
,`Line Item Start Date` as `Line_Item_or_Placement_Start_Date`
,`Line Item End Date` as `Line_Item_or_Placement_End_Date`
,`Show Name` as show_name
,CASE WHEN regexp_substr(`Order Name`,'^\\\d+[^-|_| ]*')  in (select distinct regexp_substr(`Insertion_Order_Name`,'^\\\d+[^-|_| ]*')  from fox_bi_qa.gold_ad_sales.ft_freewheel_campaign_delivery) THEN True ELSE False END Multiple_Ad_Servers
,regexp_substr(`Order Name`,'^\\\d+[^-|_| ]*') `Multiple_Ad_Server_ID`
,sum(`Delivered Impressions`) `Delivered_Impressions`
,sum(`Delivered Clicks`) `Delivered_Clicks`
,`Create Timestamp` as Create_Timestamp
,`Modified Timestamp` as modified_timestamp
-- ;select * 
from   fox_bi_qa.gold_ad_sales.v_ft_gam_campaign_delivery_hourly
group by all 
)
, fw_show as (
select 
 'Freewheel'  as `Data_Source` 
,event_date as `Event_Date`
,COALESCE(Campaign_ID, Deal_ID) as `Campaign_ID`
,COALESCE(Campaign_Name, Deal_Name) as `Campaign_Name`
,COALESCE(campaign_start_timestamp_est, Deal_Start_Date) as `Campaign_Start_Date`
,COALESCE(campaign_end_timestamp_est, Deal_End_Date) as `Campaign_End_Date`
,Insertion_Order_ID as `Order_ID`
,Insertion_Order_Name as `Order_Name`
,Advertiser_Name as `Advertiser_Name`
,Agency_Name as `Agency_Name`
,placement_id as `Line_Item_or_Placement_ID`
,placement_name as `Line_Item_or_Placement_Name`
,case when sales_channel_type = 'Programmatic' then deal_type else sales_channel_type end as `Demand_Type`
,placement_start_date as `Line_Item_or_Placement_Start_Date`
,placement_end_date as `Line_Item_or_Placement_End_Date`
,show_name as `Show_Name`
,CASE WHEN regexp_substr(`Insertion_Order_Name`,'^\\\d+[^-|_| ]*') in (select distinct regexp_substr(`Order Name`,'^\\\d+[^-|_| ]*') from fox_bi_qa.gold_ad_sales.v_ft_gam_campaign_delivery_hourly) THEN True ELSE False END Multiple_Ad_Servers
,regexp_substr(`Insertion_Order_Name`,'^\\\d+[^-|_| ]*') `Multiple_Ad_Server_ID`
,sum(delivered_impressions) `Delivered_Impressions`
,sum(delivered_clicks) `Delivered_Clicks`
,Create_Timestamp 
, Modified_Timestamp 
 from fox_bi_qa.gold_ad_sales.ft_freewheel_campaign_delivery
 group by all
)
select * from gam_show
 UNION all
select * from fw_show

"""


unified_campaign_show_delivery = spark.sql(query)

# COMMAND ----------

unified_campaign_show_delivery.write.format('delta')\
    .mode('overwrite')\
    .partitionBy('Campaign_ID')\
    .option('mergeSchema', 'true')\
    .option('overwriteDynamicPartitions', 'true')\
    .option('delta.enableDeletionVectors', 'false')\
    .option('delta.enableIcebergCompatV2', 'true')\
    .option('delta.universalFormat.enabledFormats', 'iceberg')\
    .option('delta.columnMapping.mode', 'name')\
    .saveAsTable('fox_bi_qa.gold_ad_sales.ft_unified_campaign_show_delivery')