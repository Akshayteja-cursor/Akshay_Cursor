# Databricks notebook source
from datetime import datetime, timedelta

# COMMAND ----------

# DBTITLE 1,Cell 2

date = dbutils.widgets.get('date')

# COMMAND ----------

fw_query = """
    
with fw_geo as (
  select
    'Freewheel' as `Data_Source`,
    event_date::date,
    Campaign_ID::bigint,
    Campaign_Name::string,
    to_date(campaign_start_timestamp_est,'%Y-%m-%d') as campaign_start_date,
    to_date(campaign_end_timestamp_est,'%Y-%m-%d') as campaign_end_date,
    Insertion_Order_ID::bigint,
    Insertion_Order_Name::string,
    Advertiser_Name::string,
    Agency_Name::string,
    placement_id::bigint as `Line_Item_or_Placement_ID`,
    placement_name::string as `Line_Item_or_Placement_Name`,
    'Direct Sold' as `Demand_Type`,
    delivered_city_name::string as `City_Name`,
    delivered_country_name::string as `Country_Name`,
    delivered_state_province_name::string as `State_Province_Name`,
    sum(net_counted_ads) as `Delivered_Impressions`,
    sum(delivered_clicks) as `Delivered_Clicks`,
    case
      when regexp_substr(`Insertion_Order_Name`, '^\d+[^-|_| ]*') in (
        select distinct regexp_substr(`Order Name`, '^\d+[^-|_| ]*')
        from fox_bi_qa.gold_ad_sales.v_ft_gam_campaign_delivery_geo
      ) then true
      else false
    end as `Multiple_Ad_Server_Flag`,
    regexp_substr(`Insertion_Order_Name`, '^\d+[^-|_| ]*') as `Multiple_Ad_Server_ID`,
    etl_load_timestamp as `Create_Timestamp`,
    etl_load_timestamp as `Modified_Timestamp`
  from fox_bi_dev.silver_ads.ft_freewheel_geo_daily_data
  where campaign_end_timestamp_est >= '{}' 
  group by all
)
select * from fw_geo

"""

gam_query = """

with gam_geo as (
  select
    'GAM' as `Data_Source`,
    event_date::Date, 
    Campaign_ID::bigint,
    Campaign_Name::string,
    campaign_start_date::Date,
    campaign_end_date::Date,
    order_id::bigint Insertion_Order_ID,
    order_name::string Insertion_Order_Name,
    Advertiser_Name::string,
    Agency_Name::string,
    line_item_id::bigint Line_Item_or_Placement_ID,
    line_item_name::string Line_Item_or_Placement_Name,
    `Line_Item_Type`::string as `Demand_Type`,
    `City_Name`::string as city_Name,
    `Country_Name`::string as `Country_Name`,
    `State_Province_Name`::string as `State_Province_Name`,
    sum(`total_impressions`) as `Delivered_Impressions`,
    sum(`total_Clicks`) as `Delivered_Clicks`,
    case
      when regexp_substr(`Order_Name`, '^\d+[^-|_| ]*') in (
        select distinct regexp_substr(`Insertion_Order_Name`, '^\d+[^-|_| ]*')
        from fox_bi_dev.silver_ads.ft_freewheel_geo_daily_data
      ) then true
      else false
    end as `Multiple_Ad_Server_Flag`,
    regexp_substr(`Order_Name`, '^\d+[^-|_| ]*') as `Multiple_Ad_Server_ID`,
    `etl_created_timestamp` as `Create_Timestamp`,
     `etl_updated_Timestamp` as `Modified_Timestamp`
  from fox_bi_dev.gold_ad_sales.mv_ft_gam_campaign_delivery_geo
  where campaign_end_date >= '{}'
  group by all
)

select * from gam_geo
"""

if datetime.strptime(date, '%Y-%m-%d').day < 5:
    date = (datetime.strptime(date, '%Y-%m-%d') - timedelta(days=95)).replace(day=1).strftime('%Y-%m-%d')
else:
    date = (datetime.strptime(date, '%Y-%m-%d') - timedelta(days=90)).replace(day=1).strftime('%Y-%m-%d')


fw_campaign_delivery = spark.sql(fw_query.format(date))
gam_campaign_delivery = spark.sql(gam_query.format(date))

# COMMAND ----------

fw_campaign_delivery.write.format('delta')\
    .mode('overwrite')\
    .partitionBy('Data_Source', 'Event_Date')\
    .option('mergeSchema', 'true')\
    .option('overwriteDynamicPartitions', 'true')\
    .option('delta.enableDeletionVectors', 'false')\
    .option('delta.enableIcebergCompatV2', 'true')\
    .option('delta.universalFormat.enabledFormats', 'iceberg')\
    .option('delta.columnMapping.mode', 'name')\
    .saveAsTable('fox_bi_qa.gold_ad_sales.ft_unified_campaign_geo_delivery_test')


# COMMAND ----------


gam_campaign_delivery.write.format('delta')\
    .mode('overwrite')\
    .partitionBy('Data_Source', 'Event_Date')\
    .option('mergeSchema', 'true')\
    .option('overwriteDynamicPartitions', 'true')\
    .option('delta.enableDeletionVectors', 'false')\
    .option('delta.enableIcebergCompatV2', 'true')\
    .option('delta.universalFormat.enabledFormats', 'iceberg')\
    .option('delta.columnMapping.mode', 'name')\
    .saveAsTable('fox_bi_qa.gold_ad_sales.ft_unified_campaign_geo_delivery_test')