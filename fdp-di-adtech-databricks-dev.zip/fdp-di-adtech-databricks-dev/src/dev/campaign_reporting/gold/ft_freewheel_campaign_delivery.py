# Databricks notebook source
from datetime import datetime, timedelta

# COMMAND ----------

date = dbutils.widgets.get('date')

# COMMAND ----------

query = """
    WITH campaign_delivery AS (
        SELECT
        /*+ BROADCAST(dim_plc, dim_camp) */
            camp.event_date,
            camp.campaign_id,
            UPPER(camp.campaign_name) AS campaign_name,
            campaign_start_timestamp_est,
            campaign_end_timestamp_est,
            camp.advertiser_id,
            UPPER(camp.advertiser_name) AS advertiser_name,
            UPPER(camp.agency_name) AS agency_name,
            camp.placement_id,
            UPPER(placement_name) AS placement_name,
            placement_start_timestamp_est::date AS placement_start_date,
            placement_end_timestamp_est::date AS placement_end_date,
            global_ad_unit_position,
            global_ad_unit_category,
            UPPER(series_name) AS series_name,
            UPPER(show_name) AS show_name,
            UPPER(video_vertical) AS video_vertical,
            UPPER(video_vertical) AS business_unit,
            UPPER(CASE
                WHEN device_name LIKE 'CTV' THEN 'CTV'
                WHEN device_name LIKE 'STB' THEN 'STB'
                WHEN device_name LIKE 'MB/TB' THEN 'Mobile/Tablet Web'
                WHEN device_name LIKE 'DT' THEN 'Desktop Web'
                ELSE 'N/A'
            END) AS device_name,
            dim_plc.placement_avg_user_frequency,
            dim_camp.campaign_avg_user_frequency,
            video_id,
            UPPER(video_name) AS video_name,
            camp.insertion_order_id,
            UPPER(camp.insertion_order_name) AS insertion_order_name,
            camp.insertion_order_start_timestamp_est::DATE AS insertion_order_start_date,
            camp.insertion_order_end_timestamp_est::DATE AS insertion_order_end_date,
            deal_id,
            UPPER(deal_name) AS deal_name,
            deal_start_timestamp_est::date AS deal_start_date,
            deal_end_timestamp_est::date AS deal_end_date,
            UPPER(deal_type) AS deal_type,
            external_deal_id,
            programmatic_ad_id,
            programmatic_creative_duration,
            deal_ad_units,
            dsp_name,
            CASE
                WHEN platform_group = 'Tubi' THEN 'FOX on Tubi'
                WHEN video_vertical = 'Entertainment' THEN
                    CASE
                        WHEN platform_group = 'Hulu' THEN 'FOX on Hulu'
                        WHEN platform_group = 'STB VOD' THEN 'STB VOD'
                        ELSE 'FOX'
                    END
                ELSE video_vertical
            END AS Property,
            camp.creative_id,
            camp.creative_name,
            creative_duration_secs,
            video_duration,
            stream_type,
            UPPER(camp.sales_channel_type) AS sales_channel_type,
            camp.demo_band,
            on_target_net_delivered_impressions_quantity,
            SUM(gross_counted_ads) AS gross_counted_ads,
            SUM(net_counted_ads) AS delivered_impressions,
            SUM(run_revenue_amount) AS Delivered_Revenue,
            SUM(delivered_clicks) AS delivered_clicks,
            camp.AOS_deal_id,
            UPPER(camp.AOS_deal_name) AS AOS_deal_name,
            camp.AOS_Deal_start_date,
            camp.AOS_Deal_end_date,
            sales_order_line_item_id,
            UPPER(camp.sales_order_line_item_name) AS sales_order_line_item_name,
            UPPER(camp.AOS_advertiser_name) AS AOS_advertiser_name,
            UPPER(camp.foxipedia_agency_name) AS AOS_agency_name,
            UPPER(camp.Campaign_Name_Derived) AS Campaign_Name_Derived,
            UPPER(camp.package_name) AS package_name,
            UPPER(camp.owner_name) AS owner_name,
            camp.net_unit_cost,
            camp.placement_delivered_demo_comp AS demo_comp,
            guaranteed_qty AS Guaranteed_Impressions,
            camp.guaranteed_revenue AS Guaranteed_Revenue,
            ps_line_item_id AS External_AD_ID,
            UPPER(camp.parent_line_item_name) AS parent_line_item_name,
            UPPER(camp.primary_salesperson_name) AS primary_salesperson_name,
            UPPER(camp.account_coordinator) AS account_coordinator,
            UPPER(camp.fw_audience_segment) AS fw_audience_segment,
            UPPER(array_join(array_sort(split(camp.fw_video_group, ', ')),', ')) AS fw_video_group, 
            NVL(CASE
                WHEN billable_third_party_description = 'DCM' THEN 'FOX DCM'
                WHEN billable_third_party_description = 'Doubleverify' THEN 'FOX Doubleverify'
                WHEN billable_third_party_description = 'Innovid' THEN 'FOX Innovid'
                WHEN billable_third_party_description = 'Flashtalking' THEN 'FOX Flashtalking'
                WHEN billable_third_party_description = 'Extreme Reach' THEN 'FOX Extreme Reach'
                WHEN billable_third_party_description = 'Sizmek' THEN 'FOX Sizmek'
                WHEN billable_third_party_description = '1st Party' THEN 'FOX 1st Party'
                ELSE billable_third_party_description
            END, 'N/A') AS billable_third_part_server,
            camp.etl_load_timestamp AS Create_Timestamp,
            camp.etl_load_timestamp AS Modified_Timestamp
        FROM fox_bi_qa.gold_ad_sales.ft_freewheel_delivery_daily camp
        LEFT JOIN (
            SELECT
                event_date,
                placement_id,
                campaign_id,
                advertiser_name,
                agency_name,
                insertion_order_id,
                SUM(on_target_net_delivered_impressions_quantity) AS on_target_net_delivered_impressions_quantity
            FROM fox_bi_qa.gold_ad_sales.ft_freewheel_demo_comp_daily
            WHERE event_date::date >= '2024-01-01'
            GROUP BY ALL
        ) dc
            ON dc.placement_id = camp.placement_id
            AND dc.campaign_id = camp.campaign_id
            AND dc.advertiser_name = camp.advertiser_name
            AND dc.agency_name = camp.agency_name
            AND dc.insertion_order_id = camp.insertion_order_id
            AND dc.event_date = camp.event_date
        LEFT JOIN ( 
            SELECT DISTINCT 
                Placement_ID,
                placement_avg_user_frequency
            FROM fox_bi_dev.silver_ads.dim_freewheel_analytics_placement
        ) dim_plc
            ON dim_plc.Placement_ID = camp.Placement_ID
        LEFT JOIN ( 
            SELECT DISTINCT 
                Campaign_ID,
                campaign_avg_user_frequency
            FROM fox_bi_dev.silver_ads.dim_freewheel_analytics_campaign
        ) dim_camp
            ON dim_camp.Campaign_ID = camp.Campaign_ID
        WHERE 1 = 1
            AND camp.event_date::date >= '2024-01-01'
            AND camp.sales_channel_type IN ('Direct Sold')
            AND NVL(camp.campaign_name, 'N/A') NOT ILIKE '%promo%'
            AND NVL(camp.agency_name, 'N/A') NOT IN ('FNG IN-HOUSE MARKETING & PROMOTIONS')
            AND NVL(camp.advertiser_name, 'N/A') NOT ILIKE '%promo%'
            AND NVL(camp.advertiser_name, 'N/A') NOT IN ('Placeholder Advertiser')
            AND NVL(camp.agency_name, 'N/A') NOT IN ('Placeholder Agency')
            AND NVL(camp.ps_line_item_id, -1) <> -1
            AND NVL(camp.sales_order_line_item_name, -1) NOT ILIKE '%cancelled%'
        GROUP BY ALL
    ),
    tpcd AS (
        SELECT
            camp.event_date,
            camp.creative_id,
            placement_id,
            global_ad_unit_position,
            billable_third_part_server,
            MAX(tpcd.Third_Party_Line_Item_ID) AS Third_Party_Line_Item_ID,
            SUM(tpcd.third_party_video_completes) AS third_party_video_completes,
            SUM(tpcd.third_party_video_views) AS third_party_video_views,
            SUM(tpcd.third_party_billable_impressions) AS third_party_billable_impressions,
            SUM(tpcd.third_party_clicks) AS third_party_clicks,
            SUM(tpcd.third_party_revenue) AS third_party_revenue
        FROM (
            SELECT DISTINCT
                event_date,
                ad_unit_id,
                global_ad_unit_position,
                creative_id,
                placement_id,
                NVL(CASE
                    WHEN billable_third_party_description = 'DCM' THEN 'FOX DCM'
                    WHEN billable_third_party_description = 'Doubleverify' THEN 'FOX Doubleverify'
                    WHEN billable_third_party_description = 'Innovid' THEN 'FOX Innovid'
                    WHEN billable_third_party_description = 'Flashtalking' THEN 'FOX Flashtalking'
                    WHEN billable_third_party_description = 'Extreme Reach' THEN 'FOX Extreme Reach'
                    WHEN billable_third_party_description = 'Sizmek' THEN 'FOX Sizmek'
                    WHEN billable_third_party_description = '1st Party' THEN 'FOX 1st Party'
                    ELSE billable_third_party_description
                END, 'N/A') AS billable_third_part_server
            FROM fox_bi_qa.gold_ad_sales.ft_freewheel_delivery_daily
        ) camp
        LEFT JOIN (
            SELECT
                event_date,
                ad_unit_id,
                split_part(creative_id, '-', 1) AS creative_id,
                campaign_id AS Third_Party_Line_Item_ID,
                SUM(third_party_video_completes) AS third_party_video_completes,
                SUM(third_party_video_views) AS third_party_video_views,
                SUM(third_party_billable_impressions) AS third_party_billable_impressions,
                SUM(third_party_clicks) AS third_party_clicks,
                SUM(third_party_revenue) AS third_party_revenue,
                CASE
                    WHEN third_party_billable_server = 'Moat' THEN 'Moat'
                    WHEN third_party_billable_server IN ('DFA by Google', 'Dart Report Reader', 'Dart Report Reader, DFA by Google', 'DFP by Google') THEN 'FOX DCM'
                    WHEN third_party_billable_server = 'DoubleVerify' THEN 'FOX Doubleverify'
                    WHEN third_party_billable_server = 'Innovid 3rd Party' THEN 'FOX Innovid'
                    WHEN third_party_billable_server IN ('FlashTalking', 'FlashTalking Email Reader') THEN 'FOX Flashtalking'
                    WHEN third_party_billable_server IN ('Extreme Reach Email', 'ExtremeReachAPI') THEN 'FOX Extreme Reach'
                    WHEN third_party_billable_server IN ('MediaMind', 'MediaMind Report Reader', 'Sizmek SAS Report Reader', 'MediaMind Report Reader, Sizmek SAS Report Reader', 'Sizmek SAS Report Reader, MediaMind Report Reader') THEN 'FOX Sizmek'
                    WHEN third_party_billable_server = 'TubeMogul' THEN 'TubeMogul'
                    ELSE 'FOX 1st Party'
                END AS billable_third_party_server
            FROM fox_bi_dev.silver_ads.ft_third_party_campaign_delivery_daily_data
            WHERE ad_unit_id <> '-1'
                AND event_date::date >= '2024-01-01'
            GROUP BY ALL
        ) tpcd
            ON split_part(tpcd.creative_id, '-', 1) = camp.creative_id
            AND tpcd.ad_unit_id = camp.ad_unit_id
            AND tpcd.event_date = camp.event_date
            AND camp.billable_third_part_server = tpcd.billable_third_party_server
        GROUP BY ALL
    ),
    final AS (
        SELECT
            camp.*,
            third_party_line_item_id,
            third_party_billable_impressions,
            third_party_clicks,
            third_party_revenue,
            third_party_video_completes,
            third_party_video_views
        FROM campaign_delivery camp
        LEFT JOIN tpcd
            ON tpcd.creative_id = camp.creative_id
            AND tpcd.event_date = camp.event_date
            AND tpcd.billable_third_part_server = camp.billable_third_part_server
            AND tpcd.global_ad_unit_position = camp.global_ad_unit_position
            AND tpcd.placement_id = camp.placement_id

    )
    SELECT *
    FROM final
    WHERE (AOS_Deal_end_date BETWEEN '{}' AND current_date())
        OR campaign_id IN (86484377)
    -- (campaign_end_timestamp_est BETWEEN '{}' AND current_date()) OR campaign_id IN (86484377)
"""

if datetime.strptime(date, '%Y-%m-%d').day < 5:
    date = (datetime.strptime(date, '%Y-%m-%d') - timedelta(days=95)).replace(day=1).strftime('%Y-%m-%d')
else:
    date = (datetime.strptime(date, '%Y-%m-%d') - timedelta(days=90)).replace(day=1).strftime('%Y-%m-%d')

fw_campaign_delivery = spark.sql(query.format(date, date, date))

# COMMAND ----------

fw_campaign_delivery.write.format('delta')\
    .mode('overwrite')\
    .partitionBy('Campaign_ID')\
    .option('mergeSchema', 'true')\
    .option('overwriteDynamicPartitions', 'true')\
    .option('delta.enableDeletionVectors', 'false')\
    .option('delta.enableIcebergCompatV2', 'true')\
    .option('delta.universalFormat.enabledFormats', 'iceberg')\
    .option('delta.columnMapping.mode', 'name')\
    .saveAsTable('fox_bi_qa.gold_ad_sales.ft_freewheel_campaign_delivery')
