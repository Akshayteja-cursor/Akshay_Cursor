# Databricks notebook source
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# COMMAND ----------

dbutils.widgets.dropdown("truncate_flag", "false", ["true", "false"])
dbutils.widgets.text("wrap_detailed_audit_table", "fox_bi_dev.bronze_ads.wrap_report_audit")

# COMMAND ----------

spark.conf.set("spark.databricks.remoteFiltering.blockSelfJoins", "false")

# COMMAND ----------

# MAGIC %md
# MAGIC # Parallel Execution Wrapper for wrap_detailed_unified_report_sections_by_deal
# MAGIC
# MAGIC This notebook splits deals into batches and triggers the main notebook in parallel for each batch.

# COMMAND ----------

truncate_flag = dbutils.widgets.get("truncate_flag")
wrap_detailed_audit_table = dbutils.widgets.get("wrap_detailed_audit_table")

# COMMAND ----------

# Configuration
notebook_path = "/Workspace/Repos/adtech/fdp-di-adtech-databricks/src/dev/campaign_reporting/gold/wrap_detailed_unified_report_sections_by_deal"
timeout_seconds = 3600  # 1 hour timeout per parallel execution
max_parallel = 9  # Number of parallel executions (adjust based on cluster capacity)
batch_size = 12  # Number of deals per batch

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM fox_bi_qa.gold_ad_sales.wrap_detailed_unified_report_sections_by_deal
# MAGIC WHERE AOS_Deal_ID NOT IN (
# MAGIC     SELECT DISTINCT aos_deal_id
# MAGIC     FROM fox_bi_qa.gold_ad_sales.ft_unified_campaign_delivery
# MAGIC     where aos_deal_id IS NOT NULL
# MAGIC )

# COMMAND ----------

# Conditional logic
if truncate_flag.lower() == "true":
    spark.sql(f"TRUNCATE TABLE {wrap_detailed_audit_table}")
    print("ℹ️ Truncate flag is true — executing full load.")
    print(f"✅ Table {wrap_detailed_audit_table} truncated")
else:
    print("ℹ️ Truncate flag is false — executing incremental load.")

# COMMAND ----------

# Get all deals to process
deals_query = """

with source_max_timestamps as (
select distinct aos_deal_id, MAX(last_modified_timestamp) AS src_max_last_modified_timestamp
from (
    SELECT DISTINCT
        `AOS Deal ID` AS aos_deal_id, `Modified Timestamp` as last_modified_timestamp
    FROM fox_bi_qa.gold_ad_sales.v_ft_gam_campaign_delivery
    union
    SELECT DISTINCT
        `AOS_Deal ID` AS aos_deal_id, `Modified Timestamp` as last_modified_timestamp
    FROM fox_bi_qa.gold_ad_sales.v_ft_freewheel_campaign_delivery
    )
    group by aos_deal_id
),
target_max_timestamps AS (
    SELECT AOS_Deal_ID AS aos_deal_id, `Modified Timestamp` AS tar_max_last_modified_timestamp
    FROM fox_bi_dev.bronze_ads.wrap_report_audit
    --GROUP BY AOS_Deal_ID
)

select distinct aos_deal_id
from
(
-- (a) Existing deals where source has been updated since target was last written
  SELECT s.aos_deal_id
  FROM source_max_timestamps s
  INNER JOIN target_max_timestamps t
      ON s.aos_deal_id = t.aos_deal_id
  WHERE s.src_max_last_modified_timestamp > t.tar_max_last_modified_timestamp

  UNION

-- (b) New deals in source that do not exist in target yet
  SELECT s.aos_deal_id
  FROM source_max_timestamps s
  LEFT ANTI JOIN target_max_timestamps t
      ON s.aos_deal_id = t.aos_deal_id
)
"""

deals_df = spark.sql(deals_query)

deals = [deal['aos_deal_id'] for deal in deals_df.select('aos_deal_id').collect()]

if not deals:
    print("No new or updated deals to process. Exiting.")
    dbutils.notebook.exit("NO_DEALS_TO_PROCESS")

print(f'Total deals to process: {len(deals)}')


# COMMAND ----------

# Split deals into batches for parallel processing
deal_batches = [deals[n:n+batch_size] for n in range(0, len(deals), batch_size)]

print(f'Number of batches: {len(deal_batches)}')
print(f'Batch size: {batch_size}')
print(f'Max parallel executions: {max_parallel}')


# Check if table exists and create if it doesn't
table_name = "fox_bi_qa.gold_Ad_Sales.wrap_detailed_unified_report_sections_by_deal"

# Check if table exists
table_exists = spark.catalog.tableExists(table_name)

if not table_exists:
    print(f"Table {table_name} does not exist. Creating table...")
    
    create_table_ddl = """
    CREATE TABLE fox_bi_qa.gold_Ad_Sales.wrap_detailed_unified_report_sections_by_deal (
      data_type STRING,
      AOS_Deal_ID BIGINT,
      field1 STRING,
      field2 STRING,
      field3 STRING,
      field4 STRING,
      field5 STRING,
      field6 STRING,
      field7 STRING,
      field8 STRING,
      field9 STRING,
      field10 STRING,
      field11 STRING,
      field12 STRING,
      field13 STRING,
      field14 STRING,
      field15 STRING,
      field16 STRING,
      field17 STRING,
      field18 STRING,
      field19 STRING,
      field20 STRING,
      field21 STRING,
      field22 STRING,
      field23 STRING,
      field24 STRING,
      field25 STRING)
    USING delta
    PARTITIONED BY (AOS_Deal_ID)
    TBLPROPERTIES (
      'delta.columnMapping.mode' = 'name',
      'delta.enableDeletionVectors' = 'false',
      'delta.enableIcebergCompatV2' = 'true',
      'delta.feature.appendOnly' = 'supported',
      'delta.feature.columnMapping' = 'supported',
      'delta.feature.icebergCompatV2' = 'supported',
      'delta.feature.invariants' = 'supported',
      'delta.minReaderVersion' = '2',
      'delta.minWriterVersion' = '7',
      'delta.parquet.compression.codec' = 'zstd',
      'delta.universalFormat.enabledFormats' = 'iceberg')
    """
    
    spark.sql(create_table_ddl)
    print(f"Table {table_name} created successfully.")
else:
    print(f"Table {table_name} already exists. Continuing...")

# COMMAND ----------

def run_notebook_with_batch(batch_number, deal_batch):
    """Run the notebook with a specific batch of deals"""
    try:
        parameters = {
            "deal_ids": str(deal_batch),  # Pass as string representation of list
            "batch_number": str(batch_number)
        }
        
        print(f"Starting batch {batch_number} with {len(deal_batch)} deals: {deal_batch[:5]}...")
        result = dbutils.notebook.run(
            notebook_path,
            timeout_seconds,
            parameters
        )
        print(f"Completed batch {batch_number}: {result}")
        return {"batch_number": batch_number, "status": "SUCCESS", "result": result, "deals": deal_batch}
    except Exception as e:
        error_msg = str(e)
        print(f"Error in batch {batch_number}: {error_msg}")
        return {"batch_number": batch_number, "status": "FAILED", "error": error_msg, "deals": deal_batch}

# COMMAND ----------

# Execute batches in parallel
start_time = time.time()
results = []
max_retries = 5

print(f'\n=== Starting parallel execution of {len(deal_batches)} batches ===\n')

with ThreadPoolExecutor(max_workers=max_parallel) as executor:
    # Submit all batches
    future_to_batch = {
        executor.submit(run_notebook_with_batch, i, batch): (i, batch) 
        for i, batch in enumerate(deal_batches)
    }
    
    # Collect results as they complete
    for future in as_completed(future_to_batch):
        batch_num, batch = future_to_batch[future]
        try:
            result = future.result()
            results.append(result)
            print(f"✓ Batch {batch_num} finished: {result['status']}")
        except Exception as e:
            print(f"✗ Batch {batch_num} generated an exception: {str(e)}")
            results.append({"batch_number": batch_num, "status": "FAILED", "error": str(e), "deals": batch})

# Retry failed batches
for attempt in range(1, max_retries + 1):
    failed_results = [r for r in results if r['status'] == 'FAILED']
    if not failed_results:
        break
    print(f'\n=== Retry attempt {attempt}/{max_retries} for {len(failed_results)} failed batch(es) ===\n')
    results = [r for r in results if r['status'] != 'FAILED']
    with ThreadPoolExecutor(max_workers=max_parallel) as executor:
        future_to_batch = {
            executor.submit(run_notebook_with_batch, r['batch_number'], r['deals']): (r['batch_number'], r['deals'])
            for r in failed_results
        }
        for future in as_completed(future_to_batch):
            batch_num, batch = future_to_batch[future]
            try:
                result = future.result()
                results.append(result)
                print(f"✓ Batch {batch_num} retry finished: {result['status']}")
            except Exception as e:
                print(f"✗ Batch {batch_num} retry failed: {str(e)}")
                results.append({"batch_number": batch_num, "status": "FAILED", "error": str(e), "deals": batch})

# COMMAND ----------

# Summary
total_duration = time.time() - start_time
successful = sum(1 for r in results if r['status'] == 'SUCCESS')
failed = sum(1 for r in results if r['status'] == 'FAILED')

print(f'\n=== Parallel Execution Summary ===')
print(f'Total batches: {len(results)}')
print(f'Successful: {successful}')
print(f'Failed: {failed}')
print(f'Total execution time: {total_duration:.2f} seconds ({total_duration/60:.2f} minutes)')
print(f'Average time per batch: {total_duration/len(results):.2f} seconds')

# Display failed batches if any
if failed > 0:
    print('\n✗ Failed batches:')
    for r in results:
        if r['status'] == 'FAILED':
            print(f"  Batch {r['batch_number']}: {r.get('error', 'Unknown error')}")
            print(f"    Deals: {r.get('deals', [])[:10]}...")
else:
    print('\n✓ All batches completed successfully!')

# COMMAND ----------

query = """
SELECT
    distinct
    w.AOS_Deal_ID,
    d.`Modified Timestamp`
FROM (
    SELECT DISTINCT AOS_Deal_ID
    FROM fox_bi_qa.gold_ad_sales.wrap_detailed_unified_report_sections_by_deal
) w
LEFT JOIN fox_bi_qa.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal d
    ON w.AOS_Deal_ID = d.`AOS Deal ID`
"""

result_df = spark.sql(query)

# Write to a new table
audit_table_name = "fox_bi_dev.bronze_ads.wrap_report_audit"

if not spark.catalog.tableExists(audit_table_name):
    result_df.write.format('delta')\
        .mode('overwrite')\
        .option('mergeSchema', 'true')\
        .option('delta.enableDeletionVectors', 'false')\
        .option('delta.enableIcebergCompatV2', 'true')\
        .option('delta.universalFormat.enabledFormats', 'iceberg')\
        .option('delta.columnMapping.mode', 'name')\
        .saveAsTable(audit_table_name)
else:
    result_df.write.format('delta')\
        .mode('overwrite')\
        .option('mergeSchema', 'true')\
        .saveAsTable(audit_table_name)