create or replace view fox_bi_qa.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal as
(
  select
    nvl(AOS_Deal_ID,-1) as `AOS Deal ID`
  ,nvl(AOS_Deal_Name,'N/A') `AOS Deal Name`
  ,AOS_Deal_Start_Date  `AOS Deal Start Date`
  ,AOS_Deal_End_Date	`AOS Deal End Date`
  ,nvl(Advertiser_Name,'N/A') `Advertiser Name`
  ,Targeted_Demos `Targeted Demos`
  ,nvl(Agency_Name,'N/A') `Agency Name`
  ,Sales_Channels `Sales Channels`
  ,Show_Names `Show Name`
  ,Multiple_Ad_Servers_Flag	`Multiple Ad Servers Flag`
  ,nvl(Budget,0) `Budget`
  ,nvl(Spend,0)	`Spend`
  ,nvl(Overall_Performance,'N/A')	`Overall Performance`
  ,Targeted_Devices `Targeted Devices`	
  ,nvl(CPM,0)	`CPM`
  ,nvl(CTR,0)	`CTR`
  ,nvl(Total_Views,0) `Total Views`
  ,nvl(Total_Delivered_Clicks,0) `Total Delivered Clicks`
  ,nvl(Total_Delivered_Revenue,0) `Total Delivered Revenue`
  ,nvl(Total_First_Party_Delivered_Revenue,0) `Total First Party Delivered Revenue`
  ,nvl(Total_Third_Party_Revenue,0) `Total Third Party Revenue`
  ,nvl(Impression_Pacing,0) `Impression Pacing`
  ,nvl(Third_Party_Impression_Pacing,0) `Third Party Impression Pacing`
  ,nvl(First_Party_Impression_Pacing,0) `First Party Impression Pacing`
  ,nvl(Revenue_Pacing,0) `Revenue Pacing`
  ,nvl(First_Party_Revenue_Pacing,0) `First Party Revenue Pacing`
  ,nvl(Third_Party_Revenue_Pacing,0) `Third Party Revenue Pacing`
  ,nvl(Total_Guaranteed_Impressions,0) `Total Guaranteed Impressions`
  ,nvl(Total_Delivered_Impressions,0) `Total Delivered Impressions`
  ,nvl(Total_First_Party_Delivered_Impressions,0) `Total First Party Delivered Impressions`
  ,nvl(Total_Third_Party_Impressions,0) `Total Third Party Impressions`
  ,Create_Timestamp	`Create Timestamp`
  ,Modified_Timestamp	`Modified Timestamp`
  ,FW_Audience_Segment `FW Audience Segment`
  ,FW_Video_Group `FW Video Group`
  ,nvl(total_creatives,0) `Total Creatives`
  ,nvl(total_placements,0) `Total Placements`
  ,nvl(total_shows,0) `Total Shows`
  ,nvl(Total_Countries,0) `Total Countries`
  ,nvl(Total_States,0) `Total States`
  ,nvl(Total_Geo_Ads,0) `Total Geo Ads`  
  from
    fox_bi_qa.gold_ad_sales.mv_ft_unified_campaign_delivery_by_deal
)