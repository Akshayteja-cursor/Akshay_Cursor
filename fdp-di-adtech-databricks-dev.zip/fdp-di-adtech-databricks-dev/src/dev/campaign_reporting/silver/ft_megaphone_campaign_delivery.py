# Databricks notebook source
env = dbutils.widgets.get('env')

if env == 'dev':
  catalog_name = 'fox_bi_dev'
  bronze_schema_name = 'bronze_ads'
  silver_schema_name = 'silver_ads'
elif env == 'prod':
  catalog_name = 'fox_bi_prod'
  bronze_schema_name = 'bronze_ads'
  silver_schema_name = 'silver_ads'

# COMMAND ----------

query = f"""
SELECT
  event_date,
  partner_server_name,
  order_id,
  campaign_id,
  advertisement_id,
  network_id,
  order_title as order_name,
  campaign_title as campaign_name,
  advertiser as advertiser_name,
  ad_title,
  podcast_title,
  network_name,
  advertiser_category,
  campaign_budget_currency,
  ad_location,
  order_start_date,
  order_end_date,
  ad_position,
  SUM(order_goal_amount) AS order_goal_amount,
  SUM(order_revenue_amount) AS order_revenue_amount,
  SUM(delivered_impressions) AS delivered_impressions,
  SUM(available_impressions) AS available_impressions,
  SUM(direct_sold_impressions) AS direct_sold_impressions,
  SUM(span_impressions) AS span_impressions,
  SUM(promo_impressions) AS promo_impressions,
  TO_DATE(DATE_FORMAT(CURRENT_TIMESTAMP(), 'yyyy-MM-dd'), 'yyyy-MM-dd') AS etl_load_date,
  CURRENT_TIMESTAMP() AS etl_load_timestamp
FROM {catalog_name}.{bronze_schema_name}.megaphone_amperwave_campaign_reporting_delivery
WHERE lower(partner_server_name) = 'megaphone'
GROUP BY ALL
"""

megaphone_campaign_delivery = spark.sql(query)

# COMMAND ----------

if not spark.catalog.tableExists(f'{catalog_name}.{silver_schema_name}.ft_megaphone_campaign_delivery'): #Add the table name for First time load 
    megaphone_campaign_delivery.write.format('delta')\
        .mode('overwrite')\
        .partitionBy('event_date')\
        .option('mergeSchema', 'true')\
        .option('overwriteDynamicPartitions', 'true')\
        .option('delta.enableDeletionVectors', 'false')\
        .option('delta.enableIcebergCompatV2', 'true')\
        .option('delta.universalFormat.enabledFormats', 'iceberg')\
        .option('delta.columnMapping.mode', 'name')\
        .saveAsTable(f"{catalog_name}.{silver_schema_name}.ft_megaphone_campaign_delivery")
else:
    megaphone_campaign_delivery.write.format('delta')\
        .mode('overwrite')\
        .option('partitionOverwriteMode', 'dynamic')\
        .saveAsTable(f"{catalog_name}.{silver_schema_name}.ft_megaphone_campaign_delivery")
