# Databricks notebook source
# COMMAND ----------

query = """
    SELECT
        event_date
        , ad_unit_id
        , ad_unit_name
        , creative_id
        , creative_name
        , campaign_id
        , campaign_name
        , third_party_campaign_id
        , third_party_campaign_name
        , campaign_start_date
        , campaign_end_date
        , third_party_placement_id
        , third_party_placement_name
        , third_party_billable_server
        , third_party_video_100_percent_complete
        , third_party_video_views
        , third_party_billable_impressions
        , third_party_revenue
        , clicks_third_party
    FROM fox_bi_dev.bronze_ads.third_party_campaign_reporting_delivery
"""

spark.sql(query).createOrReplaceTempView('third_party_campaign_reporting_delivery')

# COMMAND ----------

final_query = """
    SELECT
        ad_unit_id
        , ad_unit_name
        , creative_id
        , creative_name
        , campaign_id
        , campaign_name
        , third_party_campaign_id
        , third_party_campaign_name
        , campaign_start_date
        , campaign_end_date
        , third_party_placement_id
        , third_party_placement_name
        , third_party_billable_server
        , '' AS business_unit
        , SUM(third_party_video_100_percent_complete) AS third_party_video_completes
        , SUM(third_party_video_views) AS third_party_video_views
        , SUM(third_party_billable_impressions) AS third_party_billable_impressions
        , SUM(clicks_third_party) AS third_party_clicks
        , SUM(third_party_revenue) AS third_party_revenue
        , event_date
        , DATE_FORMAT(event_date, 'MM') as event_month
        , DATE_FORMAT(event_date, "y-'Q'Q") as event_quarter
        , DATE_FORMAT(event_date, 'y') as event_year
        , event_year||event_month as ad_month_id
        , DATE_FORMAT(event_date, 'MMMM-y') as ad_month_year
        , TO_DATE(DATE_FORMAT(CURRENT_TIMESTAMP(), 'yyyy-MM-dd'), 'yyyy-MM-dd') AS etl_load_date
        , CURRENT_TIMESTAMP() AS etl_load_timestamp
        FROM third_party_campaign_reporting_delivery
        GROUP BY
            ad_unit_id
            , ad_unit_name
            , creative_id
            , creative_name
            , campaign_id
            , campaign_name
            , third_party_campaign_id
            , third_party_campaign_name
            , campaign_start_date
            , campaign_end_date
            , third_party_placement_id
            , third_party_placement_name
            , third_party_billable_server
            , business_unit
            , event_date
"""

third_party_delivery_data = spark.sql(final_query)

# COMMAND ----------

if not spark.catalog.tableExists(f'fox_bi_dev.silver_ads.ft_third_party_campaign_delivery_daily_data'): #Add the table name for First time load 
    third_party_delivery_data.write.format('delta')\
        .mode('overwrite')\
        .partitionBy('event_date')\
        .option('mergeSchema', 'true')\
        .option('overwriteDynamicPartitions', 'true')\
        .option('delta.enableDeletionVectors', 'false')\
        .option('delta.enableIcebergCompatV2', 'true')\
        .option('delta.universalFormat.enabledFormats', 'iceberg')\
        .option('delta.columnMapping.mode', 'name')\
        .saveAsTable(f"fox_bi_dev.silver_ads.ft_third_party_campaign_delivery_daily_data")
else:
    third_party_delivery_data.write.format('delta')\
        .mode('overwrite')\
        .option('partitionOverwriteMode', 'dynamic')\
        .saveAsTable(f"fox_bi_dev.silver_ads.ft_third_party_campaign_delivery_daily_data")

# COMMAND ----------

# MAGIC %sql
# MAGIC select event_date, count(*) from fox_bi_dev.silver_ads.ft_third_party_campaign_delivery_daily_data group by event_date order by event_date