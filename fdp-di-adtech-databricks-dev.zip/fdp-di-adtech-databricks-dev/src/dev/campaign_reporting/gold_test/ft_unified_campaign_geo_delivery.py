# Databricks notebook source
from datetime import datetime, timedelta

# COMMAND ----------

# MAGIC %run ./campaign_config

# COMMAND ----------

spark.sparkContext.setCheckpointDir("dbfs:/checkpoints/ft_unified_campaign_geo_delivery")

# COMMAND ----------

# Reduce shuffle partitions
spark.conf.set("spark.sql.shuffle.partitions", "200")

# COMMAND ----------

# Adaptive query execution
spark.conf.set("spark.sql.adaptive.enabled",                    "true")
spark.conf.set("spark.sql.adaptive.localShuffleReader.enabled", "true")
spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled", "true")

# COMMAND ----------

# Delta optimized write
spark.conf.set("spark.databricks.delta.optimizeWrite.enabled", "true")
spark.conf.set("spark.databricks.delta.autoCompact.enabled",   "true")


# COMMAND ----------

# DBTITLE 1,Cell 7
# Compute the lookback date
if datetime.strptime(date, '%Y-%m-%d').day < 5:
    lookback_date = (datetime.strptime(date, '%Y-%m-%d') - timedelta(days=95)).replace(day=1).strftime('%Y-%m-%d')
else:
    lookback_date = (datetime.strptime(date, '%Y-%m-%d') - timedelta(days=90)).replace(day=1).strftime('%Y-%m-%d')

campaign_delivery_query = f"""
    
with mv_ft_gam_campaign_delivery_geo as (
  select
    gam_geo.line_item_id,
    gam_geo.line_item_name,
    coalesce(op_line_detail.campaign_id, -1) as campaign_id,
    coalesce(op_line_detail.campaign_name, 'N/A') as campaign_name,
    coalesce(gam_sum.order_id, -1) as order_id,
    coalesce(gam_sum.order_name, 'N/A') as order_name,
    coalesce(gam_sum.advertiser_name, 'N/A') as advertiser_name,
    coalesce(op_line_detail.agency_name, 'N/A') as agency_name,
    coalesce(op_line_detail.owner_name, 'N/A') as account_manager,
    gam_dim.line_item_start_timestamp as line_item_start_date,
    gam_dim.line_item_end_timestamp as line_item_end_date,
    op_line_detail.campaign_start_date as campaign_start_date,
    op_line_detail.campaign_end_date as campaign_end_date,
    gam_sum.line_item_type as line_item_type,
    gam_geo.event_date as event_date,
    gam_geo.city_criteria_id as city_criteria_id,
    gam_geo.city_name as city_name,
    gam_geo.neighborhood_name as neighborhood_name,
    gam_geo.state_province_name as state_province_name,
    gam_geo.country_name as country_name,
    gam_geo.total_impressions as total_impressions,
    gam_geo.total_clicks as total_clicks,
    gam_geo.etl_created_timestamp as etl_created_timestamp,
    gam_geo.etl_updated_timestamp as etl_updated_timestamp
  from
    {catalog_dev}.{adtech_schema_silver}.ft_gam_summary_daily_geo_data gam_geo
      left join {catalog_dev}.{adtech_schema_silver}.dim_gam_line_item_data gam_sum
        on gam_geo.line_item_id = gam_sum.line_item_id
        and gam_geo.line_item_id <> -1
      left join {catalog_dev}.{adtech_schema_silver}.dim_line_item gam_dim
        on gam_geo.line_item_id = gam_dim.line_item_id
        and gam_geo.line_item_id <> -1
      left join (
        select
          sales_line_item_id,
          agency_name,
          ps_line_item_id,
          sales_order_id as campaign_id,
          sales_order_name as campaign_name,
          sales_order_start_date as campaign_start_date,
          sales_order_end_date as campaign_end_date,
          owner_name
        from
          {catalog_prod}.{adsales_schema_gold}.ft_digital_operative_line_detail
        group by
          all
      ) op_line_detail
        on gam_geo.line_item_id = op_line_detail.ps_line_item_id
        and gam_geo.line_item_id <> -1
  where
    upper(gam_sum.line_item_type) in ('BULK', 'STANDARD', 'SPONSORSHIP')
)
,fw_geo as (
  select
    'Freewheel' as `Data_Source`,
    event_date::date,
    Campaign_ID::bigint,
    Campaign_Name::string,
    to_date(campaign_start_timestamp_est,'%Y-%m-%d') as campaign_start_date,
    to_date(campaign_end_timestamp_est,'%Y-%m-%d') as campaign_end_date,
    Insertion_Order_ID::bigint,
    Insertion_Order_Name::string,
    Advertiser_Name::string,
    Agency_Name::string,
    account_manager::string as `Account_Manager`,
    AOS_Deal_ID::bigint as `AOS_Deal_ID`,
    placement_id::bigint as `Line_Item_or_Placement_ID`,
    placement_name::string as `Line_Item_or_Placement_Name`,
    'Direct Sold' as `Demand_Type`,
    delivered_city_name::string as `City_Name`,
    delivered_country_name::string as `Country_Name`,
    delivered_state_province_name::string as `State_Province_Name`,
    sum(net_counted_ads) as `Delivered_Impressions`,
    sum(delivered_clicks) as `Delivered_Clicks`,
    case
      when regexp_substr(`Insertion_Order_Name`, '^\\\d+[^-|_| ]*') in (
        select regexp_substr(`Order_Name`, '^\\\d+[^-|_| ]*')
        from mv_ft_gam_campaign_delivery_geo
        group by all
      ) then true
      else false
    end as `Multiple_Ad_Server_Flag`,
    regexp_substr(`Insertion_Order_Name`, '^\\\d+[^-|_| ]*') as `Multiple_Ad_Server_ID`,
    etl_load_timestamp as `Create_Timestamp`,
    etl_load_timestamp as `Modified_Timestamp`
  from {catalog_dev}.{adtech_schema_silver}.ft_freewheel_geo_daily_data geo
  left join (select ps_line_item_id, owner_name account_manager, sales_order_ID::bigint as AOS_Deal_ID
    from {catalog_prod}.{adsales_schema_gold}.ft_digital_operative_line_detail group by all) oms
  on oms.ps_line_item_id = geo.placement_id
  where campaign_end_timestamp_est >= '{lookback_date}' 
  group by all
)
, gam_geo as (
  select
    'GAM' as `Data_Source`,
    event_date::Date, 
    Campaign_ID::bigint,
    Campaign_Name::string,
    campaign_start_date::Date,
    campaign_end_date::Date,
    order_id::bigint Insertion_Order_ID,
    order_name::string Insertion_Order_Name,
    Advertiser_Name::string,
    Agency_Name::string,
    account_manager::string as Account_Manager,
    Campaign_ID::bigint AOS_Deal_ID,
    line_item_id::bigint Line_Item_or_Placement_ID,
    line_item_name::string Line_Item_or_Placement_Name,
    `Line_Item_Type`::string as `Demand_Type`,
    `City_Name`::string as city_Name,
    `Country_Name`::string as `Country_Name`,
    `State_Province_Name`::string as `State_Province_Name`,
    sum(`total_impressions`) as `Delivered_Impressions`,
    sum(`total_Clicks`) as `Delivered_Clicks`,
    case
      when regexp_substr(`Order_Name`, '^\\\d+[^-|_| ]*') in (
        select regexp_substr(`Insertion_Order_Name`, '^\\\d+[^-|_| ]*')
        from {catalog_qa}.{adsales_schema_gold}.mv_ft_freewheel_campaign_delivery_geo_data
        group by all
      ) then true
      else false
    end as `Multiple_Ad_Server_Flag`,
    regexp_substr(`Order_Name`, '^\\\d+[^-|_| ]*') as `Multiple_Ad_Server_ID`,
    `etl_created_timestamp` as `Create_Timestamp`,
     `etl_updated_Timestamp` as `Modified_Timestamp`
  from mv_ft_gam_campaign_delivery_geo
  where campaign_end_date >= '{lookback_date}'
  group by all
)
select * from fw_geo
UNION ALL
select * from gam_geo
"""

campaign_delivery = spark.sql(campaign_delivery_query)

# COMMAND ----------

#campaign_delivery = campaign_delivery.checkpoint()   # ← materializes before shuffle

# COMMAND ----------

# DBTITLE 1,Cell 9
campaign_delivery.write.format('delta')\
    .mode('overwrite')\
    .partitionBy('Data_Source', 'Event_Date')\
    .option('mergeSchema', 'true')\
    .option("optimizeWrite", "true")\
    .option('overwriteDynamicPartitions', 'true')\
    .option('delta.enableDeletionVectors', 'false')\
    .option('delta.enableIcebergCompatV2', 'true')\
    .option('delta.universalFormat.enabledFormats', 'iceberg')\
    .option('delta.columnMapping.mode', 'name')\
    .saveAsTable(f'{catalog_qa}.test_noor.ft_unified_campaign_geo_delivery')


# COMMAND ----------


# gam_campaign_delivery.write.format('delta')\
#     .mode('overwrite')\
#     .partitionBy('Data_Source', 'Event_Date')\
#     .option('mergeSchema', 'true')\
#     .option('overwriteDynamicPartitions', 'true')\
#     .option('delta.enableDeletionVectors', 'false')\
#     .option('delta.enableIcebergCompatV2', 'true')\
#     .option('delta.universalFormat.enabledFormats', 'iceberg')\
#     .option('delta.columnMapping.mode', 'name')\
#     .saveAsTable('fox_bi_qa.gold_ad_sales.ft_unified_campaign_geo_delivery')