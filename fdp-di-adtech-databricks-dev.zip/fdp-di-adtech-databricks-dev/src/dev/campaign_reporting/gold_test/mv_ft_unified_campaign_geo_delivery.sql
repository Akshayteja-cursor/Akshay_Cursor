%sql
CREATE OR REPLACE MATERIALIZED VIEW `fox_bi_qa`.`test_noor`.`mv_ft_unified_campaign_geo_delivery`
(
    Data_Source STRING COLLATE UTF8_BINARY,
    event_date DATE,
    Campaign_ID BIGINT,
    Campaign_Name STRING COLLATE UTF8_BINARY,
    campaign_start_date DATE,
    campaign_end_date DATE,
    Insertion_Order_ID BIGINT,
    Insertion_Order_Name STRING COLLATE UTF8_BINARY,
    Advertiser_Name STRING COLLATE UTF8_BINARY,
    Agency_Name STRING COLLATE UTF8_BINARY,
    Account_Manager STRING COLLATE UTF8_BINARY,
    AOS_Deal_ID BIGINT,
    Line_Item_or_Placement_ID BIGINT,
    Line_Item_or_Placement_Name STRING COLLATE UTF8_BINARY,
    Demand_Type STRING COLLATE UTF8_BINARY,
    City_Name STRING COLLATE UTF8_BINARY,
    Country_Name STRING COLLATE UTF8_BINARY,
    State_Province_Name STRING COLLATE UTF8_BINARY,
    Delivered_Impressions BIGINT,
    Delivered_Clicks BIGINT,
    Multiple_Ad_Server_Flag BOOLEAN,
    Multiple_Ad_Server_ID STRING COLLATE UTF8_BINARY,
    Create_Timestamp TIMESTAMP,
    Modified_Timestamp TIMESTAMP
  ) AS
select
  *
FROM
  fox_bi_qa.test_noor.ft_unified_campaign_geo_delivery
CLUSTER BY
  campaign_id,
  event_date