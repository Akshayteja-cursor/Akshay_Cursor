# Databricks notebook source
env = dbutils.widgets.get('env')

if env == 'dev':
  catalog_name = 'fox_bi_dev'
  oms_catalog_name = 'fox_bi_qa'
  silver_schema_name = 'silver_ads'
  gold_schema_name = 'gold_ads'
elif env == 'prod':
  catalog_name = 'fox_bi_prod'
  oms_catalog_name = 'fox_bi_prod'
  silver_schema_name = 'silver_ads'
  gold_schema_name = 'gold_ads'

# COMMAND ----------

spark.conf.set("spark.databricks.remoteFiltering.blockSelfJoins", "false")

# COMMAND ----------

query = f"""
SELECT
  cam.event_date::date as event_date,
  cam.partner_server_name,
  cam.order_id,
  cam.campaign_id,
  cam.advertisement_id,
  cam.network_id,
  cam.order_name,
  cam.campaign_name,
  cam.advertiser_name,
  cam.ad_title,
  cam.podcast_title,
  cam.network_name,
  cam.advertiser_category,
  cam.campaign_budget_currency,
  cam.ad_location,
  cam.order_start_date,
  cam.order_end_date,
  cam.ad_position,

  op.advertiser_name AS aos_advertiser_name,
  op.agency_name AS buying_agency,
  op.placement_property AS placement_property,
  op.sales_order_name AS deal_name,
  op.sales_order_id AS deal_id,
  op.sales_order_line_item_name AS deal_line_item_name,
  op.sales_order_line_item_id AS deal_line_item_id,
  op.product_name AS product_name,
  op.forecast_category_type AS industry_category,
  op.buy_type AS buy_type,
  op.primary_salesperson_name AS account_executive,
  op.fiscal_yr AS fiscal_year,
  op.fiscal_yr_qtr AS fiscal_year_quarter,
  op.date::date AS aos_event_date,
  CASE 
    WHEN SUM(cam.delivered_impressions) OVER (PARTITION BY cam.order_id, YEAR(cam.event_date), MONTH(cam.event_date)) > 0 THEN
      oms.net_invoice_amt * 
      (cam.delivered_impressions / NULLIF(SUM(cam.delivered_impressions) OVER (PARTITION BY cam.order_id, YEAR(cam.event_date), MONTH(cam.event_date)), 0))
    ELSE NULL
  END::decimal(22,7) AS net_invoice_amount,

  cam.order_goal_amount,
  cam.order_revenue_amount,
  cam.delivered_impressions,
  cam.available_impressions,
  cam.direct_sold_impressions,
  cam.span_impressions,
  cam.promo_impressions,
  TO_DATE(DATE_FORMAT(CURRENT_TIMESTAMP(), 'yyyy-MM-dd'), 'yyyy-MM-dd') AS etl_load_date,
  CURRENT_TIMESTAMP() AS etl_load_timestamp
FROM {catalog_name}.{silver_schema_name}.ft_megaphone_campaign_delivery cam
LEFT JOIN {oms_catalog_name}.gold_ad_sales.ft_digital_operative_line_date_allocation op
  ON op.ps_line_item_id = cam.order_id --campaign_id
  and op.date = cam.event_date 
LEFT JOIN (select ps_line_item_id, 
                  year(date) as order_year, 
                  month(date) as order_month, 
                  sum(net_invoice_amt) as net_invoice_amt
           from {oms_catalog_name}.gold_ad_sales.ft_digital_operative_line_date_allocation
           group by all) oms
  ON oms.ps_line_item_id = cam.order_id
  and oms.order_year = year(cam.event_date)
  and oms.order_month = month(cam.event_date)
"""

megaphone_campaign_delivery = spark.sql(query)

# COMMAND ----------

if not spark.catalog.tableExists(f'{catalog_name}.{gold_schema_name}.ft_megaphone_campaign_delivery'): #Add the table name for First time load 
    megaphone_campaign_delivery.write.format('delta')\
        .mode('overwrite')\
        .partitionBy('event_date')\
        .option('mergeSchema', 'true')\
        .option('overwriteDynamicPartitions', 'true')\
        .option('delta.enableDeletionVectors', 'false')\
        .option('delta.enableIcebergCompatV2', 'true')\
        .option('delta.universalFormat.enabledFormats', 'iceberg')\
        .option('delta.columnMapping.mode', 'name')\
        .saveAsTable(f"{catalog_name}.{gold_schema_name}.ft_megaphone_campaign_delivery")
else:
    megaphone_campaign_delivery.write.format('delta')\
        .mode('overwrite')\
        .option('partitionOverwriteMode', 'dynamic')\
        .saveAsTable(f"{catalog_name}.{gold_schema_name}.ft_megaphone_campaign_delivery")
