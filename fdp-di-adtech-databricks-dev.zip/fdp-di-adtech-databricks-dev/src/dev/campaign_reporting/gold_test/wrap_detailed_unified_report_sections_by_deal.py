# Databricks notebook source
from datetime import datetime, timedelta


# COMMAND ----------

spark.conf.set("spark.databricks.remoteFiltering.blockSelfJoins", "false")

# COMMAND ----------

# Accept parameters for parallel execution
dbutils.widgets.text("deal_ids", "")
dbutils.widgets.text("batch_number", "0")

deal_ids_param = dbutils.widgets.get("deal_ids")
batch_number_param = dbutils.widgets.get("batch_number")

# COMMAND ----------

"""
Optimized version that maintains exact SQL logic but optimizes execution through:
1. Caching base tables
2. Parallel processing of deals
3. Optimized batch sizes
4. Spark configuration optimizations
"""

def cache_base_tables_for_batch(deal_batches):
    """
    Cache base tables filtered for the deals in this batch.
    This allows Spark to reuse cached data across multiple deal queries in the batch.
    """
    deal_ids_str = ','.join([str(d) for d in deal_batches])

    print(f"Caching base tables for {len(deal_batches)} deals...")

    # Cache FreeWheel campaign delivery table (filtered for this batch)
    fw_query = f"""
    SELECT
    `AOS_Deal ID`,
    `Creative ID`,
    `Event Date`,
    `Ad Unit Position`,
    `Third Party Billable Impressions`,
    `Third Party Revenue`,
    `Placement ID`,
    `AOS_Deal Name`,
    `Campaign Start Date`,
    `Campaign End Date`,
    `Advertiser Name`,
    `Agency Name`,
    `Sales Channel Type`,
    `Placement Name`,
    `Package Name`,
    `Parent Line Item Name`,
    `AOS Deal Line Item Name`,
    `Creative Name`,
    `Creative Duration`,
    `Device`,
    `Video Vertical`,
    `FW Audience Segment`,
    `Show Name`,
    `Deal Ad Units`,
    `Demo Band`,
    -- `Event Date`,
    `Guaranteed Impressions`,
    `Guaranteed Revenue`,
    `Net Unit Cost`,
    `Delivered Impressions`,
    `Delivered Clicks`,
    `Delivered Revenue`,
    `On Target Net Delivered Impressions`,
    `Third Party Clicks`
    FROM fox_bi_qa.gold_ad_sales.v_ft_freewheel_campaign_delivery
    WHERE `AOS_Deal ID` IN ({deal_ids_str})
    """
    fw_df = spark.sql(fw_query)
    fw_df.createOrReplaceTempView("cached_fw_campaign_delivery")
    fw_df.cache()
    fw_count = fw_df.count()  # Force materialization
    print(f"  Cached FreeWheel campaign delivery: {fw_count:,} rows")

    # Cache GAM campaign delivery table (filtered for this batch)
    gam_query = f"""
    SELECT
    `AOS Deal ID`,
    -- `Line Item ID`,
    -- `Event Date`,
    `Third Party Billable Impressions`,
    `Third Party Revenue`,
    `AOS Deal Name`,
    `Campaign Start Date`,
    `Campaign End Date`,
    `Advertiser Name`,
    `Agency Name`,
    `Line Item ID`,
    `Line Item Name`,
    `Package Name`,
    `Parent Line Item Name`,
    `AOS Deal Line Item Name`,
    `Line Item Type`,
    `Device`,
    `Demo Band`,
    `Event Date`,
    `Guaranteed Impressions`,
    `Guaranteed Revenue`,
    `Net Unit Cost`,
    `Delivered Impressions`,
    `Delivered Clicks`,
    `Third Party Clicks`,
    `Third Party Line Item ID`
    FROM fox_bi_qa.gold_ad_sales.v_ft_gam_campaign_delivery
    WHERE `AOS Deal ID` IN ({deal_ids_str})
    """
    gam_df = spark.sql(gam_query)
    gam_df.createOrReplaceTempView("cached_gam_campaign_delivery")
    gam_df.cache()
    gam_count = gam_df.count()  # Force materialization
    print(f"  Cached GAM campaign delivery: {gam_count:,} rows")

    # Cache Unified geo table (filtered for this batch)
    unified_geo_query = f"""
    SELECT
    aos_deal_id, 
    country_name, 
    state_province_name, 
    `Delivered_Impressions`, 
    `Delivered_Clicks`
    FROM fox_bi_qa.gold_ad_sales.ft_unified_campaign_geo_delivery
    WHERE aos_deal_id IN ({deal_ids_str})
    """
    uni_geo_df = spark.sql(unified_geo_query)
    uni_geo_df.createOrReplaceTempView("cached_unified_geo")
    uni_geo_df.cache()
    uni_geo_count = uni_geo_df.count()  # Force materialization
    print(f"  Cached Unified geo: {uni_geo_count:,} rows")

    # Cache unified by deal table (filtered for this batch)
    unified_by_deal_query = f"""
    SELECT
    `AOS Deal ID`,
    `AOS Deal Name`,
    `Advertiser Name`,
    `Agency Name`,
    `AOS Deal Start Date`,
    `AOS Deal End Date`,
    `Total Placements`,
    `Total Creatives`,
    `Total Shows`,
    `Total Delivered Impressions`,
    `Total Delivered Revenue`,
    `Total First Party Delivered Impressions`,
    `Total First Party Delivered Revenue`,
    `Total Delivered Clicks`,
    `Total Guaranteed Impressions`,
    `Budget`,
    `First Party CPM`,
    `Third Party CPM`,
    `CPM`,
    `CTR`,
    `Total Countries`,
    `Total States`,
    `Total Geo Ads`,
    `Revenue Pacing`,
    `Impression Pacing`,
    `Sales Channels`,
    `Total Third Party Impressions`,
    `Total Third Party Revenue`,
    `Targeted Demos`,
    concat_ws(',', `FW Audience Segment`) AS `TARGET AUDIENCE`,
    concat_ws(',', `FW Video Group`) AS `TARGET CONTENT`,
    `First Party Revenue Pacing`,
    `Third Party Revenue Pacing`
    FROM fox_bi_qa.gold_ad_sales.v_ft_unified_campaign_delivery_by_deal
    WHERE `AOS Deal ID` IN ({deal_ids_str})
    """
    unified_by_deal_query_df = spark.sql(unified_by_deal_query)
    unified_by_deal_query_df.createOrReplaceTempView("cached_unified_by_deal")
    unified_by_deal_query_df.cache()
    unified_by_deal_count = unified_by_deal_query_df.count()  # Force materialization
    print(f"  Cached Unified geo: {unified_by_deal_count:,} rows")

    # # Cache fw geo table (filtered for this batch)
    # fw_geo_query = f"""
    # SELECT
    # `Country Name`,
    # `State/Province Name`,
    # `Delivered Impressions`,
    # `Delivered Clicks`,
    # `Insertion Order Id`,
    # `Campaign ID`
    # FROM fox_bi_qa.gold_ad_sales.v_ft_freewheel_campaign_delivery_geo_data
    # WHERE `Insertion Order Id` IN ({deal_ids_str}) OR `Campaign ID` IN ({deal_ids_str})
    # """
    # fw_geo_df = spark.sql(fw_geo_query)
    # fw_geo_df.createOrReplaceTempView("cached_fw_geo")
    # fw_geo_df.cache()
    # fw_geo_count = fw_geo_df.count()  # Force materialization
    # print(f"  Cached Unified geo: {fw_geo_count:,} rows")

    # # Cache GAM geo table (filtered for this batch)
    # gam_geo_query = f"""
    # SELECT
    # `Country Name`,
    # `State/Province Name`,
    # `Delivered Impressions`,
    # `Delivered Clicks`,
    # `Order ID`
    # FROM fox_bi_qa.gold_ad_sales.v_ft_gam_campaign_delivery_geo
    # WHERE `Order ID` IN ({deal_ids_str})
    # """
    # gam_geo_df = spark.sql(gam_geo_query)
    # gam_geo_df.createOrReplaceTempView("cached_gam_geo")
    # gam_geo_df.cache()
    # gam_geo_count = gam_geo_df.count()  # Force materialization
    # print(f"  Cached GAM geo: {gam_geo_count:,} rows")

    print("Base tables cached successfully")
    return True


def uncache_base_tables():
    """Uncache base tables to free memory"""
    try:
        spark.catalog.uncacheTable("cached_fw_campaign_delivery")
        spark.catalog.uncacheTable("cached_gam_campaign_delivery")
        # spark.catalog.uncacheTable("cached_gam_campaign_delivery")
        # spark.catalog.uncacheTable("cached_fw_geo")
        # spark.catalog.uncacheTable("cached_gam_geo")
        print("Uncached base tables")
    except Exception as e:
        # Ignore errors if tables don't exist
        pass


def batch_alkimi_data_to_table(deal_batches):
    """
    Processes deals in a batch. Maintains exact SQL structure but optimizes execution.
    Uses cached base tables to avoid redundant scans.
    """
    alkimi_unified_query = """alkimi_data{} AS (
        WITH unified_third_party_metrics AS (
    SELECT
         aos_deal_id
        -- ,creative_id
        -- ,event_date
        -- ,ad_unit_position
        ,SUM(third_party_impressions)
        ,SUM(third_party_revenue)
    FROM
        (
        SELECT
            `AOS_Deal ID` as aos_deal_id,
            `Creative ID` as creative_id,
            `Event Date` as event_date,
            `Ad Unit Position` as ad_unit_position,
            `Third Party Billable Impressions` as third_party_impressions,
            `Third Party Revenue` as third_party_revenue
        FROM cached_fw_campaign_delivery
        WHERE `AOS_Deal ID` = ?
        GROUP BY ALL

        UNION ALL

        SELECT
            `AOS Deal ID`,
            `Line Item ID`, -- this is not equivalent to FW creative_id
            `Event Date`,
            'N/A' as ad_unit_position,
            MAX(`Third Party Billable Impressions`) as third_party_impressions,
            MAX(`Third Party Revenue`) as third_party_revenue
        FROM cached_gam_campaign_delivery
        WHERE `AOS Deal ID` = ?
        GROUP BY `AOS Deal ID`, `Line Item ID`, `Event Date`
    )
    GROUP BY aos_deal_id, creative_id, event_date, ad_unit_position
)

, unified_placement_third_party as (
select 
  aos_deal_id
  ,line_item_or_placement_id placement_id
  ,sum(case
        when third_party_revenue = 0 then 0 
        when third_party_revenue > 0 then
        case
          when  nvl(third_party_line_item_id,'-1') = '-1' then 0
          when data_source = 'GAM' then 
              CASE
                  WHEN Demand_Type = 'SPONSORSHIP' THEN guaranteed_revenue
                  ELSE ((third_party_impressions) * net_unit_cost)/1000
              END 
          else (third_party_revenue)
    end
    end) as placement_third_party_revenue
    ,SUM(third_party_impressions) as placement_third_party_impressions
    ,SUM(third_party_clicks) as placement_third_party_clicks
    ,SUM(third_party_video_completes) as placement_third_party_video_completes
    ,SUM(third_party_video_views) as placement_third_party_video_views
 from
    (
SELECT
        pl.aos_deal_id,
        line_item_or_placement_id,
        aos_deal_line_item_id,
        demand_type,
        third_party_line_item_id,
        Data_Source,
        Net_Unit_Cost,
        guaranteed_impressions,
        guaranteed_revenue,
        SUM(third_party_impressions) as third_party_impressions,
        SUM(third_party_revenue) as third_party_revenue,
        SUM(third_party_clicks) as third_party_clicks,
        SUM(third_party_video_completes) as third_party_video_completes,
        SUM(third_party_video_views) as third_party_video_views
FROM (
    SELECT DISTINCT
        `AOS Deal ID` aos_deal_id,
        `Line Item or Placement ID` Line_Item_or_Placement_ID,
        `Third Party Line Item ID` Third_Party_Line_Item_ID,
        `Demand Type` Demand_Type,
        `AOS Deal Line Item ID` AOS_Deal_Line_Item_ID,
        `Event Date` Event_Date,
        `Data Source` Data_Source,
        `Net Unit Cost` Net_Unit_Cost,
        `Guaranteed Impressions` guaranteed_impressions,
        `Guaranteed Revenue` guaranteed_revenue,
        MAX(`Third Party Billable Impressions`) as third_party_impressions,
        MAX(`Third Party Revenue`) as third_party_revenue,
        MIN(`Third Party Clicks`) as third_party_clicks,
        MIN(`Third Party Video Completes`) as third_party_video_completes,
        MIN(`Third Party Video Views`) as third_party_video_views
    FROM fox_bi_qa.gold_ad_sales.v_unified_campaign_delivery
    WHERE `AOS Deal ID` = ?
    GROUP BY ALL
) pl
GROUP BY all)
group by all
)

, unified_creative_third_party as (
    SELECT
         aos_deal_id
        ,creative_id
        ,SUM(third_party_impressions) creative_third_party_impressions
        ,SUM(third_party_revenue) creative_third_party_revenue
    FROM
        (
        SELECT
            `AOS_Deal ID` as aos_deal_id,
            `Creative ID` as creative_id,
            `Event Date` as event_date,
            `Ad Unit Position` as ad_unit_position,
            `Third Party Billable Impressions` as third_party_impressions,
            `Third Party Revenue` as third_party_revenue
        FROM cached_fw_campaign_delivery
        WHERE `AOS_Deal ID` = ?
        GROUP BY ALL
    )
    GROUP BY aos_deal_id, creative_id
)

, fw_placement_level as (
    SELECT
        `AOS_Deal Name` AS aos_deal_name,
        `AOS_Deal ID` AS aos_deal_id,
        pl.`Campaign Start Date` AS campaign_start_date,
        pl.`Campaign End Date` AS campaign_end_date,
        pl.`Advertiser Name` AS advertiser_name,
        pl.`Agency Name` AS agency_name,
        pl.`Sales Channel Type` AS line_item_type,
        pl.`Placement ID` AS placement_id,
        pl.`Placement Name` AS placement_name,
        pl.`Package Name` AS package_name,
        pl.`Parent Line Item Name` AS parent_line_item_name,
        pl.`AOS Deal Line Item Name` AS aos_deal_line_item_name,
        pl.`Creative ID` AS creative_id,
        pl.`Creative Name` AS creative_name,
        pl.`Creative Duration` AS creative_duration,
        pl.`Device` AS device,
        pl.`Ad Unit Position` AS ad_unit_position,
        pl.`Video Vertical` AS video_vertical,
        pl.`Show Name` AS show_name,
        pl.`Deal Ad Units` AS deal_ad_units,
        pl.`Demo Band` AS demo_band,
        pl.`Event Date` AS event_date,
        MAX(pl.`Guaranteed Impressions`) as guaranteed_impressions,
        MAX(pl.`Guaranteed Revenue`) as guaranteed_revenue,
        MAX(`Net Unit Cost`) as net_unit_cost,
        SUM(pl.`Delivered Impressions`) as delivered_impressions,
        SUM(pl.`Delivered Clicks`) as delivered_clicks,
        SUM(pl.`Delivered Revenue`) as delivered_revenue,
        SUM(pl.`On Target Net Delivered Impressions`) as on_target_impressions
    FROM cached_fw_campaign_delivery pl
    WHERE `AOS_Deal ID` = ?
    GROUP BY
        `AOS_Deal ID`,
        `AOS_Deal Name`,
        pl.`Campaign Start Date`,
        pl.`Campaign End Date`,
        pl.`Advertiser Name`,
        pl.`Agency Name`,
        pl.`Sales Channel Type`,
        pl.`Placement ID`,
        pl.`Placement Name`,
        pl.`Package Name`,
        pl.`Parent Line Item Name`,
        pl.`AOS Deal Line Item Name`,
        pl.`Creative ID`,
        pl.`Creative Name`,
        pl.`Creative Duration`,
        pl.`Device`,
        pl.`Ad Unit Position`,
        pl.`Video Vertical`,
        pl.`Show Name`,
        pl.`Deal Ad Units`,
        pl.`Event Date`,
        pl.`Demo Band`
)

, gam_placement_level AS (
    SELECT
        pl.`AOS Deal Name` AS aos_deal_name,
        pl.`AOS Deal ID` AS aos_deal_id,
        pl.`Campaign Start Date` AS campaign_start_date,
        pl.`Campaign End Date` AS campaign_end_date,
        pl.`Advertiser Name` AS advertiser_name,
        pl.`Agency Name` AS agency_name,
        pl.`Line Item Type` AS line_item_type,
        pl.`Line Item ID` AS placement_id,
        pl.`Line Item Name` AS placement_name,
        pl.`Package Name` AS package_name,
        pl.`Parent Line Item Name` AS parent_line_item_name,
        pl.`AOS Deal Line Item Name` AS aos_deal_line_item_name,
        CAST(-1 AS STRING) AS creative_id,
        CAST('N/A' AS STRING) AS creative_name,
        CAST(0 AS STRING) AS creative_duration,
        pl.`Device`,
        CAST('N/A' AS STRING) AS ad_unit_position,
        CAST('N/A' AS STRING) AS video_vertical,
        CAST('N/A' AS STRING) AS show_name,
        CAST('N/A' AS STRING) AS deal_ad_units,
        pl.`Demo Band` AS demo_band,
        pl.`Event Date` AS event_date,
        MAX(pl.`Guaranteed Impressions`) AS guaranteed_impressions,
        MAX(pl.`Guaranteed Revenue`) AS guaranteed_revenue,
        MAX(pl.`Net Unit Cost`) AS net_unit_cost,
        SUM(pl.`Delivered Impressions`) AS delivered_impressions,
        SUM(pl.`Delivered Clicks`) AS delivered_clicks,
        CASE
            WHEN MAX(pl.`Line Item Type`) = 'SPONSORSHIP'
            THEN MAX(pl.`Guaranteed Revenue`)/count(pl.`Event Date`) over (partition by pl.`Line Item ID`)
            ELSE (SUM(pl.`Delivered Impressions`) * MAX(pl.`Net Unit Cost`)) / 1000.0
        END as delivered_revenue,
        SUM(0) as on_target_impressions
    FROM cached_gam_campaign_delivery pl
    WHERE pl.`AOS Deal ID` = ?
    GROUP BY
        pl.`AOS Deal ID`,
        pl.`AOS Deal Name`,
        pl.`Campaign Start Date`,
        pl.`Campaign End Date`,
        pl.`Advertiser Name`,
        pl.`Agency Name`,
        pl.`Line Item Type`,
        pl.`Line Item ID`,
        pl.`Line Item Name`,
        pl.`Package Name`,
        pl.`Parent Line Item Name`,
        pl.`AOS Deal Line Item Name`,
        pl.`Device`,
        pl.`Demo Band`,
        pl.`Event Date`
)

, unified_placement_level as (
    SELECT
         aos_deal_id
        ,aos_deal_name
        ,campaign_start_date
        ,campaign_end_date
        ,advertiser_name
        ,agency_name
        -- ,sales_channel_type
        ,placement_id
        ,placement_name
        ,package_name
        ,parent_line_item_name
        ,aos_deal_line_item_name
        ,line_item_type
        ,creative_id
        ,creative_name
        ,creative_duration
        ,device
        ,ad_unit_position
        ,video_vertical
        ,show_name
        ,deal_ad_units
        ,event_date
        ,demo_band
        ,MAX(net_unit_cost) net_unit_cost
        ,MAX(guaranteed_impressions) AS guaranteed_impressions
        ,MAX(guaranteed_revenue) AS guaranteed_revenue
        ,SUM(delivered_impressions) AS delivered_impressions
        ,SUM(delivered_revenue) delivered_revenue
        ,SUM(delivered_clicks) AS delivered_clicks
        ,SUM(on_target_impressions) AS on_target_impressions
    FROM
        (
            select * from fw_placement_level
            union all
            select * from gam_placement_level
        )
    GROUP BY
            aos_deal_id
            ,aos_deal_name
            ,campaign_start_date
            ,campaign_end_date
            ,advertiser_name
            ,agency_name
            -- ,sales_channel_type
            ,placement_id
            ,package_name
            ,parent_line_item_name
            ,aos_deal_line_item_name
            ,placement_name
            ,creative_id
            ,creative_name
            ,creative_duration
            ,device
            ,ad_unit_position
            ,video_vertical
            ,show_name
            ,deal_ad_units
            ,event_date
            ,demo_band
            ,line_item_type
)

, unified_placement_summary as (
    SELECT
        pl.aos_deal_id,
        pl.placement_id,
        pl.placement_name,
        MAX(pl.guaranteed_impressions) as placement_guaranteed_impressions,
        MAX(pl.guaranteed_revenue) as placement_guaranteed_revenue,
        SUM(pl.delivered_impressions) as placement_delivered_impressions,
        SUM(pl.delivered_revenue) as placement_delivered_revenue,
        -- Join placement-level 3P (already de-duplicated)
        COALESCE(MAX(ptp.placement_third_party_impressions), 0) as placement_third_party_impressions,
        COALESCE(MAX(ptp.placement_third_party_revenue), 0) as placement_third_party_revenue,
        COALESCE(MAX(ptp.placement_third_party_clicks),0) as placement_third_party_clicks
    FROM unified_placement_level pl
    LEFT JOIN unified_placement_third_party ptp ON pl.placement_id = ptp.placement_id
    GROUP BY
        pl.aos_deal_id,
        pl.placement_id,
        pl.placement_name
)
, unified_performance_metrics as (
    SELECT
         SUM(placement_delivered_impressions) AS total_impressions
        ,SUM(placement_delivered_revenue) AS total_revenue
        ,SUM(placement_guaranteed_impressions) AS guaranteed_impressions
        ,SUM(placement_guaranteed_revenue) AS guaranteed_revenue
        ,SUM(placement_third_party_impressions) AS total_third_party_impressions
        ,SUM(placement_third_party_revenue) AS total_third_party_revenue
        ,SUM(placement_third_party_clicks) AS total_third_party_clicks
      FROM
        unified_placement_summary
)

, unified_click_metrics as (
    SELECT
        SUM(delivered_clicks) AS total_clicks
      FROM
        unified_placement_level
)

, unified_calculated_metrics as (
    SELECT
        pm.total_impressions,
        pm.total_revenue,
        cm.total_clicks,
        pm.guaranteed_impressions,
        pm.guaranteed_revenue,
        pm.total_third_party_impressions,
        pm.total_third_party_revenue,
        pm.total_third_party_clicks,
        CASE
            WHEN pm.total_impressions > 0
            THEN ROUND((pm.total_revenue / pm.total_impressions * 1000), 2)
            ELSE 0
        END as actual_cpm,
        CASE
            WHEN pm.total_impressions > 0
            THEN ROUND((cm.total_clicks / pm.total_impressions * 100), 4)
            ELSE 0
        END as ctr,
        CASE
            WHEN pm.guaranteed_revenue > 0
            THEN ROUND((pm.total_revenue / pm.guaranteed_revenue * 100), 2)
            ELSE 0
        END as revenue_pacing,
        CASE
            WHEN pm.guaranteed_impressions > 0
            THEN ROUND((pm.total_impressions / pm.guaranteed_impressions * 100), 2)
            ELSE 0
        END as impression_pacing
    FROM unified_performance_metrics pm
    CROSS JOIN unified_click_metrics cm
)
, unified_geo_performance as (
    select 
                aos_deal_id, 
                country_name, 
                state_province_name, 
                SUM(`Delivered_Impressions`) as delivered_impressions, 
                SUM(`Delivered_Clicks`) as delivered_clicks,
                CASE
                    WHEN SUM(`Delivered_Impressions`) > 0 THEN ROUND((SUM(`Delivered_Clicks`) / SUM(`Delivered_Impressions`) * 100), 4)
                    ELSE 0
                END AS field5
            from 
                cached_unified_geo
            where aos_deal_id = ?
            group by all
)

, unified_placement_level_packages as (
  select aos_deal_id
        ,placement_id
        ,placement_name
        ,parent_line_item_name
        ,aos_deal_line_item_name
        ,count(distinct creative_id) as creative_id_count
        ,MAX(guaranteed_impressions) as guaranteed_impressions
        ,MAX(guaranteed_revenue) as guaranteed_revenue
        ,SUM(delivered_impressions) delivered_impressions
        -- ,SUM(delivered_revenue) as delivered_revenue
        ,case when sum(delivered_revenue) = 0 then 0
        when sum(delivered_revenue) > 0 then
        CASE 
          WHEN MAX(line_item_type) in ('SPONSORSHIP', 'BULK', 'STANDARD') THEN 
            CASE
                WHEN MAX(line_item_type) = 'SPONSORSHIP' THEN MAX(guaranteed_revenue)
                ELSE (SUM(delivered_impressions) * MAX(net_unit_cost)) / 1000.0
            END 
          ELSE SUM(delivered_revenue)  
          end
        END AS delivered_revenue
        ,SUM(delivered_clicks) as delivered_clicks
    from unified_placement_level
    group by all
  UNION
  SELECT
         aos_deal_id
        ,line_item_or_placement_id
        ,line_item_or_placement_name
        ,parent_line_item_name
        ,aos_deal_line_item_name
        ,SUM(0) as creative_id_count
        ,MAX(guaranteed_impressions) AS guaranteed_impressions
        ,MAX(guaranteed_revenue) AS guaranteed_revenue
        ,SUM(delivered_impressions) AS delivered_impressions
        ,SUM(delivered_revenue) delivered_revenue
        ,SUM(delivered_clicks) AS delivered_clicks
    FROM
            fox_bi_qa.gold_ad_sales.ft_unified_campaign_delivery
    where `Data_Source` = 'Non Ad Served' and aos_deal_id = ?
    GROUP BY
            aos_deal_id
            ,line_item_or_placement_id
            ,line_item_or_placement_name
            ,parent_line_item_name
            ,aos_deal_line_item_name
)

, target_audience_distribution as (
    SELECT 
        `AOS_deal ID` AS aos_deal_id
        ,`FW Audience Segment` AS fw_audience_segment
        ,sum(`Delivered Impressions`) AS delivered_impressions
        ,sum(`Delivered Revenue`) AS delivered_revenue
    FROM cached_fw_campaign_delivery
    WHERE `AOS_Deal ID` = ?
    GROUP BY 1,2    
)

, fw_third_party_at_target_audience as (
    SELECT
                    pl.`AOS_Deal ID` as aos_deal_id
                    , pl.`FW Audience Segment` as target_audience
                    , SUM(third_party_impressions) as placement_third_party_impressions
                    , SUM(third_party_revenue) as placement_third_party_revenue
                FROM (
                    SELECT DISTINCT
                        `AOS_Deal ID`,
                        `Placement ID`,
                        `Creative ID`,
                        `Event Date`,
                        `Ad Unit Position`,
                        `FW Audience Segment`,
                        `Third Party Billable Impressions` as third_party_impressions,
                        `Third Party Revenue` as third_party_revenue
                    FROM cached_fw_campaign_delivery
                    WHERE `AOS_Deal ID` = ?
                    GROUP BY ALL
                ) pl
                GROUP BY pl.`AOS_Deal ID`, pl.`FW Audience Segment`
)

, unified_placement_summary_at_line_item_type as (
    SELECT 
        aos_deal_id
        ,line_item_type
        ,SUM(placement_third_party_impressions) placement_third_party_impressions
        ,SUM(placement_third_party_revenue) placement_third_party_revenue
        ,SUM(placement_third_party_clicks) placement_third_party_clicks
    FROM 
        (
            SELECT
                pl.aos_deal_id,
                pl.placement_id,
                pl.placement_name,
                pl.line_item_type,
                MAX(pl.guaranteed_impressions) as placement_guaranteed_impressions,
                MAX(pl.guaranteed_revenue) as placement_guaranteed_revenue,
                SUM(pl.delivered_impressions) as placement_delivered_impressions,
                SUM(pl.delivered_revenue) as placement_delivered_revenue,
                -- Join placement-level 3P (already de-duplicated)
                COALESCE(MAX(ptp.placement_third_party_impressions), 0) as placement_third_party_impressions,
                COALESCE(MAX(ptp.placement_third_party_revenue), 0) as placement_third_party_revenue,
                COALESCE(MAX(ptp.placement_third_party_clicks),0) as placement_third_party_clicks
            FROM unified_placement_level pl
            LEFT JOIN unified_placement_third_party ptp ON pl.placement_id = ptp.placement_id
            GROUP BY
                pl.aos_deal_id,
                pl.placement_id,
                pl.placement_name,
                pl.line_item_type
        )
    GROUP BY
        aos_deal_id,
        line_item_type
)

, imps_over_time_placement_third_party as (
    SELECT
        aos_deal_id
       ,event_date
       ,SUM(placement_third_party_impressions) AS placement_third_party_impressions
       ,SUM(placement_third_party_revenue) AS placement_third_party_revenue
     FROM
        (
            SELECT
                    pl.`AOS_Deal ID` as aos_deal_id,
                    pl.`Event Date` as event_date,
                    SUM(third_party_impressions) as placement_third_party_impressions,
                    SUM(third_party_revenue) as placement_third_party_revenue
                FROM (
                    SELECT DISTINCT
                        `AOS_Deal ID`,
                        `Placement ID`,
                        `Creative ID`,
                        `Event Date`,
                        `Ad Unit Position`,
                        `Third Party Billable Impressions` as third_party_impressions,
                        `Third Party Revenue` as third_party_revenue
                    FROM cached_fw_campaign_delivery
                    WHERE `AOS_Deal ID` = ?
                    GROUP BY ALL
                ) pl
                GROUP BY pl.`Event Date`, pl.`AOS_Deal ID`

            UNION ALL

            SELECT   
                    `AOS Deal ID` as aos_deal_id,
                    `Event Date` as event_date,
                    SUM(third_party_impressions) as placement_third_party_impressions,
                    SUM(third_party_revenue) as placement_third_party_revenue
                FROM (
                    SELECT
                        `AOS Deal ID`,
                        `Line Item ID`,
                        `Event Date`,                        
                        MAX(`Third Party Billable Impressions`) as third_party_impressions,
                        -- MAX(`Third Party Revenue`) as third_party_revenue
                        case
                        when MAX(`Third Party Billable Impressions`) = 0 then 0 
                        when MAX(`Third Party Billable Impressions`) > 0 then
                        case
                            when nvl(`Third Party Line Item ID`,'-1') = '-1' then 0
                            ELSE CASE
                                    WHEN `Line Item Type` = 'SPONSORSHIP' THEN MAX(`Guaranteed Revenue`)/COUNT(
                         CASE 
                             WHEN `Third Party Line Item ID` IS NOT NULL and SUM(`Third Party Billable Impressions`) > 0 
                             THEN `Event Date` 
                         END
                     ) OVER (PARTITION BY `Line Item ID`)
                                    ELSE (max(`Third Party Billable Impressions`) * max(`Net Unit Cost`))/1000
                                END 
                        end 
                        end as third_party_revenue
                    FROM cached_gam_campaign_delivery
                    WHERE `AOS Deal ID` = ?
                    GROUP BY `AOS Deal ID`, `Line Item ID`, `Event Date`,`Line Item Type`,`Third Party Line Item ID`
                )
                GROUP BY `AOS Deal ID`,`Event Date`
        )
        GROUP BY aos_deal_id,event_date
)

, unified_report_section as (
    SELECT
        'CAMPAIGN_SUMMARY' as data_type,
        `AOS Deal ID` as `AOS_Deal_ID`,
        CAST(`AOS Deal ID` AS STRING) as field1,
        `AOS Deal Name` as field2,
        `Advertiser Name` as field3,
        `Agency Name` as field4,
        CAST(`AOS Deal Start Date` AS STRING) as field5,
        CAST(`AOS Deal End Date` AS STRING) as field6,
        CAST(`Total Placements` AS STRING) as field7,
        CAST(`Total Creatives` AS STRING) as field8,
        CAST(`Total Shows` AS STRING) as field9,
        CAST(`Total First Party Delivered Impressions` AS STRING) as field10,
        CAST(`Total First Party Delivered Revenue` AS STRING) as field11,
        CAST(`Total Delivered Clicks` AS STRING) as field12,
        CAST(`Total Guaranteed Impressions` AS STRING) as field13,
        CAST(`Budget` AS STRING) as field14,
        CAST(`First Party CPM` AS STRING) as field15,
        CAST(`CTR` AS STRING) as field16,
        CAST(`Total Countries` AS STRING) as field17,
        CAST(`Total States` AS STRING) as field18,
        CAST(`Total Geo Ads` AS STRING) as field19,
        CAST(`Impression Pacing` AS STRING) as field20,
        CAST(`First Party Revenue Pacing` AS STRING) as field21,
        upper(array_join(`Sales Channels`, ',')) as field22,
        CAST(`Total Third Party Impressions` AS STRING) as field23,
        CAST(`Total Third Party Revenue` AS STRING) as field24,
        upper(array_join(`Targeted Demos`, ',')) as field25,
        `TARGET AUDIENCE` as field26,
        `TARGET CONTENT` as field27,
        CAST(`Third Party Revenue Pacing` AS STRING) as field28,
        CAST(`Third Party CPM` AS STRING) as field29
        FROM cached_unified_by_deal
        where `AOS Deal ID` = ?

    UNION ALL

    SELECT
        'DEVICE_BREAKDOWN' as data_type,
        pl.aos_deal_id as `AOS_Deal_ID`,
        pl.`Device` as field1,
        CAST(SUM(pl.delivered_impressions) AS STRING) as field2,
        CAST(SUM(pl.delivered_revenue) AS STRING) AS field3,
        CAST(SUM(pl.delivered_clicks) AS STRING) as field4,
        CAST(COUNT(DISTINCT pl.placement_id) AS STRING) as field5,
        CAST(COUNT(DISTINCT pl.creative_id) AS STRING) AS field6,
        CAST(
            CASE
                WHEN SUM(pl.delivered_impressions) > 0 THEN ROUND((SUM(pl.delivered_revenue) / SUM(pl.delivered_impressions) * 1000), 2)
                ELSE 0
            END
        AS STRING) as field7,
        -- 3P metrics: Show campaign total (not device-specific)
        CAST(MAX(cm.total_third_party_impressions) AS STRING) as field8,
        CAST(MAX(cm.total_third_party_revenue) AS STRING) as field9,
        CAST(NULL AS STRING) as field10,
        CAST(NULL AS STRING) as field11,
        CAST(NULL AS STRING) as field12,
        CAST(NULL AS STRING) as field13,
        CAST(NULL AS STRING) as field14,
        CAST(NULL AS STRING) as field15,
        CAST(NULL AS STRING) as field16,
        CAST(NULL AS STRING) as field17,
        CAST(NULL AS STRING) as field18,
        CAST(NULL AS STRING) as field19,
        CAST(NULL AS STRING) as field20,
        CAST(NULL AS STRING) as field21,
        CAST(NULL AS STRING) as field22,
        CAST(NULL AS STRING) as field23,
        CAST(NULL AS STRING) as field24,
        CAST(NULL AS STRING) as field25,
        CAST(NULL AS STRING) as field26,
        CAST(NULL AS STRING) as field27,
        CAST(NULL AS STRING) as field28,
        CAST(NULL AS STRING) as field29
    FROM (select * from unified_placement_level 
    --where `Device` is not null and `Device` != 'N/A' and `Device` != 'Unknown'
    ) pl
    CROSS JOIN unified_calculated_metrics cm
    GROUP BY pl.`Device` , pl.aos_deal_id

    UNION ALL

    SELECT
        'GEO_PERFORMANCE' as data_type,
        g.aos_deal_id as `AOS_Deal_ID`,
        country_name as field1,
        state_province_name as field2,
        CAST(delivered_impressions AS STRING) as field3,
        CAST(delivered_clicks AS STRING) as field4,
        CAST(field5 AS STRING) as field5,
        CAST(NULL AS STRING) as field6,
        CAST(NULL AS STRING) as field7,
        CAST(NULL AS STRING) as field8,
        CAST(NULL AS STRING) as field9,
        CAST(NULL AS STRING) as field10,
        CAST(NULL AS STRING) as field11,
        CAST(NULL AS STRING) as field12,
        CAST(NULL AS STRING) as field13,
        CAST(NULL AS STRING) as field14,
        CAST(NULL AS STRING) as field15,
        CAST(NULL AS STRING) as field16,
        CAST(NULL AS STRING) as field17,
        CAST(NULL AS STRING) as field18,
        CAST(NULL AS STRING) as field19,
        CAST(NULL AS STRING) as field20,
        CAST(NULL AS STRING) as field21,
        CAST(NULL AS STRING) as field22,
        CAST(NULL AS STRING) as field23,
        CAST(NULL AS STRING) as field24,
        CAST(NULL AS STRING) as field25,
        CAST(NULL AS STRING) as field26,
        CAST(NULL AS STRING) as field27,
        CAST(NULL AS STRING) as field28,
        CAST(NULL AS STRING) as field29
    FROM unified_geo_performance g
    where country_name IS NOT NULL AND state_province_name IS NOT NULL
        and country_name <> 'N/A' and country_name <> 'Unknown'
        and state_province_name <> 'N/A' and state_province_name <> 'Unknown'

    UNION ALL


    SELECT
        'PLACEMENT_PERFORMANCE' as data_type,
        pl.aos_deal_id as `AOS_Deal_ID`,
        CAST(pl.placement_id AS STRING) as field1,
        pl.placement_name as field2,
        CAST(SUM(pl.delivered_impressions) AS STRING) as field3,
        --CAST(SUM(pl.delivered_revenue) AS STRING) as field4,
        CAST(
            CASE
                WHEN pl.line_item_type = 'SPONSORSHIP' THEN MAX(pl.net_unit_cost)
                ELSE (SUM(pl.delivered_impressions) * MAX(pl.net_unit_cost)) / 1000.0
            END 
        AS STRING) as field4,
        CAST(COUNT(DISTINCT pl.creative_id) AS STRING) as field5,
        -- 3P metrics: Get from placement_summary to avoid duplication
        CAST(MAX(tpt.placement_third_party_impressions) AS STRING) as field6,
        CAST(MAX(tpt.placement_third_party_revenue) AS STRING) as field7,
        CAST(NULL AS STRING) as field8,
        CAST(NULL AS STRING) as field9,
        CAST(NULL AS STRING) as field10,
        CAST(NULL AS STRING) as field11,
        CAST(NULL AS STRING) as field12,
        CAST(NULL AS STRING) as field13,
        CAST(NULL AS STRING) as field14,
        CAST(NULL AS STRING) as field15,
        CAST(NULL AS STRING) as field16,
        CAST(NULL AS STRING) as field17,
        CAST(NULL AS STRING) as field18,
        CAST(NULL AS STRING) as field19,
        CAST(NULL AS STRING) as field20,
        CAST(NULL AS STRING) as field21,
        CAST(NULL AS STRING) as field22,
        CAST(NULL AS STRING) as field23,
        CAST(NULL AS STRING) as field24,
        CAST(NULL AS STRING) as field25,
        CAST(NULL AS STRING) as field26,
        CAST(NULL AS STRING) as field27,
        CAST(NULL AS STRING) as field28,
        CAST(NULL AS STRING) as field29
    FROM unified_placement_level pl
    LEFT JOIN unified_placement_third_party tpt ON pl.placement_id = tpt.placement_id
    GROUP BY pl.placement_id, pl.placement_name, pl.aos_deal_id, pl.line_item_type

    UNION ALL

    SELECT
        'IMPRESSIONS_OVER_TIME' as data_type,
        pl.aos_deal_id as `AOS_Deal_ID`,
        CAST(DATE(pl.event_date) AS STRING) as field1,
        CAST(SUM(pl.delivered_impressions) AS STRING) as field2,
        CAST(SUM(pl.delivered_revenue) AS STRING) as field3,
        CAST(SUM(pl.guaranteed_impressions) AS STRING) as field4,
        CAST(SUM(pl.guaranteed_revenue) AS STRING) as field5,
        CAST(MAX(tpt.placement_third_party_impressions) AS STRING) as field6,
        CAST(MAX(tpt.placement_third_party_revenue) AS STRING) as field7,
        CAST(NULL AS STRING) as field8,
        CAST(NULL AS STRING) as field9,
        CAST(NULL AS STRING) as field10,
        CAST(NULL AS STRING) as field11,
        CAST(NULL AS STRING) as field12,
        CAST(NULL AS STRING) as field13,
        CAST(NULL AS STRING) as field14,
        CAST(NULL AS STRING) as field15,
        CAST(NULL AS STRING) as field16,
        CAST(NULL AS STRING) as field17,
        CAST(NULL AS STRING) as field18,
        CAST(NULL AS STRING) as field19,
        CAST(NULL AS STRING) as field20,
        CAST(NULL AS STRING) as field21,
        CAST(NULL AS STRING) as field22,
        CAST(NULL AS STRING) as field23,
        CAST(NULL AS STRING) as field24,
        CAST(NULL AS STRING) as field25,
        CAST(NULL AS STRING) as field26,
        CAST(NULL AS STRING) as field27,
        CAST(NULL AS STRING) as field28,
        CAST(NULL AS STRING) as field29
    FROM unified_placement_level pl
    left join imps_over_time_placement_third_party tpt ON pl.aos_deal_id = tpt.aos_deal_id and pl.event_date = tpt.event_date 
    GROUP BY DATE(pl.event_date),pl.aos_deal_id

    UNION ALL

    SELECT -- A single line item type will have multiple line items, each line item will have its own net_unit_cost. This is incorrect to show the LINE_ITEM_TYPE_PERFORMANCE as we cant multiply the MAX(net_unit_cost) for all line items. This has to be calculated at line item level and then sum it up at line_item_type. This only applies to GAM, we cant do it for FW.
        'LINE_ITEM_TYPE_PERFORMANCE' as data_type,
        pl.aos_deal_id as `AOS_Deal_ID`,
        upper(pl.line_item_type) as field1,
        CAST(SUM(pl.delivered_impressions) AS STRING) as field2,
        CAST(SUM(pl.delivered_revenue) AS STRING) as field3,
        CAST(SUM(pl.delivered_clicks) AS STRING) as field4,
        CAST(COUNT(DISTINCT pl.placement_id) AS STRING) as field5,
        CAST(SUM(delivered_revenue) AS STRING) as field6,
        CAST(
            CASE
                WHEN SUM(pl.delivered_impressions) > 0
                THEN ROUND((SUM(pl.delivered_clicks) / SUM(pl.delivered_impressions) * 100), 4)
                ELSE 0
            END AS STRING
        ) as field7,
        -- 3P metrics: Show campaign total for all line item types
        CAST(MAX(cm.placement_third_party_impressions) AS STRING) as field8,
        CAST(MAX(cm.placement_third_party_revenue) AS STRING) as field9,
        CAST(
            CASE
                WHEN MAX(cm.placement_third_party_impressions) > 0
                THEN ROUND((MAX(cm.placement_third_party_clicks) / MAX(cm.placement_third_party_impressions) * 100), 4)
                ELSE 0
            END AS STRING
        ) as field10,
        CAST(NULL AS STRING) as field11,
        CAST(NULL AS STRING) as field12,
        CAST(NULL AS STRING) as field13,
        CAST(NULL AS STRING) as field14,
        CAST(NULL AS STRING) as field15,
        CAST(NULL AS STRING) as field16,
        CAST(NULL AS STRING) as field17,
        CAST(NULL AS STRING) as field18,
        CAST(NULL AS STRING) as field19,
        CAST(NULL AS STRING) as field20,
        CAST(NULL AS STRING) as field21,
        CAST(NULL AS STRING) as field22,
        CAST(NULL AS STRING) as field23,
        CAST(NULL AS STRING) as field24,
        CAST(NULL AS STRING) as field25,
        CAST(NULL AS STRING) as field26,
        CAST(NULL AS STRING) as field27,
        CAST(NULL AS STRING) as field28,
        CAST(NULL AS STRING) as field29
    FROM unified_placement_level pl
    CROSS JOIN unified_placement_summary_at_line_item_type cm
        ON pl.aos_deal_id = cm.aos_deal_id and UPPER(pl.line_item_type) = UPPER(cm.line_item_type)
    GROUP BY pl.aos_deal_id, pl.line_item_type

    UNION ALL

    SELECT
        'AD_POSITION_ANALYSIS' as data_type,
        aos_deal_id as `AOS_Deal_ID`,
        ad_unit_position as field1,
        CAST(SUM(delivered_impressions) AS STRING) as field2,
        CAST(SUM(delivered_revenue) AS STRING) as field3,
        CAST(COUNT(DISTINCT placement_id) AS STRING) as field4,
        CAST(AVG(CAST(creative_duration AS DOUBLE)) AS STRING) as field5,
        CAST(COUNT(DISTINCT creative_id) AS STRING) as field6,
        CAST(NULL AS STRING) as field7,
        CAST(NULL AS STRING) as field8,
        CAST(NULL AS STRING) as field9,
        CAST(NULL AS STRING) as field10,
        CAST(NULL AS STRING) as field11,
        CAST(NULL AS STRING) as field12,
        CAST(NULL AS STRING) as field13,
        CAST(NULL AS STRING) as field14,
        CAST(NULL AS STRING) as field15,
        CAST(NULL AS STRING) as field16,
        CAST(NULL AS STRING) as field17,
        CAST(NULL AS STRING) as field18,
        CAST(NULL AS STRING) as field19,
        CAST(NULL AS STRING) as field20,
        CAST(NULL AS STRING) as field21,
        CAST(NULL AS STRING) as field22,
        CAST(NULL AS STRING) as field23,
        CAST(NULL AS STRING) as field24,
        CAST(NULL AS STRING) as field25,
        CAST(NULL AS STRING) as field26,
        CAST(NULL AS STRING) as field27,
        CAST(NULL AS STRING) as field28,
        CAST(NULL AS STRING) as field29
    FROM unified_placement_level
    GROUP BY ad_unit_position, aos_deal_id

    UNION ALL

    SELECT
        'CREATIVE_PERFORMANCE' as data_type,
        pl.aos_deal_id as `AOS_Deal_ID`,
        CAST(pl.creative_id AS STRING) as field1,
        pl.creative_name as field2,
        CAST(pl.creative_duration AS STRING) as field3,
        CAST(SUM(pl.delivered_impressions) AS STRING) as field4,
        CAST(SUM(pl.delivered_revenue) AS STRING) as field5,
        CAST(SUM(pl.delivered_clicks) AS STRING) as field6,
        CAST(COUNT(DISTINCT pl.placement_id) AS STRING) as field7,
        CAST(
            CASE
                WHEN SUM(pl.delivered_impressions) > 0
                THEN ROUND((SUM(pl.delivered_clicks) / SUM(pl.delivered_impressions) * 100), 4)
                ELSE 0
            END AS STRING
        ) as field8,
        -- 3P metrics: Get from creative totals
        CAST(MAX(ctp.creative_third_party_impressions) AS STRING) as field9,
        CAST(MAX(ctp.creative_third_party_revenue) AS STRING) as field10,
        CAST(NULL AS STRING) as field11,
        CAST(NULL AS STRING) as field12,
        CAST(NULL AS STRING) as field13,
        CAST(NULL AS STRING) as field14,
        CAST(NULL AS STRING) as field15,
        CAST(NULL AS STRING) as field16,
        CAST(NULL AS STRING) as field17,
        CAST(NULL AS STRING) as field18,
        CAST(NULL AS STRING) as field19,
        CAST(NULL AS STRING) as field20,
        CAST(NULL AS STRING) as field21,
        CAST(NULL AS STRING) as field22,
        CAST(NULL AS STRING) as field23,
        CAST(NULL AS STRING) as field24,
        CAST(NULL AS STRING) as field25,
        CAST(NULL AS STRING) as field26,
        CAST(NULL AS STRING) as field27,
        CAST(NULL AS STRING) as field28,
        CAST(NULL AS STRING) as field29
    FROM (select * from unified_placement_level 
    --where creative_name is not null and creative_name != 'N/A' and creative_name != 'Unknown'
    ) pl
    LEFT JOIN unified_creative_third_party ctp
        ON pl.creative_id = ctp.creative_id
    GROUP BY
         pl.creative_id
        ,pl.creative_name
        ,pl.creative_duration
        ,pl.aos_deal_id

    UNION ALL

    SELECT
        'DURATION_BUCKET_ANALYSIS' as data_type,
        aos_deal_id as `AOS_Deal_ID`,
        CASE
            WHEN CAST(creative_duration AS DOUBLE) <= 15 THEN '0-15s'
            WHEN CAST(creative_duration AS DOUBLE) <= 30 THEN '16-30s'
            WHEN CAST(creative_duration AS DOUBLE) <= 45 THEN '31-45s'
            WHEN CAST(creative_duration AS DOUBLE) <= 60 THEN '46-60s'
            ELSE '60s+'
        END as field1,
        device as field2,
        ad_unit_position as field3,
        CAST(SUM(delivered_impressions) AS STRING) as field4,
        CAST(SUM(delivered_revenue) AS STRING) as field5,
        CAST(COUNT(DISTINCT creative_id) AS STRING) as field6,
        CAST(AVG(CAST(creative_duration AS DOUBLE)) AS STRING) as field7,
        CAST(
            CASE
                WHEN SUM(delivered_impressions) > 0
                THEN ROUND((SUM(delivered_revenue) / SUM(delivered_impressions) * 1000), 2)
                ELSE 0
            END AS STRING
        ) as field8,
        CAST(NULL AS STRING) as field9,
        CAST(NULL AS STRING) as field10,
        CAST(NULL AS STRING) as field11,
        CAST(NULL AS STRING) as field12,
        CAST(NULL AS STRING) as field13,
        CAST(NULL AS STRING) as field14,
        CAST(NULL AS STRING) as field15,
        CAST(NULL AS STRING) as field16,
        CAST(NULL AS STRING) as field17,
        CAST(NULL AS STRING) as field18,
        CAST(NULL AS STRING) as field19,
        CAST(NULL AS STRING) as field20,
        CAST(NULL AS STRING) as field21,
        CAST(NULL AS STRING) as field22,
        CAST(NULL AS STRING) as field23,
        CAST(NULL AS STRING) as field24,
        CAST(NULL AS STRING) as field25,
        CAST(NULL AS STRING) as field26,
        CAST(NULL AS STRING) as field27,
        CAST(NULL AS STRING) as field28,
        CAST(NULL AS STRING) as field29
    FROM fw_placement_level
    WHERE creative_duration IS NOT NULL
    and device is not null and device != 'N/A' and device != 'Unknown'
    GROUP BY
        CASE
            WHEN CAST(creative_duration AS DOUBLE) <= 15 THEN '0-15s'
            WHEN CAST(creative_duration AS DOUBLE) <= 30 THEN '16-30s'
            WHEN CAST(creative_duration AS DOUBLE) <= 45 THEN '31-45s'
            WHEN CAST(creative_duration AS DOUBLE) <= 60 THEN '46-60s'
            ELSE '60s+'
        END,
        device,
        ad_unit_position,
        aos_deal_id

    UNION ALL

    SELECT
        'DEVICE_AD_POSITION_MATRIX' as data_type,
        aos_deal_id as `AOS_Deal_ID`,
        device as field1,
        ad_unit_position as field2,
        CAST(SUM(delivered_impressions) AS STRING) as field3,
        CAST(SUM(delivered_revenue) AS STRING) as field4,
        CAST(SUM(delivered_clicks) AS STRING) as field5,
        CAST(COUNT(DISTINCT placement_id) AS STRING) as field6,
        CAST(AVG(CAST(creative_duration AS DOUBLE)) AS STRING) as field7,
        CAST(NULL AS STRING) as field8,
        CAST(NULL AS STRING) as field9,
        CAST(NULL AS STRING) as field10,
        CAST(NULL AS STRING) as field11,
        CAST(NULL AS STRING) as field12,
        CAST(NULL AS STRING) as field13,
        CAST(NULL AS STRING) as field14,
        CAST(NULL AS STRING) as field15,
        CAST(NULL AS STRING) as field16,
        CAST(NULL AS STRING) as field17,
        CAST(NULL AS STRING) as field18,
        CAST(NULL AS STRING) as field19,
        CAST(NULL AS STRING) as field20,
        CAST(NULL AS STRING) as field21,
        CAST(NULL AS STRING) as field22,
        CAST(NULL AS STRING) as field23,
        CAST(NULL AS STRING) as field24,
        CAST(NULL AS STRING) as field25,
        CAST(NULL AS STRING) as field26,
        CAST(NULL AS STRING) as field27,
        CAST(NULL AS STRING) as field28,
        CAST(NULL AS STRING) as field29
    FROM unified_placement_level
    GROUP BY
         device
        ,ad_unit_position
        ,aos_deal_id

    UNION ALL

    SELECT
        'DEAL_AD_UNITS_PERFORMANCE' as data_type,
        aos_deal_id as `AOS_Deal_ID`,
        CASE
            WHEN deal_ad_units = 'null' OR deal_ad_units IS NULL THEN 'No Deal'
            ELSE deal_ad_units
        END as field1,
        CAST(SUM(delivered_impressions) AS STRING) as field2,
        CAST(SUM(delivered_revenue) AS STRING) as field3,
        CAST(COUNT(DISTINCT placement_id) AS STRING) as field4,
        CAST(COUNT(DISTINCT creative_id) AS STRING) as field5,
        CAST(NULL AS STRING) as field6,
        CAST(NULL AS STRING) as field7,
        CAST(NULL AS STRING) as field8,
        CAST(NULL AS STRING) as field9,
        CAST(NULL AS STRING) as field10,
        CAST(NULL AS STRING) as field11,
        CAST(NULL AS STRING) as field12,
        CAST(NULL AS STRING) as field13,
        CAST(NULL AS STRING) as field14,
        CAST(NULL AS STRING) as field15,
        CAST(NULL AS STRING) as field16,
        CAST(NULL AS STRING) as field17,
        CAST(NULL AS STRING) as field18,
        CAST(NULL AS STRING) as field19,
        CAST(NULL AS STRING) as field20,
        CAST(NULL AS STRING) as field21,
        CAST(NULL AS STRING) as field22,
        CAST(NULL AS STRING) as field23,
        CAST(NULL AS STRING) as field24,
        CAST(NULL AS STRING) as field25,
        CAST(NULL AS STRING) as field26,
        CAST(NULL AS STRING) as field27,
        CAST(NULL AS STRING) as field28,
        CAST(NULL AS STRING) as field29
    FROM fw_placement_level
    GROUP BY
        CASE
            WHEN deal_ad_units = 'null' OR deal_ad_units IS NULL THEN 'No Deal'
            ELSE deal_ad_units
        END, aos_deal_id

    UNION ALL

    SELECT
        'DEMO_BAND_PERFORMANCE' as data_type,
        aos_deal_id as `AOS_Deal_ID`,
        demo_band as field1,
        CAST(SUM(on_target_impressions) AS STRING) as field2,
        CAST(COUNT(DISTINCT placement_id) AS STRING) as field3,
        CAST(NULL AS STRING) as field4,
        CAST(NULL AS STRING) as field5,
        CAST(NULL AS STRING) as field6,
        CAST(NULL AS STRING) as field7,
        CAST(NULL AS STRING) as field8,
        CAST(NULL AS STRING) as field9,
        CAST(NULL AS STRING) as field10,
        CAST(NULL AS STRING) as field11,
        CAST(NULL AS STRING) as field12,
        CAST(NULL AS STRING) as field13,
        CAST(NULL AS STRING) as field14,
        CAST(NULL AS STRING) as field15,
        CAST(NULL AS STRING) as field16,
        CAST(NULL AS STRING) as field17,
        CAST(NULL AS STRING) as field18,
        CAST(NULL AS STRING) as field19,
        CAST(NULL AS STRING) as field20,
        CAST(NULL AS STRING) as field21,
        CAST(NULL AS STRING) as field22,
        CAST(NULL AS STRING) as field23,
        CAST(NULL AS STRING) as field24,
        CAST(NULL AS STRING) as field25,
        CAST(NULL AS STRING) as field26,
        CAST(NULL AS STRING) as field27,
        CAST(NULL AS STRING) as field28,
        CAST(NULL AS STRING) as field29
    FROM unified_placement_level
    WHERE demo_band IS NOT NULL
    GROUP BY demo_band, aos_deal_id
    
    UNION ALL

    
    SELECT 
        'PACKAGE_PERFORMANCE' as data_type,
        pl.aos_deal_id as `AOS_Deal_ID`,
        -- CAST(pl.package_name AS STRING) as field1,
        CAST(
        CASE 
            WHEN pl.parent_line_item_name = 'N/A' THEN pl.aos_deal_line_item_name
            ELSE coalesce(pl.parent_line_item_name, pl.aos_deal_line_item_name)
        END AS STRING) as field1,
        CAST(SUM(pl.delivered_impressions) AS STRING) as field2,
        CAST(SUM(pl.delivered_revenue) AS STRING) as field3,
        CAST(SUM(creative_id_count) AS STRING) as field4,
        -- 3P metrics: Get from placement_third_party
        CAST(SUM(ptp.placement_third_party_impressions) AS STRING) as field5,
        CAST(SUM(ptp.placement_third_party_revenue) AS STRING) as field6,
        CAST(SUM(pl.guaranteed_impressions) AS STRING) as field7,
        CAST(SUM(pl.guaranteed_revenue) AS STRING) as field8,
        CAST(NULL AS STRING) as field9, 
        CAST(NULL AS STRING) as field10, 
        CAST(NULL AS STRING) as field11, 
        CAST(NULL AS STRING) as field12,
        CAST(NULL AS STRING) as field13, 
        CAST(NULL AS STRING) as field14, 
        CAST(NULL AS STRING) as field15, 
        CAST(NULL AS STRING) as field16, 
        CAST(NULL AS STRING) as field17,
        CAST(NULL AS STRING) as field18, 
        CAST(NULL AS STRING) as field19, 
        CAST(NULL AS STRING) as field20, 
        CAST(NULL AS STRING) as field21,
        CAST(NULL AS STRING) as field22,
        CAST(NULL AS STRING) as field23,
        CAST(NULL AS STRING) as field24,
        CAST(NULL AS STRING) as field25,
        CAST(NULL AS STRING) as field26,
        CAST(NULL AS STRING) as field27,
        CAST(NULL AS STRING) as field28,
        CAST(NULL AS STRING) as field29
    FROM (select * from unified_placement_level_packages) pl
    LEFT JOIN unified_placement_third_party ptp ON pl.placement_id = ptp.placement_id
    GROUP BY (CASE 
            WHEN pl.parent_line_item_name = 'N/A' THEN pl.aos_deal_line_item_name
            ELSE coalesce(pl.parent_line_item_name, pl.aos_deal_line_item_name)
        END), pl.aos_deal_id

    UNION ALL

    SELECT 
    'CONTENT_PERFORMANCE' as data_type,
    aos_deal_id as `AOS_Deal_ID`,
    video_vertical as field1,
    show_name as field2,
    CAST(SUM(delivered_impressions) AS STRING) as field3,
    CAST(SUM(delivered_revenue) AS STRING) as field4,
    CAST(COUNT(DISTINCT placement_id) AS STRING) as field5,
    CAST(COUNT(DISTINCT creative_id) AS STRING) as field6,
    CAST(NULL AS STRING) as field7, 
    CAST(NULL AS STRING) as field8, 
    CAST(NULL AS STRING) as field9, 
    CAST(NULL AS STRING) as field10, 
    CAST(NULL AS STRING) as field11, 
    CAST(NULL AS STRING) as field12, 
    CAST(NULL AS STRING) as field13,
    CAST(NULL AS STRING) as field14, 
    CAST(NULL AS STRING) as field15, 
    CAST(NULL AS STRING) as field16, 
    CAST(NULL AS STRING) as field17, 
    CAST(NULL AS STRING) as field18,
    CAST(NULL AS STRING) as field19, 
    CAST(NULL AS STRING) as field20, 
    CAST(NULL AS STRING) as field21,
    CAST(NULL AS STRING) as field22,
    CAST(NULL AS STRING) as field23,
    CAST(NULL AS STRING) as field24,
    CAST(NULL AS STRING) as field25,
    CAST(NULL AS STRING) as field26,
    CAST(NULL AS STRING) as field27,
    CAST(NULL AS STRING) as field28,
    CAST(NULL AS STRING) as field29
FROM unified_placement_level
--where show_name <> 'N/A' and show_name <> 'Unknown' and show_name is not null
GROUP BY video_vertical, show_name, aos_deal_id

UNION ALL

SELECT 
    'PLACEMENT_DETAIL' as data_type,
    ps.aos_deal_id as `AOS_Deal_ID`,
    CAST(ps.placement_id AS STRING) as field1,
    ps.placement_name as field2,
    CAST(ps.placement_delivered_impressions AS STRING) as field3,
    CAST(ps.placement_delivered_revenue AS STRING) as field4,
    CAST(ps.placement_guaranteed_impressions AS STRING) as field5,
    CAST(ps.placement_guaranteed_revenue AS STRING) as field6,
    CAST(ps.placement_third_party_impressions AS STRING) as field7,
    CAST(ps.placement_third_party_revenue AS STRING) as field8,
    CAST(NULL AS STRING) as field9,
    CAST(NULL AS STRING) as field10,
    CAST(NULL AS STRING) as field11,
    CAST(NULL AS STRING) as field12,
    CAST(NULL AS STRING) as field13,
    CAST(NULL AS STRING) as field14,
    CAST(NULL AS STRING) as field15,
    CAST(NULL AS STRING) as field16,
    CAST(NULL AS STRING) as field17,
    CAST(NULL AS STRING) as field18,
    CAST(NULL AS STRING) as field19,
    CAST(NULL AS STRING) as field20,
    CAST(NULL AS STRING) as field21,
    CAST(NULL AS STRING) as field22,
    CAST(NULL AS STRING) as field23,
    CAST(NULL AS STRING) as field24,
    CAST(NULL AS STRING) as field25,
    CAST(NULL AS STRING) as field26,
    CAST(NULL AS STRING) as field27,
    CAST(NULL AS STRING) as field28,
    CAST(NULL AS STRING) as field29
FROM unified_placement_summary ps

UNION ALL

SELECT 
    'TARGET_AUDIENCE_DISTRIBUTION' as data_type,
    1p.aos_deal_id as `AOS_Deal_ID`,
    upper(fw_audience_segment) as field1,
    CAST(SUM(delivered_impressions) AS STRING) as field2,
    CAST(SUM(delivered_revenue) AS STRING) as field3,
    CAST(MAX(3p.placement_third_party_impressions) AS STRING) as field4,
    CAST(MAX(3p.placement_third_party_revenue) AS STRING) as field5,
    CAST(NULL AS STRING) as field6,
    CAST(NULL AS STRING) as field7,
    CAST(NULL AS STRING) as field8,
    CAST(NULL AS STRING) as field9,
    CAST(NULL AS STRING) as field10,
    CAST(NULL AS STRING) as field11,
    CAST(NULL AS STRING) as field12,
    CAST(NULL AS STRING) as field13,
    CAST(NULL AS STRING) as field14,
    CAST(NULL AS STRING) as field15,
    CAST(NULL AS STRING) as field16,
    CAST(NULL AS STRING) as field17,
    CAST(NULL AS STRING) as field18,
    CAST(NULL AS STRING) as field19,
    CAST(NULL AS STRING) as field20,
    CAST(NULL AS STRING) as field21,
    CAST(NULL AS STRING) as field22,
    CAST(NULL AS STRING) as field23,
    CAST(NULL AS STRING) as field24,
    CAST(NULL AS STRING) as field25,
    CAST(NULL AS STRING) as field26,
    CAST(NULL AS STRING) as field27,
    CAST(NULL AS STRING) as field28,
    CAST(NULL AS STRING) as field29
FROM target_audience_distribution 1p
left join fw_third_party_at_target_audience 3p
on 1p.aos_deal_id = 3p.aos_deal_id and upper(1p.fw_audience_segment) = upper(3p.target_audience)
group by 1p.aos_deal_id, fw_audience_segment
)
select * from unified_report_section 
--where `AOS_Deal_ID` != -1    
)"""

    batch_alkimi_query = ""
    select_statement = ""

    # Build the query with all deals in the batch
    for i, deal in enumerate(deal_batches):
        if i == 0:
            batch_alkimi_query += "WITH "
        if i != len(deal_batches) - 1:
            batch_alkimi_query += alkimi_unified_query.replace('?', str(deal)).format(i) + ','
            select_statement += f"SELECT * FROM alkimi_data{i} UNION ALL "
        else:
            batch_alkimi_query += alkimi_unified_query.replace('?', str(deal)).format(i)
            select_statement += f"SELECT * FROM alkimi_data{i}"

    batch_alkimi_query += select_statement

    print(f"Processing batch with {len(deal_batches)} deals")

    # Execute the query (cached tables are already available)
    batch_alkimi_data = spark.sql(batch_alkimi_query)

    if not spark.catalog.tableExists(f'fox_bi_qa.gold_ad_sales.wrap_detailed_unified_report_sections_by_deal'):
        print("Creating table (first time load)")
        batch_alkimi_data.write.format('delta') \
            .mode('overwrite') \
            .partitionBy('AOS_Deal_ID') \
            .option('mergeSchema', 'true') \
            .option('overwriteDynamicPartitions', 'true') \
            .option('delta.enableDeletionVectors', 'false') \
            .option('delta.enableIcebergCompatV2', 'true') \
            .option('delta.universalFormat.enabledFormats', 'iceberg') \
            .option('delta.columnMapping.mode', 'name') \
            .saveAsTable(f'fox_bi_qa.gold_ad_sales.wrap_detailed_unified_report_sections_by_deal')
    else:
        print("Appending to existing table")
        batch_alkimi_data.write.format('delta') \
            .mode('overwrite') \
            .option('mergeSchema', 'true') \
            .option('partitionOverwriteMode', 'dynamic') \
            .saveAsTable(f'fox_bi_qa.gold_ad_sales.wrap_detailed_unified_report_sections_by_deal')


# Optimize Spark configuration for better performance
def optimize_spark_config():
    """Optimize Spark configuration for batch processing"""
    spark.conf.set("spark.sql.adaptive.enabled", "true")
    spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled", "true")
    spark.conf.set("spark.sql.adaptive.skewJoin.enabled", "true")
    spark.conf.set("spark.sql.adaptive.localShuffleReader.enabled", "true")
    spark.conf.set("spark.sql.shuffle.partitions", "100")  # Adjust based on cluster size
    spark.conf.set("spark.sql.files.maxPartitionBytes", "134217728")  # 128MB
    spark.conf.set("spark.sql.broadcastTimeout", "600")
    spark.conf.set("spark.sql.autoBroadcastJoinThreshold", "10485760")  # 10MB
    spark.conf.set("spark.databricks.queryWatchdog.maxQueryTasks", "2000")
    spark.conf.set("spark.sql.adaptive.advisoryPartitionSizeInBytes", "67108864")  # 64MB
    print("Spark configuration optimized for batch processing")

# Main execution code
from pyspark.sql.functions import col
import ast
import time

# Optimize Spark configuration
optimize_spark_config()

# Check if parameters are provided for parallel execution
if deal_ids_param and deal_ids_param.strip():
    # Parallel execution mode: process only the provided deal IDs
    try:
        # Try to parse as Python list string (e.g., "[1, 2, 3]")
        deals = ast.literal_eval(deal_ids_param)
    except:
        # Fallback: parse as comma-separated string (e.g., "1,2,3")
        deals = [int(d.strip()) for d in deal_ids_param.split(',') if d.strip()]

    print(f'=== Parallel Execution Mode - Batch {batch_number_param} ===')
    print(f'Processing {len(deals)} deals: {deals}')

    # Process as a single batch
    batch = deals
    batch_start = time.time()
    print(f'\n=== Processing batch {batch_number_param} ({len(batch)} deals) ===')
    try:
        # Cache base tables for this batch
        cache_base_tables_for_batch(batch)

        # Process the batch (uses cached tables)
        batch_alkimi_data_to_table(batch)

        # Uncache to free memory
        uncache_base_tables()

        batch_duration = time.time() - batch_start
        print(f'Batch {batch_number_param} completed in {batch_duration:.2f} seconds ({batch_duration/60:.2f} minutes)')
    except Exception as e:
        print(f'Error processing batch {batch_number_param}: {str(e)}')
        # Try to uncache even on error
        try:
            uncache_base_tables()
        except:
            pass
        raise
else:
    # Original sequential execution mode: get all deals and process in batches
    deals_query = f"""
    select distinct aos_deal_id
    from (
        SELECT DISTINCT
            `AOS Deal ID` AS aos_deal_id
        FROM fox_bi_qa.gold_ad_sales.v_ft_gam_campaign_delivery
        union
        SELECT DISTINCT
            `AOS_Deal ID` AS aos_deal_id
        FROM fox_bi_qa.gold_ad_sales.v_ft_freewheel_campaign_delivery
        )
    """

    deals_df = spark.sql(deals_query)
    deals = [deal['aos_deal_id'] for deal in deals_df.select('aos_deal_id').collect()]

    # Significantly increase batch size - process more deals per query
    batch_size = 15
    deal_batches = [deals[n:n+batch_size] for n in range(0, len(deals), batch_size)]
    print(f'Total deals: {len(deals)}')
    print(f'Number of batches to execute: {len(deal_batches)}')
    print(f'Batch size: {batch_size}')

    print('Executing batches')
    start_time = time.time()

    for i, batch in enumerate(deal_batches):
        batch_start = time.time()
        print("batch_number", i, " ", "for deals" , batch)
        print(f'\n=== Processing batch {i+1}/{len(deal_batches)} ({len(batch)} deals) ===')
        try:
            # Cache base tables for this batch
            cache_base_tables_for_batch(batch)

            # Process the batch (uses cached tables)
            batch_alkimi_data_to_table(batch)

            # Uncache to free memory
            uncache_base_tables()

            batch_duration = time.time() - batch_start
            print(f'Batch {i+1} completed in {batch_duration:.2f} seconds ({batch_duration/60:.2f} minutes)')
        except Exception as e:
            print(f'Error processing batch {i+1}: {str(e)}')
            # Try to uncache even on error
            try:
                uncache_base_tables()
            except:
                pass
            raise

    total_duration = time.time() - start_time
    print(f'\n=== Total execution time: {total_duration:.2f} seconds ({total_duration/60:.2f} minutes) ===')


# # Main execution code
# deals_query = f"""
# select distinct aos_deal_id
# from (
#     SELECT DISTINCT
#         `AOS Deal ID` AS aos_deal_id
#     FROM fox_bi_qa.gold_ad_sales.v_ft_gam_campaign_delivery
#     union
#     SELECT DISTINCT
#         `AOS_Deal ID` AS aos_deal_id
#     FROM fox_bi_qa.gold_ad_sales.v_ft_freewheel_campaign_delivery
#     )
# """

# from pyspark.sql.functions import col

# # Optimize Spark configuration
# optimize_spark_config()

# # deals_df = spark.sql(deals_query)
# # deals = [deal['aos_deal_id'] for deal in deals_df.select('aos_deal_id').collect()]

# # # Significantly increase batch size - process more deals per query
# # # This reduces the number of separate queries executed and overhead
# # # Key optimization: Even though each deal scans tables separately, processing
# # # more deals in one query reduces query compilation overhead and improves
# # # Spark's ability to optimize the overall execution plan
# # batch_size = 15  # Increased from 10 to 30 (can go to 50-100 if memory allows)
# # deal_batches = [deals[n:n+batch_size] for n in range(0, len(deals), batch_size)]
# # print(f'Total deals: {len(deals)}')
# # print(f'Number of batches to execute: {len(deal_batches)}')
# # print(f'Batch size: {batch_size}')

# # print('Executing batches')
# # import time
# # start_time = time.time()

# # for i, batch in enumerate(deal_batches):
# #     batch_start = time.time()
# #     print("batch_number", i, " ", "for deals" , batch)
# #     print(f'\n=== Processing batch {i+1}/{len(deal_batches)} ({len(batch)} deals) ===')
# #     try:
# #         # Cache base tables for this batch
# #         cache_base_tables_for_batch(batch)

# #         # Process the batch (uses cached tables)
# #         batch_alkimi_data_to_table(batch)

# #         # Uncache to free memory
# #         uncache_base_tables()

# #         batch_duration = time.time() - batch_start
# #         print(f'Batch {i+1} completed in {batch_duration:.2f} seconds ({batch_duration/60:.2f} minutes)')
# #     except Exception as e:
# #         print(f'Error processing batch {i+1}: {str(e)}')
# #         # Try to uncache even on error
# #         try:
# #             uncache_base_tables()
# #         except:
# #             pass
# #         raise

# # total_duration = time.time() - start_time
# # print(f'\n=== Total execution time: {total_duration:.2f} seconds ({total_duration/60:.2f} minutes) ===')