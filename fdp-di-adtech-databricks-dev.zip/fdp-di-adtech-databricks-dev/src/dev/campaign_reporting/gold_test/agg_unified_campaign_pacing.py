# Databricks notebook source
from datetime import datetime, timedelta

# COMMAND ----------

spark.conf.set(
    "spark.databricks.remoteFiltering.blockSelfJoins",
    "false"
)


# COMMAND ----------

spark.sparkContext.setCheckpointDir("dbfs:/checkpoints/agg_unified_campaign_pacing")

# COMMAND ----------

# Reduce shuffle partitions
spark.conf.set("spark.sql.shuffle.partitions", "200")

# COMMAND ----------

# Adaptive query execution
spark.conf.set("spark.sql.adaptive.enabled",                    "true")
spark.conf.set("spark.sql.adaptive.localShuffleReader.enabled", "true")
spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled", "true")

# COMMAND ----------

# Delta optimized write
spark.conf.set("spark.databricks.delta.optimizeWrite.enabled", "true")
spark.conf.set("spark.databricks.delta.autoCompact.enabled",   "true")

# COMMAND ----------

query = """
WITH fw_on_tar_imps_base AS (
    SELECT
        Event_date AS event_date,
        Data_Source,
        Campaign_ID,
        Campaign_Name,
        Campaign_Start_Date,
        Campaign_End_Date,
        AOS_Deal_Name,
        AOS_Deal_ID,
        AOS_Deal_start_date,
        AOS_Deal_end_date,
        AOS_Deal_Line_Item_ID,
        AOS_Deal_Line_Item_Name,
        AOS_Deal_Line_Item_Start_Date,
        AOS_Deal_Line_Item_end_Date,
        parent_line_item_name,
        AOS_Advertiser_Name,
        AOS_Agency_Name,
        advertiser_Name,
        agency_Name,
        Package_Name,
        Account_Manager,
        Account_Executive,
        Account_Coordinator,
        Billable_Third_Party_Server,
        Primary_Property,
        Pitch_ID,
        cost_method_name,
        unit_type,
        External_AD_ID,
        Line_Item_or_Placement_ID,
        Line_Item_or_Placement_Name,
        Line_Item_or_Placement_Start_Date,
        Line_Item_or_Placement_End_Date,
        budget_model,
        Campaign_Status,
        out_of_flight_flag,
        out_of_flight_impressions,
        placement_avg_user_frequency,
        booked_on_target_impression_goal,
        Impression_Goal,
        Demand_Type,
        Demo_Band,demo_comp,
        Delivered_Clicks,
        Delivered_Impressions AS delivered_impressions,
        Video_Completes,Video_Starts,total_engagements,
        Delivered_Revenue,
        Guaranteed_Impressions,Guaranteed_Revenue,Net_Unit_Cost,
        campaign_days,
        days_to_date,
        -- impressions per LIVE day across the line item's flight) AS campaign_days,
        
        -- impressions per LIVE day across the line item's flight.
        -- denominator = total live days expected over the full flight
        --             = live days observed in flight
        --               + remaining calendar days after the latest observed day (assumed live)
        -- _rn_per_day = 1 ensures each calendar day is counted at most once
        -- (replaces the unsupported COUNT(DISTINCT event_date) OVER (...) pattern)
        Guaranteed_Impressions / campaign_days AS daily_impression_goal,

        -- expected impressions delivered through the latest observed live day (Freewheel only)
        -- = daily_impression_goal (per-live-day rate) * live days elapsed in flight
        daily_impression_goal
                  * live_days
        AS impression_goal_to_date,
        CASE WHEN data_source in ('GAM', 'GAM Sports')
             THEN CASE WHEN MAX(event_date) OVER (PARTITION BY Line_Item_or_Placement_ID, Campaign_ID) < COALESCE(Line_Item_or_Placement_End_Date::date, Campaign_End_Date::date)
                       THEN (date_diff(
                            MAX(event_date) OVER (PARTITION BY Line_Item_or_Placement_ID, Campaign_ID),
                            COALESCE(Line_Item_or_Placement_Start_Date::date, Campaign_Start_Date::date)
                        ) + 1) / (
                            date_diff(
                                COALESCE(Line_Item_or_Placement_End_Date::date, Campaign_End_Date::date),
                                COALESCE(Line_Item_or_Placement_Start_Date::date, Campaign_Start_Date::date)
                            ) + 1
                        )
                        ELSE 1
                   END
         END  OSI_total,
        MIN(Freewheel_On_Target_Net_Delivered_Impressions) OVER (
            PARTITION BY Line_Item_or_Placement_ID, Event_Date
        ) AS min_on_target_net_delivered_impressions,
        Modified_Timestamp
    FROM fox_bi_qa.gold_ad_sales.ft_unified_campaign_pacing
    --WHERE NVL(AOS_Deal_ID, -1) <> -1
    --  AND NVL(AOS_Deal_Line_Item_ID, -1) <> -1--  AND nvl(AOS_Deal_Line_Item_Name,'N/A') not ilike 'cancelled%'
    --   and nvl(AOS_deal_id,-1) in (252732,16188,18484)
    -- GROUP BY ALL
),
min_fw_on_tar_imps_data AS (
    SELECT
        event_date,
        Data_Source,
        Campaign_ID,
        Campaign_Name,
        Campaign_Start_Date,
        Campaign_End_Date,
        AOS_Deal_Name,
        AOS_Deal_ID,
        AOS_Deal_start_date,
        AOS_Deal_end_date,
        AOS_Deal_Line_Item_ID,
        AOS_Deal_Line_Item_Name,
        AOS_Deal_Line_Item_Start_Date,
        AOS_Deal_Line_Item_end_Date,
        Line_Item_or_Placement_ID,
        Line_Item_or_Placement_Name,
        Line_Item_or_Placement_Start_Date,
        Line_Item_or_Placement_End_Date,
        budget_model,
        parent_line_item_name,
        AOS_Advertiser_Name,
        AOS_Agency_Name,
        advertiser_Name,
        agency_Name,
        Package_Name,
        Account_Manager,
        Account_Executive,
        Account_Coordinator,
        Billable_Third_Party_Server,
        Primary_Property,
        Pitch_ID,
        cost_method_name,
        unit_type,
        External_AD_ID,
        Campaign_Status,
        out_of_flight_flag,
        out_of_flight_impressions,
        placement_avg_user_frequency,
        booked_on_target_impression_goal,
        Impression_Goal,
        Demand_Type,
        Demo_Band,demo_comp,daily_impression_goal,impression_goal_to_date,
        campaign_days,days_to_date,OSI_total,
        Guaranteed_Impressions,Guaranteed_Revenue,Net_Unit_Cost,
        sum(delivered_clicks) del_clicks,
        SUM(Delivered_Impressions) del_imps,
        sum(delivered_revenue) del_rev,
        sum(Video_Completes) Video_Completes,sum(Video_Starts) Video_Starts,sum(total_engagements) as total_engagements,
        nvl(MIN(min_on_target_net_delivered_impressions),0) on_tar ,
        MAX(Modified_Timestamp) as Modified_Timestamp
    FROM fw_on_tar_imps_base
    GROUP BY ALL
)
,third_party_data as(

select aos_deal_id,line_item_or_placement_id,aos_deal_line_item_id,
sum(case
    when nvl(third_party_line_item_id,'-1') = '-1' then 0
    when nvl(third_party_impressions,0) = 0 then 0
    when data_source in ('GAM') then 
        CASE
            WHEN Demand_Type = 'SPONSORSHIP' THEN Guaranteed_Revenue
            ELSE ((third_party_impressions) * net_unit_cost)/1000
        END 
    else (third_party_revenue)
end) as third_party_revenue,
    SUM(third_party_impressions) as third_party_impressions,
    SUM(third_party_clicks) as third_party_clicks,
    SUM(third_party_video_completes) as third_party_video_completes,
    SUM(third_party_video_views) as third_party_video_views



 from
    (
SELECT
    pl.AOS_Deal_ID,line_item_or_placement_id,aos_deal_line_item_id,demand_type,third_party_line_item_id,
        Data_Source,
        Net_Unit_Cost,
        guaranteed_impressions,
        guaranteed_revenue,
    SUM(third_party_impressions) as third_party_impressions,
    SUM(third_party_revenue) as third_party_revenue,
    SUM(third_party_clicks) as third_party_clicks,
    SUM(third_party_video_completes) as third_party_video_completes,
    SUM(third_party_video_views) as third_party_video_views
FROM (
    SELECT DISTINCT
        AOS_Deal_ID,
        Line_Item_or_Placement_ID,
        Third_Party_Line_Item_ID,
        Demand_Type,
        AOS_Deal_Line_Item_ID,
        Creative_ID,
        Event_Date,
        Ad_Unit_Position,
        Data_Source,
        Net_Unit_Cost,
        guaranteed_impressions,
        guaranteed_revenue,
        MIN(Third_Party_Billable_Impressions) as third_party_impressions,
        MIN(Third_Party_Revenue) as third_party_revenue,
        MIN(third_party_clicks) as third_party_clicks,
        MIN(third_party_video_completes) as third_party_video_completes,
        MIN(third_party_video_views) as third_party_video_views
    FROM fox_bi_qa.gold_ad_sales.ft_unified_campaign_pacing
    where UPPER(Data_Source) IN ('FREEWHEEL','GAM')
    -- WHERE `AOS_Deal_ID` = 16188
    GROUP BY ALL
) pl
GROUP BY all)
group by all
UNION ALL

    SELECT DISTINCT
        AOS_Deal_ID,
        Line_Item_or_Placement_ID,
        AOS_Deal_Line_Item_ID,
        SUM(Third_Party_Revenue) as third_party_revenue,
        SUM(Third_Party_Billable_Impressions) as third_party_impressions,
        SUM(third_party_clicks) as third_party_clicks,
        SUM(third_party_video_completes) as third_party_video_completes,
        SUM(third_party_video_views) as third_party_video_views
    FROM fox_bi_qa.gold_ad_sales.ft_unified_campaign_pacing
    where UPPER(Data_Source) NOT IN ('FREEWHEEL','GAM')
    -- WHERE `AOS_Deal_ID` = 16188
    GROUP BY ALL
)

----------------------------------------------
,calculated_metrics_data as (
select 
        Data_Source,
        Campaign_ID,
        Campaign_Name,
        Campaign_Start_Date::date as Campaign_Start_Date,
        Campaign_End_Date::date as Campaign_End_Date,
        AOS_Deal_Name,
        cov_data.AOS_Deal_ID,
        AOS_Deal_start_date::Date as AOS_Deal_start_date,
        AOS_Deal_end_date::Date as AOS_Deal_end_date,
        cov_data.AOS_Deal_Line_Item_ID,
        AOS_Deal_Line_Item_Name,
        AOS_Deal_Line_Item_Start_Date::Date as AOS_Deal_Line_Item_Start_Date,
        AOS_Deal_Line_Item_end_Date::Date as AOS_Deal_Line_Item_end_Date,
        cov_data.Line_Item_or_Placement_ID,
        Line_Item_or_Placement_Name,
        Line_Item_or_Placement_Start_Date::Date as Line_Item_or_Placement_Start_Date,
        Line_Item_or_Placement_End_Date::Date as Line_Item_or_Placement_End_Date,
        budget_model,
        parent_line_item_name,
        UPPER(AOS_Advertiser_Name) AOS_Advertiser_Name,
        UPPER(AOS_Agency_Name) AOS_Agency_Name,
        UPPER(advertiser_Name) advertiser_Name,
        UPPER(agency_Name) agency_Name,
        UPPER(Package_Name) Package_Name,
        UPPER(Account_Manager) Account_Manager,
        UPPER(Account_Executive) Account_Executive,
        UPPER(Account_Coordinator) Account_Coordinator,
        Billable_Third_Party_Server,
        Primary_Property,
        Pitch_ID,
        cost_method_name,
        unit_type,
        External_AD_ID,
        Campaign_Status,
        out_of_flight_flag,
        sum(out_of_flight_impressions) out_of_flight_impressions,
        placement_avg_user_frequency,
        Demand_Type,
        Demo_Band,daily_impression_goal,impression_goal_to_date,campaign_days,days_to_date,
        Guaranteed_Impressions,Guaranteed_Revenue,Net_Unit_Cost
,sum(distinct on_tar) Freewheel_On_Target_Net_Delivered_Impressions
,sum(del_imps) first_party_delivered_impressions
,sum(del_clicks) first_party_delivered_clicks
,case when data_source in ('GAM', 'GAM Sports') then 
        CASE
            WHEN Demand_Type = 'SPONSORSHIP' THEN Guaranteed_Revenue
            ELSE (sum(del_imps) * max(net_unit_cost))/1000
        END 
    else sum(del_rev)
end first_party_delivered_revenue
,sum(Video_Completes) Video_Completes
,sum(Video_Starts) Video_Starts
,sum(total_engagements) as total_engagements
,case 
    when data_source in ('GAM', 'GAM Sports') 
    then null 
    when budget_model = 'Impression Target' 
    then null
    when budget_model = 'Demographic Impression Target'
    then case 
            when sum(distinct on_tar) = 0 
            then 1.2 
            when sum(distinct on_tar)/sum(del_imps)  < 1
            then booked_on_target_impression_goal/(impression_goal)
            else sum(distinct on_tar)/sum(del_imps)
          end
    else NULL
 end::decimal(7,2) as cov 
,CASE WHEN Billable_Third_Party_Server = 'FOX 1st Party' 
     AND budget_model='Demographic Impression Target' THEN 
      sum(del_imps) * CoV
WHEN Billable_Third_Party_Server = 'FOX 1st Party' 
     AND budget_model='Impression Target' THEN sum(del_imps)
WHEN Billable_Third_Party_Server != 'FOX 1st Party' 
      AND budget_model='Impression Target' then 
      case when min(third_party_impressions) > 0 then min(third_party_impressions) else sum(del_imps) end
WHEN Billable_Third_Party_Server != 'FOX 1st Party' 
      AND budget_model='Demographic Impression Target' then 
      case when min(third_party_impressions) > 0 then min(third_party_impressions) else sum(del_imps) end * CoV 
WHEN UPPER(unit_type)='DAYS' then campaign_days
WHEN UPPER(cost_method_name)='SOV-FLAT RATE' then min(1)
ELSE case when min(third_party_impressions) > 0 then min(third_party_impressions) else sum(del_imps) end
end campaign_billable_impressions
,((campaign_billable_impressions/guaranteed_impressions))::DECIMAL(7,2) campaign_del_pct
,( CASE when max(guaranteed_impressions) = 1 then null
            WHEN data_source ='Freewheel' and demand_type = 'PROGRAMMATIC GUARANTEED'  THEN SUM(del_imps) / MAX(impression_goal_to_date)
            when data_source = 'Freewheel' and demand_type = 'DIRECT SOLD' 
            THEN  
                CASE WHEN Demo_Band =  'Audience Target' THEN SUM(del_imps) / MAX(impression_goal_to_date)
                    WHEN Demo_Band = 'P2+' THEN  (SUM(del_imps)*(case when sum(distinct on_tar) = 0 then 1.2 else nvl(sum(distinct on_tar)/sum(del_imps),1.2) end::decimal(7,2)))/ MAX(impression_goal_to_date)
                    WHEN Demo_Band = 'N/A' THEN NULL
                    ELSE SUM(del_imps * demo_comp) / MAX(impression_goal_to_date) 
                END
            WHEN data_source in ('GAM', 'GAM Sports') then (sum(del_imps)/max(guaranteed_impressions))*max(OSI_total)
        END)::decimal(7,2) AS first_party_pacing_pct
    ,(CASE WHEN data_source ='Freewheel' and demand_type NOT IN ('PROGRAMMATIC GUARANTEED','MARKETPLACE PLATFORM PRIVATE','MARKETPLACE PLATFORM EXCHANGE')  THEN 
        CASE WHEN Demo_Band =  'Audience Target' THEN min(third_party_impressions) / MAX(impression_goal_to_date)
             WHEN Demo_Band = 'P2+' THEN  (min(third_party_impressions)*(case when sum(distinct on_tar) = 0 then 1.2 else nvl(sum(distinct on_tar)/sum(del_imps),1.2) end::decimal(7,2)))/ MAX(impression_goal_to_date)
             WHEN Demo_Band = 'N/A' THEN NULL
             ELSE min(third_party_impressions) * min(demo_comp) / MAX(impression_goal_to_date) 
         END
        WHEN data_source in ('GAM', 'GAM Sports') then (min(third_party_impressions)/max(guaranteed_impressions))*max(impression_goal_to_date)
    END)::decimal(7,2) AS third_party_pacing_pct
    ,campaign_billable_impressions / max(impression_goal_to_date) as campaign_pacing_pct
    ,(nvl(first_party_pacing_pct, 0) - nvl(third_party_pacing_pct, 0)) as  pacing_discrepency
    ,CASE 
        WHEN UPPER(unit_type)='DAYS' or UPPER(cost_method_name)='SOV-FLAT RATE'
        THEN campaign_billable_impressions * net_unit_cost
        ELSE ((campaign_billable_impressions / 1000) * net_unit_cost)
    END as billable_revenue
    ,case 
        when campaign_end_date <= current_date() 
        then billable_revenue - guaranteed_revenue
        else NULL
     end as under_delivery_over_delivery
    ,CASE 
    WHEN Data_Source = 'Freewheel' 
         AND Demand_Type in ('PROGRAMMATIC GUARANTEED','MARKETPLACE PLATFORM PRIVATE' , 'MARKETPLACE PLATFORM EXCHANGE')
    THEN 
        CASE 
            WHEN nvl(first_party_pacing_pct, 0) > 1 THEN 0
            ELSE Guaranteed_Revenue - (Guaranteed_Revenue * nvl(first_party_pacing_pct, 0))
        END
    WHEN Data_Source = 'Freewheel' 
    THEN 
        CASE 
            WHEN Campaign_Billable_Impressions < 1 THEN 0
            WHEN nvl(Campaign_Pacing_pct, 0) > 1 THEN 0
            WHEN nvl(Campaign_Pacing_pct, 0) IS NULL OR nvl(Campaign_Pacing_pct, 0) = 0 THEN NULL
            ELSE Guaranteed_Revenue - (Guaranteed_Revenue * nvl(Campaign_Pacing_pct, 0))
        END
    ELSE Guaranteed_Revenue - (Guaranteed_Revenue * nvl(Campaign_Pacing_pct, 0))
END risk
    ,sum(del_imps)/max(placement_avg_user_frequency) reach
    ,min(third_party_impressions) third_party_impressions
    ,min(third_party_revenue) third_party_revenue 
    ,min(third_party_clicks) third_party_clicks
    ,min(third_party_video_completes) as third_party_video_completes
    ,min(third_party_video_views) as third_party_video_views
    ,(sum(Video_Completes) /sum(Video_Starts)) first_party_vcr
    ,(min(third_party_video_completes)/min(third_party_impressions)) third_party_vcr
    ,(sum(del_clicks)/sum(del_imps)) first_party_clicks_thru
    ,(min(third_party_clicks)/min(third_party_impressions)) third_party_clicks_thru
    ,max(Modified_Timestamp) as Modified_Timestamp
from min_fw_on_tar_imps_data cov_data
left join third_party_data as tpd
on cov_data.aos_deal_id = tpd.aos_deal_id
and cov_data.aos_deal_line_item_id = tpd.aos_deal_line_item_id
and cov_data.line_item_or_placement_id = tpd.line_item_or_placement_id

-- where cov_data.aos_deal_id in (252732,16188,18484)
group by 
Data_Source,
        Campaign_ID,
        Campaign_Name,
        Campaign_Start_Date,
        Campaign_End_Date,
        AOS_Deal_Name,
        cov_data.AOS_Deal_ID,
        AOS_Deal_start_date,
        AOS_Deal_end_date,
        cov_data.AOS_Deal_Line_Item_ID,
        AOS_Deal_Line_Item_Name,
        AOS_Deal_Line_Item_Start_Date,
        AOS_Deal_Line_Item_end_Date,
        cov_data.Line_Item_or_Placement_ID,
        Line_Item_or_Placement_Name,
        Line_Item_or_Placement_Start_Date,
        Line_Item_or_Placement_End_Date,
        budget_model,
        parent_line_item_name,
        AOS_Advertiser_Name,
        AOS_Agency_Name,
        advertiser_Name,
        agency_Name,
        Package_Name,
        Account_Manager,
        Account_Executive,
        Account_Coordinator,
        Billable_Third_Party_Server,
        Primary_Property,
        Pitch_ID,
        cost_method_name,
        unit_type,
        External_AD_ID,
        Campaign_Status,
        out_of_flight_flag,
        placement_avg_user_frequency,
        Demand_Type,
        Demo_Band,daily_impression_goal,impression_goal_to_date,campaign_days,days_to_date,
        Guaranteed_Impressions,Guaranteed_Revenue,Net_Unit_Cost,
        booked_on_target_impression_goal,
        Impression_Goal
order by cov_data.aos_deal_id,cov_data.aos_deal_line_item_id)


select * from calculated_metrics_data 

"""


unified_campaign_delivery = spark.sql(query)

# COMMAND ----------

#unified_campaign_delivery = unified_campaign_delivery.checkpoint()   # ← materializes before shuffle

# COMMAND ----------

unified_campaign_delivery.write.format('delta')\
    .mode('overwrite')\
    .partitionBy('Campaign_ID')\
    .option('mergeSchema', 'true')\
    .option("optimizeWrite", "true")\
    .option('overwriteDynamicPartitions', 'true')\
    .option('delta.enableDeletionVectors', 'false')\
    .option('delta.enableIcebergCompatV2', 'true')\
    .option('delta.universalFormat.enabledFormats', 'iceberg')\
    .option('delta.columnMapping.mode', 'name')\
    .saveAsTable('fox_bi_qa.gold_ad_sales.agg_unified_campaign_pacing')