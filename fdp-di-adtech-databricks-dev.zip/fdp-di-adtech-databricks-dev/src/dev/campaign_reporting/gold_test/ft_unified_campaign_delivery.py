# Databricks notebook source
from datetime import datetime, timedelta

# COMMAND ----------

spark.conf.set(
    "spark.databricks.remoteFiltering.blockSelfJoins",
    "false"
)


# COMMAND ----------

query = """
    WITH raw_fw_data AS (
  SELECT
    'Freewheel' AS data_source,
    event_date,
    campaign_id,
    campaign_name,
    campaign_start_timestamp_est AS campaign_start_date,
    campaign_end_timestamp_est AS campaign_end_date,
    insertion_order_name AS order_name,
    insertion_order_id AS order_id,
    UPPER(device_name) AS device,
    UPPER(advertiser_name) AS advertiser_name,
    UPPER(agency_name) AS agency_name,
    UPPER(aos_advertiser_name) AS aos_advertiser_name,
    UPPER(aos_agency_name) AS aos_agency_name,
    advertiser_id,
    business_unit,
    global_ad_unit_category AS ad_unit_format,
    third_party_line_item_id,
    placement_id AS line_item_or_placement_id,
    placement_name AS line_item_or_placement_name,
    UPPER(sales_channel_type) AS demand_type,
    placement_start_date AS line_item_or_placement_start_date,
    placement_end_date AS line_item_or_placement_end_date,
    SUM(delivered_impressions) AS delivered_impressions,
    SUM(delivered_revenue) AS delivered_revenue,
    0 AS video_completes,
    0 AS video_starts,
    SUM(delivered_clicks) AS delivered_clicks,
    SUM(on_target_net_delivered_impressions_quantity) AS freewheel_on_target_net_delivered_impressions,
    campaign_name_derived,
    owner_name AS account_manager,
    package_name,
    net_unit_cost,
    guaranteed_impressions,
    guaranteed_revenue,
    demo_comp::decimal(30,2) AS demo_comp,
    external_ad_id,
    parent_line_item_name,
    aos_deal_id,
    aos_deal_name,
    aos_deal_start_date,
    aos_deal_end_date,
    sales_order_line_item_name AS aos_deal_line_item_name,
    sales_order_line_item_id AS aos_deal_line_item_id,
    demo_band,
    billable_third_part_server AS billable_third_party_server,
    CASE
      WHEN regexp_substr(insertion_order_name, '^\\\d+[^-|_| ]*') IN (
        SELECT DISTINCT regexp_substr(order_name, '^\\\d+[^-|_| ]*')
        FROM fox_bi_qa.gold_ad_sales.ft_gam_campaign_delivery
      )
      THEN TRUE
      ELSE FALSE
    END AS multiple_ad_servers,
    regexp_substr(insertion_order_name, '^\\\d+[^-|_| ]*') AS multiple_ad_server_id,
    fw_audience_segment,
    fw_video_group,
    create_timestamp,
    modified_timestamp
  FROM fox_bi_qa.gold_ad_sales.ft_freewheel_campaign_delivery
  GROUP BY ALL
),
fw_third_party_metrics_base AS (
  SELECT
    creative_id,
    placement_id AS line_item_or_placement_id,
    global_ad_unit_position,
    event_date,
    third_party_line_item_id,
    MIN(third_party_video_completes) AS third_party_video_completes,
    MIN(third_party_video_views) AS third_party_video_views,
    MIN(third_party_billable_impressions) AS third_party_billable_impressions,
    MIN(third_party_clicks) AS third_party_clicks,
    MIN(third_party_revenue) AS third_party_revenue
  FROM fox_bi_qa.gold_ad_sales.ft_freewheel_campaign_delivery
  GROUP BY
    creative_id,
    global_ad_unit_position,
    event_date,
    placement_id,
    third_party_line_item_id
),
fw_third_party_metrics AS (
  SELECT
    line_item_or_placement_id,
    third_party_line_item_id,
    event_date,
    SUM(third_party_video_completes) AS third_party_video_completes,
    SUM(third_party_video_views) AS third_party_video_views,
    SUM(third_party_billable_impressions) AS third_party_billable_impressions,
    SUM(third_party_clicks) AS third_party_clicks,
    SUM(third_party_revenue) AS third_party_revenue
  FROM fw_third_party_metrics_base
  GROUP BY
    line_item_or_placement_id,
    third_party_line_item_id,
    event_date
),
final_fw AS (
  SELECT
    data_source,
    fw.event_date,
    campaign_id,
    campaign_name,
    campaign_start_date,
    campaign_end_date,
    order_name,
    order_id,
    device,
    advertiser_name,
    agency_name,
    aos_advertiser_name,
    aos_agency_name,
    advertiser_id,
    business_unit,
    ad_unit_format,
    fw.third_party_line_item_id,
    fw.line_item_or_placement_id,
    line_item_or_placement_name,
    demand_type,
    line_item_or_placement_start_date,
    line_item_or_placement_end_date,
    SUM(delivered_impressions) AS delivered_impressions,
    SUM(delivered_revenue) AS delivered_revenue,
    SUM(video_completes) AS video_completes,
    SUM(video_starts) AS video_starts,
    SUM(delivered_clicks) AS delivered_clicks,
    SUM(freewheel_on_target_net_delivered_impressions) AS freewheel_on_target_net_delivered_impressions,
    campaign_name_derived,
    account_manager,
    package_name,
    net_unit_cost,
    guaranteed_impressions,
    guaranteed_revenue,
    demo_comp::decimal(30,2) AS demo_comp,
    external_ad_id,
    parent_line_item_name,
    aos_deal_id,
    aos_deal_name,
    aos_deal_start_date,
    aos_deal_end_date,
    aos_deal_line_item_name,
    aos_deal_line_item_id,
    demo_band,
    billable_third_party_server,
    multiple_ad_servers,
    multiple_ad_server_id,
    fw_audience_segment,
    fw_video_group,
    MAX(third_party_video_completes) AS third_party_video_completes,
    MAX(third_party_video_views) AS third_party_video_views,
    MAX(third_party_billable_impressions) AS third_party_billable_impressions,
    MAX(third_party_clicks) AS third_party_clicks,
    MAX(third_party_revenue) AS third_party_revenue,
    create_timestamp,
    modified_timestamp
  FROM raw_fw_data fw
  LEFT JOIN fw_third_party_metrics fw_3p
    ON fw.line_item_or_placement_id = fw_3p.line_item_or_placement_id
    AND fw.event_date = fw_3p.event_date
    AND fw.third_party_line_item_id = fw_3p.third_party_line_item_id
  GROUP BY ALL
),
raw_gam_data AS (
  SELECT
    'GAM' AS data_source,
    event_date AS event_date,
    campaign_id AS campaign_id,
    campaign_name AS campaign_name,
    campaign_start_date AS campaign_start_date,
    campaign_end_date AS campaign_end_date,
    order_name AS order_name,
    order_id AS order_id,
    UPPER(device) AS device,
    advertiser_name AS advertiser_name,
    agency_name AS agency_name,
    advertiser_oms AS aos_advertiser_name,
    advertiser_id AS advertiser_id,
    business_unit AS business_unit,
    third_party_line_item_id AS third_party_line_item_id,
    line_item_id AS line_item_or_placement_id,
    line_item_name AS line_item_or_placement_name,
    line_item_type AS demand_type,
    line_item_start_date AS line_item_or_placement_start_date,
    line_item_end_date AS line_item_or_placement_end_date,
    delivered_impressions,
    delivered_revenue,
    video_completes AS video_completes,
    video_starts AS video_starts,
    delivered_clicks,
    NULL AS freewheel_on_target_net_delivered_impressions,
    aos_deal_id || '-' || aos_deal_name AS campaign_name_derived,
    account_manager AS account_manager,
    package_name AS package_name,
    net_unit_cost AS net_unit_cost,
    guaranteed_impressions AS guaranteed_impressions,
    guaranteed_revenue AS guaranteed_revenue,
    1 AS demo_comp,
    external_ad_id AS external_ad_id,
    parent_line_item_name AS parent_line_item_name,
    aos_deal_id AS aos_deal_id,
    aos_deal_name AS aos_deal_name,
    aos_deal_start_date AS aos_deal_start_date,
    aos_deal_end_date AS aos_deal_end_date,
    aos_deal_line_item_name AS aos_deal_line_item_name,
    aos_deal_line_item_id AS aos_deal_line_item_id,
    demo_band AS demo_band,
    billable_third_party_server AS billable_third_party_server,
    CASE
      WHEN regexp_substr(order_name, '^\\\d+[^-|_| ]*') IN (
        SELECT DISTINCT regexp_substr(insertion_order_name, '^\\\d+[^-|_| ]*')
        FROM fox_bi_qa.gold_ad_sales.ft_freewheel_campaign_delivery
      )
      THEN TRUE
      ELSE FALSE
    END AS multiple_ad_servers,
    regexp_substr(order_name, '^\\\d+[^-|_| ]*') AS multiple_ad_server_id,
    'N/A' AS fw_audience_segment,
    'N/A' AS fw_video_group,
    ad_unit_format,
    create_timestamp AS create_timestamp,
    modified_timestamp AS modified_timestamp
  FROM fox_bi_qa.gold_ad_sales.ft_gam_campaign_delivery
  -- WHERE line_item_id = '6811746476' AND event_date = '2025-09-01'
),
gam_third_party_metrics AS (
  SELECT
    line_item_id AS line_item_or_placement_id,
    third_party_line_item_id,
    event_date,
    MAX(third_party_video_completes) AS third_party_video_completes,
    MAX(third_party_video_views) AS third_party_video_views,
    MAX(third_party_billable_impressions) AS third_party_billable_impressions,
    MAX(third_party_clicks) AS third_party_clicks,
    MAX(third_party_revenue) AS third_party_revenue
  FROM fox_bi_qa.gold_ad_sales.ft_gam_campaign_delivery
  GROUP BY line_item_id, third_party_line_item_id, event_date
),
final_gam AS (
  SELECT
    data_source,
    raw_gam_data.event_date,
    campaign_id,
    campaign_name,
    campaign_start_date,
    campaign_end_date,
    order_name,
    order_id,
    device,
    UPPER(advertiser_name) AS advertiser_name,
    UPPER(agency_name) AS agency_name,
    UPPER(aos_advertiser_name) AS aos_advertiser_name,
    UPPER(agency_name) AS aos_agency_name,
    advertiser_id,
    business_unit,
    ad_unit_format,
    raw_gam_data.third_party_line_item_id,
    raw_gam_data.line_item_or_placement_id,
    line_item_or_placement_name,
    UPPER(demand_type) AS demand_type,
    line_item_or_placement_start_date,
    line_item_or_placement_end_date,
    SUM(delivered_impressions) AS delivered_impressions,
    SUM(delivered_revenue) AS delivered_revenue,
    SUM(video_completes) AS video_completes,
    SUM(video_starts) AS video_starts,
    SUM(delivered_clicks) AS delivered_clicks,
    SUM(freewheel_on_target_net_delivered_impressions) AS freewheel_on_target_net_delivered_impressions,
    campaign_name_derived,
    account_manager,
    package_name,
    net_unit_cost,
    guaranteed_impressions,
    guaranteed_revenue,
    demo_comp::decimal(30,2) AS demo_comp,
    external_ad_id,
    parent_line_item_name,
    aos_deal_id,
    aos_deal_name,
    aos_deal_start_date,
    aos_deal_end_date,
    aos_deal_line_item_name,
    aos_deal_line_item_id,
    demo_band,
    billable_third_party_server,
    multiple_ad_servers,
    multiple_ad_server_id,
    fw_audience_segment,
    fw_video_group,
    MIN(third_party_video_completes) AS third_party_video_completes,
    MIN(third_party_video_views) AS third_party_video_views,
    MIN(third_party_billable_impressions) AS third_party_billable_impressions,
    MIN(third_party_clicks) AS third_party_clicks,
    MIN(third_party_revenue) AS third_party_revenue,
    create_timestamp,
    modified_timestamp
  FROM raw_gam_data
  LEFT JOIN gam_third_party_metrics gam_3p
    ON raw_gam_data.line_item_or_placement_id = gam_3p.line_item_or_placement_id
    AND raw_gam_data.third_party_line_item_id = gam_3p.third_party_line_item_id
    AND raw_gam_data.event_date = gam_3p.event_date
  GROUP BY ALL
),
unified_data AS (
  SELECT * FROM final_gam
  UNION ALL
  SELECT * FROM final_fw
),
oms_data AS (
  SELECT
    'Non Ad Served' AS data_source,
    date::date AS event_date,
    oms.sales_order_id AS campaign_id,
    UPPER(oms.sales_order_name) AS campaign_name,
    oms.order_start_dt AS campaign_start_date,
    oms.order_end_dt AS campaign_end_date,
    UPPER(oms.sales_order_name) AS order_name,
    oms.sales_order_id AS order_id,
    'N/A' AS device,
    NVL(UPPER(oms.advertiser_name), 'N/A') AS advetiser_name,
    NVL(UPPER(oms.agency_name), 'N/A') AS agency_name,
    NVL(UPPER(oms.advertiser_name), 'N/A') AS aos_advertiser_name,
    NVL(UPPER(oms.agency_name), 'N/A') AS aos_agency_name,
    -1 AS advertiser_id,
    'N/A' AS business_unit,
    'N/A' AS ad_unit_format,
    -1 AS third_party_line_item_id,
    oms.sales_order_line_item_id AS line_item_or_placement_id,
    UPPER(oms.sales_order_line_item_name) AS line_item_or_placement_name,
    'N/A' AS demand_type,
    oms.sales_order_line_item_start_dt::date AS line_item_or_placement_start_date,
    oms.sales_order_line_item_end_dt::date AS line_item_or_placement_end_date,
    0::bigint AS delivered_impressions,
    0 AS delivered_revenue,
    0 AS video_completes,
    0 AS video_starts,
    0 AS delivered_clicks,
    0 AS freewheel_on_target_net_delivered_impressions,
    UPPER(oms.advertiser_name) || ' - ' || oms.order_start_dt || ' - ' || oms.order_end_dt AS campaign_name_derived,
    NVL(UPPER(oms.owner_name), 'N/A') AS account_manager,
    NVL(UPPER(oms.package_name), 'N/A') AS package_name,
    oms.net_unit_cost_amt AS net_unit_cost,
    oms.sales_order_line_items_qty AS guaranteed_impressions,
    oms.contracted_amount_net_lifetime AS guaranteed_revenue,
    1 AS demo_comp,
    oms.ps_line_item_id AS external_ad_id,
    NVL(UPPER(oms.parent_line_item_name), 'N/A') AS parent_line_item_name,
    oms.sales_order_id AS aos_deal_id,
    UPPER(oms.sales_order_name) AS aos_deal_name,
    oms.order_start_dt::date AS aos_deal_start_date,
    oms.order_end_dt::date AS aos_deal_end_date,
    UPPER(oms.sales_order_line_item_name) AS aos_deal_line_item_name,
    oms.sales_order_line_item_id AS aos_deal_line_item_id,
    oms.demo_band,
    oms.billable_third_party_descr AS billable_third_party_server,
    ad_servers.multiple_ad_servers,
    ad_servers.multiple_ad_server_id,
    UPPER(CASE WHEN oms.fw_audience_segment = '' THEN 'N/A' ELSE NVL(oms.fw_audience_segment, 'N/A') END) AS fw_audience_segment,
    UPPER(CASE WHEN oms.fw_video_group = '' THEN 'N/A' ELSE NVL(oms.fw_video_group, 'N/A') END) AS fw_video_group,
    0 AS third_party_video_completes,
    0 AS third_party_video_views,
    0 AS third_party_billable_impressions,
    0 AS third_party_clicks,
    0 AS third_party_revenue,
    create_timestamp_sli AS create_timestamp,
    update_timestamp_sli AS modified_timestamp
  FROM fox_bi_prod.gold_ad_sales.ft_digital_operative_line_date_allocation oms
  LEFT JOIN unified_data
    ON unified_data.external_ad_id = oms.ps_line_item_id
  LEFT JOIN (
    SELECT DISTINCT aos_deal_id, multiple_ad_servers, multiple_ad_server_id
    FROM unified_data
  ) ad_servers
    ON ad_servers.aos_deal_id = oms.sales_order_id
  WHERE 1 = 1
    AND unified_data.external_ad_id IS NULL
    AND sales_order_line_item_id NOT IN (
      SELECT DISTINCT parent_line_item_id
      FROM fox_bi_prod.gold_ad_sales.ft_digital_operative_line_date_allocation
      WHERE parent_line_item_id IS NOT NULL
    )
    AND oms.sales_order_id IN (
      SELECT DISTINCT aos_deal_id
      FROM unified_data
    )
    AND oms.sales_order_line_item_name NOT ILIKE '%cancelled%'
)
SELECT * FROM unified_data
UNION ALL
SELECT * FROM oms_data


"""


unified_campaign_delivery = spark.sql(query)

# COMMAND ----------

unified_campaign_delivery.write.format('delta')\
    .mode('overwrite')\
    .partitionBy('Campaign_ID')\
    .option('mergeSchema', 'true')\
    .option('overwriteDynamicPartitions', 'true')\
    .option('delta.enableDeletionVectors', 'false')\
    .option('delta.enableIcebergCompatV2', 'true')\
    .option('delta.universalFormat.enabledFormats', 'iceberg')\
    .option('delta.columnMapping.mode', 'name')\
    .saveAsTable('fox_bi_qa.gold_ad_sales.ft_unified_campaign_delivery')