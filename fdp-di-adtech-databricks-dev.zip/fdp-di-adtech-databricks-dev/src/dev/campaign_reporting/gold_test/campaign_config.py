# Databricks notebook source
catalog_dev = 'fox_bi_dev'
catalog_prod = 'fox_bi_prod'
catalog_qa = 'fox_bi_qa'
adsales_schema_gold = 'gold_ad_sales'
adsales_schema_silver = 'silver_ad_sales'
adtech_schema_gold = 'gold_ads'
adtech_schema_silver = 'silver_ads'