# Databricks notebook source
from datetime import datetime, timedelta

# COMMAND ----------

#date = dbutils.widgets.get('date')

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM fox_bi_qa.gold_ad_sales.ft_unified_campaign_delivery_by_deal
# MAGIC WHERE AOS_Deal_ID NOT IN (
# MAGIC     SELECT DISTINCT aos_deal_id
# MAGIC     FROM fox_bi_qa.gold_ad_sales.ft_unified_campaign_delivery
# MAGIC     where aos_deal_id IS NOT NULL
# MAGIC )

# COMMAND ----------

query = """
    with cte_gtd as (
    select `AOS_Deal_ID`, SUM(guar_imps) guar_imps, SUM(guar_rev) guar_rev from (
        select `AOS_Deal_ID`, `Line_Item_or_Placement_ID`, MAX(`Guaranteed_Impressions`) guar_imps, MAX(`Guaranteed_Revenue`) guar_rev
        from fox_bi_qa.gold_ad_sales.ft_unified_campaign_delivery group by 1,2
    )
    group by 1

)
, cte_plc_cnt as (
    select `AOS_Deal_ID`
		,COUNT(DISTINCT line_item_or_placement_id) as total_placements
		from fox_bi_qa.gold_ad_sales.ft_unified_campaign_delivery group by 1
    )
, cte_creative_count as
(
    select AOS_Deal_ID, COUNT(DISTINCT creative_id) as total_creatives
    from fox_bi_qa.gold_ad_sales.ft_freewheel_campaign_delivery group by 1
)
, cte_del_rev as (
    select `AOS_Deal_ID`, SUM(total_revenue_view) delivered_revenue from (
        select `AOS_Deal_ID`, `Line_Item_or_Placement_ID`, `Data_Source`, `Demand_Type`, MAX(`Guaranteed_Impressions`) guar_imps, MAX(`Guaranteed_Revenue`) guar_rev, max(net_unit_cost) max_net_unit_cost,
        case
            when `Data_Source` = 'GAM' then 
                CASE
                    WHEN `Demand_Type` = 'SPONSORSHIP' THEN `guar_rev`
                    ELSE (sum(`Delivered_Impressions`) * `max_net_unit_cost`)/1000
                END 
            else sum(`Delivered_Revenue`)
        end AS total_revenue_view
        from fox_bi_qa.gold_ad_sales.ft_unified_campaign_delivery group by all
    )
    group by 1
)
, fw_video_program_names as (
    select 
            `AOS_Deal_ID` aos_deal_id,
            COLLECT_SET(
                CASE 
                    WHEN `show_Name` != 'N/A' AND UPPER(`show_Name`) != 'UNKNOWN' THEN `show_Name`
                END
            ) as `show_names`,
            count(DISTINCT show_name) total_shows
        from fox_bi_qa.gold_ad_sales.ft_freewheel_campaign_delivery
        group by 1
)

, fw_third_party_metrics as (
    SELECT
         aos_deal_id
        ,SUM(third_party_impressions) third_party_impressions
        ,SUM(third_party_revenue) third_party_revenue
        from (
                SELECT
                `AOS_Deal_ID` as aos_deal_id,
                `Placement_ID` as placement_id,
                `Creative_ID` as creative_id,
                `Event_Date` as event_date,
                global_ad_unit_position as ad_unit_position,
                MAX(`Third_Party_Billable_Impressions`) as third_party_impressions,
                MAX(`Third_Party_Revenue`) as third_party_revenue
            FROM fox_bi_qa.gold_ad_sales.ft_freewheel_campaign_delivery
            GROUP BY
                `AOS_Deal_ID`,
                `Placement_ID`,
                `Creative_ID`,
                `Event_Date`,
                global_ad_unit_position
        ) group by aos_deal_id
)

, gam_third_party_revenue as (
    select AOS_Deal_ID, sum(Third_Party_Revenue) Third_Party_Revenue from (
    SELECT
            `AOS_Deal_ID`,
            `Line_Item_ID`,
            `Event_Date`,
            CASE WHEN `Third_Party_Line_Item_ID` IS NOT NULL AND SUM(`Third_Party_Billable_Impressions`) > 0 
            THEN MAX(Guaranteed_Revenue)/COUNT(
                         CASE 
                             WHEN `Third_Party_Line_Item_ID` IS NOT NULL and SUM(`Third_Party_Billable_Impressions`) > 0 
                             THEN `Event_Date` 
                         END
                     ) OVER (PARTITION BY `Line_Item_ID`)
            ELSE 0 END AS Third_Party_Revenue
        FROM fox_bi_qa.gold_ad_sales.ft_gam_campaign_delivery where `Line_Item_Type` = 'SPONSORSHIP'
        GROUP BY `AOS_Deal_ID`, `Line_Item_ID`, `Event_Date`, `Third_Party_Line_Item_ID`

        union

        SELECT
            `AOS_Deal_ID`,
            `Line_Item_ID`,
            `Event_Date`,
            CASE WHEN `Third_Party_Line_Item_ID` IS NOT NULL AND SUM(`Third_Party_Billable_Impressions`) > 0  THEN (MAX(`Third_Party_Billable_Impressions`) * MAX(net_unit_cost))/1000 ELSE 0 END AS third_party_revenue
        FROM fox_bi_qa.gold_ad_sales.ft_gam_campaign_delivery where `Line_Item_Type` != 'SPONSORSHIP' 
        GROUP BY `AOS_Deal_ID`, `Line_Item_ID`, `Event_Date`,`Third_Party_Line_Item_ID`
    ) group by aos_deal_id
)

, gam_third_party_impressions as (
    select AOS_Deal_ID, sum(third_party_impressions) third_party_impressions from (
        SELECT
            `AOS_Deal_ID`,
            `Line_Item_ID`,
            MAX(`Third_Party_Billable_Impressions`) as third_party_impressions
        FROM fox_bi_qa.gold_ad_sales.ft_gam_campaign_delivery
        GROUP BY `AOS_Deal_ID`, `Line_Item_ID`, `Event_Date`
    )
    group by aos_deal_id
)
, unified_third_party_metrics AS (
    SELECT
         aos_deal_id
        ,SUM(third_party_impressions) third_party_impressions
        ,SUM(third_party_revenue) third_party_revenue
    FROM
        (
        SELECT * from fw_third_party_metrics

        UNION ALL

        SELECT t1.AOS_Deal_ID, third_party_impressions, third_party_revenue from gam_third_party_revenue t1 left join gam_third_party_impressions t2 on t1.aos_deal_id=t2.aos_deal_id
    )
    GROUP BY aos_deal_id
)

-- , unified_third_party_metrics AS (
--     SELECT
--          aos_deal_id
--         ,SUM(third_party_impressions) third_party_impressions
--         ,SUM(third_party_revenue) third_party_revenue
--     FROM
--         (
--         SELECT
--             `AOS_Deal_ID` as aos_deal_id,
--             `Creative_ID` as creative_id,
--             `Event_Date` as event_date,
--             global_ad_unit_position as ad_unit_position,
--             MAX(`Third_Party_Billable_Impressions`) as third_party_impressions,
--             MAX(`Third_Party_Revenue`) as third_party_revenue
--         FROM fox_bi_qa.gold_ad_sales.ft_freewheel_campaign_delivery
--         GROUP BY
--             `AOS_Deal_ID`,
--             `Creative_ID`,
--             `Event_Date`,
--             global_ad_unit_position
-- 
--         UNION ALL
-- 
--         SELECT
--             `AOS_Deal_ID`,
--             `Line_Item_ID`,
--             `Event_Date`,
--             NULL as ad_unit_position, -- confirm with Prajwal
--             MAX(`Third_Party_Billable_Impressions`) as third_party_impressions,
--             CASE
--                 WHEN `Line_Item_Type` = 'SPONSORSHIP' THEN MAX(Guaranteed_Revenue)
--                 ELSE (MAX(`Third_Party_Billable_Impressions`) * MAX(net_unit_cost))/1000
--             END AS third_party_revenue
--         FROM fox_bi_qa.gold_ad_sales.ft_gam_campaign_delivery
--         GROUP BY `AOS_Deal_ID`, `Line_Item_ID`, `Event_Date`, `Line_Item_Type`
--     )
--     GROUP BY aos_deal_id
-- )

, unified_geo as (
    select 
		aos_deal_id
		,COUNT(DISTINCT Country_Name) AS total_countries
		,COUNT(DISTINCT State_Province_Name) AS total_states
		,SUM(Delivered_Impressions) AS total_geo_ads
	from 
		fox_bi_qa.gold_ad_sales.ft_unified_campaign_geo_delivery
			where Country_Name != 'N/A' and State_Province_Name != 'N/A'
	group by aos_deal_id
)

select
  base.`AOS_Deal_ID`,
  base.`AOS_Deal_Name`,
  `AOS_Deal_Start_Date`,
  `AOS_Deal_End_Date`,
  `AOS_Advertiser_Name` as `Advertiser_Name`,
  COLLECT_SET(
    CASE 
        WHEN `Demo_Band` != 'N/A' AND UPPER(`Demo_Band`) != 'UNKNOWN' THEN `Demo_Band`
    END
  ) as `Targeted_Demos`,
  AOS_agency_name `Agency_Name`,
  COLLECT_SET(
    CASE 
        WHEN `Demand_Type` != 'N/A' AND UPPER(`Demand_Type`) != 'UNKNOWN' THEN `Demand_Type`
    END
  ) as `Sales_Channels`,
  show_names as `Show_Names`,
  `Multiple_Ad_Servers` as `Multiple_Ad_Servers_Flag`,
  gtd.guar_rev as Budget,
  CASE
    WHEN third_party.third_party_revenue IS NOT NULL AND third_party.third_party_revenue > 0
    THEN third_party.third_party_revenue
    ELSE rev.delivered_revenue
  END as Spend,
  case
    when ((rev.delivered_revenue / guar_rev) * 100) > 100 then ''
    when ((rev.delivered_revenue / guar_rev) * 100) = 100 then ''
    when ((rev.delivered_revenue / guar_rev) * 100) < 100 then ''
    else 'N/A'
  end AS `Overall_Performance`,
  COLLECT_SET(
  	case
		when UPPER(`Device`) != 'N/A' then UPPER(`Device`)
	end
  ) AS `Targeted_Devices`,
--   ROUND(((rev.delivered_revenue)/SUM(`Delivered_Impressions`) * 1000), 2)::decimal(5,2) as CPM,
  case
    when rev.delivered_revenue is not null and rev.delivered_revenue > 0 and SUM(`Delivered_Impressions`) is not null and SUM(`Delivered_Impressions`) > 0
        then ROUND(((rev.delivered_revenue)/SUM(`Delivered_Impressions`) * 1000), 2)::decimal(5,2)
    else
        null
  end as First_Party_CPM,
  case
    when third_party.third_party_revenue is not null and third_party.third_party_revenue > 0 and third_party.third_party_impressions is not null and third_party.third_party_impressions > 0
        then ROUND(((third_party.third_party_revenue)/third_party.third_party_impressions * 1000), 2)::decimal(5,2) 
    else null
  end as Third_Party_CPM,
  case
    when Third_Party_CPM is not null and Third_Party_CPM > 0 then Third_Party_CPM
    else First_Party_CPM
  end as CPM,
  ROUND((SUM(`Delivered_Clicks`)/SUM(`Delivered_Impressions`) * 100), 2)::decimal(5,2) as CTR,
  SUM(`Video_Starts`) as `Total_Views`,
  SUM(`Delivered_Clicks`) as `Total_Delivered_Clicks`,
  rev.delivered_revenue as `Total_First_Party_Delivered_Revenue`,
  third_party.third_party_revenue as `Total_Third_Party_Revenue`,
  CASE
    WHEN `Total_Third_Party_Revenue` IS NOT NULL AND `Total_Third_Party_Revenue` > 0
    THEN `Total_Third_Party_Revenue`
    ELSE `Total_First_Party_Delivered_Revenue`
  END as `Total_Delivered_Revenue`,
  (SUM(`Delivered_Impressions`) / gtd.guar_imps) * 100 as `First_Party_Impression_Pacing`,
  (third_party_impressions / gtd.guar_imps) * 100 as `Third_Party_Impression_Pacing`,
 case 
  when `Third_Party_Impression_Pacing` is not null and `Third_Party_Impression_Pacing` > 0
  then `Third_Party_Impression_Pacing`
  else `First_Party_Impression_Pacing`
  end as `Impression_Pacing`,
  (rev.delivered_revenue / guar_rev) * 100 as `First_Party_Revenue_Pacing`,
  (third_party.third_party_revenue / gtd.guar_rev) * 100 as `Third_Party_Revenue_Pacing`,
  CASE
    WHEN `Third_Party_Revenue_Pacing` IS NOT NULL AND `Third_Party_Revenue_Pacing` > 0
    THEN `Third_Party_Revenue_Pacing`
    ELSE `First_Party_Revenue_Pacing`
   END as revenue_pacing,
  gtd.guar_imps as `Total_Guaranteed_Impressions`,
  SUM(`Delivered_Impressions`) as `Total_First_Party_Delivered_Impressions`,
  third_party.third_party_impressions as `Total_Third_Party_Impressions`,
  case 
    when `Total_Third_Party_Impressions` is not null and `Total_Third_Party_Impressions` > 0 
    then `Total_Third_Party_Impressions`
    else `Total_First_Party_Delivered_Impressions`
  end as `Total_Delivered_Impressions`,
  MAX(`Create_Timestamp`) as `Create_Timestamp`,
  MAX(`Modified_Timestamp`) as `Modified_Timestamp`,
  ---------------------------------------------------------------------------
  array_distinct(
        flatten(
            collect_list(
                filter(
                    transform(split(fw_audience_segment, ','), x -> trim(x)),
                    x -> x NOT IN ('N/A', 'UNKNOWN')
                )
            )
        )
  ) AS FW_Audience_Segment,
  ---------------------------------------------------------------------------
  array_distinct(
        flatten(
            collect_list(
                filter(
                    transform(split(FW_Video_Group, ','), x -> trim(x)),
                    x -> x NOT IN ('N/A', 'UNKNOWN')
                )
            )
        )
  ) AS FW_Video_Group,
  ---------------------------------------------------------------------------
  nvl(total_creatives, 0) as `Total_Creatives`,
  nvl(total_placements, 0) as `Total_Placements`,
  nvl(total_shows ,0) as `Total_Shows`,
  nvl(geo.total_countries, 0) as `Total_Countries`,
  nvl(geo.total_states, 0) as `Total_States`,
  nvl(geo.total_geo_ads, 0) as `Total_Geo_Ads`
from
  fox_bi_qa.gold_ad_sales.ft_unified_campaign_delivery base 
left join 
    cte_gtd gtd on base.`AOS_Deal_ID`=gtd.`aos_deal_id`
left join 
    cte_del_rev rev on base.`AOS_Deal_ID`=rev.`aos_deal_id`
left join
    fw_video_program_names show_name on base.`AOS_Deal_ID`=show_name.aos_deal_id
left join 
    unified_third_party_metrics third_party on base.`AOS_Deal_ID`=third_party.aos_deal_id
left join 
	 cte_plc_cnt plc_cnt on base.AOS_Deal_ID = plc_cnt.AOS_Deal_ID
left join 
	 cte_creative_count cr_cnt on base.AOS_Deal_ID = cr_cnt.AOS_Deal_ID
left join
	 unified_geo geo on base.AOS_Deal_ID = geo.AOS_Deal_ID
  group by 
    base.`AOS_Deal_ID`,
    base.`AOS_Deal_Name`,
    `AOS_Deal_Start_Date`,
    `AOS_Deal_End_Date`,
    `AOS_Advertiser_Name`,
    AOS_agency_name ,
    show_names,
    `Multiple_Ad_Servers`,
    gtd.guar_rev,
    rev.delivered_revenue,
    third_party.third_party_revenue,
    third_party_impressions,
    guar_imps,
    total_creatives,
    total_placements,
    total_shows,
    total_countries,
    total_states,
    total_geo_ads
"""

# if datetime.strptime(date, '%Y-%m-%d').day < 5:
#     date = (datetime.strptime(date, '%Y-%m-%d') - timedelta(days=5)).replace(day=1).strftime('%Y-%m-%d')
# else:
#     date = datetime.strptime(date, '%Y-%m-%d').replace(day=1).strftime('%Y-%m-%d')

fw_campaign_pacing = spark.sql(query)

# COMMAND ----------

if not spark.catalog.tableExists(f'fox_bi_qa.gold_ad_sales.ft_unified_campaign_delivery_by_deal'): #Add the table name for First time load
    fw_campaign_pacing.write.format('delta') \
        .mode('overwrite') \
        .partitionBy('AOS_Deal_ID') \
        .option('mergeSchema', 'true') \
        .option('overwriteDynamicPartitions', 'true') \
        .option('delta.enableDeletionVectors', 'false') \
        .option('delta.enableIcebergCompatV2', 'true') \
        .option('delta.universalFormat.enabledFormats', 'iceberg') \
        .option('delta.columnMapping.mode', 'name') \
        .saveAsTable('fox_bi_qa.gold_ad_sales.ft_unified_campaign_delivery_by_deal')
else:
    fw_campaign_pacing.write.format('delta') \
        .mode('overwrite') \
        .option('partitionOverwriteMode', 'dynamic') \
        .saveAsTable('fox_bi_qa.gold_ad_sales.ft_unified_campaign_delivery_by_deal')