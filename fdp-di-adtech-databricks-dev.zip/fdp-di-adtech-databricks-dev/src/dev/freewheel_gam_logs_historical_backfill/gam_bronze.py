# Databricks notebook source
event_start_date=dbutils.widgets.get("event_start_date") 
event_end_date=dbutils.widgets.get("event_end_date")

# COMMAND ----------

base_path=f"/mnt/fox-fdp-bi-dev/adtech/news_gam"

# COMMAND ----------

# MAGIC %md
# MAGIC GAM NETWORK REQUESTS

# COMMAND ----------

print(f"Running from {event_start_date} to {event_end_date}")

# COMMAND ----------

target_table="fox_bi_dev.bronze_ads.news_gam_network_requests"
key_column="event_date"

# COMMAND ----------

from datetime import datetime, timedelta

# COMMAND ----------

from pyspark.sql.functions import *


# Convert strings to datetime objects
start = datetime.strptime(event_start_date, "%Y-%m-%d")
end = datetime.strptime(event_end_date, "%Y-%m-%d")


# Generate list of date strings in the required format
date_list = [(start + timedelta(days=i)).strftime("%Y-%m-%d") 
             for i in range((end - start).days + 1)]

print(date_list)

# Initialize with the first day's DataFrame
df_source = spark.read.parquet(
    f"{base_path}/network_requests/dt={date_list[0]}/"
).withColumn("eventdate", lit(date_list[0]))

# Union the rest
for date_str in date_list[1:]:
    df_next = spark.read.parquet(
        f"{base_path}/network_requests/dt={date_str}/"
    ).withColumn("eventdate", lit(date_str))
    df_source = df_source.unionByName(df_next)

# COMMAND ----------

df_source = df_source.withColumnRenamed("time","Time")
df_source = df_source.withColumnRenamed("hour",'eventhour')

# COMMAND ----------

df_transformed = df_source.selectExpr(
    "cast(eventdate as date) as event_date",
    "CAST(IsFilledRequest AS BOOLEAN) AS is_filled_request",
    "CAST(IsVideoFallbackRequest AS BOOLEAN) AS is_video_fallback_request",
    "InventoryShareAssignmentId AS inventory_share_assignment_id",
    "InventoryShareAssignmentName AS inventory_share_assignment_name",
    "InventoryShareOutcome AS inventory_share_outcome",
    "ServingRestriction AS serving_restriction",
    "CmsMetadata AS cms_metadata",
    "Time AS event_time",
    "UserId AS user_id",
    "CAST(AdUnitId AS BIGINT) AS ad_unit_id",
    "CustomTargeting AS custom_targeting",
    "Country AS country",
    "Region AS region",
    "OS AS os",
    "Browser AS browser",
    "Domain AS domain",
    "City AS city",
    "Metro AS metro",
    "PostalCode AS postal_code",
    "BandWidth AS bandwidth",
    "CAST(TimeUsec AS BIGINT) AS timeusec",
    "CAST(BrowserId AS BIGINT) AS browser_id",
    "CAST(CountryId AS BIGINT) AS country_id",
    "CAST(OSId AS BIGINT) AS os_id",
    "CAST(RegionId AS BIGINT) AS region_id",
    "CAST(CityId AS BIGINT) AS city_id",
    "CAST(MetroId AS BIGINT) AS metro_id",
    "CAST(BandwidthId AS BIGINT) AS bandwidth_id",
    "CAST(PostalCodeId AS BIGINT) AS postal_code_id",
    "CAST(GfpContentId AS BIGINT) AS gfp_content_id",
    "CAST(IsInterstitial AS BOOLEAN) AS is_interstitial",
    "DeviceCategory AS device_category",
    "KeyPart AS keypart",
    "CAST(TimeUsec2 AS BIGINT) AS timeusec2",
    "CAST(PodPosition AS bigint) AS pod_position",
    "CAST(IsCompanion AS BOOLEAN) AS is_companion",
    "CAST(VideoPosition AS BIGINT) AS video_position",
    "PublisherProvidedID AS publisher_provided_id",
    "CAST(BandwidthGroupId AS BIGINT) AS bandwidth_group_id",
    "MobileCarrier AS mobile_carrier",
    "MobileCapability AS mobile_capability",
    "RequestedAdUnitSizes AS requested_ad_unit_sizes",
    "MobileDevice AS mobile_device",
    "OSVersion AS os_version",
    "AudienceSegmentIds AS audience_segment_ids",
    "CAST(Anonymous AS BOOLEAN) AS anonymous",
    "RequestLanguage AS request_language",
    "MobileAppId AS mobile_app_id",
    "RefererURL AS referer_url",
    "cast(NULL as string) AS att_consent_status",
    "cast(NULL as string) AS backfill_keypart",
    "cast(NULL as string) AS custom_spot_subpod_ids",
    "CAST(NULL AS BIGINT) AS max_ads_in_optimized_pod",
    "CAST(NULL AS BIGINT) AS optimized_pods_filled_duration_seconds",
    "CAST(NULL AS BIGINT) AS optimized_pods_unfilled_duration_seconds",
    "CAST(NULL AS STRING) AS ppid_presence",
    "CAST(NULL AS STRING) processing_date_and_hour",
    "CAST(NULL AS STRING) publisher_provided_signals",
    "CAST(NULL AS STRING) AS user_identifier_status",
    "CURRENT_TIMESTAMP() as etl_created_at_timestamp_utc",
    "CURRENT_TIMESTAMP() as etl_updated_at_timestamp_utc",
    "eventhour as event_hour"
)

# COMMAND ----------

print(f"""
    DELETE FROM {target_table}
    WHERE {key_column} >= DATE('{event_start_date}')
      AND {key_column} <= DATE('{event_end_date}')
    """)



spark.sql(
    f"""
    DELETE FROM {target_table}
    WHERE {key_column} >= DATE('{event_start_date}')
      AND {key_column} <= DATE('{event_end_date}')
    """
);

# COMMAND ----------

(
    df_transformed.write
    .mode("append")  # Or "append" if you're not replacing existing partitions
    .saveAsTable(f"{target_table}")
)

# COMMAND ----------

# MAGIC %md
# MAGIC NETWORK BACKFILL REQUESTS

# COMMAND ----------

target_table="fox_bi_dev.bronze_ads.news_gam_network_backfill_requests"
key_column="event_date"

# COMMAND ----------

from pyspark.sql.functions import *


# Convert strings to datetime objects
start = datetime.strptime(event_start_date, "%Y-%m-%d")
end = datetime.strptime(event_end_date, "%Y-%m-%d")


# Generate list of date strings in the required format
date_list = [(start + timedelta(days=i)).strftime("%Y-%m-%d") 
             for i in range((end - start).days + 1)]

print(date_list)

# Initialize with the first day's DataFrame
df_source = spark.read.parquet(
    f"{base_path}/network_backfill_requests/dt={date_list[0]}/"
).withColumn("eventdate", lit(date_list[0]))

# Union the rest
for date_str in date_list[1:]:
    df_next = spark.read.parquet(
        f"{base_path}/network_backfill_requests/dt={date_str}/"
    ).withColumn("eventdate", lit(date_str))
    df_source = df_source.unionByName(df_next)

# COMMAND ----------

df_source = df_source.withColumnRenamed("time","Time")
df_source = df_source.withColumnRenamed("hour",'eventhour')

# COMMAND ----------

df_transformed = df_source.selectExpr(
    "cast(eventdate as date) as event_date",
    "CAST(IsFilledRequest AS BOOLEAN) AS is_filled_request",
    "CAST(IsVideoFallbackRequest AS BOOLEAN) AS is_video_fallback_request",
    "InventoryShareAssignmentId AS inventory_share_assignment_id",
    "InventoryShareAssignmentName AS inventory_share_assignment_name",
    "InventoryShareOutcome AS inventory_share_outcome",
    "ServingRestriction AS serving_restriction",
    "CmsMetadata AS cms_metadata",
    "Time AS event_time",
    "UserId AS user_id",
    "CAST(AdUnitId AS BIGINT) AS ad_unit_id",
    "CustomTargeting AS custom_targeting",
    "Country AS country",
    "Region AS region",
    "OS AS os",
    "Browser AS browser",
    "Domain AS domain",
    "City AS city",
    "Metro AS metro",
    "PostalCode AS postal_code",
    "BandWidth AS bandwidth",
    "CAST(TimeUsec AS BIGINT) AS timeusec",
    "CAST(BrowserId AS BIGINT) AS browser_id",
    "CAST(CountryId AS BIGINT) AS country_id",
    "CAST(OSId AS BIGINT) AS os_id",
    "CAST(RegionId AS BIGINT) AS region_id",
    "CAST(CityId AS BIGINT) AS city_id",
    "CAST(MetroId AS BIGINT) AS metro_id",
    "CAST(BandwidthId AS BIGINT) AS bandwidth_id",
    "CAST(PostalCodeId AS BIGINT) AS postal_code_id",
    "CAST(GfpContentId AS BIGINT) AS gfp_content_id",
    "CAST(IsInterstitial AS BOOLEAN) AS is_interstitial",
    "DeviceCategory AS device_category",
    "KeyPart AS keypart",
    "CAST(TimeUsec2 AS BIGINT) AS timeusec2",
    "CAST(PodPosition AS bigint) AS pod_position",
    "CAST(IsCompanion AS BOOLEAN) AS is_companion",
    "CAST(VideoPosition AS BIGINT) AS video_position",
    "PublisherProvidedID AS publisher_provided_id",
    "CAST(BandwidthGroupId AS BIGINT) AS bandwidth_group_id",
    "MobileCarrier AS mobile_carrier",
    "MobileCapability AS mobile_capability",
    "RequestedAdUnitSizes AS requested_ad_unit_sizes",
    "MobileDevice AS mobile_device",
    "OSVersion AS os_version",
    "AudienceSegmentIds AS audience_segment_ids",
    "CAST(Anonymous AS BOOLEAN) AS anonymous",
    "RequestLanguage AS request_language",
    "MobileAppId AS mobile_app_id",
    "RefererURL AS referer_url",
    "cast(NULL as string) AS att_consent_status",
    "cast(NULL as string) AS backfill_keypart",
    "cast(NULL as string) AS custom_spot_subpod_ids",
    "CAST(NULL AS BIGINT) AS max_ads_in_optimized_pod",
    "CAST(NULL AS BIGINT) AS optimized_pods_filled_duration_seconds",
    "CAST(NULL AS BIGINT) AS optimized_pods_unfilled_duration_seconds",
    "CAST(NULL AS STRING) AS ppid_presence",
    "CAST(NULL AS STRING) processing_date_and_hour",
    "CAST(NULL AS STRING) publisher_provided_signals",
    "CAST(NULL AS STRING) AS user_identifier_status",
    "CURRENT_TIMESTAMP() as etl_created_at_timestamp_utc",
    "CURRENT_TIMESTAMP() as etl_updated_at_timestamp_utc",
    "eventhour as event_hour"
)

# COMMAND ----------

print(f"""
    DELETE FROM {target_table}
    WHERE {key_column} >= DATE('{event_start_date}')
      AND {key_column} <= DATE('{event_end_date}')
    """)


spark.sql(
    f"""
    DELETE FROM {target_table}
    WHERE {key_column} >= DATE('{event_start_date}')
      AND {key_column} <= DATE('{event_end_date}')
    """
);

# COMMAND ----------

(
    df_transformed.write
    .mode("append")  # Or "append" if you're not replacing existing partitions
    .saveAsTable(f"{target_table}")
)

# COMMAND ----------

# MAGIC %md
# MAGIC NETWORK CODE SERVES

# COMMAND ----------

target_table="fox_bi_dev.bronze_ads.news_gam_network_code_serves"
key_column="event_date"

# COMMAND ----------

from pyspark.sql.functions import *

# Convert strings to datetime objects
start = datetime.strptime(event_start_date, "%Y-%m-%d")
end = datetime.strptime(event_end_date, "%Y-%m-%d")


# Generate list of date strings in the required format
date_list = [(start + timedelta(days=i)).strftime("%Y-%m-%d") 
             for i in range((end - start).days + 1)]

print(date_list)

# Initialize with the first day's DataFrame
df_source = spark.read.parquet(
    f"{base_path}/network_code_serves/dt={date_list[0]}/"
).withColumn("eventdate", lit(date_list[0]))

# Union the rest
for date_str in date_list[1:]:
    df_next = spark.read.parquet(
        f"{base_path}/network_code_serves/dt={date_str}/"
    ).withColumn("eventdate", lit(date_str))
    df_source = df_source.unionByName(df_next)

# COMMAND ----------

df_source = df_source.withColumnRenamed("time","Time")
df_source = df_source.withColumnRenamed("hour",'eventhour')

# COMMAND ----------

df_transformed = df_source.selectExpr(
    "cast(EventDate as date) as event_date",
    "InventoryShareAssignmentId as inventory_share_assignment_id",
    "InventoryShareOutcome as inventory_share_outcome",
    "ServingRestriction as serving_restriction",
    "CmsMetadata as cms_metadata",
    "NativeFormat as native_format",
    "NativeStyle as native_style",
    "Time as event_time",
    "UserId as user_id",
    "IP as ip",
    "AdvertiserId as advertiser_id",
    "cast(OrderId as bigint) as order_id",
    "cast(LineItemId as bigint) as line_item_id",
    "InventoryShareAssignmentName as inventory_share_assignment_name",
    "cast(CreativeId as bigint) as creative_id",
    "cast(CreativeVersion as bigint) as creative_version",
    "CreativeSize as creative_size",
    "CustomTargeting as custom_targeting",
    "cast(AdUnitId as bigint) as ad_unit_id",
    "Country as country",
    "Browser as browser",
    "Region as region",
    "OS as os",
    "Domain as domain",
    "Metro as metro",
    "City as city",
    "PostalCode as postal_code",
    "BandWidth as bandwidth",
    "cast(TimeUsec as bigint) as timeusec",
    "cast(GfpContentId as bigint) as gfp_content_id",
    "cast(OSId as bigint) as os_id",
    "cast(BrowserId as bigint) as browser_id",
    "cast(CountryId as bigint) as country_id",
    "cast(RegionId as bigint) as region_id",
    "cast(CityId as bigint) as city_id",
    "cast(MetroId as bigint) as metro_id",
    "cast(PostalCodeId as bigint) as postal_code_id",
    "cast(BandwidthId as bigint) as bandwidth_id",
    "AudienceSegmentIds as audience_segment_ids",
    "RequestedAdUnitSizes as requested_ad_unit_sizes",
    "MobileDevice as mobile_device",
    "OSVersion as os_version",
    "MobileCapability as mobile_capability",
    "cast(BandwidthGroupId as bigint) as bandwidth_group_id",
    "MobileCarrier as mobile_carrier",
    "Product as product",
    "PublisherProvidedID as publisher_provided_id",
    "cast(IsCompanion as boolean) as is_companion",
    "cast(VideoPosition as bigint) as video_position",
    "cast(PodPosition as bigint) as pod_position",
    "cast(VideoFallbackPosition as bigint) as video_fallback_position",
    "TargetedCustomCriteria as targeted_custom_criteria",
    "KeyPart as keypart",
    "cast(TimeUsec2 as bigint) as timeusec2",
    "DeviceCategory as device_category",
    "cast(IsInterstitial as boolean) as is_interstitial",
    "ActiveViewEligibleImpression as active_view_eligible_impression",
    "EventKeyPart as event_keypart",
    "cast(EventTimeUsec2 as bigint) as event_timeusec2",
    "RefererURL as referer_url",
    "cast(EstimatedBackfillRevenue as double) as estimated_backfill_revenue",
    "YieldGroupNames as yield_group_names",
    "cast(YieldGroupCompanyId as bigint) as yield_group_company_id",
    "MobileAppId as mobile_app_id",
    "RequestLanguage as request_language",
    "DealId as deal_id",
    "DealType as deal_type",
    "cast(AdxAccountId as bigint) as adx_account_id",
    "OptimizationType as optimization_type",
    "CreativeSizeDelivered as creative_size_delivered",
    "cast(Anonymous as boolean) as anonymous",
    "Advertiser as advertiser",
    "cast(SellerReservePrice as double) as seller_reserve_price",
    "Buyer as buyer",
    "ImpressionId as impression_id",
    "CAST(NULL AS STRING) as att_consent_status",
    "CAST(NULL AS STRING) as backfill_keypart",
    "cast(NULL as bigint) as custom_spot_subpod_ids",
    "cast(NULL as string) ppid_presence",
    "cast(NULL as string) as processing_date_and_hour",
    "cast(NULL as boolean) as protected_audience_api_delivery",
    "cast(NULL as string) as publisher_provided_signals",
    "cast(NULL as string) as user_identifier_status",
    "cast(NULL as string) as yield_partner_tag",
    "CURRENT_TIMESTAMP() as etl_created_at_timestamp_utc",
    "CURRENT_TIMESTAMP() as etl_updated_at_timestamp_utc",
    "EventHour as event_hour"
)

# COMMAND ----------

print(f"""
    DELETE FROM {target_table}
    WHERE {key_column} >= DATE('{event_start_date}')
      AND {key_column} <= DATE('{event_end_date}')
    """)


spark.sql(
    f"""
    DELETE FROM {target_table}
    WHERE {key_column} >= DATE('{event_start_date}')
      AND {key_column} <= DATE('{event_end_date}')
    """
);

# COMMAND ----------

(
    df_transformed.write
    .mode("append")  # Or "append" if you're not replacing existing partitions
    .saveAsTable(f"{target_table}")
)

# COMMAND ----------

# MAGIC %md
# MAGIC NETWORK BACKFILL CODE SERVES

# COMMAND ----------

target_table="fox_bi_dev.bronze_ads.news_gam_network_backfill_code_serves"
key_column="event_date"

# COMMAND ----------

from pyspark.sql.functions import *


# Convert strings to datetime objects
start = datetime.strptime(event_start_date, "%Y-%m-%d")
end = datetime.strptime(event_end_date, "%Y-%m-%d")


# Generate list of date strings in the required format
date_list = [(start + timedelta(days=i)).strftime("%Y-%m-%d") 
             for i in range((end - start).days + 1)]

print(date_list)

# Initialize with the first day's DataFrame
df_source = spark.read.parquet(
    f"{base_path}/network_backfill_code_serves/dt={date_list[0]}/"
).withColumn("eventdate", lit(date_list[0]))

# Union the rest
for date_str in date_list[1:]:
    df_next = spark.read.parquet(
        f"{base_path}/network_backfill_code_serves/dt={date_str}/"
    ).withColumn("eventdate", lit(date_str))
    df_source = df_source.unionByName(df_next)

# COMMAND ----------

df_source = df_source.withColumnRenamed("time","Time")
df_source = df_source.withColumnRenamed("hour",'eventhour')

# COMMAND ----------

df_transformed = df_source.selectExpr(
    "cast(EventDate as date) as event_date",
    "InventoryShareAssignmentId as inventory_share_assignment_id",
    "InventoryShareOutcome as inventory_share_outcome",
    "ServingRestriction as serving_restriction",
    "CmsMetadata as cms_metadata",
    "NativeFormat as native_format",
    "NativeStyle as native_style",
    "Time as event_time",
    "UserId as user_id",
    "IP as ip",
    "AdvertiserId as advertiser_id",
    "cast(OrderId as bigint) as order_id",
    "cast(LineItemId as bigint) as line_item_id",
    "InventoryShareAssignmentName as inventory_share_assignment_name",
    "cast(CreativeId as bigint) as creative_id",
    "cast(CreativeVersion as bigint) as creative_version",
    "CreativeSize as creative_size",
    "CustomTargeting as custom_targeting",
    "cast(AdUnitId as bigint) as ad_unit_id",
    "Country as country",
    "Browser as browser",
    "Region as region",
    "OS as os",
    "Domain as domain",
    "Metro as metro",
    "City as city",
    "PostalCode as postal_code",
    "BandWidth as bandwidth",
    "cast(TimeUsec as bigint) as timeusec",
    "cast(GfpContentId as bigint) as gfp_content_id",
    "cast(OSId as bigint) as os_id",
    "cast(BrowserId as bigint) as browser_id",
    "cast(CountryId as bigint) as country_id",
    "cast(RegionId as bigint) as region_id",
    "cast(CityId as bigint) as city_id",
    "cast(MetroId as bigint) as metro_id",
    "cast(PostalCodeId as bigint) as postal_code_id",
    "cast(BandwidthId as bigint) as bandwidth_id",
    "AudienceSegmentIds as audience_segment_ids",
    "RequestedAdUnitSizes as requested_ad_unit_sizes",
    "MobileDevice as mobile_device",
    "OSVersion as os_version",
    "MobileCapability as mobile_capability",
    "cast(BandwidthGroupId as bigint) as bandwidth_group_id",
    "MobileCarrier as mobile_carrier",
    "Product as product",
    "PublisherProvidedID as publisher_provided_id",
    "cast(IsCompanion as boolean) as is_companion",
    "cast(VideoPosition as bigint) as video_position",
    "cast(PodPosition as bigint) as pod_position",
    "cast(VideoFallbackPosition as bigint) as video_fallback_position",
    "TargetedCustomCriteria as targeted_custom_criteria",
    "KeyPart as keypart",
    "cast(TimeUsec2 as bigint) as timeusec2",
    "DeviceCategory as device_category",
    "cast(IsInterstitial as boolean) as is_interstitial",
    "ActiveViewEligibleImpression as active_view_eligible_impression",
    "EventKeyPart as event_keypart",
    "cast(EventTimeUsec2 as bigint) as event_timeusec2",
    "RefererURL as referer_url",
    "cast(EstimatedBackfillRevenue as double) as estimated_backfill_revenue",
    "YieldGroupNames as yield_group_names",
    "cast(YieldGroupCompanyId as bigint) as yield_group_company_id",
    "MobileAppId as mobile_app_id",
    "RequestLanguage as request_language",
    "DealId as deal_id",
    "DealType as deal_type",
    "cast(AdxAccountId as bigint) as adx_account_id",
    "OptimizationType as optimization_type",
    "CreativeSizeDelivered as creative_size_delivered",
    "cast(Anonymous as boolean) as anonymous",
    "Advertiser as advertiser",
    "cast(SellerReservePrice as double) as seller_reserve_price",
    "Buyer as buyer",
    "ImpressionId as impression_id",
    "CAST(NULL AS STRING) as att_consent_status",
    "CAST(NULL AS STRING) as backfill_keypart",
    "cast(NULL as bigint) as custom_spot_subpod_ids",
    "cast(NULL as string) ppid_presence",
    "cast(NULL as string) as processing_date_and_hour",
    "cast(NULL as boolean) as protected_audience_api_delivery",
    "cast(NULL as string) as publisher_provided_signals",
    "cast(NULL as string) as user_identifier_status",
    "cast(NULL as string) as yield_partner_tag",
    "CURRENT_TIMESTAMP() as etl_created_at_timestamp_utc",
    "CURRENT_TIMESTAMP() as etl_updated_at_timestamp_utc",
    "EventHour as event_hour"
)

# COMMAND ----------

print(f"""
    DELETE FROM {target_table}
    WHERE {key_column} >= DATE('{event_start_date}')
      AND {key_column} <= DATE('{event_end_date}')
    """)


spark.sql(
    f"""
    DELETE FROM {target_table}
    WHERE {key_column} >= DATE('{event_start_date}')
      AND {key_column} <= DATE('{event_end_date}')
    """
);

# COMMAND ----------

(
    df_transformed.write
    .mode("append")  # Or "append" if you're not replacing existing partitions
    .saveAsTable(f"{target_table}")
)

# COMMAND ----------

# MAGIC %md
# MAGIC NETWORK IMPRESSIONS

# COMMAND ----------

target_table="fox_bi_dev.bronze_ads.news_gam_network_impressions"
key_column="event_date"

# COMMAND ----------

from pyspark.sql.functions import *


# Convert strings to datetime objects
start = datetime.strptime(event_start_date, "%Y-%m-%d")
end = datetime.strptime(event_end_date, "%Y-%m-%d")


# Generate list of date strings in the required format
date_list = [(start + timedelta(days=i)).strftime("%Y-%m-%d") 
             for i in range((end - start).days + 1)]

print(date_list)

# Initialize with the first day's DataFrame
df_source = spark.read.parquet(
    f"{base_path}/network_impressions/dt={date_list[0]}/"
).withColumn("eventdate", lit(date_list[0]))

# Union the rest
for date_str in date_list[1:]:
    df_next = spark.read.parquet(
        f"{base_path}/network_impressions/dt={date_str}/"
    ).withColumn("eventdate", lit(date_str))
    df_source = df_source.unionByName(df_next)

# COMMAND ----------

df_source = df_source.withColumnRenamed("time","Time")
df_source = df_source.withColumnRenamed("hour",'eventhour')

# COMMAND ----------

df_transformed = df_source.selectExpr(
    "cast(EventDate as date) as event_date",
    "Time as event_time",
    "UserId as user_id",
    "IP as ip",
    "AdvertiserId as advertiser_id",
    "cast(OrderId as bigint) as order_id",
    "cast(LineItemId as bigint) as line_item_id",
    "cast(CreativeId as bigint) as creative_id",
    "cast(CreativeVersion as bigint) as creative_version",
    "CreativeSize as creative_size",
    "cast(AdUnitId as bigint) as ad_unit_id",
    "cast(CustomTargeting as bigint) as custom_targeting",
    "Domain as domain",
    "cast(CountryId as bigint) as country_id",
    "Country as country",
    "cast(RegionId as bigint) as region_id",
    "Region as region",
    "cast(MetroId as bigint) as metro_id",
    "Metro as metro",
    "cast(CityId as bigint) as city_id",
    "City as city",
    "cast(PostalCodeId as bigint) as postal_code_id",
    "PostalCode as postal_code",
    "cast(BrowserId as bigint) as browser_id",
    "Browser as browser",
    "cast(OSId as bigint) as os_id",
    "OS as os",
    "BandWidth as bandwidth",
    "cast(BandwidthId as bigint) as bandwidth_id",
    "CAST(TimeUsec AS STRING) as timeusec",
    "AudienceSegmentIds as audience_segment_ids",
    "RequestedAdUnitSizes as requested_ad_unit_sizes",
    "cast(BandwidthGroupId as bigint) as bandwidth_group_id",
    "MobileDevice as mobile_device",
    "OSVersion as os_version",
    "MobileCapability as mobile_capability",
    "MobileCarrier as mobile_carrier",
    "Product as product",
    "cast(GfpContentId as bigint) as gfp_content_id",
    "cast(IsCompanion as boolean) as is_companion",
    "DeviceCategory as device_category",
    "cast(IsInterstitial as boolean) as is_interstitial",
    "cast(VideoPosition as bigint) as video_position",
    "ActiveViewEligibleImpression as active_view_eligible_impression",
    "KeyPart as keypart",
    "cast(PodPosition as bigint) as pod_position",
    "MobileAppId as mobile_app_id",
    "InventoryShareAssignmentId as inventory_share_assignment_id",
    "InventoryShareAssignmentName as inventory_share_assignment_name",
    "InventoryShareOutcome as inventory_share_outcome",
    "NativeStyle as native_style",
    "NativeFormat as native_format",
    "CmsMetadata as cms_metadata",
    "ServingRestriction as serving_restriction",
    "cast(EventTimeUsec2 as bigint) as event_timeusec2",
    "EventKeyPart as event_keypart",
    "RefererURL as referer_url",
    "cast(EstimatedBackfillRevenue as double) as estimated_backfill_revenue",
    "YieldGroupNames as yield_group_names",
    "cast(YieldGroupCompanyId as bigint) as yield_group_company_id",
    "RequestLanguage as request_language",
    "DealType as deal_type",
    "DealId as deal_id",
    "cast(AdxAccountId as bigint) as adx_account_id",
    "Buyer as buyer",
    "cast(SellerReservePrice as double) as seller_reserve_price",
    "Advertiser as advertiser",
    "cast(Anonymous as boolean) as anonymous",
    "CreativeSizeDelivered as creative_size_delivered",
    "ImpressionId as impression_id",
    "OptimizationType as optimization_type",
    "PublisherProvidedID as publisher_provided_id",
    "TargetedCustomCriteria as targeted_custom_criteria",
    "cast(VideoFallbackPosition as bigint) as video_fallback_position",
    "cast(TimeUsec2 as bigint) as timeusec2",
    "cast(NULL as bigint) as active_view_eligible_count",
    "cast(NULL as bigint) as active_view_measurable_count",
    "CAST(NULL AS STRING) as att_consent_status",
    "CAST(NULL AS STRING) as backfill_keypart",
    "cast(NULL as bigint) as custom_spot_subpod_ids",
    "CAST(NULL AS STRING) as ppid_presence",
    "CAST(NULL AS STRING) as processing_date_and_hour",
    "cast(NULL as boolean) as protected_audience_api_delivery",
    "CAST(NULL AS STRING) as protected_audience_seller",
    "CAST(NULL AS STRING) as publisher_provided_signals",
    "CAST(NULL AS STRING) as publisher_provided_signals_delivered",
    "CAST(NULL AS STRING) as user_identifier_status",
    "CAST(NULL AS STRING) as yield_partner_tag",
    "CURRENT_TIMESTAMP() as etl_created_at_timestamp_utc",
    "CURRENT_TIMESTAMP() as etl_updated_at_timestamp_utc",
    "EventHour as event_hour"
)

# COMMAND ----------

print(f"""
    DELETE FROM {target_table}
    WHERE {key_column} >= DATE('{event_start_date}')
      AND {key_column} <= DATE('{event_end_date}')
    """)


spark.sql( 
    f"""
    DELETE FROM {target_table}
    WHERE {key_column} >= DATE('{event_start_date}')
      AND {key_column} <= DATE('{event_end_date}')
    """
);

# COMMAND ----------

(
    df_transformed.write
    .mode("append")  # Or "append" if you're not replacing existing partitions
    .saveAsTable(f"{target_table}")
)

# COMMAND ----------

# MAGIC %md
# MAGIC NETWORK BACKFILL IMPRESSIONS

# COMMAND ----------

target_table="fox_bi_dev.bronze_ads.news_gam_network_backfill_impressions"
key_column="event_date"

# COMMAND ----------

from pyspark.sql.functions import *


# Convert strings to datetime objects
start = datetime.strptime(event_start_date, "%Y-%m-%d")
end = datetime.strptime(event_end_date, "%Y-%m-%d")


# Generate list of date strings in the required format
date_list = [(start + timedelta(days=i)).strftime("%Y-%m-%d") 
             for i in range((end - start).days + 1)]

print(date_list)

# Initialize with the first day's DataFrame
df_source = spark.read.parquet(
    f"{base_path}/network_backfill_impressions/dt={date_list[0]}/"
).withColumn("eventdate", lit(date_list[0]))

# Union the rest
for date_str in date_list[1:]:
    df_next = spark.read.parquet(
        f"{base_path}/network_backfill_impressions/dt={date_str}/"
    ).withColumn("eventdate", lit(date_str))
    
    df_source = df_source.unionByName(df_next)

# COMMAND ----------

df_source = df_source.withColumnRenamed("time","Time")
df_source = df_source.withColumnRenamed("hour",'eventhour')

# COMMAND ----------

df_transformed = df_source.selectExpr(
    "cast(EventDate as date) as event_date",
    "Time as event_time",
    "UserId as user_id",
    "IP as ip",
    "AdvertiserId as advertiser_id",
    "cast(OrderId as bigint) as order_id",
    "cast(LineItemId as bigint) as line_item_id",
    "cast(CreativeId as bigint) as creative_id",
    "cast(CreativeVersion as bigint) as creative_version",
    "CreativeSize as creative_size",
    "cast(AdUnitId as bigint) as ad_unit_id",
    "cast(CustomTargeting as bigint) as custom_targeting",
    "Domain as domain",
    "cast(CountryId as bigint) as country_id",
    "Country as country",
    "cast(RegionId as bigint) as region_id",
    "Region as region",
    "cast(MetroId as bigint) as metro_id",
    "Metro as metro",
    "cast(CityId as bigint) as city_id",
    "City as city",
    "cast(PostalCodeId as bigint) as postal_code_id",
    "PostalCode as postal_code",
    "cast(BrowserId as bigint) as browser_id",
    "Browser as browser",
    "cast(OSId as bigint) as os_id",
    "OS as os",
    "BandWidth as bandwidth",
    "cast(BandwidthId as bigint) as bandwidth_id",
    "CAST(TimeUsec AS STRING) as timeusec",
    "AudienceSegmentIds as audience_segment_ids",
    "RequestedAdUnitSizes as requested_ad_unit_sizes",
    "cast(BandwidthGroupId as bigint) as bandwidth_group_id",
    "MobileDevice as mobile_device",
    "OSVersion as os_version",
    "MobileCapability as mobile_capability",
    "MobileCarrier as mobile_carrier",
    "Product as product",
    "cast(GfpContentId as bigint) as gfp_content_id",
    "cast(IsCompanion as boolean) as is_companion",
    "DeviceCategory as device_category",
    "cast(IsInterstitial as boolean) as is_interstitial",
    "cast(VideoPosition as bigint) as video_position",
    "ActiveViewEligibleImpression as active_view_eligible_impression",
    "KeyPart as keypart",
    "cast(PodPosition as bigint) as pod_position",
    "MobileAppId as mobile_app_id",
    "InventoryShareAssignmentId as inventory_share_assignment_id",
    "InventoryShareAssignmentName as inventory_share_assignment_name",
    "InventoryShareOutcome as inventory_share_outcome",
    "NativeStyle as native_style",
    "NativeFormat as native_format",
    "CmsMetadata as cms_metadata",
    "ServingRestriction as serving_restriction",
    "cast(EventTimeUsec2 as bigint) as event_timeusec2",
    "EventKeyPart as event_keypart",
    "RefererURL as referer_url",
    "cast(EstimatedBackfillRevenue as double) as estimated_backfill_revenue",
    "YieldGroupNames as yield_group_names",
    "cast(YieldGroupCompanyId as bigint) as yield_group_company_id",
    "RequestLanguage as request_language",
    "DealType as deal_type",
    "DealId as deal_id",
    "cast(AdxAccountId as bigint) as adx_account_id",
    "Buyer as buyer",
    "cast(SellerReservePrice as double) as seller_reserve_price",
    "Advertiser as advertiser",
    "cast(Anonymous as boolean) as anonymous",
    "CreativeSizeDelivered as creative_size_delivered",
    "ImpressionId as impression_id",
    "OptimizationType as optimization_type",
    "PublisherProvidedID as publisher_provided_id",
    "TargetedCustomCriteria as targeted_custom_criteria",
    "cast(VideoFallbackPosition as bigint) as video_fallback_position",
    "cast(TimeUsec2 as bigint) as timeusec2",
    "cast(NULL as bigint) as active_view_eligible_count",
    "cast(NULL as bigint) as active_view_measurable_count",
    "CAST(NULL AS STRING) as att_consent_status",
    "CAST(NULL AS STRING) as backfill_keypart",
    "cast(NULL as bigint) as custom_spot_subpod_ids",
    "CAST(NULL AS STRING) as ppid_presence",
    "CAST(NULL AS STRING) as processing_date_and_hour",
    "cast(NULL as boolean) as protected_audience_api_delivery",
    "CAST(NULL AS STRING) as protected_audience_seller",
    "CAST(NULL AS STRING) as publisher_provided_signals",
    "CAST(NULL AS STRING) as publisher_provided_signals_delivered",
    "CAST(NULL AS STRING) as user_identifier_status",
    "CAST(NULL AS STRING) as yield_partner_tag",
    "CURRENT_TIMESTAMP() as etl_created_at_timestamp_utc",
    "CURRENT_TIMESTAMP() as etl_updated_at_timestamp_utc",
    "EventHour as event_hour"
)

# COMMAND ----------

print(f"""
    DELETE FROM {target_table}
    WHERE {key_column} >= DATE('{event_start_date}')
      AND {key_column} <= DATE('{event_end_date}')
    """)


spark.sql( 
    f"""
    DELETE FROM {target_table}
    WHERE {key_column} >= DATE('{event_start_date}')
      AND {key_column} <= DATE('{event_end_date}')
    """
);

# COMMAND ----------

(
    df_transformed.write
    .mode("append")  # Or "append" if you're not replacing existing partitions
    .saveAsTable(f"{target_table}")
)

# COMMAND ----------

# MAGIC %md
# MAGIC NETWORK CLICKS

# COMMAND ----------

target_table="fox_bi_dev.bronze_ads.news_gam_network_clicks"
key_column="event_date"

# COMMAND ----------

from pyspark.sql.functions import *


# Convert strings to datetime objects
start = datetime.strptime(event_start_date, "%Y-%m-%d")
end = datetime.strptime(event_end_date, "%Y-%m-%d")


# Generate list of date strings in the required format
date_list = [(start + timedelta(days=i)).strftime("%Y-%m-%d") 
             for i in range((end - start).days + 1)]

print(date_list)

# Initialize with the first day's DataFrame
df_source = spark.read.parquet(
    f"{base_path}/network_clicks/dt={date_list[0]}/"
).withColumn("eventdate", lit(date_list[0]))

# Union the rest
for date_str in date_list[1:]:
    df_next = spark.read.parquet(
        f"{base_path}/network_clicks/dt={date_str}/"
    ).withColumn("eventdate", lit(date_str))
    df_source = df_source.unionByName(df_next)

# COMMAND ----------

df_source = df_source.withColumnRenamed("time","Time")  
df_source = df_source.withColumnRenamed("hour",'eventhour')

# COMMAND ----------

df_transformed = df_source.selectExpr(
    "cast(EventDate as date) as event_date",
    "Time as event_time",
    "UserId as user_id",
    "IP as ip",
    "AdvertiserId as advertiser_id",
    "cast(OrderId as bigint) as order_id",
    "cast(LineItemId as bigint) as line_item_id",
    "cast(CreativeId as bigint) as creative_id",
    "cast(CreativeVersion as bigint) as creative_version",
    "CreativeSize as creative_size",
    "cast(AdUnitId as bigint) as ad_unit_id",
    "CustomTargeting as custom_targeting",
    "Domain as domain",
    "cast(CountryId as bigint) as country_id",
    "Country as country",
    "cast(RegionId as bigint) as region_id",
    "Region as region",
    "cast(MetroId as bigint) as metro_id",
    "Metro as metro",
    "cast(CityId as bigint) as city_id",
    "City as city",
    "cast(PostalCodeId as bigint) as postal_code_id",
    "PostalCode as postal_code",
    "cast(BrowserId as bigint) as browser_id",
    "Browser as browser",
    "cast(OSId as bigint) as os_id",
    "OS as os",
    "BandWidth as bandwidth",
    "cast(BandwidthId as bigint) as bandwidth_id",
    "cast(TimeUsec as bigint) as timeusec",
    "AudienceSegmentIds as audience_segment_ids",
    "RequestedAdUnitSizes as requested_ad_unit_sizes",
    "cast(BandwidthGroupId as bigint) as bandwidth_group_id",
    "MobileDevice as mobile_device",
    "OSVersion as os_version",
    "MobileCapability as mobile_capability",
    "MobileCarrier as mobile_carrier",
    "Product as product",
    "cast(GfpContentId as bigint) as gfp_content_id",
    "cast(IsCompanion as boolean) as is_companion",
    "DeviceCategory as device_category",
    "cast(IsInterstitial as boolean) as is_interstitial",
    "cast(VideoPosition as bigint) as video_position",
    "MobileAppId as mobile_app_id",
    "ImpressionId as impression_id",
    "KeyPart as keypart",
    "cast(TimeUsec2 as bigint) as timeusec2",
    "CAST(NULL AS STRING) as advertiser",
    "cast(NULL as bigint) as adx_account_id",
    "cast(NULL as boolean) as anonymous",
    "CAST(NULL AS STRING) as att_consent_status",
    "CAST(NULL AS STRING) as backfill_keypart",
    "CAST(NULL AS STRING) as buyer",
    "CAST(NULL AS STRING) as cms_metadata",
    "CAST(NULL AS STRING) as creative_size_delivered",
    "cast(NULL as bigint) as custom_spot_subpod_ids",
    "CAST(NULL AS STRING) as deal_id",
    "CAST(NULL AS STRING) as deal_type",
    "cast(NULL as double) as estimated_backfill_revenue",
    "CAST(NULL AS STRING) as event_keypart",
    "cast(NULL as bigint) as event_timeusec2",
    "CAST(NULL AS STRING) as native_format",
    "CAST(NULL AS STRING) as native_style",
    "CAST(NULL AS STRING) as optimization_type",
    "cast(NULL as bigint) as pod_position",
    "CAST(NULL AS STRING) as ppid_presence",
    "CAST(NULL AS STRING) as processing_date_and_hour",
    "cast(NULL as boolean) as protected_audience_api_delivery",
    "CAST(NULL AS STRING) as publisher_provided_id",
    "CAST(NULL AS STRING) as publisher_provided_signals",
    "CAST(NULL AS STRING) as publisher_provided_signals_delivered",
    "CAST(NULL AS STRING) as referer_url",
    "CAST(NULL AS STRING) as request_language",
    "cast(NULL as double) as seller_reserve_price",
    "CAST(NULL AS STRING) as serving_restriction",
    "CAST(NULL AS STRING) as targeted_custom_criteria",
    "CAST(NULL AS STRING) as user_identifier_status",
    "cast(NULL as bigint) as video_fallback_position",
    "cast(NULL as bigint) as yield_group_company_id",
    "cast(NULL as STRING) as yield_group_names",
    "cast(NULL as STRING) as yield_partner_tag",
    "CURRENT_TIMESTAMP() as etl_created_at_timestamp_utc",
    "CURRENT_TIMESTAMP() as etl_updated_at_timestamp_utc",
    "EventHour as event_hour" )

# COMMAND ----------

print(f"""
    DELETE FROM {target_table}
    WHERE {key_column} >= DATE('{event_start_date}')
      AND {key_column} <= DATE('{event_end_date}')
    """)


spark.sql( 
    f"""
    DELETE FROM {target_table}
    WHERE {key_column} >= DATE('{event_start_date}')
      AND {key_column} <= DATE('{event_end_date}')
    """
);

# COMMAND ----------

(
    df_transformed.write
    .mode("append")  # Or "append" if you're not replacing existing partitions
    .saveAsTable(f"{target_table}")
)

# COMMAND ----------

# MAGIC %md
# MAGIC NETWORK BACKFILL CLICKS

# COMMAND ----------

target_table="fox_bi_dev.bronze_ads.news_gam_network_backfill_clicks"
key_column="event_date"

# COMMAND ----------

from pyspark.sql.functions import *


# Convert strings to datetime objects
start = datetime.strptime(event_start_date, "%Y-%m-%d")
end = datetime.strptime(event_end_date, "%Y-%m-%d")


# Generate list of date strings in the required format
date_list = [(start + timedelta(days=i)).strftime("%Y-%m-%d") 
             for i in range((end - start).days + 1)]

print(date_list)

# Initialize with the first day's DataFrame
df_source = spark.read.parquet(
    f"{base_path}/network_backfill_clicks/dt={date_list[0]}/"
).withColumn("eventdate", lit(date_list[0]))

# Union the rest
for date_str in date_list[1:]:
    df_next = spark.read.parquet(
        f"{base_path}/network_backfill_clicks/dt={date_str}/"
    ).withColumn("eventdate", lit(date_str))
    df_source = df_source.unionByName(df_next)

# COMMAND ----------

df_source = df_source.withColumnRenamed("time","Time")
df_source = df_source.withColumnRenamed("hour",'eventhour')

# COMMAND ----------

df_transformed = df_source.selectExpr(
    "cast(EventDate as date) as event_date",
    "Time as event_time",
    "UserId as user_id",
    "IP as ip",
    "AdvertiserId as advertiser_id",
    "cast(OrderId as bigint) as order_id",
    "cast(LineItemId as bigint) as line_item_id",
    "cast(CreativeId as bigint) as creative_id",
    "cast(CreativeVersion as bigint) as creative_version",
    "CreativeSize as creative_size",
    "cast(AdUnitId as bigint) as ad_unit_id",
    "CustomTargeting as custom_targeting",
    "Domain as domain",
    "cast(CountryId as bigint) as country_id",
    "Country as country",
    "cast(RegionId as bigint) as region_id",
    "Region as region",
    "cast(MetroId as bigint) as metro_id",
    "Metro as metro",
    "cast(CityId as bigint) as city_id",
    "City as city",
    "cast(PostalCodeId as bigint) as postal_code_id",
    "PostalCode as postal_code",
    "cast(BrowserId as bigint) as browser_id",
    "Browser as browser",
    "cast(OSId as bigint) as os_id",
    "OS as os",
    "BandWidth as bandwidth",
    "cast(BandwidthId as bigint) as bandwidth_id",
    "cast(TimeUsec as bigint) as timeusec",
    "AudienceSegmentIds as audience_segment_ids",
    "RequestedAdUnitSizes as requested_ad_unit_sizes",
    "cast(BandwidthGroupId as bigint) as bandwidth_group_id",
    "MobileDevice as mobile_device",
    "OSVersion as os_version",
    "MobileCapability as mobile_capability",
    "MobileCarrier as mobile_carrier",
    "Product as product",
    "cast(GfpContentId as bigint) as gfp_content_id",
    "cast(IsCompanion as boolean) as is_companion",
    "DeviceCategory as device_category",
    "cast(IsInterstitial as boolean) as is_interstitial",
    "cast(VideoPosition as bigint) as video_position",
    "MobileAppId as mobile_app_id",
    "ImpressionId as impression_id",
    "KeyPart as keypart",
    "cast(TimeUsec2 as bigint) as timeusec2",
    "CAST(NULL AS STRING) as advertiser",
    "cast(NULL as bigint) as adx_account_id",
    "cast(NULL as boolean) as anonymous",
    "CAST(NULL AS STRING) as att_consent_status",
    "CAST(NULL AS STRING) as backfill_keypart",
    "CAST(NULL AS STRING) as buyer",
    "CAST(NULL AS STRING) as cms_metadata",
    "CAST(NULL AS STRING) as creative_size_delivered",
    "cast(NULL as bigint) as custom_spot_subpod_ids",
    "CAST(NULL AS STRING) as deal_id",
    "CAST(NULL AS STRING) as deal_type",
    "cast(NULL as double) as estimated_backfill_revenue",
    "CAST(NULL AS STRING) as event_keypart",
    "cast(NULL as bigint) as event_timeusec2",
    "CAST(NULL AS STRING) as native_format",
    "CAST(NULL AS STRING) as native_style",
    "CAST(NULL AS STRING) as optimization_type",
    "cast(NULL as bigint) as pod_position",
    "CAST(NULL AS STRING) as ppid_presence",
    "CAST(NULL AS STRING) as processing_date_and_hour",
    "cast(NULL as boolean) as protected_audience_api_delivery",
    "CAST(NULL AS STRING) as publisher_provided_id",
    "CAST(NULL AS STRING) as publisher_provided_signals",
    "CAST(NULL AS STRING) as publisher_provided_signals_delivered",
    "CAST(NULL AS STRING) as referer_url",
    "CAST(NULL AS STRING) as request_language",
    "cast(NULL as double) as seller_reserve_price",
    "CAST(NULL AS STRING) as serving_restriction",
    "CAST(NULL AS STRING) as targeted_custom_criteria",
    "CAST(NULL AS STRING) as user_identifier_status",
    "cast(NULL as bigint) as video_fallback_position",
    "cast(NULL as bigint) as yield_group_company_id",
    "cast(NULL as STRING) as yield_group_names",
    "cast(NULL as STRING) as yield_partner_tag",
    "CURRENT_TIMESTAMP() as etl_created_at_timestamp_utc",
    "CURRENT_TIMESTAMP() as etl_updated_at_timestamp_utc",
    "EventHour as event_hour" )

# COMMAND ----------

print(f"""
    DELETE FROM {target_table}
    WHERE {key_column} >= DATE('{event_start_date}')
      AND {key_column} <= DATE('{event_end_date}')
    """)


spark.sql( 
    f"""
    DELETE FROM {target_table}
    WHERE {key_column} >= DATE('{event_start_date}')
      AND {key_column} <= DATE('{event_end_date}')
    """
);

# COMMAND ----------

(
    df_transformed.write
    .mode("append")  # Or "append" if you're not replacing existing partitions
    .saveAsTable(f"{target_table}")
)