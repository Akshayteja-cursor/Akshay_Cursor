# Databricks notebook source
# from pyspark.sql.functions import *


# # Convert strings to datetime objects
# start = datetime.strptime(event_start_date, "%Y-%m-%d")
# end = datetime.strptime(event_end_date, "%Y-%m-%d")


# # Generate list of date strings in the required format
# date_list = [(start + timedelta(days=i)).strftime("%Y-%m-%d") 
#              for i in range((end - start).days + 1)]

# print(date_list)

# # Initialize with the first day's DataFrame
# df_source = (
#     spark.read
#     .format("parquet")
#     .option("header", "true")
#     .option("inferSchema", "true")
#     .option("quote", '"')
#     .option("escape", '"')
#     .load(f"/mnt/ad-tech-lz/freewheel/516429/v4logs/{date_list[0]}/")
# )

# # Union the rest
# for date_str in date_list[1:]:
#     df_next = (
#     spark.read
#     .format("csv")
#     .option("header", "true")
#     .option("inferSchema", "true")
#     .option("quote", '"')
#     .option("escape", '"')
#     .load(f"/mnt/ad-tech-lz/freewheel/516429/v4logs/{date_str}/")
#     )

#     df_source = df_source.unionByName(df_next)

# COMMAND ----------

# (
#     df_transformed.writeStream
#     .format("uniform")
#     .outputMode("append")
#     .partitionBy("network_group_id", "event_date")  # Partitioning works for streaming appends
#     .option("checkpointLocation", "/mnt/fox-fdp-bi-dev/adtech/freewheel_historical_backfill/checkpoint/")
#     .trigger(once=True)
#     .toTable("fox_bi_dev.bronze_ads.freewheel_v4_logs_516429_fox_corp")
# )

# COMMAND ----------

skip_freewheel = dbutils.jobs.taskValues.get("set_job_parameters","skip_freewheel")
event_start_date = dbutils.jobs.taskValues.get("set_job_parameters","event_start_date_freewheel")
event_end_date = dbutils.jobs.taskValues.get("set_job_parameters","event_end_date_freewheel")

# COMMAND ----------

if skip_freewheel=='true':
  dbutils.notebook.exit("Skipping Freewheel")

# COMMAND ----------

spark.conf.set("spark.sql.shuffle.partitions", "auto")

# COMMAND ----------

from datetime import datetime, timedelta

# COMMAND ----------

# MAGIC %md
# MAGIC FW FOX CORP 516429 NETWORK BACKFILL

# COMMAND ----------

base_path=f"/mnt/ad-tech-clean/freewheel/v4logs"

# COMMAND ----------

from pyspark.sql.functions import *


# Convert strings to datetime objects
start = datetime.strptime(event_start_date, "%Y-%m-%d")
end = datetime.strptime(event_end_date, "%Y-%m-%d")


# Generate list of date strings in the required format
date_list = [(start + timedelta(days=i)).strftime("%Y-%m-%d") 
             for i in range((end - start).days + 1)]

print(date_list)

# Initialize with the first day's DataFrame
df_source = (
    spark.read
    .parquet(f"{base_path}/network_id=516429/dt={date_list[0]}/")
).withColumn("eventdate", lit(date_list[0])).withColumn("networkid", lit(516429))

# # Union the rest
for date_str in date_list[1:]:
    df_next = (
    spark.read
    .parquet(f"{base_path}/network_id=516429/dt={date_str}/")
    ).withColumn("eventdate", lit(date_str)).withColumn("networkid", lit(516429))

    df_source = df_source.unionByName(df_next)

# COMMAND ----------

df_source = df_source.withColumnRenamed("hour", 'eventhour')

# COMMAND ----------

df_transformed = df_source.selectExpr(
    "TransactionId as transaction_id",
    "EventTime as event_time",
    "EventType as event_type",
    "EventName as event_name",
    "cast(NetworkId as bigint) as network_group_id",
    "cast(ContentProviderPartnerId as bigint) as content_provider_partner_id",
    "cast(DistributionPartnerId as bigint) as distribution_partner_id",
    "cast(SellingPartnerId as bigint) as selling_partner_id",
    "cast(ExternalReseller as boolean) as external_seller",
    "ValueChainRole as value_chain_role",
    "cast(SiteId as bigint) as site_id",
    "cast(SiteSectionId as bigint) as site_section_id",
    "RequestSiteCustomId as request_site_custom_id",
    "cast(SeriesId as bigint) as series_id",
    "cast(VideoAssetId as bigint) as video_asset_id",
    "RequestVideoCustomId as request_video_custom_id",
    "TimePositionClass as time_position_class",
    "cast(SlotIndex as bigint) as slot_index",
    "cast(PositionInSlot as decimal(20,0)) as position_in_slot",
    "cast(TimePosition as decimal(20,0)) as time_position",
    "AdUnitHash as ad_unit_hash",
    "cast(PlacementId as bigint) as placement_id",
    "cast(AdUnitId as bigint) as ad_unit_id",
    "cast(NetValue as float) as net_value",
    "cast(CreativeId as bigint) as creative_id",
    "cast(CreativeRenditionId as bigint) as creative_rendition_id",
    "PriceModel as price_model",
    "UniqueIdentifier as unique_identifier",
    "CustomVisitorId as custom_visitor_id",
    "PageViewRandom as page_view_random",
    "VideoPlayRandom as video_play_random",
    "VisitorCountry as visitor_country",
    "VisitorDMA as visitor_dma",
    "VisitorStateProvince as visitor_state_province",
    "VisitorPostalCode as visitor_postal_code",
    "VisitorTimeZoneOffset as visitor_timezonze_offset",
    "ParsedUserAgent as parsed_user_agent",
    "AllRequestKV as all_request_kv",
    "AllEventKV as all_event_kv",
    "cast(BillableAbstractEventId as bigint) as billable_abstract_event_id",
    "cast(TriggeringConcreteEventId as bigint) as triggering_concrete_event_id",
    "ConcreteEventId as concrete_event_id",
    "cast(ScenarioId as bigint) as scenario_id",
    "cast(MaxAds as decimal(20,0)) as max_ads",
    "cast(MaxDuration as decimal(20,0)) as max_duration",
    "cast(TimeUnfilled as decimal(20,0)) as time_unfilled",
    "cast(AdSselected as decimal(20,0)) as ads_selected",
    "cast(AdDuration as decimal(20,0)) as ad_duration",
    "IPAddress as ip_address",
    "AdDeliveryMethod as ad_delivery_method",
    "cast(ChannelId as bigint) as channel_id",
    "cast(AiringId as bigint) as airing_id",
    "cast(BreakId as bigint) as break_id",
    "RequestBreakCustomId as request_break_custom_id",
    "RequestAiringCustomId as request_airing_custom_id",
    "RequestChannelCustomId as request_channel_custom_id",
    "cast(HyldaRequest as boolean) as hylda_request",
    "ReferrerURL as referrer_url",
    "RawUserAgent as raw_user_agent",
    "RecordIdentifier as record_identifier",
    "cast(MRMRuleId as bigint) as mrm_rule_id",
    "cast(CreativeDuration as decimal(20,0))  as creative_duration",
    "cast(AdUnitTypeId as bigint) as ad_unit_type_id",
    "cast(EventMultiplier as decimal(20,0))  as event_multiplier",
    "cast(PlatformBrowserId as bigint) as platform_browser_id",
    "cast(PlatformOSId as bigint) as platform_os_id",
    "cast(PlatformDeviceId as bigint) as platform_device_id",
    "cast(VisitorZone as bigint) as visitor_zone",
    "AudienceItem as audience_item",
    "cast(CBPId as int) as cbp_id",
    "Label as label",
    "MarketUnifiedAdId as market_unified_ad_id",
    "MarketBuyerSeatId as market_buyer_seat_id",
    "MarketDealId as market_deal_id",
    "cast(MarketAdvertiserId as bigint) as market_advertiser_id",
    "ClockNumber as clock_number",
    "VisitorCity as visitor_city",
    "cast(OpportunityId as bigint) as opportunity_id",
    "StreamId as stream_id",
    "SignalId as signal_id",
    "LinearDecisionType as linear_decision_type",
    "SalesChannelType as sales_channel_type",
    "MatchedAudienceItem as matched_audience_item",
    "cast(ProgOpenExchangeRuleId as bigint) as prog_open_exchange_rule_id",
    "cast(SoldOrderID as bigint) as sold_order_id",
    "cast(PurchasedOrderId as bigint) as purchased_order_id",
    "ListingId as listing_id",
    "cast(ContentBrandId as bigint) as content_brand_id",
    "PlatformGroup as platform_group",
    "GIVTDecisionResult as givt_decision_result",
    "GenreId as genre_id",
    "cast(LanguageId as bigint) as language_id",
    "cast(EndpointOwnerId as bigint) as end_point_owner_id",
    "cast(EndpointId as bigint) as end_point",
    "DeviceId as device_id",
    "GlobalBrandId as global_brand_id",
    "PlacementOpportunityId as placement_opportunity_id",
    "StreamType as stream_type",
    "cast(TVRatingId as bigint) as tv_rating_id",
    "cast(StandardEnvironmentId as bigint) as standard_environment_id",
    "cast(StandardOSId as bigint) as standard_os_id",
    "StandardDeviceTypeId as standard_device_type_id",
    "cast(ContentDuration as decimal(20,0)) as content_duration",
    "cast(IPEnabledAudience as boolean) as ip_enabled_audience",
    "cast(ProgrammerId as bigint) as programmer_id",
    "XifaId as xifa_id",
    "cast(ContentChannelId as bigint) as content_channel_id",
    "cast(DaypartId as bigint) as day_part_id",
    "cast(LogSampleAmplifier as bigint) as log_sample_amplifier",
    "GlobalAdvertiserId as global_advertiser_id",
    "MarketAdSource as market_ad_source",
    "CreativeVariantId as creative_variant_id",
    "CreativeRenditionVariantId as creative_rendition_variant_id",
    "MatchedInventoryPackage as matched_inventory_package",
    "PrivacyJurisdiction as privacy_jurisdiction",
    "PrivacyChoices as privacy_choices",
    "HeaderBiddingTransactionId as header_bidding_transaction_id",
    "HeaderBiddingKey as header_bidding_key",
    "HeaderBiddingValue as header_bidding_value",
    "TrimmedTrackingDomainIds as trimmed_tracking_domain_ids",
    "TrimmedTrackingDomains as trimmed_tracking_domains",
    "cast(SubscriptionModelId as bigint) as subscription_model_id",
    "MatchedTargetingItems as matched_targeting_items",
    "CreativeUniqueId as creative_unique_id",
    "cast(StandardOperatorId as bigint) as standard_operator_id",
    "cast(StandardContentSeriesId as bigint) as standard_content_series_id",
    "cast(StandardSSPAppId as bigint) as standard_ssp_app_id",
    "StandardSSPPublisherId as standard_ssp_publisher_id",
    "StandardSSPIABCategoryId as standard_ssp_iab_category_id",
    "StandardContentTerritoryId as standard_content_territory_id",
    "cast(StandardSSPDomainId as bigint) as standard_ssp_domain_id",
    "cast(StandardSSPChannelId as bigint) as standard_ssp_channel_id",
    "cast(StandardContentCredentialStatusId as bigint) as standard_content_credential_status_id",
    "InlineCreativeId as inline_creative_id",
    "InlineUniversalAdId as inline_universal_ad_id",
    "InventoryPackageId as inventory_package_id",
    "cast(GlobalSlotIndex as bigint) as global_slot_index",
    "cast(Revenue as double) as revenue",
    "YOSubConfigurationId as yosubconfiguration_id",
    "YOContributingItems as yocontributingitems",
    "cast(StandardMovieRatingId as bigint) as standard_movie_rating_id",
    "cast(VirtualCreativeRenditionId as bigint) as virtual_creative_rendition_id",
    "CURRENT_TIMESTAMP() as etl_created_at_timestamp_utc",
    "CURRENT_TIMESTAMP() as etl_updated_at_timestamp_utc",
    "cast(eventdate as date) as event_date",
    "eventhour as event_hour")

# COMMAND ----------

(
    df_transformed.write
    .mode("overwrite")
    .option('partitionOverwriteMode', 'dynamic')
    .saveAsTable("fox_bi_dev.bronze_ads.freewheel_v4_logs_516429_fox_corp")
)



# COMMAND ----------

# MAGIC %md
# MAGIC FW FOX AFF 500763 NETWORK BACKFILL 500763

# COMMAND ----------

from pyspark.sql.functions import *


# Convert strings to datetime objects
start = datetime.strptime(event_start_date, "%Y-%m-%d")
end = datetime.strptime(event_end_date, "%Y-%m-%d")


# Generate list of date strings in the required format
date_list = [(start + timedelta(days=i)).strftime("%Y-%m-%d") 
             for i in range((end - start).days + 1)]

print(date_list)

# Initialize with the first day's DataFrame
df_source = (
    spark.read
    .parquet(f"{base_path}/network_id=500763/dt={date_list[0]}/")
).withColumn("eventdate", lit(date_list[0])).withColumn("networkid", lit(500763))

# Union the rest
for date_str in date_list[1:]:
    df_next = (
    spark.read
    .parquet(f"{base_path}/network_id=500763/dt={date_str}/")
    ).withColumn("eventdate", lit(date_str)).withColumn("networkid", lit(500763))

    df_source = df_source.unionByName(df_next)

# COMMAND ----------

df_source = df_source.withColumnRenamed("hour", 'eventhour')

# COMMAND ----------

df_transformed = df_source.selectExpr(
    "TransactionId as transaction_id",
    "EventTime as event_time",
    "EventType as event_type",
    "EventName as event_name",
    "cast(NetworkId as bigint) as network_group_id",
    "cast(ContentProviderPartnerId as bigint) as content_provider_partner_id",
    "cast(DistributionPartnerId as bigint) as distribution_partner_id",
    "cast(SellingPartnerId as bigint) as selling_partner_id",
    "cast(ExternalReseller as boolean) as external_seller",
    "ValueChainRole as value_chain_role",
    "cast(SiteId as bigint) as site_id",
    "cast(SiteSectionId as bigint) as site_section_id",
    "RequestSiteCustomId as request_site_custom_id",
    "cast(SeriesId as bigint) as series_id",
    "cast(VideoAssetId as bigint) as video_asset_id",
    "RequestVideoCustomId as request_video_custom_id",
    "TimePositionClass as time_position_class",
    "cast(SlotIndex as bigint) as slot_index",
    "cast(PositionInSlot as decimal(20,0)) as position_in_slot",
    "cast(TimePosition as decimal(20,0)) as time_position",
    "AdUnitHash as ad_unit_hash",
    "cast(PlacementId as bigint) as placement_id",
    "cast(AdUnitId as bigint) as ad_unit_id",
    "cast(NetValue as float) as net_value",
    "cast(CreativeId as bigint) as creative_id",
    "cast(CreativeRenditionId as bigint) as creative_rendition_id",
    "PriceModel as price_model",
    "UniqueIdentifier as unique_identifier",
    "CustomVisitorId as custom_visitor_id",
    "PageViewRandom as page_view_random",
    "VideoPlayRandom as video_play_random",
    "VisitorCountry as visitor_country",
    "VisitorDMA as visitor_dma",
    "VisitorStateProvince as visitor_state_province",
    "VisitorPostalCode as visitor_postal_code",
    "VisitorTimeZoneOffset as visitor_timezonze_offset",
    "ParsedUserAgent as parsed_user_agent",
    "AllRequestKV as all_request_kv",
    "AllEventKV as all_event_kv",
    "cast(BillableAbstractEventId as bigint) as billable_abstract_event_id",
    "cast(TriggeringConcreteEventId as bigint) as triggering_concrete_event_id",
    "ConcreteEventId as concrete_event_id",
    "cast(ScenarioId as bigint) as scenario_id",
    "cast(MaxAds as decimal(20,0)) as max_ads",
    "cast(MaxDuration as decimal(20,0)) as max_duration",
    "cast(TimeUnfilled as decimal(20,0)) as time_unfilled",
    "cast(AdSselected as decimal(20,0)) as ads_selected",
    "cast(AdDuration as decimal(20,0)) as ad_duration",
    "IPAddress as ip_address",
    "AdDeliveryMethod as ad_delivery_method",
    "cast(ChannelId as bigint) as channel_id",
    "cast(AiringId as bigint) as airing_id",
    "cast(BreakId as bigint) as break_id",
    "RequestBreakCustomId as request_break_custom_id",
    "RequestAiringCustomId as request_airing_custom_id",
    "RequestChannelCustomId as request_channel_custom_id",
    "cast(HyldaRequest as boolean) as hylda_request",
    "ReferrerURL as referrer_url",
    "RawUserAgent as raw_user_agent",
    "RecordIdentifier as record_identifier",
    "cast(MRMRuleId as bigint) as mrm_rule_id",
    "cast(CreativeDuration as decimal(20,0))  as creative_duration",
    "cast(AdUnitTypeId as bigint) as ad_unit_type_id",
    "cast(EventMultiplier as decimal(20,0))  as event_multiplier",
    "cast(PlatformBrowserId as bigint) as platform_browser_id",
    "cast(PlatformOSId as bigint) as platform_os_id",
    "cast(PlatformDeviceId as bigint) as platform_device_id",
    "cast(VisitorZone as bigint) as visitor_zone",
    "AudienceItem as audience_item",
    "cast(CBPId as int) as cbp_id",
    "Label as label",
    "MarketUnifiedAdId as market_unified_ad_id",
    "MarketBuyerSeatId as market_buyer_seat_id",
    "MarketDealId as market_deal_id",
    "cast(MarketAdvertiserId as bigint) as market_advertiser_id",
    "ClockNumber as clock_number",
    "VisitorCity as visitor_city",
    "cast(OpportunityId as bigint) as opportunity_id",
    "StreamId as stream_id",
    "SignalId as signal_id",
    "LinearDecisionType as linear_decision_type",
    "SalesChannelType as sales_channel_type",
    "MatchedAudienceItem as matched_audience_item",
    "cast(ProgOpenExchangeRuleId as bigint) as prog_open_exchange_rule_id",
    "cast(SoldOrderID as bigint) as sold_order_id",
    "cast(PurchasedOrderId as bigint) as purchased_order_id",
    "ListingId as listing_id",
    "cast(ContentBrandId as bigint) as content_brand_id",
    "PlatformGroup as platform_group",
    "GIVTDecisionResult as givt_decision_result",
    "GenreId as genre_id",
    "cast(LanguageId as bigint) as language_id",
    "cast(EndpointOwnerId as bigint) as end_point_owner_id",
    "cast(EndpointId as bigint) as end_point",
    "DeviceId as device_id",
    "GlobalBrandId as global_brand_id",
    "PlacementOpportunityId as placement_opportunity_id",
    "StreamType as stream_type",
    "cast(TVRatingId as bigint) as tv_rating_id",
    "cast(StandardEnvironmentId as bigint) as standard_environment_id",
    "cast(StandardOSId as bigint) as standard_os_id",
    "StandardDeviceTypeId as standard_device_type_id",
    "cast(ContentDuration as decimal(20,0)) as content_duration",
    "cast(IPEnabledAudience as boolean) as ip_enabled_audience",
    "cast(ProgrammerId as bigint) as programmer_id",
    "XifaId as xifa_id",
    "cast(ContentChannelId as bigint) as content_channel_id",
    "cast(DaypartId as bigint) as day_part_id",
    "cast(LogSampleAmplifier as bigint) as log_sample_amplifier",
    "GlobalAdvertiserId as global_advertiser_id",
    "MarketAdSource as market_ad_source",
    "CreativeVariantId as creative_variant_id",
    "CreativeRenditionVariantId as creative_rendition_variant_id",
    "MatchedInventoryPackage as matched_inventory_package",
    "PrivacyJurisdiction as privacy_jurisdiction",
    "PrivacyChoices as privacy_choices",
    "HeaderBiddingTransactionId as header_bidding_transaction_id",
    "HeaderBiddingKey as header_bidding_key",
    "HeaderBiddingValue as header_bidding_value",
    "TrimmedTrackingDomainIds as trimmed_tracking_domain_ids",
    "TrimmedTrackingDomains as trimmed_tracking_domains",
    "cast(SubscriptionModelId as bigint) as subscription_model_id",
    "MatchedTargetingItems as matched_targeting_items",
    "CreativeUniqueId as creative_unique_id",
    "cast(StandardOperatorId as bigint) as standard_operator_id",
    "cast(StandardContentSeriesId as bigint) as standard_content_series_id",
    "cast(StandardSSPAppId as bigint) as standard_ssp_app_id",
    "StandardSSPPublisherId as standard_ssp_publisher_id",
    "StandardSSPIABCategoryId as standard_ssp_iab_category_id",
    "StandardContentTerritoryId as standard_content_territory_id",
    "cast(StandardSSPDomainId as bigint) as standard_ssp_domain_id",
    "cast(StandardSSPChannelId as bigint) as standard_ssp_channel_id",
    "cast(StandardContentCredentialStatusId as bigint) as standard_content_credential_status_id",
    "InlineCreativeId as inline_creative_id",
    "InlineUniversalAdId as inline_universal_ad_id",
    "InventoryPackageId as inventory_package_id",
    "cast(GlobalSlotIndex as bigint) as global_slot_index",
    "cast(Revenue as double) as revenue",
    "YOSubConfigurationId as yosubconfiguration_id",
    "YOContributingItems as yocontributingitems",
    "cast(StandardMovieRatingId as bigint) as standard_movie_rating_id",
    "cast(VirtualCreativeRenditionId as bigint) as virtual_creative_rendition_id",
    "CURRENT_TIMESTAMP() as etl_created_at_timestamp_utc",
    "CURRENT_TIMESTAMP() as etl_updated_at_timestamp_utc",
    "cast(eventdate as date) as event_date",
    "eventhour as event_hour")

# COMMAND ----------

(
    df_transformed.write
    .mode("overwrite")
    .option('partitionOverwriteMode', 'dynamic')
    .saveAsTable("fox_bi_dev.bronze_ads.freewheel_v4_logs_500763_fox_affiliates")
)