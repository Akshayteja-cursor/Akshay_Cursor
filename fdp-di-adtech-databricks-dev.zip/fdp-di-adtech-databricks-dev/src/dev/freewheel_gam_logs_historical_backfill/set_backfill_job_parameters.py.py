# Databricks notebook source
skip_freewheel = dbutils.widgets.get("skip_freewheel")
skip_gam=dbutils.widgets.get("skip_gam")

event_start_date_freewheel = dbutils.widgets.get("event_start_date_freewheel")
event_end_date_freewheel = dbutils.widgets.get("event_end_date_freewheel")
event_start_date_gam = dbutils.widgets.get("event_start_date_gam")
event_end_date_gam = dbutils.widgets.get("event_end_date_gam")

# COMMAND ----------

# Always set the task values so downstream notebooks can read them

dbutils.jobs.taskValues.set("skip_freewheel", skip_freewheel)
dbutils.jobs.taskValues.set("skip_gam", skip_gam)
dbutils.jobs.taskValues.set("event_start_date_freewheel", event_start_date_freewheel)
dbutils.jobs.taskValues.set("event_end_date_freewheel", event_end_date_freewheel)
dbutils.jobs.taskValues.set("event_start_date_gam", event_start_date_gam)
dbutils.jobs.taskValues.set("event_end_date_gam", event_end_date_gam)