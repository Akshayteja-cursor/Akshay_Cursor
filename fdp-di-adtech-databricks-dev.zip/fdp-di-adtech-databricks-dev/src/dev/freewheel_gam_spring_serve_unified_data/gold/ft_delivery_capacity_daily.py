# Databricks notebook source
from datetime import datetime, timedelta

# COMMAND ----------

spark.conf.set(
    "spark.databricks.remoteFiltering.blockSelfJoins",
    "false"
)


# COMMAND ----------
query = """

----GAM
with gam_data as (
 select
     ad_date as event_date
    ,platform
    ,platform_group
    ,business_type
    ,business_unit
    ,site property
    ,distributor
    ,ad_format
    ,advertiser_name
    ,line_item_id
    ,line_item_name
    ,'N/A' show_name
    ,product_name
    ,ad_unit_id site_section_or_ad_unit_id
    ,ad_unit_name site_section_or_ad_unit_name
    ,total_unmatched_ad_requests
    ,sum(capped_total_delivery) capped_total_delivery
    ,sum(total_impressions) total_impressions
    ,sum(sold_impressions) sold_impressions

 from fox_bi_qa.gold_ad_sales.ft_gam_summary_daily
 where ad_date < current_date() 
 group by all)

 ---- Freewheel Delivery Data
 , fw_del_data as (
select
     ft.event_date
    ,ft.custom_platform 
    ,ft.custom_platform_group 
    ,CASE WHEN lower(ft.placement_type) = 'promo' or ft.advertiser_name ilike 'FOXSPORTS.COM'
          THEN CONCAT('Promo ', COALESCE(lkpp.delivery_priority_type_point_in_time, p.placement_priority))
          ELSE ft.custom_business_type 
     END business_type
    ,ft.custom_vertical 
    ,ft.custom_property property
    ,ft.custom_distributor distributor
    ,CASE WHEN ft.custom_vertical = 'SPORTS' AND ft.video_vertical ilike 'LFV'
          THEN 'LFV'
          WHEN ft.custom_vertical = 'SPORTS' AND ft.video_vertical ilike 'SFV'
          THEN 'SFV'
          ELSE ft.custom_ad_format
     END as ad_format
    ,ft.custom_advertiser_name advertiser_name
    ,ft.video_vertical 
    ,ft.platform_name
    ,ft.specific_device
    ,ft.device_name
    -- ,placement_id,deal_id,sold_order_id,exchange_listing_id,mrm_rule_id
    -- ,placement_name,deal_name,sold_order_name,exchange_listing_name,mrm_rule_name
    ,coalesce(ft.placement_id,ft.deal_id,ft.sold_order_id,ft.exchange_listing_id,ft.mrm_rule_id) line_item_id
    ,coalesce(ft.placement_name,ft.deal_name,ft.sold_order_name,ft.exchange_listing_name,ft.mrm_rule_name) line_item_name
    ,ft.site_section_id site_section_or_ad_unit_id
    ,ft.site_section_name site_section_or_ad_unit_name
    ,ft.show_name
    ,ft.product_name
    ,ft.placement_type
    ,ft.estimated_demo_comp_vpvh planned_demo_comp
    ,ft.placement_delivered_demo_comp demo_comp
    ,ft.creative_duration_secs creative_duration
    ,ft.global_ad_unit_position
    ,ft.delivery_category
    ,ft.demo_band
    ,ft.net_unit_cost AOS_CPM
    ,sum(ft.net_counted_ads) net_counted_ads
    ,sum(ft.inventory_share_impressions) inventory_share_impressions
    ,sum(ft.run_revenue_amount) run_revenue_amount
 from fox_bi_qa.gold_ad_sales.ft_freewheel_delivery_daily ft
 LEFT JOIN fox_bi_dev.silver_ads.dim_freewheel_analytics_placement p
 ON ft.placement_id = p.placement_id
 LEFT JOIN fox_bi_dev.silver_ads.lkp_freewheel_analytics_placement lkpp
 ON ft.event_date = lkpp.event_date
 AND ft.placement_id = lkpp.placement_id
 group by all
 )

 -- Freewhel Capacity Data
 , fw_capacity_data as
 (
    SELECT 
     cap.event_date
    ,cap.custom_platform 
    ,cap.custom_platform_group
    ,'N/A' business_type
    ,cap.custom_vertical 
    ,cap.video_vertical
    ,cap.custom_property
    ,cap.custom_distributor distributor
    ,CASE WHEN cap.custom_vertical = 'SPORTS' AND cap.video_vertical ilike 'LFV'
          THEN 'LFV'
          WHEN cap.custom_vertical = 'SPORTS' AND cap.video_vertical ilike 'SFV'
          THEN 'SFV'
          ELSE cap.custom_ad_format
     END as custom_ad_format
    ,cap.show_name
    ,cap.site_section_id site_section_or_ad_unit_id
    ,cap.site_section_name site_section_or_ad_unit_name
    ,cap.platform_name
    ,CASE
         WHEN cap.site_section_name LIKE '%: CTV:%' THEN 'CTV'
         WHEN cap.site_section_name LIKE '%: STB%' THEN 'STB'
         WHEN cap.site_section_name LIKE '%Comcast Production%' THEN 'STB'
         WHEN cap.site_section_name LIKE '%: Mobile App:%' THEN 'MB/TB'
         WHEN cap.site_section_name LIKE '%Handheld%' THEN 'MB/TB'
         WHEN cap.site_section_name LIKE '%Tablet%' THEN 'MB/TB'
         WHEN cap.site_section_name LIKE '%: Web%' THEN 'DT'
         WHEN cap.site_section_name LIKE '%Desktop%' THEN 'DT'
         ELSE 'Unk'
      END AS device_name
    ,CASE
         WHEN cap.site_section_name LIKE '%:%' THEN
             CASE
                 WHEN cap.platform_group = 'Off-Platform' THEN SPLIT_PART(cap.site_section_name, ':', 6)
                 ELSE SPLIT_PART(cap.site_section_name, ':', 5)
             END
         ELSE 'N/A'
     END AS specific_device
    ,sum(cap.net_counted_ads) net_counted_ads
    ,sum(cap.historical_unfilled_ad_opportunities) historical_unfilled_ad_opportunities
    ,del.net_counted_ads net_counted_ads_without_affiliates
    from fox_bi_qa.gold_ad_sales.ft_freewheel_capacity_summary_daily cap
    left join 
    (SELECT
        event_date,
        site_section_id,
        show_name,
        custom_vertical,
        video_vertical,
        custom_property,
        sum(net_counted_ads) AS net_counted_ads
    FROM fox_bi_qa.gold_ad_sales.ft_freewheel_delivery_daily 
    WHERE lower(delivery_category) != 'affiliates' GROUP BY ALL) del
    on cap.event_date = del.event_date
    and cap.site_section_id = del.site_section_id
    and cap.show_name = del.show_name
    and cap.custom_vertical = del.custom_vertical
    and cap.video_vertical = del.video_vertical
    and cap.custom_property = del.custom_property
    group by all
 )

 --- Freewheel FXW Data
 , fw_fxw_data as 
 (
 select 
  event_date
, custom_platform platform
, custom_platform_group platform_group
, 'N/A' business_type
, custom_property property
, custom_distributor distributor
, custom_ad_format ad_format
, custom_vertical as business_unit
, 'N/A' advertiser_name
, 'N/A' line_item_name
, 'N/A' product_name
, site_section_id site_section_or_ad_unit_id
, site_section_name site_section_or_ad_unit_name
, sum(net_ad_requests) net_ad_requests
 from fox_bi_qa.gold_ad_sales.ft_freewheel_fxw_capacity_daily
 where site_section_name ilike '%weather%'
 group by all
 )
 ,spring_serve_data as 
 (

 select 

 'Spring Serve' as data_source
,'Spring Serve' as ad_server
,event_date
,platform_name platform
,business_type
,platform_group
,'N/A' business_unit
,site property
,distributor
,ad_format_name ad_format
,advertiser_name
,-1 line_item_id
,'N/A' line_item_name
,'N/A' show_name
,'N/A' product_name
,'-1' as site_section_or_ad_unit_id
,site_section_name as site_section_or_ad_unit_name
,sum(delivered_impressions) as sold_impressions
,sum(revenue) as Revenue
,0 as capacity
,0 as custom_capacity
from fox_bi_dev.silver_ads.ft_spring_serve
where lower(supply_router) = 'bidlink'
and advertiser_name = 'FW OneFOX'
group by all

 )
 ----------------------------------------------------------------------
 -- main query ctes
 --GAM
 ,gam_final as 
 (
  select 
  'GAM' data_source
 ,'GAM' ad_server
 ,event_date
 ,platform
 ,business_type
 ,platform_group
 ,business_unit
 ,property
 ,distributor
 ,ad_format
 ,advertiser_name
 ,line_item_id
 ,line_item_name
 ,show_name
 ,product_name
 ,site_section_or_ad_unit_id
 ,site_section_or_ad_unit_name
 ,case 
      when event_date >= '2025-07-01' and UPPER(advertiser_name) in ('BID LINK', 'ONE FOX')
      then 0
      else sold_impressions
   end sold_impressions
 ,case 
      when event_date >= '2025-07-01' and UPPER(advertiser_name) in ('BID LINK', 'ONE FOX')
      then 0
      else capped_total_delivery
   end revenue
 ,case
      when event_date >= '2025-10-01' and UPPER(distributor) = 'SAMSUNG' 
      then 0
      else coalesce(total_impressions,0)+nvl(total_unmatched_ad_requests,0)
   end capacity
 ,0 as custom_capacity
 from gam_data
)
---Freewheel Delivery
, fw_del_final as
(
select
  case 
      when UPPER(video_vertical) IN ('NEWS/BUSINESS','WEATHER')  
      then  'Freewheel News Delivery'
      when UPPER(video_vertical) = 'ENTERTAINMENT'
      then 'Freewheel Entertainment Delivery'
      when UPPER(video_vertical) in ('SPORTS LFV', 'SPORTS SFV', 'DEPORTES' ,'BTN') and lower(delivery_category) != 'affiliates'
      then 'Freewheel Sports Delivery'
  end data_source
--  ,video_vertical,custom_vertical
 ,'Freewheel' ad_server
 ,event_date
 ,case 
      when UPPER(video_vertical) IN ('NEWS/BUSINESS','WEATHER')  
      then custom_platform 
      else specific_device
   end platform
 ,business_type
 ,case 
      when UPPER(video_vertical) IN ('NEWS/BUSINESS','WEATHER') 
      then custom_platform_group
      else device_name
   end platform_group
 ,custom_vertical business_unit
 ,property
 ,case 
      when UPPER(video_vertical) IN ('NEWS/BUSINESS','WEATHER')  
      then distributor 
      else platform_name
   end distributor
 ,ad_format
 ,advertiser_name
 ,line_item_id
 ,line_item_name
 ,show_name
 ,product_name
 ,site_section_or_ad_unit_id
 ,site_section_or_ad_unit_name
 ,case
      when UPPER(placement_type) = 'PROMO' 
      then 0
      when UPPER(video_vertical) IN ('NEWS/BUSINESS','WEATHER') 
      then case 
               when (event_date < '2025-07-01' AND UPPER(site_section_or_ad_unit_name) LIKE '%GAM%')
               then 0
               else net_counted_ads
           end
      else net_counted_ads - inventory_share_impressions
 end sold_impressions
 ,case
      when UPPER(video_vertical) IN ('NEWS/BUSINESS','WEATHER')  
      then case when (event_date < '2025-07-01' AND UPPER(site_section_or_ad_unit_name) LIKE '%GAM%')
                then 0
                else run_revenue_amount
            end
      WHEN product_name iLIKE '%Fluidity%' 
      THEN (planned_demo_comp * run_revenue_amount)
      WHEN delivery_category = 'Direct Guaranteed' AND demo_band != 'Audience Target' 
      THEN (aos_cpm * net_counted_ads) / 1000
      ELSE run_revenue_amount
END revenue
,0 as capacity
,case 
    when UPPER(video_vertical) IN ('NEWS/BUSINESS','WEATHER') 
    then case
               when lower(site_section_or_ad_unit_name) like '%business%' 
                    and lower(site_section_or_ad_unit_name) like '%direc%'
                    and upper(placement_type) = 'PROMO' 
                    and lower(global_ad_unit_position) = 'midroll'
                    and creative_duration < 15 
               then net_counted_ads * (creative_duration / 30)
               else 0
          end
     when UPPER(video_vertical) = 'ENTERTAINMENT'
     then 0
     when upper(video_vertical) = 'SPORTS LFV' 
         and lower(global_ad_unit_position) = 'midroll'
         and upper(placement_type) = 'PROMO'
         and creative_duration < 15 
    then net_counted_ads * (creative_duration / 30)
    else net_counted_ads
end
as custom_capacity
from fw_del_data
where case 
      when UPPER(video_vertical) IN ('NEWS/BUSINESS','WEATHER')  
      then  'Freewheel News Delivery'
      when UPPER(video_vertical) = 'ENTERTAINMENT'
      then 'Freewheel Entertainment Delivery'
      when UPPER(video_vertical) in ('SPORTS LFV', 'SPORTS SFV', 'DEPORTES' ,'BTN') and lower(delivery_category) != 'affiliates'
      then 'Freewheel Sports Delivery'
  end is not null
)

---Freewheel Capacity Delivery
, fw_cap_final as
(
select
  case 
      when UPPER(video_vertical) IN ('NEWS/BUSINESS','WEATHER') 
      then  'Freewheel News Capacity'
      when UPPER(video_vertical) = 'ENTERTAINMENT'
      then 'Freewheel Entertainment Capacity'
      when UPPER(video_vertical) in ('SPORTS LFV', 'SPORTS SFV', 'DEPORTES' ,'BTN')
      then 'Freewheel Sports Capacity'
  end data_source
--  ,video_vertical,custom_vertical
 ,'Freewheel' ad_server
 ,event_date
 ,case 
      when UPPER(video_vertical) IN ('NEWS/BUSINESS','WEATHER')  
      then custom_platform 
      else specific_device
   end platform
 ,business_type
 ,case 
      when UPPER(video_vertical) IN ('NEWS/BUSINESS','WEATHER') 
      then custom_platform_group
      else device_name
   end platform_group
 ,custom_vertical business_unit
 ,custom_property property
 ,case 
      when UPPER(video_vertical) IN ('NEWS/BUSINESS','WEATHER')  
      then distributor 
      else platform_name
   end distributor
 ,custom_ad_format ad_format
 ,'N/A' advertiser_name
 ,-1 line_item_id
 ,'N/A' line_item_name
 ,show_name
 ,'N/A' product_name
 ,site_section_or_ad_unit_id
 ,site_section_or_ad_unit_name
 ,0 as sold_impressions
 ,0 as revenue
 ,case
    when (lower(site_section_or_ad_unit_name) like '%partner%' or lower(site_section_or_ad_unit_name) like '%streaming%') 
         and lower(site_section_or_ad_unit_name) like '%weather%' 
         then 0
    when event_date < '2025-07-01' and upper(site_section_or_ad_unit_name) like '%GAM%' 
         then 0
    when UPPER(video_vertical) IN ('SPRORTS LFV', 'SPORTS SFV', 'DEPORTES' ,'BTN') 
        then net_counted_ads_without_affiliates
    when lower(site_section_or_ad_unit_name) like '%business%' and lower(site_section_or_ad_unit_name) like '%direc%'
        then 0
    else net_counted_ads + historical_unfilled_ad_opportunities
end as capacity
,0 as custom_capacity
from fw_capacity_data
where 
case 
      when UPPER(video_vertical) IN ('NEWS/BUSINESS','WEATHER')  
      then  'Freewheel News Capacity'
      when UPPER(video_vertical) = 'ENTERTAINMENT'
      then 'Freewheel Entertainment Capacity'
      when UPPER(video_vertical) in ('SPORTS LFV', 'SPORTS SFV', 'DEPORTES' ,'BTN')
      then 'Freewheel Sports Capacity'
  end is not null
)
---Freewheel FOX Weather Data
,fw_fxw_final as
(
     select
      'Freewheel Weather Capacity' data_source
     ,'Freewheel' ad_server
     ,event_date
     ,platform
     ,business_type
     ,platform_group
     ,business_unit
     ,property
     ,distributor
     ,ad_format
     ,'N/A' advertiser_name
     ,-1 line_item_id
     ,'N/A' line_item_name
     ,'N/A' show_name
     ,'N/A' product_name
     ,site_section_or_ad_unit_id
     ,site_section_or_ad_unit_name
     ,0 as sold_impressions
     ,0 as revenue
     ,case 
          when event_date >= '2025-10-01' and upper(distributor) = 'ROKU' 
          then net_ad_requests * 3
          when lower(site_section_or_ad_unit_name) like '%weather%' and lower(site_section_or_ad_unit_name) like '%owned%' 
          then 0
          else net_ad_requests * 6
       end as capacity
     ,0 as custom_capacity
     from fw_fxw_data
)

----Union Query
,final_data as
(
(select * from gam_final)
UNION ALL
(select * from fw_del_final)
UNION ALL
(select * from fw_cap_final)
UNION ALL
(select * from fw_fxw_final)
UNION ALL
(select * from spring_serve_data)
)

----Final query
select data_source
,ad_server
,event_date
,platform
,business_type
,platform_group
,business_unit
,property
,distributor
,ad_format
,advertiser_name
,line_item_id
,line_item_name
,show_name
,product_name
,site_section_or_ad_unit_id
,site_section_or_ad_unit_name
,sum(sold_impressions) sold_impressions
,sum(revenue) revenue
,sum(capacity) capacity
,sum(custom_capacity) custom_capacity
from final_data
group by all
"""


unified_data = spark.sql(query)

# COMMAND ----------

unified_data.write.format('delta')\
    .mode('overwrite')\
    .partitionBy('data_source')\
    .option('mergeSchema', 'true')\
    .option('overwriteDynamicPartitions', 'true')\
    .option('delta.enableDeletionVectors', 'false')\
    .option('delta.enableIcebergCompatV2', 'true')\
    .option('delta.universalFormat.enabledFormats', 'iceberg')\
    .option('delta.columnMapping.mode', 'name')\
    .saveAsTable('fox_bi_qa.gold_ad_sales.ft_delivery_capacity_daily')