CREATE OR REPLACE MATERIALIZED VIEW `fox_bi_qa`.`gold_ad_sales`.`mv_ft_delivery_capacity_daily` (
    Data_source STRING,
    Ad_Server STRING,
    Event_Date DATE,
    Platform STRING,
    Business_Type STRING,
    Platform_Group STRING,
    Business_Unit STRING,
    Property STRING,
    Distributor STRING,
    Ad_Format STRING,
    Advertiser_Name STRING,
    Line_Item_ID BIGINT,
    Line_Item_Name STRING,
    Show_Name STRING,
    Product_Name STRING,
    Site_Section_or_Ad_Unit_ID BIGINT,
    Site_Section_or_Ad_Unit_Name STRING,
    Sold_Impressions BIGINT,
    Revenue DOUBLE,
    Capacity BIGINT
  ) AS
(
select
  *
FROM fox_bi_qa.gold_ad_sales.ft_delivery_capacity_daily
  CLUSTER BY
    Data_source,
    event_date
)