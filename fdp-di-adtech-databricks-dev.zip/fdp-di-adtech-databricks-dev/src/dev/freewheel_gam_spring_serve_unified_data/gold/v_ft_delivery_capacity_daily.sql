%sql
CREATE OR REPLACE VIEW `fox_bi_qa`.`gold_ad_sales`.`v_ft_delivery_capacity_daily`
  as (
    Data_source  as `Data_source`,
    Ad_Server  as `Ad_Server`,
    Event_Date  as `Event_Date`,
    nvl(Platform,'N/A')  as `Platform`,
    nvl(Business_Type,'N/A')  as `Business_Type`,
    nvl(Platform_Group,'N/A')  as `Platform_Group`,
    nvl(Business_Unit,'N/A')  as `Business_Unit`,
    nvl(Property,'N/A')  as `Property`,
    nvl(Distributor,'N/A')  as `Distributor`,
    nvl(Ad_Format,'N/A')  as `Ad_Format`,
    nvl(Advertiser_Name,'N/A')  as `Advertiser_Name`,
    nvl(Line_Item_ID,-1)  as `Line_Item_ID`,
    nvl(Line_Item_Name,'N/A')  as `Line_Item_Name`,
    nvl(Show_Name,'N/A')  as `Show_Name`,
    nvl(Product_Name,'N/A')  as `Product_Name`,
    nvl(Site_Section_or_Ad_Unit_ID,-1)  as `Site_Section_or_Ad_Unit_ID`,
    nvl(Site_Section_or_Ad_Unit_Name,'N/A')  as `Site_Section_or_Ad_Unit_Name`,
    nvl(Sold_Impressions,0)  as `Sold_Impressions`,
    nvl(Revenue,0)  as `Revenue`,
    nvl(Capacity,0)  as `Capacity`
  ) AS
(
select
  *
FROM fox_bi_qa.gold_ad_sales.mv_ft_delivery_capacity_daily
)