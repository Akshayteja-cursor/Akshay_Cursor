# Databricks notebook source

# MAGIC %sql
# MAGIC MERGE INTO fox_bi_qa.gold_ad_sales.ft_freewheel_delivery_daily AS tgt
# MAGIC     USING (
# MAGIC     SELECT DISTINCT 
# MAGIC         ps_line_item_id,
# MAGIC         deal_type AS sales_type,
# MAGIC         deal_type_finance AS sales_type_finance,
# MAGIC         sales_order_line_item_id,
# MAGIC         sales_order_line_item_name,
# MAGIC         sales_order_line_item_start_dt::DATE AS sales_order_line_item_start_date,
# MAGIC         sales_order_line_item_end_dt::DATE AS sales_order_line_item_end_date,
# MAGIC         fw_industry AS industry_descr,
# MAGIC         demo_band,
# MAGIC         p2_plus_cpm,
# MAGIC         hh_cpm,
# MAGIC         parent_line_item_id,
# MAGIC         parent_line_item_name,
# MAGIC         est_demo_comp_vpvh,
# MAGIC         billable_third_party_descr,
# MAGIC         is_makegood_flg is_makegood_flag,
# MAGIC         is_added_value_flg is_added_value_flag,
# MAGIC         marketplace_type,
# MAGIC         product_name,
# MAGIC         placement_property,
# MAGIC         package_name,
# MAGIC         owner_name,
# MAGIC         duration,
# MAGIC         external_id AS advertiser_external_id,
# MAGIC         external_id AS agency_external_id,
# MAGIC         TRY_CAST(advertiser_id AS STRING) AS foxipedia_advertiser_id,
# MAGIC         advertiser_name AS foxipedia_advertiser_name,
# MAGIC         foxipedia_advertiser_parent_name AS foxipedia_advertiser_parent_name,
# MAGIC         foxipedia_advertiser_corporate_name AS foxipedia_advertiser_corporate_name,
# MAGIC         TRY_CAST(agency_id AS STRING) AS foxipedia_agency_id,
# MAGIC         agency_name AS foxipedia_agency_name,
# MAGIC         foxipedia_agency_parent_name AS foxipedia_agency_parent_name,
# MAGIC         foxipedia_agency_holding_name AS foxipedia_agency_holding_name,
# MAGIC         advertiser_category,
# MAGIC         TRY_CAST(sales_order_id AS BIGINT) AS AOS_deal_id,
# MAGIC         sales_order_name AS AOS_deal_name,
# MAGIC         DATE(order_start_dt) AS AOS_Deal_start_date,
# MAGIC         DATE(order_end_dt) AS AOS_Deal_end_date,
# MAGIC         advertiser_name AS AOS_advertiser_name,
# MAGIC         advertiser_name ||' - '|| order_start_dt || ' - '|| order_end_dt AS Campaign_Name_Derived ,
# MAGIC         TRY_CAST(net_unit_cost_amt AS DECIMAL(38,6)) AS net_unit_cost,
# MAGIC         sales_order_line_items_qty AS guaranteed_qty,
# MAGIC         TRY_CAST(contracted_amount_net_lifetime AS DECIMAL(38,6)) AS guaranteed_revenue,
# MAGIC         primary_salesperson_name,
# MAGIC         account_coordinator,
# MAGIC         source source_aos_op1,
# MAGIC         fw_audience_segment,
# MAGIC         fw_video_group,
# MAGIC         primary_property,
# MAGIC         opportunity_unique_id,
# MAGIC         cost_method_name,
# MAGIC         unit_type  ,
# MAGIC         fw_rbp_advanced,
# MAGIC         buy_type 
# MAGIC     FROM fox_bi_prod.gold_ad_sales.ft_digital_operative_line_date_allocation
# MAGIC     WHERE ps_line_item_id IS NOT NULL
# MAGIC     AND ps_line_item_id NOT IN (237823 ,237818 ,272555 ,237817 ,237812 ,237822 ,237816 ,272554 ,237821 ,237813 ,237814 ,237811 ,237824 ,237819)
# MAGIC     ) AS src
# MAGIC     ON COALESCE(tgt.deal_id, tgt.placement_id) = src.ps_line_item_id
# MAGIC     AND COALESCE(tgt.deal_id, tgt.placement_id) IS NOT NULL
# MAGIC     WHEN MATCHED
# MAGIC         THEN UPDATE SET 
# MAGIC         tgt.sales_type = src.sales_type
# MAGIC         , tgt.finance_sales_type = case when src.sales_type_finance = 'Programmatic Backfill' then 'Exclude' else src.sales_type_finance end
# MAGIC         , tgt.ps_line_item_id = src.ps_line_item_id
# MAGIC         , tgt.sales_order_line_item_id = src.sales_order_line_item_id
# MAGIC         , tgt.sales_order_line_item_name = src.sales_order_line_item_name
# MAGIC         , tgt.sales_order_line_item_start_date = src.sales_order_line_item_start_date
# MAGIC         , tgt.sales_order_line_item_end_date = src.sales_order_line_item_end_date
# MAGIC         , tgt.industry_description = src.industry_descr
# MAGIC         , tgt.demo_band = src.demo_band
# MAGIC         , tgt.p2_plus_cpm = src.p2_plus_cpm
# MAGIC         , tgt.hh_cpm = src.hh_cpm
# MAGIC         , tgt.parent_line_item_id = src.parent_line_item_id
# MAGIC         , tgt.parent_line_item_name = src.parent_line_item_name
# MAGIC         , tgt.estimated_demo_comp_vpvh = src.est_demo_comp_vpvh
# MAGIC         , tgt.billable_third_party_description = src.billable_third_party_descr
# MAGIC         , tgt.is_makegood_flag = src.is_makegood_flag
# MAGIC         , tgt.is_added_value_flag = src.is_added_value_flag
# MAGIC         , tgt.marketplace_type = src.marketplace_type
# MAGIC         , tgt.product_name = src.product_name
# MAGIC         , tgt.placement_property = src.placement_property
# MAGIC         , tgt.package_name = src.package_name
# MAGIC         , tgt.owner_name = src.owner_name
# MAGIC         , tgt.duration = src.duration
# MAGIC         , tgt.advertiser_external_id = src.advertiser_external_id
# MAGIC         , tgt.agency_external_id = src.agency_external_id
# MAGIC         , tgt.foxipedia_advertiser_id = src.foxipedia_advertiser_id
# MAGIC         , tgt.foxipedia_advertiser_name = src.foxipedia_advertiser_name
# MAGIC         , tgt.foxipedia_advertiser_parent_name = src.foxipedia_advertiser_parent_name
# MAGIC         , tgt.foxipedia_advertiser_corporate_name = src.foxipedia_advertiser_corporate_name
# MAGIC         , tgt.foxipedia_agency_id = src.foxipedia_agency_id
# MAGIC         , tgt.foxipedia_agency_name = src.foxipedia_agency_name
# MAGIC         , tgt.foxipedia_agency_parent_name = src.foxipedia_agency_parent_name
# MAGIC         , tgt.foxipedia_agency_holding_name = src.foxipedia_agency_holding_name
# MAGIC         , tgt.advertiser_category = src.advertiser_category
# MAGIC         , tgt.AOS_deal_id = src.AOS_deal_id
# MAGIC         , tgt.AOS_deal_name = src.AOS_deal_name
# MAGIC         , tgt.AOS_Deal_start_date = src.AOS_Deal_start_date
# MAGIC         , tgt.AOS_Deal_end_date = src.AOS_Deal_end_date
# MAGIC         , tgt.AOS_advertiser_name = src.AOS_advertiser_name
# MAGIC         , tgt.Campaign_Name_Derived = src.Campaign_Name_Derived
# MAGIC         , tgt.net_unit_cost = src.net_unit_cost
# MAGIC         , tgt.guaranteed_qty = src.guaranteed_qty
# MAGIC         , tgt.guaranteed_revenue = src.guaranteed_revenue
# MAGIC         , tgt.primary_salesperson_name = src.primary_salesperson_name
# MAGIC         , tgt.account_coordinator = src.account_coordinator
# MAGIC         , tgt.source_aos_op1 = src.source_aos_op1
# MAGIC         , tgt.fw_audience_segment = src.fw_audience_segment
# MAGIC         , tgt.fw_video_group = src.fw_video_group
# MAGIC         , tgt.primary_property = src.primary_property
# MAGIC         , tgt.pitch_id = src.opportunity_unique_id
# MAGIC         , tgt.cost_method_name = src.cost_method_name
# MAGIC         , tgt.unit_type = src.unit_type
# MAGIC         , tgt.fw_rbp_advanced = src.fw_rbp_advanced
# MAGIC         , tgt.buy_type = src.buy_type;
# MAGIC         
# MAGIC         
# MAGIC         MERGE INTO fox_bi_qa.gold_ad_sales.ft_freewheel_delivery_daily AS tgt
# MAGIC         USING (
# MAGIC             WITH fw_base_data AS (                      
# MAGIC                 SELECT
# MAGIC                     event_date,
# MAGIC                     nvl(placement_id, deal_id)                                                                   AS placement_id,
# MAGIC                     max(coalesce(placement_start_timestamp_est::date, deal_start_timestamp_est::date))           AS placement_start_date,
# MAGIC                     max(coalesce(placement_end_timestamp_est::date,  deal_end_timestamp_est::date, current_date())) AS placement_end_date,
# MAGIC                     max(guaranteed_qty)                                                                          AS guaranteed_qty,   -- <-- pick the right rollup (see note)
# MAGIC                     sum(net_counted_ads)                                                                         AS net_counted_ads
# MAGIC                 FROM fox_bi_qa.gold_ad_sales.ft_freewheel_delivery_daily
# MAGIC                 WHERE coalesce(placement_id, deal_id) IS NOT NULL
# MAGIC                   AND ps_line_item_id IS NOT NULL
# MAGIC                 GROUP BY event_date, nvl(placement_id, deal_id)
# MAGIC             )
# MAGIC             SELECT
# MAGIC                 event_date,
# MAGIC                 placement_id,
# MAGIC                 (sum(net_counted_ads) OVER (PARTITION BY placement_id ORDER BY event_date) / guaranteed_qty)
# MAGIC                     / (date_diff(day, placement_start_date, event_date + 1)
# MAGIC                        / date_diff(day, placement_start_date, coalesce(placement_end_date, current_date()) + 1))::decimal(19,2) AS placement_deal_OSI
# MAGIC             FROM fw_base_data
# MAGIC         ) AS src
# MAGIC         ON  tgt.event_date = src.event_date
# MAGIC         AND COALESCE(tgt.placement_id, tgt.deal_id) = src.placement_id
# MAGIC         WHEN MATCHED AND COALESCE(src.placement_deal_OSI, 0) != COALESCE(tgt.placement_deal_OSI, 0)
# MAGIC         THEN UPDATE SET tgt.placement_deal_OSI = src.placement_deal_OSI
# MAGIC         