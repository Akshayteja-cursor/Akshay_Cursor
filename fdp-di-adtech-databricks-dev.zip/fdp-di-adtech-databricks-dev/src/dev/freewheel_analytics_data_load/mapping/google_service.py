# Databricks notebook source
import json
from retry import retry
import time
from oauth2client.service_account import ServiceAccountCredentials
from googleapiclient.discovery import build

def get_service(secret_dict, scope, service):
    creds = ServiceAccountCredentials.from_json_keyfile_dict(secret_dict, scope)
    if service == 'sheets':
        return build('sheets', 'v4', credentials=creds, cache_discovery=False)
    if service == 'drive':
        return build('drive', 'v3', credentials=creds, cache_discovery=False)

@retry(tries=5, delay=60)
def gsheet_get_data(g_service, file_id, sheet_range):
    data = g_service.spreadsheets().values().get(spreadsheetId=file_id, range=sheet_range).execute()
    return data.get('values', [])

def clear_sheets(g_service, file_id, sheet_range):
    body = {}
    resultClear = g_service.spreadsheets( ).values( ).clear( spreadsheetId=file_id, range=sheet_range,body=body ).execute()

@retry(tries=5, delay=60)
def update_sheet(g_service, file_id, sheet_range, data):
    if type(data[0]) == dict:
        res = [[key for key in data[0].keys()], *[list(idx.values()) for idx in data ]]
    else:
        res = data
    data = {"values": res}
    res = g_service.spreadsheets().values().update(spreadsheetId=file_id,range=sheet_range, valueInputOption='USER_ENTERED', body=data).execute()

def list_to_dict(data_list):
    temp_list = []
    for lst in range(1,len(data_list)):
        temp_dict = dict()
        for item in range(len(data_list[lst])):
            if data_list[lst][item] != '':
                temp_dict[data_list[0][item]] = data_list[lst][item]
        temp_list.append(temp_dict)
    return temp_list