# Databricks notebook source
from pyspark.sql import functions as F
from pyspark.sql import types as T
from datetime import datetime, timedelta

# COMMAND ----------

query = f"""
    SELECT
        ds.event_date
        , ds.distributor_name
        , ds.distributor_id
        , ds.site_section_id
        , ds.video_id
        , ds.series_id
        , au.ad_unit_position AS global_ad_unit_position
        , au.ad_unit_class AS global_ad_unit_class
        , CASE
            WHEN au.ad_unit_class = 'Video Ads' THEN 'Video Ads'
            WHEN au.ad_unit_class = 'Display Ads' THEN 'Display Ads'
            WHEN au.ad_unit_type_name like '%TrueX%' THEN 'TrueX'
        END AS global_ad_unit_category
        , ds.creative_id
        , ds.ad_unit_id
        , ds.placement_id
        , ds.insertion_order_id
        , ds.campaign_id
        , 'Direct Sold' AS sales_channel_type
        , NULL AS reseller_name
        , NULL AS reseller_id
        , NULL AS mrm_rule_id
        --, ds.advertiser_name
        ,  ds.advertiser_id
        , COALESCE(adv.advertiser_name,ds.advertiser_name) as advertiser_name
        , ds.agency_name
        , NULL AS priority_setting
        , NULL AS dsp_name
        , NULL AS trading_desk_name
        , NULL AS buyer_name
        , NULL AS buyer_priority
        , NULL AS deal_id
        , NULL AS programmatic_ad_id
        , NULL AS programmatic_advertiser_id
        , NULL AS programmatic_advertiser_name
        , NULL AS sold_order_id
        , NULL AS sold_order_priority_type
        , NULL AS exchange_listing_id
        , NULL AS exchange_listing_name
        , NULL AS exchange_listing_transaction_type
        , NULL AS exchange_listing_priority
        , NULL AS private_listing_transaction_type
        , NULL AS global_advertiser_name
        , ds.net_counted_ads
        , ds.gross_counted_ads
        , ds.run_revenue
        , ds.ecpm
        , ds.delivered_clicks
        , ds.measurable_video_ads_quartile_impressions
    FROM fox_bi_dev.bronze_ads.freewheel_analytics_direct_sold_delivery ds
    LEFT JOIN fox_bi_dev.silver_ads.dim_freewheel_analytics_ad_unit au
    ON ds.ad_unit_id = au.ad_unit_id
    LEFT JOIN fox_bi_dev.silver_ads.dim_freewheel_analytics_advertiser adv
    ON ds.advertiser_id = adv.advertiser_id
"""

spark.sql(query).createOrReplaceTempView('ft_direct_sold_delivery')

# display ads -> Ad Unit Class = Display Ads
# trueX -> Ad Unit Type Name contains 'TrueX'
# video ads preroll-> Ad Unit Class = Video Ads & Ad Unit Position != midroll
# video ads midroll hulu-> Ad Unit Class = Video Ads & Ad Unit Position = midroll & Site Section Name contains 'hulu'
# video ads midroll non hulu-> Ad Unit Class = Video Ads & Ad Unit Position = midroll & Site Section Name does not contain 'hulu'

# COMMAND ----------

query = f"""
    SELECT
        rs.event_date
        , rs.distributor_name
        , rs.distributor_id
        , rs.site_section_id
        , rs.video_id
        , rs.series_id
        , rs.ad_unit_position AS global_ad_unit_position
        , rs.ad_unit_class AS global_ad_unit_class
        , rs.ad_unit_class AS global_ad_unit_category
        , NULL AS creative_id
        , rs.ad_unit_id
        , NULL AS placement_id
        , NULL AS insertion_order_id
        , NULL AS campaign_id
        , rs.sales_channel_type
        , rs.reseller_name
        , rs.reseller_id
        , rs.mrm_rule_id
        , NULL as advertiser_id
        , NULL AS advertiser_name
        , NULL AS agency_name
        , mr.priority_setting
        , NULL AS dsp_name
        , NULL AS trading_desk_name
        , NULL AS buyer_name
        , NULL AS buyer_priority
        , NULL AS deal_id
        , NULL AS programmatic_ad_id
        , NULL AS programmatic_advertiser_id
        , NULL AS programmatic_advertiser_name
        , NULL AS sold_order_id
        , NULL AS sold_order_priority_type
        , NULL AS exchange_listing_id
        , NULL AS exchange_listing_name
        , NULL AS exchange_listing_transaction_type
        , NULL AS exchange_listing_priority
        , NULL AS private_listing_transaction_type
        , NULL AS global_advertiser_name
        , rs.net_counted_ads
        , rs.gross_counted_ads
        , rs.run_revenue
        , rs.ecpm
        , rs.delivered_clicks
        , rs.measurable_video_ads_quartile_impressions
    FROM fox_bi_dev.bronze_ads.freewheel_analytics_reseller_delivery rs
    LEFT JOIN fox_bi_dev.silver_ads.dim_freewheel_analytics_mrm_rule mr
    ON rs.mrm_rule_id = mr.mrm_rule_id
"""

spark.sql(query).createOrReplaceTempView('ft_reseller_delivery')

# COMMAND ----------

query = f"""
    SELECT
        md.event_date
        , md.distributor_name
        , md.distributor_id
        , md.site_section_id
        , md.video_id
        , md.series_id
        , md.ad_unit_position AS global_ad_unit_position
        , CASE
            WHEN md.ad_unit_position == 'Display' THEN 'Display Ads'
            ELSE 'Video Ads'
        END AS global_ad_unit_class
        , CASE
            WHEN md.ad_unit_position == 'Display' THEN 'Display Ads'
            ELSE 'Video Ads'
        END AS global_ad_unit_category
        , NULL AS creative_id
        , NULL AS ad_unit_id
        , NULL AS placement_id
        , NULL AS insertion_order_id
        , NULL AS campaign_id
        , 'Programmatic' AS sales_channel_type
        , NULL AS reseller_name
        , NULL AS reseller_id
        , NULL AS mrm_rule_id
        , NULL as advertiser_id
        , NULL AS advertiser_name
        , NULL AS agency_name
        , NULL AS priority_setting
        , md.dsp_name
        , md.trading_desk_name
        , md.invite_buyer_name AS buyer_name
        , md.invite_buyer_priority AS buyer_priority
        , md.deal_id
        , md.programmatic_ad_id
        , md.global_advertiser_id AS programmatic_advertiser_id
        , md.global_advertiser_name AS programmatic_advertiser_name
        , NULL AS sold_order_id
        , NULL AS sold_order_priority_type
        , NULL AS exchange_listing_id
        , NULL AS exchange_listing_name
        , NULL AS exchange_listing_transaction_type
        , NULL AS exchange_listing_priority
        , NULL AS private_listing_transaction_type
        , NULL AS global_advertiser_name
        , md.net_counted_ads
        , md.gross_counted_ads
        , md.run_revenue
        , md.ecpm
        , md.delivered_clicks
        , NULL AS measurable_video_ads_quartile_impressions
    FROM fox_bi_dev.bronze_ads.freewheel_analytics_markets_delivery md
"""

spark.sql(query).createOrReplaceTempView('ft_markets_delivery')

# COMMAND ----------

query = f"""
    SELECT
        mpe.event_date
        , mpe.distributor_name
        , mpe.distributor_id
        , mpe.site_section_id
        , mpe.video_id
        , mpe.series_id
        , mpe.ad_unit_position AS global_ad_unit_position
        , CASE
            WHEN mpe.ad_unit_position == 'Display' THEN 'Display Ads'
            ELSE 'Video Ads'
        END AS global_ad_unit_class
        , CASE
            WHEN mpe.ad_unit_position == 'Display' THEN 'Display Ads'
            ELSE 'Video Ads'
        END AS global_ad_unit_category
        , NULL AS creative_id
        , NULL AS ad_unit_id
        , NULL AS placement_id
        , NULL AS insertion_order_id
        , NULL AS campaign_id
        , mpe.sales_channel_type
        , NULL AS reseller_id
        , NULL AS reseller_name
        , NULL AS mrm_rule_id
        , NULL as advertiser_id
        , NULL AS advertiser_name
        , NULL AS agency_name
        , NULL AS priority_setting
        , NULL AS dsp_name
        , NULL AS trading_desk_name
        , NULL AS buyer_name
        , NULL AS buyer_priority
        , NULL AS deal_id
        , NULL AS programmatic_ad_id
        , NULL AS programmatic_advertiser_id
        , NULL AS programmatic_advertiser_name
        , NULL AS sold_order_id
        , NULL AS sold_order_priority_type
        , mpe.exchange_listing_id
        , mpe.exchange_listing_name
        , mpe.exchange_listing_transaction_type
        , mpe.exchange_listing_priority
        , NULL AS private_listing_transaction_type
        , mpe.global_advertiser_name
        , mpe.net_counted_ads
        , mpe.gross_counted_ads
        , mpe.run_revenue
        , mpe.ecpm
        , mpe.delivered_clicks
        , NULL AS measurable_video_ads_quartile_impressions
    FROM fox_bi_dev.bronze_ads.freewheel_analytics_marketplace_platform_exchange mpe
"""

spark.sql(query).createOrReplaceTempView('ft_marketplace_platform_exchange')

# COMMAND ----------

query = f"""
    SELECT
        mpp.event_date
        , mpp.distributor_name
        , mpp.distributor_id
        , mpp.site_section_id
        , mpp.video_id
        , mpp.series_id
        , mpp.ad_unit_position AS global_ad_unit_position
        , CASE
            WHEN mpp.ad_unit_position == 'Display' THEN 'Display Ads'
            ELSE 'Video Ads'
        END AS global_ad_unit_class
        , CASE
            WHEN mpp.ad_unit_position == 'Display' THEN 'Display Ads'
            ELSE 'Video Ads'
        END AS global_ad_unit_category
        , NULL AS creative_id
        , NULL AS ad_unit_id
        , NULL AS placement_id
        , NULL AS insertion_order_id
        , NULL AS campaign_id
        , mpp.sales_channel_type
        , NULL AS reseller_id
        , NULL AS reseller_name
        , NULL AS mrm_rule_id
        , NULL as advertiser_id
        , NULL AS advertiser_name
        , NULL AS agency_name
        , NULL AS priority_setting
        , NULL AS dsp_name
        , NULL AS trading_desk_name
        , NULL AS buyer_name
        , NULL AS buyer_priority
        , NULL AS deal_id
        , NULL AS programmatic_ad_id
        , NULL AS programmatic_advertiser_id
        , NULL AS programmatic_advertiser_name
        , mpp.sold_order_id
        , so.sold_order_priority_type
        , NULL AS exchange_listing_id
        , NULL AS exchange_listing_name
        , NULL AS exchange_listing_transaction_type
        , NULL AS exchange_listing_priority
        , mpp.private_listing_transaction_type
        , mpp.global_advertiser_name
        , mpp.net_counted_ads
        , mpp.gross_counted_ads
        , mpp.run_revenue
        , mpp.ecpm
        , mpp.delivered_clicks
        , NULL AS measurable_video_ads_quartile_impressions
    FROM fox_bi_dev.bronze_ads.freewheel_analytics_marketplace_platform_private mpp
    LEFT JOIN fox_bi_dev.silver_ads.dim_freewheel_analytics_sold_order so
    ON mpp.sold_order_id = so.sold_order_id
"""

spark.sql(query).createOrReplaceTempView('ft_marketplace_platform_private')

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW ft_fw_delivery AS
# MAGIC SELECT * FROM ft_direct_sold_delivery
# MAGIC UNION ALL
# MAGIC SELECT * FROM ft_reseller_delivery
# MAGIC UNION ALL
# MAGIC SELECT * FROM ft_markets_delivery
# MAGIC UNION ALL
# MAGIC SELECT * FROM ft_marketplace_platform_exchange
# MAGIC UNION ALL
# MAGIC SELECT * FROM ft_marketplace_platform_private

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW promo_show_mapping AS
# MAGIC SELECT
# MAGIC     creative_name
# MAGIC     , series_promoted
# MAGIC     , condition
# MAGIC     , _row as rank
# MAGIC FROM fox_bi_dev.raw_ads.freewheel_gsheet_map_promo_show_mapping

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW creative_map AS
# MAGIC SELECT DISTINCT
# MAGIC     cr.creative_id
# MAGIC     , CASE
# MAGIC         WHEN psm1.rank IS NOT NULL AND psm2.rank IS NULL THEN psm1.creative_name
# MAGIC         WHEN psm2.rank IS NOT NULL AND psm1.rank IS NULL THEN psm2.creative_name
# MAGIC         WHEN psm1.rank IS NULL AND psm2.rank IS NULL THEN NULL
# MAGIC         WHEN psm1.rank <= psm2.rank THEN psm1.creative_name
# MAGIC         WHEN psm2.rank <= psm1.rank THEN psm2.creative_name
# MAGIC     END AS creative_name_map
# MAGIC     , CASE
# MAGIC         WHEN psm1.rank IS NOT NULL AND psm2.rank IS NULL THEN psm1.condition
# MAGIC         WHEN psm2.rank IS NOT NULL AND psm1.rank IS NULL THEN psm2.condition
# MAGIC         WHEN psm1.rank IS NULL AND psm2.rank IS NULL THEN 'NA'
# MAGIC         WHEN psm1.rank <= psm2.rank THEN psm1.condition
# MAGIC         WHEN psm2.rank <= psm1.rank THEN psm2.condition
# MAGIC     END AS condition
# MAGIC     , CASE
# MAGIC         WHEN cr.creative_name IS NULL THEN 'Exclude'
# MAGIC         ELSE
# MAGIC             CASE
# MAGIC                 WHEN psm1.rank IS NOT NULL AND psm2.rank IS NULL THEN psm1.series_promoted
# MAGIC                 WHEN psm2.rank IS NOT NULL AND psm1.rank IS NULL THEN psm2.series_promoted
# MAGIC                 WHEN psm1.rank IS NULL AND psm2.rank IS NULL THEN 'Other / Unknown'
# MAGIC                 WHEN psm1.rank <= psm2.rank THEN psm1.series_promoted
# MAGIC                 WHEN psm2.rank <= psm1.rank THEN psm2.series_promoted
# MAGIC             END
# MAGIC     END AS series_promoted
# MAGIC FROM fox_bi_dev.silver_ads.dim_freewheel_analytics_creative cr
# MAGIC LEFT JOIN (SELECT * FROM promo_show_mapping WHERE condition = 'STARTSWITH') psm1
# MAGIC ON cr.creative_name LIKE REPLACE(psm1.creative_name, '_', '\\_') || '%'
# MAGIC LEFT JOIN (SELECT * FROM promo_show_mapping WHERE condition = 'CONTAINS') psm2
# MAGIC ON cr.creative_name LIKE REPLACE(psm2.creative_name, '_', '\\_') || '%'
# MAGIC WHERE (cr.creative_name, LEAST(psm1.rank, psm2.rank)) IN (
# MAGIC     SELECT
# MAGIC         cr.creative_name,
# MAGIC         MIN(LEAST(psm1.rank, psm2.rank)) AS rank
# MAGIC     FROM
# MAGIC         fox_bi_dev.silver_ads.dim_freewheel_analytics_creative cr
# MAGIC         LEFT JOIN (SELECT * FROM promo_show_mapping WHERE condition = 'STARTSWITH') psm1
# MAGIC         ON cr.creative_name LIKE REPLACE(psm1.creative_name, '_', '\\_') || '%'
# MAGIC         LEFT JOIN (SELECT * FROM promo_show_mapping WHERE condition = 'CONTAINS') psm2
# MAGIC         ON cr.creative_name LIKE '%' || REPLACE(psm2.creative_name, '_', '\\_') || '%'
# MAGIC     GROUP BY
# MAGIC         cr.creative_name
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TEMP VIEW delivery_data AS
# MAGIC SELECT
# MAGIC     /*+ BROADCAST(au, p, lkpp, mr, lkpmr, io, dl, lkpdl, cr, site, vs, cmp, crm, pa, vc, pc, svgmo, ss, svgio, usvg, so, cm, el) */
# MAGIC     ft.event_date
# MAGIC     , ft.distributor_name
# MAGIC     , ft.distributor_id
# MAGIC     , ft.site_section_id
# MAGIC     , site.site_section_name
# MAGIC     , CASE
# MAGIC         WHEN site.site_section_name LIKE '%: CTV:%' THEN 'CTV'
# MAGIC         WHEN site.site_section_name LIKE '%: STB%' THEN 'STB'
# MAGIC         WHEN site.site_section_name LIKE '%Comcast Production%' THEN 'STB'
# MAGIC         WHEN site.site_section_name LIKE '%: Mobile App:%' THEN 'MB/TB'
# MAGIC         WHEN site.site_section_name LIKE '%Handheld%' THEN 'MB/TB'
# MAGIC         WHEN site.site_section_name LIKE '%Tablet%' THEN 'MB/TB'
# MAGIC         WHEN site.site_section_name LIKE '%: Web%' THEN 'DT'
# MAGIC         WHEN site.site_section_name LIKE '%Desktop%' THEN 'DT'
# MAGIC         ELSE 'Unk'
# MAGIC     END AS device_name
# MAGIC     , CASE
# MAGIC         WHEN site.site_section_name like '%Fox One%' THEN 'Fox One'
# MAGIC         WHEN site.site_section_name like '%foxone%' THEN 'Fox One'
# MAGIC         WHEN site.site_section_name like '%Charter: Programmer VOD%' THEN 'STB VOD'
# MAGIC         WHEN site.site_section_name like '%Cox: Legacy Live%' THEN 'STB VOD'
# MAGIC         WHEN site.site_section_name like '%Cox: Watermark C2%' THEN 'STB VOD'
# MAGIC         WHEN site.site_section_name like '%Comcast%IP STB VOD%' THEN 'STB VOD'
# MAGIC         WHEN site.site_section_name like '%: Canoe%' THEN 'STB VOD'
# MAGIC         WHEN site.site_section_name LIKE '%FNC%' THEN 'FNC'
# MAGIC         WHEN site.site_section_name LIKE '%FBN%' THEN 'FBN'
# MAGIC         WHEN site.site_section_name LIKE '%FOX Nation%' THEN 'FOX Nation'
# MAGIC         WHEN site.site_section_name LIKE '%Hulu%' THEN 'Hulu'
# MAGIC         WHEN site.site_section_name LIKE '%Tubi%' THEN 'Tubi'
# MAGIC         WHEN site.site_section_name LIKE '%: STB%' THEN 'STB VOD'
# MAGIC         WHEN site.site_section_name LIKE '%Comcast Production%' THEN 'STB VOD'
# MAGIC         WHEN site.site_section_name LIKE '%Partner%' THEN 'Off-Platform'
# MAGIC         WHEN site.site_section_name LIKE '%Run Of Site%' THEN 'Off-Platform'
# MAGIC         WHEN site.site_section_name LIKE '%Owned%' THEN 'O&O'
# MAGIC         ELSE 'Other'
# MAGIC      END AS platform_group
# MAGIC     , CASE
# MAGIC         WHEN site.site_section_name LIKE '%Fox News%' THEN 'Fox News'
# MAGIC         WHEN site.site_section_name LIKE '%Fox Business%' THEN 'Fox Business'
# MAGIC         WHEN site.site_section_name LIKE '%Fox Weather%' THEN 'Fox Weather'
# MAGIC         ELSE 'Other'
# MAGIC     END AS site_news_one_fox
# MAGIC     , CASE
# MAGIC         WHEN site.site_section_name LIKE '%Run Of Site%' THEN
# MAGIC             CASE
# MAGIC                 WHEN site.site_section_name LIKE '%Fubo%' THEN 'FuboTV'
# MAGIC                 ELSE SPLIT_PART(SUBSTRING(site.site_section_name FROM 34), ' ', 1)
# MAGIC             END
# MAGIC         WHEN site.site_section_name LIKE '%SS: Owned: %' THEN SPLIT_PART(SUBSTRING(site.site_section_name FROM 12), ':', 1)
# MAGIC         WHEN site.site_section_name LIKE '%SS: Partner: %' THEN SPLIT_PART(SUBSTRING(site.site_section_name FROM 14), ':', 1)
# MAGIC         WHEN site.site_section_name LIKE '%Charter: Programmer VOD%' THEN 'Canoe'
# MAGIC         WHEN site.site_section_name LIKE '%Cox: Legacy Live%' THEN 'Canoe'
# MAGIC         WHEN site.site_section_name LIKE '%Cox: Watermark C2%' THEN 'Canoe'
# MAGIC         WHEN site.site_section_name LIKE '%Comcast%IP STB VOD%' THEN 'Canoe'
# MAGIC     END AS platform_name
# MAGIC     , CASE
# MAGIC         WHEN site.site_section_name LIKE '%FNC%' THEN 'FNC'
# MAGIC         WHEN site.site_section_name LIKE '%FBN%' THEN 'FBN'
# MAGIC         ELSE 'Others'
# MAGIC     END AS site_short_name
# MAGIC     , CASE
# MAGIC         WHEN site.site_section_name LIKE '%Live: FOX%' THEN 'T'
# MAGIC         ELSE 'F'
# MAGIC     END AS is_live_fox_ss
# MAGIC     , CASE
# MAGIC         WHEN site.site_section_name LIKE '%VOD%' THEN 'T'
# MAGIC         ELSE 'F'
# MAGIC     END AS is_fep
# MAGIC     , CASE
# MAGIC         WHEN site.site_section_name LIKE '%Live%' THEN 'T'
# MAGIC         ELSE 'F'
# MAGIC     END AS is_go
# MAGIC     , CASE
# MAGIC         WHEN site.site_section_name LIKE '%FOXNOW%' THEN 'Y'
# MAGIC         ELSE 'N'
# MAGIC     END AS is_fox_now
# MAGIC     , CASE
# MAGIC         WHEN site.site_section_name LIKE '%:%' THEN
# MAGIC             CASE
# MAGIC                 WHEN platform_group = 'Off-Platform' THEN SPLIT_PART(site.site_section_name, ':', 6)
# MAGIC                 ELSE SPLIT_PART(site.site_section_name, ':', 5)
# MAGIC             END
# MAGIC         ELSE 'N/A'
# MAGIC     END AS specific_device
# MAGIC     , CASE
# MAGIC         WHEN LOWER(site.site_section_name) LIKE '%vod%' THEN 'VOD'
# MAGIC         WHEN LOWER(site.site_section_name) LIKE '%run of site%' THEN 'Unk'
# MAGIC         WHEN LOWER(site.site_section_name) LIKE '%live%' THEN 'Live'
# MAGIC         ELSE 'Unk'
# MAGIC     END AS stream_type
# MAGIC     , ft.video_id
# MAGIC     , vc.video_name
# MAGIC     , vc.video_duration
# MAGIC     ,CASE 
# MAGIC         WHEN UPPER(ft.global_ad_unit_category) = 'DISPLAY ADS' THEN 'Display'
# MAGIC         WHEN LOWER(vs.series_name) LIKE '%deportes%' THEN 'Deportes'
# MAGIC         WHEN vc.primary_video_group_id = '18773867' THEN 'BTN'
# MAGIC         WHEN LOWER(vs.series_name) LIKE '%monarch%' THEN 'Entertainment'
# MAGIC         
# MAGIC         -- Weather Logic
# MAGIC         WHEN LOWER(vs.series_name) LIKE '%fox weather%' 
# MAGIC              OR LOWER(site.site_section_name) LIKE '%fox weather%' THEN 'Weather'
# MAGIC         
# MAGIC         -- News/Business Logic
# MAGIC         WHEN vc.primary_video_group_id IN ('20474534', '20474467')
# MAGIC              OR LOWER(vs.series_name) LIKE '%vs: news%'
# MAGIC              OR LOWER(vs.series_name) LIKE '%vs: fnc%'
# MAGIC              OR LOWER(vs.series_name) LIKE '%vs: fbn%'
# MAGIC              OR LOWER(vs.series_name) LIKE '%: fnc%'
# MAGIC              OR LOWER(vs.series_name) LIKE '%: fbn%'
# MAGIC              OR LOWER(vs.series_name) LIKE '%: fox business%'
# MAGIC              OR LOWER(site.site_section_name) LIKE '%fox news app%'
# MAGIC              OR LOWER(site.site_section_name) LIKE '%fnc%'
# MAGIC              OR LOWER(site.site_section_name) LIKE '%fbn%'
# MAGIC              OR LOWER(site.site_section_name) LIKE '%fox business%' THEN 'News/Business'
# MAGIC         
# MAGIC         -- Fox Nation Logic
# MAGIC         WHEN LOWER(vs.series_name) LIKE '%vs: nation%'
# MAGIC              OR LOWER(site.site_section_name) LIKE '%fox nation%' THEN 'Fox Nation'
# MAGIC         WHEN site.site_section_name LIKE '%Fox One%' AND site.site_section_name LIKE '%Nation%' THEN 'Fox Nation'
# MAGIC         
# MAGIC         WHEN LOWER(site.site_section_name) LIKE '%tmz%' THEN 'TMZ'
# MAGIC         WHEN LOWER(site.site_section_name) LIKE '%outkick app%' THEN 'Outkick'
# MAGIC         WHEN LOWER(vs.series_name) LIKE '%ultimate tag%' THEN 'Entertainment'
# MAGIC         WHEN vc.primary_video_group_id = '18698796' THEN 'Sports SFV'
# MAGIC         
# MAGIC         WHEN vc.primary_video_group_id = '414462094' OR vc.video_name LIKE '%NIVA%' THEN 'NIVA'
# MAGIC         
# MAGIC         -- Sports LFV Logic
# MAGIC         WHEN vc.primary_video_group_id IN ('18698781', '241987048', '241987474')
# MAGIC              OR UPPER(vs.series_name) LIKE '%WWE%'
# MAGIC              OR UPPER(vs.series_name) LIKE '%SMACKDOWN%'
# MAGIC              OR UPPER(vs.series_name) LIKE '%VS: SPORTS%' THEN 'Sports LFV'
# MAGIC         
# MAGIC         -- Entertainment Logic
# MAGIC         WHEN vc.primary_video_group_id = '18652208'
# MAGIC              OR LOWER(site.site_section_name) LIKE '%fox ent%'
# MAGIC              OR LOWER(vs.series_name) LIKE '%vs: ent: fox:%' THEN 'Entertainment'
# MAGIC         
# MAGIC         WHEN vc.primary_video_group_id = '18698699' THEN 'Entertainment SFV'
# MAGIC         
# MAGIC         -- Fox One Cross-Sells
# MAGIC         WHEN site.site_section_name LIKE '%Fox One%' AND site.site_section_name LIKE '%ENT%' THEN 'Entertainment'
# MAGIC         WHEN site.site_section_name LIKE '%Fox One%' AND site.site_section_name LIKE '%Sports%' THEN 'Sports LFV'
# MAGIC         WHEN site.site_section_name LIKE '%Fox One%' AND site.site_section_name LIKE '%Weather%' THEN 'Weather'
# MAGIC         WHEN site.site_section_name LIKE '%Fox One%' AND site.site_section_name LIKE '%Business%' THEN 'News/Business'
# MAGIC         WHEN site.site_section_name LIKE '%Fox One%' AND site.site_section_name LIKE '%News%' THEN 'News/Business'
# MAGIC         
# MAGIC         -- Tubi Specific Logic
# MAGIC         WHEN UPPER(site.site_section_name) LIKE '%TUBI%' AND vs.series_name = 'Unknown Series' THEN
# MAGIC             CASE 
# MAGIC                 WHEN vc.video_name LIKE '%FOX Entertainment%' THEN 'Entertainment'
# MAGIC                 WHEN LOWER(vc.video_name) LIKE '%gordon ramsay%' THEN 'Entertainment'
# MAGIC                 WHEN LOWER(vc.video_name) LIKE '%masterchef%' THEN 'Entertainment'
# MAGIC                 WHEN LOWER(vc.video_name) LIKE "%hell's kitchen%" THEN 'Entertainment'
# MAGIC                 WHEN LOWER(vc.video_name) LIKE '%masked singer%' THEN 'Entertainment'
# MAGIC                 WHEN vc.video_name LIKE '%FOX Sports%' THEN 'Sports LFV'
# MAGIC                 WHEN vc.video_name LIKE '%FOX News%' THEN 'News/Business'
# MAGIC                 WHEN vc.video_name LIKE '%FOX Weather%' THEN 'Weather'
# MAGIC                 ELSE 'Tubi' -- Default if within Tubi/Unknown but no video match
# MAGIC             END
# MAGIC             
# MAGIC         WHEN vs.series_name = 'Unknown Series' AND LOWER(vc.video_name) LIKE '%masked singer%' THEN 'Entertainment'
# MAGIC         WHEN LOWER(site.site_section_name) LIKE '%tubi%' THEN 'Tubi'
# MAGIC     
# MAGIC         ELSE 'Unassigned'
# MAGIC     END AS video_vertical
# MAGIC     , CASE
# MAGIC         WHEN video_vertical ='Deportes' OR video_vertical LIKE '%Sports%' THEN (
# MAGIC             CASE
# MAGIC                 WHEN stream_type ='VOD' THEN 'VOD'
# MAGIC                 WHEN site.site_section_name like '%Live: FOX%' THEN 'FBC'
# MAGIC                 WHEN lower(site.site_section_name) like '%live: fbn%' THEN 'FBN'
# MAGIC                 WHEN lower(site.site_section_name) like '%live: btn%' THEN 'BTN'
# MAGIC                 WHEN lower(site.site_section_name) like '%live: deportes%' THEN 'Deportes'
# MAGIC                 WHEN lower(site.site_section_name) like '%fs1%' 
# MAGIC                     OR lower(site.site_section_name) like '%fs2%' 
# MAGIC                     OR lower(site.site_section_name) like '%live: fsp%' 
# MAGIC                     OR (site.site_section_name) like '%Live: FoxDigital%' 
# MAGIC                     OR (site.site_section_name) like '%Live: Fox Digital%' THEN 'FS1/FS2'
# MAGIC                 ELSE 'Unk'
# MAGIC             END
# MAGIC         )
# MAGIC         ELSE 'Unk'
# MAGIC     END as network
# MAGIC     , vc.prefered_video_group
# MAGIC     , vc.primary_video_group_id
# MAGIC     , vc.primary_video_group_name
# MAGIC     , CASE
# MAGIC         WHEN svgio.series_name IS NULL THEN 'Out of Season'
# MAGIC         ELSE 'In Season'
# MAGIC     END AS season_in_out_flag
# MAGIC     , COALESCE(svgmo.season_video_group_id, vc.season_video_group_id) AS season_video_group_id
# MAGIC     , COALESCE(svgmo.season_video_group_name, vc.season_video_group_name) AS season_video_group_name
# MAGIC     , CASE
# MAGIC         WHEN LOWER(vc.secondary_video_group_name) = 'unassigned' AND vc.video_name='V: Partner: Youtube TV: FS1 Live' THEN '18830626'
# MAGIC         WHEN LOWER(vc.secondary_video_group_name) = 'unassigned' AND vc.video_name='V: Partner: Youtube TV: FS2 Live' THEN '18830626'
# MAGIC         WHEN LOWER(vc.secondary_video_group_name) = 'unassigned' AND LOWER(ss.show_name) = 'studio shows' THEN '18830626'
# MAGIC         WHEN LOWER(vc.secondary_video_group_name) = 'unassigned' THEN COALESCE(usvg.assigned_secondary_video_group_id, vc.secondary_video_group_id)
# MAGIC         ELSE vc.secondary_video_group_id
# MAGIC     END AS secondary_video_group_id
# MAGIC     , CASE
# MAGIC         WHEN LOWER(vc.secondary_video_group_name) = 'unassigned' AND vc.video_name='V: Partner: Youtube TV: FS1 Live' THEN 'VG: SPORTS: Long Form: Talk Shows'
# MAGIC         WHEN LOWER(vc.secondary_video_group_name) = 'unassigned' AND vc.video_name='V: Partner: Youtube TV: FS2 Live' THEN 'VG: SPORTS: Long Form: Talk Shows'
# MAGIC         WHEN LOWER(vc.secondary_video_group_name) = 'unassigned' AND LOWER(ss.show_name) = 'studio shows' THEN 'VG: SPORTS: Long Form: Talk Shows'
# MAGIC         WHEN LOWER(vc.secondary_video_group_name) = 'unassigned' THEN COALESCE(usvg.assigned_secondary_video_group_name, vc.secondary_video_group_name)
# MAGIC         ELSE vc.secondary_video_group_name
# MAGIC     END AS secondary_video_group_name
# MAGIC     , ft.series_id
# MAGIC     , vs.series_name
# MAGIC     , CASE
# MAGIC         WHEN cr.creative_name IS NULL THEN 'Exclude'
# MAGIC         WHEN crm.creative_name_map IS NULL THEN 'Other/Unknown'
# MAGIC         ELSE crm.series_promoted
# MAGIC     END AS series_promoted
# MAGIC     , COALESCE(ss.show_name, 'N/A') AS show_name
# MAGIC     , ft.global_ad_unit_position
# MAGIC     , ft.global_ad_unit_class
# MAGIC     , ft.global_ad_unit_category
# MAGIC     , ft.creative_id
# MAGIC     , cr.creative_name
# MAGIC     , cr.creative_duration_secs
# MAGIC     , crm.condition
# MAGIC     , crm.creative_name_map
# MAGIC     , ft.ad_unit_id
# MAGIC     , au.ad_unit_external_id
# MAGIC     , au.ad_unit_price
# MAGIC     , ft.placement_id
# MAGIC     , p.placement_external_id
# MAGIC     , p.placement_name
# MAGIC     , p.placement_booked_on_target_impression_goal
# MAGIC     , p.placement_budget_model
# MAGIC     , p.placement_pacing
# MAGIC     , p.placement_priority
# MAGIC     , COALESCE(lkpp.delivery_priority_type_point_in_time, p.placement_priority) AS placement_priority_point_in_time
# MAGIC     , p.placement_demographic_data_source
# MAGIC     , p.placement_demographic_on_target_calculation
# MAGIC     , p.placement_forced_over_delivery_percent
# MAGIC     , p.placement_impression_goal
# MAGIC     , p.placement_estimated_impression_goal
# MAGIC     , p.placement_budgeted_impressions
# MAGIC     , p.placement_start_timestamp_est
# MAGIC     , p.placement_end_timestamp_est
# MAGIC     , p.placement_industry
# MAGIC     , p.placement_status
# MAGIC     , p.placement_type
# MAGIC     , p.placement_avg_user_frequency
# MAGIC     , p.unified_yield_name
# MAGIC     , ft.insertion_order_id
# MAGIC     , io.insertion_order_name
# MAGIC     , io.insertion_order_start_timestamp_est
# MAGIC     , io.insertion_order_end_timestamp_est
# MAGIC     , io.insertion_order_external_id
# MAGIC     , io.insertion_order_primary_salesperson
# MAGIC     , io.insertion_order_primary_trafficker
# MAGIC     , io.insertion_order_status
# MAGIC     , ft.campaign_id
# MAGIC     , cmp.campaign_end_timestamp_est
# MAGIC     , cmp.campaign_external_id
# MAGIC     , cmp.campaign_name
# MAGIC     , cmp.campaign_avg_user_frequency
# MAGIC     , cmp.campaign_start_timestamp_est
# MAGIC     , ft.sales_channel_type
# MAGIC     , ft.reseller_id
# MAGIC     , ft.reseller_name
# MAGIC     , ft.mrm_rule_id
# MAGIC     , mr.mrm_rule_name
# MAGIC     , mr.mrm_rule_start_timestamp_est
# MAGIC     , mr.mrm_rule_end_timestamp_est
# MAGIC     , mr.mrm_rule_impression_goal
# MAGIC     , ft.advertiser_id AS advertiser_id
# MAGIC     , TRIM(ft.advertiser_name) AS advertiser_name
# MAGIC     , CASE
# MAGIC         WHEN pa.promo_advertiser IS NOT NULL THEN 'Y'
# MAGIC         ELSE 'N'
# MAGIC     END AS is_promo_advertiser
# MAGIC     , ft.agency_name
# MAGIC     , ft.priority_setting
# MAGIC     , COALESCE(lkpmr.priority_setting_point_in_time, ft.priority_setting) AS priority_setting_point_in_time
# MAGIC     , ft.dsp_name
# MAGIC     , ft.trading_desk_name
# MAGIC     , ft.buyer_name
# MAGIC     , ft.buyer_priority
# MAGIC     , ft.deal_id
# MAGIC     , dl.external_deal_id
# MAGIC     , dl.deal_name
# MAGIC     , lkpdl.deal_type AS deal_type_point_in_time
# MAGIC     , dl.deal_type
# MAGIC     , dl.deal_override_priority
# MAGIC     , dl.deal_start_timestamp_est
# MAGIC     , dl.deal_end_timestamp_est
# MAGIC     , dl.deal_impression_goal
# MAGIC     , dl.deal_salesperson
# MAGIC     , ft.programmatic_ad_id
# MAGIC     , ft.programmatic_advertiser_id
# MAGIC     , ft.programmatic_advertiser_name
# MAGIC     , pc.programmatic_brand_name
# MAGIC     , pc.programmatic_industry_name
# MAGIC     , pc.programmatic_creative_duration
# MAGIC     , ft.sold_order_id
# MAGIC     , so.sold_order_name
# MAGIC     , ft.sold_order_priority_type
# MAGIC     , so.sold_order_avails_in_played_slot
# MAGIC     , so.sold_order_cpm_usd
# MAGIC     , so.sold_order_goal_impressions
# MAGIC     , so.sold_order_pricing_model
# MAGIC     , so.sold_order_type
# MAGIC     , so.sold_order_start_timestamp_est
# MAGIC     , so.sold_order_end_timestamp_est
# MAGIC     , ft.exchange_listing_id
# MAGIC     , ft.exchange_listing_name
# MAGIC     , ft.exchange_listing_transaction_type
# MAGIC     , ft.exchange_listing_priority
# MAGIC     , el.exchange_listing_start_timestamp_est
# MAGIC     , el.exchange_listing_end_timestamp_est
# MAGIC     , ft.private_listing_transaction_type
# MAGIC     , ft.global_advertiser_name
# MAGIC     , CASE
# MAGIC         WHEN ft.sales_channel_type = 'Direct Sold' THEN
# MAGIC             CASE
# MAGIC                 WHEN ft.advertiser_name = 'AMAZON APS' THEN
# MAGIC                     CASE
# MAGIC                         WHEN (io.insertion_order_name LIKE '%Guaranteed%' OR placement_priority_point_in_time LIKE '%Guaranteed%') THEN 'Programmatic Guaranteed'
# MAGIC                         ELSE 'Backfill'
# MAGIC                     END
# MAGIC                 WHEN TRIM(ft.advertiser_name) IN (SELECT DISTINCT promo_advertiser FROM fox_bi_dev.raw_ads.freewheel_gsheet_map_promo_advertiser) THEN CONCAT('Promo ', placement_priority_point_in_time)
# MAGIC                 WHEN p.placement_name LIKE '%Amobee%' OR p.placement_name LIKE '%B2B%' THEN 'Programmatic Guaranteed'
# MAGIC                 ELSE CONCAT('Direct ', placement_priority_point_in_time)
# MAGIC             END
# MAGIC         WHEN ft.sales_channel_type = 'Reseller Sold' THEN
# MAGIC             CASE
# MAGIC                 WHEN ft.reseller_name LIKE '%Fox Affiliates Live%' THEN 'Affiliates'
# MAGIC                 WHEN mr.mrm_rule_name LIKE '%Inventory Share%' THEN 'Inventory Share'
# MAGIC                 WHEN COALESCE(lkpmr.priority_setting_point_in_time, ft.priority_setting) LIKE '%HARD_GUARANTEE%' THEN 'Hard Guaranteed'
# MAGIC                 ELSE 'Backfill'
# MAGIC             END
# MAGIC         WHEN ft.sales_channel_type = 'Programmatic' THEN
# MAGIC             CASE
# MAGIC                 WHEN lkpdl.deal_type IN ('DEAL', 'BACKFILL_DEAL', 'Backfill Deal', 'Deal') THEN 'Backfill'
# MAGIC                 WHEN lkpdl.deal_type IN ('FIRST_LOOK_DEAL', 'First Look','Biddable Guaranteed') THEN 'Hard Guaranteed'
# MAGIC                 WHEN lkpdl.deal_type IS NULL THEN
# MAGIC                     CASE 
# MAGIC                       WHEN dl.deal_type IN ('DEAL', 'BACKFILL_DEAL', 'Backfill Deal', 'Deal') THEN 'Backfill'
# MAGIC                       WHEN dl.deal_type IN ('FIRST_LOOK_DEAL', 'First Look', 'Biddable Guaranteed') THEN 'Hard Guaranteed'
# MAGIC                       ELSE 'Programmatic Guaranteed'
# MAGIC                     END
# MAGIC                 ELSE 'Programmatic Guaranteed'
# MAGIC             END
# MAGIC         WHEN ft.sales_channel_type = 'Marketplace Platform Private' THEN
# MAGIC             CASE
# MAGIC                 WHEN so.sold_order_name LIKE '%[Inventory Share]%' THEN 'Inventory Share'
# MAGIC                 WHEN so.sold_order_name LIKE '%Fox Affiliates%' THEN 'Affiliates'
# MAGIC                 WHEN ft.private_listing_transaction_type == 'Guaranteed' THEN 'Hard Guaranteed'
# MAGIC                 ELSE 'Backfill'
# MAGIC             END
# MAGIC         WHEN ft.sales_channel_type = 'Marketplace Platform Exchange' THEN
# MAGIC             CASE
# MAGIC                 WHEN ft.exchange_listing_transaction_type = 'Guaranteed' THEN 'Hard Guaranteed'
# MAGIC                 ELSE 'Backfill'
# MAGIC             END
# MAGIC         ELSE NULL
# MAGIC     END AS delivery_category
# MAGIC     , cm.budget_sheet_sport_categories AS sports_category
# MAGIC     , dl.deal_ad_units
# MAGIC     , ft.net_counted_ads
# MAGIC     , ft.gross_counted_ads
# MAGIC     , ft.run_revenue AS run_revenue_amount
# MAGIC     , ft.ecpm AS ecpm_amount
# MAGIC     , ft.delivered_clicks
# MAGIC     , ft.measurable_video_ads_quartile_impressions
# MAGIC     , CASE WHEN delivery_category = 'Direct Guaranteed' THEN ft.net_counted_ads ELSE 0 END AS direct_guaranteed_impressions
# MAGIC     , CASE WHEN delivery_category = 'Direct Preemptible' THEN ft.net_counted_ads ELSE 0 END AS direct_pre_emptible_impressions
# MAGIC     , CASE WHEN delivery_category = 'Promo Guaranteed' THEN ft.net_counted_ads ELSE 0 END AS promo_guaranteed_impressions
# MAGIC     , CASE WHEN delivery_category = 'Promo Preemptible' THEN ft.net_counted_ads ELSE 0 END AS promo_pre_emptible_impressions
# MAGIC     , CASE WHEN delivery_category = 'Programmatic Guaranteed' THEN ft.net_counted_ads ELSE 0 END AS programmatic_guaranteed_impressions
# MAGIC     , CASE WHEN delivery_category = 'Inventory Share' THEN ft.net_counted_ads ELSE 0 END AS inventory_share_impressions
# MAGIC     , CASE WHEN delivery_category = 'Affiliates' THEN ft.net_counted_ads ELSE 0 END AS affiliates_impressions
# MAGIC     , CASE WHEN delivery_category = 'Hard Guaranteed' THEN ft.net_counted_ads ELSE 0 END AS hard_guaranteed_impressions
# MAGIC     , CASE WHEN delivery_category = 'Backfill' THEN ft.net_counted_ads ELSE 0 END AS backfill_impressions
# MAGIC     , CASE WHEN cr.creative_duration_secs >= 15 THEN promo_guaranteed_impressions ELSE 0 END AS promo_guaranteed_monetizable_impressions
# MAGIC     , CASE WHEN cr.creative_duration_secs IS NULL OR cr.creative_duration_secs < 15 THEN promo_guaranteed_impressions ELSE 0 END AS promo_guaranteed_unmonetizable_impressions
# MAGIC     , CASE WHEN cr.creative_duration_secs >= 15 THEN promo_pre_emptible_impressions ELSE 0 END AS promo_pre_emptible_monetizable_impressions
# MAGIC     , CASE WHEN cr.creative_duration_secs IS NULL OR cr.creative_duration_secs < 15 THEN promo_pre_emptible_impressions ELSE 0 END AS promo_pre_emptible_unmonetizable_impressions
# MAGIC     ,CASE
# MAGIC             WHEN LOWER(site.site_section_name) LIKE '%android tv%'       THEN 'Android TV'
# MAGIC             WHEN LOWER(site.site_section_name) LIKE '%androidtv%'        THEN 'Android TV'
# MAGIC             WHEN LOWER(site.site_section_name) LIKE '%apple%'            THEN 'Apple TV'
# MAGIC             WHEN LOWER(site.site_section_name) LIKE '%fire%'             THEN 'Amazon TV'
# MAGIC             WHEN LOWER(site.site_section_name) LIKE '%roku%'             THEN 'Roku'
# MAGIC             WHEN LOWER(site.site_section_name) LIKE '%mobile app: android%' THEN 'Android App'
# MAGIC             WHEN LOWER(site.site_section_name) LIKE '%android phone%'    THEN 'Android App'
# MAGIC             WHEN LOWER(site.site_section_name) LIKE '%android tablet%'   THEN 'Android App'
# MAGIC             WHEN LOWER(site.site_section_name) LIKE '%ios%'              THEN 'iOS App'
# MAGIC             WHEN LOWER(site.site_section_name) LIKE '%ipad%'             THEN 'iOS App'
# MAGIC             WHEN LOWER(site.site_section_name) LIKE '%iphone%'           THEN 'iOS App'
# MAGIC             WHEN LOWER(site.site_section_name) LIKE '%mobile app%'       THEN 'Mobile App'
# MAGIC             WHEN LOWER(site.site_section_name) LIKE '%mobile web%'       THEN 'Mobile Web'
# MAGIC             WHEN LOWER(site.site_section_name) LIKE '%tablet web%'       THEN 'Tablet Web'
# MAGIC             WHEN LOWER(site.site_section_name) LIKE '%mobile tablet%'    THEN 'Mobile Web'
# MAGIC             WHEN LOWER(site.site_section_name) LIKE '%mobile handheld%'  THEN 'Mobile Web'
# MAGIC             WHEN LOWER(site.site_section_name) LIKE '%desktop%'          THEN 'Desktop Web'
# MAGIC             WHEN LOWER(site.site_section_name) LIKE '%web%'              THEN 'Web'
# MAGIC             WHEN LOWER(site.site_section_name) LIKE '%amp%'              THEN 'AMP'
# MAGIC             WHEN LOWER(site.site_section_name) LIKE '%ctv%'              THEN 'Other CTV'
# MAGIC             ELSE 'Unknown'
# MAGIC     END AS custom_platform
# MAGIC     ,CASE 
# MAGIC             WHEN LOWER(custom_platform) = "android tv"  THEN "CTV"
# MAGIC             WHEN LOWER(custom_platform) = "apple tv"    THEN "CTV"
# MAGIC             WHEN LOWER(custom_platform) = "amazon tv"   THEN "CTV"
# MAGIC             WHEN LOWER(custom_platform) = "roku"        THEN "CTV"
# MAGIC             WHEN LOWER(custom_platform) = "other ctv"   THEN "CTV"
# MAGIC             WHEN LOWER(custom_platform) LIKE '%app%'    THEN "Mobile Apps"
# MAGIC             WHEN LOWER(custom_platform) = "mobile web"  THEN "Mobile/Tablet Web"
# MAGIC             WHEN LOWER(custom_platform) = "tablet web"  THEN "Mobile/Tablet Web"
# MAGIC             WHEN LOWER(custom_platform) = "amp"         THEN "Mobile/Tablet Web"
# MAGIC             WHEN LOWER(custom_platform) = "desktop web" THEN "Desktop Web"
# MAGIC             WHEN LOWER(custom_platform) = "web"         THEN "Web"
# MAGIC             ELSE "Unknown"
# MAGIC     END AS custom_platform_group
# MAGIC     ,CASE
# MAGIC             WHEN UPPER(dl.deal_type) IN ('PROGRAMMATIC GUARANTEED', 'PROGRAMMATIC_GUARANTEED_TRADING_DESK_DEAL') THEN 'Direct IO'
# MAGIC             --WHEN UPPER(product_name) LIKE '%DR %' THEN 'DR'
# MAGIC             WHEN UPPER(p.placement_priority) LIKE '%PREEMPTIBLE%' THEN 'DR'
# MAGIC             WHEN UPPER(ft.sales_channel_type) = 'DIRECT SOLD' THEN 'Direct IO'
# MAGIC             ELSE 'Programmatic'
# MAGIC     END AS custom_business_type
# MAGIC     ,CASE
# MAGIC             -- Series Name–based rules
# MAGIC             WHEN (UPPER(COALESCE(vs.series_name, '')) LIKE '%FBN%'
# MAGIC                     OR UPPER(COALESCE(vs.series_name, '')) LIKE '%FOX BUSINESS%'
# MAGIC                     OR UPPER(COALESCE(vs.series_name, '')) LIKE '%VS: BUSINESS%') THEN 'FBN'
# MAGIC             WHEN UPPER(COALESCE(vs.series_name, '')) LIKE '%FOX WEATHER%'         THEN 'FXW'
# MAGIC             WHEN UPPER(COALESCE(vs.series_name, '')) LIKE '%NEWS%'                THEN 'FNC'
# MAGIC             WHEN UPPER(COALESCE(vs.series_name, '')) LIKE '%BTN%'                 THEN 'BTN'
# MAGIC             WHEN UPPER(COALESCE(vs.series_name, '')) LIKE '%DEPORTES%'            THEN 'Deportes'
# MAGIC             WHEN UPPER(COALESCE(vs.series_name, '')) LIKE '%SPORTS%'              THEN 'FS'
# MAGIC             WHEN UPPER(COALESCE(vs.series_name, '')) LIKE '%VS: ENT%'             THEN 'ENT'
# MAGIC             WHEN UPPER(COALESCE(vs.series_name, '')) LIKE '%TUBI%'                THEN 'TUBI'
# MAGIC             WHEN UPPER(COALESCE(vs.series_name, '')) LIKE '%VS: NATION%'          THEN 'Fox Nation'
# MAGIC
# MAGIC             -- Site Section Name–based rules
# MAGIC             WHEN (UPPER(COALESCE(site.site_section_name, '')) LIKE '%FOX NEWS%'
# MAGIC                     OR UPPER(COALESCE(site.site_section_name, '')) LIKE '%FNC%')  THEN 'FNC'
# MAGIC             WHEN (UPPER(COALESCE(site.site_section_name, '')) LIKE '%FOX BUSINESS%'
# MAGIC                     OR UPPER(COALESCE(site.site_section_name, '')) LIKE '%FBN%')  THEN 'FBN'
# MAGIC             WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%FOX WEATHER%' THEN 'FXW'
# MAGIC             WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%TMZ%'         THEN 'TMZ'
# MAGIC             WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%OUTKICK%'     THEN 'OKI'
# MAGIC             WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%BTN%'         THEN 'BTN'
# MAGIC             WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%DEPORTES%'    THEN 'Deportes'
# MAGIC             WHEN (UPPER(COALESCE(site.site_section_name, '')) LIKE '%FS%'
# MAGIC                     OR UPPER(COALESCE(site.site_section_name, '')) LIKE '%FOX SPORTS%')
# MAGIC                                                                                   THEN 'FS'
# MAGIC             WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%FOX ENT%'     THEN 'ENT'
# MAGIC
# MAGIC             -- Tubi + Unknown Series + Video Name disambiguation
# MAGIC             WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%TUBI%'
# MAGIC                 AND COALESCE(vs.series_name, '') = 'Unknown Series'
# MAGIC                 AND UPPER(COALESCE(vc.video_name, '')) LIKE '%FOX ENTERTAINMENT%'           THEN 'ENT'
# MAGIC             WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%TUBI%'
# MAGIC                 AND COALESCE(vs.series_name, '') = 'Unknown Series'
# MAGIC                 AND ( UPPER(COALESCE(vc.video_name, '')) LIKE '%FOX SPORTS%'
# MAGIC                         OR UPPER(COALESCE(vc.video_name, '')) LIKE '%ONEFOX VOD SPORTS%' )  THEN 'FS'
# MAGIC             WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%TUBI%'
# MAGIC                 AND COALESCE(vs.series_name, '') = 'Unknown Series'
# MAGIC                 AND UPPER(COALESCE(vc.video_name, '')) LIKE '%FOX NEWS%'                    THEN 'FNC'
# MAGIC             WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%TUBI%'
# MAGIC                 AND COALESCE(vs.series_name, '') = 'Unknown Series'
# MAGIC                 AND UPPER(COALESCE(vc.video_name, '')) LIKE '%FOX WEATHER%'                 THEN 'FXW'
# MAGIC
# MAGIC             -- Remaining Tubi / Fox Nation
# MAGIC             WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%TUBI%'                  THEN 'TUBI'
# MAGIC             WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%FOX NATION%'            THEN 'Fox Nation'
# MAGIC
# MAGIC             ELSE 'Unknown'
# MAGIC     END AS custom_property 
# MAGIC     ,CASE
# MAGIC             WHEN UPPER(custom_property) IN ('FNC', 'FBN', 'FXW', 'TMZ', 'OKI') THEN 'NEWS'
# MAGIC             WHEN UPPER(custom_property) IN ('FS', 'BTN', 'DEPORTES') THEN 'SPORTS'
# MAGIC             WHEN UPPER(custom_property) = 'ENT' THEN 'ENTERTAINMENT'
# MAGIC             WHEN UPPER(custom_property) = 'TUBI' THEN 'TUBI'
# MAGIC             ELSE 'Unknown'
# MAGIC     END AS custom_vertical
# MAGIC     ,CASE
# MAGIC             -- Case 1: SS: Owned
# MAGIC             WHEN site.site_section_name ILIKE '%SS: Owned%' THEN
# MAGIC                 CASE
# MAGIC                 WHEN LOCATE(':', site.site_section_name, 12) > 0 THEN
# MAGIC                     SUBSTRING(
# MAGIC                     site.site_section_name,
# MAGIC                     12,
# MAGIC                     LOCATE(':', site.site_section_name, 12) - 12
# MAGIC                     )
# MAGIC                 ELSE
# MAGIC                     SUBSTRING(
# MAGIC                     site.site_section_name,
# MAGIC                     12,
# MAGIC                     LENGTH(site.site_section_name) - 11
# MAGIC                     )
# MAGIC                 END
# MAGIC
# MAGIC             -- Case 2: SS: Partner
# MAGIC             WHEN site.site_section_name ILIKE '%SS: Partner%' THEN
# MAGIC                 CASE
# MAGIC                 WHEN LOCATE(':', site.site_section_name, 14) > 0 THEN
# MAGIC                     SUBSTRING(
# MAGIC                     site.site_section_name,
# MAGIC                     14,
# MAGIC                     LOCATE(':', site.site_section_name, 14) - 14
# MAGIC                     )
# MAGIC                 ELSE
# MAGIC                     SUBSTRING(
# MAGIC                     site.site_section_name,
# MAGIC                     14,
# MAGIC                     LENGTH(site.site_section_name) - 13
# MAGIC                     )
# MAGIC                 END
# MAGIC
# MAGIC             ELSE NULL
# MAGIC     END AS custom_distributor
# MAGIC     ,CASE 
# MAGIC             WHEN UPPER(site.site_section_name) LIKE '%CLIP%' THEN "SFV" 
# MAGIC             WHEN UPPER(site.site_section_name) LIKE '%SS: OWNED: FOX WEATHER APP: MOBILE APP%' THEN "SFV"
# MAGIC             WHEN UPPER(site.site_section_name) LIKE '%SS: OWNED: FOX WEATHER APP: WEB%' THEN "SFV"
# MAGIC             ELSE "LFV" 
# MAGIC     END AS custom_ad_format
# MAGIC     ,CASE
# MAGIC             WHEN UPPER(ft.sales_channel_type) = 'DIRECT SOLD' THEN TRIM(ft.advertiser_name)
# MAGIC             ELSE TRIM(ft.programmatic_advertiser_name)
# MAGIC     END AS custom_advertiser_name
# MAGIC     ,CASE
# MAGIC             WHEN UPPER(ft.sales_channel_type) = 'DIRECT SOLD' THEN p.placement_name
# MAGIC             ELSE dl.deal_name
# MAGIC     END AS custom_line_item_name
# MAGIC FROM ft_fw_delivery ft
# MAGIC LEFT JOIN fox_bi_dev.silver_ads.dim_freewheel_analytics_ad_unit au
# MAGIC ON ft.ad_unit_id = au.ad_unit_id
# MAGIC LEFT JOIN fox_bi_dev.silver_ads.dim_freewheel_analytics_placement p
# MAGIC ON ft.placement_id = p.placement_id
# MAGIC LEFT JOIN fox_bi_dev.silver_ads.lkp_freewheel_analytics_placement lkpp
# MAGIC ON ft.event_date = lkpp.event_date
# MAGIC AND ft.placement_id = lkpp.placement_id
# MAGIC LEFT JOIN fox_bi_dev.silver_ads.dim_freewheel_analytics_mrm_rule mr
# MAGIC ON ft.mrm_rule_id = mr.mrm_rule_id
# MAGIC LEFT JOIN fox_bi_dev.silver_ads.lkp_freewheel_analytics_mrm_rule lkpmr
# MAGIC ON ft.event_date = lkpmr.event_date
# MAGIC AND ft.mrm_rule_id = lkpmr.mrm_rule_id
# MAGIC LEFT JOIN fox_bi_dev.silver_ads.dim_freewheel_analytics_insertion_order io
# MAGIC ON ft.insertion_order_id = io.insertion_order_id
# MAGIC LEFT JOIN fox_bi_dev.silver_ads.dim_freewheel_analytics_deal dl
# MAGIC ON ft.deal_id = dl.deal_id
# MAGIC LEFT JOIN fox_bi_dev.silver_ads.lkp_freewheel_analytics_deal lkpdl
# MAGIC ON ft.deal_id = lkpdl.deal_id
# MAGIC AND ft.event_date = lkpdl.event_date
# MAGIC LEFT JOIN fox_bi_dev.silver_ads.dim_freewheel_analytics_creative cr
# MAGIC ON ft.creative_id = cr.creative_id
# MAGIC LEFT JOIN (
# MAGIC     SELECT
# MAGIC         *
# MAGIC     FROM fox_bi_dev.silver_ads.dim_freewheel_analytics_site
# MAGIC     WHERE (
# MAGIC         site_section_id
# MAGIC         , site_id
# MAGIC     ) NOT IN (
# MAGIC         SELECT
# MAGIC             dfas.site_section_id
# MAGIC             , -1
# MAGIC         FROM fox_bi_dev.silver_ads.dim_freewheel_analytics_site dfas
# MAGIC         GROUP BY dfas.site_section_id
# MAGIC         HAVING COUNT(*) > 1
# MAGIC     )
# MAGIC ) site
# MAGIC ON ft.site_section_id = site.site_section_id
# MAGIC LEFT JOIN fox_bi_dev.silver_ads.dim_freewheel_analytics_video_series vs
# MAGIC ON ft.series_id = vs.series_id
# MAGIC LEFT JOIN fox_bi_dev.silver_ads.dim_freewheel_analytics_campaign cmp
# MAGIC ON ft.campaign_id = cmp.campaign_id
# MAGIC LEFT JOIN creative_map crm
# MAGIC ON ft.creative_id = crm.creative_id
# MAGIC LEFT JOIN fox_bi_dev.raw_ads.freewheel_gsheet_map_promo_advertiser pa
# MAGIC ON LOWER(TRIM(ft.advertiser_name)) = LOWER(pa.promo_advertiser)
# MAGIC LEFT JOIN fox_bi_dev.silver_ads.dim_freewheel_analytics_video_group_custom vc
# MAGIC ON ft.video_id = vc.video_id
# MAGIC LEFT JOIN fox_bi_dev.silver_ads.dim_freewheel_analytics_programmatic_creative pc
# MAGIC ON ft.programmatic_ad_id = pc.programmatic_ad_id
# MAGIC LEFT JOIN fox_bi_dev.raw_ads.freewheel_gsheet_map_season_video_group_manual_override svgmo
# MAGIC ON vc.video_name = svgmo.video_name
# MAGIC LEFT JOIN fox_bi_prod.silver_ads.freewheel_gsheet_map_series_to_show ss
# MAGIC ON vs.series_name = ss.series_name
# MAGIC LEFT JOIN (
# MAGIC     SELECT DISTINCT
# MAGIC         series_name
# MAGIC         , season_video_group_id
# MAGIC     FROM fox_bi_dev.raw_ads.freewheel_gsheet_map_season_video_group_in_out
# MAGIC     WHERE season_video_group_id NOT ILIKE 'NA'
# MAGIC ) svgio
# MAGIC ON COALESCE(svgmo.season_video_group_id, vc.season_video_group_id) = svgio.season_video_group_id
# MAGIC LEFT JOIN fox_bi_prod.silver_ads.freewheel_gsheet_map_unassigned_secondary_video_group usvg
# MAGIC ON vc.video_name = usvg.video_name
# MAGIC AND vc.primary_video_group_name = usvg.primary_video_group_name
# MAGIC AND vc.secondary_video_group_name = usvg.secondary_video_group_name
# MAGIC AND vs.series_name = usvg.series_name
# MAGIC LEFT JOIN fox_bi_dev.silver_ads.dim_freewheel_analytics_sold_order so
# MAGIC ON ft.sold_order_id = so.sold_order_id
# MAGIC LEFT JOIN fox_bi_dev.silver_ads.dim_freewheel_analytics_exchange_listing el
# MAGIC ON ft.exchange_listing_id = el.exchange_listing_id
# MAGIC LEFT JOIN fox_bi_dev.raw_ads.freewheel_gsheet_map_category_mapping cm
# MAGIC ON LOWER(cm.secondary_video_group_name_from_spencer_s_excel) = LOWER(
# MAGIC     CASE
# MAGIC         WHEN LOWER(vc.secondary_video_group_name) = 'unassigned' AND vc.video_name='V: Partner: Youtube TV: FS1 Live' THEN 'VG: SPORTS: Long Form: Talk Shows'
# MAGIC         WHEN LOWER(vc.secondary_video_group_name) = 'unassigned' AND vc.video_name='V: Partner: Youtube TV: FS2 Live' THEN 'VG: SPORTS: Long Form: Talk Shows'
# MAGIC         WHEN LOWER(vc.secondary_video_group_name) = 'unassigned' AND LOWER(ss.show_name) = 'studio shows' THEN 'VG: SPORTS: Long Form: Talk Shows'
# MAGIC         ELSE COALESCE(usvg.assigned_secondary_video_group_name, vc.secondary_video_group_name)
# MAGIC     END
# MAGIC )

# COMMAND ----------

query = """
    SELECT
        distributor_name
        , distributor_id
        , site_section_id
        , site_section_name
        , device_name
        , platform_group
        , site_news_one_fox
        , platform_name
        , site_short_name
        , is_live_fox_ss
        , is_fep
        , is_go
        , is_fox_now
        , specific_device
        , stream_type
        , video_id
        , video_name
        , video_duration
        , video_vertical
        , network
        , prefered_video_group
        , primary_video_group_id
        , primary_video_group_name
        , season_in_out_flag
        , season_video_group_id
        , season_video_group_name
        , secondary_video_group_id
        , secondary_video_group_name
        , series_id
        , series_name
        , series_promoted
        , show_name
        , global_ad_unit_position
        , global_ad_unit_class
        , global_ad_unit_category
        , creative_id
        , creative_name
        , creative_duration_secs
        , condition
        , creative_name_map
        , ad_unit_id
        , ad_unit_external_id
        , ad_unit_price
        , placement_id
        , placement_external_id
        , placement_name
        , placement_booked_on_target_impression_goal AS booked_on_target_impression_goal
        , placement_budget_model AS budget_model
        , placement_pacing AS delivery_pacing
        , placement_priority AS delivery_priority
        , placement_priority_point_in_time AS delivery_priority_point_in_time
        , placement_demographic_data_source AS demographic_data_source
        , placement_demographic_on_target_calculation AS demographic_on_target_calculation
        , placement_forced_over_delivery_percent AS forced_over_delivery_percent
        , placement_impression_goal AS impression_goal
        , placement_estimated_impression_goal AS estimated_impression_goal
        , placement_budgeted_impressions
        , placement_start_timestamp_est
        , placement_end_timestamp_est
        , placement_industry
        , placement_status
        , placement_type
        , placement_avg_user_frequency
        , unified_yield_name
        , insertion_order_id
        , insertion_order_name
        , insertion_order_start_timestamp_est
        , insertion_order_end_timestamp_est
        , insertion_order_external_id
        , insertion_order_primary_salesperson
        , insertion_order_primary_trafficker
        , insertion_order_status
        , campaign_id
        , campaign_end_timestamp_est
        , campaign_external_id
        , campaign_name
        , campaign_avg_user_frequency
        , campaign_start_timestamp_est
        , sales_channel_type
        , reseller_id
        , reseller_name
        , mrm_rule_id
        , mrm_rule_name
        , mrm_rule_start_timestamp_est
        , mrm_rule_end_timestamp_est
        , mrm_rule_impression_goal
        , advertiser_id
        , advertiser_name
        , is_promo_advertiser
        , agency_name
        , priority_setting
        , priority_setting_point_in_time
        , dsp_name
        , trading_desk_name
        , buyer_name
        , buyer_priority
        , deal_id
        , external_deal_id
        , deal_name
        , deal_type_point_in_time
        , deal_type
        , deal_override_priority
        , deal_start_timestamp_est
        , deal_end_timestamp_est
        , deal_impression_goal
        , deal_salesperson
        , deal_ad_units
        , programmatic_ad_id
        , programmatic_advertiser_id
        , programmatic_advertiser_name
        , programmatic_brand_name
        , programmatic_industry_name
        , programmatic_creative_duration
        , sold_order_id
        , sold_order_name
        , sold_order_avails_in_played_slot
        , sold_order_cpm_usd
        , sold_order_goal_impressions
        , sold_order_pricing_model
        , sold_order_priority_type
        , sold_order_type
        , sold_order_start_timestamp_est
        , sold_order_end_timestamp_est
        , exchange_listing_id
        , exchange_listing_name
        , exchange_listing_transaction_type
        , exchange_listing_priority
        , exchange_listing_start_timestamp_est
        , exchange_listing_end_timestamp_est
        , private_listing_transaction_type
        , global_advertiser_name
        , delivery_category
        , sports_category
        , custom_platform
        , custom_platform_group
        , custom_business_type
        , custom_property
        , custom_vertical
        , custom_distributor
        , custom_ad_format
        , custom_advertiser_name
        , custom_line_item_name
        , SUM(net_counted_ads) AS net_counted_ads
        , SUM(gross_counted_ads) AS gross_counted_ads
        , SUM(run_revenue_amount) AS run_revenue_amount
        , SUM(ecpm_amount) AS ecpm_amount
        , SUM(delivered_clicks) AS delivered_clicks
        , SUM(measurable_video_ads_quartile_impressions) AS measurable_video_ads_quartile_impressions
        , SUM(direct_guaranteed_impressions) AS direct_guaranteed_impressions
        , SUM(direct_pre_emptible_impressions) AS direct_pre_emptible_impressions
        , SUM(promo_guaranteed_impressions) AS promo_guaranteed_impressions
        , SUM(promo_pre_emptible_impressions) AS promo_pre_emptible_impressions
        , SUM(programmatic_guaranteed_impressions) AS programmatic_guaranteed_impressions
        , SUM(inventory_share_impressions) AS inventory_share_impressions
        , SUM(affiliates_impressions) AS affiliates_impressions
        , SUM(hard_guaranteed_impressions) AS hard_guaranteed_impressions
        , SUM(backfill_impressions) AS backfill_impressions
        , SUM(promo_guaranteed_monetizable_impressions) AS promo_guaranteed_monetizable_impressions
        , SUM(promo_guaranteed_unmonetizable_impressions) AS promo_guaranteed_unmonetizable_impressions
        , SUM(promo_pre_emptible_monetizable_impressions) AS promo_pre_emptible_monetizable_impressions
        , SUM(promo_pre_emptible_unmonetizable_impressions) AS promo_pre_emptible_unmonetizable_impressions
        , event_date
        , DATE_FORMAT(event_date, 'MM') as event_month
        , DATE_FORMAT(event_date, "y-'Q'Q") as event_quarter
        , DATE_FORMAT(event_date, 'y') as event_year
        , event_year||event_month as ad_month_id
        , DATE_FORMAT(event_date, 'MMMM-y') as ad_month_year
        , DATE_FORMAT(CURRENT_TIMESTAMP(), 'yyyy-MM-dd') AS etl_load_date
        , CURRENT_TIMESTAMP() AS etl_load_timestamp
    FROM delivery_data
    GROUP BY
        event_date
        , distributor_name
        , distributor_id
        , site_section_id
        , site_section_name
        , device_name
        , platform_group
        , site_news_one_fox
        , platform_name
        , site_short_name
        , is_live_fox_ss
        , is_fep
        , is_go
        , is_fox_now
        , specific_device
        , stream_type
        , video_id
        , video_name
        , video_duration
        , video_vertical
        , network
        , prefered_video_group
        , primary_video_group_id
        , primary_video_group_name
        , season_in_out_flag
        , season_video_group_id
        , season_video_group_name
        , secondary_video_group_id
        , secondary_video_group_name
        , series_id
        , series_name
        , series_promoted
        , show_name
        , global_ad_unit_position
        , global_ad_unit_class
        , global_ad_unit_category
        , creative_id
        , creative_name
        , creative_duration_secs
        , condition
        , creative_name_map
        , ad_unit_id
        , ad_unit_external_id
        , ad_unit_price
        , placement_id
        , placement_external_id
        , placement_name
        , placement_booked_on_target_impression_goal
        , placement_budget_model
        , placement_pacing
        , placement_priority
        , placement_priority_point_in_time
        , placement_demographic_data_source
        , placement_demographic_on_target_calculation
        , placement_forced_over_delivery_percent
        , placement_impression_goal
        , placement_estimated_impression_goal
        , placement_budgeted_impressions
        , placement_start_timestamp_est
        , placement_end_timestamp_est
        , placement_industry
        , placement_status
        , placement_type
        , placement_avg_user_frequency
        , unified_yield_name
        , insertion_order_id
        , insertion_order_name
        , insertion_order_start_timestamp_est
        , insertion_order_end_timestamp_est
        , insertion_order_external_id
        , insertion_order_primary_salesperson
        , insertion_order_primary_trafficker
        , insertion_order_status
        , campaign_id
        , campaign_end_timestamp_est
        , campaign_external_id
        , campaign_name
        , campaign_avg_user_frequency
        , campaign_start_timestamp_est
        , sales_channel_type
        , reseller_id
        , reseller_name
        , mrm_rule_id
        , mrm_rule_name
        , mrm_rule_start_timestamp_est
        , mrm_rule_end_timestamp_est
        , mrm_rule_impression_goal
        , advertiser_id
        , advertiser_name
        , is_promo_advertiser
        , agency_name
        , priority_setting
        , priority_setting_point_in_time
        , dsp_name
        , trading_desk_name
        , buyer_name
        , buyer_priority
        , deal_id
        , external_deal_id
        , deal_name
        , deal_type_point_in_time
        , deal_type
        , deal_override_priority
        , deal_start_timestamp_est
        , deal_end_timestamp_est
        , deal_impression_goal
        , deal_salesperson
        , deal_ad_units
        , programmatic_ad_id
        , programmatic_advertiser_id
        , programmatic_advertiser_name
        , programmatic_brand_name
        , programmatic_industry_name
        , programmatic_creative_duration
        , sold_order_id
        , sold_order_name
        , sold_order_priority_type
        , sold_order_avails_in_played_slot
        , sold_order_cpm_usd
        , sold_order_goal_impressions
        , sold_order_pricing_model
        , sold_order_type
        , sold_order_start_timestamp_est
        , sold_order_end_timestamp_est
        , exchange_listing_id
        , exchange_listing_name
        , exchange_listing_transaction_type
        , exchange_listing_priority
        , exchange_listing_start_timestamp_est
        , exchange_listing_end_timestamp_est
        , private_listing_transaction_type
        , global_advertiser_name
        , delivery_category
        , sports_category
        , custom_platform
        , custom_platform_group
        , custom_business_type
        , custom_property
        , custom_vertical
        , custom_distributor
        , custom_ad_format
        , custom_advertiser_name
        , custom_line_item_name
"""

delivery_data = spark.sql(query)

# COMMAND ----------

# delivery_data.write.format('delta')\
#     .mode('overwrite')\
#     .partitionBy('event_date')\
#     .option('mergeSchema', 'true')\
#     .option('overwriteDynamicPartitions', 'true')\
#     .option('delta.enableDeletionVectors', 'false')\
#     .option('delta.enableIcebergCompatV2', 'true')\
#     .option('delta.universalFormat.enabledFormats', 'iceberg')\
#     .option('delta.columnMapping.mode', 'name')\
#     .saveAsTable('fox_bi_dev.silver_ads.ft_freewheel_delivery_daily_data')

delivery_data.write.format('delta')\
    .mode('overwrite')\
    .option('partitionOverwriteMode', 'dynamic')\
    .saveAsTable('fox_bi_dev.silver_ads.ft_freewheel_delivery_daily_data')

# COMMAND ----------

# MAGIC %sql
# MAGIC select event_date, count(*) from fox_bi_dev.silver_ads.ft_freewheel_delivery_daily_data group by event_date order by event_date
