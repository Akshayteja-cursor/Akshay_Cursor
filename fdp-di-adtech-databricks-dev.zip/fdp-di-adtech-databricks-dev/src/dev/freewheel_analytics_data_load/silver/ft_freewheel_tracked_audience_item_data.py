# Databricks notebook source
from pyspark.sql import functions as F
from pyspark.sql import types as T 
from datetime import datetime, timedelta

# COMMAND ----------

query = f"""
    SELECT
        cap.event_date
        , cap.site_section_id
        , SUM(cap.total_historical_unconstrained_ad_avails) AS total_historical_unconstrained_ad_avails_lod
        , SUM(cap.total_historical_constrained_ad_avails) AS total_historical_constrained_ad_avails_lod
        ,SUM(cap.historical_unfilled_ad_opportunities) AS historical_unfilled_available_lod
        , SUM(cap.net_counted_ads) AS net_counted_ads_lod
    FROM fox_bi_dev.silver_ads.ft_freewheel_capacity_summary_daily_data cap
    GROUP BY
        cap.event_date
        , cap.site_section_id
"""

spark.sql(query).createOrReplaceTempView('ft_capacity_delivery')

# COMMAND ----------

query = f"""
    SELECT
        taid.event_date,
        taid.tracked_audience_item,
        taid.site_section_id,
        sum(total_historical_constrained_ad_avails) as historical_constrained_ad_avails,
        sum(total_historical_unconstrained_ad_avails) as historical_unconstrained_ad_avails,
        sum(historical_unfilled_ad_opportunities) as historical_unfilled_available,
        sum(net_counted_ads) as net_counted_ads
    FROM fox_bi_dev.bronze_ads.freewheel_analytics_tracked_audience_item taid
    GROUP BY
        taid.event_date
        , taid.tracked_audience_item
        , taid.site_section_id
"""

spark.sql(query).createOrReplaceTempView('ft_tracked_audience_item_data')

# COMMAND ----------

query = f"""
    SELECT
        /*+ BROADCAST(site) */
        taid.event_date,
        taid.site_section_id,
        taid.tracked_audience_item,
        COALESCE(site.site_section_name,'N/A') as site_section_name,
        CASE
        WHEN site.site_section_name LIKE '%: CTV:%' THEN 'CTV'
        WHEN site.site_section_name LIKE '%: STB%' THEN 'STB'
        WHEN site.site_section_name LIKE '%Comcast Production%' THEN 'STB'
        WHEN site.site_section_name LIKE '%: Mobile App:%' THEN 'MB/TB'
        WHEN site.site_section_name LIKE '%Handheld%' THEN 'MB/TB'
        WHEN site.site_section_name LIKE '%Tablet%' THEN 'MB/TB'
        WHEN site.site_section_name LIKE '%: Web%' THEN 'DT'
        WHEN site.site_section_name LIKE '%Desktop%' THEN 'DT'
        ELSE 'Unk'
    END AS device,
        CASE
            WHEN LOWER(site.site_section_name) LIKE '%android tv%'       THEN 'Android TV'
            WHEN LOWER(site.site_section_name) LIKE '%androidtv%'        THEN 'Android TV'
            WHEN LOWER(site.site_section_name) LIKE '%apple%'            THEN 'Apple TV'
            WHEN LOWER(site.site_section_name) LIKE '%fire%'             THEN 'Amazon TV'
            WHEN LOWER(site.site_section_name) LIKE '%roku%'             THEN 'Roku'
            WHEN LOWER(site.site_section_name) LIKE '%mobile app: android%' THEN 'Android App'
            WHEN LOWER(site.site_section_name) LIKE '%android phone%'    THEN 'Android App'
            WHEN LOWER(site.site_section_name) LIKE '%android tablet%'   THEN 'Android App'
            WHEN LOWER(site.site_section_name) LIKE '%ios%'              THEN 'iOS App'
            WHEN LOWER(site.site_section_name) LIKE '%ipad%'             THEN 'iOS App'
            WHEN LOWER(site.site_section_name) LIKE '%iphone%'           THEN 'iOS App'
            WHEN LOWER(site.site_section_name) LIKE '%mobile app%'       THEN 'Mobile App'
            WHEN LOWER(site.site_section_name) LIKE '%mobile web%'       THEN 'Mobile Web'
            WHEN LOWER(site.site_section_name) LIKE '%tablet web%'       THEN 'Tablet Web'
            WHEN LOWER(site.site_section_name) LIKE '%mobile tablet%'    THEN 'Mobile Web'
            WHEN LOWER(site.site_section_name) LIKE '%mobile handheld%'  THEN 'Mobile Web'
            WHEN LOWER(site.site_section_name) LIKE '%desktop%'          THEN 'Desktop Web'
            WHEN LOWER(site.site_section_name) LIKE '%web%'              THEN 'Web'
            WHEN LOWER(site.site_section_name) LIKE '%amp%'              THEN 'AMP'
            WHEN LOWER(site.site_section_name) LIKE '%ctv%'              THEN 'Other CTV'
            ELSE 'Unknown'
    END AS platform,
    CASE 
            WHEN LOWER(platform) = "android tv"  THEN "CTV"
            WHEN LOWER(platform) = "apple tv"    THEN "CTV"
            WHEN LOWER(platform) = "amazon tv"   THEN "CTV"
            WHEN LOWER(platform) = "roku"        THEN "CTV"
            WHEN LOWER(platform) = "other ctv"   THEN "CTV"
            WHEN LOWER(platform) LIKE '%app%'    THEN "Mobile Apps"
            WHEN LOWER(platform) = "mobile web"  THEN "Mobile/Tablet Web"
            WHEN LOWER(platform) = "tablet web"  THEN "Mobile/Tablet Web"
            WHEN LOWER(platform) = "amp"         THEN "Mobile/Tablet Web"
            WHEN LOWER(platform) = "desktop web" THEN "Desktop Web"
            WHEN LOWER(platform) = "web"         THEN "Web"
            ELSE "Unknown"
    END AS platform_group,
        taid.historical_constrained_ad_avails,
        taid.historical_unconstrained_ad_avails,
        taid.historical_unfilled_available,
        taid.net_counted_ads,
        cap.total_historical_constrained_ad_avails_lod
        , cap.total_historical_unconstrained_ad_avails_lod
        ,cap.historical_unfilled_available_lod
        , cap.net_counted_ads_lod
        , DATE_FORMAT(CURRENT_TIMESTAMP(), 'yyyy-MM-dd') AS etl_load_date
        , CURRENT_TIMESTAMP() AS etl_load_timestamp
    FROM ft_tracked_audience_item_data taid
    LEFT OUTER JOIN ft_capacity_delivery cap
    ON taid.event_date = cap.event_date
    AND taid.site_section_id = cap.site_section_id
    LEFT JOIN (
        SELECT
            distinct 
            site_section_id,
            site_section_name
        FROM fox_bi_dev.silver_ads.dim_freewheel_analytics_site
    ) site
    ON taid.site_section_id = site.site_section_id
"""

tracked_audience_summary = spark.sql(query)

# COMMAND ----------

display(tracked_audience_summary)

# COMMAND ----------

tracked_audience_summary.write.format('delta')\
     .mode('overwrite')\
     .option('mergeSchema', 'true')\
     .option('partitionOverwriteMode', 'dynamic')\
     .option('delta.enableDeletionVectors', 'false')\
     .option('delta.enableIcebergCompatV2', 'true')\
     .option('delta.universalFormat.enabledFormats', 'iceberg')\
     .option('delta.columnMapping.mode', 'name')\
     .saveAsTable('fox_bi_dev.silver_ads.ft_freewheel_tracked_audience_item_daily_data')

# COMMAND ----------

# MAGIC %sql
# MAGIC select event_date, count(*) from fox_bi_dev.silver_ads.ft_freewheel_tracked_audience_item_daily_data group by event_date order by event_date
