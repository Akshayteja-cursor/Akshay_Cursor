# Databricks notebook source
from pyspark.sql import functions as F
from pyspark.sql import types as T
from datetime import datetime, timedelta

# COMMAND ----------

query = f"""
    SELECT
        /*+ BROADCAST(site, vc) */
        cap.event_date
        , cap.distributor_name
        , cap.distributor_id
        , cap.site_section_id
        , site.site_section_name
        , site.site_id
        , site.site_name
        , cap.video_id
        , vc.video_name
        , vc.prefered_video_group
        , vc.primary_video_group_id
        , vc.primary_video_group_name
        , cap.series_id
        , vs.series_name
        , CASE
            WHEN site.site_section_name LIKE '%Run Of Site%' THEN
                CASE
                    WHEN site.site_section_name LIKE '%Fubo%' THEN 'FuboTV'
                    ELSE SPLIT_PART(SUBSTRING(site.site_section_name FROM 34), ' ', 1)
                END
            WHEN site.site_section_name LIKE '%SS: Owned: %' THEN SPLIT_PART(SUBSTRING(site.site_section_name FROM 12), ':', 1)
            WHEN site.site_section_name LIKE '%SS: Partner: %' THEN SPLIT_PART(SUBSTRING(site.site_section_name FROM 14), ':', 1)
            WHEN site.site_section_name LIKE '%Charter: Programmer VOD%' THEN 'Canoe'
			WHEN site.site_section_name LIKE '%Cox: Legacy Live%' THEN 'Canoe'
			WHEN site.site_section_name LIKE '%Cox: Watermark C2%' THEN 'Canoe'
			WHEN site.site_section_name LIKE '%Comcast%IP STB VOD%' THEN 'Canoe'
        END AS platform_name
        , CASE
            -- WHEN UPPER(COALESCE(dd.global_ad_unit_category, cap.global_ad_unit_category)) = 'DISPLAY ADS' THEN 'Display'
            WHEN LOWER(vs.series_name) LIKE '%deportes%' THEN 'Deportes'
            WHEN vc.primary_video_group_id = '18773867' THEN 'BTN'
            WHEN LOWER(vs.series_name) LIKE '%monarch%' THEN 'Entertainment'
            
            -- Weather Logic
            WHEN LOWER(vs.series_name) LIKE '%fox weather%' 
                OR LOWER(site.site_section_name) LIKE '%fox weather%' THEN 'Weather'
            
            -- News/Business Logic
            WHEN vc.primary_video_group_id IN ('20474534', '20474467')
                OR LOWER(vs.series_name) LIKE '%vs: news%'
                OR LOWER(vs.series_name) LIKE '%vs: fnc%'
                OR LOWER(vs.series_name) LIKE '%vs: fbn%'
                OR LOWER(vs.series_name) LIKE '%: fnc%'
                OR LOWER(vs.series_name) LIKE '%: fbn%'
                OR LOWER(site.site_section_name) LIKE '%fox news app%'
                OR LOWER(site.site_section_name) LIKE '%fox business app%' THEN 'News/Business'
            
            -- Fox Nation Logic
            WHEN LOWER(vs.series_name) LIKE '%vs: nation%'
                OR LOWER(site.site_section_name) LIKE '%fox nation%' THEN 'Fox Nation'
            WHEN site.site_section_name LIKE '%Fox One%' AND site.site_section_name LIKE '%Nation%' THEN 'Fox Nation'
            
            WHEN LOWER(site.site_section_name) LIKE '%tmz app%' THEN 'TMZ'
            WHEN LOWER(site.site_section_name) LIKE '%outkick app%' THEN 'Outkick'
            WHEN LOWER(vs.series_name) LIKE '%ultimate tag%' THEN 'Entertainment'
            WHEN vc.primary_video_group_id = '18698796' THEN 'Sports SFV'
            
            WHEN vc.primary_video_group_id = '414462094' OR vc.video_name LIKE '%NIVA%' THEN 'NIVA'
            
            -- Sports LFV Logic
            WHEN vc.primary_video_group_id IN ('18698781', '241987048', '241987474')
                OR UPPER(vs.series_name) LIKE '%WWE%'
                OR UPPER(vs.series_name) LIKE '%SMACKDOWN%'
                OR UPPER(vs.series_name) LIKE '%VS: SPORTS%' THEN 'Sports LFV'
            
            -- Entertainment Logic
            WHEN vc.primary_video_group_id = '18652208'
                OR LOWER(site.site_section_name) LIKE '%fox ent%'
                OR LOWER(vs.series_name) LIKE '%vs: ent: fox:%' THEN 'Entertainment'
            
            WHEN vc.primary_video_group_id = '18698699' THEN 'Entertainment SFV'
            
            -- Fox One Cross-Sells
            WHEN site.site_section_name LIKE '%Fox One%' AND site.site_section_name LIKE '%ENT%' THEN 'Entertainment'
            WHEN site.site_section_name LIKE '%Fox One%' AND site.site_section_name LIKE '%Sports%' THEN 'Sports LFV'
            WHEN site.site_section_name LIKE '%Fox One%' AND site.site_section_name LIKE '%Weather%' THEN 'Weather'
            
            -- Tubi Specific Logic
            WHEN UPPER(site.site_section_name) LIKE '%TUBI%' AND vs.series_name = 'Unknown Series' THEN
                CASE 
                    WHEN vc.video_name LIKE '%FOX Entertainment%' THEN 'Entertainment'
                    WHEN LOWER(vc.video_name) LIKE '%gordon ramsay%' THEN 'Entertainment'
                    WHEN LOWER(vc.video_name) LIKE '%masterchef%' THEN 'Entertainment'
                    WHEN LOWER(vc.video_name) LIKE "%hell's kitchen%" THEN 'Entertainment'
                    WHEN LOWER(vc.video_name) LIKE '%masked singer%' THEN 'Entertainment'
                    WHEN vc.video_name LIKE '%FOX Sports%' THEN 'Sports LFV'
                    WHEN vc.video_name LIKE '%FOX News%' THEN 'News/Business'
                    WHEN vc.video_name LIKE '%FOX Weather%' THEN 'Weather'
                    ELSE 'Tubi' -- Default if within Tubi/Unknown but no video match
                END
                
            WHEN vs.series_name = 'Unknown Series' AND LOWER(vc.video_name) LIKE '%masked singer%' THEN 'Entertainment'
            WHEN LOWER(site.site_section_name) LIKE '%tubi%' THEN 'Tubi'

            ELSE 'Unassigned'
        END Video_vertical
        , CASE
            WHEN site.site_section_name like '%Fox One%' THEN 'Fox One'
            WHEN site.site_section_name like '%foxone%' THEN 'Fox One'
            WHEN site.site_section_name like '%Charter: Programmer VOD%' THEN 'STB VOD'
            WHEN site.site_section_name like '%Cox: Legacy Live%' THEN 'STB VOD'
            WHEN site.site_section_name like '%Cox: Watermark C2%' THEN 'STB VOD'
            WHEN site.site_section_name like '%Comcast%IP STB VOD%' THEN 'STB VOD'
            WHEN site.site_section_name like '%: Canoe%' THEN 'STB VOD'
            WHEN site.site_section_name LIKE '%FNC%' THEN 'FNC'
            WHEN site.site_section_name LIKE '%FBN%' THEN 'FBN'
            WHEN site.site_section_name LIKE '%FOX Nation%' THEN 'FOX Nation'
            WHEN site.site_section_name LIKE '%Hulu%' THEN 'Hulu'
            WHEN site.site_section_name LIKE '%Tubi%' THEN 'Tubi'
            WHEN site.site_section_name LIKE '%: STB%' THEN 'STB VOD'
            WHEN site.site_section_name LIKE '%Comcast Production%' THEN 'STB VOD'
            WHEN site.site_section_name LIKE '%Partner%' THEN 'Off-Platform'
            WHEN site.site_section_name LIKE '%Run Of Site%' THEN 'Off-Platform'
            WHEN site.site_section_name LIKE '%Owned%' THEN 'O&O'
            ELSE 'Other'
         END AS platform_group
       , CASE 
            WHEN Video_vertical = 'Entertainment' THEN
                CASE 
                    WHEN platform_group = 'Hulu' THEN 'FOX on Hulu'
                    WHEN platform_group = 'Tubi' THEN 'FOX on Tubi'
                    WHEN platform_group = 'STB VOD' THEN 'STB VOD'
                    ELSE 'FOX'
                END
            ELSE Video_vertical
        END AS property
        , SUM(cap.net_ad_requests) As net_ad_requests
        , DATE_FORMAT(cap.event_date, 'MM') as event_month
        , DATE_FORMAT(cap.event_date, "y-'Q'Q") as event_quarter
        , DATE_FORMAT(cap.event_date, 'y') as event_year
        , event_year||event_month as ad_month_id
        , DATE_FORMAT(cap.event_date, 'MMMM-y') as ad_month_year
        , DATE_FORMAT(CURRENT_TIMESTAMP(), 'yyyy-MM-dd') AS etl_load_date
        , CURRENT_TIMESTAMP() AS etl_load_timestamp
        , CASE
            WHEN LOWER(site.site_section_name) LIKE '%android tv%' THEN 'Android TV'
            WHEN LOWER(site.site_section_name) LIKE '%androidtv%' THEN 'Android TV'
            WHEN LOWER(site.site_section_name) LIKE '%apple%' THEN 'Apple TV'
            WHEN LOWER(site.site_section_name) LIKE '%fire%' THEN 'Amazon TV'
            WHEN LOWER(site.site_section_name) LIKE '%roku%' THEN 'Roku'
            WHEN LOWER(site.site_section_name) LIKE '%mobile app: android%' THEN 'Android App'
            WHEN LOWER(site.site_section_name) LIKE '%android phone%' THEN 'Android App'
            WHEN LOWER(site.site_section_name) LIKE '%android tablet%' THEN 'Android App'
            WHEN LOWER(site.site_section_name) LIKE '%ios%' THEN 'iOS App'
            WHEN LOWER(site.site_section_name) LIKE '%ipad%' THEN 'iOS App'
            WHEN LOWER(site.site_section_name) LIKE '%iphone%' THEN 'iOS App'
            WHEN LOWER(site.site_section_name) LIKE '%mobile app%' THEN 'Mobile App'
            WHEN LOWER(site.site_section_name) LIKE '%mobile web%' THEN 'Mobile Web'
            WHEN LOWER(site.site_section_name) LIKE '%tablet web%' THEN 'Tablet Web'
            WHEN LOWER(site.site_section_name) LIKE '%mobile tablet%' THEN 'Mobile Web'
            WHEN LOWER(site.site_section_name) LIKE '%mobile handheld%' THEN 'Mobile Web'
            WHEN LOWER(site.site_section_name) LIKE '%desktop%' THEN 'Desktop Web'
            WHEN LOWER(site.site_section_name) LIKE '%web%' THEN 'Web'
            WHEN LOWER(site.site_section_name) LIKE '%amp%' THEN 'AMP'
            WHEN LOWER(site.site_section_name) LIKE '%ctv%' THEN 'Other CTV'
            ELSE 'Unknown'
        END AS custom_platform
        , CASE
            WHEN LOWER(custom_platform) = "android tv" THEN "CTV"
            WHEN LOWER(custom_platform) = "apple tv" THEN "CTV"
            WHEN LOWER(custom_platform) = "amazon tv" THEN "CTV"
            WHEN LOWER(custom_platform) = "roku" THEN "CTV"
            WHEN LOWER(custom_platform) = "other ctv" THEN "CTV"
            WHEN LOWER(custom_platform) LIKE '%app%' THEN "Mobile Apps"
            WHEN LOWER(custom_platform) = "mobile web" THEN "Mobile/Tablet Web"
            WHEN LOWER(custom_platform) = "tablet web" THEN "Mobile/Tablet Web"
            WHEN LOWER(custom_platform) = "amp" THEN "Mobile/Tablet Web"
            WHEN LOWER(custom_platform) = "desktop web" THEN "Desktop Web"
            WHEN LOWER(custom_platform) = "web" THEN "Web"
            ELSE "Unknown"
        END AS custom_platform_group
        , CASE
            -- Series Name–based rules
            WHEN (UPPER(COALESCE(vs.series_name, '')) LIKE '%FBN%'
                OR UPPER(COALESCE(vs.series_name, '')) LIKE '%FOX BUSINESS%'
                OR UPPER(COALESCE(vs.series_name, '')) LIKE '%VS: BUSINESS%') THEN 'FBN'
            WHEN UPPER(COALESCE(vs.series_name, '')) LIKE '%FOX WEATHER%' THEN 'FXW'
            WHEN UPPER(COALESCE(vs.series_name, '')) LIKE '%NEWS%' THEN 'FNC'
            WHEN UPPER(COALESCE(vs.series_name, '')) LIKE '%BTN%' THEN 'BTN'
            WHEN UPPER(COALESCE(vs.series_name, '')) LIKE '%DEPORTES%' THEN 'Deportes'
            WHEN UPPER(COALESCE(vs.series_name, '')) LIKE '%SPORTS%' THEN 'FS'
            WHEN UPPER(COALESCE(vs.series_name, '')) LIKE '%VS: ENT%' THEN 'ENT'
            WHEN UPPER(COALESCE(vs.series_name, '')) LIKE '%TUBI%' THEN 'TUBI'
            WHEN UPPER(COALESCE(vs.series_name, '')) LIKE '%VS: NATION%' THEN 'Fox Nation'

            -- Site Section Name–based rules
            WHEN (UPPER(COALESCE(site.site_section_name, '')) LIKE '%FOX NEWS%'
                OR UPPER(COALESCE(site.site_section_name, '')) LIKE '%FNC%') THEN 'FNC'
            WHEN (UPPER(COALESCE(site.site_section_name, '')) LIKE '%FOX BUSINESS%'
                OR UPPER(COALESCE(site.site_section_name, '')) LIKE '%FBN%') THEN 'FBN'
            WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%FOX WEATHER%' THEN 'FXW'
            WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%TMZ%' THEN 'TMZ'
            WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%OUTKICK%' THEN 'OKI'
            WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%BTN%' THEN 'BTN'
            WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%DEPORTES%' THEN 'Deportes'
            WHEN (UPPER(COALESCE(site.site_section_name, '')) LIKE '%FS%'
                OR UPPER(COALESCE(site.site_section_name, '')) LIKE '%FOX SPORTS%') THEN 'FS'
            WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%FOX ENT%' THEN 'ENT'

            -- Tubi + Unknown Series + Video Name disambiguation
            WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%TUBI%'
                AND COALESCE(vs.series_name, '') = 'Unknown Series'
                AND UPPER(COALESCE(vc.video_name, '')) LIKE '%FOX ENTERTAINMENT%' THEN 'ENT'
            WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%TUBI%'
                AND COALESCE(vs.series_name, '') = 'Unknown Series'
                AND ( UPPER(COALESCE(vc.video_name, '')) LIKE '%FOX SPORTS%'
                    OR UPPER(COALESCE(vc.video_name, '')) LIKE '%ONEFOX VOD SPORTS%' ) THEN 'FS'
            WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%TUBI%'
                AND COALESCE(vs.series_name, '') = 'Unknown Series'
                AND UPPER(COALESCE(vc.video_name, '')) LIKE '%FOX NEWS%' THEN 'FNC'
            WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%TUBI%'
                AND COALESCE(vs.series_name, '') = 'Unknown Series'
                AND UPPER(COALESCE(vc.video_name, '')) LIKE '%FOX WEATHER%' THEN 'FXW'

            -- Remaining Tubi / Fox Nation
            WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%TUBI%' THEN 'TUBI'
            WHEN UPPER(COALESCE(site.site_section_name, '')) LIKE '%FOX NATION%' THEN 'Fox Nation'

            ELSE 'Unknown'
        END AS custom_property
        , CASE
            WHEN UPPER(custom_property) IN ('FNC', 'FBN', 'FXW', 'TMZ', 'OKI') THEN 'NEWS'
            WHEN UPPER(custom_property) IN ('FS', 'BTN', 'DEPORTES') THEN 'SPORTS'
            WHEN UPPER(custom_property) = 'ENT' THEN 'ENTERTAINMENT'
            WHEN UPPER(custom_property) = 'TUBI' THEN 'TUBI'
            ELSE 'Unknown'
        END AS custom_vertical
        , CASE
            -- Case 1: SS: Owned
            WHEN site.site_section_name ILIKE '%SS: Owned%' THEN
                CASE
                    WHEN LOCATE(':', site.site_section_name, 12) > 0 THEN
                        SUBSTRING(site.site_section_name, 12, LOCATE(':', site.site_section_name, 12) - 12)
                    ELSE
                        SUBSTRING(site.site_section_name, 12, LENGTH(site.site_section_name) - 11)
                END

            -- Case 2: SS: Partner
            WHEN site.site_section_name ILIKE '%SS: Partner%' THEN
                CASE
                    WHEN LOCATE(':', site.site_section_name, 14) > 0 THEN
                        SUBSTRING(site.site_section_name, 14, LOCATE(':', site.site_section_name, 14) - 14)
                    ELSE
                        SUBSTRING(site.site_section_name, 14, LENGTH(site.site_section_name) - 13)
                END

            ELSE NULL
        END AS custom_distributor
        , CASE
            WHEN UPPER(site.site_section_name) LIKE '%CLIP%' THEN "SFV"
            WHEN UPPER(site.site_section_name) LIKE '%SS: OWNED: FOX WEATHER APP: MOBILE APP%' THEN "SFV"
            WHEN UPPER(site.site_section_name) LIKE '%SS: OWNED: FOX WEATHER APP: WEB%' THEN "SFV"
            ELSE "LFV"
        END AS custom_ad_format
    FROM fox_bi_dev.bronze_ads.freewheel_analytics_fxw_capacity cap
    LEFT JOIN (
        SELECT
            *
        FROM fox_bi_dev.silver_ads.dim_freewheel_analytics_site
        WHERE (
            site_section_id
            , site_id
        ) NOT IN (
            SELECT
                dfas.site_section_id
                , -1
            FROM fox_bi_dev.silver_ads.dim_freewheel_analytics_site dfas
            GROUP BY dfas.site_section_id
            HAVING COUNT(*) > 1
        )
    ) site
    ON cap.site_section_id = site.site_section_id
    LEFT JOIN fox_bi_dev.silver_ads.dim_freewheel_analytics_video_group_custom vc
    ON cap.video_id = vc.video_id
    LEFT JOIN fox_bi_dev.silver_ads.dim_freewheel_analytics_video_series vs
    ON cap.series_id = vs.series_id
    GROUP BY
        cap.event_date
        , cap.distributor_name
        , cap.distributor_id
        , cap.site_section_id
        , cap.video_id
        , cap.series_id
        , site.site_section_name
        , site.site_id
        , site.site_name
        , vc.video_name
        , vc.prefered_video_group
        , vc.primary_video_group_id
        , vc.primary_video_group_name
        , vs.series_name
"""

fxw_capacity = spark.sql(query)

# COMMAND ----------

# fxw_capacity.write.format('delta')\
#     .mode('overwrite')\
#     .partitionBy('event_date')\
#     .option('mergeSchema', 'true')\
#     .option('overwriteDynamicPartitions', 'true')\
#     .option('delta.enableDeletionVectors', 'false')\
#     .option('delta.enableIcebergCompatV2', 'true')\
#     .option('delta.universalFormat.enabledFormats', 'iceberg')\
#     .option('delta.columnMapping.mode', 'name')\
#     .saveAsTable('fox_bi_dev.silver_ads.ft_freewheel_fxw_capacity_daily_data')

fxw_capacity.write.format('delta')\
    .mode('overwrite')\
    .option('partitionOverwriteMode', 'dynamic')\
    .saveAsTable('fox_bi_dev.silver_ads.ft_freewheel_fxw_capacity_daily_data')

# COMMAND ----------

# MAGIC %sql
# MAGIC select event_date, count(*) from fox_bi_dev.silver_ads.ft_freewheel_fxw_capacity_daily_data group by event_date order by event_date