# Databricks notebook source
import configparser

# COMMAND ----------

# MAGIC %run ./freewheel_analytics_config

# COMMAND ----------

dbutils.widgets.text("env", "")
env = dbutils.widgets.get("env")

# COMMAND ----------

config = configparser.ConfigParser()
config = freewheel_analytics_config[env]
display(config)
catalog=config['catalog']
silver_schema=config['silver_schema']
bronze_schema = config['bronze_schema']
raw_schema=config['raw_schema']

# COMMAND ----------

query = f"""
SELECT
   event_date,
  video_name,
  site_section_name,
  placement_name,
  creative_name,
     CASE
       WHEN site_section_name LIKE '%: CTV:%' THEN 'CTV'
       WHEN site_section_name LIKE '%: STB%' THEN 'STB'
       WHEN site_section_name LIKE '%Comcast Production%' THEN 'STB'
       WHEN site_section_name LIKE '%: Mobile App:%' THEN 'MB/TB'
       WHEN site_section_name LIKE '%Handheld%' THEN 'MB/TB'
       WHEN site_section_name LIKE '%Tablet%' THEN 'MB/TB'
       WHEN site_section_name LIKE '%: Web%' THEN 'DT'
       WHEN site_section_name LIKE '%Desktop%' THEN 'DT'
       ELSE 'Unk'
   END AS device_name,
  net_counted_ads,
  delivered_clicks,
  video_ads_100_complete
FROM {catalog}.{bronze_schema}.freewheel_analytics_tubi_fox_one_promo_delivery
"""

# COMMAND ----------

tubi_fox_one_df = spark.sql(query)
# display(tubi_fox_one_df)

# COMMAND ----------

# tubi_fox_one_df.write.format('delta')\
#     .mode('overwrite')\
#     .partitionBy('event_date')\
#     .option("overwriteSchema", "true")\
#     .option('mergeSchema', 'true')\
#     .option('overwriteDynamicPartitions', 'true')\
#     .option('delta.enableDeletionVectors', 'false')\
#     .option('delta.enableIcebergCompatV2', 'true')\
#     .option('delta.universalFormat.enabledFormats', 'iceberg')\
#     .option('delta.columnMapping.mode', 'name')\
#     .saveAsTable(f'{catalog}.{silver_schema}.ft_freewheel_promo_delivery')

tubi_fox_one_df.write.format('delta')\
    .mode('overwrite')\
    .option('partitionOverwriteMode', 'dynamic')\
    .saveAsTable(f'{catalog}.{silver_schema}.ft_freewheel_promo_delivery')
