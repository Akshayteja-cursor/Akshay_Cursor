# Databricks notebook source
freewheel_analytics_config = {
"dev":{
  "catalog":"fox_bi_dev",
  "raw_schema":"raw_ads",
  "bronze_schema":"bronze_ads",
  "silver_schema":"silver_ads"
},
"prod":{
  "catalog":"fox_bi_prod",
  "raw_schema":"raw_ads",
  "bronze_schema":"bronze_ads",
  "silver_schema":"silver_ads"
}
}
