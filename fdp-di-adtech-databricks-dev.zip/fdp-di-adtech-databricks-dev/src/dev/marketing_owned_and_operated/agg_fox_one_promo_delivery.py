# Databricks notebook source
import datetime
from datetime import timedelta
from pyspark.sql import functions as F
from pyspark.sql import types as T
from datetime import datetime, timedelta
import configparser

# COMMAND ----------

# MAGIC %run ./marketing_owned_operated_config

# COMMAND ----------

config = configparser.ConfigParser()
dbutils.widgets.text("env", "")
env = dbutils.widgets.get("env")
config = marketing_o_o_config[env]
display(config)
catalog=config['catalog']
silver_schema=config['silver_schema']
gold_schema_adsales=config['gold_schema_adsales']
gold_schema_ads=config['gold_schema_ads']
bronze_schema = config['bronze_schema']
raw_schema=config['raw_schema']

# COMMAND ----------

# DBTITLE 1,Untitled
query=""" 
select date,
      upper(platform) as platform,
      upper(ad_server) as ad_server,
      sum(impressions) as impressions
      from (
SELECT
  ad_date as date,
  site_name as platform,
  'NEWS GAM' AS ad_server,
  SUM(total_impressions) AS impressions
FROM
  fox_bi_prod.{silver_schema}.ft_gam_summary_daily_data summary 
WHERE 
  upper(site_name) not in ('FOX WEATHER')
  AND ad_date >= DATE('2025-10-01')
  AND advertiser_id in (5848968151)
GROUP BY
  1,
  2,
  3

UNION ALL
SELECT
  ad_date as date,
  site_name as platform,
  'NEWS GAM' AS ad_server,
  SUM(total_impressions) AS impressions
FROM
  fox_bi_prod.{silver_schema}.ft_gam_summary_daily_data summary 
WHERE 
  ad_unit_name ilike '%fxw%'
  AND ad_date >= DATE('2025-10-01')
  AND advertiser_id in (5848968151)
GROUP BY
  1,
  2,
  3

UNION ALL
SELECT  
  event_date as date,
  site_name as platform,
  'NEWS GAM' AS ad_server,
  sum(total_line_item_level_impressions) AS impressions
 FROM 
    {catalog}.{raw_schema}.gam_api_marketing_owned_operated_summary_with_impressions_and_error_count summary
LEFT JOIN 
    {catalog}.{silver_schema}.dim_ad_unit au
      ON summary.ad_unit_id = au.ad_unit_id AND au.network_group_id = 4145
WHERE 
  upper(site_name) not in ('FOX WEATHER')
   AND creative_click_through_url ilike '%fox.com%' and advertiser_id in (4870164238)
GROUP BY
   1,
   2,
   3

UNION ALL
SELECT  
  event_date as date,
  site_name as platform,
  'NEWS GAM' AS ad_server,
  sum(total_line_item_level_impressions) AS impressions
 FROM 
    {catalog}.{raw_schema}.gam_api_marketing_owned_operated_summary_with_impressions_and_error_count summary
LEFT JOIN 
    {catalog}.{silver_schema}.dim_ad_unit au
      ON summary.ad_unit_id = au.ad_unit_id AND au.network_group_id = 4145
WHERE 
  ad_unit_name ilike '%fxw%'
   AND creative_click_through_url ilike '%fox.com%' and advertiser_id in (4870164238)
GROUP BY
   1,
   2,
   3

UNION ALL
-- FTS GAM
select
  event_date as date,
  'FTS' as platform,
  'FTS GAM' as ad_server,
  sum(total_line_item_level_impressions) as impressions
from
  fox_bi_prod.{bronze_schema}.fts_delivery_gam_api_63790564 fts_api_delivery 
  where event_date >= DATE('2025-10-01') and order_id in (3820607981,3842930598)
GROUP BY 1,2,3

union all 
-- FTS GAM
select
  event_date as date,
  'FTS' as platform,
  'FTS GAM' as ad_server,
  sum(total_line_item_level_impressions) as impressions
from
  fox_bi_prod.{bronze_schema}.fts_delivery_gam_api_63790564 fts_api_delivery 
  where event_date >= DATE('2025-10-01') and order_id in (3039856472, 424994244) and line_item_id in (6004535999, 6046533745, 6002559537, 6045137418, 6040268594, 6045137439, 6041571782, 6045136719)
GROUP BY 1,2,3

UNION ALL
-- SPORTS GAM ,
SELECT
  event_date as date,
  'FOX Sports' AS site_name,
  'SPORTS GAM' AS ad_server,
  SUM(total_impressions) AS impressions
FROM
  {catalog}.{silver_schema}.ft_sports_gam_ad_delivery_and_capacity
WHERE
  event_date >= DATE('2025-10-01')
  AND advertiser_id in (5861093169,32014028)
GROUP BY
  1,
  2,
  3
UNION ALL
-- FW (516429 FOX CORP) , USING ONLY advert. name in filter as agency blank for these advertisers in hotb table
SELECT
  event_date as date,
  platform_name as platform,
  'FREEWHEEL FOX CORP' AS ad_server,
  SUM(net_counted_ads) AS impressions
FROM
  fox_bi_prod.{silver_schema}.ft_freewheel_delivery_daily_data
WHERE
  event_date >= DATE('2025-10-01')
  AND insertion_order_id in (87579529,90538010,88835426)
GROUP BY
  1,
  2,
  3
UNION ALL
--- Tubi data
select
  date,
  'Tubi' as site_name,
  'Tubi' as ad_server,
  sum(impressions_1p) as impressions
from
  adrise_share_prod.ads_curated.v_fox_one_daily_impressions
where
  advertiser_name = 'FOX Marketing'
  and creative_name ilike '%fox one%'
  and date >= '2025-10-01'
group by
  1,
  2,
  3
  UNION ALL
  select 
  event_date as date,
  'Tubi AdRise' as site_name,
  'FREEWHEEL FOX CORP' as ad_server,
  SUM(net_counted_ads) AS impressions
  from fox_bi_dev.{silver_schema}.ft_freewheel_promo_delivery
  WHERE
  event_date >= DATE('2025-10-01')
  GROUP BY
    1,
    2,
    3
  ) group by date,
      upper(platform),
      upper(ad_server)
 """.format(catalog=catalog,raw_schema=raw_schema,bronze_schema=bronze_schema,gold_schema=gold_schema_adsales,silver_schema=silver_schema)

# COMMAND ----------

query_1=""" 
select date,
      upper(creative_name) as creative_name,
      upper(business_unit) as business_unit,
      upper(device_platform_name) as device_platform_name,
      upper(destination_url) as destination_url,
      upper(ad_server) as ad_server,
      sum(impressions) as impressions,
      sum(clicks) as clicks
      from (
SELECT  
  event_date as date,
  li.line_item_name as creative_name,
  au.site_name as business_unit,
  au.platform_name as device_platform_name,
  creative_click_through_url as destination_url,
  'NEWS GAM' AS ad_server,
  sum(total_line_item_level_impressions) AS impressions,
  sum(total_line_item_level_clicks) AS clicks
 FROM 
    {catalog}.{raw_schema}.gam_api_marketing_owned_operated_summary_with_impressions_and_error_count summary
LEFT JOIN 
    {catalog}.{silver_schema}.dim_ad_unit au
      ON summary.ad_unit_id = au.ad_unit_id AND au.network_group_id = 4145
LEFT JOIN
    {catalog}.{silver_schema}.dim_line_item li
      ON summary.line_item_id = li.line_item_id
WHERE 
  upper(au.site_name) not in ('FOX WEATHER')
   and (advertiser_id = 4870164238 AND creative_click_through_url ilike '%fox.com%' 
          or advertiser_id=5848968151)
GROUP BY
   1,2,3,4,5,6

UNION ALL
SELECT  
  event_date as date,
  li.line_item_name as creative_name,
  au.site_name as business_unit,
  au.platform_name as device_platform_name,
  creative_click_through_url as destination_url,
  'NEWS GAM' AS ad_server,
  sum(total_line_item_level_impressions) AS impressions,
  sum(total_line_item_level_clicks) AS clicks
 FROM 
    {catalog}.{raw_schema}.gam_api_marketing_owned_operated_summary_with_impressions_and_error_count summary
LEFT JOIN 
    {catalog}.{silver_schema}.dim_ad_unit au
      ON summary.ad_unit_id = au.ad_unit_id AND au.network_group_id = 4145
LEFT JOIN
    {catalog}.{silver_schema}.dim_line_item li
      ON summary.line_item_id = li.line_item_id
WHERE 
  ad_unit_name ilike '%fxw%'
   and (advertiser_id = 4870164238 AND creative_click_through_url ilike '%fox.com%' 
          or advertiser_id=5848968151)
GROUP BY
   1,2,3,4,5,6

UNION ALL
-- FTS GAM
select
  event_date as date,
  dimension_line_item_name as creative_name,
  'FTS' as business_unit,
  'NA' as device_platform_name,
  creative_click_through_url as destination_url,
  'FTS GAM' as ad_server,
  sum(total_line_item_level_impressions) as impressions,
  sum(total_line_item_level_clicks) AS clicks
from
  {catalog}.{bronze_schema}.fts_delivery_gam_api_63790564 ft
  left join (select distinct dimension_line_item_id,dimension_line_item_name from {catalog}.{raw_schema}.fts_gam_line_item) dim
      on ft.line_item_id=dim.dimension_line_item_id
  where event_date >= DATE('2025-10-01') and order_id in (3820607981,3842930598)
GROUP BY 1,2,3,4,5,6

union all 
-- FTS GAM
select
  event_date as date,
  dimension_line_item_name as creative_name,
  'FTS' as business_unit,
  'NA' as device_platform_name,
  creative_click_through_url as destination_url,
  'FTS GAM' as ad_server,
  sum(total_line_item_level_impressions) as impressions,
  sum(total_line_item_level_clicks) AS clicks
from
  {catalog}.{bronze_schema}.fts_delivery_gam_api_63790564 ft
  left join (select distinct dimension_line_item_id,dimension_line_item_name from {catalog}.{raw_schema}.fts_gam_line_item) dim
      on ft.line_item_id=dim.dimension_line_item_id
  where event_date >= DATE('2025-10-01') and order_id in (3039856472, 424994244) and line_item_id in (6004535999, 6046533745, 6002559537, 6045137418, 6040268594, 6045137439, 6041571782, 6045136719)
GROUP BY 1,2,3,4,5,6

UNION ALL
-- SPORTS GAM ,
SELECT
  event_date as date,
  li.line_item_name as creative_name,
  'FOX Sports' as business_unit,
  au.platform_name as device_platform_name,
  creative_click_through_url as destination_url,
  'SPORTS GAM' AS ad_server,
  sum(total_line_item_level_impressions) AS impressions,
  sum(total_line_item_level_clicks) AS clicks
FROM
{catalog}.{raw_schema}.sports_gam_api_marketing_owned_operated_summary_with_impressions_and_viewability ft
LEFT JOIN {catalog}.{silver_schema}.dim_sports_gam_ad_unit au 
  ON ft.ad_unit_id = au.ad_unit_id and au.network_group_id = 20893548
LEFT JOIN {catalog}.{silver_schema}.dim_sports_gam_line_item li
  ON ft.line_item_id = li.line_item_id
WHERE
  event_date >= DATE('2025-10-01')
  AND advertiser_id in (5861093169,32014028)
GROUP BY
  1,2,3,4,5,6
UNION ALL
-- FW (516429 FOX CORP) , USING ONLY advert. name in filter as agency blank for these advertisers in hotb table
SELECT
  event_date as date,
  creative_name as creative_name,
  platform_name as business_unit,
  device_name as device_platform_name,
  'NA' as destination_url,
  'FREEWHEEL FOX CORP' AS ad_server,
  SUM(net_counted_ads) AS impressions,
  SUM(delivered_clicks) AS clicks
FROM
  fox_bi_prod.{silver_schema}.ft_freewheel_delivery_daily_data
WHERE
  event_date >= DATE('2025-10-01')
  AND insertion_order_id in (87579529,90538010,88835426)
GROUP BY
  1,2,3,4,5,6
UNION ALL
--- Tubi data
select
  date,
  creative_name as creative_name,
  'Tubi' as business_unit,
  'NA' as device_platform_name,
  'NA' as destination_url,
  'Tubi' as ad_server,
  sum(impressions_1p) as impressions,
  0 AS clicks
from
  adrise_share_prod.ads_curated.v_fox_one_daily_impressions
where
  advertiser_name = 'FOX Marketing'
  and creative_name ilike '%fox one%'
  and date >= '2025-10-01'
group by
  1,2,3,4,5,6

UNION ALL
SELECT
  event_date as date,
  creative_name as creative_name,
  'Tubi AdRise' as business_unit,
  device_name as device_platform_name,
  'NA' as destination_url,
  'FREEWHEEL FOX CORP' AS ad_server,
  SUM(net_counted_ads) AS impressions,
  SUM(delivered_clicks) AS clicks
FROM
  fox_bi_dev.{silver_schema}.ft_freewheel_promo_delivery
WHERE
  event_date >= DATE('2025-10-01')
GROUP BY
  1,2,3,4,5,6

  ) group by date,
      upper(creative_name),
      upper(business_unit),
      upper(device_platform_name),
      upper(destination_url),
      upper(ad_server)
;
 """.format(catalog=catalog,raw_schema=raw_schema,bronze_schema=bronze_schema,gold_schema=gold_schema_adsales,silver_schema=silver_schema)

# COMMAND ----------

marketing_O_O_daily = spark.sql(query)

# COMMAND ----------

marketing_O_O_daily_detailed = spark.sql(query_1)

# COMMAND ----------

marketing_O_O_daily.write.format('delta')\
     .mode('overwrite')\
     .option('mergeSchema', 'true')\
     .option('partitionOverwriteMode', 'dynamic')\
     .option('delta.enableDeletionVectors', 'false')\
     .option('delta.enableIcebergCompatV2', 'true')\
     .option('delta.universalFormat.enabledFormats', 'iceberg')\
     .option('delta.columnMapping.mode', 'name')\
     .saveAsTable(f'{catalog}.{gold_schema_ads}.agg_fox_one_promo_delivery')

# COMMAND ----------

marketing_O_O_daily_detailed.write.format('delta')\
     .mode('overwrite')\
     .option('mergeSchema', 'true')\
     .option('partitionOverwriteMode', 'dynamic')\
     .option('delta.enableDeletionVectors', 'false')\
     .option('delta.enableIcebergCompatV2', 'true')\
     .option('delta.universalFormat.enabledFormats', 'iceberg')\
     .option('delta.columnMapping.mode', 'name')\
     .saveAsTable(f'{catalog}.{gold_schema_ads}.agg_fox_one_promo_delivery_by_line_item')