# Databricks notebook source
marketing_o_o_config={
"dev": {
'catalog' : 'fox_bi_dev',
'raw_schema':'raw_ads',
'bronze_schema':'bronze_ads',
'silver_schema':'silver_ads',
'gold_schema_adsales' : 'gold_ad_sales',
'gold_schema_ads' : 'gold_ads',
'from_email':'adtech.dev@data.fox',
'to_mail':["yogesh.nageswararao@fox.com", "dharmender.hosiyar@fox.com"]
  },
"prod": {
'catalog' : 'fox_bi_prod',
'raw_schema':'raw_ads',
'bronze_schema':'bronze_ads',
'silver_schema':'silver_ads',
'gold_schema_adsales' : 'gold_ad_sales',
'gold_schema_ads' : 'gold_ads',
'from_email':'adtech.prod@data.fox',
'to_mail':["yogesh.nageswararao@fox.com","Anitha.Mohanraj@fox.com","data_adtech@fox.com",
                 "alex.lehman@fox.com"
                ]
  },
}


