﻿CREATE TABLE [stag].[S4Hana_MaterialsHierarchyTexts] (
    [HierarchyID]     NVARCHAR (2)  NOT NULL,
    [HierarchyNode]   NVARCHAR (18) NOT NULL,
    [Language]        NVARCHAR (2)  NOT NULL,
    [NodeDescription] NVARCHAR (40) NULL,
    [_LDTS]           DATETIME2 (7) NULL,
    [RowNo]           INT           NULL,
    [_BatchId]        INT           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

