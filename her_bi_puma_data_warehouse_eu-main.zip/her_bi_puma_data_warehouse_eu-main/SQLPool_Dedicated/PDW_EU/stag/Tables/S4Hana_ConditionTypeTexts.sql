﻿CREATE TABLE [stag].[S4Hana_ConditionTypeTexts] (
    [SPRAS]    NVARCHAR (2000) NULL,
    [KVEWE]    NVARCHAR (2000) NULL,
    [KAPPL]    NVARCHAR (2000) NULL,
    [KSCHL]    NVARCHAR (2000) NULL,
    [VTEXT]    NVARCHAR (2000) NULL,
    [_LDTS]    DATETIME        NULL,
    [_REC_SRC] NVARCHAR (2000) NULL,
    [ID]       INT             NULL,
    [RowNo]    INT             NULL,
    [_BatchId] INT             NULL
)
WITH (HEAP, DISTRIBUTION = ROUND_ROBIN);

