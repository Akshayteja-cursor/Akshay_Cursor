﻿CREATE TABLE [stag].[S4Hana_CreditLimitLmtRuleText] (
    [Language]      NVARCHAR (2)   NOT NULL,
    [LIMITRULE]     NVARCHAR (20)  NOT NULL,
    [LIMITRULETEXT] NVARCHAR (100) NULL,
    [_LDTS]         DATETIME2 (7)  NULL,
    [RowNo]         INT            NULL,
    [_BatchId]      INT            NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

