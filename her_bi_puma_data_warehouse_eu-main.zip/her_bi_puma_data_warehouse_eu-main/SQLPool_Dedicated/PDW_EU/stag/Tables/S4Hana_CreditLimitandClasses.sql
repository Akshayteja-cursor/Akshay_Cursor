﻿CREATE TABLE [stag].[S4Hana_CreditLimitandClasses] (
    [PARTNER]       NVARCHAR (10) NOT NULL,
    [CREDITSEGMENT] NVARCHAR (4)  NULL,
    [CHECKRULE]     NVARCHAR (2)  NULL,
    [LIMITRULE]     NVARCHAR (10) NULL,
    [RISKCLASS]     NVARCHAR (4)  NULL,
    [RowNo]         INT           NULL,
    [_BatchId]      INT           NULL,
    [_LDTS]         DATETIME2 (7) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

