﻿CREATE TABLE [stag].[S4Hana_InventoryStockCategoryTexts] (
    [Domainname]                 NVARCHAR (30) NOT NULL,
    [Language]                   NVARCHAR (2)  NOT NULL,
    [ActivationState]            NVARCHAR (1)  NOT NULL,
    [Domainvaluekey]             NVARCHAR (4)  NOT NULL,
    [Version]                    NVARCHAR (4)  NOT NULL,
    [InventoryStockCategory]     NVARCHAR (1)  NULL,
    [InventoryStockCategoryText] NVARCHAR (60) NULL,
    [_LDTS]                      DATETIME2 (7) NULL,
    [RowNo]                      INT           NULL,
    [_BatchId]                   INT           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

