﻿CREATE TABLE [stag].[S4Hana_AssortmentTexts] (
    [ASSORTMENT]                   NVARCHAR (15) NOT NULL,
    [ASSORTMENTNAME]               NVARCHAR (50) NULL,
    [ASSORTMENTCATEGORY]           NVARCHAR (1)  NULL,
    [ASSORTMENTSTATUS]             NVARCHAR (1)  NULL,
    [LSTGCNDNFORASSTMTISTOBECRTED] NVARCHAR (1)  NULL,
    [VALIDITYSTARTDATE]            DATE          NULL,
    [VALIDITYENDDATE]              DATE          NULL,
    [SALESORGANIZATION]            NVARCHAR (10) NULL,
    [DISTRIBUTIONCHANNEL]          NVARCHAR (10) NULL,
    [ZSEASON_YEAR]                 NVARCHAR (4)  NULL,
    [ZSEASON_CATEGORY]             NVARCHAR (4)  NULL,
    [ASSORTYP]                     NVARCHAR (5)  NULL,
    [ASSORDIMVAL1]                 NVARCHAR (2)  NULL,
    [_LDTS]                        DATETIME2 (7) NULL,
    [RowNo]                        INT           NULL,
    [_BatchId]                     INT           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

