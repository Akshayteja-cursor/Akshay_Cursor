﻿CREATE TABLE [stag].[S4Hana_MaterialTexts] (
    [MaterialNumber] NVARCHAR (40) NOT NULL,
    [Language]       NVARCHAR (2)  NOT NULL,
    [DESCRIPTION]    NVARCHAR (40) NULL,
    [_LDTS]          DATETIME2 (7) NULL,
    [RowNo]          INT           NULL,
    [_BatchId]       INT           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

