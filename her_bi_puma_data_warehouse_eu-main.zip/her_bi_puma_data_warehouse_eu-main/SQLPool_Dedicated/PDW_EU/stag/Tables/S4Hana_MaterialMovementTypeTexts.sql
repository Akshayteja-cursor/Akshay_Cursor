﻿CREATE TABLE [stag].[S4Hana_MaterialMovementTypeTexts] (
    [MovementType] NVARCHAR (3)  NOT NULL,
    [Language]     NVARCHAR (2)  NOT NULL,
    [MvtTypeText]  NVARCHAR (20) NULL,
    [_LDTS]        DATETIME2 (7) NULL,
    [RowNo]        INT           NULL,
    [_BatchId]     INT           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

