﻿CREATE TABLE [stag].[S4Hana_PUMADistributionChannelTexts] (
    [DistributionChannel] NVARCHAR (2)  NOT NULL,
    [LanguageKey]         NVARCHAR (2)  NOT NULL,
    [Name]                NVARCHAR (20) NULL,
    [_LDTS]               DATETIME2 (7) NULL,
    [RowNo]               INT           NULL,
    [_BatchId]            INT           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

