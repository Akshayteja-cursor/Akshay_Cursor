﻿CREATE TABLE [stag].[S4Hana_DeliveryDocumentTypeTexts] (
    [DELIVERYDOCTYPE]     NCHAR (4)       NULL,
    [LANGUAGE]            NVARCHAR (2000) NULL,
    [DELIVERYDOCTYPETEXT] VARCHAR (40)    NULL,
    [_LDTS]               DATETIME2 (7)   NULL,
    [RowNo]               INT             NULL,
    [_BatchId]            INT             NULL
)
WITH (HEAP, DISTRIBUTION = ROUND_ROBIN);

