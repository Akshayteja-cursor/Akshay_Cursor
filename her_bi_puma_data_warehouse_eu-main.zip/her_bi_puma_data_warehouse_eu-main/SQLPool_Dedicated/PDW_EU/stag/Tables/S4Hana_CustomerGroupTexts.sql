﻿CREATE TABLE [stag].[S4Hana_CustomerGroupTexts] (
    [LANGUAGEKEY]   NVARCHAR (2000) NULL,
    [CUSTOMERGROUP] NVARCHAR (2000) NULL,
    [DESCRIPTION]   NVARCHAR (2000) NULL,
    [_LDTS]         DATETIME        NULL,
    [RowNo]         INT             NULL,
    [_BatchId]      INT             NULL
)
WITH (HEAP, DISTRIBUTION = ROUND_ROBIN);

