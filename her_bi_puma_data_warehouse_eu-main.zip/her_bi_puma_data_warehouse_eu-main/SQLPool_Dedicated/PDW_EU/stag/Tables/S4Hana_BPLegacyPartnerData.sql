﻿CREATE TABLE [stag].[S4Hana_BPLegacyPartnerData]
(
	[__operation_type] [nvarchar](1) NULL,
	[__sequence_number] [bigint] NULL,
	[__timestamp] [bigint] NULL,
	[partner] [nvarchar](10) NULL,
	[LegacyPartnerType] [nvarchar](50) NULL,
	[LegacyPartnerNumber] [nvarchar](50) NULL,
	[ValidityDtFrom] [datetime2](7) NULL,
	[ValidityDtTo] [datetime2](7) NULL,
	[_LDTS] [datetime2](7) NULL,
	[RowNo] [int] NULL,
	[_BatchId] [int] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
GO
