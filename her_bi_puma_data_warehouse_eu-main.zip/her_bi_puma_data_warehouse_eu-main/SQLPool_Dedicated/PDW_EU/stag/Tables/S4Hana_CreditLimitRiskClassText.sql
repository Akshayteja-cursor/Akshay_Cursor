﻿CREATE TABLE [stag].[S4Hana_CreditLimitRiskClassText] (
    [Language]      NVARCHAR (2)  NOT NULL,
    [RISKCLASS]     NVARCHAR (2)  NOT NULL,
    [RISKCLASSTEXT] NVARCHAR (40) NULL,
    [_LDTS]         DATETIME2 (7) NULL,
    [RowNo]         INT           NULL,
    [_BatchId]      INT           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

