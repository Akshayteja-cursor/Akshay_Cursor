﻿CREATE TABLE [stag].[S4Hana_BusSegCodeTexts] (
    [CTYPE]       NVARCHAR (10)  NULL,
    [BRANDC]      NVARCHAR (10)  NULL,
    [PIDC]        NVARCHAR (10)  NULL,
    [LDATE]       DATE           NULL,
    [DESCRIPTION] NVARCHAR (100) NULL,
    [_LDTS]       DATETIME2 (7)  NULL,
    [RowNo]       INT            NULL,
    [_BatchId]    INT            NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

