﻿CREATE TABLE [stag].[S4Hana_BPAddressEmail] (
    [__operation_type]  NVARCHAR (1)   NULL,
    [__sequence_number] BIGINT         NULL,
    [__timestamp]       BIGINT         NULL,
    [BusinessPartner]   NVARCHAR (10)  NOT NULL,
    [AddressNumber]     NVARCHAR (10)  NOT NULL,
    [StrdAddress]       NVARCHAR (1)   NULL,
    [addrnumber]        NVARCHAR (10)  NULL,
    [persnumber]        NVARCHAR (10)  NULL,
    [ValidFromDflt]     DATE           NULL,
    [SequenceNumber]    NVARCHAR (3)   NULL,
    [StdSender]         NVARCHAR (1)   NULL,
    [NotUsed]           NVARCHAR (1)   NULL,
    [HomeFlag]          NVARCHAR (1)   NULL,
    [EmailAddress]      NVARCHAR (241) NULL,
    [FlagStdRecipient]  NVARCHAR (1)   NULL,
    [COnSapSys]         NVARCHAR (1)   NULL,
    [RequiredEncoding]  NVARCHAR (1)   NULL,
    [TNEFEncode]        NVARCHAR (1)   NULL,
    [ValidFrom]         NVARCHAR (14)  NULL,
    [ValidTo]           NVARCHAR (14)  NULL,
    [_LDTS]             DATETIME2 (7)  NULL,
    [RowNo]             INT            NULL,
    [_BatchId]          INT            NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

