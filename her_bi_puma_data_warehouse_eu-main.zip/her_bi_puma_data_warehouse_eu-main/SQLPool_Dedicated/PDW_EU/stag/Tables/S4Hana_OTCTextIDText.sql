﻿CREATE TABLE [stag].[S4Hana_OTCTextIDText] (
    [TECHNICALOBJECTTYPE] NVARCHAR (10) NULL,
    [DOCUMENTTEXTID]      NVARCHAR (10) NULL,
    [LANGUAGE]            NVARCHAR (2)  NULL,
    [TDIDDESC]            NVARCHAR (50) NULL,
    [_LDTS]               DATETIME2 (7) NULL,
    [RowNo]               INT           NULL,
    [_BatchId]            INT           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

