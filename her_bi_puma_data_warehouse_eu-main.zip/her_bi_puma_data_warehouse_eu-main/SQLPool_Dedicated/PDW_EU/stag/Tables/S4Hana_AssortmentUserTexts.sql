﻿CREATE TABLE [stag].[S4Hana_AssortmentUserTexts] (
    [ASSORTMENT]          NVARCHAR (15) NOT NULL,
    [SEQUENCENUMBER]      NVARCHAR (4)  NULL,
    [CUSTOMER]            NVARCHAR (15) NULL,
    [SITECUSTOMER]        NVARCHAR (10) NULL,
    [VALIDITYSTARTDATE]   DATE          NULL,
    [VALIDITYENDDATE]     DATE          NULL,
    [SALESORGANIZATION]   NVARCHAR (10) NULL,
    [DISTRIBUTIONCHANNEL] NVARCHAR (10) NULL,
    [CREATEDBY]           NVARCHAR (30) NULL,
    [ENTRYTIME]           TIME (7)      NULL,
    [CHANGEDBY]           NVARCHAR (30) NULL,
    [CHANGEDON]           DATE          NULL,
    [CHANGEDTIME]         TIME (7)      NULL,
    [_LDTS]               DATETIME2 (7) NULL,
    [RowNo]               INT           NULL,
    [_BatchId]            INT           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

