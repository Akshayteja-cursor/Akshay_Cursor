﻿CREATE TABLE [stag].[S4Hana_MaterialsHierarchy] (
    [HierarchyID]       NVARCHAR (2)  NOT NULL,
    [HierarchyNode]     NVARCHAR (18) NOT NULL,
    [ValidityStartDate] DATE          NOT NULL,
    [ValidityEndDate]   DATE          NULL,
    [ParentNode]        NVARCHAR (18) NULL,
    [Product]           NVARCHAR (40) NULL,
    [_LDTS]             DATETIME2 (7) NULL,
    [RowNo]             INT           NULL,
    [_BatchId]          INT           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

