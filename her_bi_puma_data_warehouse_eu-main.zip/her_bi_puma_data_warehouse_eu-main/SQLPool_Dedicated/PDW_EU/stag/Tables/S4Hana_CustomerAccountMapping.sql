﻿CREATE TABLE [stag].[S4Hana_CustomerAccountMapping] (
    [__operation_type]         NVARCHAR (1)  NULL,
    [__sequence_number]        BIGINT        NULL,
    [__timestamp]              BIGINT        NULL,
    [MasterCustomer]           NVARCHAR (10) NOT NULL,
    [ACCOUNT]                  NVARCHAR (10) NULL,
    [UserNameUserMasterRecord] NVARCHAR (12) NULL,
    [Daqte]                    DATE          NULL,
    [Time]                     BIGINT        NULL,
    [_LDTS]                    DATETIME2 (7) NULL,
    [RowNo]                    INT           NULL,
    [_BatchId]                 INT           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

