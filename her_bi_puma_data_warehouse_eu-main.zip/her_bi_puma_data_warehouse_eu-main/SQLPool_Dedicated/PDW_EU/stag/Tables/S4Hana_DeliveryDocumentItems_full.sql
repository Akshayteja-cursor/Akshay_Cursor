﻿CREATE TABLE [stag].[S4Hana_DeliveryDocumentItems_full] (
    [__operation_type]        NVARCHAR (1)  NULL,
    [__sequence_number]       BIGINT        NULL,
    [__timestamp]             BIGINT        NULL,
    [DeliveryDocument]        NVARCHAR (10) NOT NULL,
    [DeliveryDocumentItem]    NVARCHAR (6)  NOT NULL,
    [ActualDeliveryQuantity]  FLOAT (53)    NULL,
    [ReferenceSDDocument]     NVARCHAR (10) NULL,
    [ReferenceSDDocumentItem] NVARCHAR (6)  NULL,
    [_LDTS]                   DATETIME2 (7) NULL,
    [RowNo]                   INT           NULL,
    [_BatchId]                INT           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX ORDER([_LDTS]), DISTRIBUTION = HASH([ReferenceSDDocument]));



