﻿CREATE TABLE [stag].[S4Hana_DeliveryDocuments_full] (
    [__operation_type]             NVARCHAR (1)  NULL,
    [__sequence_number]            BIGINT        NULL,
    [__timestamp]                  BIGINT        NULL,
    [DeliveryDocument]             NVARCHAR (10) NOT NULL,
    [ActualGoodsMovementDate]      DATE          NULL,
    [ActualGoodsMovementTime]      BIGINT        NULL,
    [_LDTS]                        DATETIME2 (7) NULL,
    [RowNo]                        INT           NULL,
    [_BatchId]                     INT           NULL,
    [SDDocumentCategory]           NVARCHAR (4)  NULL,
    [TimeSegHeader]                NVARCHAR (50) NULL,
    [OverallDelivReltdBillgStatus] NVARCHAR (1)  NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

