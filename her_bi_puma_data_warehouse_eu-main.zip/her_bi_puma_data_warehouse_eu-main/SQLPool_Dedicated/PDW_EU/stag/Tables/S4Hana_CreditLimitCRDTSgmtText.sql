﻿CREATE TABLE [stag].[S4Hana_CreditLimitCRDTSgmtText] (
    [Language]       NVARCHAR (2)   NOT NULL,
    [CREDITSEGMENT]  NVARCHAR (5)   NOT NULL,
    [CREDITSGMNTTXT] NVARCHAR (100) NULL,
    [_LDTS]          DATETIME2 (7)  NULL,
    [RowNo]          INT            NULL,
    [_BatchId]       INT            NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

