﻿CREATE TABLE [stag].[S4Hana_InsuranceLimit] (
    [PARTNER]        NVARCHAR (10)   NULL,
    [CRITER]         NVARCHAR (4)    NULL,
    [ADDTYPE]        NVARCHAR (5)    NULL,
    [DATA_TYPE]      NVARCHAR (5)    NULL,
    [TIMESTAMP]      NVARCHAR (30)   NULL,
    [COUNTER]        INT             NULL,
    [CHECKBOX]       NVARCHAR (2)    NULL,
    [TEXT]           NVARCHAR (100)  NULL,
    [INSURANCELIMIT] DECIMAL (20, 2) NULL,
    [CURRENCY]       NVARCHAR (10)   NULL,
    [VALIDFROM]      NVARCHAR (10)   NULL,
    [VALIDTO]        NVARCHAR (10)   NULL,
    [ADDDATE]        NVARCHAR (10)   NULL,
    [_LDTS]          DATETIME2 (7)   NULL,
    [RowNo]          INT             NULL,
    [_BatchId]       INT             NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

