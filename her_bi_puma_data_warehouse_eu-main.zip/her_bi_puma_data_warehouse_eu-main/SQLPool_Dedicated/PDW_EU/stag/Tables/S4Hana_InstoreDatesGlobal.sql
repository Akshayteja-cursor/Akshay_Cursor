﻿CREATE TABLE [stag].[S4Hana_InstoreDatesGlobal] (
    [__operation_type]  NVARCHAR (1)  NULL,
    [__sequence_number] BIGINT        NULL,
    [__timestamp]       BIGINT        NULL,
    [Brand]             NVARCHAR (6)  NOT NULL,
    [Productdiv]        NVARCHAR (9)  NOT NULL,
    [SeasonYear]        NVARCHAR (4)  NOT NULL,
    [SeasonCategory]    NVARCHAR (2)  NOT NULL,
    [Linenamecode]      NVARCHAR (9)  NOT NULL,
    [BusiSeg]           NVARCHAR (6)  NOT NULL,
    [Forecastunit]      NVARCHAR (15) NOT NULL,
    [IsdFrom]           DATE          NULL,
    [IsdTo]             DATE          NULL,
    [Erdat]             DATE          NULL,
    [Aedat]             DATE          NULL,
    [_LDTS]             DATETIME2 (7) NULL,
    [RowNo]             INT           NULL,
    [_BatchId]          INT           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

