﻿CREATE TABLE [stag].[S4Hana_AssortmentCondTexts] (
    [ASSORTMENT]                    NVARCHAR (15) NOT NULL,
    [PRODUCT]                       NVARCHAR (40) NULL,
    [SALESUNIT]                     NVARCHAR (15) NULL,
    [LISTINGCONDITIONENDDATE]       DATE          NULL,
    [SEQUENCENUMBER]                NVARCHAR (4)  NULL,
    [LISTINGCONDITIONSTARTDATE]     DATE          NULL,
    [LASTCHANGEDATE]                DATE          NULL,
    [ASSORTMENTSTATUS]              NVARCHAR (4)  NULL,
    [PRODUCTOFSUPRORDLSTGCONDITION] NVARCHAR (40) NULL,
    [SALESORGANIZATION]             NVARCHAR (10) NULL,
    [_LDTS]                         DATETIME2 (7) NULL,
    [RowNo]                         INT           NULL,
    [_BatchId]                      INT           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

