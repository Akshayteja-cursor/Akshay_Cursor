﻿CREATE TABLE [stag].[S4Hana_CustomerAccountGroupTexts] (
    [CustomerAccountGroup]     NVARCHAR (4)  NOT NULL,
    [Language]                 NVARCHAR (2)  NOT NULL,
    [CustomerAccountGroupName] NVARCHAR (30) NULL,
    [_LDTS]                    DATETIME2 (7) NULL,
    [RowNo]                    INT           NULL,
    [_BatchId]                 INT           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

