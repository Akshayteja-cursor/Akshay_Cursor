﻿CREATE TABLE [stag].[S4Hana_CreditLimitCheckRuleText] (
    [Language]      NVARCHAR (2)   NOT NULL,
    [CHECKRULE]     NVARCHAR (2)   NOT NULL,
    [CHECKRULETEXT] NVARCHAR (100) NULL,
    [_LDTS]         DATETIME2 (7)  NULL,
    [RowNo]         INT            NULL,
    [_BatchId]      INT            NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

