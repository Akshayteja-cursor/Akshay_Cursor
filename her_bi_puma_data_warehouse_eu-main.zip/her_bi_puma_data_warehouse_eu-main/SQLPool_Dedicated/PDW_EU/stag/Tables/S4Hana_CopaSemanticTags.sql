﻿CREATE TABLE [stag].[S4Hana_CopaSemanticTags] (
    [GLAccount]          NVARCHAR (40) NOT NULL,
    [GLAccountHierarchy] NVARCHAR (42) NOT NULL,
    [SemanticTag]        NVARCHAR (10) NOT NULL,
    [ValidityEndDate]    NVARCHAR (60) NULL,
    [ValidityStartDate]  NVARCHAR (60) NULL,
    [ChartOfAccounts]    NVARCHAR (12) NULL,
    [_LDTS]              DATETIME2 (7) NULL,
    [RowNo]              INT           NULL,
    [_BatchId]           INT           NULL
)
WITH (CLUSTERED INDEX([GLAccount], [SemanticTag], [_LDTS]), DISTRIBUTION = HASH([GLAccount]));

