﻿CREATE TABLE [stag].[S4Hana_LocalDCTierText] (
    [SALESORGANIZATION] NVARCHAR (10) NULL,
    [LOCALDC]           NVARCHAR (10) NULL,
    [TIER]              NVARCHAR (10) NULL,
    [DESCRIPTION]       NVARCHAR (50) NULL,
    [ZDEFAULT]          NVARCHAR (10) NULL,
    [_LDTS]             DATETIME2 (7) NULL,
    [RowNo]             INT           NULL,
    [_BatchId]          INT           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

