﻿CREATE TABLE [stag].[S4Hana_CustSpecialistTexts] (
    [CUSTSPECIALIST] NVARCHAR (10) NOT NULL,
    [DESCRIPTION]    NVARCHAR (50) NULL,
    [_LDTS]          DATETIME2 (7) NULL,
    [RowNo]          INT           NULL,
    [_BatchId]       INT           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

