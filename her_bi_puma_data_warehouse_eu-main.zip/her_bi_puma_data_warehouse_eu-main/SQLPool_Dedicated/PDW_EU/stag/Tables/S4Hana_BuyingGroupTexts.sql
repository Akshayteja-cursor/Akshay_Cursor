﻿CREATE TABLE [stag].[S4Hana_BuyingGroupTexts] (
    [PurchasingGroup] NVARCHAR (3)  NOT NULL,
    [PurGrpText]      NVARCHAR (18) NULL,
    [_LDTS]           DATETIME2 (7) NULL,
    [RowNo]           INT           NULL,
    [_BatchId]        INT           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

