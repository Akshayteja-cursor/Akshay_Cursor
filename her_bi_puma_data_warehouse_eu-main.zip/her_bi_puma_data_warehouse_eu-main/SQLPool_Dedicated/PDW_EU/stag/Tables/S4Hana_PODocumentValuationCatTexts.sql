﻿CREATE TABLE [stag].[S4Hana_PODocumentValuationCatTexts] (
    [MANDT]    NVARCHAR (2000) NULL,
    [SPRAS]    NVARCHAR (2000) NULL,
    [BWTTY]    NVARCHAR (2000) NULL,
    [BTBEZ]    NVARCHAR (2000) NULL,
    [_LDTS]    DATETIME        NULL,
    [_REC_SRC] NVARCHAR (2000) NULL,
    [ID]       INT             NULL
)
WITH (HEAP, DISTRIBUTION = ROUND_ROBIN);

