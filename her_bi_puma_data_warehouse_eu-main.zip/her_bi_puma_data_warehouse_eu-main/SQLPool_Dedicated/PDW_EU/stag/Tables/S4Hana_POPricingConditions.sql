﻿CREATE TABLE [stag].[S4Hana_POPricingConditions] (
    [__operation_type]         NVARCHAR (1)  NULL,
    [__sequence_number]        BIGINT        NULL,
    [__timestamp]              BIGINT        NULL,
    [PricingDocument]          NVARCHAR (10) NOT NULL,
    [PricingDocumentItem]      NVARCHAR (6)  NOT NULL,
    [PricingProcedureStep]     NVARCHAR (3)  NOT NULL,
    [PricingProcedureCounter]  NVARCHAR (3)  NOT NULL,
    [ConditionApplication]     NVARCHAR (2)  NULL,
    [ValidFromDate]            NVARCHAR (14) NULL,
    [ConditionRateValue]       FLOAT (53)    NULL,
    [ConditionQuantity]        BIGINT        NULL,
    [ConditionType]            NVARCHAR (4)  NULL,
    [ConditionIsForStatistics] NVARCHAR (1)  NULL,
    [TransactionCurrency]      NVARCHAR (5)  NULL,
    [ConditionAmount]          FLOAT (53)    NULL,
    [ConditionCurrency]        NVARCHAR (5)  NULL,
    [CompanyCode]              NVARCHAR (4)  NULL,
    [SalesOrganization]        NVARCHAR (4)  NULL,
    [_LDTS]                    DATETIME2 (7) NULL,
    [RowNo]                    INT           NULL,
    [_BatchId]                 INT           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX ORDER([_LDTS]), DISTRIBUTION = HASH([PricingDocument]));



