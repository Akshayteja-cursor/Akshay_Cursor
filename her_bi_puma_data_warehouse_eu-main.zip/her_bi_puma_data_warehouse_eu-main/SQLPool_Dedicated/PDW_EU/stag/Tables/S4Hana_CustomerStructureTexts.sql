﻿CREATE TABLE [stag].[S4Hana_CustomerStructureTexts] (
    [MANDT]       NVARCHAR (2000) NULL,
    [ZREGR5]      NVARCHAR (2000) NULL,
    [DESCRIPTION] NVARCHAR (2000) NULL,
    [_LDTS]       DATETIME        NULL,
    [_REC_SRC]    NVARCHAR (2000) NULL,
    [ID]          INT             NULL,
    [RowNo]       INT             NULL,
    [_BatchId]    INT             NULL
)
WITH (HEAP, DISTRIBUTION = ROUND_ROBIN);

