﻿CREATE TABLE [stag].[S4Hana_AccountingClerkTexts] (
    [COMPANYCODE]    NVARCHAR (4)  NULL,
    [ACCTGCLERK]     NVARCHAR (10) NULL,
    [ACCTGCLERKDESC] NVARCHAR (60) NULL,
    [OFFICEUSER]     NVARCHAR (60) NULL,
    [_LDTS]          DATETIME      NULL,
    [RowNo]          INT           NULL,
    [_BatchId]       INT           NULL
)
WITH (HEAP, DISTRIBUTION = ROUND_ROBIN);

