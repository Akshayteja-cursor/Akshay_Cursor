﻿CREATE TABLE [stag].[S4Hana_OrderReasonTexts] (
    [LANGUAGE]         NVARCHAR (2)  NULL,
    [ORDERREASON]      NVARCHAR (3)  NULL,
    [ORDERDESCRIPTION] NVARCHAR (80) NULL,
    [_LDTS]            DATETIME2 (7) NULL,
    [RowNo]            INT           NULL,
    [_BatchId]         INT           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

