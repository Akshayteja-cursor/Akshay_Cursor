﻿CREATE TABLE [stag].[S4Hana_InstoreDatesLocal] (
    [__operation_type]  NVARCHAR (1)  NULL,
    [__sequence_number] BIGINT        NULL,
    [__timestamp]       BIGINT        NULL,
    [Style]             NVARCHAR (10) NOT NULL,
    [Color]             NVARCHAR (2)  NOT NULL,
    [SeasonYear]        NVARCHAR (4)  NOT NULL,
    [SeasonCategory]    NVARCHAR (2)  NOT NULL,
    [Forecastunit]      NVARCHAR (15) NOT NULL,
    [Erdat]             DATE          NULL,
    [Aedat]             DATE          NULL,
    [IsdFrom]           DATE          NULL,
    [IsdTo]             DATE          NULL,
    [_LDTS]             DATETIME2 (7) NULL,
    [RowNo]             INT           NULL,
    [_BatchId]          INT           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

