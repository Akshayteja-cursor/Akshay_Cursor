﻿CREATE TABLE [stag].[S4Hana_PackingRatio] (
    [SALESDOCUMENT]                  NVARCHAR (10)  NULL,
    [SALESDOCUMENTITEM]              NVARCHAR (6)   NULL,
    [VASSERVICETYPE]                 NVARCHAR (4)   NULL,
    [VASSUBSERVICETYPE]              NVARCHAR (6)   NULL,
    [GROUPINGFOREACHPACKING]         NVARCHAR (4)   NULL,
    [PACKINGNUMBER]                  NVARCHAR (40)  NULL,
    [CROSSPLANTCONFIGURABLEMATERIAL] NVARCHAR (18)  NULL,
    [MATERIAL]                       NVARCHAR (40)  NULL,
    [PACKEDQUANTITY]                 NVARCHAR (16)  NULL,
    [PACKEDQUANTITYUNIT]             NVARCHAR (4)   NULL,
    [SUBPACKINGPIECESPERCARTON]      NVARCHAR (10)  NULL,
    [PACKINGRATIO]                   NVARCHAR (10)  NULL,
    [PACKINGRATIOSUMMARY]            NVARCHAR (200) NULL,
    [PACKINGSTATUS]                  NVARCHAR (4)   NULL,
    [CREATEDBY]                      NVARCHAR (40)  NULL,
    [CREATEDON]                      NVARCHAR (20)  NULL,
    [_LDTS]                          DATETIME2 (7)  NULL,
    [RowNo]                          INT            NULL,
    [_BatchId]                       INT            NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

