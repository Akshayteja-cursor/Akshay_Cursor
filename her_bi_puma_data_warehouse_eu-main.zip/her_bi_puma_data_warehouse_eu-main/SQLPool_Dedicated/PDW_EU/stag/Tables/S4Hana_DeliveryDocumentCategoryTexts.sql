﻿CREATE TABLE [stag].[S4Hana_DeliveryDocumentCategoryTexts] (
    [SPRAS]    NVARCHAR (2000) NULL,
    [PSTYV]    NVARCHAR (2000) NULL,
    [VTEXT]    NVARCHAR (2000) NULL,
    [_LDTS]    DATETIME        NULL,
    [_REC_SRC] NVARCHAR (2000) NULL,
    [ID]       INT             NULL,
    [RowNo]    INT             NULL,
    [_BatchId] INT             NULL
)
WITH (HEAP, DISTRIBUTION = ROUND_ROBIN);

