﻿CREATE TABLE [stag].[S4Hana_OTCSpecificLongTexts] (
    [MANDT]               INT            NULL,
    [TEXTOBJECT]          NVARCHAR (20)  NULL,
    [TEXTNAME]            NVARCHAR (30)  NULL,
    [TEXTID]              NVARCHAR (10)  NULL,
    [LANGUAGE]            NVARCHAR (5)   NULL,
    [OBJECTNUMBER]        NVARCHAR (30)  NULL,
    [SALESORGANIZATION]   INT            NULL,
    [DISTRIBUTIONCHANNEL] INT            NULL,
    [DIVISION]            INT            NULL,
    [LONGTEXT]            NVARCHAR (500) NULL,
    [CREATEDON]           DATE           NULL,
    [CHANGEDON]           DATE           NULL,
    [ODQ_ENTITYCNTR]      NVARCHAR (50)  NULL,
    [_LDTS]               DATETIME2 (7)  NULL,
    [RowNo]               INT            NULL,
    [_BatchId]            INT            NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

