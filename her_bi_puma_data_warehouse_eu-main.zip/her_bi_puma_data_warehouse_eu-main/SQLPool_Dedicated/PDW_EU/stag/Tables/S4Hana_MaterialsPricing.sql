﻿CREATE TABLE [stag].[S4Hana_MaterialsPricing] (
    [TS_SEQUENCE_NUMBER] INT             NULL,
    [MATNR]              NVARCHAR (2000) NULL,
    [KSCHL]              NVARCHAR (2000) NULL,
    [KNUMH]              NVARCHAR (2000) NULL,
    [VKORG]              NVARCHAR (2000) NULL,
    [VTWEG]              NVARCHAR (2000) NULL,
    [PLTYP]              NVARCHAR (2000) NULL,
    [KUNNR]              NVARCHAR (2000) NULL,
    [DATAB]              NVARCHAR (2000) NULL,
    [DATBI]              NVARCHAR (2000) NULL,
    [KBETR]              NVARCHAR (2000) NULL,
    [KONWA]              NVARCHAR (2000) NULL,
    [ODQ_CHANGEMODE]     NVARCHAR (2000) NULL,
    [ODQ_ENTITYCNTR]     NVARCHAR (2000) NULL,
    [_LDTS]              DATETIME        NULL,
    [_REC_SRC]           NVARCHAR (2000) NULL,
    [ID]                 INT             NULL,
    [RowNo]              INT             NULL,
    [_BatchId]           INT             NULL
)
WITH (HEAP, DISTRIBUTION = ROUND_ROBIN);

