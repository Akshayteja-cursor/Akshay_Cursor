﻿CREATE TABLE [stag].[S4Hana_LocalCustomerGroupTexts] (
    [LOCALCUSTGR] NVARCHAR (2)  NOT NULL,
    [DESCRIPTION] NVARCHAR (30) NOT NULL,
    [_LDTS]       DATETIME2 (7) NULL,
    [RowNo]       INT           NULL,
    [_BatchId]    INT           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

