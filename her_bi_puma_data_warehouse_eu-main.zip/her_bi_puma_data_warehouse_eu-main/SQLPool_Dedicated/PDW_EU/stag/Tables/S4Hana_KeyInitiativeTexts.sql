﻿CREATE TABLE [stag].[S4Hana_KeyInitiativeTexts] (
    [KEYINITIATIVE] NVARCHAR (10)  NULL,
    [DESCRIPTION]   NVARCHAR (200) NULL,
    [_LDTS]         DATETIME2 (7)  NULL,
    [RowNo]         INT            NULL,
    [_BatchId]      INT            NULL
)
WITH (HEAP, DISTRIBUTION = REPLICATE);

