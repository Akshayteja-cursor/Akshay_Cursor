﻿CREATE TABLE [stag].[S4Hana_ARUN_SDO_ALLDOC] (
    [__operation_type]  NVARCHAR (1)    NULL,
    [__sequence_number] BIGINT          NULL,
    [__timestamp]       BIGINT          NULL,
    [ARunid]            NVARCHAR (40)   NOT NULL,
    [Plant]             NVARCHAR (4)    NULL,
    [Material]          NVARCHAR (40)   NULL,
    [Arun_Status]       NVARCHAR (1)    NULL,
    [Salesdoc_Num]      NVARCHAR (10)   NULL,
    [salesdoc_item]     NVARCHAR (6)    NULL,
    [itemPOSTOReturn]   NVARCHAR (5)    NULL,
    [REQ_type]          NVARCHAR (2)    NULL,
    [supplytype]        NVARCHAR (1)    NULL,
    [Stock_source]      NVARCHAR (1)    NULL,
    [STORAGE_LOCATION]  NVARCHAR (4)    NULL,
    [PONumberStock]     NVARCHAR (10)   NULL,
    [ALLOC_QTY]         DECIMAL (13, 3) NULL,
    [Base_Unit]         NVARCHAR (3)    NULL,
    [REQUESTED_DATE]    DATE            NULL,
    [MatAvailDate]      DATE            NULL,
    [Delivery_Date_PO]  NVARCHAR (20)   NULL,
    [WithdrawalQty]     DECIMAL (13, 3) NULL,
    [Pirdate]           NVARCHAR (20)   NULL,
    [_LDTS]             DATETIME2 (7)   NULL,
    [RowNo]             INT             NULL,
    [_BatchId]          INT             NULL
)
WITH (HEAP, DISTRIBUTION = ROUND_ROBIN);



