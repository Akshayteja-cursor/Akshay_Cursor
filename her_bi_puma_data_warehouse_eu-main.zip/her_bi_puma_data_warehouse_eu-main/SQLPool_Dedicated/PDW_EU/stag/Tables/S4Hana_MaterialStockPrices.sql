﻿CREATE TABLE [stag].[S4Hana_MaterialStockPrices] (
    [__operation_type]      NVARCHAR (1)  NULL,
    [__sequence_number]     BIGINT        NULL,
    [__timestamp]           BIGINT        NULL,
    [Material]              NVARCHAR (40) NOT NULL,
    [Plant]                 NVARCHAR (4)  NOT NULL,
    [ValuationType]         NVARCHAR (10) NOT NULL,
    [PriceControlIndicator] NVARCHAR (1)  NULL,
    [MovingAveragePrice]    FLOAT (53)    NULL,
    [StandardPrice]         FLOAT (53)    NULL,
    [PriceUnit]             BIGINT        NULL,
    [PriceCurrency]         NVARCHAR (5)  NULL,
    [LastChangedAt]         DATETIME2 (7) NULL,
    [CompanyCode]           NVARCHAR (4)  NULL,
    [_LDTS]                 DATETIME2 (7) NULL,
    [RowNo]                 INT           NULL,
    [_BatchId]              INT           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);



