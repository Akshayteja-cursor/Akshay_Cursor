﻿CREATE TABLE [stag].[S4Hana_MaterialTypeTexts] (
    [Language]         NVARCHAR (2)  NOT NULL,
    [Materialtype]     NVARCHAR (4)  NOT NULL,
    [MaterialTypetext] NVARCHAR (25) NULL,
    [_LDTS]            DATETIME2 (7) NULL,
    [RowNo]            INT           NULL,
    [_BatchId]         INT           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

