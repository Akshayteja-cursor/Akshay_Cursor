﻿CREATE TABLE [stag].[S4Hana_FreeAvailableStock] (
    [__operation_type]    NVARCHAR (1)  NULL,
    [__sequence_number]   BIGINT        NULL,
    [__timestamp]         BIGINT        NULL,
    [Plant]               NVARCHAR (4)  NOT NULL,
    [Material]            NVARCHAR (40) NOT NULL,
    [RequirementSegment]  NVARCHAR (40) NOT NULL,
    [StockSegment]        NVARCHAR (40) NOT NULL,
    [SequentialNumber]    NVARCHAR (10) NOT NULL,
    [ConfirmedDateATP]    DATE          NULL,
    [MRPElement]          NVARCHAR (2)  NULL,
    [CharacteristicValue] NVARCHAR (18) NULL,
    [ean_nr]              NVARCHAR (18) NULL,
    [upc_nr]              NVARCHAR (18) NULL,
    [quantity]            FLOAT (53)    NULL,
    [BaseUnitOfMeasure]   NVARCHAR (3)  NULL,
    [TimeStamp]           BIGINT        NULL,
    [_LDTS]               DATETIME2 (7) NULL,
    [RowNo]               INT           NULL,
    [_BatchId]            INT           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = HASH([Material]));

