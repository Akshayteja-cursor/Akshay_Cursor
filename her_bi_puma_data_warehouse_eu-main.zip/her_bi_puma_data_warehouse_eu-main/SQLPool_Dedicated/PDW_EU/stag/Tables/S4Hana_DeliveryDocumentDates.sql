﻿CREATE TABLE [stag].[S4Hana_DeliveryDocumentDates] (
    [__operation_type]  NVARCHAR (1)  NULL,
    [__sequence_number] BIGINT        NULL,
    [__timestamp]       BIGINT        NULL,
    [TimeSegHeader]     NVARCHAR (50) NULL,
    [MileStone]         NVARCHAR (10) NULL,
    [TransactionType]   INT           NULL,
    [VersionType]       NVARCHAR (1)  NULL,
    [VersionNumber]     INT           NULL,
    [StartTimeUTC]      DATETIME      NULL,
    [MileStoneDate]     DATE          NULL,
    [MileStoneTime]     BIGINT        NULL,
    [_LDTS]             DATETIME2 (7) NULL,
    [RowNo]             INT           NULL,
    [_BatchId]          INT           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

