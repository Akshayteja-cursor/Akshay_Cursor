﻿CREATE TABLE [stag].[S4Hana_POAssignments] (
    [__operation_type]        NVARCHAR (1)  NULL,
    [__sequence_number]       BIGINT        NULL,
    [__timestamp]             BIGINT        NULL,
    [PURCHASINGDOCUMENT]      NVARCHAR (10) NOT NULL,
    [PURCHASINGDOCUMENTITEM]  NVARCHAR (5)  NOT NULL,
    [ACCOUNTASSIGNMENTNUMBER] NVARCHAR (2)  NOT NULL,
    [DATECHANGED]             DATE          NULL,
    [QUANTITY]                FLOAT (53)    NULL,
    [PURGDOCNETAMOUNT]        FLOAT (53)    NULL,
    [ISDELETED]               NVARCHAR (1)  NULL,
    [BUSINESSAREA]            NVARCHAR (4)  NULL,
    [SALESORDER]              NVARCHAR (10) NULL,
    [SALESORDERITEM]          NVARCHAR (6)  NULL,
    [SALESORDERSCHEDULELINE]  NVARCHAR (4)  NULL,
    [ORDERID]                 NVARCHAR (12) NULL,
    [UNLOADINGPOINTNAME]      NVARCHAR (25) NULL,
    [CREATIONDATE]            DATE          NULL,
    [GOODSRECIPIENTNAME]      NVARCHAR (12) NULL,
    [ISFINALLYINVOICED]       NVARCHAR (1)  NULL,
    [ORDERINTERNALID]         NVARCHAR (10) NULL,
    [COMPANYCODE]             NVARCHAR (4)  NULL,
    [_LDTS]                   DATETIME2 (7) NULL,
    [RowNo]                   INT           NULL,
    [_BatchId]                INT           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

