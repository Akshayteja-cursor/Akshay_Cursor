CREATE FUNCTION [stag].[S4Hana_fnSOSupplyAssignments] (@LDTS [DATETIME2](7)) RETURNS TABLE
AS
RETURN (
    SELECT
          ARunId
        , SalesOrderNo
        , SalesOrderItemNo
        , ARunStatus
        , AssignedQuantityARun
        , SalesOrganizationCode
        , StockSource
        , IsDeleted
        , LDTS

    FROM
          (
              SELECT
                    sosa.ARUNID                                  AS ARunId                  -- BK
                  , sosa.SALESDOC_NUM                            AS SalesOrderNo
                  , sosa.salesdoc_item                           AS SalesOrderItemNo
                  , sosa.ARUN_STATUS                             AS ARunStatus
                  , CAST(sosa.ALLOC_QTY AS DECIMAL(15, 2))       AS AssignedQuantityARun
                  , SalesOrganization                            AS SalesOrganizationCode
                  , StockSource                                  AS StockSource
                  , CAST(CASE
                             WHEN sosa.__operation_type = 'X'
                                 THEN 1
                             ELSE 0
                         END AS BIT)                             AS IsDeleted
                  , sosa._LDTS                                   AS LDTS
                  , ROW_NUMBER() OVER (PARTITION BY
                                           sosa.ARUNID
                                       ORDER BY sosa._LDTS DESC
                                              , sosa.__timestamp DESC
                                      )                          AS RN
              FROM  stag.S4Hana_SOSupplyAssignments AS sosa
              WHERE  sosa._LDTS >= @LDTS
          ) X
    WHERE RN = 1
)
GO
