﻿﻿CREATE FUNCTION [stag].[S4Hana_fnPODocumentItems] (@LDTS [DATETIME2](7)) RETURNS TABLE
AS
RETURN (
    SELECT
          PONo
        , POItemNo
        , DeletionCode
        , IsCompletelyDelivered
        , MaterialNumber
        , EAN
        , FactoryCode
        , SiteCode
        , RequestedDeliveryDate
        , OrderQuantity        
        , NetAmount 
        , PlannedDeliveryDate
        , LastConfirmedDeliveryDate
        , ExpectedHandoverDate
        , ActualHandoverDate
        , CountryOfOrigin
        , ShippingInstructionCode
		, StorageLocation
		, StockSegment
		, ISSSTORLOCSTO
        , LegacyPONumber
        , LegacyPOItemNumber
		, RequisitionerName
        , IsDeleted
        , LDTS
    FROM
          (
              SELECT
                    podi.PURCHASINGDOCUMENT                      AS PONo         --BK
                  , podi.PURCHASINGDOCUMENTITEM                  AS POItemNo     --BK
                  , podi.PURCHASINGDOCUMENTDELETIONCODE          AS DeletionCode
                  , podi.ISCOMPLETELYDELIVERED                   AS IsCompletelyDelivered
                  , podi.MATERIAL                                AS MaterialNumber
                  , podi.INTERNATIONALARTICLENUMBER              AS EAN
                  , podi.FACTORYDATA                             AS FactoryCode
                  , podi.PLANT                                   AS SiteCode     --Receiving Plant
                  , podi.REQUESTEDDELIVERYDATE                   AS RequestedDeliveryDate                  
                  , CAST(podi.ORDERQUANTITY AS DECIMAL(13, 3))   AS OrderQuantity
                  , CAST(podi.NETAMOUNT AS DECIMAL(13, 2))       AS NetAmount
                  , podi.PLANNEDDELIVERYDATE                     AS PlannedDeliveryDate
                  , podi.LASTCONFIRMEDDELIVERYDATE               AS LastConfirmedDeliveryDate
                  , podi.EXPECTEDHANDOVERDATE                    AS ExpectedHandoverDate
                  , podi.ACTUALHANDOVERDATE                      AS ActualHandoverDate
                  , podi.COUNTRYOFORIGIN                         AS CountryOfOrigin
                  , podi.SHIPPINGINSTRUCTION                     AS ShippingInstructionCode
				  , podi.StorageLocation
				  , podi.StockSegment
				  , podi.ISSSTORLOCSTO
                  , podi.LegacyPONumber
                  , podi.LegacyPOItemNumber
				  , podi.RequisitionerName
				  , CAST(CASE
                             WHEN podi.__operation_type = 'X'
                                 THEN 1
                             ELSE 0
                         END AS BIT)                             AS IsDeleted
                  , podi._LDTS                                   AS LDTS
                  , ROW_NUMBER() OVER (PARTITION BY
                                           podi.PURCHASINGDOCUMENT  
                                         , podi.PURCHASINGDOCUMENTITEM
                                       ORDER BY podi._LDTS DESC
                                              , podi.__timestamp DESC
                                      )                          AS RN
              FROM  stag.S4Hana_PODocumentItems        AS podi
              WHERE podi._LDTS >= @LDTS
          ) X
    WHERE RN = 1
)