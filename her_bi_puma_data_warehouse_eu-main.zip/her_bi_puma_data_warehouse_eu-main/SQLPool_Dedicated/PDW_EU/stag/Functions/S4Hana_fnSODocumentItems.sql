CREATE FUNCTION [stag].[S4Hana_fnSODocumentItems] (@ldts [Datetime2](7)) RETURNS TABLE
AS
RETURN (

SELECT
	 [SalesDocument]													     		AS [SalesDocument]
	,[SalesDocumentItem]															AS [SalesDocumentItem]
    ,[SDDocumentRejectionStatus]													AS [SDDocumentRejectionStatus]
	,[IncompletionStatus]															AS [IncompletionStatus]
	,[IncompletionStatusBilling]													AS [IncompletionStatusBilling]
	,[IncompletionStatusDelivery]													AS [IncompletionStatusDelivery]
	,[SalesDocumentType]															AS [SalesDocumentType]
	,[BillingCompanyCode]															AS [BillingCompanyCode] 
	,[SalesOrganization]															AS [SalesOrganization]
	,[NameOfOrderer]																AS [NameOfOrderer]
	,[AgrmtValdtyStartDate]															AS [AgrmtValdtyStartDate]
	,[AgrmtValdtyEndDate]															AS [AgrmtValdtyEndDate]
	,[ShippingCondition]															AS [ShippingCondition]
	,[SalesDocumentRjcnReason]														AS [RejectionReason]
	,[LastChangeDate]																AS [LastChangeDate]
	,[EAN]																			AS [EAN]
	,[CreationDate]																	AS [CreationDate]
    ,[CreationDateItem]														        AS [CreationDateItem]
	,CAST([OrderQuantity]	AS NUMERIC(15,3))										AS [OrderQuantity]
	,CAST([Subtotal1Amount] AS NUMERIC(13,2))										AS [Subtotal1Amount]
	,CAST([Subtotal2Amount]	AS NUMERIC(13,2))										AS [Subtotal2Amount]
	,CAST([Subtotal3Amount]	AS NUMERIC(13,2))										AS [Subtotal3Amount]    
	,CAST([Subtotal4Amount]	AS NUMERIC(13,2))										AS [Subtotal4Amount]
	,CAST([Subtotal5Amount]	AS NUMERIC(13,2))										AS [Subtotal5Amount]
	,CAST([Subtotal6Amount]	AS NUMERIC(13,2))										AS [Subtotal6Amount]
    ,[RequestedDeliveryDate]                                                        AS [RequestedDeliveryDate]
	,[StorageLocation]																AS [StorageLocation]
	,[Material]																		AS [Material]
	,CAST([TaxAmount]	AS NUMERIC(13,2))											AS [TaxAmount]
	,CAST([NetAmount]   AS NUMERIC(15,2))											AS [NetAmount]
	,TransactionCurrency                                                            AS [TransactionCurrency]
    ,[ReferenceSDDocument]															AS [ReferenceSDDocument]
	,[ReferenceDocumentItemNumber]													AS [ReferenceDocumentItemNumber]
	,[PrecedingDocumentCategory]													AS [PrecedingDocumentCategory]
	,CAST([CostAmount]	AS NUMERIC(13,2))											AS [CostAmount]
	,[Plant]																		AS [Plant] 
	,[ProductSeason]																AS [ProductSeason]
	,[ProductSeasonYear]														    AS [ProductSeasonYear]
	,[BillingDate]														        	AS [BillingDate]
	,[IncotermsClassification]														AS [IncotermsClassification]
	,[IncotermsTransferLocation]													AS [IncotermsTransferLocation]
	,[Promotion]																	AS [Promotion]
	,[PurchaseOrderByCustomer]														AS [PurchaseOrderByCustomer] 
	,[CustomerConditionGroup1]														AS [CustomerConditionGroup1]
	,[FixedValueDate]																AS [FixedValueDate]
	,[CustomerPaymentTerms]															AS [CustomerPaymentTerms] 
	,[SalesRepParty]																AS [SalesRepParty] --> XS
	--,[BuyerParty]																	AS [BuyerParty] --> ZE
	,[ShipToParty]																	AS [ShipToParty] --> WE
	,[BillToParty]																	AS [BillToParty] --> RE
	,[PayerParty]																	AS [PayerParty] --> RG
	--,[BuygroupParty]																AS [BuygroupParty] --> ZB
	,[OwnerGrParty]																	AS [OwnerGrParty] --> ZW
	--,[InvoicerecParty]																AS [InvoicerecParty] --> ZI
	--,[ForwagtParty]																	AS [ForwagtParty] --> SP
	,[SoldToParty]																	AS [SoldToParty] --> AG
	--,[custServRepParty]																AS [custServRepParty] --> ZS
	--,[salesrepmanParty]																AS [salesrepmanParty] --> ZT
    ,[DeliveryBlockReason]                                                          AS [DeliveryBlockReason]
    ,[PricingDate]                                                                  AS [PricingDate]
    ,[CustomerPurchaseOrderType]													AS [CustomerPurchaseOrderType]
	,[Route]																		AS [Route]
	,[YourReference]																AS [YourReference]
	,[version]																		AS [Version]
	,[SalesDocumentItemCategory]													AS [SalesDocumentItemCategory] 
    ,[UltimateCustomerBarcode]                                                      AS [UltimateCustomerBarcode] 
    ,[OuterCartonPackFactor]                                                        AS [OuterCartonPackFactor]
    ,[POType]                                                                       AS [POType]
    ,[DistributionChannel]                                                          AS [DistributionChannel]
    ,[SDDocumentReason]                                                             AS [SDDocumentReason]
	,[FirstConfirmedDeliveryDate]													AS [FirstConfirmedDeliveryDate]
	,[OriginalRequestedDeliveryDate]												AS [OriginalRequestedDeliveryDate]
	,[LatestRDD]																	AS [LatestRDD]
	,[LatestFCDD]																	AS [LatestFCDD]
	,[LatestCDD]																	AS [LatestCDD]
    ,MaterialByCustomer                                                             AS MaterialByCustomer
    ,SDDocumentCollectiveNumber                                                     AS SDDocumentCollectiveNumber
	,CustomerPurchaseOrderSuplmnt													AS CustomerPurchaseOrderSuplmnt
	,HeaderBillingBlockReason														AS HeaderBillingBlockReason 
    ,NetPriceAmount																	AS NetPriceAmount
   	,totalSDDocReferenceStatus														AS totalSDDocReferenceStatus
    ,CreatedByUser																	AS CreatedByUser
    ,RequirementSegment																AS RequirementSegment
    ,CustomerOrdertype                                                              AS CustomerOrdertype
    ,CorrespncExternalReference                                                     AS CorrespncExternalReference
    ,InnerCartonPackFactor                                                        AS InnerCartonPackFactor
	,CAST (CASE WHEN a.[__operation_type] = 'X' THEN 1 ELSE 0 END AS BIT) AS IsDeleted
	,a._LDTS												AS LDTS
	FROM	(SELECT	*
			,ROW_NUMBER() OVER (PARTITION BY [SalesDocument], [SalesDocumentItem] ORDER BY _LDTS DESC,__Timestamp DESC)	AS Rng
			FROM stag.S4Hana_SODocumentItems a
			WHERE a._LDTS >= @ldts
			) AS a 
	WHERE a.Rng=1		
		)
GO
