﻿CREATE FUNCTION [stag].[S4Hana_fnFreeAvailableStock] (@LDTS [DATETIME2](7)) RETURNS TABLE
AS
RETURN SELECT	
			Ranked.__operation_type,
			Ranked.Plant,
			Ranked.Material,
			Ranked.RequirementSegment,
			Ranked.StockSegment,
			CONCAT('F', Ranked.SequentialNumber) AS SequentialNumber,
			Ranked.MRPElement,
			Ranked.RunningTotal,
			Ranked.BaseUnitOfMeasure,
			Ranked.PostingDate,
			Ranked._LDTS
FROM	(
--DECLARE @LDTS DATETIME2(7)='2023-09-11 06:01:57.0000000'
			SELECT	SHFAS.__operation_type,
						SHFAS.Plant,
						SHFAS.Material,
						SHFAS.RequirementSegment,
						SHFAS.StockSegment,
						SHFAS.SequentialNumber,
						SHFAS.MRPElement,
						CONVERT(DECIMAL(15,3), SHFAS.quantity) AS RunningTotal,
						SHFAS.BaseUnitOfMeasure,
						CONVERT(DATE,
							DATEADD(HOUR, CONVERT(INT, LEFT(TZI.current_utc_offset, 3))
										, CONVERT(DATETIME,LEFT(CONVERT(VARCHAR(20), SHFAS.TimeStamp),8)
										+' '+SUBSTRING(CONVERT(VARCHAR(20), SHFAS.TimeStamp),9,2)
										+':'+SUBSTRING(CONVERT(VARCHAR(20), SHFAS.TimeStamp),11,2)
										+':'+RIGHT(CONVERT(VARCHAR(20), SHFAS.TimeStamp),2)))) AS PostingDate,
						SHFAS._LDTS,
						ROW_NUMBER() OVER(PARTITION BY SHFAS.Plant, SHFAS.Material, SHFAS.RequirementSegment, SHFAS.StockSegment, SHFAS.SequentialNumber ORDER BY SHFAS.Timestamp DESC) AS Rnk
			FROM stag.S4Hana_FreeAvailableStock AS SHFAS
				LEFT JOIN sys.time_zone_info AS TZI ON TZI.NAME='Central European Standard Time'
			WHERE SHFAS._LDTS>=DATEADD(DAY, -1, CONVERT(DATE, @LDTS))
					AND SHFAS.TimeStamp>0
					AND SHFAS.StockSegment='WHS'
					AND SHFAS.MRPElement='WB'
					AND DATEADD(DAY, -1, CONVERT(DATE, @LDTS)) = CONVERT(DATE,
																					DATEADD(HOUR, CONVERT(INT, LEFT(TZI.current_utc_offset, 3))
																								, CONVERT(DATETIME,LEFT(CONVERT(VARCHAR(20), SHFAS.TimeStamp),8)
																								+' '+SUBSTRING(CONVERT(VARCHAR(20), SHFAS.TimeStamp),9,2)
																								+':'+SUBSTRING(CONVERT(VARCHAR(20), SHFAS.TimeStamp),11,2)
																								+':'+RIGHT(CONVERT(VARCHAR(20), SHFAS.TimeStamp),2))))
		) AS Ranked
WHERE Ranked.Rnk=1
