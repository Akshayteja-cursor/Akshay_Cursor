﻿CREATE FUNCTION [stag].[S4Hana_fnDeliveryDocumentItems] (@ldts [DATETIME2](7)) RETURNS TABLE
AS
RETURN (

SELECT
		deli.DELIVERYDOCUMENTITEMCATEGORY							AS DeliveryNoteItemCategory
		,deli.CREATIONDATE											AS CreationDate
		,deli.CREATIONTIME											AS CreationTime
		,deli.DISTRIBUTIONCHANNEL									AS DistributionChannel
		,deli.DIVISION												AS Division
		,deli.MATERIAL												AS MaterialNumber
		,deli.MATERIALBYCUSTOMER									AS MaterialByCustomer
		,deli.INTERNATIONALARTICLENUMBER							AS EAN
		,deli.PLANT													AS SiteCode
		,deli.STORAGELOCATION										AS StorageLocation
		,deli.INVENTORYSPECIALSTOCKTYPE								AS InventorySpecialStockTypeCode
		,CAST(deli.ACTUALDELIVERYQUANTITY		AS DECIMAL(13,3)) 	AS ActualDeliveryQuantity
		,CAST(deli.ORIGINALDELIVERYQUANTITY		AS DECIMAL(13,3)) 	AS OriginalDeliveryQuantity
		,deli.DELIVERYQUANTITYUNIT									AS DeliveryQuantityUnit
		,CAST(deli.ACTUALDELIVEREDQTYINBASEUNIT AS DECIMAL(13,3)) 	AS ActualDeliveryQuantityBaseUnit
		,deli.BASEUNIT												AS BaseUnit
		,CAST(deli.ITEMGROSSWEIGHT				AS DECIMAL(15,3)) 	AS ItemGrossWeight
		,CAST(deli.ITEMNETWEIGHT				AS DECIMAL(15,3)) 	AS ItemNetWeight
		,deli.ITEMWEIGHTUNIT										AS ItemWeightUnit
		,CAST(deli.ITEMVOLUME					AS DECIMAL(15,3)) 	AS ItemVolume
		,deli.ITEMVOLUMEUNIT										AS ItemVolumeUnit
		,deli.PARTIALDELIVERYISALLOWED								AS PartialDeliveryAllowed
		,deli.STOCKTYPE												AS StockType
		,deli.ISCOMPLETELYDELIVERED									AS IsCompletelyDelivered
		,deli.ORDERID												AS OrderNo
		,deli.ORDERITEM										 		AS OrderItemNo
		,deli.REFERENCESDDOCUMENT									AS ReferenceDocumentNo
		,deli.REFERENCESDDOCUMENTITEM								AS ReferenceDocumentItemNo
		,deli.REFERENCESDDOCUMENTCATEGORY							AS ReferenceDocumentCategory
		,deli.ADDITIONALCUSTOMERGROUP1								AS DeliveryPriority
		,deli.ADDITIONALCUSTOMERGROUP2								AS BookingInType
		,deli.ADDITIONALCUSTOMERGROUP3								AS ADDITIONALCUSTOMERGROUP3
		,deli.ADDITIONALCUSTOMERGROUP4								AS BuyingGroup
		,deli.ADDITIONALCUSTOMERGROUP5								AS ForReporting
		,deli.SDPROCESSSTATUS										AS SDProcessStatus
		,deli.PICKINGSTATUS											AS PickingStatus
		,deli.PACKINGSTATUS											AS PackingStatus
		,deli.GOODSMOVEMENTSTATUS									AS GoodsMovementStatus
		,deli.STOCKSEGMENT											AS StockSegment
		,deli.PRODUCTCHARACTERISTIC1								AS ProductCharacteristic1
		,deli.PRODUCTCHARACTERISTIC2								AS ProductCharacteristic2
		,deli.PRODUCTCHARACTERISTIC3								AS ProductCharacteristic3
		,deli.ORIGINSDDOCUMENT										AS OriginDocumentNo
		,deli.SDDOCUMENTITEM										AS OriginDocumentItemNo
		,deli.SALESSDDOCUMENTCATEGORY								AS SDDocumentCategory
		,deli.MATERIALTYPEPRIMARY									AS MaterialType
		,deli.ORDERDOCUMENT											AS SONumber
		,deli.DELIVERYDOCUMENTITEM									AS DeliveryNoteItemNo
		,deli.DELIVERYDOCUMENT										AS DeliveryNoteNumber
		,deli.CreatedByUser											AS CreatedByUser
		,deli.ProfitCenter											AS ProfitCenter
		,deli.RequirementSegment									AS RequirementSegment
		,deli.ProductAvailabilityDate								AS ProductAvailabilityDate
		,deli.ProductAvailabilityTime								AS ProductAvailabilityTime
		,CAST(CASE WHEN deli.[__operation_type] = 'X' THEN 1 ELSE 0 END AS BIT) AS IsDeleted
		,deli._LDTS													AS LDTS
	FROM	(SELECT	*
			,ROW_NUMBER() OVER (PARTITION BY DELIVERYDOCUMENT, DELIVERYDOCUMENTITEM ORDER BY _LDTS DESC,__timestamp DESC)	AS Rng
			FROM [stag].[S4Hana_DeliveryDocumentItems]
			WHERE _LDTS >= @ldts ) AS deli
	WHERE deli.Rng=1

		 )
