﻿CREATE FUNCTION [stag].[S4Hana_fnPOPricingConditions] (@LDTS [DATETIME2](7)) RETURNS TABLE
AS
RETURN (
    SELECT
          PricingDocument
        , PricingDocumentItem
        , PricingProcedureStep
        , PricingProcedureCounter
        , CompanyCode
        , ConditionApplication
        , ConditionTypeCode
        , ConditionAmount
        , IsDeleted
        , LDTS
    FROM
          (
              SELECT
                    popc.PRICINGDOCUMENT                         AS PricingDocument         -- BK
                  , popc.PRICINGDOCUMENTITEM                     AS PricingDocumentItem     -- BK
                  , popc.PRICINGPROCEDURESTEP                    AS PricingProcedureStep    -- BK
                  , popc.PRICINGPROCEDURECOUNTER                 AS PricingProcedureCounter -- BK
                  , popc.COMPANYCODE                             AS CompanyCode
                  , popc.CONDITIONAPPLICATION                    AS ConditionApplication
                  , popc.CONDITIONTYPE                           AS ConditionTypeCode
                  , CAST(popc.CONDITIONAMOUNT AS DECIMAL(15, 2)) AS ConditionAmount
                  , CAST(CASE
                             WHEN popc.__operation_type = 'X'
                                 THEN 1
                             ELSE 0
                         END AS BIT)                             AS IsDeleted
                  , popc._LDTS                                   AS LDTS
                  , ROW_NUMBER() OVER (PARTITION BY
                                           popc.PRICINGDOCUMENT
                                         , popc.PRICINGDOCUMENTITEM
                                         , popc.PRICINGPROCEDURESTEP
                                         , popc.PRICINGPROCEDURECOUNTER
                                       ORDER BY popc._LDTS DESC
                                              , popc.__timestamp DESC
                                      )                          AS RN
              FROM  stag.S4Hana_POPricingConditions    AS popc
              WHERE popc._LDTS >= @LDTS
          ) X
    WHERE RN = 1
)
