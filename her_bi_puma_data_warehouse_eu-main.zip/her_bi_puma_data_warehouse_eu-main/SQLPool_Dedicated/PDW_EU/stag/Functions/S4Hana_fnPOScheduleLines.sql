﻿CREATE FUNCTION [stag].[S4Hana_fnPOScheduleLines] (@LDTS [DATETIME2](7)) RETURNS TABLE
AS
RETURN (
    SELECT
          PONo
        , POItemNo
        , ScheduleLineCount
        , DeliveryDate
        , RoughGoodsReceiptQuantity
        , IsDeleted
        , LDTS
    FROM
          (
              SELECT
                    posl.PURCHASINGDOCUMENT                                     AS PONo              -- BK
                  , posl.PURCHASINGDOCUMENTITEM                                 AS POItemNo          -- BK
                  , posl.SCHEDULELINE                                           AS ScheduleLineCount -- BK
                  , posl.SCHEDULELINEDELIVERYDATE                               AS DeliveryDate
                  , CAST(posl.ROUGHGOODSRECEIPTQTY AS DECIMAL(13, 3))           AS RoughGoodsReceiptQuantity
                  , CAST(CASE
                             WHEN posl.__operation_type = 'X'
                                 THEN 1
                             ELSE 0
                         END AS BIT)                                            AS IsDeleted
                  , posl._LDTS                                                  AS LDTS
                  , ROW_NUMBER() OVER (PARTITION BY
                                           posl.PURCHASINGDOCUMENT
                                         , posl.PURCHASINGDOCUMENTITEM
                                         , posl.SCHEDULELINE
                                       ORDER BY posl._LDTS DESC
                                              , posl.__timestamp DESC
                                      )                                         AS RN
              FROM  stag.S4Hana_POScheduleLines        AS posl
              WHERE posl._LDTS >= @LDTS
          ) X
    WHERE RN = 1
)
