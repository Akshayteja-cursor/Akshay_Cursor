﻿CREATE FUNCTION [stag].[S4Hana_fnDeliveryDocuments] (@ldts [Datetime2](7)) RETURNS TABLE
AS
RETURN (
 SELECT
     del.DELIVERYDOCUMENT									AS DeliveryNoteNumber
	,del.DELIVERYDOCUMENTTYPE								AS DeliveryNoteDocType
	,del.CREATIONDATE										AS CreationDate
	,del.CREATIONTIME										AS CreationTime
	,del.SALESORGANIZATION									AS SalesOrganization
	,del.COMPLETEDELIVERYISDEFINED							AS CompleteDeliveryDefined
	,del.DELIVERYPRIORITY									AS DeliveryPriority
	,del.DELIVERYBLOCKREASON								AS DeliveryBlockReason
	,del.ISEXPORTDELIVERY									AS IsExportDelivery
	,del.ORDERID											AS OrderNo
	,CAST(del.HEADERGROSSWEIGHT				AS DECIMAL(15,3))	AS GrossWeight
	,CAST(del.HEADERNETWEIGHT				AS DECIMAL(15,3))	AS NetWeight
	,del.HEADERWEIGHTUNIT									AS WeightUnit
	,CAST(del.HEADERVOLUME					AS DECIMAL(15,3))	AS Volume
	,del.HEADERVOLUMEUNIT									AS VolumeUnit
	,del.GOODSISSUEORRECEIPTSLIPNUMBER						AS GoodsReceiptIssueSlipNo
	,del.DOCUMENTDATE										AS DocumentDate
	,del.PICKINGDATE										AS PickingDate
	,del.PICKINGTIME										AS PickingTime
	,del.BILLOFLADING										AS BillOfLading
	,del.SHIPTOPARTY										AS CustomerCode_ShipTo
	,del.SHIPPINGTYPE										AS ShippingType
	,del.DELIVERYDATE										AS DeliveryDate
	,del.SHIPPINGCONDITION									AS ShippingCondition
	,del.TRANSPORTATIONPLANNINGDATE							AS TransportationPlanningDate
	,del.ACTUALDELIVERYROUTE								AS ActualDeliveryRoute
	,del.ACTUALGOODSMOVEMENTDATE							AS ActualGoodsMovementDate
	,del.INCOTERMSCLASSIFICATION							AS IncotermsClassification
	,del.INCOTERMSTRANSFERLOCATION							AS IncotermsTransferLocation
	,del.MEANSOFTRANSPORT									AS MeansOfTransportCode
	,del.SOLDTOPARTY										AS CustomerCode_SoldTo
    ,del.TransactionCurrency                                AS TransactionCurrency
	,del.OVERALLSDPROCESSSTATUS								AS OverallSDProcessStatus
	,del.OVERALLPICKINGSTATUS								AS OverallPickingStatus
	,del.OVERALLPACKINGSTATUS								AS OverallPackingStatus
	,del.OVERALLGOODSMOVEMENTSTATUS							AS OverallGoodsMovementStatus
	,del.OVERALLDELIVRELTDBILLGSTATUS						AS OverallBillingStatus
	,del.REFERENCEDOCUMENTNUMBER							AS RefDocumentNo
	,del.DELETIONINDICATOR									AS DeletionIndicator
	,del.TOTALCREDITCHECKSTATUS								AS TotalCreditCheckStatus
    ,del.MeansOfTransport                                   AS MeansOfTransport
    ,del.SpecialProcessingCode                              AS SpecialProcessingCode
    ,del.LoadingDate                                        As ActualLoadingDate
    ,del.DeliveryDocumentBySupplier                         As DeliveryDocumentBySupplier
    ,del.SDDocumentCategory
	,del.SpecialLogisticsProcess							AS SpecialLogisticsProcess
	,del.PlannedGoodsIssueDate								AS PlannedGoodsIssueDate
	,del.TimeSegHeader										AS TimeSegHeader
	,CAST (CASE WHEN del.[__operation_type] = 'X' THEN 1 ELSE 0 END AS BIT) AS IsDeleted
	,del._LDTS												AS LDTS
	FROM	(SELECT	*
			,ROW_NUMBER() OVER (PARTITION BY DELIVERYDOCUMENT ORDER BY _LDTS DESC,__Timestamp DESC)	AS Rng
			FROM stag.S4Hana_DeliveryDocuments
			WHERE _LDTS >= @ldts
			) AS del
	WHERE del.Rng=1
	--AND ([SDDocumentCategory]= 'J' OR [SDDocumentCategory]= '')

		)