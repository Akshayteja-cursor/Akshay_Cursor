﻿CREATE FUNCTION [stag].[S4Hana_fnSoRejectionDates] (@ldts [DATETIME2](7)) RETURNS TABLE
AS
RETURN (

SELECT distinct
		  [vbeln]							AS SalesDocument
		  ,[posnr]							AS SalesDocumentItem
		  ,[udate]							AS RejectionDate
		  ,[value_new]						AS value_new
		  ,[value_old]						AS value_old
          ,[changenr]                         AS changenr --Stelli: for showing original Rejection Date
		  ,CAST (CASE WHEN a.[__operation_type] = 'X' THEN 1 ELSE 0 END AS BIT) AS IsDeleted
		  ,a.[_LDTS]                        AS LDTS
	   FROM  (SELECT *
			,ROW_NUMBER() OVER (PARTITION BY vbeln, posnr ORDER BY [_LDTS] DESC, [udate] DESC, [utime] DESC  ) AS Rng
			FROM [stag].[S4Hana_SORejectionDates]
			WHERE _LDTS >= @ldts
		) AS a
		WHERE a.Rng = 1
)
GO  
