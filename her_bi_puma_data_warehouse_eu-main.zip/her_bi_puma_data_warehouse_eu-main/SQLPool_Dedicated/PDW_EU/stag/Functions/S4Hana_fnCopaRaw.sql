﻿CREATE FUNCTION [stag].[S4Hana_fnCopaRaw] (@ldts [datetime2](7)) RETURNS TABLE
AS
RETURN (
	SELECT * FROM (
		SELECT 
		  --cr.SourceLedger													--BK
		  LTRIM(RTRIM(cr.CompanyCode)) 				AS CompanyCode			--BK
		  ,cr.FiscalYear													--BK
		  ,LTRIM(RTRIM(cr.AccountingDocument))		AS AccountingDocNo		--BK
		  --,cr.LedgerGLLineItem											--BK
		  ,cr.ChartOfAccounts
		  ,cr.ReferenceDocumentType
		  ,LTRIM(RTRIM(cr.ReferenceDocument))       AS ReferenceDocNo
		  ,LTRIM(RTRIM(cr.ReferenceDocumentItem))   AS ReferenceDocItemNo
		  ,cr.GLAccount
		  ,cr.ProfitCenter   						AS ProfitCenterCode
		  ,cr.TransactionCurrency					AS CurrencyCode
		  ,cr.AmountInCompanyCodeCurrency
		  ,cr.Quantity 
		  ,cr.PostingDate
		  ,cr.DocumentDate						AS CreationDate 
		  ,cr.SalesOrder						AS NatSalesOrderNo
		  ,cr.SalesOrderItem					AS NatSalesOrderItemNo
		  ,LTRIM(RTRIM(cr.Plant))				AS Plant
		  ,LTRIM(RTRIM(cr.Customer))			AS CustomerCode_SoldTo
		  ,CASE WHEN cr.GLAccount in ('0000301121','0000302131', '0000303121', '0000304121') THEN 'BI_2'
		  WHEN cr.GLAccount in ('0000301010','0000302010', '0000303010', '0000304010', '0000313010') THEN 'BI_3' ELSE
			cr.BillingDocumentType END         	AS BillingDocTypeCode
		  ,cr.DistributionChannel				AS DistributionChannelCode
		  ,LTRIM(RTRIM(cr.SoldProduct))  		AS MaterialNumber
		  ,LTRIM(RTRIM(cr.BillToParty))         AS CustomerCode_BillTo
		  ,LTRIM(RTRIM(cr.ShipToParty))         AS CustomerCode_ShipTo
		  ,cr.CustomerSupplierCorporateGroup	AS GroupKey
		  ,cr.BusSegment						AS BusSegmentCode
		  ,cr.BusSubSegment						AS BusSubSegmentCode
		  ,LTRIM(RTRIM(cr.ProductDivision))     AS ProdDivCode 
		  ,CAST(cr.RBU AS INT)					AS RBUCode
		  ,CAST(cr.ReferenceRBU AS INT)    		AS RefRBUCode
		  ,cr.SalesDocumentType					AS SOTypeCode
		  ,LTRIM(RTRIM(cr.Payer))				AS Payer
		  ,cr.Brand1							AS BrandCode
		  ,LTRIM(RTRIM(cr.SalesRep))			AS SalesRep
		  ,LTRIM(RTRIM(cr.OwnerGroup))          AS CustomerCode_OwnerGroup 
		  ,LTRIM(RTRIM(cr.DiscreasonCode))      AS DiscountReasonCode 
          ,cr.ProfitCenter      
          ,cr.OrderID			
          ,cr.CostCenter		
          ,cr.AccountingDocument
	      ,NULL as SeasonYear--cr.SeasonYear
          ,NULL as Season --cr.Season
		  ,cr.[_LDTS] AS LDTS
		  ,ROW_NUMBER() OVER (PARTITION BY cr.SourceLedger,cr.CompanyCode,cr.FiscalYear,cr.AccountingDocument,cr.LedgerGLLineItem ORDER BY cr.[_LDTS] DESC,cr.[__timestamp] DESC)	AS Rng
	  FROM stag.S4Hana_CopaRaw AS cr JOIN (SELECT DISTINCT CompanyCode FROM stag.S4Hana_vSalesOrgToCompanyCode) AS sct ON cr.CompanyCode = sct.CompanyCode
	  WHERE (cr.AccountingDocumentCategory <> 'D' and cr.AccountingDocumentCategory <> 'M') 
		AND (cr.SourceLedger ='Z1' or cr.SourceLedger ='0L') 
		AND (cr.GLAccount BETWEEN '0000200000' AND '0000499999' OR cr.GLAccount in ('000007Z','000004Z'))
		AND _LDTS >= @ldts
				) AS crFiltered
	WHERE crFiltered.Rng=1
)