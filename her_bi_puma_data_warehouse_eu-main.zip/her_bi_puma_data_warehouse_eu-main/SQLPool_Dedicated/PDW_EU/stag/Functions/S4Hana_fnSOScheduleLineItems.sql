﻿CREATE FUNCTION [stag].[S4Hana_fnSOScheduleLineItems] () RETURNS TABLE
AS
RETURN (

SELECT distinct 
        [SalesDocument]									AS [SalesDocument]
      ,[SalesDocumentItem]								AS [SalesDocumentItem]
      ,[ScheduleLine]									AS [ScheduleLine]
      ,[SalesDocumentDate]								AS [SalesDocumentDate]
      ,[ShippingCondition]								AS [ShippingCondition]
      ,[DeliveryPriority]								AS [DeliveryPriority]
      ,[GoodsMovementType]								AS [GoodsMovementType]
      ,[DeliveredQtyInOrderQtyUnit]						AS [DeliveredQtyInOrderQtyUnit]
      ,[CreationDate]									AS [CreationDate]
      ,[LastChangeDate]									AS [LastChangeDate]
      ,[SDDocumentCategory]								AS [SDDocumentCategory]
      ,[SalesDocumentType]								AS [SalesDocumentType]
      ,[SalesDocumentItemCategory]						AS [SalesDocumentItemCategory]
      ,[ScheduleLineCategory]							AS [ScheduleLineCategory]
      ,[SalesOrganization]								AS [SalesOrganization]
      ,[DistributionChannel]							AS [DistributionChannel]
      ,[Division]										AS [Division]
      ,[PricingDate]									AS [PricingDate]
      ,[Material]										AS [Material]
      ,[ProductAvailabilityDate]						AS [ProductAvailabilityDate]
      ,[InternationalArticleNumber]						AS [InternationalArticleNumber]
      ,[IsConfirmedDelivSchedLine]						AS [IsConfirmedDelivSchedLine]
      ,[IsRequestedDelivSchedLine]						AS [IsRequestedDelivSchedLine]
      ,[TargetQuantityUnit]								AS [TargetQuantityUnit]
      ,[CorrectedQtyInOrderQtyUnit]						AS [CorrectedQtyInOrderQtyUnit]
      ,[OrderQuantityUnit]								AS [OrderQuantityUnit]
      ,[ConfdOrderQtyByMatlAvailCheck]					AS [ConfirmedOrderQuantity]
      ,[ScheduleLineOrderQuantity]						AS [ScheduleLineOrderQuantity]
      ,[BaseUnit]										AS [BaseUnit]
      ,[DeliveryDate]									AS [DeliveryDate]
      ,[RequestedDeliveryDate]							AS [RequestedDeliveryDate]
      ,[StatisticsCurrency]								AS [StatisticsCurrency]
      ,[Route]											AS [Route]
      ,[Plant]											AS [Plant]
      ,[StorageLocation]								AS [StorageLocation]
      ,[ShippingPoint]									AS [ShippingPoint]
      ,[IncotermsClassification]						AS [IncotermsClassification]
      ,[IncotermsTransferLocation]						AS [IncotermsTransferLocation]
      ,[IncotermsVersion]								AS [IncotermsVersion]
      ,[DeliveryBlockReason]							AS [DeliveryBlockReason]
      ,[ConfdSchedLineReqdDelivDate]					AS [ConfdSchedLineReqdDelivDate]
      ,[ConfirmedDeliveryDate]							AS [ConfirmedDeliveryDate]
      ,[MRPRequiredQuantityInBaseUnit]					AS [MRPRequiredQuantityInBaseUnit]
      ,[DelivBlockReasonForSchedLine]					AS [DelivBlockReasonForSchedLine]
      ,[LoadingDate]									AS [LoadingDate]
      ,[TransportationPlanningDate]						AS [TransportationPlanningDate]
      ,[GoodsIssueDate]									AS [GoodsIssueDate]
      ,[BindingPeriodValidityStartDate]					AS [BindingPeriodValidityStartDate]
      ,[BindingPeriodValidityEndDate]					AS [BindingPeriodValidityEndDate]
      ,[BillingCompanyCode]								AS [BillingCompanyCode]
      ,[ItemBillingBlockReason]							AS [ItemBillingBlockReason]
      ,[TransactionCurrency]							AS [TransactionCurrency]
      ,[SDDocumentRejectionStatus]						AS [SDDocumentRejectionStatus]
      ,[_LDTS]											AS [LDTS]
	  ,CAST (CASE WHEN [__operation_type] = 'X' 
		THEN 1 ELSE 0 END AS BIT)						AS IsDeleted
	 FROM	(SELECT	*
			,ROW_NUMBER() OVER (PARTITION BY [SalesDocument], [SalesDocumentItem],[ScheduleLine] ORDER BY _LDTS DESC,__Timestamp DESC)	AS Rng
			FROM [stag].[S4Hana_SOScheduleLineItems] a
			) AS a 
	WHERE a.Rng=1

	)
