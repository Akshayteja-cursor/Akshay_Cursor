﻿CREATE FUNCTION [stag].[S4Hana_fnMaterialStockPricesHistory] (@LDTS [DATETIME2](7)) RETURNS TABLE
AS
RETURN SELECT Ranked.__operation_type,
       Ranked.__sequence_number,
       Ranked.__timestamp,
       Ranked.Material,
       Ranked.Plant,
       Ranked.ValuationType,
       Ranked.FiscalYear,
       Ranked.PERIOD,
       Ranked.PriceControlIndicator,
       Ranked.MovingAveragePrice,
       Ranked.StandardPrice,
       Ranked.PriceUnit,
       Ranked.PriceCurrency,
       Ranked.CompanyCode,
       Ranked.Country,
       Ranked._LDTS,
       Ranked.RowNo,
       Ranked._BatchId,
       Ranked.Rnk
FROM	(
			SELECT SHMSPH.__operation_type,
					 SHMSPH.__sequence_number,
					 SHMSPH.__timestamp,
					 SHMSPH.Material,
					 SHMSPH.Plant,
					 SHMSPH.ValuationType,
					 SHMSPH.FiscalYear,
					 SHMSPH.Period,
					 SHMSPH.PriceControlIndicator,
					 SHMSPH.MovingAveragePrice,
					 SHMSPH.StandardPrice,
					 SHMSPH.PriceUnit,
					 SHMSPH.PriceCurrency,
					 SHMSPH.CompanyCode,
					 SHMSPH.Country,
					 SHMSPH._LDTS,
					 SHMSPH.RowNo,
					 SHMSPH._BatchId,
					 ROW_NUMBER() OVER (PARTITION BY SHMSPH.Material, SHMSPH.Plant, SHMSPH.FiscalYear, SHMSPH.Period ORDER BY SHMSPH.__timestamp DESC, SHMSPH._LDTS DESC) AS Rnk
			FROM stag.S4Hana_MaterialStockPricesHistory AS SHMSPH
			WHERE SHMSPH._LDTS=@LDTS
					--SHMSPH.Material='599939-01-160' AND SHMSPH.Plant='DE01' AND SHMSPH.FiscalYear='2019' AND SHMSPH.Period='12'
		) AS Ranked
WHERE Ranked.Rnk=1
