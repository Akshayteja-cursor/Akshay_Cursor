﻿CREATE PROC [stag].[spCleanUp_ARUN] AS   
BEGIN

SET NOCOUNT ON;
SET ANSI_WARNINGS ON;

DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(7) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(7)
DECLARE @DestinationLastLoadDate DATETIME2(7)
DECLARE @BatchLdts DATETIME2(7)
DECLARE @AffectedRows BIGINT = NULL

	-- get Information for Logging
IF(EXISTS(SELECT 1 FROM stag.S4Hana_ARUN_SDO_ALLDOC))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(_LDTS))
		FROM stag.S4Hana_ARUN_SDO_ALLDOC
	END
ELSE 
	BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' 
	END 

IF(EXISTS(SELECT 1 FROM stag.S4Hana_ARUN_SDO_ALLDOC))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MIN(_LDTS))
		FROM stag.S4Hana_ARUN_SDO_ALLDOC
	END
ELSE 
	BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01'
	END
-- Logging Informations END


-- Log first DATA Informations

INSERT INTO etl.DataTransferLogs
(
  DataTransferLogId
, TransferName
, TransferGroupName
, TargetTableName
, TargetSchemaName
, ExecStart
, SourceLastLoadDate
, DestinationLastLoadDate
, BatchLdts
)
SELECT 
  @DataTransferLogId 
, 'SPCleanUp_ARUN'
, 'S4Hana_ARUN_SDO_ALLDOC'
, 'S4Hana_ARUN_SDO_ALLDOC'
, 'stag'
, @ExecStart
, @SourceLastLoadDate
, @DestinationLastLoadDate
, @DestinationLastLoadDate;

	IF OBJECT_ID(N'tempdb..#Deleted') IS NOT NULL DROP TABLE #Deleted
	IF OBJECT_ID(N'tempdb..#valid') IS NOT NULL DROP TABLE #valid
	IF OBJECT_ID(N'tempdb..#ToDel') IS NOT NULL DROP TABLE #ToDel


IF DATENAME(WEEKDAY, GETDATE()) = 'Sunday'
BEGIN
/*BeginWeekendCleanup*/

	
SELECT ARunid  INTO #Deleted
    FROM [stag].[S4Hana_vARUN_Latest_WithDeletionStatus]
			WHERE [__operation_type] = 'X'


SELECT DISTINCT arunid INTO #valid 
FROM  STAG.[S4Hana_ARUN_SDO_ALLDOC] 
WHERE __operation_type <> 'X'

select d.arunid INTO #ToDel 
FROM  #deleted d LEFT JOIN #valid a
ON d.arunid = a.arunid 
WHERE a.arunid IS NULL 


DELETE arun 
FROM  STAG.[S4Hana_ARUN_SDO_ALLDOC]  arun INNER JOIN #ToDel d
ON arun.arunid = d.arunid 


;WITH cte AS
(	
SELECT *,CONVERT([BINARY](16),
		HASHBYTES('MD5',CONCAT(
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), Plant	)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), Material	)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), Arun_Status	)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), Salesdoc_Num	)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), salesdoc_item	)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), itemPOSTOReturn	)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), REQ_type	)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), supplytype	)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), Stock_source	)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), STORAGE_LOCATION	)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PONumberStock	)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ALLOC_QTY	)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), Base_Unit	)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), REQUESTED_DATE	)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), MatAvailDate	)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), Delivery_Date_PO	)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), WithdrawalQty))))	
))) AS HashDiff
FROM STAG.[S4Hana_ARUN_SDO_ALLDOC]
)
,cte2 AS
(
SELECT *
	,LAG(HashDiff) OVER (PARTITION BY Salesdoc_Num, salesdoc_item,PONumberStock  ORDER BY _LDTS) AS HashDiff_prevRow
FROM cte
)
DELETE f
FROM cte2 c INNER JOIN STAG.[S4Hana_ARUN_SDO_ALLDOC] f
ON  c.Plant=	f.Plant	
AND c.Material = f.Material
AND c.Arun_Status = f.Arun_Status
AND c.Salesdoc_Num = f.Salesdoc_Num
AND c.salesdoc_item = f.salesdoc_item
AND c.itemPOSTOReturn = f.itemPOSTOReturn
AND c.REQ_type = f.REQ_type
AND c.supplytype = f.supplytype
AND c.Stock_source = f.Stock_source
AND c.STORAGE_LOCATION = f.STORAGE_LOCATION
AND c.PONumberStock = f.PONumberStock
AND c.ALLOC_QTY = f.ALLOC_QTY
AND c.Base_Unit = f.Base_Unit
AND c.REQUESTED_DATE = f.REQUESTED_DATE
AND c.MatAvailDate = f.MatAvailDate
AND c.Delivery_Date_PO = f.Delivery_Date_PO
AND c.WithdrawalQty = f.WithdrawalQty
AND	c._ldts	= f._ldts 
WHERE c.HashDiff  = ISNULL(c.HashDiff_prevRow,0);

/*EndOfWeekendCleanup*/
END 

END
