﻿CREATE PROC [stag].[spCleanUp_StagTables] @SchemaName [VARCHAR](250),@TblName [VARCHAR](250),@BKs [VARCHAR](250),@OrderDup [VARCHAR](250),@SequenceNum [VARCHAR](250),@DatabaseName [VARCHAR](250),@DoBackup [CHAR],@DoDedup [CHAR],@LastLDTS [VARCHAR](30) AS 
BEGIN
 
	SET NOCOUNT ON;
	SET ANSI_WARNINGS ON;
	--sp describtion
---- =============================================
---- Author:      <>
---- Create Date: <2022.06.23>
---- Description: <Data CleanUp /Archiving deprecated data from [stag].* tables. > 
----				<has 4 steps groups:  1.Prepare components for Dynamic-SQL  INSERT&DELETE statements in dependence of input parameters values.					>
----				<					  2.delete region specific data (base on BUKRS & VKORG values)																>
----				<					  3.delete data ranked over BK and ordered by LDTS , Sequense  , batchid etc. In result remains - Last valid record per BK.	>
----				<					  4.deduplication of the rows in order to keep row uniqueness over all table.												>
---- =============================================
	--params describtion
--@SchemaName		VARCHAR(250),   -- affected table schema name
--@TblName		VARCHAR(250),	-- affected table name
--@BKs			VARCHAR(250),	-- Bussiness keys fields
--@OrderDup		VARCHAR(250),	-- provides field name for ORDER BY clause into ranking expression.
--@SequenceNum	VARCHAR(250),	-- provides second field name for ORDER BY clause into ranking expression.
--@DatabaseName	VARCHAR(250),	-- name of affected database
--@DoBackup		CHAR,			-- flag - force to do create backup tables for rows which are going to be deleted from affected table
--@DoDedup		CHAR			-- flag - force deduplication statements to run
--@LastLDTS		VARCHAR(30)		-- it is a data time value, coming in CHAR format in order to be integrated into dynamic SQL without supplimentary CAST expression. Indicated data when a table was cleaned last time. 
								-- consequently, allow to reduce, dataset for cleansing in case of repeatable data cleanup operation

DECLARE @sqlcmd NVARCHAR(MAX) --main variable for dynamic sql execution
-------------------------------------------------------------------------------------------
--put BKs into brackets for proper SELECT
SELECT @BKs  = CONCAT('[',REPLACE(@BKs,',','],['),']')
--process NULLs into BK fields
DECLARE @BKs_COALESCE VARCHAR(500);
SELECT @BKs_COALESCE = CONCAT('COALESCE(r.',REPLACE(@BKs,',',',''N''),COALESCE(r.'),',''N'')')
--explicit conversion for temp tables
DECLARE @BKs_Cast VARCHAR(500);
SELECT @BKs_Cast = STRING_AGG(joinCond, ',') FROM (SELECT CONCAT('CAST(',value,' AS NVARCHAR(250)) AS ',value) joinCond FROM STRING_SPLIT(@BKs, ',')) t;
----------------------------------------------------------------------------------------------
--build WHERE clause for DELETE per DB (BUKRS & VKORG)
DECLARE @where VARCHAR(250) = '';

SELECT @where = 
 CASE WHEN column_name = 'BUKRS' AND TABLE_CATALOG = 'bieuropeprdpdw_se' THEN ' WHERE BUKRS NOT IN (''ES10'',''IT10'',''PT10'')'
		WHEN column_name = 'BUKRS' AND TABLE_CATALOG = 'bieuropeprdpdw_peg' THEN ' WHERE BUKRS IN (''ES10'',''IT10'',''PT10'')'
		WHEN column_name = 'BUKRS' AND TABLE_CATALOG = 'bieuropeprdpdw_fra' THEN ' WHERE BUKRS NOT IN (''ES10'',''IT10'',''PT10'')'
		ELSE '' END
 FROM INFORMATION_SCHEMA.COLUMNS
 WHERE TABLE_CATALOG = @DatabaseName
	AND table_schema = @SchemaName
	AND table_name = @TblName
    AND column_name = ('BUKRS')


IF COALESCE(@where,'') = '' 
	BEGIN
		SELECT @where = 
		 CASE WHEN column_name = 'VKORG' AND TABLE_CATALOG = 'bieuropeprdpdw_se' THEN ' WHERE VKORG >= ''6000'''
				WHEN column_name = 'VKORG' AND TABLE_CATALOG = 'bieuropeprdpdw_peg' THEN ' WHERE VKORG < ''6000'''
				WHEN column_name = 'VKORG' AND TABLE_CATALOG = 'bieuropeprdpdw_fra' THEN ' WHERE VKORG >= ''6000'''
				ELSE '' END
		 FROM INFORMATION_SCHEMA.COLUMNS
		 WHERE TABLE_CATALOG = @DatabaseName
			AND table_schema = @SchemaName
			AND table_name = @TblName
			AND column_name = ('VKORG')	
	END
--------------------------------------------------------------------------
--check if bachid field exists into table
DECLARE @bachID VARCHAR(20);
SELECT @bachID = column_name 
FROM INFORMATION_SCHEMA.COLUMNS
		 WHERE TABLE_CATALOG = @DatabaseName
			AND table_schema = @SchemaName
			AND table_name = @TblName
			AND column_name = '_Batchid';

--build ORDER BY clause
DECLARE @orderby VARCHAR(500) = CASE WHEN @SequenceNum IS NULL AND  @bachID IS NULL THEN CONCAT (@OrderDup, ' DESC')
									 WHEN @SequenceNum IS NULL AND  @bachID IS NOT NULL THEN CONCAT (@OrderDup, ' DESC , ',@bachID,' DESC') 
									 WHEN @SequenceNum IS NOT NULL AND  @bachID IS NULL THEN CONCAT (@OrderDup, ' DESC , ',@SequenceNum,' DESC')
									 ELSE CONCAT (@OrderDup, ' DESC, ',@SequenceNum,' DESC, ',@bachID,' DESC') END;

--build LDTS & Sequence for main field list 
DECLARE @selectLdtsSequenceMain VARCHAR(500) = CASE WHEN @SequenceNum IS NULL AND  @bachID IS NULL THEN @OrderDup
													WHEN @SequenceNum IS NULL AND  @bachID IS NOT NULL THEN CONCAT (@OrderDup, ', ',@bachID) 
													WHEN @SequenceNum IS NOT NULL AND  @bachID IS NULL THEN CONCAT (@OrderDup, ', ',@SequenceNum) 
													ELSE CONCAT (@OrderDup, ', ',@SequenceNum,', ',@bachID) END;


--------------------------------------------------------------------------
--form Backup Table Name
DECLARE @backupDate VARCHAR(30) = convert(varchar, getdate(), 121);
DECLARE @backupTblName	VARCHAR(250) = CONCAT('x.'
								   ,'BACKUP_' 
								   ,@TblName
								   ,CAST(CONVERT(char(8),GETDATE(),112) AS int)
								   ,'_'
								   ,CAST(REPLACE(CONVERT(char(8),GETDATE(), 108), ':', '') AS int));

----------------------------------------------------------------------------------------
----form a list of attributes for JOIN clause
--build '=' expressions for join clause for LDTSs
DECLARE @forJoin_LDTS VARCHAR(1000)	= CASE WHEN @SequenceNum IS NULL AND  @bachID IS NULL 
												THEN CONCAT(CHAR(13),' AND COALESCE(r.',@OrderDup,',''1900.01.01'') = COALESCE(t.',@OrderDup,',''1900.01.01'')')
										   WHEN @SequenceNum IS NULL AND  @bachID IS NOT NULL 
												THEN CONCAT(CHAR(13),' AND COALESCE(r.',@OrderDup,',''1900.01.01'') = COALESCE(t.',@OrderDup,',''1900.01.01'')',CHAR(13),' AND COALESCE(r.',@bachID,',-1) = COALESCE(t.',@bachID,',-1)')
										   WHEN @SequenceNum IS NOT NULL AND  @bachID IS NULL 
												THEN CONCAT(CHAR(13),' AND COALESCE(r.',@OrderDup,',''1900.01.01'') = COALESCE(t.',@OrderDup,',''1900.01.01'')',CHAR(13),' AND COALESCE(r.',@SequenceNum,',''0'') = COALESCE(t.',@SequenceNum,',''0'')') 
										   ELSE CONCAT(CHAR(13),' AND COALESCE(r.',@OrderDup,',''1900.01.01'') = COALESCE(t.',@OrderDup,',''1900.01.01'')',CHAR(13),' AND COALESCE(r.',@SequenceNum,',''0'') = COALESCE(t.',@SequenceNum,',''0'')',CHAR(13),' AND COALESCE(r.',@bachID,',-1) = COALESCE(t.',@bachID,',-1)') END

---------------------------------------------------------------------------------
--build '=' expressions for join clause for BKs
DECLARE @JoinforDeleteBK VARCHAR(1000)
SELECT @JoinforDeleteBK = STRING_AGG(joinCond, ' AND ')
FROM (SELECT CONCAT(CHAR(13), 'r.',value,' = t.',value, '') joinCond FROM STRING_SPLIT(@BKs, ',')) t;

DECLARE @JoinforDelete VARCHAR(1000)
SET @JoinforDelete = CONCAT(@JoinforDeleteBK, ' ',@forJoin_LDTS);
---------------------------------------------------------------------------------

--create table for Backup
IF @DoBackup = 1
	BEGIN
		DECLARE @createBkpTbl NVARCHAR(2000); 
		SELECT @createBkpTbl = 'SELECT top(0) *, CAST(1 AS INT) AS RN, GETDATE() AS BackupDate 
		 INTO '+ @backupTblName +' FROM '+CONCAT(@SchemaName,'.',@TblName)+';'

		--Print @createBkpTbl
		EXECUTE sp_executesql @createBkpTbl;
	END

------------------------------------------------------------------------------------------------
--Process regional data (DELETE Regional Data if Backup table is not empty)

IF COALESCE(@where,'') <> ''
  BEGIN
		--backup regional data which will be deleted
		SELECT @sqlcmd = 
		'DECLARE @tableNotEmpty INT = 0;
		IF '+ @DoBackup + ' = 1
			BEGIN
				INSERT INTO '+@backupTblName+' 
				SELECT *,0 as RN, CAST('''+@backupDate+''' AS DATETIME) AS BackupDate 
				FROM '+@SchemaName+'.'+@TblName +' '+ @where +';

				SET @tableNotEmpty  = (SELECT TOP(1) 1 FROM '+@backupTblName+');
			END 
		IF COALESCE(@tableNotEmpty,0) > 0 OR '+ @DoBackup + ' =0
			BEGIN
				DELETE FROM '+@SchemaName+'.'+@TblName+' '+@where +';
			END'

				--print(@sqlcmd)
				EXECUTE sp_executesql @sqlcmd;
	END
	
-------------------------------------------------------------------------------------------
--Process main data (backup & delete if backup table is not empty)
SELECT @sqlcmd =
		'DECLARE @tableNotEmpty INT = 0;
		 DECLARE @forprint INT = 0

		IF OBJECT_ID(N''x.cleanUp_'+@TblName +''') IS NOT NULL  DROP TABLE x.cleanUp_'+@TblName +';
		IF OBJECT_ID(N''x.forDelete_'+@TblName +''') IS NOT NULL  DROP TABLE x.forDelete_'+@TblName +';
		IF OBJECT_ID(N''tempdb..#tmp'') IS NOT NULL  DROP TABLE #tmp;

		--when first time clean
		IF CAST('''+@LastLDTS+''' AS DATETIME) = CAST(''1900.01.01'' AS DATETIME) --initial load
		 BEGIN 
			SELECT '+@BKs+', '+@selectLdtsSequenceMain+ ' INTO x.cleanUp_'+@TblName +' FROM '+@SchemaName+'.'+@TblName +' 
		 END

		 --when incremental clean
		IF CAST('''+@LastLDTS+''' AS DATETIME) > CAST(''1900.01.01'' AS DATETIME)
		 BEGIN
			;with r AS (SELECT DISTINCT '+@BKs+' FROM '+@SchemaName+'.'+@TblName +' WHERE '+ @OrderDup+ ' > CAST('''+@LastLDTS+''' AS DATETIME)) 
			SELECT r.* , '+@selectLdtsSequenceMain+ ' INTO x.cleanUp_'+@TblName +' FROM r JOIN '+@SchemaName+'.'+@TblName +' AS t 
						ON '+ @JoinforDeleteBK+'; 
		 END

		;WITH r0 AS (SELECT DISTINCT * FROM x.cleanUp_'+@TblName +'), 
				r AS (SELECT '+@BKs+', '+@selectLdtsSequenceMain+ ' , ROW_NUMBER() OVER (PARTITION BY '+@BKs_COALESCE+' ORDER BY '+@orderby+') RN FROM r0 as r)
					  SELECT '+@BKs_Cast+', '+@selectLdtsSequenceMain+ ', RN INTO x.forDelete_'+@TblName +' FROM r WHERE r.RN >= 2;
		IF COALESCE(@tableNotEmpty,0) > 0 
			BEGIN
					   DELETE t  FROM x.forDelete_'+@TblName +' AS r 
						JOIN ' +@SchemaName+'.'+@TblName+ ' AS t ON '+ @JoinforDelete+';
			END
	

  		'
			--print(@sqlcmd)
			EXECUTE sp_executesql @sqlcmd
	
-----------------------------------------------------------------------------
	SELECT  @sqlcmd = 'IF OBJECT_ID(N''x.cleanUp_'+@TblName +''') IS NOT NULL  DROP TABLE x.cleanUp_'+@TblName +';'
	EXECUTE sp_executesql @sqlcmd;

	SELECT  @sqlcmd = 'IF OBJECT_ID(N''x.forDelete_'+@TblName +''') IS NOT NULL  DROP TABLE x.forDelete_'+@TblName +';'
	EXECUTE sp_executesql @sqlcmd;

	select getdate(); 
	
END