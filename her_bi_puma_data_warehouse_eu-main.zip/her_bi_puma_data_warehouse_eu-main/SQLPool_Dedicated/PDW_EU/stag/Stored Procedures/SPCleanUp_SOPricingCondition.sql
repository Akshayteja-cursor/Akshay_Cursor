﻿CREATE PROC [stag].[SPCleanUp_SOPricingCondition] AS 

DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(0) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(0)
DECLARE @DestinationLastLoadDate DATETIME2(0)
DECLARE @AffectedRows BIGINT = NULL


-- get last LDTS Informations for Logging
IF(EXISTS(SELECT 1 FROM [stag].[S4Hana_SOPricingConditions_full]))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(_LDTS))
		FROM [stag].[S4Hana_SOPricingConditions_full]
	END
ELSE 
	BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

IF(EXISTS(SELECT 1 FROM [stag].[S4Hana_SOPricingConditions_full]))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(_LDTS))
		FROM [stag].[S4Hana_SOPricingConditions_full]
	END
ELSE 
	BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END
-- Logging Informations END


-- Log first DATA Informations

INSERT INTO etl.DataTransferLogs
(
  DataTransferLogId
, TransferName
, TransferGroupName
, TargetTableName
, TargetSchemaName
, ExecStart
, SourceLastLoadDate
, DestinationLastLoadDate
, BatchLdts
)
SELECT 
  @DataTransferLogId 
, 'SPCleanUp_SOPricingCondition'
, 'S4Hana_SOPricingConditions_full'
, 'S4Hana_SOPricingConditions_full'
, 'stag'
, @ExecStart
, @SourceLastLoadDate
, @DestinationLastLoadDate
, @DestinationLastLoadDate;

WITH cte AS
(	
SELECT
*
	,CONVERT([BINARY](16),
		HASHBYTES('MD5',CONCAT(
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [PricingDocument])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [PricingDocumentItem])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [PricingProcedureStep])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [PricingProcedureCounter]))))
	))) AS HashBK
	,CONVERT([BINARY](16),
		HASHBYTES('MD5',CONCAT(
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [PricingDocument])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [PricingDocumentItem])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [PricingProcedureStep])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [PricingProcedureCounter])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [SalesDocument])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [SalesDocumentItem])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [ConditionType])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [ConditionAmount])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [ConditionInactiveReason]))))
	))) AS HashDiff
FROM [stag].[S4Hana_SOPricingConditions_full])
,cte2 AS
(
SELECT *
	,LAG(HashDiff) OVER (PARTITION BY HashBK ORDER BY _LDTS) AS HashDiff_prevRow
FROM cte
)
delete f
FROM cte2 c inner join [stag].[S4Hana_SOPricingConditions_full] f
on c.[PricingDocument]				  = f.[PricingDocument]
and   c.[PricingDocumentItem]		  = f.[PricingDocumentItem]
and   c.[PricingProcedureStep]		  = f.[PricingProcedureStep]
and   c.[PricingProcedureCounter]	  = f.[PricingProcedureCounter]
and   c.[SalesDocument]				  = f.[SalesDocument]
and   c.[SalesDocumentItem]			  = f.[SalesDocumentItem]
and   c.[ConditionType]				  = f.[ConditionType]
and   c.[ConditionAmount]			  = f.[ConditionAmount]
and   c.[ConditionInactiveReason]	  = f.[ConditionInactiveReason]
and	  c._ldts						  = f._ldts 
WHERE c.HashDiff  = ISNULL(c.HashDiff_prevRow,0);

SET @AffectedRows = 
(
	SELECT
	TOP 1  
	row_count
	FROM sys.dm_pdw_request_steps
	WHERE 1=1 
	and row_count >= 0
	AND request_id IN (
		SELECT TOP 1 
		request_id 
		FROM sys.dm_pdw_exec_requests
		WHERE session_id = SESSION_ID()
		AND resource_class IS NOT NULL
		ORDER BY end_time DESC)
	order by end_time desc
);

UPDATE DTlogs SET 
  Deleted = @AffectedRows
, ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId