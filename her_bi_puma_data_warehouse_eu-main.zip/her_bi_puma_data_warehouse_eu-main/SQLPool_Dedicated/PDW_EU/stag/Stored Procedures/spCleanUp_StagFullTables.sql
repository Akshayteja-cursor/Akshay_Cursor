﻿CREATE PROC [stag].[spCleanUp_StagFullTables] @table [nvarchar](max) AS
BEGIN

DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(0) = GETDATE()
DECLARE @DestinationLastLoadDate DATETIME2(0)
DECLARE @AffectedRows BIGINT = NULL
DECLARE @hashdiff varchar(max)
DECLARE @hashbk varchar(400)
DECLARE @sqlcmd varchar(max)
DECLARE @sqllog varchar(500)
DECLARE @Joincondition varchar(max)


-- get last LDTS Informations for Logging
select @sqllog = '
declare @DestinationLastLoadDate DATETIME2(0)
IF(EXISTS(SELECT 1 FROM [stag].'+@table+'))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(_LDTS))
		FROM [stag].'+ @table +'
	END
ELSE 
	BEGIN
		SELECT @DestinationLastLoadDate = ''1990-01-01'' 
	END '

		EXECUTE(@sqllog)

-- Logging Informations 

INSERT INTO etl.DataTransferLogs
(
  DataTransferLogId
, TransferName
, TransferGroupName
, TargetTableName
, TargetSchemaName
, ExecStart
, SourceLastLoadDate
, DestinationLastLoadDate
, BatchLdts
)
SELECT 
  @DataTransferLogId 
, 'spDedup_stagFullTables'
, @table
, @table
, 'stag'
, @ExecStart
, @DestinationLastLoadDate
, @DestinationLastLoadDate
, @DestinationLastLoadDate;

select @hashbk = string_agg('UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),'+column_name +')))),'+'''_''' , ',')  FROM
    information_schema.columns	
	where table_name = @table
	and is_nullable = 'NO'
	group by table_name; 

	SELECT 
    @hashdiff = string_agg( 'UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),'+column_name +')))),'+'''_''' , ',')
FROM
    information_schema.columns	
	where table_name = @table
	and column_name not in (
	'__operation_type'
	,'__sequence_number'
	,'__timestamp'
	,'_LDTS'
	,'RowNo'
	,'_BatchId'
	)
	group by table_name 

select @Joincondition =  string_agg('c.' +column_name +' = d.'+column_name , '  and   ' )
FROM
    information_schema.columns	
	where table_name = @table
	and column_name not in (
	'__operation_type'
	,'__sequence_number'
	,'__timestamp'
	,'RowNo'
	,'_BatchId'
	)
	group by table_name 
	
	select @sqlcmd  = 
	'with cte_1 as ('+ 
	'select   * '+
	',CONVERT([BINARY](16),
		HASHBYTES(''MD5'',CONCAT('+ @hashbk +' , UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),'''')))) 
		))) AS Hashbk  '+
	',CONVERT([BINARY](16),
		HASHBYTES(''MD5'',CONCAT(' + @hashdiff +' , UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),'''')))) 
		))) AS Hashdiff from stag.'+ @table
		+
		'
		),
		cte_2 as (

			SELECT *
			,LAG(HashDiff) OVER (PARTITION BY HashBK ORDER BY _LDTS) AS HashDiff_prevRow
			FROM cte_1
			)
			delete d 
			from cte_2 c inner join stag.'+ @table +' d 
			on ' + @Joincondition + ' 
			WHERE HashDiff = ISNULL(HashDiff_prevRow,0);
		'
	--EXECUTE sp_executesql @sqlcmd;
	EXECUTE(@sqlcmd);

SET @AffectedRows = 
(
	SELECT
	TOP 1  
	row_count
	FROM sys.dm_pdw_request_steps
	WHERE 1=1 
	and row_count >= 0
	AND request_id IN (
		SELECT TOP 1 
		request_id 
		FROM sys.dm_pdw_exec_requests
		WHERE session_id = SESSION_ID()
		AND resource_class IS NOT NULL
		ORDER BY end_time DESC)
	order by end_time desc
);

UPDATE DTlogs SET 
  Deleted = @AffectedRows
, ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId


END