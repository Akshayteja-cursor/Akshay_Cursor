﻿CREATE VIEW [sales].[vNatSalesOrdersOohHistory_SE]
AS SELECT *
FROM sales.NatSalesOrdersOohHistory
WHERE COMPANYCODE IN ('ES10','PT10','IT10');