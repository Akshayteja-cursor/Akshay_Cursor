﻿CREATE VIEW [sales].[vNatSalesOrderDeliveryNotesCurrent_CEU]
AS SELECT *
FROM sales.NatSalesOrderDeliveryNotesCurrent
 WHERE COMPANYCODE in ('AT19' ,'BE19','DE19' ,'CH19', 'NL19');