﻿CREATE VIEW [sales].[vNatSalesOrderCurrentAccumulated_FRA]
AS SELECT *
FROM [sales].[NatSalesOrderCurrentAccumulated]
WHERE COMPANYCODE = 'FR10';