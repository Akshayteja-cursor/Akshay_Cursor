﻿CREATE VIEW [sales].[vNatCopaDetails_CEU]
AS SELECT *
FROM sales.NatCopaDetails
WHERE COMPANYCODE in ('AT19' ,'BE19','DE19' ,'CH19', 'NL19');