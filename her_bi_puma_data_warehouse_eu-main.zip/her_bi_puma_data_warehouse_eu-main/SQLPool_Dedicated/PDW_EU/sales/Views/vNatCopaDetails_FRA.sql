﻿CREATE VIEW [sales].[vNatCopaDetails_FRA]
AS SELECT *
FROM sales.NatCopaDetails
WHERE COMPANYCODE = 'FR10';