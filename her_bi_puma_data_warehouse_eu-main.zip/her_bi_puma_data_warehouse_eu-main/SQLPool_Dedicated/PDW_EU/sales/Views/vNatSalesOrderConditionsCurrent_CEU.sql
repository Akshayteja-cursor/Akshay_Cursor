﻿CREATE VIEW [sales].[vNatSalesOrderConditionsCurrent_CEU]
AS SELECT *
FROM sales.NatSalesOrderConditionsCurrent
WHERE COMPANYCODE in ('AT19' ,'BE19','DE19' ,'CH19', 'NL19');