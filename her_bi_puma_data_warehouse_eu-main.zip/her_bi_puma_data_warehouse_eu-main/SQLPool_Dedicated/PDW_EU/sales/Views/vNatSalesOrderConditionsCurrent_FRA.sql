﻿CREATE VIEW [sales].[vNatSalesOrderConditionsCurrent_FRA]
AS SELECT *
FROM sales.NatSalesOrderConditionsCurrent
WHERE COMPANYCODE = 'FR10';