﻿CREATE VIEW [sales].[vNatSalesOrderCurrentAccumulated_CEU]
AS SELECT *
FROM [sales].[NatSalesOrderCurrentAccumulated]
WHERE COMPANYCODE in ('AT19' ,'BE19','DE19' ,'CH19', 'NL19');