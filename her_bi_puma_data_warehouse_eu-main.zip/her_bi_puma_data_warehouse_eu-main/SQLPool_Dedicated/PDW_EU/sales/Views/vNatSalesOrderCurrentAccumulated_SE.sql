﻿CREATE VIEW [sales].[vNatSalesOrderCurrentAccumulated_SE]
AS SELECT *
FROM [sales].[NatSalesOrderCurrentAccumulated]
WHERE COMPANYCODE IN ('ES10','PT10','IT10');