﻿CREATE VIEW [sales].[vNatCopaDetails_SE]
AS SELECT *
FROM sales.NatCopaDetails
WHERE COMPANYCODE IN ('ES10','PT10','IT10');