﻿CREATE VIEW [sales].[vNatSalesOrdersOohHistory_CEU]
AS SELECT *
FROM sales.NatSalesOrdersOohHistory
WHERE COMPANYCODE in ('AT19' ,'BE19','DE19' ,'CH19', 'NL19');