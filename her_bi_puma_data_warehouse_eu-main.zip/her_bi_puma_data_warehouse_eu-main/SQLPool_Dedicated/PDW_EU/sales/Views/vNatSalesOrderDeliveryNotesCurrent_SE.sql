﻿CREATE VIEW [sales].[vNatSalesOrderDeliveryNotesCurrent_SE]
AS SELECT *
FROM sales.NatSalesOrderDeliveryNotesCurrent
WHERE COMPANYCODE IN ('ES10','PT10','IT10');