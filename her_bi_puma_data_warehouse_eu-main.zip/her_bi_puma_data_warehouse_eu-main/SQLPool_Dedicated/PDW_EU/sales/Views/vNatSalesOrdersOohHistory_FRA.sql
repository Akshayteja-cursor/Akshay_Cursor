﻿CREATE VIEW [sales].[vNatSalesOrdersOohHistory_FRA]
AS SELECT *
FROM sales.NatSalesOrdersOohHistory
WHERE COMPANYCODE = 'FR10';