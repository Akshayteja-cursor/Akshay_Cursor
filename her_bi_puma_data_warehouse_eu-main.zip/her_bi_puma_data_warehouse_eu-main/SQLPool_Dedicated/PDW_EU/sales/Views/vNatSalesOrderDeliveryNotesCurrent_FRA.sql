﻿CREATE VIEW [sales].[vNatSalesOrderDeliveryNotesCurrent_FRA]
AS SELECT *
FROM sales.NatSalesOrderDeliveryNotesCurrent
WHERE COMPANYCODE = 'FR10';