﻿CREATE VIEW [sales].[S4Hana_vCoPaDetails_DS_V02] AS SELECT
	   ROW_NUMBER() OVER (ORDER BY NEWID ( )) as ID
	   ,MAX(a.modifiedOn) as ModifiedOn
	   ,(CONVERT(BIGINT, DATEDIFF(sECOND,'1970-01-01', MAX(a.modifiedOn))) * 1000000)  +  DATEPART(MCS,MAX(a.modifiedOn)) as modifiedOn_UTC_epoch
	  ,c.SalesOrganization
	  ,b.[CustomerAccountGroup]
	  ,b.NatCustomerNo									as CustomerNumber
	  ,a.ReferenceDocNo									as InvoiceNumber
	  ,a.ArticleNumber_BK								as ArticleNumber
	  ,CONVERT(date, cast(PostingDate as char(8)))	    as PostingDate
	  ,a.NatInvoiceTypeCode								as InvoiceTypeCode
	  ,SUM(CAST(a.GrossSalesLC as money))				as GrossSales
	  ,SUM(CAST(a.InvoicedSalesLC as money))			as InvoiceSales
	  ,SUM(CAST(a.NetSalesLC as money))					as NetSales
	  ,SUM(CAST(a.NetSalesUnits as decimal(12,1)))		as SalesUnits

  FROM [sales].[NatCopaDetails] a
  INNER JOIN [ref].[NatCustomers] b on a.NatCustomer_BK=b.NatCustomer_BK
  INNER JOIN (SELECT DISTINCT CONCAT(Customer,'|',SalesOrganization) NatCustomer_BK, SalesOrganization FROM [biz].[S4Hana_CustomerSalesAttributes]) c on a.NatCustomer_BK=c.NatCustomer_BK
  GROUP BY c.SalesOrganization
	  ,b.[CustomerAccountGroup]
	  ,b.NatCustomerNo
	  ,a.ReferenceDocNo
	  ,a.ArticleNumber_BK
	  ,a.PostingDate
	  ,a.NatInvoiceTypeCode;