﻿CREATE VIEW [sales].[vNatSalesOrderConditionsCurrent_SE]
AS SELECT *
FROM sales.NatSalesOrderConditionsCurrent
WHERE COMPANYCODE IN ('ES10','PT10','IT10');