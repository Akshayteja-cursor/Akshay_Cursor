﻿CREATE TABLE [sales].[NatSalesOrdersPurchaseOrders_ARUN]
(
	[NatSalesOrderNo] [nvarchar](10) NULL,
	[NatSalesOrderItemNo] [nvarchar](6) NULL,
	[NatPurchaseOrders] [nvarchar](1500) NOT NULL,
	[Min_NatPODeliveryDate] [date] NULL,
	[Max_NatPODeliveryDate] [date] NULL,
	[LDTS] [datetime2](7) NULL,
	[HashDiff] [binary](16) NULL
)
WITH (DISTRIBUTION = ROUND_ROBIN, HEAP)

