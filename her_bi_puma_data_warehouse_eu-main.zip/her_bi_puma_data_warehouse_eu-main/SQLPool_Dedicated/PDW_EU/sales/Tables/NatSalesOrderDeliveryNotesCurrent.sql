﻿CREATE TABLE [sales].[NatSalesOrderDeliveryNotesCurrent] (
    [NatDeliveryNote_BK]         BIGINT          NOT NULL,
    [CreatedOn]                  SMALLDATETIME   NOT NULL,
    [ModifiedOn]                 SMALLDATETIME   NOT NULL,
    [NatDeliveryNoteNo]          VARCHAR (20)    NULL,
    [NatDeliveryNoteItemNo]      VARCHAR (20)    NULL,
    [CompanyCode]                VARCHAR (20)    NOT NULL,
    [IntPupMasterId]             INT             NOT NULL,
    [PDUCode]                    VARCHAR (20)    NOT NULL,
    [NatSalesOrderNo]            VARCHAR (20)    NULL,
    [NatSalesOrderItemNo]        VARCHAR (20)    NULL,
    [SalesDocumentType]          NVARCHAR (4)    NULL,
    [RequestedDeliveryDate]      INT             NULL,
    [StyleNumber_BK]             INT             NULL,
    [ArticleNumber_BK]           VARCHAR (20)    NULL,
    [ArticleSize_BK]             VARCHAR (20)    NULL,
    [NatArticle_BK]              VARCHAR (40)    NOT NULL,
    [NatCustomer_BK]             VARCHAR (50)    NOT NULL,
    [NatStoreDC_BK]              VARCHAR (40)    NOT NULL,
    [DeliveryNoteStatusDesc]     VARCHAR (40)    NULL,
    [DeliveryNoteCreationDate]   INT             NULL,
    [Qty]                        INT             NULL,
    [InvoicedSalesValueLC]       NUMERIC (38, 6) NULL,
    [Active]                     BIT             NOT NULL,
    [RBUCode]                    INT             NULL,
    [BrandCode]                  VARCHAR (4)     NULL,
    [ProdDivCode]                INT             NULL,
    [CurrencyCode]               CHAR (5)        NULL,
    [DeliveryNoteTypeCode]       CHAR (4)        NULL,
    [DeliveryNoteTypeDesc]       VARCHAR (40)    NULL,
    [ActualGoodsMovementDate]    INT             NULL,
    [HashDiff]                   BINARY (16)     NOT NULL,
    [LDTS]                       DATETIME2 (7)   NULL,
    [TotalCreditCheckStatus]     NCHAR (1)       NULL,
    [TotalCreditCheckStatusDesc] NVARCHAR (200)  NULL,
    [MeansOfTransport]           NVARCHAR (20)   NULL,
    [SpecialProcessingCode]      NVARCHAR (4)    NULL,
    [PlannedGoodsIssueDate]      INT             NULL,
    [DeliveryDate]               INT             NULL,
    [GrossWeight]                DECIMAL (15, 3) NULL,
    [ActualLoadingDate]          DATE            NULL,
    [DeliveryDocumentBySupplier] NVARCHAR (35)   NULL,
    [GoodsIssueDate]             DATE            NULL,
    [ConfBookingInDate]          DATE            NULL,
    [ConfBookingInTime]          NVARCHAR (30)   NULL,
    [BookingInDate]              DATE            NULL,
    [SpecialLogisticsProcess]    NVARCHAR (2)    NULL,
    [OverallBillingStatus]       NVARCHAR (1)    NULL,
    [OverallPackingStatus]       NVARCHAR (1)    NULL,
    [ActualForwardingAgentName]  NVARCHAR (40)   NULL,
    [ActualDeliveryQuantity]     DECIMAL (17, 3) NULL,
    [OriginalDeliveryQuantity]   DECIMAL (17, 3) NULL,
    [GrossWeightPerUnit]         DECIMAL (15, 3) NULL,
    [VASCode]                    NVARCHAR (20)   NULL,
    [SubVASCode]                 NVARCHAR (50)   NULL,
    [VASDesc]                    NVARCHAR (100)  NULL,
    [SubVASDesc]                 NVARCHAR (200)  NULL,
    [SalesSeason]                NVARCHAR (14)   NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

















