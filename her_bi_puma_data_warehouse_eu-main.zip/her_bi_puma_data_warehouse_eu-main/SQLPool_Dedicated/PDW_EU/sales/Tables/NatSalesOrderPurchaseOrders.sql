﻿CREATE TABLE [sales].[NatSalesOrderPurchaseOrders] (
    [NatSalesOrderNo]          NVARCHAR (10)   NULL,
    [NatSalesOrderItemNo]      NVARCHAR (6)    NULL,
    [NatPurchaseOrders_Late]   NVARCHAR (1000) NULL,
    [units_late]               DECIMAL (18, 3) NULL,
    [PO_Delivery_Date_Late]    DATE            NULL,
    [NatPurchaseOrders_OnTime] NVARCHAR (1000) NULL,
    [PO_Delivery_Date_OnTime]  DATE            NULL,
    [units_OnTime]             DECIMAL (18, 3) NULL,
    [units_OnStock]            DECIMAL (18, 3) NULL,
    [Min_NatPODeliveryDate]    DATE            NULL,
    [Max_NatPODeliveryDate]    DATE            NULL,
    [LDTS]                     DATETIME2 (7)   NULL,
    [HashDiff]                 BINARY (16)     NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

