﻿CREATE TABLE [sales].[SOScheduleLineDeliveries] (
    [SOScheduleLineDeliveries_ID] INT             IDENTITY (1, 1) NOT NULL,
    [ScheduleLine]                CHAR (4)        NOT NULL,
    [SalesOrderNo]                VARCHAR (10)    NOT NULL,
    [SalesOrderItemNo]            VARCHAR (6)     NOT NULL,
    [DeliveryNoteNumber]          VARCHAR (10)    NULL,
    [DeliveryNoteItemNo]          VARCHAR (6)     NOT NULL,
    [DeliveredQuantity]           NUMERIC (13, 3) NULL,
    [DeliveryStatus]              CHAR (1)        NULL,
    [ActualGoodsMovementDate]     INT             NULL,
    [IsDeleted]                   BIT             NOT NULL,
    [CreatedOn]                   SMALLDATETIME   NOT NULL,
    [ModifiedON]                  SMALLDATETIME   NOT NULL,
    [LDTS]                        SMALLDATETIME   NULL,
    PRIMARY KEY NONCLUSTERED ([SOScheduleLineDeliveries_ID] ASC) NOT ENFORCED
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

