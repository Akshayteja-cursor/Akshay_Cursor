﻿CREATE SCHEMA [pdwref]
    AUTHORIZATION [dbo];





