﻿CREATE SCHEMA [sales]
    AUTHORIZATION [dbo];





