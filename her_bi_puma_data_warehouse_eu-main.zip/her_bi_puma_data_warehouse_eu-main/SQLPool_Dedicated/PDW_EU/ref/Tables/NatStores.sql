﻿CREATE TABLE [ref].[NatStores] (
    [NatStore_BK]     NVARCHAR (20) NOT NULL,
    [CreatedOn]       DATETIME2 (7) NOT NULL,
    [ModifiedOn]      DATETIME2 (7) NOT NULL,
    [NatStoreCode]    NVARCHAR (20) NOT NULL,
    [CompanyCode]     NVARCHAR (4)  NULL,
    [IntPupMasterId]  INT           NULL,
    [PDUCode]         NVARCHAR (15) NOT NULL,
    [HashDiff]        BINARY (16)   NOT NULL,
    [NatStoreName]    NVARCHAR (30) NOT NULL,
    [City]            NVARCHAR (35) NOT NULL,
    [Street]          NVARCHAR (35) NOT NULL,
    [PostalCode]      NVARCHAR (10) NOT NULL,
    [CountryCode]     NVARCHAR (3)  NOT NULL,
    [CountryDesc]     NVARCHAR (60) NULL,
    [DistChannelCode] NVARCHAR (10) NOT NULL,
    [DistChannelDesc] NVARCHAR (50) NULL,
    [GSMCode]         NVARCHAR (20) NULL,
    [IntDCTypeCode]   NVARCHAR (10) NULL,
    CONSTRAINT [PK_NatStore_BK] PRIMARY KEY NONCLUSTERED ([NatStore_BK] ASC) NOT ENFORCED
)
WITH (CLUSTERED INDEX([NatStore_BK]), DISTRIBUTION = ROUND_ROBIN);

