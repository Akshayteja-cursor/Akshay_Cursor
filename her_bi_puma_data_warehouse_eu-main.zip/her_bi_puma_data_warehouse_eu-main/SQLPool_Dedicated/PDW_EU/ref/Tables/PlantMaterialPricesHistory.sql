﻿CREATE TABLE [ref].[PlantMaterialPricesHistory] (
    [HashValueBK]         BINARY (16)     NULL,
    [ArticleSize_BK]      NVARCHAR (40)   NULL,
    [GSMStoreCode]        NVARCHAR (20)   NULL,
    [ArticleCurrencyCode] NVARCHAR (5)    NULL,
    [UnitLandedCost]      DECIMAL (18, 2) NULL,
    [ValidFrom]           DATE            NULL,
    [ValidTo]             DATE            NULL,
    [HashDiff]            BINARY (16)     NULL,
    [CreationDate]        DATETIME        NOT NULL,
    [ModificationDate]    DATETIME        NOT NULL,
    [SalesOrganization]   NVARCHAR (4)    NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);



