﻿CREATE TABLE [ref].[NatSalesmen] (
    [NatSalesman_BK]   NVARCHAR (20) NOT NULL,
    [CreatedOn]        DATETIME2 (7) NOT NULL,
    [ModifiedOn]       DATETIME2 (7) NULL,
    [NatSalesmanCode]  NVARCHAR (10) NULL,
    [CompanyCode]      NVARCHAR (4)  NULL,
    [IntPupMasterId]   INT           NULL,
    [PDUCode]          NVARCHAR (15) NULL,
    [HashDiff]         BINARY (16)   NULL,
    [NatSalesmanName]  NVARCHAR (80) NULL,
    [City]             NVARCHAR (35) NULL,
    [Street]           NVARCHAR (35) NULL,
    [PostalCode]       NVARCHAR (10) NULL,
    [LockFlag]         BIT           NULL,
    [SalesManagerName] NVARCHAR (35) NULL,
    CONSTRAINT [PK_NatSalesman_BK] PRIMARY KEY NONCLUSTERED ([NatSalesman_BK] ASC) NOT ENFORCED
)
WITH (CLUSTERED INDEX([NatSalesman_BK]), DISTRIBUTION = ROUND_ROBIN);

