﻿CREATE TABLE [ref].[NatStoreDCs] (
    [NatStoreDC_BK]   NVARCHAR (20) NOT NULL,
    [CreatedOn]       DATETIME2 (7) NOT NULL,
    [ModifiedOn]      DATETIME2 (7) NOT NULL,
    [NatStoreDCCode]  NVARCHAR (20) NOT NULL,
    [CompanyCode]     NVARCHAR (4)  NULL,
    [IntPupMasterId]  INT           NULL,
    [PDUCode]         NVARCHAR (15) NOT NULL,
    [HashDiff]        BINARY (16)   NOT NULL,
    [NatStoreDCName]  NVARCHAR (30) NOT NULL,
    [City]            NVARCHAR (35) NOT NULL,
    [Street]          NVARCHAR (35) NOT NULL,
    [PostalCode]      NVARCHAR (10) NOT NULL,
    [Channel]         NVARCHAR (3)  NULL,
    [CountryCode]     NVARCHAR (3)  NOT NULL,
    [CountryDesc]     NVARCHAR (60) NULL,
    [DistChannelCode] NVARCHAR (10) NOT NULL,
    [DistChannelDesc] NVARCHAR (50) NULL,
    [GSMCode]         NVARCHAR (20) NULL,
    [IntDCTypeCode]   NVARCHAR (10) NULL,
    CONSTRAINT [PK_NatStoreDC_BK] PRIMARY KEY NONCLUSTERED ([NatStoreDC_BK] ASC) NOT ENFORCED
)
WITH (CLUSTERED INDEX([NatStoreDC_BK]), DISTRIBUTION = ROUND_ROBIN);

