﻿CREATE TABLE [ref].[DimDate] (
    [DateKey]          INT          NOT NULL,
    [CalendarDate]     DATE         NOT NULL,
    [Weekday]          TINYINT      NOT NULL,
    [WeekDayName]      VARCHAR (10) NOT NULL,
    [WeekDayNameShort] CHAR (3)     NOT NULL,
    [DayNumberOfMonth] TINYINT      NOT NULL,
    [DayNumberOfYear]  SMALLINT     NOT NULL,
    [WeekOfMonth]      TINYINT      NOT NULL,
    [WeekOfYear]       TINYINT      NOT NULL,
    [MonthNumber]      TINYINT      NOT NULL,
    [MonthName]        VARCHAR (10) NOT NULL,
    [MonthNameShort]   CHAR (3)     NOT NULL,
    [QuarterNumber]    TINYINT      NOT NULL,
    [YearNumber]       INT          NOT NULL,
    [YYYYMM]           INT          NOT NULL,
    [YearMonth]        CHAR (7)     NOT NULL
)
WITH (CLUSTERED INDEX([DateKey]), DISTRIBUTION = REPLICATE);

