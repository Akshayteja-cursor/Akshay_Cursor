﻿CREATE TABLE [ref].[NatArticlesPrices] (
    [MaterialNumber] NVARCHAR (40) NOT NULL,
    [CreatedOn]      DATETIME2 (7) NOT NULL,
    [ModifiedOn]     DATETIME2 (7) NULL,
    [IsDeleted]      BIT           NOT NULL,
    [RRP_CH19_CHF]   FLOAT (53)    NULL,
    [RRP_NL19_CHF]   FLOAT (53)    NULL,
    [RRP_DE19_CHF]   FLOAT (53)    NULL,
    [RRP_AT19_CHF]   FLOAT (53)    NULL,
    [RRP_BE19_CHF]   FLOAT (53)    NULL,
    [RRP_CH19_EUR]   FLOAT (53)    NULL,
    [RRP_NL19_EUR]   FLOAT (53)    NULL,
    [RRP_DE19_EUR]   FLOAT (53)    NULL,
    [RRP_AT19_EUR]   FLOAT (53)    NULL,
    [RRP_BE19_EUR]   FLOAT (53)    NULL,
    [WSP_CH19_CHF]   FLOAT (53)    NULL,
    [WSP_NL19_CHF]   FLOAT (53)    NULL,
    [WSP_DE19_CHF]   FLOAT (53)    NULL,
    [WSP_AT19_CHF]   FLOAT (53)    NULL,
    [WSP_BE19_CHF]   FLOAT (53)    NULL,
    [WSP_CH19_EUR]   FLOAT (53)    NULL,
    [WSP_NL19_EUR]   FLOAT (53)    NULL,
    [WSP_DE19_EUR]   FLOAT (53)    NULL,
    [WSP_AT19_EUR]   FLOAT (53)    NULL,
    [WSP_BE19_EUR]   FLOAT (53)    NULL,
    [HashDiff]       BINARY (16)   NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

