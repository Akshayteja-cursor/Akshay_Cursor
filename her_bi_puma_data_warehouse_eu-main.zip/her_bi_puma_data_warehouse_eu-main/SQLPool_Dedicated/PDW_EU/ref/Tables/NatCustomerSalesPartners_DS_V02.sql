﻿CREATE TABLE [ref].[NatCustomerSalesPartners_DS_v02] (
    [ID]                         BIGINT        IDENTITY (1, 1) NOT NULL,
    [NatCustomerSalesPartner_BK] NVARCHAR (50) NOT NULL,
    [IsDeleted]                  BIT           NULL,
    [CreatedOn]                  DATETIME2 (7) NULL,
    [ModifiedOn]                 DATETIME2 (7) NULL,
    [CustomerNumber]             NVARCHAR (10) NOT NULL,
    [SalesOrganization]          NVARCHAR (4)  NOT NULL,
    [CustomerAccountGroup]       NVARCHAR (4)  NULL,
    [DistributionChannel]        NVARCHAR (2)  NOT NULL,
    [Division]                   NVARCHAR (2)  NOT NULL,
    [PartnerFunction]            NVARCHAR (2)  NOT NULL,
    [PartnerCounter]             NVARCHAR (3)  NOT NULL,
    [Partner]                    NVARCHAR (10) NULL,
    [Vendor]                     NVARCHAR (8)  NULL,
    [PersonalNumber]             NVARCHAR (8)  NULL,
    [ContactPerson]              NVARCHAR (10) NULL,
    [Description]                NVARCHAR (30) NULL,
    [DefaultPartner]             NVARCHAR (1)  NULL,
    [FunctionDescription]        NVARCHAR (20) NULL,
    [Desccustpartm]              NVARCHAR (35) NULL,
    [Partnername]                NVARCHAR (35) NULL,
    [HashDiff]                   BINARY (16)   NOT NULL,
    CONSTRAINT [PK_NatCustomerSalesPartner_BK_V02] PRIMARY KEY NONCLUSTERED ([NatCustomerSalesPartner_BK] ASC) NOT ENFORCED
)
WITH (CLUSTERED INDEX([NatCustomerSalesPartner_BK]), DISTRIBUTION = ROUND_ROBIN);

