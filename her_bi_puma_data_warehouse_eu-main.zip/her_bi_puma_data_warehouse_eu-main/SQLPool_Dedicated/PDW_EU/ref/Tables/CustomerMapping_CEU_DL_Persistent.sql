﻿CREATE TABLE [ref].[CustomerMapping_CEU_DL_Persistent] (
    [MasterCustomerName]      NVARCHAR (50) NULL,
    [GlobalAccount]           NVARCHAR (50) NULL,
    [ISRArea_Code]            NVARCHAR (50) NULL,
    [Sold to Customer Number] NVARCHAR (50) NULL,
    [MappingCodeMDS]          NVARCHAR (50) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

