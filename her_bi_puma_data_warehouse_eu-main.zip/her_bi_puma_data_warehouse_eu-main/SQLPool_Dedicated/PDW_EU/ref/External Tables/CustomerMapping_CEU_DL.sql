﻿CREATE EXTERNAL TABLE [ref].[CustomerMapping_CEU_DL] (
    [MasterCustomerName] NVARCHAR (50) NULL,
    [GlobalAccount] NVARCHAR (50) NULL,
    [ISRArea_Code] NVARCHAR (50) NULL,
    [Sold to Customer Number] NVARCHAR (50) NULL,
    [MappingCodeMDS] NVARCHAR (50) NULL
)
    WITH (
    DATA_SOURCE = [ds_bieurope_encur_curated],
    LOCATION = N'/MDS/CustomerMapping/',
    FILE_FORMAT = [ff_parquet],
    REJECT_TYPE = VALUE,
    REJECT_VALUE = 0
    );

