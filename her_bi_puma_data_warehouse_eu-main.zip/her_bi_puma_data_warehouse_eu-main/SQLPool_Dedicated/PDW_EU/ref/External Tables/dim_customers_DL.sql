﻿CREATE EXTERNAL TABLE [ref].[dim_customers_DL] (
    [dim_customer_key] VARCHAR (10) NULL,
    [customer_name2] NVARCHAR (200) NULL,
    [vat_number] NVARCHAR (200) NULL,
    [customer_classification_code] NVARCHAR (200) NULL,
    [customer_account_group_code] NVARCHAR (200) NULL,
    [pdu_code] NVARCHAR (200) NULL,
    [postal_code] NVARCHAR (200) NULL,
    [customer_number] NVARCHAR (200) NULL,
    [country_code] NVARCHAR (200) NULL,
    [region] NVARCHAR (200) NULL,
    [_hashdiff] NVARCHAR (200) NULL,
    [_ldts] DATETIME2 (0) NULL,
    [city] NVARCHAR (200) NULL,
    [currency_code] NVARCHAR (200) NULL,
    [customer_name] NVARCHAR (200) NULL,
    [search_term] NVARCHAR (200) NULL,
    [deletion_indicator] NVARCHAR (200) NULL,
    [telephone_number] NVARCHAR (200) NULL,
    [pit_importer_code] NVARCHAR (200) NULL,
    [district] NVARCHAR (200) NULL,
    [street] NVARCHAR (200) NULL,
    [post_office_box] NVARCHAR (200) NULL,
    [_file_creation_datetime] DATETIME2 (0) NULL,
    [customer_creation_date] DATE NULL
)
    WITH (
    DATA_SOURCE = [ds_bigbd_encur_curated],
    LOCATION = N'/PDW_Sourcing/supplychain/dim_customers/',
    FILE_FORMAT = [ff_parquet],
    REJECT_TYPE = VALUE,
    REJECT_VALUE = 0
    );

