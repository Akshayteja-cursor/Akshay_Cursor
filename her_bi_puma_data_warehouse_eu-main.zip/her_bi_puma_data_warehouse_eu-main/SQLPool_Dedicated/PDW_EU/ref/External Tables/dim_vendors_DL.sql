﻿CREATE EXTERNAL TABLE [ref].[dim_vendors_DL] (
    [Py_HashValueBK] NVARCHAR (200) NULL,
    [FactoryCode] VARCHAR (10) NULL,
    [FactoryName] VARCHAR (60) NULL,
    [SupplierCode] VARCHAR (10) NULL,
    [SupplierName] VARCHAR (60) NULL,
    [SupplierCity] VARCHAR (30) NULL,
    [SupplierGroupDesc] VARCHAR (30) NULL,
    [FactoryCountry] VARCHAR (120) NULL,
    [CurrencyCode] VARCHAR (3) NULL,
    [SourceOrganizationCode] VARCHAR (20) NULL,
    [SourceOrganizationDesc] VARCHAR (60) NULL,
    [SupplierCountry] VARCHAR (120) NULL,
    [FactoryActive_Source] INT NULL,
    [FactoryShortName] VARCHAR (15) NULL,
    [SupplierShortName] VARCHAR (15) NULL,
    [Street] VARCHAR (60) NULL,
    [City] VARCHAR (60) NULL,
    [Zip_Code] VARCHAR (20) NULL,
    [ModifiedOn] DATETIME NULL
)
    WITH (
    DATA_SOURCE = [ds_bigbd_encur_curated],
    LOCATION = N'/PDW_ArticleInformation/ref/vFactories/',
    FILE_FORMAT = [ff_parquet],
    REJECT_TYPE = VALUE,
    REJECT_VALUE = 0
    );

