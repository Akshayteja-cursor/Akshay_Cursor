﻿CREATE VIEW [ref].[vGlobalPDM_Vendors] AS SELECT
		CAST(fac.FactoryCode AS VARCHAR(10)) AS FactoryCode
		,fac.FactoryName
		,fac.FactoryShortName
		,fac.FactoryCountry
		,CAST(ISNULL(NULLIF(TRIM(REPLACE(fac.Street,'-','')),''),'n/a') AS varchar(120)) AS FactoryStreet
		,CAST(ISNULL(NULLIF(TRIM(REPLACE(fac.City,'-','')),''),'n/a') AS varchar(120)) AS FactoryCity
		,CAST(ISNULL(NULLIF(TRIM(REPLACE(REPLACE(fac.Zip_Code,'-',''),CHAR(39),'')),''),'n/a') AS varchar(120)) AS FactoryZipCode
		,CAST(fac.CurrencyCode AS VARCHAR(3)) AS FactoryCurrencyCode
		,CAST(fac.SupplierCode AS VARCHAR(10)) AS SupplierCode
		,fac.SupplierName
		,fac.SupplierShortName
		,CAST(ISNULL(NULLIF(TRIM(REPLACE(fac.SupplierGroupDesc,'-','')),''),'n/a') AS varchar(120)) AS SupplierGroup
		--,CAST(ISNULL(NULLIF(TRIM(REPLACE(fac.SupplierCountry,'-','')),''),'n/a') AS varchar(120)) AS SupplierCountry
		,CAST('n/a' AS VARCHAR(120)) AS SupplierCountry
		,CAST(ISNULL(NULLIF(TRIM(REPLACE(fac.SupplierCity,'-','')),''),'n/a') AS varchar(120)) AS SupplierCity
		,CAST(fac.SourceOrganizationCode AS VARCHAR(10)) AS SourcingOrganizationCode
		,CAST(fac.SourceOrganizationDesc AS varchar(120)) AS SourcingOrganization
		,fac.FactoryActive_Source AS Active
	FROM
		ref.dim_vendors_DL fac

	UNION ALL
	SELECT
		'0' AS FactoryCode
		,'n/a' AS FactoryName
		,'n/a' AS FactoryShortName
		,'n/a' AS FactoryCountry
		,'n/a' AS FactoryStreet
		,'n/a' AS FactoryCity
		,'n/a' AS FactoryZipCode
		,'0' AS FactoryCurrencyCode
		,'n/a' AS SupplierCode
		,'n/a' AS SupplierName
		,'n/a' AS SupplierShortName
		,'n/a' AS SupplierGroup
		,'n/a' AS SupplierCountry
		,'n/a' AS SupplierCity
		,'n/a' AS SourcingOrganizationCode
		,'n/a' AS SourcingOrganization
		,1 AS Active;