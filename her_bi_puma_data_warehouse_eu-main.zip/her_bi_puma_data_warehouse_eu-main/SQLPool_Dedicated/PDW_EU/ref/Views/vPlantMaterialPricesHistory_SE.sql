﻿CREATE VIEW [ref].[vPlantMaterialPricesHistory_SE]
AS select * from
[ref].[PlantMaterialPricesHistory] a 
where salesorganization in ('1010','1030','1050');