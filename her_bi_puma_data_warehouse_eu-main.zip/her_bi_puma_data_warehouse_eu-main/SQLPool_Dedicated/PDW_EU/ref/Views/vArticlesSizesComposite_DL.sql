﻿CREATE VIEW [ref].[vArticlesSizesComposite_DL]
AS Select   
  A.ArticleNumber_BK   
  ,A.SizeNumber  
  ,ArticleSize_BK = CONCAT(A.ArticleNumber_BK, ' ', A.SizeNumber)  
  ,C.StyleNumber_BK  
  ,StyleNumber = RIGHT(CONCAT('000000',C.StyleNumber_BK),6)  
  ,C.StyleName  
  ,A.ArticleName  
  ,A.ColorNumber  
  ,A.ColorName  
  ,A.SizeCode  
  ,A.EANNo  
  ,A.SizeTableName  
  ,A.UPCNo  
  ,A.SizeScale  
  ,A.SizeConversionCodeUS  
  ,A.SizeConversionScaleCodeUS  
  ,A.SizeConversionCodeCN  
  ,A.SizeConversionScaleCodeCN  
  ,A.SizeSortingNumber  
  ,A.QuantityOuterCarton  
  ,A.SizeConversionCodeEUR  
  ,A.SizeConversionScaleCodeEUR  
  ,B.SeasonCode_BK AS ArtSeason  
  ,C.SeasonCode_BK As StyleSeason  
  ,B.ProductCreationModelCode  
  ,B.MainColorGroup  
  ,C.BusinessSegmentCode  
  ,C.BusinessUnitCode  
  ,B.ReportingMainProductCharacterCode AS RepMainProductCharacterCode   
  ,b.ReportingProductCharacterGroupCode AS RepProdCharacterGroupCode  
  ,C.Brand  
  ,C.BrandCode  
  ,C.ProductDivision  
  ,C.ProductDivisionCode  
  ,C.ProductClassification  
  ,C.RBU  
  ,C.RBUCode  
  ,C.ReferenceRBU AS IntRefRBUDesc  
  ,C.ReportingGenderCode AS RepIntGenderCode  
  ,CASE WHEN C.ReportingAgeGroup = 'kids' THEN C.ReportingAgeGroup   
        ELSE   
    CASE C.Gender   
                WHEN 'Male' THEN 'Men'   
                WHEN 'Female' THEN 'Women'  
                WHEN 'Undefined' THEN 'n/a'   
          ELSE C.Gender END   
   END AS RepAgeGender    
  ,C.ReportingAgeGroupCode RepAgeGrpCode  
  , C.ReportingAgeGroup RepAgeGrp  
  --,D.SizeTableDesc  
  ,C.ArticleType AS ArticleTypeDesc  
  ,Replace(A.ArticleNumber_BK,' ','') as ModifiedArticleNumber  
  ,Right(Concat('00',A.ColorNumber),2) as ModifiedColorNumber  
  ,Concat(A.ArticleNumber_BK,' ',A.SizeCode) as NatArticleSize_BK  
  ,Concat(Replace(A.ArticleNumber_BK,' ',''),'|',A.EANNo) as NatArticleEAN_BK  
  , B.Franchise  
  , B.FranchiseCode  
  , B.BusinessSegment,  
  C.ReportingGender AS  RepIntGender ,  
  B.ProductCreationModel AS ProdCreationModel,  
  B.ReportingMainProductCharacter AS RepMainProductCharacter,  
  B.ReportingProductCharacterGroup AS RepProductCharacterGroup,  
  B.ArticleTypeCode,  
  MainColorGroupCode,  
  A.SizeConversionCodeUK,  
  B.SeasonCode_StyleNumber_BK  
from ref.ArticleSizes_DL A   
INNER JOIN ref.ArticlesSeasonIndependent_DL B on A.ArticleNumber_BK=B.ArticleNumber_BK   
INNER JOIN ref.StylesSeasonIndependent_DL C on B.StyleNumber_BK=C.StyleNumber_BK   
Where A.EANNo != 'n/a';