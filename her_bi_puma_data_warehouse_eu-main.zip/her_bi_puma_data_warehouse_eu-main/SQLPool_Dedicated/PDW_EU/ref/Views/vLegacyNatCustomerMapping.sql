﻿CREATE VIEW [ref].[vLegacyNatCustomerMapping] AS SELECT  distinct 
	    a.[BusinessPartner] 
	  , d.[SalesOrganization]
	  ,'LegacyPartnerNumber'  = right ( LTRIM(LTRIM(LegacyPartnerNumber , ''''), '0') , 7 )
	  ,'LegacyNatCustomer_BK' = case 
								when d.[SalesOrganization] = '2000' 
									then concat ('2420|',i.pducode, '|' , right(LegacyPartnerNumber, 7) ) 
								when d.[SalesOrganization] = '1110' 
									then concat ('2420|',i.pducode, '|' , right(LegacyPartnerNumber, 7) ) 
								when d.[SalesOrganization] = '1130' 
									then concat ('2420|',i.pducode, '|' , right(LegacyPartnerNumber, 7) ) 
								when d.[SalesOrganization] = '1070' 
									then concat ('2420|',i.pducode, '|' , right(LegacyPartnerNumber, 7) ) 
								when d.[SalesOrganization] = '1090' 
									then concat ('2420|',i.pducode, '|' , right(LegacyPartnerNumber, 7) ) 
									end 
     , RANK() OVER (PARTITION BY right ( LTRIM(LTRIM(LegacyPartnerNumber , ''''), '0') , 7 )  ORDER BY a.[BusinessPartner] DESC ) AS RankResult
	 , getdate() as date_column
	 
FROM biz.[S4Hana_BPGeneralData1] a
left join biz.[S4Hana_CustomerBusinessPartner] b on a.[BusinessPartner] = b.But051partner
left join [stag].[vCustomerAccountGroup_DS] d on a.[BusinessPartner] = d.[BusinessPartner]
left join biz.S4Hana_BPLegacyPartnerData lp on a.[BusinessPartner] = lp.[partner] and lp.isdeleted = 0
left join [pdwref].[S4Hana_SalesOrgPDU] i on i.SalesOrg = d.[SalesOrganization]
	WHERE d.[SalesOrganization] in ( 1110, 2000,1090,1070,1130 ) 
	and LegacyPartnerType like '%0000'  and a.BPGroup <> 'Z007'

Union 

SELECT 'BusinessPartner' = [Sold-To Number] ,
       'SalesOrganization' = case when right(Left([NatCustomer_BK],12),7) in ('PLGERLC', 'PLGERLD', 'PLGERLX') then 2000
                                when right(Left([NatCustomer_BK],12),7) in ('PLAUTLD', 'PLAUTLC' ) then 1110
                                when right(Left([NatCustomer_BK],12),7) in ('PLSWILC', 'PLSWILD' ) then 1130
                                when right(Left([NatCustomer_BK],12),7) in ('PLBEXLN' ) then 1070
                                when right(Left([NatCustomer_BK],12),7) in ('PLBEXLB','PLBEXLC'  ) then 1090
                               end
        ,[Legacy Customer Number]
       ,[NatCustomer_BK]
      ,'RankResult' = 1
      ,'date_column' = getdate()
  FROM [pdwref].[CEU_CustomrMappingSAP_DL]
  where [NatCustomer_BK] not in ('2420|PLGERLD|0700124','2420|PLBEXLN|4054783');
