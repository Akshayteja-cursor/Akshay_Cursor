﻿CREATE VIEW [ref].[vNatArticles] AS select 
 art.NatArticle_BK
,art.CreatedOn
,art.ModifiedOn
,art.NatMaterialNo
,art.NatArticleNo
,art.CompanyCode
,art.IntPupMasterId
,art.PDUCode
,art.HashDiff
,ISNULL(art.NatMaterialDesc, '') as NatMaterialDesc
,art.NatStyleNo
,art.NatColorDesc
,art.EAN
,art.SizeScaleCode
,art.SizeCode
,art.SizeNumber
,art.MaterialSite
,art.DistributionChannel
,art.NatSizeLockFlag
,art.NatLaunchDate
,art.NatWholesaleCosts
,art.NatLandedCosts
,art.NatLocalRetailPrice
,art.CurrencyCode
,art.BrandCode
,art.GenderCode
,art.GenderDesc
,art.DistChannelCode
,art.DistChannelDesc
,art.DCSClassCode
,art.DCSSubClassCode
,art.RetailDCSDepCode
,art.ProdDivCode
,art.ProdDivDesc
,art.BusSegCode
,art.BusSubSegCode
,art.RBUCode
,rb.[description] as RBUDesc 
,art.OutletTheme
,art.FPeComTheme
,art.RetailBusUnit
,art.Retailclass
,art.RetailSubClass
,art.RetailGender
,art.RetailProdDiv
,art.PIDFlag
,art.CRP
,art.FirstAssortment
,art.LatestAssortment
,art.Exclusivity
,art.[Specialist1]
,st1.[description] as Specialist1Desc
,art.[Specialist2]
,st2.[description] as Specialist2Desc
,art.[Specialist3]
,st3.[description] as Specialist3Desc
,art.[Specialist4]
,st4.[description] as Specialist4Desc
,art.[Specialist5]
,st5.[description] as Specialist5Desc
,art.[Specialist6]
,st6.[description] as Specialist6Desc
,art.[Specialist7]
,st7.[description] as Specialist7Desc
,art.[Specialist8]
,st8.[description] as Specialist8Desc
,art.NeveroutofStock
,art.ProductStatus
,art.ProductLifecycle
,Plc.[description] as ProdLifecycleDesc
,art.Embargo
,art.ProductFamily
,pft.[description] as ProductFamilyDesc
,art.ProductSubFamily
,pfst.[description] as ProductSubFamilyDesc
,art.AssortmentCategory1
,ass1.[description] as AssortmentCategory1Desc
,art.AssortmentCategory2
,ass2.[description] as AssortmentCategory2Desc
,art.FirstPIDSeason
,art.LastPIDSeason
,art.Theme
,art.StyleDesc
,art.LocalDC
 from ref.natarticles art
left join stag.S4Hana_vRBUTexts rb on art.RBUCode = rb.code
left join stag.S4Hana_vSpecialistTexts st1 on art.Specialist1 = st1.SPECIALIST
left join stag.S4Hana_vSpecialistTexts st2 on art.Specialist2 = st2.SPECIALIST
left join stag.S4Hana_vSpecialistTexts st3 on art.Specialist3 = st3.SPECIALIST
left join stag.S4Hana_vSpecialistTexts st4 on art.Specialist4 = st4.SPECIALIST
left join stag.S4Hana_vSpecialistTexts st5 on art.Specialist5 = st5.SPECIALIST
left join stag.S4Hana_vSpecialistTexts st6 on art.Specialist6 = st6.SPECIALIST
left join stag.S4Hana_vSpecialistTexts st7 on art.Specialist7 = st7.SPECIALIST
left join stag.S4Hana_vSpecialistTexts st8 on art.Specialist8 = st8.SPECIALIST
left join stag.S4Hana_vProdLifeCycleTexts Plc on art.ProductLifecycle = plc.PRODUCTLIFECYCLE
left join stag.S4Hana_vPRODFamilyTexts pft on art.[ProductFamily] = pft.[ProductFamily]
left join stag.S4Hana_vPRODFAMSubTexts pfst on art.[ProductSubFamily] = pfst.PRODUCTSUBFAMILY
left join stag.S4Hana_vAssortMCat1Texts ass1 on  art.AssortmentCategory1 =  ass1.ASSORTCATEGORY1
left join stag.S4Hana_vAssortMCat2Texts ass2 on  art.AssortmentCategory2 =  ass2.ASSORTCATEGORY2;
