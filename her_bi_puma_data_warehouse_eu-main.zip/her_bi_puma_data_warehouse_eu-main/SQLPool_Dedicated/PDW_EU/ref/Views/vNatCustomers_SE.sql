﻿CREATE VIEW [ref].[vNatCustomers_SE] AS select 
cu.NatCustomerId
,cu.NatCustomer_BK
,cu.CreatedOn
,cu.ModifiedOn
,cu.NatCustomerNo
,cu.CompanyCode
,cu.IntPupMasterId
,cu.PDUCode
,cu.HashDiff
,cu.NatCustomerName
,cu.MainCustomerNo
,cu.MainCustomerName
,cu.MasterCustomerNo
,cu.MasterCustomerName
,cu.CustBusClassCode
,cu.CustBusClassDesc
,cu.DistChannelCode
,cu.DistChannelDesc
,cu.CountryCode
,cu.CountryDesc
,cu.City
,cu.PostalCode
,cu.Street
,cu.Region
,cu.[Language]
,cu.OrganizationBPName1
,cu.OrderIsBlockedForCustomer
,cu.PumaDC
,cu.CustomerAccountGroup
,cagt.CustomerAccountGroupName as CustomerAccountGroupName
,cu.Account
,cu.AccountName
,cu.AreaAccount
,cu.AccountRole
,cu.CustomerGroupCode
,cgt.[DESCRIPTION] as CustomerGroupDesc
,cu.ReportingGroup10
,rpt.[Description] as ReportingGroupDesc
,cu.CustomerCorporateGroup
,cu.OrganizationBpName2
,cu.CreditBlock
,cu.CreditBlockReason
,cu.SalesManagerCode
,cu.SalesManagerName
,cu.SalesAreaManagerCode
,cu.SalesAreaManagerName
,cu.SalesmanCode
,cu.SalesmanName
,NULL	AS idPartner 
,NULL	AS LegacyCustomer
,NULL	AS LegacyVendor
,cu.AdditionalCustomerGroup4 
,cu.LocalCustomerGroupCode	 
,cu.LocalCustomerGroupDesc	 
,cu.PayerCode
,cu.PayerName
,cu.OwnerGroupCode
,cu.OwnerGroupName
,cu.CustomerServiceRepCode
,cu.CustomerServiceRepName
,cu.Active
,cu.CustomerGroupName
,cu.BuyingGroup
,cgrt.[DESCRIPTION] as BuyingGroupDesc 
,cu.DC31Performance
,cu.Specialist
,cst.[description] as SpecialistDesc
,cu.NeveroutofStock
,cu.LocalOwnerGroup
,lo.[description] as LocalOwnerGroupDesc 
,cu.TeamBusinessSpecIdentification
,tb.[DESCRIPTION] as  TeamBusinessSpecIdentificationDesc
,cu.DunningBlock
,cu.ShopName
,st.[description] as ShopNameDesc
,cu.AccountType
,aty.[description] as AccountTypeDesc
,cu.EDI
,cu.CallCenterCampaign
,cu.CommercialOperations
,cu.EarlyShipment
,cu.RestrictProdAccess
,cu.credit_limit
,cu.CreditControlArea
,cu.Postingblockforcompanycode
,cu.DeletionFlagCompanyCodeLevel
,cu.BlockKeyforPayment
,cu.DunningArea
,cu.[AccountByCustomer]  
,cu.[TAXNUMBER]			
,cu.[InsuranceLimit]	
,cu.[dunningclerk]		
,cu.[HOAccountNo]		
,cu.[Payer_CreditBlock]	
,CAST(cu.[Payer_credit_limit] AS INT) [Payer_credit_limit]
,cu.[DZBNo]
from ref.NatCustomers cu 
left join stag.S4Hana_vCustSpecialistTexts cst on cu.Specialist = cst.CUSTSPECIALIST
left join stag.S4Hana_vLocalOwnerGroupTexts lo on cu.LocalOwnerGroup = lo.LOCALOWNERGROUP
left join [stag].[S4Hana_vTeamBusSpecIDTexts] tb on cu.TeamBusinessSpecIdentification = tb.[TEAMBUSSPECID]
left join stag.S4Hana_vShopTexts st on cu.ShopName = st.shop
left join stag.S4Hana_vAccountTypeTexts aty on cu.AccountType = aty.AccountType
left join [stag].[S4Hana_VBPGeneralData1] b on cast(b.BusinessPartner as varchar(50))= cast(cu.NatCustomerno as varchar(50))
left join [stag].[S4Hana_vCustomerGroupTexts] cgt on cu.CustomerGroupCode = cgt.[Code]
left join [stag].[S4Hana_vCustomerAccountGroupTexts] cagt on cagt.CustomerAccountGroup = cu.CustomerAccountGroup
left join stag.S4Hana_vReportingGroup10Texts rpt on cu.ReportingGroup10 = rpt.code 
left join stag.S4Hana_vcustomergroup4Texts cgrt on cu.buyingGroup = cgrt.BUYINGGROUP4
where cu.CompanyCode IN ('ES10','PT10','IT10');