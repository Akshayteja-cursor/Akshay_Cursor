﻿CREATE VIEW [ref].[vNatCustomers_CEU_OpCo] AS SELECT distinct
    'CustomerId'                           = c.natcustomer_BK
    ,'CustomerNumber'                      = c.NatCustomerNo 
    ,'CustomerName'                        = c.NatCustomerName 
	,'Natcustomer_BK'                      = c.natcustomer_BK
    ,'CustomerNameInt'                     = null
    ,'ISOCountryCode'                      = c.CountryCode       
    ,'ISOCountry'                          = c.CountryDesc  
    ,'ISRMarketRegion'                     = isr.ISRMarketRegionDesc
    ,'ISRMarket'                           = isr.ISRMarketDesc         
    ,'ISRSubMarket'                        = isr.ISRSubMarketDesc
    ,'PDUCode'                             = c.PDUCode
    ,'PDU'                                 = case 
													when c.SalesOrganization = 2000 then 'PUMA Germany'
													when c.SalesOrganization = 1070 then 'PUMA Benelux NLD (PC)'	
													when c.SalesOrganization = 1130 then 'PUMA Switzerland Dom (PC)'	
													when c.SalesOrganization = 1110 then 'PUMA Switzerland Dom (PC)'	
													when c.SalesOrganization = 1090 then 'PUMA Benelux BEL (PC)'
													end

    /* BII Customer References */    
    ,'MainCustomerNumber'                  = c.MainCustomerNo
    ,'MainCustomerName'                    = c.MainCustomerName 
    ,'MasterCustomerNumber'                = c.MasterCustomerNo
    ,'MasterCustomerName'                  = COALESCE(c.MasterCustomerName,'')
    ,'GlobalAccount'                       = COALESCE(replace(c.accountname, ' {}', ''),'')
	 ,'AccountRole'                   = c.AccountRole

    /* BII Customer References */

    ,'CustomerBusinessType'                = 'Wholesale'
    ,'CustomerBusinessClass'               = c.CustBusClassDesc
	,'CustomerBusinessClassCode'           = case when c.CustBusClassCode = 30 then 20 else c.CustBusClassCode  end 
    ,'CustomerOrganisation'                = NULL 
    ,'CustomerOrgSortNo'                   = null 
    ,'CustomerDistributionChannel'         = c.DistChannelDesc
    ,'DistChanSortNo'                      = null
    ,'CustomerStructure'                   = NULL
    ,'CustomerStructSortNo'                = null 
    ,'CustomerOrgCode'                     = null
    ,'CustomerType'                        = NULL
    ,'CustomerTypeSortNo'                  = null 

    ,'GlobalAccountType'                   = null 
    ,'BuyingGroup'                         = NULL

    /* MDS Customer References */
    ,'RepAccount'                          = null 
    ,'RepAccountCode'                      = null 
    ,'RepAccountRole'                      = null 
    ,'RepCustomerType'                     = null 
    ,'RepCustomerStructure'                = null 
    ,'RepCustomerDistChannel'              = c.DistChannelDesc
    ,'RepBuyingGroup'                      = null 
    ,'RepMainCustomerName'                 = null
    ,'RepMasterCustomerName'               = null
    ,'RepAreaAccount'                      = null

    /* Retail Only References */
    ,'StoreType'                           = null
    ,'HFMStoreCode'                        = null

    /* National References */
    ,'Territory'                           = null 
    ,'NationalClassification1'             = null
    ,'NationalClassification2'             = null
    ,'NatCustFunct'                        = null 
    ,'NationalAttribute1'                  = null
    ,'NationalAttribute2'                  = null
    ,'NationalAttribute3'                  = null
    ,'NationalAttribute4'                  = null
    ,'NationalAttribute5'                  = null
    ,'NationalAttribute6'                  = null
    ,'NationalAttribute7'                  = null
    ,'NationalAttribute8'                  = null
    ,'NationalAttribute9'                  = null
    ,'NationalAttribute10'                 = null
    ,'NationalAttribute11'                 = null
    ,'NationalAttribute12'                 = null
    ,'SalesTeamCode'                       = null 
    ,'NatCustomFlag'                       = null 
    ,'PlanningCustomerId'                  = null
    ,'PlanningCustomerCode'                = null
    ,'PlanningCustomerName'                = null
    
    /* MypumaBiz Flag*/
    ,'MyPumaBizFlag'                       =   CASE
                                                   WHEN  c.CustomerAccountGroup = 'Z004' THEN 'MyPumaBiz Ready'
                                                   ELSE 'MyPumaBiz Not Ready'
                                               END
    /* Sell Thru MDS fields */
    ,'RepSellThroughAccount'               = null 
    ,'RepSellThroughAccountParent'         = null 
    , 'partition' = 'CEU'
   
FROM
    [ref].[NatCustomers] c 
       left join [pdwref].[ISOCountries] isr  with(nolock) on c.CountryCode = isr.ISOCountryCode

 where c.active =  1  and c.COMPANYCODE in ('AT19' ,'BE19','DE19' ,'CH19', 'NL19') 

 Union 


 SELECT distinct
    'CustomerId'                           = cte.LegacyNatCustomer_BK
    ,'CustomerNumber'                      = c.NatCustomerNo 
    ,'CustomerName'                        = c.NatCustomerName 
	,'Natcustomer_BK'                      = cte.LegacyNatCustomer_BK
    ,'CustomerNameInt'                     = null
    ,'ISOCountryCode'                      = c.CountryCode       
    ,'ISOCountry'                          = c.CountryDesc  
    ,'ISRMarketRegion'                     = isr.ISRMarketRegionDesc
    ,'ISRMarket'                           = isr.ISRMarketDesc         
    ,'ISRSubMarket'                        = isr.ISRSubMarketDesc
    ,'PDUCode'                             = c.PDUCode
    ,'PDU'                                 = case 
													when c.SalesOrganization = 2000 then 'PUMA Germany'
													when c.SalesOrganization = 1070 then 'PUMA Benelux NLD (PC)'	
													when c.SalesOrganization = 1130 then 'PUMA Switzerland Dom (PC)'	
													when c.SalesOrganization = 1110 then 'PUMA Switzerland Dom (PC)'	
													when c.SalesOrganization = 1090 then 'PUMA Benelux BEL (PC)'
													end

    /* BII Customer References */    
    ,'MainCustomerNumber'                  = c.MainCustomerNo
    ,'MainCustomerName'                    = c.MainCustomerName 
    ,'MasterCustomerNumber'                = c.MasterCustomerNo
    ,'MasterCustomerName'                  = COALESCE(c.MasterCustomerName,'')
    ,'GlobalAccount'                       = COALESCE(replace(c.accountname, ' {}', ''),'')
	,'AccountRole'                   = c.AccountRole

    /* BII Customer References */

    ,'CustomerBusinessType'                = 'Wholesale'
    ,'CustomerBusinessClass'               = c.CustBusClassDesc
	,'CustomerBusinessClassCode'           = case when c.CustBusClassCode = 30 then 20 else c.CustBusClassCode  end 
    ,'CustomerOrganisation'                = NULL 
    ,'CustomerOrgSortNo'                   = null 
    ,'CustomerDistributionChannel'         = c.DistChannelDesc
    ,'DistChanSortNo'                      = null
    ,'CustomerStructure'                   = NULL
    ,'CustomerStructSortNo'                = null 
    ,'CustomerOrgCode'                     = null
    ,'CustomerType'                        = NULL
    ,'CustomerTypeSortNo'                  = null 

    ,'GlobalAccountType'                   = null 
    ,'BuyingGroup'                         = NULL

    /* MDS Customer References */
    ,'RepAccount'                          = null 
    ,'RepAccountCode'                      = null 
    ,'RepAccountRole'                      = null 
    ,'RepCustomerType'                     = null 
    ,'RepCustomerStructure'                = null 
    ,'RepCustomerDistChannel'              = c.DistChannelDesc
    ,'RepBuyingGroup'                      = null 
    ,'RepMainCustomerName'                 = null
    ,'RepMasterCustomerName'               = null
    ,'RepAreaAccount'                      = null

    /* Retail Only References */
    ,'StoreType'                           = null
    ,'HFMStoreCode'                        = null

    /* National References */
    ,'Territory'                           = null 
    ,'NationalClassification1'             = null
    ,'NationalClassification2'             = null
    ,'NatCustFunct'                        = null 
    ,'NationalAttribute1'                  = null
    ,'NationalAttribute2'                  = null
    ,'NationalAttribute3'                  = null
    ,'NationalAttribute4'                  = null
    ,'NationalAttribute5'                  = null
    ,'NationalAttribute6'                  = null
    ,'NationalAttribute7'                  = null
    ,'NationalAttribute8'                  = null
    ,'NationalAttribute9'                  = null
    ,'NationalAttribute10'                 = null
    ,'NationalAttribute11'                 = null
    ,'NationalAttribute12'                 = null
    ,'SalesTeamCode'                       = null 
    ,'NatCustomFlag'                       = null 
    ,'PlanningCustomerId'                  = null
    ,'PlanningCustomerCode'                = null
    ,'PlanningCustomerName'                = null
    
    /* MypumaBiz Flag*/
    ,'MyPumaBizFlag'                       =   CASE
                                                   WHEN  c.CustomerAccountGroup = 'Z004' THEN 'MyPumaBiz Ready'
                                                   ELSE 'MyPumaBiz Not Ready'
                                               END
    /* Sell Thru MDS fields */
    ,'RepSellThroughAccount'               = null 
    ,'RepSellThroughAccountParent'         = null 
	, 'partition' = 'CEU'
   
FROM
    [ref].[NatCustomers] c 
       left join [pdwref].[ISOCountries] isr  with(nolock) on c.CountryCode = isr.ISOCountryCode
           join [ref].[vLegacyNatCustomerMapping] cte on c.NatCustomerNo = cte.[BusinessPartner] and cte.SalesOrganization = c.SalesOrganization  and RankResult = 1 

 where c.active =  1  and c.COMPANYCODE in ('AT19' ,'BE19','DE19' ,'CH19', 'NL19');