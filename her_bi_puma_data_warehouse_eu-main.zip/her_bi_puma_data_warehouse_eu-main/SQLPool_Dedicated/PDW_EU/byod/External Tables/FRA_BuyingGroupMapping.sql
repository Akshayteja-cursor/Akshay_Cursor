CREATE EXTERNAL TABLE [byod].[FRA_BuyingGroupMapping]
(
	[BuyingGroupLanding] [nvarchar](100) NULL,
	[BuyingGroup] [nvarchar](3) NULL,
	[BuyingGroupDesc] [nvarchar](60) NULL
)
WITH (DATA_SOURCE = [ds_bieurope_work_workspacefrance],LOCATION = N'FRA_MI/BI/source/BuyingGroupMapping/',FILE_FORMAT = [ff_parquet],REJECT_TYPE = VALUE,REJECT_VALUE = 0)
GO
