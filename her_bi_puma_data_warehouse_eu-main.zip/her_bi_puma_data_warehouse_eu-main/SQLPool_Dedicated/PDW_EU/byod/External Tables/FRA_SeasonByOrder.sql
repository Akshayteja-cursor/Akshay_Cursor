CREATE EXTERNAL TABLE [byod].[FRA_SeasonByOrder]
(
	[SalesOrderNumber] [nvarchar](30) NULL,
	[SalesOrderNumberItem] [nvarchar](30) NULL,
	[Season] [nvarchar](14) NULL
)
WITH (DATA_SOURCE = [ds_bieurope_work_workspacefrance],LOCATION = N'FRA_MI/BI/source/SeasonByOrder/',FILE_FORMAT = [ff_parquet],REJECT_TYPE = VALUE,REJECT_VALUE = 0)
GO
