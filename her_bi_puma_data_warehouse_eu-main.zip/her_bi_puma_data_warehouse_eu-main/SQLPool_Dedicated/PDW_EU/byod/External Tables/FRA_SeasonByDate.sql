CREATE EXTERNAL TABLE [byod].[FRA_SeasonByDate]
(
	[Season] [nvarchar](14) NULL,
	[SOCreationDateBegin] [int] NULL,
	[SOCreationDateEnd] [int] NULL
)
WITH (DATA_SOURCE = [ds_bieurope_work_workspacefrance],LOCATION = N'FRA_MI/BI/source/SeasonByDate/',FILE_FORMAT = [ff_parquet],REJECT_TYPE = VALUE,REJECT_VALUE = 0)
GO
