﻿CREATE EXTERNAL TABLE [pdwref].[S4Hana_SalesTypes_DL] (
    [SalesTypesEBP_ID] INT NOT NULL,
    [IntSalesType] INT NOT NULL,
    [MappingDesc] VARCHAR (30) NOT NULL,
    [SOTypeCode] VARCHAR (4) NOT NULL,
    [EBPDesc] VARCHAR (30) NOT NULL,
    [IsFinanceOOH] BIT NULL
)
    WITH (
    DATA_SOURCE = [ds_bieurope_encur_curated],
    LOCATION = N'/EU_REF/pdwref/S4Hana_SalesTypes/',
    FILE_FORMAT = [ff_parquet],
    REJECT_TYPE = VALUE,
    REJECT_VALUE = 0
    );

