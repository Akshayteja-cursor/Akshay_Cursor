﻿CREATE TABLE [pdwref].[S4Hana_CustomerDistributionChannel] (
    [CustDistChannelCode] VARCHAR (4)  NOT NULL,
    [Description]         VARCHAR (25) NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

