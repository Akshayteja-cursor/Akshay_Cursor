﻿CREATE TABLE [pdwref].[S4Hana_Genders] (
    [GenderCode] NVARCHAR (10) NOT NULL,
    [GenderDesc] NVARCHAR (50) NOT NULL,
    [Active]     BIT           NOT NULL
)
WITH (CLUSTERED INDEX([GenderCode]), DISTRIBUTION = REPLICATE);

