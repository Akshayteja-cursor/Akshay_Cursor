﻿CREATE TABLE [pdwref].[S4Hana_LocalCustomerGroups] (
    [LocalCustomerGroup] NVARCHAR (10)  NOT NULL,
    [DESCRIPTION]        NVARCHAR (100) NOT NULL
)
WITH (CLUSTERED INDEX([LocalCustomerGroup]), DISTRIBUTION = REPLICATE);

