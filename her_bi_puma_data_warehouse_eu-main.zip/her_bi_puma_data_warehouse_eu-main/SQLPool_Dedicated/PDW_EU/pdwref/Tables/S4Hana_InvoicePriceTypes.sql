﻿CREATE TABLE [pdwref].[S4Hana_InvoicePriceTypes] (
    [IntInvoicePriceTypeCode] INT          NOT NULL,
    [MappingDesc]             VARCHAR (9)  NOT NULL,
    [NatInvoiceTypeCode]      VARCHAR (4)  NOT NULL,
    [EBPDesc]                 VARCHAR (50) NOT NULL,
    [ID]                      INT          IDENTITY (1, 1) NOT NULL
)
WITH (CLUSTERED INDEX([ID]), DISTRIBUTION = REPLICATE);

