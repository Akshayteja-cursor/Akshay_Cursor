﻿CREATE TABLE [pdwref].[S4Hana_InvoiceRecTypes] (
    [IntRecTypeCode] INT            NOT NULL,
    [MappingDesc]    VARCHAR (25)   NOT NULL,
    [EBPIndicator]   VARCHAR (4)    NOT NULL,
    [EBPDesc]        NVARCHAR (250) NOT NULL
)
WITH (CLUSTERED INDEX([EBPIndicator]), DISTRIBUTION = REPLICATE);

