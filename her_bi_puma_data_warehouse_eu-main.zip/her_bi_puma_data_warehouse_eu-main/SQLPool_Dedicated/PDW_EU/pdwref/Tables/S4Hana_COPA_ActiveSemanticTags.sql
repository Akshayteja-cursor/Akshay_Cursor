﻿CREATE TABLE [pdwref].[S4Hana_COPA_ActiveSemanticTags] (
    [COPA_ActiveSemanticTagsID] INT           IDENTITY (1, 1) NOT NULL,
    [SemanticTag]               VARCHAR (30)  NOT NULL,
    [IsActive]                  BIT           DEFAULT ((1)) NOT NULL,
    [ModifiedOn]                SMALLDATETIME NOT NULL
)
WITH (CLUSTERED INDEX([COPA_ActiveSemanticTagsID]), DISTRIBUTION = REPLICATE);

