﻿CREATE TABLE [pdwref].[ISOCountries] (
    [ISOCountryCode]      NVARCHAR (2)   NOT NULL,
    [ISOCountryCode3]     NVARCHAR (3)   NOT NULL,
    [ISOCountryNo]        INT            NOT NULL,
    [ISOCountryDesc]      NVARCHAR (60)  NOT NULL,
    [ISRMarketCode]       NVARCHAR (15)  NOT NULL,
    [ISRMarketDesc]       NVARCHAR (120) NOT NULL,
    [ISRSubMarketCode]    NVARCHAR (15)  NOT NULL,
    [ISRSubMarketDesc]    NVARCHAR (120) NOT NULL,
    [ISRMarketRegionCode] NVARCHAR (15)  NOT NULL,
    [ISRMarketRegionDesc] NVARCHAR (120) NOT NULL
)
WITH (CLUSTERED INDEX([ISOCountryCode]), DISTRIBUTION = REPLICATE);

