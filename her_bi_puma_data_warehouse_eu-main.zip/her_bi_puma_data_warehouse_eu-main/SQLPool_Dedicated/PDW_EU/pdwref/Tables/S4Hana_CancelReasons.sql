﻿CREATE TABLE [pdwref].[S4Hana_CancelReasons] (
    [IntCancelReasonCode] INT          NOT NULL,
    [MappingDesc]         VARCHAR (72) NULL,
    [EBPIndicator]        VARCHAR (2)  NOT NULL,
    [EBPDesc]             VARCHAR (40) NOT NULL,
    [ID]                  INT          IDENTITY (1, 1) NOT NULL
)
WITH (CLUSTERED INDEX([ID]), DISTRIBUTION = REPLICATE);

