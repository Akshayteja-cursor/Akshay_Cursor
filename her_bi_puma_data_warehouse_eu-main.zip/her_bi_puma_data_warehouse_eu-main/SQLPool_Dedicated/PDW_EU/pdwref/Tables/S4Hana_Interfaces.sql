﻿CREATE TABLE [pdwref].[S4Hana_Interfaces] (
    [ID]                   INT            IDENTITY (1, 1) NOT NULL,
    [Interface]            NVARCHAR (20)  NOT NULL,
    [Country]              NVARCHAR (60)  NOT NULL,
    [IntPupMasterId]       INT            NOT NULL,
    [IntPupNo]             INT            NOT NULL,
    [PDUCode]              VARCHAR (15)   NOT NULL,
    [PDUDesc]              NVARCHAR (120) NOT NULL,
    [SourceSysDetailedId]  INT            NULL,
    [LastModifiedDate]     DATETIME       NOT NULL,
    [CompanyCode]          NVARCHAR (4)   NULL,
    [SourcingCustomerCode] NVARCHAR (5)   NULL,
    [RegionCode]           NVARCHAR (4)   NULL,
    [SalesOrg]             INT            NULL
)
WITH (CLUSTERED INDEX([ID]), DISTRIBUTION = REPLICATE);



