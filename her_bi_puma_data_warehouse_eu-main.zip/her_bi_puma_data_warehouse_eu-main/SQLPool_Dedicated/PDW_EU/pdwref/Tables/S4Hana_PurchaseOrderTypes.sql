﻿CREATE TABLE [pdwref].[S4Hana_PurchaseOrderTypes] (
    [POTypeId]      INT           IDENTITY (1, 1) NOT NULL,
    [IntPOTypeCode] INT           NOT NULL,
    [MappingDesc]   NVARCHAR (40) NOT NULL,
    [EBPIndicator]  NVARCHAR (4)  NOT NULL,
    [EBPDesc]       NVARCHAR (40) NOT NULL
)
WITH (CLUSTERED INDEX([POTypeId]), DISTRIBUTION = REPLICATE);

