﻿CREATE TABLE [pdwref].[S4Hana_InvoiceTypes] (
    [IntInvoiceTypeCode] INT            NOT NULL,
    [IntInvoiceTypeDesc] VARCHAR (25)   NOT NULL,
    [SOTypeCode]         VARCHAR (4)    NOT NULL,
    [EBPDesc]            NVARCHAR (250) NOT NULL
)
WITH (CLUSTERED INDEX([SOTypeCode]), DISTRIBUTION = REPLICATE);

