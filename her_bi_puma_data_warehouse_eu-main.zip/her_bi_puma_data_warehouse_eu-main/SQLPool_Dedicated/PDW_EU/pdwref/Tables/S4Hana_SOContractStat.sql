﻿CREATE TABLE [pdwref].[S4Hana_SOContractStat] (
    [totalSDDocReferenceStatus] NVARCHAR (2)  NOT NULL,
    [Description]               NVARCHAR (50) NOT NULL
)
WITH (CLUSTERED INDEX([totalSDDocReferenceStatus]), DISTRIBUTION = REPLICATE);

