﻿CREATE TABLE [pdwref].[AreaCodeMapping] (
    [ID]                INT           IDENTITY (1, 1) NOT NULL,
    [SalesOrganization] NVARCHAR (4)  NOT NULL,
    [Companycode]       NVARCHAR (4)  NOT NULL,
    [AreaCode]          NVARCHAR (15) NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = REPLICATE);

