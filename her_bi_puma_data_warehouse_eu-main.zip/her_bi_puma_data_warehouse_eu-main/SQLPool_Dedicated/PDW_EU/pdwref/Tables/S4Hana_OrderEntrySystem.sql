﻿CREATE TABLE [pdwref].[S4Hana_OrderEntrySystem] (
    [NatOrderEntrySys] NVARCHAR (10) NOT NULL,
    [OrderEntrySys]    NVARCHAR (50) NOT NULL
)
WITH (CLUSTERED INDEX([NatOrderEntrySys]), DISTRIBUTION = REPLICATE);

