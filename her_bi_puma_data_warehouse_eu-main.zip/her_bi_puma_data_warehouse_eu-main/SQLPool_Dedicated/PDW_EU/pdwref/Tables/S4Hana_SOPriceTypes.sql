﻿CREATE TABLE [pdwref].[S4Hana_SOPriceTypes] (
    [IntSOPriceTypeCode] INT          NOT NULL,
    [MappingDesc]        VARCHAR (9)  NOT NULL,
    [SOTypeCode]         VARCHAR (4)  NOT NULL,
    [EBPDesc]            VARCHAR (30) NOT NULL,
    [ID]                 INT          IDENTITY (1, 1) NOT NULL
)
WITH (CLUSTERED INDEX([ID]), DISTRIBUTION = REPLICATE);

