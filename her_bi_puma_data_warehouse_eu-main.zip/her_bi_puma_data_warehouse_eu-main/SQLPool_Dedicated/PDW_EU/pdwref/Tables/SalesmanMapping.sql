﻿CREATE TABLE [pdwref].[SalesmanMapping] (
    [LegacySalesmanNo] VARCHAR (7)  NULL,
    [SapSalesmanNo]    VARCHAR (10) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

