﻿CREATE TABLE [pdwref].[S4Hana_COPA_ProfitCenters] (
    [ProfitCenter]     NVARCHAR (10) NULL,
    [ProfitCenterDesc] NVARCHAR (50) NULL
)
WITH (CLUSTERED INDEX([ProfitCenter]), DISTRIBUTION = REPLICATE);

