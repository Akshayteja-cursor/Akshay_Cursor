﻿CREATE TABLE [pdwref].[S4Hana_SalesTypes] (
    [SalesTypesEBP_ID]     INT           IDENTITY (1, 1) NOT NULL,
    [IntSalesType]         INT           NOT NULL,
    [MappingDesc]          VARCHAR (100) NULL,
    [SOTypeCode]           VARCHAR (4)   NOT NULL,
    [EBPDesc]              VARCHAR (100) NULL,
    [IsFinanceOOH]         BIT           NULL,
    [SecBusinessPerimeter] BIT           NULL,
    [OrderBusinessType]    VARCHAR (50)  NULL
)
WITH (CLUSTERED INDEX([SalesTypesEBP_ID]), DISTRIBUTION = REPLICATE);





