﻿CREATE TABLE [pdwref].[S4Hana_COPA_DiscountReasons] (
    [DiscountReasonCode] NVARCHAR (3)  NULL,
    [DiscountReasonDesc] NVARCHAR (50) NULL
)
WITH (CLUSTERED INDEX([DiscountReasonCode]), DISTRIBUTION = REPLICATE);

