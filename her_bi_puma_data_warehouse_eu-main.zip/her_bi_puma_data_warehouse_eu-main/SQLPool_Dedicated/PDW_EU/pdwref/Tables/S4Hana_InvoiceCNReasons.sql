﻿CREATE TABLE [pdwref].[S4Hana_InvoiceCNReasons] (
    [IntCNReasonCode] INT           NOT NULL,
    [MappingDesc]     VARCHAR (100) NOT NULL,
    [EBPIndicator]    VARCHAR (4)   NOT NULL,
    [EBPDesc]         VARCHAR (100) NOT NULL,
    [ID]              INT           IDENTITY (1, 1) NOT NULL
)
WITH (CLUSTERED INDEX([ID]), DISTRIBUTION = REPLICATE);

