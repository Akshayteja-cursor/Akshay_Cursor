﻿CREATE TABLE [pdwref].[S4Hana_ShippingModes] (
    [ShippingModeCode]        NVARCHAR (25)  NOT NULL,
    [ShippingModeDescription] NVARCHAR (500) NOT NULL
)
WITH (CLUSTERED INDEX([ShippingModeCode]), DISTRIBUTION = REPLICATE);

