﻿CREATE TABLE [pdwref].[S4Hana_ProductDivisions] (
    [ProdDivCode] NVARCHAR (10) NOT NULL,
    [ProdDivDesc] NVARCHAR (50) NOT NULL,
    [Active]      BIT           NOT NULL
)
WITH (CLUSTERED INDEX([ProdDivCode]), DISTRIBUTION = REPLICATE);

