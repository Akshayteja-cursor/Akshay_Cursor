﻿CREATE TABLE [pdwref].[S4Hana_BillingBlockReasons] (
    [HeaderBillingBlockReason] VARCHAR (2)  NOT NULL,
    [ItemBillingBlockReason]   VARCHAR (71) NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

