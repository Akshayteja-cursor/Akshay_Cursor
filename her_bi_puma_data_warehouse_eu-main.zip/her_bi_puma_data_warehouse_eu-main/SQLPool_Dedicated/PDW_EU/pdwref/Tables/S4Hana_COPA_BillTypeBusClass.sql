﻿CREATE TABLE [pdwref].[S4Hana_COPA_BillTypeBusClass] (
    [COPA_BillTypeBusClassID] INT           IDENTITY (1, 1) NOT NULL,
    [BillingDocTypeCode]      VARCHAR (4)   NOT NULL,
    [BillingDocTypeDesc]      VARCHAR (255) NULL,
    [BusinessClassCode]       SMALLINT      NOT NULL,
    [BusinessClassDesc]       VARCHAR (60)  NULL,
    [ModifiedOn]              DATETIME2 (7) NULL
)
WITH (CLUSTERED INDEX([COPA_BillTypeBusClassID]), DISTRIBUTION = REPLICATE);

