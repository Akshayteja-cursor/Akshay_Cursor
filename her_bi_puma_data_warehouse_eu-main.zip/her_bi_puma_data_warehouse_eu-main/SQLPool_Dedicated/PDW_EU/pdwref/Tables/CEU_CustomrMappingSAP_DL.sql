﻿CREATE TABLE [pdwref].[CEU_CustomrMappingSAP_DL] (
    [NatCustomer_BK]         NVARCHAR (30)  NULL,
    [Legacy Customer Number] NVARCHAR (100) NULL,
    [Sold-To Number]         NVARCHAR (30)  NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

