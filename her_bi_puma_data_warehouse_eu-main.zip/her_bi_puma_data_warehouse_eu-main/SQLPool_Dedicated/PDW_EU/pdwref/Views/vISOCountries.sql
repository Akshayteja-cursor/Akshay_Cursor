﻿CREATE VIEW [pdwref].[vISOCountries]
AS SELECT  [ISOCountryCode]
      ,[ISOCountryCode3]
      ,[ISOCountryNo]
      ,[ISOCountryDesc]
      ,[ISRMarketCode]
      ,[ISRMarketDesc]
      ,[ISRSubMarketCode]
      ,[ISRSubMarketDesc]
      ,[ISRMarketRegionCode]
      ,[ISRMarketRegionDesc]
	  ,getdate() as Date
  FROM [pdwref].[ISOCountries];