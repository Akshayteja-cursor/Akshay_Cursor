﻿CREATE VIEW [pdwref].[vS4Hana_SalesTypes] AS SELECT 
	st.EBPDesc
	,st.IntSalesType
	,st.SoTypeCode
	,st.isfinanceooh
	, case when st.SOTypeCode in ('ZRET','ZCRR','ZPCR','ZRAU') then -1 else 1 end as  OperatorSwitch
	FROM pdwref.S4Hana_SalesTypes st
	WHERE (st.IntSalesType <> 3 OR st.SOTypeCode in ('ZRET','ZCRR','ZPCR','ZRAU'));