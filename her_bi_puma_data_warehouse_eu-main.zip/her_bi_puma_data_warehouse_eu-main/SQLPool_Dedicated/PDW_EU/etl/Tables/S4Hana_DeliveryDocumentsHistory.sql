﻿CREATE TABLE [etl].[S4Hana_DeliveryDocumentsHistory] (
    [DeliveryNoteNumber]      NVARCHAR (10) NOT NULL,
    [LDTS]                    DATETIME2 (7) NULL,
    [LEDTS]                   DATETIME2 (7) NULL,
    [HashDiff]                BINARY (16)   NULL,
    [NatSalesOrderNo]         NVARCHAR (10) NULL,
    [ActualGoodsMovementDate] DATE          NULL,
    [OverallBillingStatus]    NVARCHAR (1)  NULL,
    [IsDeleted]               TINYINT       NULL,
    [SourceIdentifier]        TINYINT       NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX ORDER([LDTS]), DISTRIBUTION = HASH([NatSalesOrderNo]));

