﻿CREATE TABLE [etl].[S4Hana_CustomerBusinessPartner] (
    [CustomerNo]             NVARCHAR (10)   NULL,
    [LDTS]                   DATETIME2 (7)   NULL,
    [SalesManagerCode]       NVARCHAR (500)  NULL,
    [SalesManagerName]       NVARCHAR (500)  NULL,
    [SalesAreaManagerCode]   NVARCHAR (500)  NULL,
    [SalesAreaManagerName]   NVARCHAR (500)  NULL,
    [CustomerServiceRepCode] NVARCHAR (1000) NULL,
    [CustomerServiceRepName] NVARCHAR (1000) NULL,
    [ID]                     INT             IDENTITY (1, 1) NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

