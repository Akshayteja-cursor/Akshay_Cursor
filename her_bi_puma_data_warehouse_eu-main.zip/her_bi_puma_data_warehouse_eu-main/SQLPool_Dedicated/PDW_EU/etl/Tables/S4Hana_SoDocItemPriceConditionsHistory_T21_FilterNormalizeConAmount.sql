﻿CREATE TABLE [etl].[S4Hana_SoDocItemPriceConditionsHistory_T21_FilterNormalizeConAmount] (
    [NatSalesOrderNo]         NVARCHAR (10)    NULL,
    [NatSalesOrderItemNo]     NVARCHAR (6)     NULL,
    [PricingDocument]         NVARCHAR (10)    NOT NULL,
    [PricingDocumentItem]     NVARCHAR (6)     NOT NULL,
    [PricingProcedureStep]    NVARCHAR (3)     NOT NULL,
    [PricingProcedureCounter] NVARCHAR (3)     NOT NULL,
    [ConditionTypeCode]       NVARCHAR (4)     NULL,
    [PreviewsLDTS]            DATETIME2 (7)    NULL,
    [LDTS]                    DATETIME2 (7)    NULL,
    [ConditionAmount]         DECIMAL (38, 25) NULL,
    [rn]                      BIGINT           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX ORDER([LDTS]), DISTRIBUTION = HASH([NatSalesOrderNo]));

