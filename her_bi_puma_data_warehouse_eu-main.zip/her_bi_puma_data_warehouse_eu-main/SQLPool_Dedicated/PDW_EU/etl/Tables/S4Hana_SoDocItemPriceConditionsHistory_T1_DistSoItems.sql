﻿CREATE TABLE [etl].[S4Hana_SoDocItemPriceConditionsHistory_T1_DistSoItems] (
    [NatSalesOrderNo]     NVARCHAR (10) NULL,
    [NatSalesOrderItemNo] NVARCHAR (6)  NULL,
    [IsDeleted]           TINYINT       NULL,
    [LDTS]                DATETIME2 (7) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX ORDER([LDTS]), DISTRIBUTION = HASH([NatSalesOrderNo]));

