﻿CREATE TABLE [etl].[S4Hana_SoDocumentItemPriceConditionsHistory_T1_DistSoItem_onPrem] (
    [NatSalesOrderNo]     NVARCHAR (10) NULL,
    [NatSalesOrderItemNo] NVARCHAR (6)  NULL,
    [LDTS]                DATETIME2 (0) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX ORDER([LDTS]), DISTRIBUTION = HASH([NatSalesOrderNo]));

