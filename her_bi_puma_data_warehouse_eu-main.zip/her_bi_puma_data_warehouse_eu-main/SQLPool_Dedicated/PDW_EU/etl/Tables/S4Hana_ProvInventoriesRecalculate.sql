﻿CREATE TABLE [etl].[S4Hana_ProvInventoriesRecalculate] (
    [HASH_BK]                     BINARY (16)      NOT NULL,
    [AggInventoryMovements_HASH]  BINARY (16)      NOT NULL,
    [AggInventoryValuations_HASH] BINARY (16)      NULL,
    [AggInventoryTypes_HASH]      BINARY (16)      NULL,
    [HASH_Diff]                   BINARY (16)      NULL,
    [COMPANYCODE]                 NVARCHAR (4)     NULL,
    [PLANT]                       NVARCHAR (4)     NULL,
    [MATERIAL]                    NVARCHAR (40)    NULL,
    [STORAGELOCATION]             NVARCHAR (4)     NULL,
    [STOCKSEGMENT]                NVARCHAR (40)    NULL,
    [BATCHID]                     NVARCHAR (10)    NULL,
    [QTYTYPE]                     NVARCHAR (128)   NULL,
    [MATERIALBASEUNIT]            NVARCHAR (3)     NULL,
    [QTY]                         DECIMAL (31, 14) NULL,
    [PRICE]                       DECIMAL (17, 2)  NULL,
    [PRICECURRENCY]               NVARCHAR (5)     NULL,
    [VALIDFROMDAT]                DATE             NULL,
    [VALIDTODAT]                  DATE             NULL,
    [POSTINGDATE]                 DATE             NULL,
    [INSERTTYPE]                  INT              NULL,
    [ModifiedOn]                  DATETIME2 (7)    NULL,
    [SPECIALSTOCKINDICATOR]       NVARCHAR (1)     NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = HASH([MATERIAL]));

