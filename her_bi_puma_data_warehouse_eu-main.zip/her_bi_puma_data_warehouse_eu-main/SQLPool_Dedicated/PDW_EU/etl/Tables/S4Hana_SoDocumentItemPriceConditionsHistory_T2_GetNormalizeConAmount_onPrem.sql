﻿CREATE TABLE [etl].[S4Hana_SoDocumentItemPriceConditionsHistory_T2_GetNormalizeConAmount_onPrem] (
    [NatSalesorderNo]         NVARCHAR (10)    NULL,
    [NatSalesOrderItemNo]     NVARCHAR (6)     NULL,
    [PricingProcedureStep]    NVARCHAR (6)     NULL,
    [PricingProcedureCounter] NVARCHAR (3)     NULL,
    [ConditionTypeCode]       NVARCHAR (4)     NULL,
    [LDTS]                    DATETIME2 (0)    NULL,
    [ConditionAmount]         NUMERIC (34, 19) NULL,
    [rn_PerLdts]              BIGINT           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX ORDER([LDTS]), DISTRIBUTION = HASH([NatSalesorderNo]));

