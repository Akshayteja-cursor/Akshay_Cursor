﻿CREATE TABLE [etl].[S4Hana_SoDocumentsPartners] (
    [SalesDocument]     NVARCHAR (10) NOT NULL,
    [SalesDocumentItem] NVARCHAR (6)  NOT NULL,
    [PartnerFunction]   NVARCHAR (2)  NULL,
    [PartnerNo]         NVARCHAR (20) NOT NULL,
    [LDTS]              DATETIME2 (7) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);



