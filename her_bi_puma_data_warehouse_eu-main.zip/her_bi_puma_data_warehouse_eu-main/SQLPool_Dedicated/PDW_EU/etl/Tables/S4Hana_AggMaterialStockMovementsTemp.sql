﻿CREATE TABLE [etl].[S4Hana_AggMaterialStockMovementsTemp] (
    [AggInventoryMovements_HASHUnique] BINARY (16)      NOT NULL,
    [KEY1]                             BINARY (4)       NULL,
    [KEY2]                             BINARY (4)       NULL,
    [KEY3]                             BINARY (5)       NULL,
    [KEY4]                             BINARY (1)       NULL,
    [KEY5]                             BINARY (1)       NULL,
    [KEY6]                             BINARY (1)       NULL,
    [COMPANYCODE]                      NVARCHAR (4)     NULL,
    [MATERIAL]                         NVARCHAR (40)    NULL,
    [PLANT]                            NVARCHAR (4)     NULL,
    [STORAGELOCATION]                  NVARCHAR (4)     NULL,
    [STOCKSEGMENT]                     NVARCHAR (40)    NULL,
    [ISSGORRCVGSTOCKSEGMENT]           NVARCHAR (40)    NULL,
    [STOCKIDENTIFYINGBATCH]            NVARCHAR (10)    NULL,
    [MATERIALBASEUNIT]                 NVARCHAR (3)     NULL,
    [POSTINGDATE]                      DATE             NULL,
    [INVENTORYSTOCKTYPE]               NVARCHAR (2)     NULL,
    [MATLSTKCHANGEQTYINBASEUNIT]       NUMERIC (31, 14) NULL,
    [MATERIALDOCUMENT]                 NVARCHAR (10)    NULL,
    [LASTCHANGEDON]                    DATE             NULL,
    [INVENTORYSPECIALSTOCKTYPE]        NVARCHAR (1)     NULL,
    [SPECIALSTOCKIDFGCUSTOMER]         NVARCHAR (10)    NULL,
    [__operation_type]                 NVARCHAR (1)     NULL,
    [_LDTS]                            DATETIME         NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = HASH([MATERIAL]));

