﻿CREATE TABLE [etl].[S4Hana_CustomerSalesPartners] (
    [CustomerNo]     NVARCHAR (10) NULL,
    [LDTS]           DATETIME2 (7) NULL,
    [SalesmanCode]   NVARCHAR (10) NULL,
    [SalesmanName]   NVARCHAR (80) NULL,
    [PayerCode]      NVARCHAR (10) NULL,
    [PayerName]      NVARCHAR (35) NULL,
    [OwnerGroupCode] NVARCHAR (10) NULL,
    [OwnerGroupName] NVARCHAR (80) NULL,
    [SalesOrgCode]   NVARCHAR (4)  NULL,
    [ID]             INT           IDENTITY (1, 1) NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);



