﻿CREATE TABLE [etl].[S4Hana_SoDocItemPriceConditionDeletions] (
    [PricingDocument]         NVARCHAR (10) NOT NULL,
    [PricingDocumentItem]     NVARCHAR (6)  NOT NULL,
    [PricingProcedureStep]    NVARCHAR (3)  NOT NULL,
    [PricingProcedureCounter] NVARCHAR (3)  NOT NULL,
    [LDTS]                    DATETIME2 (7) NULL,
    [LEDTS]                   DATETIME2 (7) NULL,
    [__timestamp]             BIGINT        NULL,
    [HashDiff]                BINARY (16)   NULL,
    [NatSalesOrderNo]         NVARCHAR (10) NULL,
    [NatSalesOrderItemNo]     NVARCHAR (6)  NULL,
    [ConditionTypeCode]       NVARCHAR (4)  NULL,
    [IsDeleted]               TINYINT       NULL,
    [SourceIdentifier]        TINYINT       NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX ORDER([LDTS]), DISTRIBUTION = HASH([NatSalesOrderNo]));

