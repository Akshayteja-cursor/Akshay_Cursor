﻿CREATE TABLE [etl].[DataTransferLogs] (
    [DataTransferLogId]       UNIQUEIDENTIFIER NOT NULL,
    [TransferName]            NVARCHAR (100)   NULL,
    [TransferGroupName]       NVARCHAR (100)   NULL,
    [TargetTableName]         NVARCHAR (100)   NULL,
    [TargetSchemaName]        NVARCHAR (100)   NULL,
    [ExecStart]               DATETIME2 (0)    NULL,
    [ExecEnd]                 DATETIME2 (0)    NULL,
    [SourceLastLoadDate]      DATETIME2 (0)    NULL,
    [DestinationLastLoadDate] DATETIME2 (0)    NULL,
    [BatchLdts]               DATETIME2 (0)    NULL,
    [Inserted]                BIGINT           NULL,
    [Updated]                 BIGINT           NULL,
    [Deleted]                 BIGINT           NULL
)
WITH (HEAP, DISTRIBUTION = REPLICATE);

