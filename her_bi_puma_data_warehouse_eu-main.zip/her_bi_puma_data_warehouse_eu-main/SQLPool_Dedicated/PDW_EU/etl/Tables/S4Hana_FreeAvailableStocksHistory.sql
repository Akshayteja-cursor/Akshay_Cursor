﻿CREATE TABLE [etl].[S4Hana_FreeAvailableStocksHistory] (
    [Plant]              NVARCHAR (4)    NOT NULL,
    [Material]           NVARCHAR (40)   NOT NULL,
    [StockSegment]       NVARCHAR (40)   NOT NULL,
    [PostingDate]        DATE            NULL,
    [PostingDateValidTo] DATE            NULL,
    [MRPElement]         NVARCHAR (2)    NULL,
    [RunningTotal]       DECIMAL (15, 3) NULL,
    [BaseUnitOfMeasure]  NVARCHAR (3)    NULL,
    [HashDiff]           BINARY (16)     NULL,
    [LDTS]               DATETIME2 (7)   NULL,
    [SourceIdentifier]   TINYINT         NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

