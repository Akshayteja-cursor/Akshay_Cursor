﻿CREATE TABLE [etl].[LdtsProcessingLog] (
    [ProcessingDate] DATETIME      NULL,
    [ObjectName]     VARCHAR (255) NULL,
    [ProvidedLdts]   DATETIME2 (7) NULL,
    [ProcessedLdts]  DATETIME2 (7) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

