﻿CREATE TABLE [etl].[S4Hana_MasterCodesCustomers] (
    [Code]        NVARCHAR (10) NOT NULL,
    [Group]       NVARCHAR (50) NOT NULL,
    [LDTS]        DATETIME      NOT NULL,
    [Description] NVARCHAR (50) NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

