﻿CREATE PROC [etl].[S4Hana_spCustomerSalesPartners] AS

BEGIN

--TRUNCATE ETL TABLE
TRUNCATE TABLE etl.S4Hana_CustomerSalesPartners;

WITH CTE_CustomerSalesPartners AS
(
	SELECT 
	  A.CustomerNumber
	, A.PartnerNo
	, COALESCE(B.OrganizationBPName1, A.PartnerName) AS PartnerName
	, A.PartnerFunction
	, A.DefaultPartner
	, A.PartnerCounter
	, A.LDTS
	, A.SalesOrgCode
	, A.IsDeleted
	FROM stag.S4Hana_vCustomerSalesPartners A
	LEFT JOIN stag.S4Hana_vCustomers B ON A.PartnerNo = B.CustomerCode
)
, CTE_SalesMen AS
(
	SELECT 
	  A.CustomerNumber										AS CustomerNo
	, A.PartnerNo											AS SalesmanCode
	, A.PartnerName											AS SalesmanName
	, A.PartnerFunction										AS PartnerFunction
	, A.DefaultPartner										AS DefaultPartner
	, A.PartnerCounter										AS PartnerCounter
	, A.LDTS												AS LDTS
	, A.SalesOrgCode
	, ROW_NUMBER() OVER (PARTITION BY A.CustomerNumber
									, A.PartnerFunction
									, A.SalesOrgCode
							ORDER BY A.DefaultPartner DESC
								   , A.PartnerCounter DESC)	AS RN
	FROM CTE_CustomerSalesPartners A
	WHERE A.IsDeleted = 0
		AND A.PartnerFunction = 'AD'
)
, CTE_Payer AS
(
	SELECT 
	  A.CustomerNumber										AS CustomerNo
	, A.PartnerNo											AS PayerCode
	, A.PartnerName											AS PayerName
	, A.PartnerFunction										AS PartnerFunction
	, A.DefaultPartner										AS DefaultPartner
	, A.PartnerCounter										AS PartnerCounter
	, A.LDTS												AS LDTS
	, A.SalesOrgCode
	, ROW_NUMBER() OVER (PARTITION BY A.CustomerNumber
									, A.PartnerFunction
									, A.SalesOrgCode
							ORDER BY A.DefaultPartner DESC
								   , A.PartnerCounter DESC)	AS RN
	FROM CTE_CustomerSalesPartners A
	WHERE A.IsDeleted = 0
		AND A.PartnerFunction = 'RG'
)
, CTE_OwnerGroup AS
(
	SELECT 
	  A.CustomerNumber										AS CustomerNo
	, A.PartnerNo											AS OwnerGroupCode
	, A.PartnerName											AS OwnerGroupName
	, A.PartnerFunction										AS PartnerFunction
	, A.DefaultPartner										AS DefaultPartner
	, A.PartnerCounter										AS PartnerCounter
	, A.LDTS												AS LDTS
	, A.SalesOrgCode
	, ROW_NUMBER() OVER (PARTITION BY A.CustomerNumber
									, A.PartnerFunction
									, A.SalesOrgCode
							ORDER BY A.DefaultPartner DESC
								   , A.PartnerCounter DESC)	AS RN
	FROM CTE_CustomerSalesPartners A
	WHERE A.IsDeleted = 0
		AND A.PartnerFunction = 'ZW'
)

, CTE_Union_CustomerNo AS
(
	SELECT 
	  CustomerNo
	, LDTS
	, SalesOrgCode
	FROM CTE_SalesMen
	WHERE RN = 1
	UNION 
	SELECT 
	  CustomerNo
	, LDTS
	, SalesOrgCode
	FROM CTE_Payer
	WHERE RN = 1
	UNION 
	SELECT 
	  CustomerNo
	, LDTS
	, SalesOrgCode
	FROM CTE_OwnerGroup
	WHERE RN = 1
)
, CTE_MAX_CustomerNo AS
(
	SELECT 
	  CustomerNo	AS CustomerNo
	, MAX(LDTS)		AS LDTS
	, SalesOrgCode
	FROM CTE_Union_CustomerNo
	GROUP BY CustomerNo , SalesOrgCode
)
--Load ETL Table
INSERT INTO etl.S4Hana_CustomerSalesPartners
(
  CustomerNo
, LDTS
, SalesmanCode
, SalesmanName
, PayerCode
, PayerName
, OwnerGroupCode
, OwnerGroupName
, SalesOrgCode
)
SELECT 
  A.CustomerNo
, A.LDTS
, B.SalesmanCode
, B.SalesmanName
, C.PayerCode
, C.PayerName
, D.OwnerGroupCode
, D.OwnerGroupName
, A.SalesOrgCode
FROM CTE_MAX_CustomerNo A
LEFT JOIN CTE_SalesMen B ON A.CustomerNo = B.CustomerNo and A.SalesOrgCode = B.SalesOrgCode
	AND B.RN = 1
LEFT JOIN CTE_Payer C ON A.CustomerNo = C.CustomerNo and A.SalesOrgCode = C.SalesOrgCode
	AND C.RN = 1
LEFT JOIN CTE_OwnerGroup D ON A.CustomerNo = D.CustomerNo and A.SalesOrgCode = D.SalesOrgCode 
	AND D.RN = 1
--ORDER BY 1

END