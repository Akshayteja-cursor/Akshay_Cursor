﻿CREATE PROC [etl].[S4Hana_spCustomerBusinessPartner] AS

BEGIN

--TRUNCATE ETL TABLE
TRUNCATE TABLE etl.S4Hana_CustomerBusinessPartner;

WITH CTE_CustomerBusinessPartner AS
(
	SELECT
	  cbp.CustomerNo
	, cbp.PartnerNumber
	, RTRIM(LTRIM(CASE WHEN SearchHelp1 = SearchHelp2 THEN SearchHelp1 ELSE CONCAT(SearchHelp1,' ',SearchHelp2)	END)) as PartnerName
	, bpgd._LDTS as LDTS
	, cbp.IsDeleted
	, cbp.PartnerFunction
	, cbp.ValidityDate
	, COALESCE(bpgd.BPCentralBlk, '') BPCentralBlk
	, COALESCE(bpgd.FlagArchive, '') FlagArchive
FROM stag.S4Hana_vCustomerBusinessPartner cbp
LEFT JOIN stag.S4Hana_vBPGeneralData1 bpgd ON cbp.PartnerNumber = bpgd.BusinessPartner
),
CTE_SalesManager AS
(
	SELECT 
	  CustomerNo			AS CustomerNo
	, PartnerNumber			AS SalesManagerCode
	, PartnerName		    AS SalesManagerName
	, MAX(LDTS)				AS LDTS
	FROM CTE_CustomerBusinessPartner
	WHERE IsDeleted = 0
	AND PartnerFunction = 'X001'
	AND year(ValidityDate) = '9999'
	GROUP BY CustomerNo, PartnerNumber, PartnerName
)
, CTE_SalesManager_Agg AS
(
	SELECT 
	  CustomerNo
	, LDTS
	, STRING_AGG(SalesManagerCode, ', ') WITHIN GROUP(ORDER BY CustomerNo, SalesManagerCode) SalesManagerCode
	, STRING_AGG(SalesManagerName, ', ') WITHIN GROUP(ORDER BY CustomerNo, SalesManagerCode) SalesManagerName
	FROM CTE_SalesManager
	GROUP BY CustomerNo, LDTS
)
, CTE_SalesAreaManager AS
(
	SELECT 
	  CustomerNo			AS CustomerNo
	, PartnerNumber			AS SalesAreaManagerCode
	, PartnerName       	AS SalesAreaManagerName
	, MAX(LDTS)				AS LDTS
	FROM CTE_CustomerBusinessPartner
	WHERE IsDeleted = 0
	AND PartnerFunction = 'X005'
	AND year(ValidityDate) = '9999'
	GROUP BY CustomerNo, PartnerNumber, PartnerName
)
, CTE_SalesAreaManager_Agg AS
(
	SELECT 
	  CustomerNo
	, MAX(LDTS) as LDTS
	, STRING_AGG(SalesAreaManagerCode, ', ') WITHIN GROUP(ORDER BY CustomerNo, SalesAreaManagerCode) SalesAreaManagerCode
	, STRING_AGG(SalesAreaManagerName, ', ') WITHIN GROUP(ORDER BY CustomerNo, SalesAreaManagerCode) SalesAreaManagerName
	FROM CTE_SalesAreaManager
	GROUP BY CustomerNo
)
, CTE_PurchasingManager AS
(
	SELECT 
	  CustomerNo			AS CustomerNo
	, PartnerNumber			AS CustomerServiceRepCode
	, PartnerName       	AS CustomerServiceRepName
	, MAX(LDTS)				AS LDTS
	FROM CTE_CustomerBusinessPartner
	WHERE IsDeleted = 0
	AND PartnerFunction = 'X002'
	AND year(ValidityDate) = '9999'
	GROUP BY CustomerNo, PartnerNumber, PartnerName
)
, CTE_PurchasingManager_Agg AS
(
	SELECT 
	  CustomerNo
	, LDTS
	, STRING_AGG(CustomerServiceRepCode, ', ') WITHIN GROUP(ORDER BY CustomerNo, CustomerServiceRepCode) CustomerServiceRepCode
	, STRING_AGG(CustomerServiceRepName, ', ') WITHIN GROUP(ORDER BY CustomerNo, CustomerServiceRepCode) CustomerServiceRepName
	FROM CTE_PurchasingManager
	GROUP BY CustomerNo, LDTS
)
, CTE_Union_CustomerNo AS
(
	SELECT 
	  CustomerNo
	, LDTS
	FROM CTE_SalesAreaManager_Agg
	UNION 
	SELECT 
	  CustomerNo
	, LDTS
	FROM CTE_SalesManager_Agg
	UNION 
	SELECT 
	  CustomerNo
	, LDTS
	FROM CTE_PurchasingManager_Agg
)
, CTE_MAX_CustomerNo AS
(
	SELECT 
	  CustomerNo	AS CustomerNo
	, MAX(LDTS)		AS LDTS
	FROM CTE_Union_CustomerNo
	GROUP BY CustomerNo
	--ORDER BY 1
)

--Load ETL Table
INSERT INTO etl.S4Hana_CustomerBusinessPartner
(
  CustomerNo
, LDTS
, SalesManagerCode
, SalesManagerName
, SalesAreaManagerCode
, SalesAreaManagerName
, CustomerServiceRepCode
, CustomerServiceRepName
)
SELECT
  A.CustomerNo
, A.LDTS
, B.SalesManagerCode
, B.SalesManagerName
, C.SalesAreaManagerCode
, C.SalesAreaManagerName
, D.CustomerServiceRepCode
, D.CustomerServiceRepName
FROM CTE_MAX_CustomerNo A
LEFT JOIN CTE_SalesManager_Agg B ON A.CustomerNo = B.CustomerNo
LEFT JOIN CTE_SalesAreaManager_Agg C ON A.CustomerNo = C.CustomerNo
LEFT JOIN CTE_PurchasingManager_Agg D ON A.CustomerNo = D.CustomerNo
--ORDER BY 1

END
