﻿CREATE PROC [etl].[S4Hana_spMasterCodesCustomers] AS 


TRUNCATE TABLE etl.S4Hana_MasterCodesCustomers;

WITH CTE_MasterCodesCustomers AS 
(
	SELECT 
	  Code
	, 'SalesOrganizaton' AS [Group]	
	, [Description]
	, LDTS
	FROM stag.S4Hana_vSalesOrganizationTexts
	WHERE [Language] = 'EN'
	UNION
	SELECT
	  Code
	, 'AccountTexts' AS [Group]	
	, [Description]
	, LDTS
	FROM stag.S4Hana_vCustomerAccountTexts
	--AccountRoleText removed not used in on-prem
	UNION
	SELECT
	  Code
	, 'PUMADistributionChannelTexts' AS [Group]	
	, [Description]
	, LDTS
	FROM stag.S4Hana_vPUMADistributionChannelTexts
	--AreaAccountTexts removed not used in on-prem
	--CustomerStructureTexts removed not used in on-prem
	UNION
	SELECT
	  Code
	, 'MainCustomerTexts' AS [Group]	
	, [Description]
	, LDTS
	FROM stag.S4Hana_vMainCustomerTexts
	UNION
	SELECT
	  Code
	, 'MasterCustomerTexts' AS [Group]	
	, [Description]
	, LDTS
	FROM stag.S4Hana_vMasterCustomerTexts
	UNION
	SELECT
	  Code
	, 'ReportingGroup10Texts' AS [Group]	
	, [Description]
	, LDTS
	FROM stag.S4Hana_vReportingGroup10Texts
	UNION
	--CustomerGroupTexts needs to be recheck when we received it from SAP DI
	SELECT
	  Code
	, 'CustomerGroupTexts' AS [Group]	
	, [Description]
	, LDTS
	FROM stag.S4Hana_vCustomerGroupTexts
	WHERE [Language] = 'EN'
	UNION
	SELECT
	  Code
	, 'BuyingGroupTexts' AS [Group]	
	, [Description]
	, LDTS
	FROM stag.S4Hana_vBuyingGroupTexts
	UNION
	SELECT
	  Code
	, 'CustomerAccountTexts' AS [Group]	
	, [Description]
	, LDTS
	FROM stag.S4Hana_vCustomerAccountTexts
)

INSERT INTO etl.S4Hana_MasterCodesCustomers 
(
  Code
, [Group]
, [Description]
, LDTS
)
SELECT 
  Code
, [Group]
, [Description]
, LDTS
FROM CTE_MasterCodesCustomers