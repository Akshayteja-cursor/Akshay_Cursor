﻿CREATE PROC [etl].[S4Hana_spSoDocumentItemPriceConditionsHistIncrement] @LDTS [DATETIME] AS
BEGIN
SET NOCOUNT ON
 
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(0) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(0)
DECLARE @DestinationLastLoadDate DATETIME2(0)
DECLARE @BatchLdts DATETIME2(0) = @LDTS

-- do not use the input parameter, in case of an failur or reload situartion take the last tranfered LDTS from the Hist table
IF(EXISTS(SELECT 1 FROM etl.S4Hana_SoDocumentItemPriceConditionsHistPre))
BEGIN
	SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(LDTS))
	FROM etl.S4Hana_SoDocumentItemPriceConditionsHistPre
END
ELSE BEGIN
	SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
END 

IF(EXISTS(SELECT 1 FROM stag.s4hana_SOPricingConditions_Full))
BEGIN
	SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(_LDTS))
	FROM stag.s4hana_SOPricingConditions_Full
END
ELSE BEGIN
	SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
END 

--Log Data load
INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'spSoDocumentItemPriceConditionsHistIncrement'
			,'prepSoDocHist'
			,'NatSalesOrdersOohHistory'
			,'sales'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts

TRUNCATE Table etl.S4Hana_SoDocumentItemPriceConditionsHistPre_T1_DistSoItem  -- temp peristing table 

INSERT INTO etl.S4Hana_SoDocumentItemPriceConditionsHistPre_T1_DistSoItem
 (SalesOrderNo
 ,SalesOrderItemNo
 ,LDTS)
 SELECT DISTINCT 
     CONVERT(NVARCHAR(10),sopStagFull.VBELN) AS SalesOrderNo
    ,CONVERT(NVARCHAR(6),sopStagFull.POSNR) AS SalesOrderItemNo
    ,CONVERT(DateTime2(0),sopStagFull._LDTS) AS LDTS
FROM stag.s4hana_SOPricingConditions_Full  AS sopStagFull 
INNER JOIN stag.S4Hana_vSalesOrgToCompanyCode AS sct -- filter not SE relevant orders out
	ON sopStagFull.BUKRS = sct.CompanyCode
WHERE 1=1
    AND (sopStagFull.ODQ_CHANGEMODE <> 'D' OR sopStagFull.ODQ_CHANGEMODE IS NULL)
	AND sopStagFull._LDTS > @DestinationLastLoadDate 
 

 IF OBJECT_ID('tempdb..#SoPriceConditionsDistSoItemLastBatchWithOutLDTS') IS NOT NULL
BEGIN
    DROP TABLE #SoPriceConditionsDistSoItemLastBatchWithOutLDTS
END

CREATE TABLE #SoPriceConditionsDistSoItemLastBatchWithOutLDTS --> get all entires from the past to this SO / SOItem
WITH
(DISTRIBUTION = HASH(SalesOrderNo)
,HEAP)
AS(	SELECT DISTINCT
		 SalesOrderNo
		,SalesOrderItemNo
	FROM etl.S4Hana_SoDocumentItemPriceConditionsHistPre_T1_DistSoItem 
)

TRUNCATE TABLE  etl.S4Hana_SoDocumentItemPriceConditionsHistPre_T2_GetNormalizeConAmount -- temp peristing table 

INSERT INTO etl.S4Hana_SoDocumentItemPriceConditionsHistPre_T2_GetNormalizeConAmount -- temp peristing table 
( 	SalesorderNo
    ,SalesOrderItemNo
    ,PricingProcedureStep
    ,PricingProcedureCounter
    ,ConditionTypeCode
    ,LDTS
    ,ConditionAmount
    ,rn_PerLdts)
SELECT 
     CONVERT(NVARCHAR(10),sopStagFull.VBELN) AS SalesorderNo
    ,CONVERT(NVARCHAR(6),sopStagFull.POSNR) AS SalesOrderItemNo
    ,CONVERT(NVARCHAR(6),sopStagFull.STUNR) AS PricingProcedureStep
    ,CONVERT(NVARCHAR(3),sopStagFull.ZAEHK) AS PricingProcedureCounter
    ,CONVERT(NVARCHAR(4),sopStagFull.KSCHL) AS ConditionTypeCode
    ,CONVERT(DateTime2(0),sopStagFull._LDTS) AS LDTS
    ,CONVERT(NUMERIC(15,3),sopStagFull.KWERT) / 
                    CASE WHEN etlAggSoi.OrderQuantity = 0 THEN 1 
                        ELSE CONVERT(NUMERIC(15,3),etlAggSoi.OrderQuantity) 
        END AS ConditionAmount
    ,ROW_NUMBER() OVER (PARTITION BY sopStagFull.VBELN, sopStagFull.POSNR, sopStagFull.STUNR, sopStagFull.ZAEHK, sopStagFull._LDTS ORDER BY sopStagFull.TS_SEQUENCE_NUMBER DESC) AS rn_PerLdts 
FROM stag.s4hana_SOPricingConditions_Full AS sopStagFull
INNER JOIN #SoPriceConditionsDistSoItemLastBatchWithOutLDTS AS soSoItem  -- Filter just enties from this batch (LDTS)
	ON CONVERT(NVARCHAR(10),sopStagFull.VBELN)  = soSoItem.SalesorderNo 
    AND CONVERT(NVARCHAR(6),sopStagFull.POSNR)  = soSoItem.SalesOrderItemNo
INNER JOIN etl.s4hana_SoDocumentItemQtysHistPre AS etlAggSoi
    ON CONVERT(NVARCHAR(10),sopStagFull.VBELN)  = etlAggSoi.SalesorderNo 
    AND CONVERT(NVARCHAR(6),sopStagFull.POSNR)  = etlAggSoi.SalesOrderItemNo
    AND CONVERT(DateTime2(0),sopStagFull._LDTS) BETWEEN etlAggSoi.LDTS AND etlAggSoi.LEDTS
INNER JOIN stag.S4Hana_vSalesOrgToCompanyCode AS sct -- filter not SE relevant orders out
	ON sopStagFull.BUKRS = sct.CompanyCode
WHERE 1=1
	AND (sopStagFull.ODQ_CHANGEMODE <> 'D' OR sopStagFull.ODQ_CHANGEMODE IS NULL)  

Truncate table etl.S4Hana_SoDocumentItemPriceConditionsHistPre_T3_ExtendLdtsPreValues

INSERT INTO etl.S4Hana_SoDocumentItemPriceConditionsHistPre_T3_ExtendLdtsPreValues
(
 SalesorderNo
,SalesOrderItemNo
,PricingProcedureStep
,PricingProcedureCounter
,ConditionTypeCode
,PreviewsLDTS
,LDTS
,ConditionAmount
,rn
)
SELECT sopNorm.SalesorderNo
      ,sopNorm.SalesOrderItemNo
      ,sopNorm.PricingProcedureStep
      ,sopNorm.PricingProcedureCounter
      ,sopNorm.ConditionTypeCode
      ,sopNorm.LDTS AS PreviewsLDTS
      ,distSoPrLdts.LDTS -- artificial entrie for the last value for this LDTS
      ,sopNorm.ConditionAmount
      ,ROW_NUMBER() OVER (PARTITION BY sopNorm.SalesorderNo, sopNorm.SalesOrderItemNo, sopNorm.ConditionTypeCode, sopNorm.PricingProcedureCounter, sopNorm.PricingProcedureCounter, distSoPrLdts.LDTS ORDER BY sopNorm.LDTS DESC) AS rn
FROM etl.S4Hana_SoDocumentItemPriceConditionsHistPre_T1_DistSoItem AS distSoPrLdts
INNER JOIN etl.S4Hana_SoDocumentItemPriceConditionsHistPre_T2_GetNormalizeConAmount AS sopNorm 
    ON distSoPrLdts.SalesorderNo = sopNorm.SalesorderNo
    AND distSoPrLdts.SalesOrderItemNo = sopNorm.SalesOrderItemNo
    AND distSoPrLdts.LDTS > sopNorm.LDTS 
WHERE sopNorm.rn_PerLdts = 1 -- only the last entry per Batch
    AND NOT EXISTS ( -- Filter the related Pricing Conditions for this batch out
        SELECT 1
        FROM etl.S4Hana_SoDocumentItemPriceConditionsHistPre_T2_GetNormalizeConAmount AS LdtsEntry
        WHERE sopNorm.SalesorderNo = LdtsEntry.SalesorderNo
          AND sopNorm.SalesOrderItemNo = LdtsEntry.SalesOrderItemNo
          AND sopNorm.ConditionTypeCode = LdtsEntry.ConditionTypeCode
          AND sopNorm.PricingProcedureCounter = LdtsEntry.PricingProcedureCounter
          AND distSoPrLdts.LDTS = LdtsEntry.LDTS
          )

INSERT INTO etl.S4Hana_SoDocumentItemPriceConditionsHistPre_T3_ExtendLdtsPreValues
(
 SalesorderNo
,SalesOrderItemNo
,PricingProcedureStep
,PricingProcedureCounter
,ConditionTypeCode
,PreviewsLDTS
,LDTS
,ConditionAmount
,rn
)
SELECT sopNorm.SalesorderNo
      ,sopNorm.SalesOrderItemNo
      ,sopNorm.PricingProcedureStep
      ,sopNorm.PricingProcedureCounter
      ,sopNorm.ConditionTypeCode
      ,sopNorm.LDTS AS PreviewsLDTS
      ,sopNorm.LDTS -- LDTS keep the same because there is an orig value at this LDTS (Batch)
      ,sopNorm.ConditionAmount
      ,CONVERT(INT, 1) AS rn
FROM etl.S4Hana_SoDocumentItemPriceConditionsHistPre_T2_GetNormalizeConAmount AS sopNorm
WHERE sopNorm.rn_PerLdts = 1 -- only the last entry per Batch

TRUNCATE TABLE etl.S4Hana_SoDocumentItemPriceConditionsHistPre_T4_PivotIncrement

INSERT INTO etl.S4Hana_SoDocumentItemPriceConditionsHistPre_T4_PivotIncrement
      (SalesorderNo
      ,SalesOrderItemNo
      ,LDTS
	  ,HashDiff
      ,DIFF ,GRWR ,MWST ,PNTP ,VPRS ,ZACC ,ZAFG ,ZART ,ZB2B ,ZBOL ,ZCC1 ,ZCCE ,ZCIT ,ZCO1 ,ZCWD ,ZDIS ,ZDNP ,ZDVG ,ZEQU ,ZFMW ,ZFOC ,ZGS1 ,ZICV ,ZIDU ,[ZIF%] ,ZIFV ,ZIHF 
      ,ZIIN ,ZINM ,ZINV ,ZIUP ,ZLOG ,ZLSM ,ZMD0 ,ZMOV ,ZNEP ,ZOFF ,ZOPX ,ZORD ,ZOUT ,ZPAR ,ZPAY ,ZPR0 ,ZPRF ,ZRAC ,ZRAS ,ZRDI ,ZRMP ,ZRY1 ,ZRY2 ,ZSF1 ,ZSFP ,ZSPR ,ZSRD 
      ,ZSSC ,ZSSM, ZST1 ,ZSTS ,ZSWC ,ZVP1 ,ZVPR ,ZXDU ,[ZXF%] ,ZXFP ,ZXFV ,ZXHF ,ZXIN ,ZXRD ,ZXSC ,ZXSM ,ZXWC ,ZZCR ,ZZD1 ,ZZDR ,ZZP1 ,ZZSR ,ZERR ,ZDIF ,ZECR ,ZXCF ,ZECN 
      ,ZNRR ,ZBGD ,ZBUY ,ZCOC ,ZDIR ,ZEBD ,ZESC ,ZEXL ,ZFRH ,ZICF ,ZRY3 ,ZSIS ,ZVAS ,ZCOB ,ZNTS ,ZRRP ,ZDSB ,ZDSD ,ZDSN ,ZBD1 ,ZBD2 ,ZBD3 ,ZBD4 ,ZBD5 ,ZBD6 ,ZBD7 ,ZCOS
      ,SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist
	   )
SELECT SalesorderNo
    ,SalesOrderItemNo
    ,LDTS
    ,CONVERT(BINARY(16), 
        HASHBYTES('MD5',CONCAT( 
        UPPER(LTRIM(RTRIM(SalesOrderNo))),'_', 
        UPPER(LTRIM(RTRIM(SalesOrderItemNo))),'_', 
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),DIFF)))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),GRWR )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),MWST )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),PNTP )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),VPRS )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZACC )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZAFG )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZART )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZB2B )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZBOL )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZCC1 )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZCCE )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZCIT )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZCO1 )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZCWD )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZDIS )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZDNP )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZDVG )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZEQU )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZFMW )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZFOC )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZGS1 )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZICV )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZIDU )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),[ZIF%] )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZIFV )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZIHF )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZIIN )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZINM )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZINV )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZIUP )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZLOG )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZLSM )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZMD0 )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZMOV )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZNEP )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZOFF )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZOPX )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZORD )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZOUT )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZPAR )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZPAY )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZPR0 )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZPRF )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZRAC )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZRAS )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZRDI )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZRMP )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZRY1 )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZRY2 )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZSF1 )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZSFP )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZSPR )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZSRD )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZSSC )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZSSM )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZST1 )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZSTS )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZSWC )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZVP1 )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZVPR )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZXDU )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),[ZXF%] )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZXFP )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZXFV )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZXHF )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZXIN )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZXRD )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZXSC )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZXSM )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZXWC )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZZCR )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZZD1 )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZZDR )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZZP1 )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZZSR )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZERR )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZDIF )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZECR )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZXCF )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZECN )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZNRR )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZBGD )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZBUY )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZCOC )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZDIR )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZEBD )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZESC )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZEXL )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZFRH )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZICF )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZRY3 )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZSIS )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZVAS )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZCOB )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZNTS )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZRRP )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZDSB )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZDSD )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZDSN )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZBD1 )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZBD2 )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZBD3 )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZBD4 )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZBD5 )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZBD6 )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZBD7 )))),'_',
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZCOS ))))
      ))) AS HashDiff
	,DIFF ,GRWR ,MWST ,PNTP ,VPRS ,ZACC ,ZAFG ,ZART ,ZB2B ,ZBOL ,ZCC1 ,ZCCE ,ZCIT ,ZCO1 ,ZCWD ,ZDIS ,ZDNP ,ZDVG ,ZEQU ,ZFMW ,ZFOC ,ZGS1 ,ZICV ,ZIDU ,[ZIF%] ,ZIFV ,ZIHF 
    ,ZIIN ,ZINM ,ZINV ,ZIUP ,ZLOG ,ZLSM ,ZMD0 ,ZMOV ,ZNEP ,ZOFF ,ZOPX ,ZORD ,ZOUT ,ZPAR ,ZPAY ,ZPR0 ,ZPRF ,ZRAC ,ZRAS ,ZRDI ,ZRMP ,ZRY1 ,ZRY2 ,ZSF1 ,ZSFP ,ZSPR ,ZSRD 
    ,ZSSC ,ZSSM, ZST1 ,ZSTS ,ZSWC ,ZVP1 ,ZVPR ,ZXDU ,[ZXF%] ,ZXFP ,ZXFV ,ZXHF ,ZXIN ,ZXRD ,ZXSC ,ZXSM ,ZXWC ,ZZCR ,ZZD1 ,ZZDR ,ZZP1 ,ZZSR ,ZERR ,ZDIF ,ZECR ,ZXCF ,ZECN 
    ,ZNRR ,ZBGD ,ZBUY ,ZCOC ,ZDIR ,ZEBD ,ZESC ,ZEXL ,ZFRH ,ZICF ,ZRY3 ,ZSIS ,ZVAS ,ZCOB ,ZNTS ,ZRRP ,ZDSB ,ZDSD ,ZDSN ,ZBD1 ,ZBD2 ,ZBD3 ,ZBD4 ,ZBD5 ,ZBD6 ,ZBD7 ,ZCOS
	,CONVERT(TINYINT,1) AS SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist 
 FROM (
    SELECT SalesorderNo
          ,SalesOrderItemNo
          ,ConditionTypeCode
          ,LDTS
          ,ConditionAmount
        FROM etl.S4Hana_SoDocumentItemPriceConditionsHistPre_T3_ExtendLdtsPreValues
        WHERE RN = 1
        ) AS src 
    PIVOT(    
    SUM(ConditionAmount) 
    FOR ConditionTypeCode IN (
     DIFF ,GRWR ,MWST ,PNTP ,VPRS ,ZACC ,ZAFG ,ZART ,ZB2B ,ZBOL ,ZCC1 ,ZCCE ,ZCIT ,ZCO1 ,ZCWD ,ZDIS ,ZDNP ,ZDVG ,ZEQU ,ZFMW ,ZFOC ,ZGS1 ,ZICV ,ZIDU ,[ZIF%] ,ZIFV ,ZIHF 
    ,ZIIN ,ZINM ,ZINV ,ZIUP ,ZLOG ,ZLSM ,ZMD0 ,ZMOV ,ZNEP ,ZOFF ,ZOPX ,ZORD ,ZOUT ,ZPAR ,ZPAY ,ZPR0 ,ZPRF ,ZRAC ,ZRAS ,ZRDI ,ZRMP ,ZRY1 ,ZRY2 ,ZSF1 ,ZSFP ,ZSPR ,ZSRD 
    ,ZSSC ,ZSSM, ZST1 ,ZSTS ,ZSWC ,ZVP1 ,ZVPR ,ZXDU ,[ZXF%] ,ZXFP ,ZXFV ,ZXHF ,ZXIN ,ZXRD ,ZXSC ,ZXSM ,ZXWC ,ZZCR ,ZZD1 ,ZZDR ,ZZP1 ,ZZSR ,ZERR ,ZDIF ,ZECR ,ZXCF ,ZECN 
    ,ZNRR ,ZBGD ,ZBUY ,ZCOC ,ZDIR ,ZEBD ,ZESC ,ZEXL ,ZFRH ,ZICF ,ZRY3 ,ZSIS ,ZVAS ,ZCOB ,ZNTS ,ZRRP ,ZDSB ,ZDSD ,ZDSN ,ZBD1 ,ZBD2 ,ZBD3 ,ZBD4 ,ZBD5 ,ZBD6 ,ZBD7 ,ZCOS)
    ) pvt

-- Add last related entires from Hist which are in the new batch
INSERT INTO etl.S4Hana_SoDocumentItemPriceConditionsHistPre_T4_PivotIncrement
      (SalesorderNo
      ,SalesOrderItemNo
      ,LDTS
	  ,HashDiff
      ,DIFF ,GRWR ,MWST ,PNTP ,VPRS ,ZACC ,ZAFG ,ZART ,ZB2B ,ZBOL ,ZCC1 ,ZCCE ,ZCIT ,ZCO1 ,ZCWD ,ZDIS ,ZDNP ,ZDVG ,ZEQU ,ZFMW ,ZFOC ,ZGS1 ,ZICV ,ZIDU ,[ZIF%] ,ZIFV ,ZIHF 
      ,ZIIN ,ZINM ,ZINV ,ZIUP ,ZLOG ,ZLSM ,ZMD0 ,ZMOV ,ZNEP ,ZOFF ,ZOPX ,ZORD ,ZOUT ,ZPAR ,ZPAY ,ZPR0 ,ZPRF ,ZRAC ,ZRAS ,ZRDI ,ZRMP ,ZRY1 ,ZRY2 ,ZSF1 ,ZSFP ,ZSPR ,ZSRD 
      ,ZSSC ,ZSSM, ZST1 ,ZSTS ,ZSWC ,ZVP1 ,ZVPR ,ZXDU ,[ZXF%] ,ZXFP ,ZXFV ,ZXHF ,ZXIN ,ZXRD ,ZXSC ,ZXSM ,ZXWC ,ZZCR ,ZZD1 ,ZZDR ,ZZP1 ,ZZSR ,ZERR ,ZDIF ,ZECR ,ZXCF ,ZECN 
      ,ZNRR ,ZBGD ,ZBUY ,ZCOC ,ZDIR ,ZEBD ,ZESC ,ZEXL ,ZFRH ,ZICF ,ZRY3 ,ZSIS ,ZVAS ,ZCOB ,ZNTS ,ZRRP ,ZDSB ,ZDSD ,ZDSN ,ZBD1 ,ZBD2 ,ZBD3 ,ZBD4 ,ZBD5 ,ZBD6 ,ZBD7 ,ZCOS
      ,SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist
	   )
SELECT SoPrCoHist.SalesorderNo
	  ,SoPrCoHist.SalesOrderItemNo
	  ,SoPrCoHist.LDTS
	  ,SoPrCoHist.HashDiff
	  ,SoPrCoHist.DIFF ,SoPrCoHist.GRWR ,SoPrCoHist.MWST ,SoPrCoHist.PNTP ,SoPrCoHist.VPRS ,SoPrCoHist.ZACC ,SoPrCoHist.ZAFG ,SoPrCoHist.ZART ,SoPrCoHist.ZB2B 
	  ,SoPrCoHist.ZBOL ,SoPrCoHist.ZCC1 ,SoPrCoHist.ZCCE ,SoPrCoHist.ZCIT ,SoPrCoHist.ZCO1 ,SoPrCoHist.ZCWD ,SoPrCoHist.ZDIS ,SoPrCoHist.ZDNP ,SoPrCoHist.ZDVG 
	  ,SoPrCoHist.ZEQU ,SoPrCoHist.ZFMW ,SoPrCoHist.ZFOC ,SoPrCoHist.ZGS1 ,SoPrCoHist.ZICV ,SoPrCoHist.ZIDU ,SoPrCoHist.[ZIF%] ,SoPrCoHist.ZIFV ,SoPrCoHist.ZIHF 
	  ,SoPrCoHist.ZIIN ,SoPrCoHist.ZINM ,SoPrCoHist.ZINV ,SoPrCoHist.ZIUP ,SoPrCoHist.ZLOG ,SoPrCoHist.ZLSM ,SoPrCoHist.ZMD0 ,SoPrCoHist.ZMOV ,SoPrCoHist.ZNEP 
	  ,SoPrCoHist.ZOFF ,SoPrCoHist.ZOPX ,SoPrCoHist.ZORD ,SoPrCoHist.ZOUT ,SoPrCoHist.ZPAR ,SoPrCoHist.ZPAY ,SoPrCoHist.ZPR0 ,SoPrCoHist.ZPRF ,SoPrCoHist.ZRAC 
	  ,SoPrCoHist.ZRAS ,SoPrCoHist.ZRDI ,SoPrCoHist.ZRMP ,SoPrCoHist.ZRY1 ,SoPrCoHist.ZRY2 ,SoPrCoHist.ZSF1 ,SoPrCoHist.ZSFP ,SoPrCoHist.ZSPR ,SoPrCoHist.ZSRD 
	  ,SoPrCoHist.ZSSC ,SoPrCoHist.ZSSM, SoPrCoHist.ZST1 ,SoPrCoHist.ZSTS ,SoPrCoHist.ZSWC ,SoPrCoHist.ZVP1 ,SoPrCoHist.ZVPR ,SoPrCoHist.ZXDU ,SoPrCoHist.[ZXF%] 
	  ,SoPrCoHist.ZXFP ,SoPrCoHist.ZXFV ,SoPrCoHist.ZXHF ,SoPrCoHist.ZXIN ,SoPrCoHist.ZXRD ,SoPrCoHist.ZXSC ,SoPrCoHist.ZXSM ,SoPrCoHist.ZXWC ,SoPrCoHist.ZZCR 
	  ,SoPrCoHist.ZZD1 ,SoPrCoHist.ZZDR ,SoPrCoHist.ZZP1 ,SoPrCoHist.ZZSR ,SoPrCoHist.ZERR ,SoPrCoHist.ZDIF ,SoPrCoHist.ZECR ,SoPrCoHist.ZXCF ,SoPrCoHist.ZECN 
	  ,SoPrCoHist.ZNRR ,SoPrCoHist.ZBGD ,SoPrCoHist.ZBUY ,SoPrCoHist.ZCOC ,SoPrCoHist.ZDIR ,SoPrCoHist.ZEBD ,SoPrCoHist.ZESC ,SoPrCoHist.ZEXL ,SoPrCoHist.ZFRH 
	  ,SoPrCoHist.ZICF ,SoPrCoHist.ZRY3 ,SoPrCoHist.ZSIS ,SoPrCoHist.ZVAS ,SoPrCoHist.ZCOB ,SoPrCoHist.ZNTS ,SoPrCoHist.ZRRP ,SoPrCoHist.ZDSB ,SoPrCoHist.ZDSD 
	  ,SoPrCoHist.ZDSN ,SoPrCoHist.ZBD1 ,SoPrCoHist.ZBD2 ,SoPrCoHist.ZBD3 ,SoPrCoHist.ZBD4 ,SoPrCoHist.ZBD5 ,SoPrCoHist.ZBD6 ,SoPrCoHist.ZBD7 ,SoPrCoHist.ZCOS
	  ,CONVERT(TINYINT,2) AS SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist
FROM etl.S4Hana_SoDocumentItemPriceConditionsHistPre AS SoPrCoHist
INNER JOIN #SoPriceConditionsDistSoItemLastBatchWithOutLDTS AS soSoItemLast
		ON soSoItemLast.SalesOrderNo = SoPrCoHist.SalesOrderNo
		AND soSoItemLast.SalesOrderItemNo = SoPrCoHist.SalesOrderItemNo
		AND SoPrCoHist.LEDTS = '9999-12-31' ---> Get latest entrie from the hist table 	


TRUNCATE TABLE etl.S4Hana_SoDocumentItemPriceConditionsHistNew

-- remove duplictes and point to the first entry
;WITH preHash AS (
	SELECT SalesorderNo
		  ,SalesOrderItemNo
		  ,LDTS
		  ,LAG(HashDiff) OVER (PARTITION BY SalesOrderNo, SalesOrderItemNo ORDER BY LDTS) AS pre_HashDiff
		  ,ROW_NUMBER() OVER (PARTITION BY SalesOrderNo, SalesOrderItemNo ORDER BY LDTS) AS RankOverAll
		  ,HashDiff
		  ,DIFF ,GRWR ,MWST ,PNTP ,VPRS ,ZACC ,ZAFG ,ZART ,ZB2B ,ZBOL ,ZCC1 ,ZCCE ,ZCIT ,ZCO1 ,ZCWD ,ZDIS ,ZDNP ,ZDVG ,ZEQU ,ZFMW ,ZFOC ,ZGS1 ,ZICV ,ZIDU ,[ZIF%] ,ZIFV ,ZIHF 
		  ,ZIIN ,ZINM ,ZINV ,ZIUP ,ZLOG ,ZLSM ,ZMD0 ,ZMOV ,ZNEP ,ZOFF ,ZOPX ,ZORD ,ZOUT ,ZPAR ,ZPAY ,ZPR0 ,ZPRF ,ZRAC ,ZRAS ,ZRDI ,ZRMP ,ZRY1 ,ZRY2 ,ZSF1 ,ZSFP ,ZSPR ,ZSRD 
		  ,ZSSC ,ZSSM, ZST1 ,ZSTS ,ZSWC ,ZVP1 ,ZVPR ,ZXDU ,[ZXF%] ,ZXFP ,ZXFV ,ZXHF ,ZXIN ,ZXRD ,ZXSC ,ZXSM ,ZXWC ,ZZCR ,ZZD1 ,ZZDR ,ZZP1 ,ZZSR ,ZERR ,ZDIF ,ZECR ,ZXCF ,ZECN 
		  ,ZNRR ,ZBGD ,ZBUY ,ZCOC ,ZDIR ,ZEBD ,ZESC ,ZEXL ,ZFRH ,ZICF ,ZRY3 ,ZSIS ,ZVAS ,ZCOB ,ZNTS ,ZRRP ,ZDSB ,ZDSD ,ZDSN ,ZBD1 ,ZBD2 ,ZBD3 ,ZBD4 ,ZBD5 ,ZBD6 ,ZBD7 ,ZCOS
		  ,SourceIdentifier
FROM etl.S4Hana_SoDocumentItemPriceConditionsHistPre_T4_PivotIncrement
)
,DiffCheck AS (
	SELECT SalesorderNo
	      ,SalesOrderItemNo
	      ,LDTS
		  ,ISNULL((DateAdd(ss ,-1, LEAD(LDTS) OVER (PARTITION BY SalesOrderNo, SalesOrderItemNo ORDER BY LDTS))),'9999-12-31') AS LEDTS
		  ,HashDiff
	      ,DIFF ,GRWR ,MWST ,PNTP ,VPRS ,ZACC ,ZAFG ,ZART ,ZB2B ,ZBOL ,ZCC1 ,ZCCE ,ZCIT ,ZCO1 ,ZCWD ,ZDIS ,ZDNP ,ZDVG ,ZEQU ,ZFMW ,ZFOC ,ZGS1 ,ZICV ,ZIDU ,[ZIF%] ,ZIFV ,ZIHF 
	      ,ZIIN ,ZINM ,ZINV ,ZIUP ,ZLOG ,ZLSM ,ZMD0 ,ZMOV ,ZNEP ,ZOFF ,ZOPX ,ZORD ,ZOUT ,ZPAR ,ZPAY ,ZPR0 ,ZPRF ,ZRAC ,ZRAS ,ZRDI ,ZRMP ,ZRY1 ,ZRY2 ,ZSF1 ,ZSFP ,ZSPR ,ZSRD 
	      ,ZSSC ,ZSSM, ZST1 ,ZSTS ,ZSWC ,ZVP1 ,ZVPR ,ZXDU ,[ZXF%] ,ZXFP ,ZXFV ,ZXHF ,ZXIN ,ZXRD ,ZXSC ,ZXSM ,ZXWC ,ZZCR ,ZZD1 ,ZZDR ,ZZP1 ,ZZSR ,ZERR ,ZDIF ,ZECR ,ZXCF ,ZECN 
	      ,ZNRR ,ZBGD ,ZBUY ,ZCOC ,ZDIR ,ZEBD ,ZESC ,ZEXL ,ZFRH ,ZICF ,ZRY3 ,ZSIS ,ZVAS ,ZCOB ,ZNTS ,ZRRP ,ZDSB ,ZDSD ,ZDSN ,ZBD1 ,ZBD2 ,ZBD3 ,ZBD4 ,ZBD5 ,ZBD6 ,ZBD7 ,ZCOS
		  ,SourceIdentifier
	FROM preHash
	WHERE HashDiff <> pre_HashDiff
	   OR RankOverAll = 1 -- to get the first entry
)
INSERT INTO etl.S4Hana_SoDocumentItemPriceConditionsHistNew
      (SalesorderNo
      ,SalesOrderItemNo
      ,LDTS
	  ,LEDTS
	  ,HashDiff
      ,DIFF ,GRWR ,MWST ,PNTP ,VPRS ,ZACC ,ZAFG ,ZART ,ZB2B ,ZBOL ,ZCC1 ,ZCCE ,ZCIT ,ZCO1 ,ZCWD ,ZDIS ,ZDNP ,ZDVG ,ZEQU ,ZFMW ,ZFOC ,ZGS1 ,ZICV ,ZIDU ,[ZIF%] ,ZIFV ,ZIHF 
      ,ZIIN ,ZINM ,ZINV ,ZIUP ,ZLOG ,ZLSM ,ZMD0 ,ZMOV ,ZNEP ,ZOFF ,ZOPX ,ZORD ,ZOUT ,ZPAR ,ZPAY ,ZPR0 ,ZPRF ,ZRAC ,ZRAS ,ZRDI ,ZRMP ,ZRY1 ,ZRY2 ,ZSF1 ,ZSFP ,ZSPR ,ZSRD 
      ,ZSSC ,ZSSM, ZST1 ,ZSTS ,ZSWC ,ZVP1 ,ZVPR ,ZXDU ,[ZXF%] ,ZXFP ,ZXFV ,ZXHF ,ZXIN ,ZXRD ,ZXSC ,ZXSM ,ZXWC ,ZZCR ,ZZD1 ,ZZDR ,ZZP1 ,ZZSR ,ZERR ,ZDIF ,ZECR ,ZXCF ,ZECN 
      ,ZNRR ,ZBGD ,ZBUY ,ZCOC ,ZDIR ,ZEBD ,ZESC ,ZEXL ,ZFRH ,ZICF ,ZRY3 ,ZSIS ,ZVAS ,ZCOB ,ZNTS ,ZRRP ,ZDSB ,ZDSD ,ZDSN ,ZBD1 ,ZBD2 ,ZBD3 ,ZBD4 ,ZBD5 ,ZBD6 ,ZBD7 ,ZCOS
	  ,SourceIdentifier
       )
SELECT SalesorderNo
      ,SalesOrderItemNo
      ,LDTS
	  ,LEDTS
	  ,HashDiff
      ,DIFF ,GRWR ,MWST ,PNTP ,VPRS ,ZACC ,ZAFG ,ZART ,ZB2B ,ZBOL ,ZCC1 ,ZCCE ,ZCIT ,ZCO1 ,ZCWD ,ZDIS ,ZDNP ,ZDVG ,ZEQU ,ZFMW ,ZFOC ,ZGS1 ,ZICV ,ZIDU ,[ZIF%] ,ZIFV ,ZIHF 
      ,ZIIN ,ZINM ,ZINV ,ZIUP ,ZLOG ,ZLSM ,ZMD0 ,ZMOV ,ZNEP ,ZOFF ,ZOPX ,ZORD ,ZOUT ,ZPAR ,ZPAY ,ZPR0 ,ZPRF ,ZRAC ,ZRAS ,ZRDI ,ZRMP ,ZRY1 ,ZRY2 ,ZSF1 ,ZSFP ,ZSPR ,ZSRD 
      ,ZSSC ,ZSSM, ZST1 ,ZSTS ,ZSWC ,ZVP1 ,ZVPR ,ZXDU ,[ZXF%] ,ZXFP ,ZXFV ,ZXHF ,ZXIN ,ZXRD ,ZXSC ,ZXSM ,ZXWC ,ZZCR ,ZZD1 ,ZZDR ,ZZP1 ,ZZSR ,ZERR ,ZDIF ,ZECR ,ZXCF ,ZECN 
      ,ZNRR ,ZBGD ,ZBUY ,ZCOC ,ZDIR ,ZEBD ,ZESC ,ZEXL ,ZFRH ,ZICF ,ZRY3 ,ZSIS ,ZVAS ,ZCOB ,ZNTS ,ZRRP ,ZDSB ,ZDSD ,ZDSN ,ZBD1 ,ZBD2 ,ZBD3 ,ZBD4 ,ZBD5 ,ZBD6 ,ZBD7 ,ZCOS
	  ,SourceIdentifier
FROM DiffCheck
WHERE SourceIdentifier = 1 -- only new entiers 
	OR (SourceIdentifier = 2 AND LEDTS <> '9999-12-31') -- keep existing entries to update LEDTS in the Hist table 

-- Insert new entries to S4Hana_SoDocumentItemPriceConditionsHistNew.

INSERT INTO etl.S4Hana_SoDocumentItemPriceConditionsHistPre
      (SalesorderNo
      ,SalesOrderItemNo
      ,LDTS
	  ,LEDTS
	  ,HashDiff
      ,DIFF ,GRWR ,MWST ,PNTP ,VPRS ,ZACC ,ZAFG ,ZART ,ZB2B ,ZBOL ,ZCC1 ,ZCCE ,ZCIT ,ZCO1 ,ZCWD ,ZDIS ,ZDNP ,ZDVG ,ZEQU ,ZFMW ,ZFOC ,ZGS1 ,ZICV ,ZIDU ,[ZIF%] ,ZIFV ,ZIHF 
      ,ZIIN ,ZINM ,ZINV ,ZIUP ,ZLOG ,ZLSM ,ZMD0 ,ZMOV ,ZNEP ,ZOFF ,ZOPX ,ZORD ,ZOUT ,ZPAR ,ZPAY ,ZPR0 ,ZPRF ,ZRAC ,ZRAS ,ZRDI ,ZRMP ,ZRY1 ,ZRY2 ,ZSF1 ,ZSFP ,ZSPR ,ZSRD 
      ,ZSSC ,ZSSM, ZST1 ,ZSTS ,ZSWC ,ZVP1 ,ZVPR ,ZXDU ,[ZXF%] ,ZXFP ,ZXFV ,ZXHF ,ZXIN ,ZXRD ,ZXSC ,ZXSM ,ZXWC ,ZZCR ,ZZD1 ,ZZDR ,ZZP1 ,ZZSR ,ZERR ,ZDIF ,ZECR ,ZXCF ,ZECN 
      ,ZNRR ,ZBGD ,ZBUY ,ZCOC ,ZDIR ,ZEBD ,ZESC ,ZEXL ,ZFRH ,ZICF ,ZRY3 ,ZSIS ,ZVAS ,ZCOB ,ZNTS ,ZRRP ,ZDSB ,ZDSD ,ZDSN ,ZBD1 ,ZBD2 ,ZBD3 ,ZBD4 ,ZBD5 ,ZBD6 ,ZBD7 ,ZCOS
       )
SELECT SalesorderNo
      ,SalesOrderItemNo
      ,LDTS
	  ,LEDTS
	  ,HashDiff
      ,DIFF ,GRWR ,MWST ,PNTP ,VPRS ,ZACC ,ZAFG ,ZART ,ZB2B ,ZBOL ,ZCC1 ,ZCCE ,ZCIT ,ZCO1 ,ZCWD ,ZDIS ,ZDNP ,ZDVG ,ZEQU ,ZFMW ,ZFOC ,ZGS1 ,ZICV ,ZIDU ,[ZIF%] ,ZIFV ,ZIHF 
      ,ZIIN ,ZINM ,ZINV ,ZIUP ,ZLOG ,ZLSM ,ZMD0 ,ZMOV ,ZNEP ,ZOFF ,ZOPX ,ZORD ,ZOUT ,ZPAR ,ZPAY ,ZPR0 ,ZPRF ,ZRAC ,ZRAS ,ZRDI ,ZRMP ,ZRY1 ,ZRY2 ,ZSF1 ,ZSFP ,ZSPR ,ZSRD 
      ,ZSSC ,ZSSM, ZST1 ,ZSTS ,ZSWC ,ZVP1 ,ZVPR ,ZXDU ,[ZXF%] ,ZXFP ,ZXFV ,ZXHF ,ZXIN ,ZXRD ,ZXSC ,ZXSM ,ZXWC ,ZZCR ,ZZD1 ,ZZDR ,ZZP1 ,ZZSR ,ZERR ,ZDIF ,ZECR ,ZXCF ,ZECN 
      ,ZNRR ,ZBGD ,ZBUY ,ZCOC ,ZDIR ,ZEBD ,ZESC ,ZEXL ,ZFRH ,ZICF ,ZRY3 ,ZSIS ,ZVAS ,ZCOB ,ZNTS ,ZRRP ,ZDSB ,ZDSD ,ZDSN ,ZBD1 ,ZBD2 ,ZBD3 ,ZBD4 ,ZBD5 ,ZBD6 ,ZBD7 ,ZCOS
FROM etl.S4Hana_SoDocumentItemPriceConditionsHistNew
WHERE SourceIdentifier = 1 -- only new entiers 

--Update LEDTS for entires with fresh inserted entries for this BK

UPDATE histPre
SET histPre.LEDTS = new.LEDTS
FROM etl.S4Hana_SoDocumentItemPriceConditionsHistPre AS histPre
INNER JOIN etl.S4Hana_SoDocumentItemPriceConditionsHistNew AS new
	ON histPre.SalesOrderNo = new.SalesOrderNo  -- join over SalesOrderNo and not HashDiff because the distribution of the tables via SalesOrderNo order by LDTS
	AND histPre.SalesOrderItemNo = new.SalesOrderItemNo
	AND histPre.LDTS = new.LDTS
WHERE histPre.LEDTS = '9999-12-31'
  AND new.SourceIdentifier = 2 -- only update Objects loaded from Hist table

-- Update End of the load
UPDATE DTlogs
SET ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

END -- END SP