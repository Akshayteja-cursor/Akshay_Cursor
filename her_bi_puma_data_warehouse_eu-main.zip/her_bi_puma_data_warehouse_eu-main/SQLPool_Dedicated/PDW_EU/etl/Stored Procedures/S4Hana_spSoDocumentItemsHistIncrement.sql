﻿CREATE PROC [etl].[S4Hana_spSoDocumentItemsHistIncrement] @LDTS [DATETIME] AS
BEGIN
SET NOCOUNT ON

DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(0) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(0)
DECLARE @DestinationLastLoadDate DATETIME2(0)
DECLARE @BatchLdts DATETIME2(0) = @LDTS

-- do not use the input parameter, in case of an failur or reload situartion take the last tranfered LDTS from the Hist table
IF(EXISTS(SELECT 1 FROM etl.S4Hana_SoDocumentItemsHistPre))
BEGIN
	SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(LDTS))
	FROM etl.S4Hana_SoDocumentItemsHistPre
END
ELSE BEGIN
	SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
END 

IF(EXISTS(SELECT 1 FROM stag.S4Hana_SODocumentItems_full))
BEGIN
	SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(_LDTS))
	FROM stag.S4Hana_SODocumentItems_full
END
ELSE BEGIN
	SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
END 

--Log Data load
INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'spSoDocumentItemsHistIncrement'
			,'prepSoDocHist'
			,'NatSalesOrdersOohHistory'
			,'sales'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts

IF OBJECT_ID('tempdb..#SoDocumentItemsFullLastIncrement') IS NOT NULL
BEGIN
    DROP TABLE #SoDocumentItemsFullLastIncrement
END

CREATE TABLE #SoDocumentItemsFullLastIncrement
WITH
(DISTRIBUTION = HASH(SalesOrderNo)
,HEAP)
AS(
SELECT CAST(stagSoDocItemFull.VBELN AS NVARCHAR(10)) AS SalesOrderNo 
	  ,CAST(stagSoDocItemFull.POSNR AS NVARCHAR(6)) AS SalesOrderItemNo
	  ,CAST(stagSoDocItemFull.MATNR AS NVARCHAR(40)) AS MaterialNumber
	  ,CAST(stagSoDocItemFull.KWMENG AS NUMERIC(15, 3)) AS OrderQuantity
	  ,CAST(stagSoDocItemFull.NETWR AS NUMERIC(15, 2)) AS NetAmount
	  ,CAST(stagSoDocItemFull.ABGRU AS NCHAR(2)) AS RejectionReason
	  ,CAST(stagSoDocItemFull.VGBEL AS NVARCHAR(10)) AS ReferenceDocumentNumber
	  ,CAST(stagSoDocItemFull.VGPOS AS NVARCHAR(6)) AS ReferenceDocumentItemNumber
	  ,CAST(stagSoDocItemFull.VGTYP AS NCHAR(4)) AS PrecedingDocumentCategory
	  ,CAST(CASE WHEN stagSoDocItemFull.ODQ_CHANGEMODE = 'D' THEN 1 ELSE 0 END AS BIT) AS IsDeleted
	  ,CAST(stagSoDocItemFull._LDTS AS DATETIME2(0)) AS LDTS 
	  ,ROW_NUMBER() OVER (PARTITION BY stagSoDocItemFull.VBELN, stagSoDocItemFull.POSNR, stagSoDocItemFull._LDTS ORDER BY stagSoDocItemFull.TS_SEQUENCE_NUMBER DESC) AS rn_PerLdts
	  ,CONVERT(BINARY(16), 
		HASHBYTES('MD5',CONCAT( 
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),stagSoDocItemFull.VBELN)))),'_', 
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),stagSoDocItemFull.POSNR)))),'_', 
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),stagSoDocItemFull.MATNR)))),'_', 
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),stagSoDocItemFull.KWMENG)))),'_', 
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),stagSoDocItemFull.NETWR)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),stagSoDocItemFull.ABGRU)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),stagSoDocItemFull.VGBEL)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),stagSoDocItemFull.VGPOS)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),stagSoDocItemFull.VGTYP)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),CASE WHEN stagSoDocItemFull.ODQ_CHANGEMODE = 'D' THEN 1 ELSE 0 END))))
	  ))) AS HashDiff 
	  ,CONVERT(TINYINT,1) AS SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist
FROM stag.S4Hana_SODocumentItems_full AS stagSoDocItemFull
INNER JOIN stag.S4Hana_vSalesOrgToCompanyCode AS sct 
	ON stagSoDocItemFull.BUKRS = sct.CompanyCode
WHERE stagSoDocItemFull._LDTS > @DestinationLastLoadDate
)

-- Add last entires from Hist which are in the new batch
INSERT INTO #SoDocumentItemsFullLastIncrement
	(SalesOrderNo
	,SalesOrderItemNo
	,MaterialNumber
	,OrderQuantity
	,NetAmount
	,RejectionReason
	,ReferenceDocumentNumber
	,ReferenceDocumentItemNumber
	,PrecedingDocumentCategory
	,IsDeleted
	,LDTS
	,rn_PerLdts
	,HashDiff
	,SourceIdentifier)
SELECT SoItemHist.SalesOrderNo
	,SoItemHist.SalesOrderItemNo
	,SoItemHist.MaterialNumber
	,SoItemHist.OrderQuantity
	,SoItemHist.NetAmount
	,SoItemHist.RejectionReason
	,SoItemHist.ReferenceDocumentNumber
	,SoItemHist.ReferenceDocumentItemNumber
	,SoItemHist.PrecedingDocumentCategory
	,SoItemHist.IsDeleted
	,SoItemHist.LDTS
	,CONVERT(INT,1) AS rn_PerLdts
	,SoItemHist.HashDiff
	,CONVERT(TINYINT,2) AS SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist
	FROM #SoDocumentItemsFullLastIncrement AS stagNew
	INNER JOIN etl.S4Hana_SoDocumentItemsHistPre AS SoItemHist
		ON stagNew.SalesOrderNo = SoItemHist.SalesOrderNo
		AND stagNew.SalesOrderItemNo = SoItemHist.SalesOrderItemNo
		AND SoItemHist.LEDTS = '9999-12-31' ---> Get latest entrie from the hist table 

TRUNCATE TABLE etl.S4Hana_SoDocumentItemsHistNew

;WITH preHash AS (
	 SELECT SalesOrderNo
		   ,SalesOrderItemNo
		   ,MaterialNumber
		   ,OrderQuantity
		   ,NetAmount
		   ,RejectionReason
		   ,ReferenceDocumentNumber
		   ,ReferenceDocumentItemNumber
		   ,PrecedingDocumentCategory
		   ,IsDeleted
		   ,SourceIdentifier
		   ,LDTS
		   ,HashDiff
		   ,LAG(HashDiff) OVER (PARTITION BY SalesOrderNo, SalesOrderItemNo ORDER BY LDTS) AS pre_HashDiff
		   ,ROW_NUMBER() OVER (PARTITION BY SalesOrderNo, SalesOrderItemNo ORDER BY LDTS) AS RankOverAll
	FROM #SoDocumentItemsFullLastIncrement
	WHERE rn_PerLdts = 1
)
,DiffCheck AS (
	SELECT SalesOrderNo
		  ,SalesOrderItemNo
		  ,LDTS
		  ,ISNULL((DateAdd(ss ,-1, LEAD(LDTS) OVER (PARTITION BY SalesOrderNo, SalesOrderItemNo ORDER BY LDTS))),'9999-12-31') AS LEDTS
		  ,HashDiff
		  ,MaterialNumber
		  ,OrderQuantity
		  ,NetAmount
		  ,RejectionReason
		  ,ReferenceDocumentNumber
		  ,ReferenceDocumentItemNumber
		  ,PrecedingDocumentCategory
		  ,IsDeleted
		  ,SourceIdentifier
	FROM preHash
	WHERE HashDiff <> pre_HashDiff
	   OR RankOverAll = 1 -- to get the first entry
)
INSERT INTO etl.S4Hana_SoDocumentItemsHistNew
	  (SalesOrderNo
	  ,SalesOrderItemNo
	  ,LDTS
	  ,LEDTS
	  ,HashDiff
	  ,MaterialNumber
	  ,OrderQuantity
	  ,NetAmount
	  ,RejectionReason
	  ,ReferenceDocumentNumber
	  ,ReferenceDocumentItemNumber
	  ,PrecedingDocumentCategory
	  ,IsDeleted
	  ,SourceIdentifier)
SELECT SalesOrderNo
	  ,SalesOrderItemNo
	  ,LDTS
	  ,LEDTS
	  ,HashDiff
	  ,MaterialNumber
	  ,OrderQuantity
	  ,NetAmount
	  ,RejectionReason
	  ,ReferenceDocumentNumber
	  ,ReferenceDocumentItemNumber
	  ,PrecedingDocumentCategory
	  ,IsDeleted
	  ,SourceIdentifier
FROM DiffCheck
WHERE SourceIdentifier = 1 -- only new entiers 
	OR (SourceIdentifier = 2 AND LEDTS <> '9999-12-31') -- existing entries to update LEDTS in the HIST table 

-- Insert new entries to S4Hana_SoDocumentItemsHistPre
INSERT INTO etl.S4Hana_SoDocumentItemsHistPre
	  (SalesOrderNo
	  ,SalesOrderItemNo
	  ,LDTS
	  ,LEDTS
	  ,HashDiff
	  ,MaterialNumber
	  ,OrderQuantity
	  ,NetAmount
	  ,RejectionReason
	  ,ReferenceDocumentNumber
	  ,ReferenceDocumentItemNumber
	  ,PrecedingDocumentCategory
	  ,IsDeleted)
SELECT SalesOrderNo
	  ,SalesOrderItemNo
	  ,LDTS
	  ,LEDTS
	  ,HashDiff
	  ,MaterialNumber
	  ,OrderQuantity
	  ,NetAmount
	  ,RejectionReason
	  ,ReferenceDocumentNumber
	  ,ReferenceDocumentItemNumber
	  ,PrecedingDocumentCategory
	  ,IsDeleted
FROM etl.S4Hana_SoDocumentItemsHistNew
WHERE SourceIdentifier = 1 -- only new entiers 

--Update LEDTS for entires with fresh inserted entries for this BK
UPDATE histPre
SET histPre.LEDTS = new.LEDTS
FROM etl.S4Hana_SoDocumentItemsHistPre AS histPre
INNER JOIN etl.S4Hana_SoDocumentItemsHistNew AS new
	ON histPre.SalesOrderNo = new.SalesOrderNo  -- join over SalesOrderNo and not HashDiff because the distribution of the tables via SalesOrderNo order by LDTS
	AND histPre.SalesOrderItemNo = new.SalesOrderItemNo
	AND histPre.LDTS = new.LDTS
WHERE histPre.LEDTS = '9999-12-31'
  AND new.SourceIdentifier = 2 -- only update Objects loaded from Hist table

-- Update End of the load
UPDATE DTlogs
SET ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

END -- END SP