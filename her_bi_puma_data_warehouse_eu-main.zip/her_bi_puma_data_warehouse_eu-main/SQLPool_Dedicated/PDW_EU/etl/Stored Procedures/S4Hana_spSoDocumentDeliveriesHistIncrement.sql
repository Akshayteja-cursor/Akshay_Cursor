﻿CREATE PROC [etl].[S4Hana_spSoDocumentDeliveriesHistIncrement] @LDTS [DATETIME] AS
BEGIN
SET NOCOUNT ON

DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(0) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(0)
DECLARE @DestinationLastLoadDate DATETIME2(0)
DECLARE @BatchLdts DATETIME2(0) = @LDTS

-- do not use the input parameter, in case of an failur or reload situartion take the last tranfered LDTS from the Hist table
IF(EXISTS(SELECT 1 FROM etl.S4Hana_SODocumentDeliveriesHistPre))
BEGIN
	SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(LDTS))
	FROM etl.S4Hana_SODocumentDeliveriesHistPre
END
ELSE BEGIN
	SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
END 


IF(EXISTS(SELECT 1 FROM stag.S4Hana_SODocumentDeliveries_full))
BEGIN
	SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(_LDTS))
	FROM stag.S4Hana_SODocumentDeliveries_full
END
ELSE BEGIN
	SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
END 

--Log Data load
INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'spSoDocumentDeliveriesHistIncrement'
			,'prepSoDocHist'
			,'NatSalesOrdersOohHistory'
			,'sales'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts


IF OBJECT_ID('tempdb..#SoDocumentDeliveriesFullLastIncrement') IS NOT NULL
BEGIN
    DROP TABLE #SoScheduleLinesFullLastIncrement
END

Create TABLE #SoDocumentDeliveriesFullLastIncrement
WITH
(DISTRIBUTION = HASH(SalesOrderNo)
,HEAP)
AS( SELECT CAST(VBELN AS NVARCHAR(10)) AS SalesOrderNo  --BK
		  ,CAST(POSNR AS NVARCHAR(6)) AS SalesOrderItemNo --BK
		  ,CAST(ETENR AS NVARCHAR(4)) AS ScheduleLine --BK
		  ,CAST(VBELN_VL AS NVARCHAR(10)) AS DeliveryNoteNumber --BK
		  ,CAST(POSNR_VL AS NVARCHAR(6)) AS DeliveryNoteItemNo --BK
		  ,CAST(LFSTA AS NCHAR(1)) AS DeliveryStatus
		  ,CAST(MCEX_I_WADAT AS DATE) AS ActualGoodsMovementDate
		  ,CAST(RECORD_DELETED AS NCHAR(1)) AS SalesOrderDeleted
		  ,CAST(CASE WHEN ODQ_CHANGEMODE = 'D' OR RECORD_DELETED = 'X' THEN 1 ELSE 0 END AS BIT) AS IsDeleted
		  ,CAST(_LDTS AS DATETIME2(0)) AS LDTS
  		  ,ROW_NUMBER() OVER (PARTITION BY VBELN, POSNR, ETENR, _LDTS
		  				ORDER BY TS_SEQUENCE_NUMBER DESC, -- this order is not on prem
		  						(CASE WHEN ODQ_CHANGEMODE = 'D' OR RECORD_DELETED = 'X' THEN 1 ELSE 0 END) ASC,  /* #onPrem: New sort for Zero Pics*/
		  						 POSNR_VL DESC,  /* #onPrem:added to avoid picking 000000 delivery notes when others are available*/
		  						 VBELN_VL ASC /*#onPrem: for multiple delivery notes for the same schedule line*/
  		  ) AS rn_PerLdts
  		  ,CONVERT(BINARY(16),
  		  	HASHBYTES('MD5', CONCAT(
		  		UPPER(LTRIM(RTRIM(VBELN))), '_',
		  		UPPER(LTRIM(RTRIM(POSNR))), '_',
		  		UPPER(LTRIM(RTRIM(ETENR))), '_',
		  		UPPER(LTRIM(RTRIM(VBELN_VL))), '_',
		  		UPPER(LTRIM(RTRIM(POSNR_VL))), '_',
		  		UPPER(LTRIM(RTRIM(LFSTA))), '_',
		  		UPPER(LTRIM(RTRIM(MCEX_I_WADAT))), '_',
		  		UPPER(LTRIM(RTRIM(RECORD_DELETED))), '_',
		  		UPPER(LTRIM(RTRIM(ODQ_CHANGEMODE)))
  		  ))) AS HashDiff 
		  ,CONVERT(TINYINT,1) AS SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist
	FROM stag.S4Hana_SODocumentDeliveries_full
	WHERE _LDTS > @DestinationLastLoadDate  
)

-- Add last related entires from Hist which are in the new batch
INSERT INTO #SoDocumentDeliveriesFullLastIncrement
	(SalesOrderNo
	,SalesOrderItemNo
	,ScheduleLine
	,DeliveryNoteNumber
	,DeliveryNoteItemNo
	,DeliveryStatus
	,ActualGoodsMovementDate
	,SalesOrderDeleted
	,IsDeleted
	,LDTS
	,rn_PerLdts
	,HashDiff
	,SourceIdentifier)
SELECT SoDelivHist.SalesOrderNo
	  ,SoDelivHist.SalesOrderItemNo
	  ,SoDelivHist.ScheduleLine
	  ,SoDelivHist.DeliveryNoteNumber
	  ,SoDelivHist.DeliveryNoteItemNo
	  ,SoDelivHist.DeliveryStatus
	  ,SoDelivHist.ActualGoodsMovementDate
	  ,SoDelivHist.SalesOrderDeleted
	  ,SoDelivHist.IsDeleted
	  ,SoDelivHist.LDTS
	  ,CONVERT(INT,1) AS rn_PerLdts
	  ,SoDelivHist.HashDiff
	  ,CONVERT(TINYINT,2) AS SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist
FROM #SoDocumentDeliveriesFullLastIncrement AS stagNew
INNER JOIN etl.S4Hana_SODocumentDeliveriesHistPre AS SoDelivHist
		ON stagNew.SalesOrderNo = SoDelivHist.SalesOrderNo
		AND stagNew.SalesOrderItemNo = SoDelivHist.SalesOrderItemNo
		AND stagNew.ScheduleLine = SoDelivHist.ScheduleLine
		AND SoDelivHist.LEDTS = '9999-12-31' ---> Get latest entrie from the hist table 

TRUNCATE TABLE etl.S4Hana_SODocumentDeliveriesHistNew

;WITH preHash AS 
	(SELECT SalesOrderNo
		   ,SalesOrderItemNo
		   ,ScheduleLine
		   ,DeliveryNoteNumber
		   ,DeliveryNoteItemNo
		   ,DeliveryStatus
		   ,ActualGoodsMovementDate
		   ,SalesOrderDeleted
		   ,IsDeleted
		   ,SourceIdentifier
		   ,LDTS
		   ,HashDiff
		   ,LAG(HashDiff) OVER (PARTITION BY SalesOrderNo, SalesOrderItemNo, ScheduleLine ORDER BY LDTS) AS pre_HashDiff
		   ,ROW_NUMBER() OVER (PARTITION BY SalesOrderNo, SalesOrderItemNo, ScheduleLine ORDER BY LDTS) AS RankOverAll
	FROM #SoDocumentDeliveriesFullLastIncrement
	WHERE rn_PerLdts = 1
)
,DiffCheck AS (	
	SELECT SalesOrderNo
		  ,SalesOrderItemNo
		  ,ScheduleLine
		  ,DeliveryNoteNumber
		  ,DeliveryNoteItemNo
		  ,LDTS
		  ,ISNULL((DateAdd(ss ,-1, LEAD(LDTS) OVER (PARTITION BY SalesOrderNo, SalesOrderItemNo, ScheduleLine ORDER BY LDTS))),'9999-12-31') AS LEDTS
		  ,HashDiff
		  ,DeliveryStatus
		  ,ActualGoodsMovementDate
		  ,SalesOrderDeleted
		  ,IsDeleted
		  ,SourceIdentifier
	FROM preHash
	WHERE HashDiff <> pre_HashDiff
	   OR RankOverAll = 1 -- to get the first entry
)
INSERT INTO etl.S4Hana_SODocumentDeliveriesHistNew
	  (SalesOrderNo
      ,SalesOrderItemNo
      ,ScheduleLine
      ,DeliveryNoteNumber
      ,DeliveryNoteItemNo
      ,LDTS
      ,LEDTS
      ,HashDiff
      ,DeliveryStatus
      ,ActualGoodsMovementDate
      ,SalesOrderDeleted
      ,IsDeleted
	  ,SourceIdentifier)
SELECT SalesOrderNo
	  ,SalesOrderItemNo
	  ,ScheduleLine
	  ,DeliveryNoteNumber
	  ,DeliveryNoteItemNo
	  ,LDTS
	  ,LEDTS
	  ,HashDiff
	  ,DeliveryStatus
	  ,ActualGoodsMovementDate
	  ,SalesOrderDeleted
	  ,IsDeleted
	  ,SourceIdentifier
FROM DiffCheck
WHERE SourceIdentifier = 1 -- only new entiers 
	OR (SourceIdentifier = 2 AND LEDTS <> '9999-12-31') -- existing entries to update LEDTS in the HIST table 

-- Insert new entries to S4Hana_SODocumentDeliveriesHistPre

INSERT INTO etl.S4Hana_SODocumentDeliveriesHistPre
	  (SalesOrderNo
      ,SalesOrderItemNo
      ,ScheduleLine
      ,DeliveryNoteNumber
      ,DeliveryNoteItemNo
      ,LDTS
      ,LEDTS
      ,HashDiff
      ,DeliveryStatus
      ,ActualGoodsMovementDate
      ,SalesOrderDeleted
      ,IsDeleted)
SELECT SalesOrderNo
	  ,SalesOrderItemNo
	  ,ScheduleLine
	  ,DeliveryNoteNumber
	  ,DeliveryNoteItemNo
	  ,LDTS
	  ,LEDTS
	  ,HashDiff
	  ,DeliveryStatus
	  ,ActualGoodsMovementDate
	  ,SalesOrderDeleted
	  ,IsDeleted
FROM etl.S4Hana_SODocumentDeliveriesHistNew
	WHERE SourceIdentifier = 1 -- only new Objects from the Incremental 

--Update LEDTS for entires with fresh inserted entries for this BK

UPDATE histPre
SET histPre.LEDTS = new.LEDTS
FROM etl.S4Hana_SODocumentDeliveriesHistPre AS histPre
INNER JOIN etl.S4Hana_SODocumentDeliveriesHistNew AS new
	ON histPre.SalesOrderNo = new.SalesOrderNo  -- join over SalesOrderNo and not HashDiff because the distribution of the tables via SalesOrderNo order by LDTS
	AND histPre.SalesOrderItemNo = new.SalesOrderItemNo
	AND histPre.ScheduleLine = new.ScheduleLine
	AND histPre.DeliveryNoteNumber = new.DeliveryNoteNumber
	AND histPre.DeliveryNoteItemNo = new.DeliveryNoteItemNo
	AND histPre.LDTS = new.LDTS
WHERE histPre.LEDTS = '9999-12-31'
  AND new.SourceIdentifier = 2 -- only update Objects loaded from Hist table

-- Update End of the load
UPDATE DTlogs
SET ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

END -- END SP