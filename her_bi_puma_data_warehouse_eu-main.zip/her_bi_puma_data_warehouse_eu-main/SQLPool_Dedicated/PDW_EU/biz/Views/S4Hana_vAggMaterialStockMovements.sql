﻿CREATE VIEW [biz].[S4Hana_vAggMaterialStockMovements]
AS with cte
as
(
select HASH_BK, count(*) as count from biz.S4Hana_AggMaterialStockMovements group by HASH_BK having count(*)=1
)
SELECT
	   a.[HASH_BK]
      ,[AggInventoryMovements_HASH]
      ,[HASH_Diff]
      ,[COMPANYCODE]
      ,[MATERIAL]
      ,[PLANT]
      ,[STORAGELOCATION]
      ,[STOCKSEGMENT]
      ,[BATCHID]
      ,[MATERIALBASEUNIT]
      ,[POSTINGDATE]
      ,[_LDTS]
      ,[UNRESTRICTEDSTOCK]
      ,[STOCKINQUALITYINSPECTION]
      ,[BLOCKEDSTOCKRETURNS]
      ,[STOCKINTRANSFERSTLOC]
      ,[BLOCKEDSTOCK]
      ,[TOTALSTOCKRESTRICTEDBATCHES]
      ,[STOCKINTRANSFERPLANT]
      ,[STOCKINTRANSIT]
      ,[TIEDEMPTIES]
      ,[VALUATEDGOODSRECEIPTBLOCKEDSTOCK]
      ,[SCRAPQUANTITY]
      ,[UPDATED]
      ,GETDATE() as [ModifiedOn]
      ,[SPECIALSTOCKINDICATOR]
  FROM [biz].[S4Hana_AggMaterialStockMovements] a
  join cte on a.hash_bk=cte.hash_bk;