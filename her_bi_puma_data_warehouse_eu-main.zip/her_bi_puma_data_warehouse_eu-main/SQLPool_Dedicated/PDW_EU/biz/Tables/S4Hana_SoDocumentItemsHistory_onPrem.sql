﻿CREATE TABLE [biz].[S4Hana_SoDocumentItemsHistory_onPrem] (
    [NatSalesOrderNo]             NVARCHAR (10)   NULL,
    [NatSalesOrderItemNo]         NVARCHAR (6)    NULL,
    [LDTS]                        DATETIME2 (0)   NULL,
    [LEDTS]                       DATETIME2 (0)   NOT NULL,
    [HashDiff]                    BINARY (16)     NULL,
    [MaterialNumber]              NVARCHAR (40)   NULL,
    [OrderQuantity]               DECIMAL (15, 3) NULL,
    [NetAmount]                   DECIMAL (15, 2) NULL,
    [RejectionReason]             NCHAR (2)       NULL,
    [ReferenceDocumentNumber]     NVARCHAR (10)   NULL,
    [ReferenceDocumentItemNumber] NVARCHAR (6)    NULL,
    [PrecedingDocumentCategory]   NCHAR (4)       NULL,
    [GrossSalesValue]             DECIMAL (15, 3) NULL,
    [IsDeleted]                   BIT             NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX ORDER([LDTS]), DISTRIBUTION = HASH([NatSalesOrderNo]));

