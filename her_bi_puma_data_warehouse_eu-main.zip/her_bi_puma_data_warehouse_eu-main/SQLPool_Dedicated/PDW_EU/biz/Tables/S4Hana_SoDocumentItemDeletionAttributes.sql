﻿CREATE TABLE [biz].[S4Hana_SoDocumentItemDeletionAttributes] (
    [SoDocumentItemDeletionAttributeId] BIGINT        IDENTITY (1, 1) NOT NULL,
    [NatSalesOrderNo]                   NVARCHAR (10) NOT NULL,
    [NatSalesOrderItemNo]               NVARCHAR (6)  NOT NULL,
    [HashDiff]                          BINARY (16)   NULL,
    [SOTypeCode]                        NVARCHAR (4)  NULL,
    [MaterialNumber]                    NVARCHAR (40) NULL,
    [ReferenceSDDocument]               NVARCHAR (10) NULL,
    [ReferenceDocumentItemNumber]       NVARCHAR (6)  NULL,
    [PrecedingDocumentCategory]         NVARCHAR (4)  NULL,
    [LDTS]                              DATETIME2 (7) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = HASH([NatSalesOrderNo]));

