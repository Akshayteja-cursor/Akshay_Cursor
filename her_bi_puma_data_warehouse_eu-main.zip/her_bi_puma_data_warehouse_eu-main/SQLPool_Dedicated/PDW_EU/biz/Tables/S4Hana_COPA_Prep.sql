﻿CREATE TABLE [biz].[S4Hana_COPA_Prep] (
    [NatSalesOrderNo]     NVARCHAR (10)   NULL,
    [NatSalesOrderItemNo] NVARCHAR (6)    NULL,
    [LDTS]                DATETIME2 (7)   NULL,
    [Quantity]            DECIMAL (13, 3) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);


GO
CREATE NONCLUSTERED INDEX [IX_Copaprep_OOH_Join]
    ON [biz].[S4Hana_COPA_Prep]([NatSalesOrderNo] ASC, [NatSalesOrderItemNo] ASC);

