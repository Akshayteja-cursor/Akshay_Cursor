﻿CREATE TABLE [biz].[S4Hana_AggMaterialStockMovementsUnique] (
    [AggInventoryMovements_HASHUnique] BINARY (16)   NOT NULL,
    [_LDTS]                            DATETIME2 (7) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = HASH([AggInventoryMovements_HASHUnique]));

