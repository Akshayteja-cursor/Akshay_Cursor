﻿CREATE TABLE [biz].[S4Hana_POScheduleLines] (
    [PONo]                      NVARCHAR (10)   NULL,
    [POItemNo]                  NVARCHAR (5)    NULL,
    [ScheduleLineCount]         NVARCHAR (4)    NULL,
    [DeliveryDate]              DATE            NULL,
    [RoughGoodsReceiptQuantity] DECIMAL (13, 3) NULL,
    [IsDeleted]                 BIT             NULL,
    [LDTS]                      DATETIME2 (7)   NULL,
    [HashDiff]                  BINARY (16)     NULL
)
WITH (CLUSTERED INDEX([PONo], [POItemNo], [ScheduleLineCount]), DISTRIBUTION = HASH([PONo]));

