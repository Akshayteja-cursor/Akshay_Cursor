﻿CREATE TABLE [biz].[S4Hana_SoScheduleLinesHistory_onPrem] (
    [NatSalesOrderNo]        NVARCHAR (10)   NULL,
    [NatSalesOrderItemNo]    NVARCHAR (6)    NULL,
    [ScheduleLine]           NVARCHAR (4)    NULL,
    [LDTS]                   DATETIME2 (7)   NULL,
    [LEDTS]                  DATETIME2 (7)   NOT NULL,
    [HashDiff]               BINARY (16)     NULL,
    [ScheduleLineDate]       DATE            NULL,
    [ConfirmedOrderQuantity] NUMERIC (13, 3) NULL,
    [IsDeleted]              TINYINT         NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX ORDER([LDTS]), DISTRIBUTION = HASH([NatSalesOrderNo]));

