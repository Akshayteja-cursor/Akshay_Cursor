﻿CREATE TABLE [biz].[S4Hana_BPAddressEmail] (
    [BPAddressEmail_BK] NVARCHAR (100) NOT NULL,
    [BusinessPartner]   NVARCHAR (10)  NOT NULL,
    [AddressNumber]     NVARCHAR (10)  NOT NULL,
    [StrdAddress]       NVARCHAR (1)   NULL,
    [addrnumber]        NVARCHAR (10)  NULL,
    [persnumber]        NVARCHAR (10)  NULL,
    [ValidFromDflt]     DATE           NULL,
    [SequenceNumber]    NVARCHAR (3)   NULL,
    [StdSender]         NVARCHAR (1)   NULL,
    [NotUsed]           NVARCHAR (1)   NULL,
    [HomeFlag]          NVARCHAR (1)   NULL,
    [EmailAddress]      NVARCHAR (241) NULL,
    [FlagStdRecipient]  NVARCHAR (1)   NULL,
    [COnSapSys]         NVARCHAR (1)   NULL,
    [RequiredEncoding]  NVARCHAR (1)   NULL,
    [TNEFEncode]        NVARCHAR (1)   NULL,
    [ValidFrom]         NVARCHAR (14)  NULL,
    [ValidTo]           NVARCHAR (14)  NULL,
    [IsDeleted]         BIT            NULL,
    [LDTS]              DATETIME2 (7)  NULL,
    [HashDiff]          BINARY (16)    NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

