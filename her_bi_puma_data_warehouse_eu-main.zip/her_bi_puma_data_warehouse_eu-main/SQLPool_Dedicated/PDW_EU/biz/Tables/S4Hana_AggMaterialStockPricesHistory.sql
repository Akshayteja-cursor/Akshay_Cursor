﻿CREATE TABLE [biz].[S4Hana_AggMaterialStockPricesHistory] (
    [__timestamp]           BIGINT          NULL,
    [Material]              NVARCHAR (40)   NULL,
    [Plant]                 NVARCHAR (4)    NULL,
    [ValuationType]         NVARCHAR (10)   NULL,
    [FiscalYear]            NVARCHAR (4)    NULL,
    [FiscalMonth]           NVARCHAR (2)    NULL,
    [FiscalDay]             NVARCHAR (2)    NULL,
    [PriceControlIndicator] NVARCHAR (1)    NULL,
    [MovingAveragePrice]    NUMERIC (17, 2) NULL,
    [StandardPrice]         NUMERIC (17, 2) NULL,
    [PriceUnit]             NUMERIC (5)     NULL,
    [PriceCurrency]         NVARCHAR (5)    NULL,
    [LastChangedAt]         NUMERIC (15)    NULL,
    [ValidFromDat]          DATE            NULL,
    [ValidToDat]            DATE            NULL,
    [CompanyCode]           NVARCHAR (4)    NULL,
    [Country]               NVARCHAR (3)    NULL,
    [__operation_type]      NVARCHAR (1)    NULL,
    [_LDTS]                 DATETIME2 (7)   NULL,
    [ModifiedOn]            DATETIME        NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = HASH([Material]));

