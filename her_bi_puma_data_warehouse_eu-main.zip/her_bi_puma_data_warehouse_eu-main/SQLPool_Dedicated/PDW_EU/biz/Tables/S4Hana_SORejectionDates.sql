﻿CREATE TABLE [biz].[S4Hana_SORejectionDates] (
    [SoRejectionDate_BK] BIGINT        NULL,
    [SalesDocument]      NVARCHAR (10) NULL,
    [SalesDocumentItem]  NVARCHAR (6)  NULL,
    [RejectionDate]      DATE          NULL,
    [isDeleted]          BIT           NULL,
    [CreatedOn]          DATETIME2 (7) NULL,
    [ModifiedOn]         DATETIME2 (7) NULL,
    [LDTS]               DATETIME2 (7) NULL,
    [HashDiff]           BINARY (16)   NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = HASH([SoRejectionDate_BK]));

