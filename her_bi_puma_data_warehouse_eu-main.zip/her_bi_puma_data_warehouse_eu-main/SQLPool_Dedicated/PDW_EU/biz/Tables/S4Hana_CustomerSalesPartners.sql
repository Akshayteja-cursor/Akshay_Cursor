﻿CREATE TABLE [biz].[S4Hana_CustomerSalesPartners] (
    [CustomerSalesPartners_BK] NVARCHAR (100) NOT NULL,
    [CustomerNumber]           NVARCHAR (10)  NOT NULL,
    [SalesOrganization]        NVARCHAR (4)   NOT NULL,
    [DistributionChannel]      NVARCHAR (2)   NOT NULL,
    [Division]                 NVARCHAR (2)   NOT NULL,
    [PartnerFunction]          NVARCHAR (2)   NOT NULL,
    [PartnerCounter]           NVARCHAR (3)   NOT NULL,
    [Partner]                  NVARCHAR (10)  NULL,
    [Vendor]                   NVARCHAR (8)   NULL,
    [PersonalNumber]           NVARCHAR (8)   NULL,
    [ContactPerson]            NVARCHAR (10)  NULL,
    [Description]              NVARCHAR (30)  NULL,
    [DefaultPartner]           NVARCHAR (1)   NULL,
    [FunctionDescription]      NVARCHAR (20)  NULL,
    [Desccustpartm]            NVARCHAR (35)  NULL,
    [Partnername]              NVARCHAR (35)  NULL,
    [IsDeleted]                BIT            NULL,
    [LDTS]                     DATETIME2 (7)  NULL,
    [HashDiff]                 BINARY (16)    NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

