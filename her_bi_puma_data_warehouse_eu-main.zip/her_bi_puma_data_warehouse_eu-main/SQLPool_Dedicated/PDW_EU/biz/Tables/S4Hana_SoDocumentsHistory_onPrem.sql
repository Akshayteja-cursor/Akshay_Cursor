﻿CREATE TABLE [biz].[S4Hana_SoDocumentsHistory_onPrem] (
    [NatSalesOrderNo]         NVARCHAR (10) NULL,
    [LDTS]                    DATETIME2 (0) NULL,
    [LEDTS]                   DATETIME2 (0) NOT NULL,
    [HashDiff]                BINARY (16)   NULL,
    [SOTypeCode]              NCHAR (4)     NULL,
    [CompanyCode]             NCHAR (4)     NULL,
    [CurrencyCode]            NVARCHAR (5)  NULL,
    [DistributionChannelCode] NCHAR (2)     NULL,
    [CustomerCode_SoldTo]     NVARCHAR (10) NULL,
    [IsDeleted]               BIT           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX ORDER([LDTS]), DISTRIBUTION = HASH([NatSalesOrderNo]));

