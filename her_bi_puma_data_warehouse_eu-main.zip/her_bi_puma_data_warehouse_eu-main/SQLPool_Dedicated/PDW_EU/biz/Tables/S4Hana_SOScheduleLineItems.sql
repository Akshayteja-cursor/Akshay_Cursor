﻿CREATE TABLE [biz].[S4Hana_SOScheduleLineItems] (
    [SalesDocument]                NVARCHAR (10) NOT NULL,
    [SalesDocumentItem]            NVARCHAR (6)  NOT NULL,
    [RequestedDeliveryDate]        DATE          NULL,
    [DeliveryDateMin]              DATE          NULL,
    [DeliveryDateMax]              DATE          NULL,
    [MaterialAvailabilityDate]     DATE          NULL,
    [ConfirmedQty]                 FLOAT (53)    NULL,
    [DeliveredQty]                 FLOAT (53)    NULL,
    [HashDiff]                     BINARY (16)   NULL,
    [DelivBlockReasonForSchedLine] NVARCHAR (2)  NULL,
    [PurchaseRequisition]          NVARCHAR (10) NULL,
    [MinMaterialAvailabilityDate]  DATE          NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = HASH([SalesDocument]));

