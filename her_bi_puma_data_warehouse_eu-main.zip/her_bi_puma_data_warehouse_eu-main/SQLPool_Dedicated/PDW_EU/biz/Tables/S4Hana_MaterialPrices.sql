﻿CREATE TABLE [biz].[S4Hana_MaterialPrices] (
    [MaterialNumber]        NVARCHAR (40)  NOT NULL,
    [SalesOrganisation]     NVARCHAR (10)  NOT NULL,
    [CompanyCode]           NVARCHAR (10)  NULL,
    [DistributionChannel]   NVARCHAR (10)  NOT NULL,
    [Currency]              NVARCHAR (5)   NULL,
    [MaterialPrice_bk]      NVARCHAR (100) NULL,
    [ConditionType]         NVARCHAR (10)  NOT NULL,
    [PriceType]             VARCHAR (10)   NULL,
    [PivotKey]              NVARCHAR (30)  NULL,
    [ValidityStartDate]     DATE           NULL,
    [ValidityEndDate]       DATE           NOT NULL,
    [ConditionRecordNumber] NVARCHAR (30)  NULL,
    [WHPrice]               FLOAT (53)     NULL,
    [_LDTS]                 DATETIME2 (7)  NULL,
    [IsDeleted]             BIT            NULL,
    [HashDiff]              BINARY (16)    NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

