﻿CREATE TABLE [biz].[S4Hana_BPLegacyPartnerData]
(
	[LegacyPartnerData_bk] [nvarchar](110) NOT NULL,
	[partner] [nvarchar](10) NOT NULL,
	[LegacyPartnerType] [nvarchar](50) NOT NULL,
	[LegacyPartnerNumber] [nvarchar](50) NOT NULL,
	[ValidityDtFrom] [datetime2](7) NULL,
	[ValidityDtTo] [datetime2](7) NULL,
	[IsDeleted] [bit] NULL,
	[LDTS] [datetime2](7) NULL,
	[HashDiff] [binary](16) NOT NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
GO
