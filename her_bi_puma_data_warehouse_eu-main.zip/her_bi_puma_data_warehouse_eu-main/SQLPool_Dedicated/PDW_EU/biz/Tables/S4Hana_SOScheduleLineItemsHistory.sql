﻿CREATE TABLE [biz].[S4Hana_SOScheduleLineItemsHistory] (
    [NatSalesOrderNo]                 NVARCHAR (10)   NULL,
    [NatSalesOrderItemNo]             NVARCHAR (6)    NULL,
    [NatSalesOrderItemScheduleLineNo] NVARCHAR (4)    NULL,
    [LDTS]                            DATETIME2 (7)   NULL,
    [LEDTS]                           DATETIME2 (7)   NOT NULL,
    [HashDiff]                        BINARY (16)     NULL,
    [ConfirmedQty]                    DECIMAL (13, 3) NULL,
    [ConfirmedDeliveryDate]           DATE            NULL,
    [IsDeleted]                       TINYINT         NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX ORDER([LDTS]), DISTRIBUTION = HASH([NatSalesOrderNo]));



