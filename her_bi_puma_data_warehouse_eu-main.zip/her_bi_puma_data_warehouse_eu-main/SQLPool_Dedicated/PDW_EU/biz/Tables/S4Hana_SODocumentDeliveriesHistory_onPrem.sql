﻿CREATE TABLE [biz].[S4Hana_SODocumentDeliveriesHistory_onPrem] (
    [NatSalesOrderNo]         NVARCHAR (10) NULL,
    [NatSalesOrderItemNo]     NVARCHAR (6)  NULL,
    [ScheduleLine]            NVARCHAR (4)  NULL,
    [DeliveryNoteNumber]      NVARCHAR (10) NULL,
    [DeliveryNoteItemNo]      NVARCHAR (6)  NULL,
    [LDTS]                    DATETIME2 (7) NULL,
    [LEDTS]                   DATETIME2 (0) NOT NULL,
    [HashDiff]                BINARY (16)   NULL,
    [DeliveryStatus]          NCHAR (1)     NULL,
    [ActualGoodsMovementDate] DATE          NULL,
    [NatSalesOrderDeleted]    NCHAR (1)     NULL,
    [IsDeleted]               TINYINT       NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX ORDER([LDTS]), DISTRIBUTION = HASH([NatSalesOrderNo]));

