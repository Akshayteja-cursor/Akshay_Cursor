﻿CREATE TABLE [biz].[S4Hana_SoDocumentItemsHistory] (
    [SoDocumentItemHistoryId]       BIGINT           IDENTITY (1, 1) NOT NULL,
    [NatSalesOrderNo]               NVARCHAR (10)    NOT NULL,
    [NatSalesOrderItemNo]           NVARCHAR (6)     NOT NULL,
    [LDTS]                          DATETIME2 (7)    NULL,
    [LEDTS]                         DATETIME2 (7)    NOT NULL,
    [HashDiff]                      BINARY (16)      NULL,
    [CompanyCode]                   NVARCHAR (4)     NULL,
    [CustomerCode_SoldTo]           NVARCHAR (10)    NULL,
    [CurrencyCode]                  NVARCHAR (5)     NULL,
    [DistributionChannelCode]       NVARCHAR (2)     NULL,
    [SOTypeCode]                    NVARCHAR (4)     NULL,
    [MaterialNumber]                NVARCHAR (40)    NULL,
    [OrderQuantity]                 DECIMAL (15, 3)  NULL,
    [NetAmount]                     DECIMAL (15, 2)  NULL,
    [NetAmountUnit]                 DECIMAL (38, 25) NULL,
    [RejectionReason]               NVARCHAR (2)     NULL,
    [ReferenceDocumentNumber]       NVARCHAR (10)    NULL,
    [ReferenceDocumentItemNumber]   NVARCHAR (6)     NULL,
    [PrecedingDocumentCategory]     NVARCHAR (4)     NULL,
    [GrossSalesValue]               DECIMAL (15, 2)  NULL,
    [GrossSalesValueUnit]           DECIMAL (38, 25) NULL,
    [SalesSeason]                   NVARCHAR (14)    NULL,
    [IsDeleted]                     TINYINT          NULL,
    [LatestCDD]                     DATE             NULL,
    [LatestRDD]                     DATE             NULL,
    [OriginalRequestedDeliveryDate] DATE             NULL,
    [FirstConfirmedDeliveryDate]    DATE             NULL,
    [SalesOrganization]             NVARCHAR (4)     NULL,
    [SalesDocumentItemCategory]     NVARCHAR (4)     NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX ORDER([LDTS]), DISTRIBUTION = HASH([NatSalesOrderNo]));


GO
CREATE NONCLUSTERED INDEX [IX_SoItemsHistory_Join]
    ON [biz].[S4Hana_SoDocumentItemsHistory]([NatSalesOrderNo] ASC, [NatSalesOrderItemNo] ASC, [LDTS] ASC, [LEDTS] ASC);

