﻿CREATE TABLE [biz].[s4hana_SoDocumentItemQtysHistory_onPrem] (
    [NatSalesorderNo]     CHAR (10)     NULL,
    [NatSalesOrderItemNo] CHAR (6)      NULL,
    [LDTS]                DATETIME2 (7) NULL,
    [LEDTS]               DATETIME2 (7) NOT NULL,
    [OrderQuantity]       INT           NULL,
    [IsDeleted]           BIT           NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX ORDER([LDTS]), DISTRIBUTION = HASH([NatSalesorderNo]));

