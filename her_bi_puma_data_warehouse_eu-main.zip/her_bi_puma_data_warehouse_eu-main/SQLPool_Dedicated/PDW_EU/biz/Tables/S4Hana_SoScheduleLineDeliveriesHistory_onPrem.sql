﻿CREATE TABLE [biz].[S4Hana_SoScheduleLineDeliveriesHistory_onPrem] (
    [NatSalesOrderNo]        NVARCHAR (10)   NULL,
    [NatSalesOrderItemNo]    NVARCHAR (6)    NULL,
    [LDTS]                   DATETIME2 (7)   NULL,
    [LEDTS]                  DATETIME2 (7)   NOT NULL,
    [HashDiff]               BINARY (16)     NULL,
    [MinScheduleLineDate]    DATE            NULL,
    [MaxScheduleLineDate]    DATE            NULL,
    [MinPre_IntSOStatusCode] SMALLINT        NULL,
    [MaxPre_IntSOStatusCode] SMALLINT        NULL,
    [ConfirmedOrderQuantity] DECIMAL (15, 3) NULL,
    [Pre_OOHUnits]           DECIMAL (15, 3) NULL,
    [IsDeleted]              SMALLINT        NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX ORDER([LDTS]), DISTRIBUTION = HASH([NatSalesOrderNo]));

