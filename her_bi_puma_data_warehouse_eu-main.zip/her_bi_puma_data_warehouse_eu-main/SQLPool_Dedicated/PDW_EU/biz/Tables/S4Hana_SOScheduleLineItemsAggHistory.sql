﻿CREATE TABLE [biz].[S4Hana_SOScheduleLineItemsAggHistory] (
    [NatSalesOrderNo]       NVARCHAR (10)   NULL,
    [NatSalesOrderItemNo]   NVARCHAR (6)    NULL,
    [LDTS]                  DATETIME2 (7)   NULL,
    [LEDTS]                 DATETIME2 (7)   NOT NULL,
    [HashDiff]              BINARY (16)     NULL,
    [MinSODeliveryDate]     DATE            NULL,
    [MaxSODeliveryDate]     DATE            NULL,
    [ConfirmedQty]          DECIMAL (13, 3) NULL,
    [ConfirmedDeliveryDate] DATE            NULL,
    [IsDeleted]             TINYINT         NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX ORDER([LDTS]), DISTRIBUTION = HASH([NatSalesOrderNo]));


GO
CREATE NONCLUSTERED INDEX [IX_SOSL_Agg_OOH_Join]
    ON [biz].[S4Hana_SOScheduleLineItemsAggHistory]([NatSalesOrderNo] ASC, [NatSalesOrderItemNo] ASC, [LDTS] ASC, [LEDTS] ASC);

