﻿CREATE TABLE [biz].[S4Hana_POPricingConditions] (
    [PricingDocument]         NVARCHAR (10)   NULL,
    [PricingDocumentItem]     NVARCHAR (6)    NULL,
    [PricingProcedureStep]    NVARCHAR (3)    NULL,
    [PricingProcedureCounter] NVARCHAR (3)    NULL,
    [CompanyCode]             NVARCHAR (4)    NULL,
    [ConditionApplication]    NVARCHAR (2)    NULL,
    [ConditionTypeCode]       NVARCHAR (4)    NULL,
    [ConditionAmount]         DECIMAL (15, 2) NULL,
    [IsDeleted]               BIT             NULL,
    [LDTS]                    DATETIME2 (7)   NULL,
    [HashDiff]                BINARY (16)     NULL
)
WITH (CLUSTERED INDEX([PricingDocument], [PricingDocumentItem], [PricingProcedureStep], [PricingProcedureCounter]), DISTRIBUTION = HASH([PricingDocument]));



