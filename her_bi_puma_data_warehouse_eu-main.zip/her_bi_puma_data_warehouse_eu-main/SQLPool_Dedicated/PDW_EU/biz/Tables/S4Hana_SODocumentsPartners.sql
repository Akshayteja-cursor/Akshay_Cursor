﻿CREATE TABLE [biz].[S4Hana_SODocumentsPartners] (
    [SalesDocument]     NVARCHAR (10) NOT NULL,
    [SalesDocumentItem] NVARCHAR (6)  NOT NULL,
    [AD]                NVARCHAR (10) NULL,
    [AP]                NVARCHAR (10) NULL,
    [SP]                NVARCHAR (10) NULL,
    [ZW]                NVARCHAR (10) NULL,
    [LDTS]              DATETIME2 (7) NULL
)
WITH (CLUSTERED INDEX([LDTS], [SalesDocument]), DISTRIBUTION = HASH([SalesDocument]));



