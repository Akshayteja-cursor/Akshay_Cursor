﻿CREATE TABLE [biz].[S4Hana_DeliveryDocumentAggSoItemsHistory] (
    [DeliveryDocumentAggSoItemHistoryId] BIGINT          IDENTITY (1, 1) NOT NULL,
    [NatSalesOrderNo]                    NVARCHAR (10)   NOT NULL,
    [NatSalesOrderItemNo]                NVARCHAR (6)    NOT NULL,
    [LDTS]                               DATETIME2 (7)   NULL,
    [LEDTS]                              DATETIME2 (7)   NOT NULL,
    [HashDiff]                           BINARY (16)     NULL,
    [ActualDeliveryQuantity]             DECIMAL (13, 3) NULL,
    [IsDeleted]                          TINYINT         NULL,
    [CompletedDeliveryQuantity]          DECIMAL (13, 3) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX ORDER([LDTS]), DISTRIBUTION = HASH([NatSalesOrderNo]));


GO
CREATE NONCLUSTERED INDEX [IX_DD_Agg_OOH_Join]
    ON [biz].[S4Hana_DeliveryDocumentAggSoItemsHistory]([NatSalesOrderNo] ASC, [NatSalesOrderItemNo] ASC, [LDTS] ASC, [LEDTS] ASC);

