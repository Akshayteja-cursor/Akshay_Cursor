﻿CREATE TABLE [biz].[S4Hana_DeliveryDocuments] (
    [DeliveryNoteNumber]         NVARCHAR (10)   NULL,
    [CreationDate]               DATE            NULL,
    [DeliveryDate]               DATE            NULL,
    [OverallGoodsMovementStatus] NCHAR (1)       NULL,
    [OverallPackingStatus]       NCHAR (1)       NULL,
    [OverallSDProcessStatus]     NCHAR (1)       NULL,
    [CustomerCode_SoldTo]        NVARCHAR (10)   NULL,
    [TransactionCurrency]        NVARCHAR (5)    NULL,
    [ActualGoodsMovementDate]    DATE            NULL,
    [DeliveryNoteDocType]        NCHAR (4)       NULL,
    [SalesOrganization]          NCHAR (4)       NULL,
    [LDTS]                       DATETIME2 (7)   NULL,
    [HashDiff]                   BINARY (16)     NULL,
    [TotalCreditCheckStatus]     NCHAR (1)       NULL,
    [MeansOfTransport]           NVARCHAR (20)   NULL,
    [SpecialProcessingCode]      NVARCHAR (4)    NULL,
    [ActualLoadingDate]          DATE            NULL,
    [GrossWeight]                DECIMAL (15, 3) NULL,
    [DeliveryDocumentBySupplier] NVARCHAR (35)   NULL,
    [SDDocumentCategory]         NVARCHAR (4)    NULL,
    [SpecialLogisticsProcess]    NVARCHAR (2)    NULL,
    [OverallBillingStatus]       NVARCHAR (1)    NULL,
    [PlannedGoodsIssueDate]      DATE            NULL,
    [GoodsIssueDate]             DATE            NULL,
    [ConfBookingInDate]          DATE            NULL,
    [ConfBookingInTime]          BIGINT          NULL,
    [BookingInDate]              DATE            NULL
)
WITH (CLUSTERED INDEX([LDTS], [DeliveryNoteNumber]), DISTRIBUTION = HASH([DeliveryNoteNumber]));









