﻿CREATE TABLE [biz].[S4Hana_SOSupplyAssignments] (
    [ARunId]                NVARCHAR (36)   NULL,
    [SalesOrderNo]          NVARCHAR (10)   NULL,
    [SalesOrderItemNo]      NVARCHAR (6)    NULL,
    [ARunStatus]            NVARCHAR (1)    NULL,
    [AssignedQuantityARun]  DECIMAL (13, 3) NULL,
    [SalesOrganizationCode] NVARCHAR (4)    NULL,
    [IsDeleted]             BIT             NULL,
    [LDTS]                  DATETIME2 (7)   NULL,
    [HashDiff]              BINARY (16)     NULL,
    [StockSource]           NVARCHAR (1)    NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX ORDER([LDTS]), DISTRIBUTION = HASH([SalesOrderNo]));



