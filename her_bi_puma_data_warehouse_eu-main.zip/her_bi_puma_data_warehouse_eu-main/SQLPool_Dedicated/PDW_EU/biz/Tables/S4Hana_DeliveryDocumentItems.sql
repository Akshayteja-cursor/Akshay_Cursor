﻿CREATE TABLE [biz].[S4Hana_DeliveryDocumentItems] (
    [DeliveryNoteNumber]             NVARCHAR (10)   NULL,
    [DeliveryNoteItemNo]             NVARCHAR (6)    NULL,
    [ReferenceDocumentNo]            NVARCHAR (10)   NULL,
    [ReferenceDocumentItemNo]        NVARCHAR (6)    NULL,
    [MaterialNumber]                 NVARCHAR (40)   NULL,
    [SiteCode]                       NCHAR (4)       NULL,
    [ActualDeliveryQuantity]         DECIMAL (17, 3) NULL,
    [ActualDeliveryQuantityBaseUnit] DECIMAL (17, 3) NULL,
    [OriginalDeliveryQuantity]       DECIMAL (17, 3) NULL,
    [DeliveryQuantityUnit]           DECIMAL (17, 3) NULL,
    [CreatedByUser]                  NVARCHAR (12)   NULL,
    [DistributionChannel]            NVARCHAR (2)    NULL,
    [StorageLocation]                NVARCHAR (4)    NULL,
    [ProfitCenter]                   NVARCHAR (10)   NULL,
    [SDProcessStatus]                NVARCHAR (1)    NULL,
    [RequirementSegment]             NVARCHAR (40)   NULL,
    [StockSegment]                   NVARCHAR (40)   NULL,
    [IsDeleted]                      BIT             NULL,
    [LDTS]                           DATETIME2 (7)   NULL,
    [HashDiff]                       BINARY (16)     NULL,
    [ProductAvailabilityDate]        DATE            NULL,
    [ProductAvailabilityTime]        BIGINT          NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX ORDER([LDTS]), DISTRIBUTION = HASH([DeliveryNoteNumber]));



