﻿CREATE TABLE [biz].[S4Hana_DeliveryDocumentsHistory] (
    [DeliveryDocumentHistoryId] BIGINT        IDENTITY (1, 1) NOT NULL,
    [DeliveryNoteNumber]        NVARCHAR (10) NOT NULL,
    [LDTS]                      DATETIME2 (7) NULL,
    [LEDTS]                     DATETIME2 (7) NULL,
    [HashDiff]                  BINARY (16)   NULL,
    [ActualGoodsMovementDate]   DATE          NULL,
    [IsDeleted]                 TINYINT       NULL,
    [OverallBillingStatus]      NVARCHAR (1)  NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX ORDER([LDTS]), DISTRIBUTION = HASH([DeliveryNoteNumber]));

