﻿CREATE TABLE [biz].[S4Hana_AggSOSupplyAssignments] (
    [SalesOrderNo]     NVARCHAR (10)   NULL,
    [SalesOrderItemNo] NVARCHAR (6)    NULL,
    [IntPupMasterId]   INT             NULL,
    [FQty]             DECIMAL (13, 3) NULL,
    [HQty]             DECIMAL (13, 3) NULL,
    [RQty]             DECIMAL (13, 3) NULL,
    [LDTS]             DATETIME2 (7)   NULL,
    [HashDiff]         BINARY (16)     NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX ORDER([LDTS]), DISTRIBUTION = HASH([SalesOrderNo]));

