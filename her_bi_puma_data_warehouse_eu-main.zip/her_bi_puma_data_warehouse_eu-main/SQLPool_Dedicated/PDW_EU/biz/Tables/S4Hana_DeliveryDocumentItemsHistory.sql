﻿CREATE TABLE [biz].[S4Hana_DeliveryDocumentItemsHistory] (
    [DeliveryDocumentItemHistoryId] BIGINT          IDENTITY (1, 1) NOT NULL,
    [DeliveryNoteNumber]            NVARCHAR (10)   NOT NULL,
    [DeliveryNoteItemNo]            NVARCHAR (6)    NOT NULL,
    [LDTS]                          DATETIME2 (7)   NULL,
    [LEDTS]                         DATETIME2 (7)   NULL,
    [HashDiff]                      BINARY (16)     NULL,
    [NatSalesOrderNo]               NVARCHAR (10)   NULL,
    [NatSalesOrderItemNo]           NVARCHAR (6)    NULL,
    [ActualDeliveryQuantity]        DECIMAL (13, 3) NULL,
    [IsDeleted]                     TINYINT         NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX ORDER([LDTS]), DISTRIBUTION = HASH([NatSalesOrderNo]));

