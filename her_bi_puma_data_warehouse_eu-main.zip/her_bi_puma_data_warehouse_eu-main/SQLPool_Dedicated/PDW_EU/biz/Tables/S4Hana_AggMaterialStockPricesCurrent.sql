﻿CREATE TABLE [biz].[S4Hana_AggMaterialStockPricesCurrent] (
    [Material]              NVARCHAR (40)   NULL,
    [Plant]                 NVARCHAR (4)    NULL,
    [PriceControlIndicator] NVARCHAR (1)    NULL,
    [MovingAveragePrice]    NUMERIC (17, 2) NULL,
    [StandardPrice]         NUMERIC (17, 2) NULL,
    [PriceCurrency]         NVARCHAR (5)    NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = HASH([Material]));

