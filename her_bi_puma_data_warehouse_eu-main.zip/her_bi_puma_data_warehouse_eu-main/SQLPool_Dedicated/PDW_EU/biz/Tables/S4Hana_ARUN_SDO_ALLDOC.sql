﻿CREATE TABLE [biz].[S4Hana_ARUN_SDO_ALLDOC] (
    [ARunid]           NVARCHAR (40)   NOT NULL,
    [SOPO_bk]          NVARCHAR (50)   NULL,
    [SalesOrderNo]     NVARCHAR (10)   NULL,
    [SalesOrderItemNo] NVARCHAR (6)    NULL,
    [PONo]             NVARCHAR (10)   NULL,
    [supplytype]       NVARCHAR (1)    NULL,
    [Delivery_Date_PO] NVARCHAR (20)   NULL,
    [LDTS]             DATETIME2 (7)   NULL,
    [IsDeleted]        BIT             NULL,
    [HashDiff]         BINARY (16)     NULL,
    [ALLOC_QTY]        DECIMAL (13, 3) NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX ORDER([LDTS]), DISTRIBUTION = HASH([SOPO_bk]));

