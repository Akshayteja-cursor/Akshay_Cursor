﻿CREATE TABLE [biz].[S4Hana_POAssignments] (
    [POAssignments_BK]        NVARCHAR (100) NOT NULL,
    [PONo]                    NVARCHAR (10)  NOT NULL,
    [POItemNo]                NVARCHAR (5)   NOT NULL,
    [AccountAssignmentNumber] NVARCHAR (2)   NOT NULL,
    [SalesOrderNo]            NVARCHAR (10)  NULL,
    [SalesOrderItemNo]        NVARCHAR (6)   NULL,
    [SalesOrderScheduleLine]  NVARCHAR (4)   NULL,
    [IsDeleted]               BIT            NULL,
    [LDTS]                    DATETIME2 (7)  NULL,
    [HashDiff]                BINARY (16)    NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

