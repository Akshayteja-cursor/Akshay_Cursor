﻿CREATE TABLE [biz].[S4Hana_PODocumentItems] (
    [PONo]                      NVARCHAR (10)   NULL,
    [POItemNo]                  NVARCHAR (5)    NULL,
    [DeletionCode]              NVARCHAR (1)    NULL,
    [IsCompletelyDelivered]     NVARCHAR (1)    NULL,
    [MaterialNumber]            NVARCHAR (40)   NULL,
    [EAN]                       NVARCHAR (18)   NULL,
    [FactoryCode]               NVARCHAR (10)   NULL,
    [SiteCode]                  NVARCHAR (4)    NULL,
    [RequestedDeliveryDate]     DATE            NULL,
    [OrderQuantity]             DECIMAL (13, 3) NULL,
    [NetAmount]                 DECIMAL (13, 2) NULL,
    [PlannedDeliveryDate]       DATE            NULL,
    [LastConfirmedDeliveryDate] DATE            NULL,
    [ExpectedHandoverDate]      DATE            NULL,
    [ActualHandoverDate]        DATE            NULL,
    [CountryOfOrigin]           NVARCHAR (2)    NULL,
    [ShippingInstructionCode]   NVARCHAR (2)    NULL,
    [IsDeleted]                 BIT             NULL,
    [LDTS]                      DATETIME2 (7)   NULL,
    [HashDiff]                  BINARY (16)     NOT NULL,
    [StorageLocation]           NVARCHAR (4)    NULL,
    [StockSegment]              NVARCHAR (40)   NULL,
    [ISSSTORLOCSTO]             NVARCHAR (4)    NULL,
    [LegacyPONumber]            NVARCHAR (10)   NULL,
    [LegacyPOItemNumber]        NVARCHAR (6)    NULL,
    [RequisitionerName]         NVARCHAR (12)   NULL
)
WITH (CLUSTERED INDEX([PONo], [POItemNo]), DISTRIBUTION = HASH([PONo]));





