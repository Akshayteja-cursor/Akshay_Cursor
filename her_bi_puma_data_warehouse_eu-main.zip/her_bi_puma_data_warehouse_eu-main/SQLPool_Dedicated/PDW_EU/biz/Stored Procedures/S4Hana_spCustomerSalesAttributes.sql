﻿CREATE PROC [biz].[S4Hana_spCustomerSalesAttributes] @ldts [DATETIME2](7) AS
BEGIN
	SET NOCOUNT ON;
	SET ANSI_WARNINGS ON;

	DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
	DECLARE @ExecStart DATETIME2(7) = GETDATE()
	DECLARE @SourceLastLoadDate DATETIME2(7)
	DECLARE @DestinationLastLoadDate DATETIME2(7)
	DECLARE @BatchLdts DATETIME2(7) = @LDTS
	DECLARE @AffectedRows BIGINT = NULL

	IF(EXISTS(SELECT 1 FROM [biz].[S4Hana_CustomerSalesAttributes]))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(LDTS))
	FROM [biz].[S4Hana_CustomerSalesAttributes]
	END
	ELSE BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

	IF(EXISTS(SELECT 1 FROM stag.[S4Hana_CustomerSalesAttributes]))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(_LDTS))
		FROM stag.[S4Hana_CustomerSalesAttributes]
	END
	ELSE BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END 


	--Log Data load
	INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'S4Hana_spCustomerSalesAttributes'
			,'biz_CustomerSalesAttributess'
			,'S4Hana_CustomerSalesAttributes'
			,'biz'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts


	IF OBJECT_ID(N'tempdb..#csa') IS NOT NULL
	DROP TABLE #csa;

	SELECT
	   CONCAT([Customer], '|', [SalesOrganization], '|', [DistributionChannel], '|',[Division]) AS CustomerSalesAttributes_BK
	  ,[Customer]
      ,[SalesOrganization]
      ,[DistributionChannel]
      ,[Division]
      ,[CustomerABCClassification]
      ,[SalesOffice]
      ,[SalesGroup]
      ,[OrderIsBlockedForCustomer]
      ,[Currency]
      ,[CustomerPriceGroup]
      ,[PriceListType]
      ,[DeliveryPriority]
      ,[ShippingCondition]
      ,[IncotermsClassification]
      ,[SupplyingPlant]
      ,[CompleteDeliveryIsDefined]
      ,[DeliveryIsBlockedForCustomer]
      ,[BillingIsBlockedForCustomer]
      ,[CustomerPaymentTerms]
      ,[CustomerAccountAssignmentGroup]
      ,[AccountByCustomer]
      ,[CustomerGroup]
      ,[CustomerGroupName]
      ,[CustomerPricingProcedure]
      ,[OrderCombinationIsAllowed]
      ,[PartialDeliveryIsAllowed]
      ,[InvoiceDate]
      ,[PaymentTerms]
      ,[IncotermsTransferLocation]
      ,[ItemOrderProbabilityInPercent]
      ,[IncotermsLocation2]
      ,[AuthorizationGroup]
      ,[SalesDistrict]
      ,[IncotermsVersion]
      ,[IncotermsLocation1]
      ,[DeletionIndicator]
      ,[IsBusinessPurposeCompleted]
      ,[SalesItemProposal]
      ,[CustProdProposalProcedure]
      ,[MaxNmbrOfPartialDelivery]
      ,[UnderdelivTolrtdLmtRatioInPct]
      ,[OverdelivTolrtdLmtRatioInPct]
      ,[IsActiveEntity]
      ,[AdditionalCustomerGroup1]
      ,[AdditionalCustomerGroup2]
      ,[AdditionalCustomerGroup3]
      ,[AdditionalCustomerGroup4]
      ,[AdditionalCustomerGroup5]
      ,[InvoiceListSchedule]
      ,[ExchangeRateType]
      ,[PaymentGuaranteeProcedure]
      ,[DeliverySplitStrategy]
      ,[InvoiceSplitStrategy]
      ,[TermsOfPayment]
      ,[SalesRepType]
      ,[B2BOrderHistory]
      ,[OrderNumber]
      ,[CostCenter]
      ,[RetCreditNoteSStrategy]
      ,[DC10SportsSpecial]
      ,[DC20Sports]
      ,[DC30SportStyle]
      ,[DC40SportLifest]
      ,[DC50Lifestyle]
      ,[DC60Fashion]
      ,[DC35SportStylePlus]
      ,[DC45LifestylePlus]
      ,[DC90Distributer]
      ,[DC90B2B]
      ,[DC92InternalSales]
      ,[DC93MonobrandFranchiseStore]
      ,[DC94MassMerchant]
      ,[DC95Clearance]
      ,[DC99Others]
      ,[DC31Performance]
      ,[PumaDistributionChannel]
      ,[LocalCustomerGroup]
      ,[AreaAccount]
      ,[AccountRole]
      ,[CustomerStructure]
      ,[MainCustomer]
      ,[MasterCustomer]
      ,[ReportingGroup10]
      ,[LaunchDateBuffer]
      ,[Specialist]
      ,[NeveroutofStock]
      ,[LocalOwnerGroup]
      ,[TeamBusinessSpecIdentification]
      ,[ShopName]
      ,[AccountType]
      ,[EDI]
      ,[CallCenterCampaign]
      ,[CommercialOperations]
      ,[EarlyShipment]
      ,[RestrictProdAccess]
      ,[RetailAdditionalCustomerGrp6]
      ,[RetailAdditionalCustomerGrp7]
      ,[RetailAdditionalCustomerGrp8]
      ,[RetailAdditionalCustomerGrp9]
      ,[RetailAdditionalCustomerGrp10]
      ,[credit_limit]
      ,[xblocked]
      ,[block_reason]
      ,[Companycode]
      ,[CreditControlArea]
      ,[Postingblockforcompanycode]
      ,[DeletionFlagCompanyCodeLevel]
      ,[BlockKeyforPayment]
      ,[DunningArea]
      ,[DunningBlock]
	  ,[TierDC10]
	  ,[TierDC20]
	  ,[TierDC30]
	  ,[TierDC40]
	  ,[TierDC45]
	  ,[TierDC50]
	  ,[TierDC60]
	  ,IsDeleted       
      ,[_LDTS] as LDTS
	  ,CONVERT([BINARY](16),
				HASHBYTES('MD5',CONCAT(
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Customer]                      )))),'_',     
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SalesOrganization]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DistributionChannel]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Division]					  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CustomerABCClassification]	  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SalesOffice]					  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SalesGroup]					  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[OrderIsBlockedForCustomer]	  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Currency]					  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CustomerPriceGroup]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PriceListType]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DeliveryPriority]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ShippingCondition]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[IncotermsClassification]		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SupplyingPlant]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CompleteDeliveryIsDefined]	  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DeliveryIsBlockedForCustomer]  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[BillingIsBlockedForCustomer]	  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CustomerPaymentTerms]		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CustomerAccountAssignmentGroup])))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[AccountByCustomer]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CustomerGroup]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CustomerGroupName]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CustomerPricingProcedure]	  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[OrderCombinationIsAllowed]	  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PartialDeliveryIsAllowed]	  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[InvoiceDate]					  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PaymentTerms]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[IncotermsTransferLocation]	  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ItemOrderProbabilityInPercent] )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[IncotermsLocation2]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[AuthorizationGroup]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SalesDistrict]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[IncotermsVersion]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[IncotermsLocation1]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DeletionIndicator]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[IsBusinessPurposeCompleted]	  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SalesItemProposal]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CustProdProposalProcedure]	  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[MaxNmbrOfPartialDelivery]	  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[UnderdelivTolrtdLmtRatioInPct] )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[OverdelivTolrtdLmtRatioInPct]  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[IsActiveEntity]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[AdditionalCustomerGroup1]	  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[AdditionalCustomerGroup2]	  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[AdditionalCustomerGroup3]	  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[AdditionalCustomerGroup4]	  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[AdditionalCustomerGroup5]	  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[InvoiceListSchedule]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ExchangeRateType]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PaymentGuaranteeProcedure]	  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DeliverySplitStrategy]		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[InvoiceSplitStrategy]		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TermsOfPayment]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SalesRepType]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[B2BOrderHistory]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[OrderNumber]					  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CostCenter]					  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[RetCreditNoteSStrategy]		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DC10SportsSpecial]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DC20Sports]					  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DC30SportStyle]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DC40SportLifest]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DC50Lifestyle]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DC60Fashion]					  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DC35SportStylePlus]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DC45LifestylePlus]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DC90Distributer]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DC90B2B]						  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DC92InternalSales]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DC93MonobrandFranchiseStore]	  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DC94MassMerchant]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DC95Clearance]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DC99Others]					  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DC31Performance]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PumaDistributionChannel]		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[LocalCustomerGroup]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[AreaAccount]					  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[AccountRole]					  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CustomerStructure]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[MainCustomer]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[MasterCustomer]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ReportingGroup10]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[LaunchDateBuffer]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Specialist]					  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[NeveroutofStock]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[LocalOwnerGroup]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TeamBusinessSpecIdentification])))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ShopName]					  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[AccountType]					  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[EDI]							  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CallCenterCampaign]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CommercialOperations]		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[EarlyShipment]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[RestrictProdAccess]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[RetailAdditionalCustomerGrp6]  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[RetailAdditionalCustomerGrp7]  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[RetailAdditionalCustomerGrp8]  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[RetailAdditionalCustomerGrp9]  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[RetailAdditionalCustomerGrp10] )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[credit_limit]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[xblocked]					  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[block_reason]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Companycode]					  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CreditControlArea]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Postingblockforcompanycode]	  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DeletionFlagCompanyCodeLevel]  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[BlockKeyforPayment]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DunningArea]					  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DunningBlock] 				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TierDC10] 					  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TierDC20] 					  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TierDC30] 					  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TierDC40] 					  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TierDC45] 					  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TierDC50] 					  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TierDC60] 					  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[IsDeleted]))))))       
			) AS HashDiff

INTO #csa
FROM
(
	SELECT
	   *
	  ,CAST(CASE WHEN __operation_type = 'X' 
					THEN 1 ELSE 0 END AS BIT)					AS IsDeleted
      ,ROW_NUMBER() OVER (PARTITION BY Customer
									, SalesOrganization
									, DistributionChannel	
									, Division
						ORDER BY _LDTS DESC
								, __timestamp DESC)				AS RN
	FROM stag.S4Hana_CustomerSalesAttributes

) X
WHERE RN = 1
and [_LDTS] > @ldts
	
		-- count new Records for S4Hana_CustomerSalesAttributes
		    SELECT @AffectedRows = COUNT(*)
			FROM #csa AS stg LEFT JOIN biz.S4Hana_CustomerSalesAttributes AS prd 
			ON prd.CustomerSalesAttributes_BK = stg.CustomerSalesAttributes_BK 
			WHERE prd.CustomerSalesAttributes_BK IS NULL

   --load new
   INSERT INTO biz.S4Hana_CustomerSalesAttributes
			(
				 CustomerSalesAttributes_BK
	            ,[Customer]
                ,[SalesOrganization]
                ,[DistributionChannel]
                ,[Division]
                ,[CustomerABCClassification]
                ,[SalesOffice]
                ,[SalesGroup]
                ,[OrderIsBlockedForCustomer]
                ,[Currency]
                ,[CustomerPriceGroup]
                ,[PriceListType]
                ,[DeliveryPriority]
                ,[ShippingCondition]
                ,[IncotermsClassification]
                ,[SupplyingPlant]
                ,[CompleteDeliveryIsDefined]
                ,[DeliveryIsBlockedForCustomer]
                ,[BillingIsBlockedForCustomer]
                ,[CustomerPaymentTerms]
                ,[CustomerAccountAssignmentGroup]
                ,[AccountByCustomer]
                ,[CustomerGroup]
                ,[CustomerGroupName]
                ,[CustomerPricingProcedure]
                ,[OrderCombinationIsAllowed]
                ,[PartialDeliveryIsAllowed]
                ,[InvoiceDate]
                ,[PaymentTerms]
                ,[IncotermsTransferLocation]
                ,[ItemOrderProbabilityInPercent]
                ,[IncotermsLocation2]
                ,[AuthorizationGroup]
                ,[SalesDistrict]
                ,[IncotermsVersion]
                ,[IncotermsLocation1]
                ,[DeletionIndicator]
                ,[IsBusinessPurposeCompleted]
                ,[SalesItemProposal]
                ,[CustProdProposalProcedure]
                ,[MaxNmbrOfPartialDelivery]
                ,[UnderdelivTolrtdLmtRatioInPct]
                ,[OverdelivTolrtdLmtRatioInPct]
                ,[IsActiveEntity]
                ,[AdditionalCustomerGroup1]
                ,[AdditionalCustomerGroup2]
                ,[AdditionalCustomerGroup3]
                ,[AdditionalCustomerGroup4]
                ,[AdditionalCustomerGroup5]
                ,[InvoiceListSchedule]
                ,[ExchangeRateType]
                ,[PaymentGuaranteeProcedure]
                ,[DeliverySplitStrategy]
                ,[InvoiceSplitStrategy]
                ,[TermsOfPayment]
                ,[SalesRepType]
                ,[B2BOrderHistory]
                ,[OrderNumber]
                ,[CostCenter]
                ,[RetCreditNoteSStrategy]
                ,[DC10SportsSpecial]
                ,[DC20Sports]
                ,[DC30SportStyle]
                ,[DC40SportLifest]
                ,[DC50Lifestyle]
                ,[DC60Fashion]
                ,[DC35SportStylePlus]
                ,[DC45LifestylePlus]
                ,[DC90Distributer]
                ,[DC90B2B]
                ,[DC92InternalSales]
                ,[DC93MonobrandFranchiseStore]
                ,[DC94MassMerchant]
                ,[DC95Clearance]
                ,[DC99Others]
                ,[DC31Performance]
                ,[PumaDistributionChannel]
                ,[LocalCustomerGroup]
                ,[AreaAccount]
                ,[AccountRole]
                ,[CustomerStructure]
                ,[MainCustomer]
                ,[MasterCustomer]
                ,[ReportingGroup10]
                ,[LaunchDateBuffer]
                ,[Specialist]
                ,[NeveroutofStock]
                ,[LocalOwnerGroup]
                ,[TeamBusinessSpecIdentification]
                ,[ShopName]
                ,[AccountType]
                ,[EDI]
                ,[CallCenterCampaign]
                ,[CommercialOperations]
                ,[EarlyShipment]
                ,[RestrictProdAccess]
                ,[RetailAdditionalCustomerGrp6]
                ,[RetailAdditionalCustomerGrp7]
                ,[RetailAdditionalCustomerGrp8]
                ,[RetailAdditionalCustomerGrp9]
                ,[RetailAdditionalCustomerGrp10]
                ,[credit_limit]
                ,[xblocked]
                ,[block_reason]
                ,[Companycode]
                ,[CreditControlArea]
                ,[Postingblockforcompanycode]
                ,[DeletionFlagCompanyCodeLevel]
                ,[BlockKeyforPayment]
                ,[DunningArea]
                ,[DunningBlock]
				,[TierDC10]
				,[TierDC20]
				,[TierDC30]
				,[TierDC40]
				,[TierDC45]
				,[TierDC50]
				,[TierDC60]
	            ,IsDeleted       
                ,LDTS
				,[HashDiff]			
			)
	SELECT 
				 stg.CustomerSalesAttributes_BK
	            ,stg.[Customer]
                ,stg.[SalesOrganization]
                ,stg.[DistributionChannel]
                ,stg.[Division]
                ,stg.[CustomerABCClassification]
                ,stg.[SalesOffice]
                ,stg.[SalesGroup]
                ,stg.[OrderIsBlockedForCustomer]
                ,stg.[Currency]
                ,stg.[CustomerPriceGroup]
                ,stg.[PriceListType]
                ,stg.[DeliveryPriority]
                ,stg.[ShippingCondition]
                ,stg.[IncotermsClassification]
                ,stg.[SupplyingPlant]
                ,stg.[CompleteDeliveryIsDefined]
                ,stg.[DeliveryIsBlockedForCustomer]
                ,stg.[BillingIsBlockedForCustomer]
                ,stg.[CustomerPaymentTerms]
                ,stg.[CustomerAccountAssignmentGroup]
                ,stg.[AccountByCustomer]
                ,stg.[CustomerGroup]
                ,stg.[CustomerGroupName]
                ,stg.[CustomerPricingProcedure]
                ,stg.[OrderCombinationIsAllowed]
                ,stg.[PartialDeliveryIsAllowed]
                ,stg.[InvoiceDate]
                ,stg.[PaymentTerms]
                ,stg.[IncotermsTransferLocation]
                ,stg.[ItemOrderProbabilityInPercent]
                ,stg.[IncotermsLocation2]
                ,stg.[AuthorizationGroup]
                ,stg.[SalesDistrict]
                ,stg.[IncotermsVersion]
                ,stg.[IncotermsLocation1]
                ,stg.[DeletionIndicator]
                ,stg.[IsBusinessPurposeCompleted]
                ,stg.[SalesItemProposal]
                ,stg.[CustProdProposalProcedure]
                ,stg.[MaxNmbrOfPartialDelivery]
                ,stg.[UnderdelivTolrtdLmtRatioInPct]
                ,stg.[OverdelivTolrtdLmtRatioInPct]
                ,stg.[IsActiveEntity]
                ,stg.[AdditionalCustomerGroup1]
                ,stg.[AdditionalCustomerGroup2]
                ,stg.[AdditionalCustomerGroup3]
                ,stg.[AdditionalCustomerGroup4]
                ,stg.[AdditionalCustomerGroup5]
                ,stg.[InvoiceListSchedule]
                ,stg.[ExchangeRateType]
                ,stg.[PaymentGuaranteeProcedure]
                ,stg.[DeliverySplitStrategy]
                ,stg.[InvoiceSplitStrategy]
                ,stg.[TermsOfPayment]
                ,stg.[SalesRepType]
                ,stg.[B2BOrderHistory]
                ,stg.[OrderNumber]
                ,stg.[CostCenter]
                ,stg.[RetCreditNoteSStrategy]
                ,stg.[DC10SportsSpecial]
                ,stg.[DC20Sports]
                ,stg.[DC30SportStyle]
                ,stg.[DC40SportLifest]
                ,stg.[DC50Lifestyle]
                ,stg.[DC60Fashion]
                ,stg.[DC35SportStylePlus]
                ,stg.[DC45LifestylePlus]
                ,stg.[DC90Distributer]
                ,stg.[DC90B2B]
                ,stg.[DC92InternalSales]
                ,stg.[DC93MonobrandFranchiseStore]
                ,stg.[DC94MassMerchant]
                ,stg.[DC95Clearance]
                ,stg.[DC99Others]
                ,stg.[DC31Performance]
                ,stg.[PumaDistributionChannel]
                ,stg.[LocalCustomerGroup]
                ,stg.[AreaAccount]
                ,stg.[AccountRole]
                ,stg.[CustomerStructure]
                ,stg.[MainCustomer]
                ,stg.[MasterCustomer]
                ,stg.[ReportingGroup10]
                ,stg.[LaunchDateBuffer]
                ,stg.[Specialist]
                ,stg.[NeveroutofStock]
                ,stg.[LocalOwnerGroup]
                ,stg.[TeamBusinessSpecIdentification]
                ,stg.[ShopName]
                ,stg.[AccountType]
                ,stg.[EDI]
                ,stg.[CallCenterCampaign]
                ,stg.[CommercialOperations]
                ,stg.[EarlyShipment]
                ,stg.[RestrictProdAccess]
                ,stg.[RetailAdditionalCustomerGrp6]
                ,stg.[RetailAdditionalCustomerGrp7]
                ,stg.[RetailAdditionalCustomerGrp8]
                ,stg.[RetailAdditionalCustomerGrp9]
                ,stg.[RetailAdditionalCustomerGrp10]
                ,stg.[credit_limit]
                ,stg.[xblocked]
                ,stg.[block_reason]
                ,stg.[Companycode]
                ,stg.[CreditControlArea]
                ,stg.[Postingblockforcompanycode]
                ,stg.[DeletionFlagCompanyCodeLevel]
                ,stg.[BlockKeyforPayment]
                ,stg.[DunningArea]
                ,stg.[DunningBlock]
				,stg.[TierDC10]
				,stg.[TierDC20]
				,stg.[TierDC30]
				,stg.[TierDC40]
				,stg.[TierDC45]
				,stg.[TierDC50]
				,stg.[TierDC60]
	            ,stg.IsDeleted       
                ,stg.LDTS
				,stg.[HashDiff]				


		 FROM #csa AS stg LEFT JOIN biz.S4Hana_CustomerSalesAttributes AS prd 
		 ON prd.CustomerSalesAttributes_BK = stg.CustomerSalesAttributes_BK 
		 WHERE prd.CustomerSalesAttributes_BK IS NULL
	
		UPDATE DTlogs
		SET Inserted = @AffectedRows
		FROM etl.DataTransferLogs DTlogs
		WHERE DataTransferLogId = @DataTransferLogId


		-- count new Records for S4Hana_CustomerSalesAttributes
		SELECT @AffectedRows = COUNT(*)
		FROM #csa AS stg JOIN biz.S4Hana_CustomerSalesAttributes AS prd 
		ON prd.CustomerSalesAttributes_BK = stg.CustomerSalesAttributes_BK
		WHERE stg.HashDiff <> prd.HashDiff

		UPDATE DTlogs
		SET Updated = @AffectedRows
		, ExecEnd = GETDATE()
		FROM etl.DataTransferLogs DTlogs
		WHERE DataTransferLogId = @DataTransferLogId

		--update non deleted records
		  UPDATE prd SET	
				 prd.CustomerSalesAttributes_BK                     = stg.CustomerSalesAttributes_BK
	            ,prd.[Customer]										= stg.[Customer]
                ,prd.[SalesOrganization]							= stg.[SalesOrganization]
                ,prd.[DistributionChannel]							= stg.[DistributionChannel]
                ,prd.[Division]										= stg.[Division]
                ,prd.[CustomerABCClassification]					= stg.[CustomerABCClassification]
                ,prd.[SalesOffice]									= stg.[SalesOffice]
                ,prd.[SalesGroup]									= stg.[SalesGroup]
                ,prd.[OrderIsBlockedForCustomer]					= stg.[OrderIsBlockedForCustomer]
                ,prd.[Currency]										= stg.[Currency]
                ,prd.[CustomerPriceGroup]							= stg.[CustomerPriceGroup]
                ,prd.[PriceListType]								= stg.[PriceListType]
                ,prd.[DeliveryPriority]								= stg.[DeliveryPriority]
                ,prd.[ShippingCondition]							= stg.[ShippingCondition]
                ,prd.[IncotermsClassification]						= stg.[IncotermsClassification]
                ,prd.[SupplyingPlant]								= stg.[SupplyingPlant]
                ,prd.[CompleteDeliveryIsDefined]					= stg.[CompleteDeliveryIsDefined]
                ,prd.[DeliveryIsBlockedForCustomer]					= stg.[DeliveryIsBlockedForCustomer]
                ,prd.[BillingIsBlockedForCustomer]					= stg.[BillingIsBlockedForCustomer]
                ,prd.[CustomerPaymentTerms]							= stg.[CustomerPaymentTerms]
                ,prd.[CustomerAccountAssignmentGroup]				= stg.[CustomerAccountAssignmentGroup]
                ,prd.[AccountByCustomer]							= stg.[AccountByCustomer]
                ,prd.[CustomerGroup]								= stg.[CustomerGroup]
                ,prd.[CustomerGroupName]							= stg.[CustomerGroupName]
                ,prd.[CustomerPricingProcedure]						= stg.[CustomerPricingProcedure]
                ,prd.[OrderCombinationIsAllowed]					= stg.[OrderCombinationIsAllowed]
                ,prd.[PartialDeliveryIsAllowed]						= stg.[PartialDeliveryIsAllowed]
                ,prd.[InvoiceDate]									= stg.[InvoiceDate]
                ,prd.[PaymentTerms]									= stg.[PaymentTerms]
                ,prd.[IncotermsTransferLocation]					= stg.[IncotermsTransferLocation]
                ,prd.[ItemOrderProbabilityInPercent]				= stg.[ItemOrderProbabilityInPercent]
                ,prd.[IncotermsLocation2]							= stg.[IncotermsLocation2]
                ,prd.[AuthorizationGroup]							= stg.[AuthorizationGroup]
                ,prd.[SalesDistrict]								= stg.[SalesDistrict]
                ,prd.[IncotermsVersion]								= stg.[IncotermsVersion]
                ,prd.[IncotermsLocation1]							= stg.[IncotermsLocation1]
                ,prd.[DeletionIndicator]							= stg.[DeletionIndicator]
                ,prd.[IsBusinessPurposeCompleted]					= stg.[IsBusinessPurposeCompleted]
                ,prd.[SalesItemProposal]							= stg.[SalesItemProposal]
                ,prd.[CustProdProposalProcedure]					= stg.[CustProdProposalProcedure]
                ,prd.[MaxNmbrOfPartialDelivery]						= stg.[MaxNmbrOfPartialDelivery]
                ,prd.[UnderdelivTolrtdLmtRatioInPct]				= stg.[UnderdelivTolrtdLmtRatioInPct]
                ,prd.[OverdelivTolrtdLmtRatioInPct]					= stg.[OverdelivTolrtdLmtRatioInPct]
                ,prd.[IsActiveEntity]								= stg.[IsActiveEntity]
                ,prd.[AdditionalCustomerGroup1]						= stg.[AdditionalCustomerGroup1]
                ,prd.[AdditionalCustomerGroup2]						= stg.[AdditionalCustomerGroup2]
                ,prd.[AdditionalCustomerGroup3]						= stg.[AdditionalCustomerGroup3]
                ,prd.[AdditionalCustomerGroup4]						= stg.[AdditionalCustomerGroup4]
                ,prd.[AdditionalCustomerGroup5]						= stg.[AdditionalCustomerGroup5]
                ,prd.[InvoiceListSchedule]							= stg.[InvoiceListSchedule]
                ,prd.[ExchangeRateType]								= stg.[ExchangeRateType]
                ,prd.[PaymentGuaranteeProcedure]					= stg.[PaymentGuaranteeProcedure]
                ,prd.[DeliverySplitStrategy]						= stg.[DeliverySplitStrategy]
                ,prd.[InvoiceSplitStrategy]							= stg.[InvoiceSplitStrategy]
                ,prd.[TermsOfPayment]								= stg.[TermsOfPayment]
                ,prd.[SalesRepType]									= stg.[SalesRepType]
                ,prd.[B2BOrderHistory]								= stg.[B2BOrderHistory]
                ,prd.[OrderNumber]									= stg.[OrderNumber]
                ,prd.[CostCenter]									= stg.[CostCenter]
                ,prd.[RetCreditNoteSStrategy]						= stg.[RetCreditNoteSStrategy]
                ,prd.[DC10SportsSpecial]							= stg.[DC10SportsSpecial]
                ,prd.[DC20Sports]									= stg.[DC20Sports]
                ,prd.[DC30SportStyle]								= stg.[DC30SportStyle]
                ,prd.[DC40SportLifest]								= stg.[DC40SportLifest]
                ,prd.[DC50Lifestyle]								= stg.[DC50Lifestyle]
                ,prd.[DC60Fashion]									= stg.[DC60Fashion]
                ,prd.[DC35SportStylePlus]							= stg.[DC35SportStylePlus]
                ,prd.[DC45LifestylePlus]							= stg.[DC45LifestylePlus]
                ,prd.[DC90Distributer]								= stg.[DC90Distributer]
                ,prd.[DC90B2B]										= stg.[DC90B2B]
                ,prd.[DC92InternalSales]							= stg.[DC92InternalSales]
                ,prd.[DC93MonobrandFranchiseStore]					= stg.[DC93MonobrandFranchiseStore]
                ,prd.[DC94MassMerchant]								= stg.[DC94MassMerchant]
                ,prd.[DC95Clearance]								= stg.[DC95Clearance]
                ,prd.[DC99Others]									= stg.[DC99Others]
                ,prd.[DC31Performance]								= stg.[DC31Performance]
                ,prd.[PumaDistributionChannel]						= stg.[PumaDistributionChannel]
                ,prd.[LocalCustomerGroup]							= stg.[LocalCustomerGroup]
                ,prd.[AreaAccount]									= stg.[AreaAccount]
                ,prd.[AccountRole]									= stg.[AccountRole]
                ,prd.[CustomerStructure]							= stg.[CustomerStructure]
                ,prd.[MainCustomer]									= stg.[MainCustomer]
                ,prd.[MasterCustomer]								= stg.[MasterCustomer]
                ,prd.[ReportingGroup10]								= stg.[ReportingGroup10]
                ,prd.[LaunchDateBuffer]								= stg.[LaunchDateBuffer]
                ,prd.[Specialist]									= stg.[Specialist]
                ,prd.[NeveroutofStock]								= stg.[NeveroutofStock]
                ,prd.[LocalOwnerGroup]								= stg.[LocalOwnerGroup]
                ,prd.[TeamBusinessSpecIdentification]				= stg.[TeamBusinessSpecIdentification]
                ,prd.[ShopName]										= stg.[ShopName]
                ,prd.[AccountType]									= stg.[AccountType]
                ,prd.[EDI]											= stg.[EDI]
                ,prd.[CallCenterCampaign]							= stg.[CallCenterCampaign]
                ,prd.[CommercialOperations]							= stg.[CommercialOperations]
                ,prd.[EarlyShipment]								= stg.[EarlyShipment]
                ,prd.[RestrictProdAccess]							= stg.[RestrictProdAccess]
                ,prd.[RetailAdditionalCustomerGrp6]					= stg.[RetailAdditionalCustomerGrp6]
                ,prd.[RetailAdditionalCustomerGrp7]					= stg.[RetailAdditionalCustomerGrp7]
                ,prd.[RetailAdditionalCustomerGrp8]					= stg.[RetailAdditionalCustomerGrp8]
                ,prd.[RetailAdditionalCustomerGrp9]					= stg.[RetailAdditionalCustomerGrp9]
                ,prd.[RetailAdditionalCustomerGrp10]				= stg.[RetailAdditionalCustomerGrp10]
                ,prd.[credit_limit]									= stg.[credit_limit]
                ,prd.[xblocked]										= stg.[xblocked]
                ,prd.[block_reason]									= stg.[block_reason]
                ,prd.[Companycode]									= stg.[Companycode]
                ,prd.[CreditControlArea]							= stg.[CreditControlArea]
                ,prd.[Postingblockforcompanycode]					= stg.[Postingblockforcompanycode]
                ,prd.[DeletionFlagCompanyCodeLevel]					= stg.[DeletionFlagCompanyCodeLevel]
                ,prd.[BlockKeyforPayment]							= stg.[BlockKeyforPayment]
                ,prd.[DunningArea]									= stg.[DunningArea]
                ,prd.[DunningBlock]									= stg.[DunningBlock]
				,prd.[TierDC10]										= stg.[TierDC10]
				,prd.[TierDC20]										= stg.[TierDC20]
				,prd.[TierDC30]										= stg.[TierDC30]
				,prd.[TierDC40]										= stg.[TierDC40]
				,prd.[TierDC45]										= stg.[TierDC45]
				,prd.[TierDC50]										= stg.[TierDC50]
				,prd.[TierDC60]										= stg.[TierDC60]
	            ,prd.IsDeleted       								= stg.IsDeleted       
                ,prd.LDTS											= stg.LDTS
				,prd.[HashDiff]										= stg.[HashDiff]	


			FROM #csa AS stg JOIN biz.S4Hana_CustomerSalesAttributes AS prd 
			ON prd.CustomerSalesAttributes_BK = stg.CustomerSalesAttributes_BK
			WHERE stg.HashDiff <> prd.HashDiff and stg.IsDeleted = 0

		 --update deletions (only deleted status and LDTS)
		 UPDATE prd SET
				 prd.LDTS				= stg.LDTS
				,prd.IsDeleted			= stg.IsDeleted
				,prd.[HashDiff]			= stg.[HashDiff]

		 	FROM #csa AS stg JOIN biz.S4Hana_CustomerSalesAttributes AS prd 
			ON prd.CustomerSalesAttributes_BK = stg.CustomerSalesAttributes_BK
			WHERE stg.HashDiff <> prd.HashDiff and stg.IsDeleted = 1


END

--truncate table biz.S4Hana_CustomerSalesAttributes
-- exec [biz].[S4Hana_spCustomerSalesAttributes]'1900-01-01'