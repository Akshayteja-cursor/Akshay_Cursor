﻿CREATE PROC [biz].[S4Hana_spPODocumentItems] @LDTS [DATETIME2](7) AS
BEGIN
    SET NOCOUNT ON;
    SET ANSI_WARNINGS ON;

    IF OBJECT_ID(N'tempdb..#PODocumentItems') IS NOT NULL
        DROP TABLE #PODocumentItems

    CREATE TABLE #PODocumentItems
    WITH
    (
      DISTRIBUTION = HASH(PONo),
	  CLUSTERED INDEX ([PONo] ASC, [POItemNo] ASC)
    )
    AS
    SELECT
         PONo     --BK
       , POItemNo --BK
       , DeletionCode
       , IsCompletelyDelivered
       , MaterialNumber
       , EAN
       , FactoryCode
       , SiteCode
       , RequestedDeliveryDate
       , OrderQuantity
       , NetAmount
       , PlannedDeliveryDate
       , LastConfirmedDeliveryDate
       , ExpectedHandoverDate
       , ActualHandoverDate
       , CountryOfOrigin
       , ShippingInstructionCode
	   , StorageLocation
	   , StockSegment
	   , ISSSTORLOCSTO
	   , LegacyPONumber
	   , LegacyPOItemNumber
	   , RequisitionerName
       , IsDeleted
       , LDTS
	   ,CONVERT([BINARY](16),
				HASHBYTES('MD5',CONCAT(
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PONo)))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), POItemNo)))),'_',				
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), DeletionCode)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), IsCompletelyDelivered)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), MaterialNumber)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), EAN)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FactoryCode)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), SiteCode)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), RequestedDeliveryDate)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), OrderQuantity)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), NetAmount)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PlannedDeliveryDate)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), LastConfirmedDeliveryDate)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ExpectedHandoverDate)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ActualHandoverDate)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CountryOfOrigin)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ShippingInstructionCode)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), StorageLocation)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), StockSegment)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ISSSTORLOCSTO)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), LegacyPONumber)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), LegacyPOItemNumber)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), RequisitionerName)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), IsDeleted))))))
			) AS HashDiff
    FROM stag.S4Hana_fnPODocumentItems(@LDTS)
    OPTION (LABEL = 'biz.S4Hana_spPODocumentItems: DeltaTempTableFromFunctionStatement')

    --update changed			
    UPDATE
          dest
    SET
          dest.DeletionCode = src.DeletionCode
        , dest.IsCompletelyDelivered = src.IsCompletelyDelivered
        , dest.MaterialNumber = src.MaterialNumber
        , dest.EAN = src.EAN
        , dest.FactoryCode = src.FactoryCode
        , dest.SiteCode = src.SiteCode
        , dest.RequestedDeliveryDate = src.RequestedDeliveryDate
        , dest.OrderQuantity = src.OrderQuantity
        , dest.NetAmount = src.NetAmount
        , dest.PlannedDeliveryDate = src.PlannedDeliveryDate
        , dest.LastConfirmedDeliveryDate = src.LastConfirmedDeliveryDate
        , dest.ExpectedHandoverDate = src.ExpectedHandoverDate
        , dest.ActualHandoverDate = src.ActualHandoverDate
        , dest.CountryOfOrigin = src.CountryOfOrigin
        , dest.ShippingInstructionCode = src.ShippingInstructionCode
		, dest.StorageLocation = src.StorageLocation
		, dest.StockSegment = src.StockSegment
		, dest.ISSSTORLOCSTO = src.ISSSTORLOCSTO
		, dest.LegacyPONumber = src.LegacyPONumber
		, dest.LegacyPOItemNumber = src.LegacyPOItemNumber
		, dest.RequisitionerName = src.RequisitionerName
        , dest.IsDeleted = src.IsDeleted
        , dest.LDTS = src.LDTS
        , dest.HashDiff = src.HashDiff
    FROM  biz.S4Hana_PODocumentItems AS dest
    JOIN  #PODocumentItems           AS src ON src.PONo = dest.PONo AND src.POItemNo = dest.POItemNo
    WHERE src.HashDiff <> dest.HashDiff
    OPTION (LABEL = 'biz.S4Hana_spPODocumentItems: UpdateStatement')

    --load new
    INSERT biz.S4Hana_PODocumentItems
    (
        PONo     --BK
      , POItemNo --BK
      , DeletionCode
      , IsCompletelyDelivered
      , MaterialNumber
      , EAN
      , FactoryCode
      , SiteCode
      , RequestedDeliveryDate
      , OrderQuantity
      , NetAmount
      , PlannedDeliveryDate
      , LastConfirmedDeliveryDate
      , ExpectedHandoverDate
      , ActualHandoverDate
      , CountryOfOrigin
      , ShippingInstructionCode
	  , StorageLocation
	  , StockSegment
	  , ISSSTORLOCSTO
	  , LegacyPONumber
	  , LegacyPOItemNumber
	  , RequisitionerName
      , IsDeleted
      , LDTS
      , HashDiff
    )
    SELECT
              src.PONo     --BK
            , src.POItemNo --BK
            , src.DeletionCode
            , src.IsCompletelyDelivered
            , src.MaterialNumber
            , src.EAN
            , src.FactoryCode
            , src.SiteCode
            , src.RequestedDeliveryDate
            , src.OrderQuantity
            , src.NetAmount
            , src.PlannedDeliveryDate
            , src.LastConfirmedDeliveryDate
            , src.ExpectedHandoverDate
            , src.ActualHandoverDate
            , src.CountryOfOrigin
            , src.ShippingInstructionCode
			, src.StorageLocation
			, src.StockSegment
			, src.ISSSTORLOCSTO
			, src.LegacyPONumber
			, src.LegacyPOItemNumber
			, src.RequisitionerName
            , src.IsDeleted
            , src.LDTS
            , src.HashDiff
    FROM      #PODocumentItems           AS src
    LEFT JOIN biz.S4Hana_PODocumentItems AS dest ON src.PONo = dest.PONo AND src.POItemNo = dest.POItemNo
    WHERE     dest.PONo IS NULL
    OPTION (LABEL = 'biz.S4Hana_spPODocumentItems: InsertStatement')
END
