﻿CREATE PROC [biz].[S4Hana_spSOSupplyAssignments] @LDTS [DATETIME2](7) AS
BEGIN
    SET NOCOUNT ON;
    SET ANSI_WARNINGS ON;


    IF OBJECT_ID(N'tempdb..#SOSupplyAssignments') IS NOT NULL  DROP TABLE #SOSupplyAssignments

	--DECLARE @LDTS AS [DATETIME2](7)
	--SET @LDTS = '1900-01-01'

    CREATE TABLE #SOSupplyAssignments
    WITH
    (
        DISTRIBUTION = HASH(SalesOrderNo),
	    CLUSTERED INDEX ([SalesOrderNo] ASC, [SalesOrderItemNo] ASC,[ARunStatus] ASC, [ARunId] ASC)
    )
    AS
    SELECT
         ARunId                  -- BK
       , SalesOrderNo            
       , SalesOrderItemNo        
       , ARunStatus              
       , AssignedQuantityARun
       , SalesOrganizationCode
	   , StockSource
       , IsDeleted
       , LDTS
	   , CONVERT([BINARY](16),
				HASHBYTES('MD5',CONCAT(
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ARunId)))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), SalesOrderNo)))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), SalesOrderItemNo)))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ARunStatus)))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), AssignedQuantityARun)))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), SalesOrganizationCode)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), StockSource)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), IsDeleted))))))
			) AS HashDiff
    FROM stag.S4Hana_fnSOSupplyAssignments(@LDTS)
    OPTION (LABEL = 'biz.S4Hana_spSOSupplyAssignments: DeltaTempTableFromFunctionStatement')

    --update changed
    UPDATE
          dest
    SET
        dest.ARunStatus = src.ARunStatus		
		, dest.AssignedQuantityARun = src.AssignedQuantityARun
        , dest.SalesOrganizationCode = src.SalesOrganizationCode
		, dest.StockSource	=	src.StockSource
        , dest.LDTS = src.LDTS
        , dest.HashDiff = src.HashDiff
	FROM  biz.S4Hana_SOSupplyAssignments AS dest
    --for not deleted rows SalesOrderNo (the distribution key) has value in #SOSupplyAssignments and can be included in the join (to avoid data movement)
    JOIN  #SOSupplyAssignments           AS src ON src.SalesOrderNo = dest.SalesOrderNo AND src.SalesOrderItemNo = dest.SalesOrderItemNo
                                                   AND src.ARunId = dest.ARunId
    WHERE src.IsDeleted = 0 AND src.HashDiff <> dest.HashDiff
    OPTION (LABEL = 'biz.S4Hana_spSOSupplyAssignments: UpdateStatement')

    --load new
    INSERT INTO biz.S4Hana_SOSupplyAssignments
    (
        ARunId                  
      , SalesOrderNo            
      , SalesOrderItemNo        
      , ARunStatus              
      , AssignedQuantityARun
	  , StockSource
      , SalesOrganizationCode
      , IsDeleted
      , LDTS
      , HashDiff
    )    
    SELECT
              src.ARunId                
            , src.SalesOrderNo          
            , src.SalesOrderItemNo      
            , src.ARunStatus            
            , src.AssignedQuantityARun
			, src.StockSource
            , src.SalesOrganizationCode
            , src.IsDeleted
            , src.LDTS
            , src.HashDiff
    FROM      #SOSupplyAssignments           AS src
    --for not deleted rows SalesOrderNo (the distribution key) has value in #SOSupplyAssignments and can be included in the join (to avoid data movement)
    LEFT JOIN biz.S4Hana_SOSupplyAssignments AS dest ON src.SalesOrderNo = dest.SalesOrderNo AND src.SalesOrderItemNo = dest.SalesOrderItemNo
                                                        AND src.ARunStatus = dest.ARunStatus
                                                        AND src.ARunId = dest.ARunId
    WHERE     src.IsDeleted = 0 AND dest.ARunId IS NULL
    OPTION (LABEL = 'biz.S4Hana_spSOSupplyAssignments: InsertStatement')

    IF OBJECT_ID(N'tempdb..#DeletedSOSupplyAssignments') IS NOT NULL
        DROP TABLE #DeletedSOSupplyAssignments

    CREATE TABLE #DeletedSOSupplyAssignments
    WITH
    (
      DISTRIBUTION = HASH([ARunId]),
      CLUSTERED INDEX ([SalesOrderNo] ASC, [SalesOrderItemNo] ASC,  [ARunStatus] ASC, [ARunId] ASC)
    )
    AS
    SELECT
          ARunId                  --BK
        , SalesOrderNo            --BK
        , SalesOrderItemNo        --BK
        , ARunStatus              --BK
        , AssignedQuantityARun
		, StockSource
        , SalesOrganizationCode
        , IsDeleted
        , LDTS
        , HashDiff
    FROM  #SOSupplyAssignments
    WHERE IsDeleted = 1

    --update deleted
    UPDATE
          dest
    SET
          dest.IsDeleted = src.IsDeleted
        , dest.LDTS = src.LDTS
		, dest.AssignedQuantityARun = src.AssignedQuantityARun
		, dest.StockSource	=	src.StockSource
        , dest.HashDiff = CONVERT([BINARY](16),
                                HASHBYTES('MD5',CONCAT(
                                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), dest.ARunId)))),'_',
                                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), dest.SalesOrderNo)))),'_',
                                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), dest.SalesOrderItemNo)))),'_',
                                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), dest.ARunStatus)))),'_',
                                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), src.AssignedQuantityARun)))),'_',
                                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), dest.SalesOrganizationCode)))),'_',
								UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), src.StockSource)))),'_',
                                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), src.IsDeleted))))))
                            )
    FROM  biz.S4Hana_SOSupplyAssignments AS dest
    --for deleted rows SalesOrderNo (the distribution key) is empty in #SOSupplyAssignments and can't be included in the join (data movement unavoidable)
    JOIN  #DeletedSOSupplyAssignments    AS src ON src.ARunId = dest.ARunId
    WHERE src.IsDeleted <> dest.IsDeleted
    OPTION (LABEL='biz.S4Hana_spSOSupplyAssignments: UpdateDeletedStatement')
END