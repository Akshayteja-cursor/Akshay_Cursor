﻿CREATE PROC [biz].[S4Hana_spDataServices] AS
BEGIN
SET NOCOUNT ON;
SET ANSI_WARNINGS ON;

IF OBJECT_ID('tempdb..#biz') IS NOT NULL DROP TABLE #biz;
select name as name  into #biz from sys.tables where schema_name(schema_id)='biz' and (name like '%Customer%' or name like '%BP%'or name like 'S4Hana_Material%') and name not like '%backup%'
and name not like '%S4Hana_BPLegacyPartnerData%'
--select * from #biz

declare @sql1 nvarchar(max)
declare @Tablename nvarchar(100)
declare @LDTS nvarchar(100)
declare @sp nvarchar(100)
WHILE (SELECT count(1) FROM #biz) > 0
		BEGIN
			SELECT TOP(1) @Tablename = name from #biz
			select @LDTS = coalesce(max(SourceLastLoadDate),'19000101'), @sp = max(TransferName) from [etl].[DataTransferLogs] where TargetTableName = @Tablename and TargetSchemaName='biz' and execend is not NULL
			select @sql1 = concat( 'exec biz.',@sp,' ','''',@LDTS,'''')
			--print  concat(@Tablename,'          ', @sql1)
			EXECUTE sp_executesql @sql1;

            DELETE FROM #biz WHERE name = @Tablename
		END
END