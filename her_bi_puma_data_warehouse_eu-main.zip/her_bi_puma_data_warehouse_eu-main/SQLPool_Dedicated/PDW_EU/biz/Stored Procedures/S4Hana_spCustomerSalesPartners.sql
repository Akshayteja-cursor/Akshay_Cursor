﻿CREATE PROC [biz].[S4Hana_spCustomerSalesPartners] @ldts [DATETIME2](7) AS
BEGIN
	SET NOCOUNT ON;
	SET ANSI_WARNINGS ON;

	DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
	DECLARE @ExecStart DATETIME2(7) = GETDATE()
	DECLARE @SourceLastLoadDate DATETIME2(7)
	DECLARE @DestinationLastLoadDate DATETIME2(7)
	DECLARE @BatchLdts DATETIME2(7) = @LDTS
	DECLARE @AffectedRows BIGINT = NULL

	IF(EXISTS(SELECT 1 FROM [biz].[S4Hana_CustomerSalesPartners]))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(LDTS))
	FROM [biz].[S4Hana_CustomerSalesPartners]
	END
	ELSE BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

	IF(EXISTS(SELECT 1 FROM stag.[S4Hana_CustomerSalesPartners]))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(_LDTS))
		FROM stag.[S4Hana_CustomerSalesPartners]
	END
	ELSE BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END 


	--Log Data load
	INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'S4Hana_spCustomerSalesPartners'
			,'biz_CustomerSalesPartners'
			,'S4Hana_CustomerSalesPartners'
			,'biz'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts


	IF OBJECT_ID(N'tempdb..#csp') IS NOT NULL
	DROP TABLE #csp;

	SELECT
	   CONCAT(CustomerNumber, '|', SalesOrganization, '|', DistributionChannel, '|', PartnerFunction, '|', PartnerCounter) AS CustomerSalesPartners_BK
	  ,[CustomerNumber]
      ,[SalesOrganization]
      ,[DistributionChannel]
      ,[Division]
      ,[PartnerFunction]
      ,[PartnerCounter]
      ,[Partner]
      ,[Vendor]
      ,[PersonalNumber]
      ,[ContactPerson]
      ,[Description]
      ,[DefaultPartner]
      ,[FunctionDescription]
      ,[Desccustpartm]
      ,[Partnername]
	  ,IsDeleted       
      ,[_LDTS] as LDTS
	  ,CONVERT([BINARY](16),
				HASHBYTES('MD5',CONCAT(
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CustomerNumber]       )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SalesOrganization]	 )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DistributionChannel]	 )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Division]			 )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PartnerFunction]		 )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PartnerCounter]		 )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Partner]				 )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Vendor]				 )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PersonalNumber]		 )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ContactPerson]		 )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Description]			 )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DefaultPartner]		 )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FunctionDescription]	 )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Desccustpartm]		 )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Partnername]			 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [IsDeleted]))))))       
			) AS HashDiff

INTO #csp
FROM 
(
	SELECT
*
	, CAST(CASE WHEN __operation_type = 'X' 
		THEN 1 ELSE 0 END AS BIT)				AS IsDeleted
	, ROW_NUMBER() OVER (PARTITION BY CustomerNumber,SalesOrganization,DistributionChannel,PartnerFunction,PartnerCounter 
					ORDER BY _LDTS DESC
						, __timestamp DESC)		AS RN
	FROM stag.[S4Hana_CustomerSalesPartners]
) X
WHERE RN = 1
and [_LDTS] > @ldts
	
		-- count new Records for S4Hana_CustomerSalesPartners
		    SELECT @AffectedRows = COUNT(*)
			FROM #csp AS stg LEFT JOIN biz.S4Hana_CustomerSalesPartners AS prd 
			ON prd.CustomerSalesPartners_BK = stg.CustomerSalesPartners_BK 
			WHERE prd.CustomerSalesPartners_BK IS NULL

   --load new
   INSERT INTO biz.S4Hana_CustomerSalesPartners
			(
				 CustomerSalesPartners_BK
	            ,[CustomerNumber]
                ,[SalesOrganization]
                ,[DistributionChannel]
                ,[Division]
                ,[PartnerFunction]
                ,[PartnerCounter]
                ,[Partner]
                ,[Vendor]
                ,[PersonalNumber]
                ,[ContactPerson]
                ,[Description]
                ,[DefaultPartner]
                ,[FunctionDescription]
                ,[Desccustpartm]
                ,[Partnername]
	            ,IsDeleted       
                ,LDTS
				,[HashDiff]			
			)
	SELECT 
				 stg.CustomerSalesPartners_BK
	            ,stg.[CustomerNumber]
                ,stg.[SalesOrganization]
                ,stg.[DistributionChannel]
                ,stg.[Division]
                ,stg.[PartnerFunction]
                ,stg.[PartnerCounter]
                ,stg.[Partner]
                ,stg.[Vendor]
                ,stg.[PersonalNumber]
                ,stg.[ContactPerson]
                ,stg.[Description]
                ,stg.[DefaultPartner]
                ,stg.[FunctionDescription]
                ,stg.[Desccustpartm]
                ,stg.[Partnername]
	            ,stg.IsDeleted       
                ,stg.LDTS
				,stg.[HashDiff]			


		 FROM #csp AS stg LEFT JOIN biz.S4Hana_CustomerSalesPartners AS prd 
		 ON prd.CustomerSalesPartners_BK = stg.CustomerSalesPartners_BK 
		 WHERE prd.CustomerSalesPartners_BK IS NULL
	
		UPDATE DTlogs
		SET Inserted = @AffectedRows
		FROM etl.DataTransferLogs DTlogs
		WHERE DataTransferLogId = @DataTransferLogId


		-- count new Records for S4Hana_CustomerSalesPartners
		SELECT @AffectedRows = COUNT(*)
		FROM #csp AS stg JOIN biz.S4Hana_CustomerSalesPartners AS prd 
		ON prd.CustomerSalesPartners_BK = stg.CustomerSalesPartners_BK
		WHERE stg.HashDiff <> prd.HashDiff

		UPDATE DTlogs
		SET Updated = @AffectedRows
		, ExecEnd = GETDATE()
		FROM etl.DataTransferLogs DTlogs
		WHERE DataTransferLogId = @DataTransferLogId

		--update non deleted records
		  UPDATE prd SET	
				 prd.CustomerSalesPartners_BK = stg.CustomerSalesPartners_BK 
	            ,prd.[CustomerNumber]		  = stg.[CustomerNumber]		  
                ,prd.[SalesOrganization]	  = stg.[SalesOrganization]	  
                ,prd.[DistributionChannel]	  = stg.[DistributionChannel]	  
                ,prd.[Division]				  = stg.[Division]				  
                ,prd.[PartnerFunction]		  = stg.[PartnerFunction]		  
                ,prd.[PartnerCounter]		  = stg.[PartnerCounter]		  
                ,prd.[Partner]				  = stg.[Partner]				  
                ,prd.[Vendor]				  = stg.[Vendor]				  
                ,prd.[PersonalNumber]		  = stg.[PersonalNumber]		  
                ,prd.[ContactPerson]		  = stg.[ContactPerson]		  
                ,prd.[Description]			  = stg.[Description]			  
                ,prd.[DefaultPartner]		  = stg.[DefaultPartner]		  
                ,prd.[FunctionDescription]	  = stg.[FunctionDescription]	  
                ,prd.[Desccustpartm]		  = stg.[Desccustpartm]		  
                ,prd.[Partnername]			  = stg.[Partnername]			  
	            ,prd.IsDeleted       		  = stg.IsDeleted       		  
                ,prd.LDTS					  = stg.LDTS					  
				,prd.[HashDiff]				  = stg.[HashDiff]				  	


			FROM #csp AS stg JOIN biz.S4Hana_CustomerSalesPartners AS prd 
			ON prd.CustomerSalesPartners_BK = stg.CustomerSalesPartners_BK
			WHERE stg.HashDiff <> prd.HashDiff and stg.IsDeleted = 0

		 --update deletions (only deleted status and LDTS)
		 UPDATE prd SET
				 prd.LDTS				= stg.LDTS
				,prd.IsDeleted			= stg.IsDeleted
				,prd.[HashDiff]			= stg.[HashDiff]
		 	FROM #csp AS stg JOIN biz.S4Hana_CustomerSalesPartners AS prd 
			ON prd.CustomerSalesPartners_BK = stg.CustomerSalesPartners_BK
			WHERE stg.HashDiff <> prd.HashDiff and stg.IsDeleted = 1


END

--truncate table biz.S4Hana_CustomerSalesPartners
-- exec [biz].[S4Hana_spCustomerSalesPartners]'1900-01-01'