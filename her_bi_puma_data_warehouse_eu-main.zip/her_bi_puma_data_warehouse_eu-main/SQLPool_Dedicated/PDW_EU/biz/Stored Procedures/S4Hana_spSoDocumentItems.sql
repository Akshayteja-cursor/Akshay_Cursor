﻿CREATE PROC [biz].[S4Hana_spSoDocumentItems] @ldts [DATETIME2](7) AS
BEGIN
	SET NOCOUNT ON;
	SET ANSI_WARNINGS ON;

	DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
	DECLARE @ExecStart DATETIME2(7) = GETDATE()
	DECLARE @SourceLastLoadDate DATETIME2(7)
	DECLARE @DestinationLastLoadDate DATETIME2(7)
	DECLARE @BatchLdts DATETIME2(7) = @LDTS
	DECLARE @AffectedRows BIGINT = NULL

	IF(EXISTS(SELECT 1 FROM [biz].[S4Hana_SoDocumentItems]))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(LDTS))
	FROM [biz].[S4Hana_SoDocumentItems]
	END
	ELSE BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

	IF(EXISTS(SELECT 1 FROM stag.[S4Hana_SoDocumentItems]))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(_LDTS))
		FROM stag.[S4Hana_SoDocumentItems]
	END
	ELSE BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END 


	--Log Data load
	INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'S4Hana_spSoDocumentItems'
			,'biz_SODocuments'
			,'S4Hana_SoDocumentItems'
			,'Stag'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts


	IF OBJECT_ID(N'tempdb..#soi') IS NOT NULL
	DROP TABLE #soi;

	SELECT 
         soi.[SalesDocument]
        ,soi.[SalesDocumentItem]
        ,soi.[CustomerConditionGroup1]
        ,soi.[PoType]
        ,soi.[ShippingConditionItm]
        ,soi.[SalesDocumentItemCategory]
        ,soi.[PurchaseOrderByCustomer]
        ,soi.[PurchaseConfirmationStatus]
        ,soi.[PaymentMethod]
        ,soi.[CreationDateItem]
        ,soi.[LastChangeDate]
        ,soi.[FixedValueDate]
        ,soi.[Division]
		,CASE WHEN soi.[IsDeleted] = 0 THEN soi.[Material] ELSE DEL.MaterialNumber END AS Material
        ,soi.[MaterialGroup]
        ,soi.[ShipToParty]
        ,soi.[PayerParty]
        ,soi.[BillToParty]
        ,soi.[SoldToParty]
        ,soi.[OrderQuantity]
        ,soi.[OrderQuantityUnit]
        ,soi.[TargetQuantityUnit]
        ,soi.[ConfdDelivQtyInOrderQtyUnit]
        ,soi.[ConfdDeliveryQtyInBaseUnit]
        ,soi.[BaseUnit]
        ,soi.[ItemGrossWeight]
        ,soi.[ItemNetWeight]
        ,soi.[ItemWeightUnit]
        ,soi.[CustomerPaymentTerms]
        ,soi.[SalesDocumentItemType]
        ,soi.[SalesDocumentRjcnReason]
        ,soi.[PricingDate]
        ,soi.[NetAmount]
		,CONVERT(DECIMAL(38,25),CONVERT(DECIMAL(15,2),soi.NetAmount) 
							/ (CASE WHEN soi.OrderQuantity <> 0 THEN CONVERT(DECIMAL(15, 3),soi.OrderQuantity) ELSE 1 END )) AS NetAmountUnit
		,CONVERT(DECIMAL(38,25), CONVERT(DECIMAL(15,2),soi.Subtotal1Amount) 
						/(CASE WHEN soi.OrderQuantity <> 0 THEN CONVERT(DECIMAL(15, 3),soi.OrderQuantity)ELSE 1 END )) AS GrossSalesValueUnit
		,soi.[TransactionCurrency]
        ,soi.[SalesOrganization]
        ,soi.[BillingCompanyCode]
        ,soi.[NetPriceAmount]
        ,soi.[CostAmount]
        ,soi.[Plant]
        ,soi.[StorageLocation]
        ,soi.[IncotermsClassification]
        ,soi.[IncotermsTransferLocation]
        ,soi.[ItemBillingBlockReason]
        ,soi.[ItemIsBillingRelevant]
		,CASE WHEN soi.[IsDeleted] = 0 THEN soi.[ReferenceSDDocument] ELSE DEL.ReferenceSDDocument END AS ReferenceSDDocument
		,CASE WHEN soi.[IsDeleted] = 0 THEN soi.[ReferenceDocumentItemNumber] ELSE DEL.ReferenceDocumentItemNumber END AS ReferenceDocumentItemNumber
		,CASE WHEN soi.[IsDeleted] = 0 THEN soi.[PrecedingDocumentCategory] ELSE DEL.[PrecedingDocumentCategory] END AS [PrecedingDocumentCategory]
        ,soi.[ProductSeason]
        ,soi.[ProductSeasonYear]
        ,soi.[DeliveryBlockStatus]
        ,soi.[TotalSDDocReferenceStatus]
        ,soi.[SDDocumentRejectionStatus]
        ,soi.[IncompletionStatus]
        ,soi.[IncompletionStatusBilling]
        ,soi.[PricingIncompletionStatus]
        ,soi.[IncompletionStatusDelivery]
        ,soi.[DeliveryConfirmationStatus]
        ,soi.[TotalDeliveryStatus]
        ,soi.[DeliveryStatus]
        ,soi.[CorrespncExternalReference]
        ,soi.[EAN]
        ,soi.[Promotion]
        ,soi.[TaxAmount]
        ,soi.[Subtotal1Amount]
        ,soi.[Subtotal2Amount]
        ,soi.[Subtotal3Amount]
        ,soi.[Subtotal4Amount]
        ,soi.[Subtotal5Amount]
		,soi.[Subtotal6Amount]
        ,soi.[Route]
        ,soi.[BillingDate]
        ,soi.[CustomerPurchaseOrderType]
        ,soi.[YourReference]
        ,soi.[OriginalRequestedDeliveryDate]
        ,soi.[FirstConfirmedDeliveryDate]
        ,soi.[LatestRDD]
        ,soi.[LatestFCDD]
        ,soi.[LatestCDD]
        ,soi.[UltimateCustomerBarcode]
        ,soi.[OuterCartonPackFactor]
        ,soi.[MaterialByCustomer]
        ,soi.[CustomerOrdertype]
        ,soi.[InnerCartonPackFactor]
        ,soi.[RequirementSegment]
        ,soi.[AdditionalValueDays]
        ,soi.[PriceDetnExchangeRate]
        ,soi.[ExchangeRateDate]
        ,soi.[IncotermsVersion]
        ,soi.[TargetQuantity]
        ,soi.[OriginallyRequestedMaterial]
        ,soi.[StatisticalValueControl]
        ,soi.[DeliveryPriority]
        ,soi.[ShippingPoint]
        ,soi.[RequestedDeliveryDate]
        ,soi.[SalesDocumentCondition]
		,soi.[IsDeleted]
		,soi.[LDTS]
		,CONVERT([BINARY](16),
				HASHBYTES('MD5',CONCAT(
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SalesDocument]                )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SalesDocumentItem]			 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CustomerConditionGroup1]		 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PoType]						 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ShippingConditionItm]		 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SalesDocumentItemCategory]	 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PurchaseOrderByCustomer]		 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PurchaseConfirmationStatus]	 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PaymentMethod]				 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CreationDateItem]			 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[LastChangeDate]				 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FixedValueDate]				 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Division]					 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),CASE WHEN soi.[IsDeleted] = 0 THEN soi.[Material] ELSE DEL.MaterialNumber END)))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[MaterialGroup]				 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ShipToParty]					 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PayerParty]					 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[BillToParty]					 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SoldToParty]					 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[OrderQuantity]				 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[OrderQuantityUnit]			 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TargetQuantityUnit]			 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ConfdDelivQtyInOrderQtyUnit]	 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ConfdDeliveryQtyInBaseUnit]	 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[BaseUnit]					 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ItemGrossWeight]				 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ItemNetWeight]				 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ItemWeightUnit]				 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CustomerPaymentTerms]		 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SalesDocumentItemType]		 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SalesDocumentRjcnReason]		 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PricingDate]					 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[NetAmount]					 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TransactionCurrency]			 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SalesOrganization]			 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[BillingCompanyCode]			 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[NetPriceAmount]				 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CostAmount]					 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Plant]						 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[StorageLocation]				 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[IncotermsClassification]		 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[IncotermsTransferLocation]	 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ItemBillingBlockReason]		 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ItemIsBillingRelevant]		 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),CASE WHEN soi.[IsDeleted] = 0 THEN soi.[ReferenceSDDocument] ELSE DEL.ReferenceSDDocument END)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),CASE WHEN soi.[IsDeleted] = 0 THEN soi.[ReferenceDocumentItemNumber] ELSE DEL.ReferenceDocumentItemNumber END)))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),CASE WHEN soi.[IsDeleted] = 0 THEN soi.[PrecedingDocumentCategory] ELSE DEL.[PrecedingDocumentCategory] END)))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ProductSeason]				 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ProductSeasonYear]			 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DeliveryBlockStatus]			 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TotalSDDocReferenceStatus]	 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SDDocumentRejectionStatus]	 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[IncompletionStatus]			 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[IncompletionStatusBilling]	 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PricingIncompletionStatus]	 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[IncompletionStatusDelivery]	 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DeliveryConfirmationStatus]	 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TotalDeliveryStatus]			 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DeliveryStatus]				 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CorrespncExternalReference]	 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[EAN]							 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Promotion]					 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TaxAmount]					 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Subtotal1Amount]				 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Subtotal2Amount]				 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Subtotal3Amount]				 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Subtotal4Amount]				 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Subtotal5Amount]				 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Subtotal6Amount]				 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Route]						 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[BillingDate]					 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CustomerPurchaseOrderType]	 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[YourReference]				 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[OriginalRequestedDeliveryDate])))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FirstConfirmedDeliveryDate]	 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[LatestRDD]					 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[LatestFCDD]					 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[LatestCDD]					 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[UltimateCustomerBarcode]		 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[OuterCartonPackFactor]		 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[MaterialByCustomer]			 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CustomerOrdertype]			 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[InnerCartonPackFactor]		 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[RequirementSegment]			 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[AdditionalValueDays]			 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PriceDetnExchangeRate]		 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ExchangeRateDate]			 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[IncotermsVersion]			 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TargetQuantity]				 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[OriginallyRequestedMaterial]	 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[StatisticalValueControl]		 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DeliveryPriority]			 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ShippingPoint]				 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[RequestedDeliveryDate]		 )))),'_',
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SalesDocumentCondition]		 )))),'_',				
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[IsDeleted]))))
			))) AS HashDiff
		INTO #soi
		FROM stag.S4hana_fnSoDocumentItems(@ldts) AS soi
		INNER JOIN biz.S4Hana_SoDocumentItemDeletionAttributes AS Del 
													ON soi.SalesDocument = Del.NatSalesOrderNo AND soi.SalesDocumentItem = Del.NatSalesOrderItemNo
		
		-- count new Records for S4Hana_SoDocumentItems
		SELECT @AffectedRows = COUNT(*)
			FROM #soi AS stg LEFT JOIN biz.S4Hana_SoDocumentItems AS prd 
			ON prd.[SalesDocument] = stg.[SalesDocument] AND prd.[SalesDocumentItem] = stg.[SalesDocumentItem]
			WHERE prd.[SalesDocument] IS NULL AND prd.[SalesDocumentItem] IS NULL

   --load new
   INSERT INTO biz.S4Hana_SoDocumentItems
			(
				 [SalesDocument]
				,[SalesDocumentItem]
				,[CustomerConditionGroup1]
				,[PoType]
				,[ShippingConditionItm]
				,[SalesDocumentItemCategory]
				,[PurchaseOrderByCustomer]
				,[PurchaseConfirmationStatus]
				,[PaymentMethod]
				,[CreationDateItem]
				,[LastChangeDate]
				,[FixedValueDate]
				,[Division]
				,Material
				,[MaterialGroup]
				,[ShipToParty]
				,[PayerParty]
				,[BillToParty]
				,[SoldToParty]
				,[OrderQuantity]
				,[OrderQuantityUnit]
				,[TargetQuantityUnit]
				,[ConfdDelivQtyInOrderQtyUnit]
				,[ConfdDeliveryQtyInBaseUnit]
				,[BaseUnit]
				,[ItemGrossWeight]
				,[ItemNetWeight]
				,[ItemWeightUnit]
				,[CustomerPaymentTerms]
				,[SalesDocumentItemType]
				,[SalesDocumentRjcnReason]
				,[PricingDate]
				,[NetAmount]
				,NetAmountUnit
				,GrossSalesValueUnit
				,[TransactionCurrency]
				,[SalesOrganization]
				,[BillingCompanyCode]
				,[NetPriceAmount]
				,[CostAmount]
				,[Plant]
				,[StorageLocation]
				,[IncotermsClassification]
				,[IncotermsTransferLocation]
				,[ItemBillingBlockReason]
				,[ItemIsBillingRelevant]
				,ReferenceSDDocument
				,ReferenceDocumentItemNumber
				,[PrecedingDocumentCategory]
				,[ProductSeason]
				,[ProductSeasonYear]
				,[DeliveryBlockStatus]
				,[TotalSDDocReferenceStatus]
				,[SDDocumentRejectionStatus]
				,[IncompletionStatus]
				,[IncompletionStatusBilling]
				,[PricingIncompletionStatus]
				,[IncompletionStatusDelivery]
				,[DeliveryConfirmationStatus]
				,[TotalDeliveryStatus]
				,[DeliveryStatus]
				,[CorrespncExternalReference]
				,[EAN]
				,[Promotion]
				,[TaxAmount]
				,[Subtotal1Amount]
				,[Subtotal2Amount]
				,[Subtotal3Amount]
				,[Subtotal4Amount]
				,[Subtotal5Amount]
				,[Subtotal6Amount]
				,[Route]
				,[BillingDate]
				,[CustomerPurchaseOrderType]
				,[YourReference]
				,[OriginalRequestedDeliveryDate]
				,[FirstConfirmedDeliveryDate]
				,[LatestRDD]
				,[LatestFCDD]
				,[LatestCDD]
				,[UltimateCustomerBarcode]
				,[OuterCartonPackFactor]
				,[MaterialByCustomer]
				,[CustomerOrdertype]
				,[InnerCartonPackFactor]
				,[RequirementSegment]
				,[AdditionalValueDays]
				,[PriceDetnExchangeRate]
				,[ExchangeRateDate]
				,[IncotermsVersion]
				,[TargetQuantity]
				,[OriginallyRequestedMaterial]
				,[StatisticalValueControl]
				,[DeliveryPriority]
				,[ShippingPoint]
				,[RequestedDeliveryDate]
				,[SalesDocumentCondition]
				,[IsDeleted]
				,[LDTS]
				,[HashDiff]
			
			)
	SELECT 
				 stg.[SalesDocument]
				,stg.[SalesDocumentItem]
				,stg.[CustomerConditionGroup1]
				,stg.[PoType]
				,stg.[ShippingConditionItm]
				,stg.[SalesDocumentItemCategory]
				,stg.[PurchaseOrderByCustomer]
				,stg.[PurchaseConfirmationStatus]
				,stg.[PaymentMethod]
				,stg.[CreationDateItem]
				,stg.[LastChangeDate]
				,stg.[FixedValueDate]
				,stg.[Division]
				,stg.Material
				,stg.[MaterialGroup]
				,stg.[ShipToParty]
				,stg.[PayerParty]
				,stg.[BillToParty]
				,stg.[SoldToParty]
				,stg.[OrderQuantity]
				,stg.[OrderQuantityUnit]
				,stg.[TargetQuantityUnit]
				,stg.[ConfdDelivQtyInOrderQtyUnit]
				,stg.[ConfdDeliveryQtyInBaseUnit]
				,stg.[BaseUnit]
				,stg.[ItemGrossWeight]
				,stg.[ItemNetWeight]
				,stg.[ItemWeightUnit]
				,stg.[CustomerPaymentTerms]
				,stg.[SalesDocumentItemType]
				,stg.[SalesDocumentRjcnReason]
				,stg.[PricingDate]
				,stg.[NetAmount]
				,stg.NetAmountUnit
				,stg.GrossSalesValueUnit
				,stg.[TransactionCurrency]
				,stg.[SalesOrganization]
				,stg.[BillingCompanyCode]
				,stg.[NetPriceAmount]
				,stg.[CostAmount]
				,stg.[Plant]
				,stg.[StorageLocation]
				,stg.[IncotermsClassification]
				,stg.[IncotermsTransferLocation]
				,stg.[ItemBillingBlockReason]
				,stg.[ItemIsBillingRelevant]
				,stg.ReferenceSDDocument
				,stg.ReferenceDocumentItemNumber
				,stg.[PrecedingDocumentCategory]
				,stg.[ProductSeason]
				,stg.[ProductSeasonYear]
				,stg.[DeliveryBlockStatus]
				,stg.[TotalSDDocReferenceStatus]
				,stg.[SDDocumentRejectionStatus]
				,stg.[IncompletionStatus]
				,stg.[IncompletionStatusBilling]
				,stg.[PricingIncompletionStatus]
				,stg.[IncompletionStatusDelivery]
				,stg.[DeliveryConfirmationStatus]
				,stg.[TotalDeliveryStatus]
				,stg.[DeliveryStatus]
				,stg.[CorrespncExternalReference]
				,stg.[EAN]
				,stg.[Promotion]
				,stg.[TaxAmount]
				,stg.[Subtotal1Amount]
				,stg.[Subtotal2Amount]
				,stg.[Subtotal3Amount]
				,stg.[Subtotal4Amount]
				,stg.[Subtotal5Amount]
				,stg.[Subtotal6Amount]
				,stg.[Route]
				,stg.[BillingDate]
				,stg.[CustomerPurchaseOrderType]
				,stg.[YourReference]
				,stg.[OriginalRequestedDeliveryDate]
				,stg.[FirstConfirmedDeliveryDate]
				,stg.[LatestRDD]
				,stg.[LatestFCDD]
				,stg.[LatestCDD]
				,stg.[UltimateCustomerBarcode]
				,stg.[OuterCartonPackFactor]
				,stg.[MaterialByCustomer]
				,stg.[CustomerOrdertype]
				,stg.[InnerCartonPackFactor]
				,stg.[RequirementSegment]
				,stg.[AdditionalValueDays]
				,stg.[PriceDetnExchangeRate]
				,stg.[ExchangeRateDate]
				,stg.[IncotermsVersion]
				,stg.[TargetQuantity]
				,stg.[OriginallyRequestedMaterial]
				,stg.[StatisticalValueControl]
				,stg.[DeliveryPriority]
				,stg.[ShippingPoint]
				,stg.[RequestedDeliveryDate]
				,stg.[SalesDocumentCondition]
				,stg.[IsDeleted]
				,stg.[LDTS]
				,stg.[HashDiff]
		 FROM #soi AS stg LEFT JOIN biz.S4Hana_SoDocumentItems AS prd 
			ON prd.[SalesDocument] = stg.[SalesDocument] AND prd.[SalesDocumentItem] = stg.[SalesDocumentItem]
		 WHERE prd.[SalesDocument] IS NULL AND prd.[SalesDocumentItem] IS NULL
	
		UPDATE DTlogs
		SET Inserted = @AffectedRows
		FROM etl.DataTransferLogs DTlogs
		WHERE DataTransferLogId = @DataTransferLogId


		-- count new Records for S4Hana_SoDocumentItems
		SELECT @AffectedRows = COUNT(*)
		FROM #soi AS stg JOIN biz.S4Hana_SoDocumentItems AS prd 
		ON prd.[SalesDocument] = stg.[SalesDocument] AND prd.[SalesDocumentItem] = stg.[SalesDocumentItem]
		WHERE stg.HashDiff <> prd.HashDiff


		  UPDATE prd SET	
				 prd.[SalesDocument]                = stg.[SalesDocument]                
				,prd.[SalesDocumentItem]            = stg.[SalesDocumentItem]            
				,prd.[CustomerConditionGroup1]		= stg.[CustomerConditionGroup1]		
				,prd.[PoType]						= stg.[PoType]						
				,prd.[ShippingConditionItm]			= stg.[ShippingConditionItm]			
				,prd.[SalesDocumentItemCategory]	= stg.[SalesDocumentItemCategory]	
				,prd.[PurchaseOrderByCustomer]		= stg.[PurchaseOrderByCustomer]		
				,prd.[PurchaseConfirmationStatus]	= stg.[PurchaseConfirmationStatus]	
				,prd.[PaymentMethod]				= stg.[PaymentMethod]				
				,prd.[CreationDateItem]				= stg.[CreationDateItem]				
				,prd.[LastChangeDate]				= stg.[LastChangeDate]				
				,prd.[FixedValueDate]				= stg.[FixedValueDate]				
				,prd.[Division]						= stg.[Division]						
				,prd.Material						= stg.Material						
				,prd.[MaterialGroup]				= stg.[MaterialGroup]				
				,prd.[ShipToParty]					= stg.[ShipToParty]					
				,prd.[PayerParty]					= stg.[PayerParty]					
				,prd.[BillToParty]					= stg.[BillToParty]					
				,prd.[SoldToParty]					= stg.[SoldToParty]					
				,prd.[OrderQuantity]				= stg.[OrderQuantity]				
				,prd.[OrderQuantityUnit]			= stg.[OrderQuantityUnit]			
				,prd.[TargetQuantityUnit]			= stg.[TargetQuantityUnit]			
				,prd.[ConfdDelivQtyInOrderQtyUnit]	= stg.[ConfdDelivQtyInOrderQtyUnit]	
				,prd.[ConfdDeliveryQtyInBaseUnit]	= stg.[ConfdDeliveryQtyInBaseUnit]	
				,prd.[BaseUnit]						= stg.[BaseUnit]						
				,prd.[ItemGrossWeight]				= stg.[ItemGrossWeight]				
				,prd.[ItemNetWeight]				= stg.[ItemNetWeight]				
				,prd.[ItemWeightUnit]				= stg.[ItemWeightUnit]				
				,prd.[CustomerPaymentTerms]			= stg.[CustomerPaymentTerms]			
				,prd.[SalesDocumentItemType]		= stg.[SalesDocumentItemType]		
				,prd.[SalesDocumentRjcnReason]		= stg.[SalesDocumentRjcnReason]		
				,prd.[PricingDate]					= stg.[PricingDate]					
				,prd.[NetAmount]					= stg.[NetAmount]					
				,prd.NetAmountUnit					= stg.NetAmountUnit					
				,prd.GrossSalesValueUnit			= stg.GrossSalesValueUnit			
				,prd.[TransactionCurrency]			= stg.[TransactionCurrency]			
				,prd.[SalesOrganization]			= stg.[SalesOrganization]			
				,prd.[BillingCompanyCode]			= stg.[BillingCompanyCode]			
				,prd.[NetPriceAmount]				= stg.[NetPriceAmount]				
				,prd.[CostAmount]					= stg.[CostAmount]					
				,prd.[Plant]						= stg.[Plant]						
				,prd.[StorageLocation]				= stg.[StorageLocation]				
				,prd.[IncotermsClassification]		= stg.[IncotermsClassification]		
				,prd.[IncotermsTransferLocation]	= stg.[IncotermsTransferLocation]	
				,prd.[ItemBillingBlockReason]		= stg.[ItemBillingBlockReason]		
				,prd.[ItemIsBillingRelevant]		= stg.[ItemIsBillingRelevant]		
				,prd.ReferenceSDDocument			= stg.ReferenceSDDocument			
				,prd.ReferenceDocumentItemNumber	= stg.ReferenceDocumentItemNumber	
				,prd.[PrecedingDocumentCategory]	= stg.[PrecedingDocumentCategory]	
				,prd.[ProductSeason]				= stg.[ProductSeason]				
				,prd.[ProductSeasonYear]			= stg.[ProductSeasonYear]			
				,prd.[DeliveryBlockStatus]			= stg.[DeliveryBlockStatus]			
				,prd.[TotalSDDocReferenceStatus]	= stg.[TotalSDDocReferenceStatus]	
				,prd.[SDDocumentRejectionStatus]	= stg.[SDDocumentRejectionStatus]	
				,prd.[IncompletionStatus]			= stg.[IncompletionStatus]			
				,prd.[IncompletionStatusBilling]	= stg.[IncompletionStatusBilling]	
				,prd.[PricingIncompletionStatus]	= stg.[PricingIncompletionStatus]	
				,prd.[IncompletionStatusDelivery]	= stg.[IncompletionStatusDelivery]	
				,prd.[DeliveryConfirmationStatus]	= stg.[DeliveryConfirmationStatus]	
				,prd.[TotalDeliveryStatus]			= stg.[TotalDeliveryStatus]			
				,prd.[DeliveryStatus]				= stg.[DeliveryStatus]				
				,prd.[CorrespncExternalReference]	= stg.[CorrespncExternalReference]	
				,prd.[EAN]							= stg.[EAN]							
				,prd.[Promotion]					= stg.[Promotion]					
				,prd.[TaxAmount]					= stg.[TaxAmount]					
				,prd.[Subtotal1Amount]				= stg.[Subtotal1Amount]				
				,prd.[Subtotal2Amount]				= stg.[Subtotal2Amount]				
				,prd.[Subtotal3Amount]				= stg.[Subtotal3Amount]				
				,prd.[Subtotal4Amount]				= stg.[Subtotal4Amount]				
				,prd.[Subtotal5Amount]				= stg.[Subtotal5Amount]				
				,prd.[Subtotal6Amount]				= stg.[Subtotal6Amount]				
				,prd.[Route]						= stg.[Route]						
				,prd.[BillingDate]					= stg.[BillingDate]					
				,prd.[CustomerPurchaseOrderType]	= stg.[CustomerPurchaseOrderType]	
				,prd.[YourReference]				= stg.[YourReference]				
				,prd.[OriginalRequestedDeliveryDate]= stg.[OriginalRequestedDeliveryDate]
				,prd.[FirstConfirmedDeliveryDate]	= stg.[FirstConfirmedDeliveryDate]	
				,prd.[LatestRDD]					= stg.[LatestRDD]					
				,prd.[LatestFCDD]					= stg.[LatestFCDD]					
				,prd.[LatestCDD]					= stg.[LatestCDD]					
				,prd.[UltimateCustomerBarcode]		= stg.[UltimateCustomerBarcode]		
				,prd.[OuterCartonPackFactor]		= stg.[OuterCartonPackFactor]		
				,prd.[MaterialByCustomer]			= stg.[MaterialByCustomer]			
				,prd.[CustomerOrdertype]			= stg.[CustomerOrdertype]			
				,prd.[InnerCartonPackFactor]		= stg.[InnerCartonPackFactor]		
				,prd.[RequirementSegment]			= stg.[RequirementSegment]			
				,prd.[AdditionalValueDays]			= stg.[AdditionalValueDays]			
				,prd.[PriceDetnExchangeRate]		= stg.[PriceDetnExchangeRate]		
				,prd.[ExchangeRateDate]				= stg.[ExchangeRateDate]				
				,prd.[IncotermsVersion]				= stg.[IncotermsVersion]				
				,prd.[TargetQuantity]				= stg.[TargetQuantity]				
				,prd.[OriginallyRequestedMaterial]	= stg.[OriginallyRequestedMaterial]	
				,prd.[StatisticalValueControl]		= stg.[StatisticalValueControl]		
				,prd.[DeliveryPriority]				= stg.[DeliveryPriority]				
				,prd.[ShippingPoint]				= stg.[ShippingPoint]				
				,prd.[RequestedDeliveryDate]		= stg.[RequestedDeliveryDate]		
				,prd.[SalesDocumentCondition]		= stg.[SalesDocumentCondition]		
				,prd.[IsDeleted]					= stg.[IsDeleted]					
				,prd.[LDTS]							= stg.[LDTS]							
				,prd.[HashDiff]						= stg.[HashDiff]						
			FROM #soi AS stg JOIN [biz].[S4Hana_SoDocumentItems] AS prd 
				ON prd.[SalesDocument] = stg.[SalesDocument] AND prd.[SalesDocumentItem] = stg.[SalesDocumentItem]
			WHERE stg.HashDiff <> prd.HashDiff

			UPDATE DTlogs
			SET Updated = @AffectedRows
			, ExecEnd = GETDATE()
			FROM etl.DataTransferLogs DTlogs
			WHERE DataTransferLogId = @DataTransferLogId


END

--truncate table biz.S4Hana_SoDocumentItems
--exec [biz].[S4Hana_spSoDocumentItems]'1900-01-01'