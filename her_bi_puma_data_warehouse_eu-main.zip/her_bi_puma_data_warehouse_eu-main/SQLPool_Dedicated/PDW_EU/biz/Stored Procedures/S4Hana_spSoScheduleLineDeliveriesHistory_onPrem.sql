﻿CREATE PROC [biz].[S4Hana_spSoScheduleLineDeliveriesHistory_onPrem] @LDTS [DATETIME2](7) AS
BEGIN
SET NOCOUNT ON

--DECLARE @LDTS DATETIME2(7) = '2000-01-01'
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(0) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(0)
DECLARE @DestinationLastLoadDate DATETIME2(0)
DECLARE @BatchLdts DATETIME2(0) = @LDTS

IF(EXISTS(SELECT 1 FROM biz.S4Hana_SoScheduleLineDeliveriesHistory_onPrem))
BEGIN
	SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(LDTS))
	FROM biz.S4Hana_SoScheduleLineDeliveriesHistory_onPrem
END
ELSE BEGIN
	SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
END 

IF(EXISTS(SELECT 1 FROM stag.S4Hana_SOScheduleLines_full_onPrem))
BEGIN
	SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(LDTS))
	FROM biz.S4Hana_SoScheduleLinesHistory_onPrem
END
ELSE BEGIN
	SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
END 

--Log Data load
INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'SoScheduleLineDeliveriesHistory_onPrem'
			,'prepSoDocHist_OnPrem'
			,'NatSalesOrdersOohHistory_onPrem'
			,'sales'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts

--> Start merge Scheduline & Delivey notes

IF OBJECT_ID('tempdb..#DistLdtsSoItemDeliveries') IS NOT NULL
BEGIN
    DROP TABLE #DistLdtsSoItemDeliveries
END

CREATE TABLE #DistLdtsSoItemDeliveries
WITH
(DISTRIBUTION = HASH(NatSalesOrderNo)
,HEAP)
AS(
SELECT NatSalesOrderNo
      ,NatSalesOrderItemNo
      ,LDTS
FROM biz.S4Hana_SODocumentDeliveriesHistory_onPrem
WHERE LDTS > @DestinationLastLoadDate
UNION
SELECT NatSalesOrderNo
      ,NatSalesOrderItemNo
      ,LDTS
FROM biz.S4Hana_SoScheduleLinesHistory_onPrem
WHERE LDTS > @DestinationLastLoadDate
)

IF OBJECT_ID('tempdb..#DistLdtsSoItemSchLineDeliveries') IS NOT NULL
BEGIN
    DROP TABLE #DistLdtsSoItemSchLineDeliveries
END

CREATE TABLE #DistLdtsSoItemSchLineDeliveries
WITH
(DISTRIBUTION = HASH(NatSalesOrderNo)
,HEAP)
AS(
SELECT DISTINCT 
	   schL.NatSalesOrderNo
      ,schL.NatSalesOrderItemNo
      ,schL.ScheduleLine
      ,soItemLdts.LDTS
FROM biz.S4Hana_SoScheduleLinesHistory_onPrem AS schL
INNER JOIN #DistLdtsSoItemDeliveries AS soItemLdts
	ON schL.NatSalesOrderNo = soItemLdts.NatSalesOrderNo
	AND schL.NatSalesOrderItemNo = soItemLdts.NatSalesOrderItemNo)

IF OBJECT_ID('tempdb..#SoItemSchLineDeliveries') IS NOT NULL
BEGIN
    DROP TABLE #SoItemSchLineDeliveries
END

CREATE TABLE #SoItemSchLineDeliveries
WITH
(DISTRIBUTION = HASH(NatSalesOrderNo)
,HEAP)
AS WITH SOScheduleLinesLast 
AS(
SELECT distLDTS.NatSalesOrderNo
		  ,distLDTS.NatSalesOrderItemNo
		  ,distLDTS.ScheduleLine
		  ,distLDTS.LDTS
		  ,SoSchLines.ScheduleLineDate
		  ,SoSchLines.ConfirmedOrderQuantity
		  ,CONVERT(DECIMAL(13, 3), CASE WHEN s_sdel.DeliveryStatus IN ('B', 'C') 
										AND year(s_sdel.ActualGoodsMovementDate) > 1970 
										--AND s_sdel.IsDeleted = 0 -- filtered out at the next level
										THEN SoSchLines.ConfirmedOrderQuantity 
								ELSE NULL END) 
				AS Pre_OOHUnits
		  ,CONVERT(SMALLINT, CASE WHEN s_sdel.DeliveryStatus = 'B' 
								  AND year(s_sdel.ActualGoodsMovementDate) > 1970 
								  AND s_sdel.IsDeleted = 0 THEN 2 
								  WHEN s_sdel.DeliveryStatus = 'C' 
								  AND year(s_sdel.ActualGoodsMovementDate) > 1970 
								  AND s_sdel.IsDeleted = 0 THEN 3	  
								  ELSE 1 END) 
			AS Pre_IntSOStatusCode
		  ,SoSchLines.IsDeleted AS SchLineIsDelted
		  ,s_sdel.DeliveryStatus
		  ,s_sdel.ActualGoodsMovementDate
		  ,s_sdel.NatSalesOrderDeleted
		  ,s_sdel.IsDeleted AS DeliveryIsDeleted
	FROM #DistLdtsSoItemSchLineDeliveries AS distLDTS
	LEFT JOIN biz.S4Hana_SoScheduleLinesHistory_onPrem AS SoSchLines
		ON distLDTS.NatSalesOrderNo = SoSchLines.NatSalesOrderNo
		AND distLDTS.NatSalesOrderItemNo = SoSchLines.NatSalesOrderItemNo
		AND distLDTS.ScheduleLine = SoSchLines.ScheduleLine	
		AND distLDTS.LDTS BETWEEN SoSchLines.LDTS AND SoSchLines.LEDTS
	LEFT JOIN biz.S4Hana_SODocumentDeliveriesHistory_onPrem AS s_sdel
		ON distLDTS.NatSalesOrderNo = s_sdel.NatSalesOrderNo
		AND distLDTS.NatSalesOrderItemNo = s_sdel.NatSalesOrderItemNo
		AND distLDTS.ScheduleLine = s_sdel.ScheduleLine
		AND distLDTS.LDTS BETWEEN s_sdel.LDTS AND s_sdel.LEDTS)
SELECT NatSalesOrderNo
	  ,NatSalesOrderItemNo
	  ,MIN(ScheduleLineDate) AS MinScheduleLineDate
	  ,MAX(ScheduleLineDate) AS MaxScheduleLineDate
	  ,MIN(Pre_IntSOStatusCode) AS MinPre_IntSOStatusCode
	  ,MAX(Pre_IntSOStatusCode) AS MaxPre_IntSOStatusCode
	  ,SUM(CASE WHEN SchLineIsDelted = 0 THEN ConfirmedOrderQuantity ELSE NULL END) AS ConfirmedOrderQuantity
	  ,SUM(CASE WHEN SchLineIsDelted = 0 THEN Pre_OOHUnits ELSE NULL END) AS Pre_OOHUnits
	  ,MIN(SchLineIsDelted) AS IsDeleted
	  ,LDTS
	  ,CONVERT(BINARY(16), 
			HASHBYTES('MD5',CONCAT( 
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),NatSalesOrderNo)))),'_', 
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),NatSalesOrderItemNo)))),'_', 
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),MIN(ScheduleLineDate))))),'_', 
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),MAX(ScheduleLineDate))))),'_', 
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),MIN(Pre_IntSOStatusCode))))),'_', 
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),MAX(Pre_IntSOStatusCode))))),'_', 
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),SUM(CASE WHEN SchLineIsDelted = 0 THEN NULL ELSE ConfirmedOrderQuantity END))))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),SUM(CASE WHEN SchLineIsDelted = 0 THEN NULL ELSE Pre_OOHUnits END))))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),MIN(SchLineIsDelted)))))
         ))) AS HashDiff 
	  ,CONVERT(TINYINT,1) AS SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist
FROM SOScheduleLinesLast
GROUP BY NatSalesOrderNo
	    ,NatSalesOrderItemNo
		,LDTS

-- Add last related entires from Hist which are in the new batch
INSERT INTO #SoItemSchLineDeliveries
	(NatSalesOrderNo
	,NatSalesOrderItemNo
	,MinScheduleLineDate
	,MaxScheduleLineDate
	,MinPre_IntSOStatusCode
	,MaxPre_IntSOStatusCode
	,ConfirmedOrderQuantity
	,Pre_OOHUnits
	,IsDeleted
	,LDTS
	,HashDiff
	,SourceIdentifier)
SELECT SoSchHist.NatSalesOrderNo
	  ,SoSchHist.NatSalesOrderItemNo
	  ,SoSchHist.MinScheduleLineDate
	  ,SoSchHist.MaxScheduleLineDate
	  ,SoSchHist.MinPre_IntSOStatusCode
	  ,SoSchHist.MaxPre_IntSOStatusCode
	  ,SoSchHist.ConfirmedOrderQuantity
	  ,SoSchHist.Pre_OOHUnits
	  ,SoSchHist.IsDeleted
	  ,SoSchHist.LDTS
	  ,SoSchHist.HashDiff
	  ,CONVERT(TINYINT,2) AS SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist
FROM #SoItemSchLineDeliveries AS stagNew
INNER JOIN biz.S4Hana_SoScheduleLineDeliveriesHistory_onPrem AS SoSchHist
		ON stagNew.NatSalesOrderNo = SoSchHist.NatSalesOrderNo
		AND stagNew.NatSalesOrderItemNo = SoSchHist.NatSalesOrderItemNo
		AND SoSchHist.LEDTS = '9999-12-31' ---> Get latest entrie from the hist table 

CREATE TABLE #SoScheduleLinesHistNew
WITH
(DISTRIBUTION = HASH(NatSalesOrderNo)
,HEAP)
AS WITH preHash AS 
	(SELECT NatSalesOrderNo
		   ,NatSalesOrderItemNo
		   ,LDTS
		   ,HashDiff
		   ,MinScheduleLineDate
		   ,MaxScheduleLineDate
		   ,MinPre_IntSOStatusCode
		   ,MaxPre_IntSOStatusCode
		   ,ConfirmedOrderQuantity
		   ,Pre_OOHUnits
		   ,IsDeleted
		   ,SourceIdentifier
		   ,LAG(HashDiff) OVER (PARTITION BY NatSalesOrderNo, NatSalesOrderItemNo ORDER BY LDTS) AS pre_HashDiff
		   ,ROW_NUMBER() OVER (PARTITION BY NatSalesOrderNo, NatSalesOrderItemNo ORDER BY LDTS) AS RankOverAll
	FROM #SoItemSchLineDeliveries
)
,DiffCheck AS (	
	SELECT NatSalesOrderNo
		  ,NatSalesOrderItemNo
		  ,LDTS
		  ,ISNULL((DateAdd(ss ,-1, LEAD(LDTS) OVER (PARTITION BY NatSalesOrderNo, NatSalesOrderItemNo ORDER BY LDTS))),'9999-12-31') AS LEDTS
		  ,HashDiff
		  ,MinScheduleLineDate
		  ,MaxScheduleLineDate
		  ,MinPre_IntSOStatusCode
		  ,MaxPre_IntSOStatusCode
		  ,ConfirmedOrderQuantity
		  ,Pre_OOHUnits
		  ,IsDeleted
		  ,SourceIdentifier
	FROM preHash
	WHERE HashDiff <> pre_HashDiff
	   OR RankOverAll = 1 -- to get the first entry
) 
SELECT NatSalesOrderNo
	  ,NatSalesOrderItemNo
	  ,LDTS
	  ,LEDTS
	  ,HashDiff
	  ,MinScheduleLineDate
	  ,MaxScheduleLineDate
	  ,MinPre_IntSOStatusCode
	  ,MaxPre_IntSOStatusCode
	  ,ConfirmedOrderQuantity
	  ,Pre_OOHUnits
	  ,IsDeleted
	  ,SourceIdentifier
FROM DiffCheck
WHERE SourceIdentifier = 1 -- only new entiers 
  OR (SourceIdentifier = 2 AND LEDTS <> '9999-12-31') -- existing entries to update LEDTS in the HIST table 

-- Insert new entries to 
INSERT INTO biz.S4Hana_SoScheduleLineDeliveriesHistory_onPrem
	  (NatSalesOrderNo
      ,NatSalesOrderItemNo
      ,LDTS
      ,LEDTS
      ,HashDiff
	  ,MinScheduleLineDate
	  ,MaxScheduleLineDate
	  ,MinPre_IntSOStatusCode
	  ,MaxPre_IntSOStatusCode
	  ,ConfirmedOrderQuantity
	  ,Pre_OOHUnits
      ,IsDeleted)
SELECT NatSalesOrderNo
      ,NatSalesOrderItemNo
      ,LDTS
      ,LEDTS
      ,HashDiff
	  ,MinScheduleLineDate
	  ,MaxScheduleLineDate
	  ,MinPre_IntSOStatusCode
	  ,MaxPre_IntSOStatusCode
	  ,ConfirmedOrderQuantity
	  ,Pre_OOHUnits
      ,IsDeleted
FROM  #SoScheduleLinesHistNew
WHERE SourceIdentifier = 1 -- only new entiers 

--Update LEDTS for entires with fresh inserted entries for this BK
UPDATE histPre
SET histPre.LEDTS = new.LEDTS
FROM biz.S4Hana_SoScheduleLineDeliveriesHistory_onPrem AS histPre
INNER JOIN #SoScheduleLinesHistNew AS new
	ON histPre.NatSalesOrderNo = new.NatSalesOrderNo  
	AND histPre.NatSalesOrderItemNo = new.NatSalesOrderItemNo
	AND histPre.LDTS = new.LDTS
WHERE histPre.LEDTS = '9999-12-31'
  AND new.SourceIdentifier = 2 -- only update Objects loaded from Hist table

-- Update End of the load
UPDATE DTlogs
SET ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

END -- END SP