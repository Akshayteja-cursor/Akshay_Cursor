﻿CREATE PROC [biz].[S4Hana_spBPAddressTelefon] @ldts [DATETIME2](7) AS
BEGIN
	SET NOCOUNT ON;
	SET ANSI_WARNINGS ON;

	DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
	DECLARE @ExecStart DATETIME2(7) = GETDATE()
	DECLARE @SourceLastLoadDate DATETIME2(7)
	DECLARE @DestinationLastLoadDate DATETIME2(7)
	DECLARE @BatchLdts DATETIME2(7) = @LDTS
	DECLARE @AffectedRows BIGINT = NULL

	IF(EXISTS(SELECT 1 FROM [biz].[S4Hana_BPAddressTelefon]))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(LDTS))
	FROM [biz].[S4Hana_BPAddressTelefon]
	END
	ELSE BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

	IF(EXISTS(SELECT 1 FROM stag.[S4Hana_BPAddressTelefon]))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(_LDTS))
		FROM stag.[S4Hana_BPAddressTelefon]
	END
	ELSE BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END 


	--Log Data load
	INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'S4Hana_spBPAddressTelefon'
			,'biz_BPAddressTelefon'
			,'S4Hana_BPAddressTelefon'
			,'biz'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts


	IF OBJECT_ID(N'tempdb..#bpat') IS NOT NULL
	DROP TABLE #bpat;

	SELECT
	   CONCAT(BusinessPartner, '|', addrnumber, '|', persnumber, '|',ValidFromDflt, '|',SequenceNumber) AS BPAddressTelefon_BK
	  ,[BusinessPartner]
      ,[AddressNumber]
      ,[StrdAddress]
      ,[addrnumber]
      ,[persnumber]
      ,[ValidFromDflt]
      ,[SequenceNumber]
      ,[Telcountry]
      ,[StdSender]
      ,[NotUsed]
      ,[HomeFlag]
      ,[TelNumber]
      ,[TelExtension]
      ,[ComplTelNum]
      ,[TelDetCaller]
      ,[SMSEnabled]
      ,[Moble]
      ,[ValidFrom]
      ,[ValidTo]
	  ,IsDeleted       
      ,[_LDTS] as LDTS
	  ,CONVERT([BINARY](16),
				HASHBYTES('MD5',CONCAT(
	            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[BusinessPartner]		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[AddressNumber]  		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[StrdAddress]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[addrnumber]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[persnumber]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ValidFromDflt]		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SequenceNumber]		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Telcountry]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[StdSender]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[NotUsed]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[HomeFlag]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TelNumber]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TelExtension]		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ComplTelNum]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TelDetCaller]		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SMSEnabled]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Moble]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ValidFrom]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ValidTo]				  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[IsDeleted]))))))       
			) AS HashDiff

INTO #bpat
FROM
(
	SELECT
	   *
	  ,CAST(CASE WHEN __operation_type = 'X' 
					THEN 1 ELSE 0 END AS BIT)					AS IsDeleted
      ,ROW_NUMBER() OVER (PARTITION BY BusinessPartner
									, addrnumber
									, persnumber	
									, ValidFromDflt
									, SequenceNumber
						ORDER BY _LDTS DESC
								, __timestamp DESC)				AS RN
	FROM [stag].[S4Hana_BPAddressTelefon]

) X
WHERE RN = 1 and ([TelNumber] <> '' or IsDeleted=1)
and [_LDTS] > @ldts
	
		-- count new Records for S4Hana_BPAddressTelefon
		    SELECT @AffectedRows = COUNT(*)
			FROM #bpat AS stg LEFT JOIN biz.S4Hana_BPAddressTelefon AS prd 
			ON prd.BPAddressTelefon_BK = stg.BPAddressTelefon_BK 
			WHERE prd.BPAddressTelefon_BK IS NULL

   --load new
   INSERT INTO biz.S4Hana_BPAddressTelefon
			(
				 BPAddressTelefon_BK
	            ,[BusinessPartner]
                ,[AddressNumber]
                ,[StrdAddress]
                ,[addrnumber]
                ,[persnumber]
                ,[ValidFromDflt]
                ,[SequenceNumber]
                ,[Telcountry]
                ,[StdSender]
                ,[NotUsed]
                ,[HomeFlag]
                ,[TelNumber]
                ,[TelExtension]
                ,[ComplTelNum]
                ,[TelDetCaller]
                ,[SMSEnabled]
                ,[Moble]
                ,[ValidFrom]
                ,[ValidTo]
	            ,IsDeleted       
                ,LDTS
				,[HashDiff]			
			)
	SELECT 
				 stg.BPAddressTelefon_BK
	            ,stg.[BusinessPartner]
                ,stg.[AddressNumber]
                ,stg.[StrdAddress]
                ,stg.[addrnumber]
                ,stg.[persnumber]
                ,stg.[ValidFromDflt]
                ,stg.[SequenceNumber]
                ,stg.[Telcountry]
                ,stg.[StdSender]
                ,stg.[NotUsed]
                ,stg.[HomeFlag]
                ,stg.[TelNumber]
                ,stg.[TelExtension]
                ,stg.[ComplTelNum]
                ,stg.[TelDetCaller]
                ,stg.[SMSEnabled]
                ,stg.[Moble]
                ,stg.[ValidFrom]
                ,stg.[ValidTo]
	            ,stg.IsDeleted       
                ,stg.LDTS
				,stg.[HashDiff]	


		 FROM #bpat AS stg LEFT JOIN biz.S4Hana_BPAddressTelefon AS prd 
		 ON prd.BPAddressTelefon_BK = stg.BPAddressTelefon_BK 
		 WHERE prd.BPAddressTelefon_BK IS NULL
	
		UPDATE DTlogs
		SET Inserted = @AffectedRows
		FROM etl.DataTransferLogs DTlogs
		WHERE DataTransferLogId = @DataTransferLogId


		-- count new Records for S4Hana_BPAddressTelefon
		SELECT @AffectedRows = COUNT(*)
		FROM #bpat AS stg JOIN biz.S4Hana_BPAddressTelefon AS prd 
		ON prd.BPAddressTelefon_BK = stg.BPAddressTelefon_BK
		WHERE stg.HashDiff <> prd.HashDiff

		UPDATE DTlogs
		SET Updated = @AffectedRows
		, ExecEnd = GETDATE()
		FROM etl.DataTransferLogs DTlogs
		WHERE DataTransferLogId = @DataTransferLogId

		--update non deleted records
		  UPDATE prd SET	
				 prd.BPAddressTelefon_BK = stg.BPAddressTelefon_BK
	            ,prd.[BusinessPartner]	 = stg.[BusinessPartner]
                ,prd.[AddressNumber]	 = stg.[AddressNumber]
                ,prd.[StrdAddress]		 = stg.[StrdAddress]
                ,prd.[addrnumber]		 = stg.[addrnumber]
                ,prd.[persnumber]		 = stg.[persnumber]
                ,prd.[ValidFromDflt]	 = stg.[ValidFromDflt]
                ,prd.[SequenceNumber]	 = stg.[SequenceNumber]
                ,prd.[Telcountry]		 = stg.[Telcountry]
                ,prd.[StdSender]		 = stg.[StdSender]
                ,prd.[NotUsed]			 = stg.[NotUsed]
                ,prd.[HomeFlag]			 = stg.[HomeFlag]
                ,prd.[TelNumber]		 = stg.[TelNumber]
                ,prd.[TelExtension]		 = stg.[TelExtension]
                ,prd.[ComplTelNum]		 = stg.[ComplTelNum]
                ,prd.[TelDetCaller]		 = stg.[TelDetCaller]
                ,prd.[SMSEnabled]		 = stg.[SMSEnabled]
                ,prd.[Moble]			 = stg.[Moble]
                ,prd.[ValidFrom]		 = stg.[ValidFrom]
                ,prd.[ValidTo]			 = stg.[ValidTo]
	            ,prd.IsDeleted       	 = stg.IsDeleted       
                ,prd.LDTS				 = stg.LDTS
				,prd.[HashDiff]			 = stg.[HashDiff]				


			FROM #bpat AS stg JOIN biz.S4Hana_BPAddressTelefon AS prd 
			ON prd.BPAddressTelefon_BK = stg.BPAddressTelefon_BK
			WHERE stg.HashDiff <> prd.HashDiff and stg.IsDeleted = 0

		 --update deletions (only deleted status and LDTS)
		 UPDATE prd SET
				 prd.LDTS				= stg.LDTS
				,prd.IsDeleted			= stg.IsDeleted
				,prd.[HashDiff]			= stg.[HashDiff]
		 	FROM #bpat AS stg JOIN biz.S4Hana_BPAddressTelefon AS prd 
			ON prd.BPAddressTelefon_BK = stg.BPAddressTelefon_BK
			WHERE stg.HashDiff <> prd.HashDiff and stg.IsDeleted = 1


END

--truncate table biz.S4Hana_BPAddressTelefon
-- exec [biz].[S4Hana_spBPAddressTelefon]'1900-01-01'