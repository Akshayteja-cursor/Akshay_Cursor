﻿CREATE PROC [biz].[S4Hana_spCustomerBusinessPartner] @ldts [DATETIME2](7) AS
BEGIN
	SET NOCOUNT ON;
	SET ANSI_WARNINGS ON;

	DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
	DECLARE @ExecStart DATETIME2(7) = GETDATE()
	DECLARE @SourceLastLoadDate DATETIME2(7)
	DECLARE @DestinationLastLoadDate DATETIME2(7)
	DECLARE @BatchLdts DATETIME2(7) = @LDTS
	DECLARE @AffectedRows BIGINT = NULL

	IF(EXISTS(SELECT 1 FROM [biz].[S4Hana_CustomerBusinessPartner]))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(LDTS))
	FROM [biz].[S4Hana_CustomerBusinessPartner]
	END
	ELSE BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

	IF(EXISTS(SELECT 1 FROM stag.[S4Hana_CustomerBusinessPartner]))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(_LDTS))
		FROM stag.[S4Hana_CustomerBusinessPartner]
	END
	ELSE BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END 


	--Log Data load
	INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'S4Hana_spCustomerBusinessPartner'
			,'biz_CustomerBusinessPartners'
			,'S4Hana_CustomerBusinessPartner'
			,'biz'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts


	IF OBJECT_ID(N'tempdb..#cbp') IS NOT NULL
	DROP TABLE #cbp;

	SELECT
	   CONCAT([BPRelationNo], '|', [But051customer], '|', [But051partner]) AS CustomerBusinessPartner_BK
	  ,[BPRelationNo]
      ,[But051customer]
      ,[But051partner]
      ,[But051validto]
      ,[DescPartner1]
      ,[DescPartner2]
      ,[But051Reltyp]
      ,[RelationDesc]
      ,[But051roledef]
      ,[But051FunctionName]
      ,[But051Function]
      ,[FunctionDesc]
      ,[But051CompDept]
      ,[But051Departm]
      ,[But051Auth]
      ,[But051Vip]
      ,[But051Note]
      ,[But051telNo]
      ,[But051Telext]
      ,[But051FaxNo]
      ,[But051FaxExt]
      ,[But051Email]
      ,[But051Curr]
      ,[But051Ruleid]
      ,[But051RuleidVisitm]
      ,[But051RuleCall]
      ,[But051RuleVisit]
      ,[But051Dummy1]
      ,[But051Dummy2]
      ,[BPRelationNo050]
      ,[customer050]
      ,[partner2050]
      ,[validto050]
      ,[Validfrom050]
      ,[reltyp050]
      ,[roledef050]
      ,[reltype050]
      ,[CreationDate050]
      ,[ChangeDat050]
      ,[Relkinddesc]
	  ,IsDeleted       
      ,[_LDTS] as LDTS
	  ,CONVERT([BINARY](16),
				HASHBYTES('MD5',CONCAT(
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [BPRelationNo]      )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051customer]	   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051partner]	   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051validto]	   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DescPartner1]	   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DescPartner2]	   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051Reltyp]	   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [RelationDesc]	   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051roledef]	   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051FunctionName])))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051Function]	   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [FunctionDesc]	   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051CompDept]	   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051Departm]	   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051Auth]		   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051Vip]		   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051Note]		   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051telNo]	   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051Telext]	   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051FaxNo]	   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051FaxExt]	   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051Email]	   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051Curr]		   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051Ruleid]	   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051RuleidVisitm])))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051RuleCall]	   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051RuleVisit]   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051Dummy1]	   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051Dummy2]	   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [BPRelationNo050]   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [customer050]	   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [partner2050]	   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [validto050]		   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [Validfrom050]	   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [reltyp050]		   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [roledef050]		   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [reltype050]		   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [CreationDate050]   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [ChangeDat050]	   )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [Relkinddesc]       )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [IsDeleted]))))))       
			) AS HashDiff

INTO #cbp
FROM 
(
	SELECT
	 *
	, CAST(CASE WHEN __operation_type = 'X' 
		THEN 1 ELSE 0 END AS BIT)				AS IsDeleted
	, ROW_NUMBER() OVER (PARTITION BY BPRelationNo,But051customer,But051partner 
					ORDER BY _LDTS DESC
						, __timestamp DESC)		AS RN
	FROM [stag].[S4Hana_CustomerBusinessPartner]
) X
WHERE RN = 1
and [_LDTS] > @ldts
	
		-- count new Records for S4Hana_CustomerBusinessPartner
		    SELECT @AffectedRows = COUNT(*)
			FROM #cbp AS stg LEFT JOIN biz.S4Hana_CustomerBusinessPartner AS prd 
			ON prd.CustomerBusinessPartner_BK = stg.CustomerBusinessPartner_BK 
			WHERE prd.CustomerBusinessPartner_BK IS NULL

   --load new
   INSERT INTO biz.S4Hana_CustomerBusinessPartner
			(
				 CustomerBusinessPartner_BK
	            ,[BPRelationNo]
                ,[But051customer]
                ,[But051partner]
                ,[But051validto]
                ,[DescPartner1]
                ,[DescPartner2]
                ,[But051Reltyp]
                ,[RelationDesc]
                ,[But051roledef]
                ,[But051FunctionName]
                ,[But051Function]
                ,[FunctionDesc]
                ,[But051CompDept]
                ,[But051Departm]
                ,[But051Auth]
                ,[But051Vip]
                ,[But051Note]
                ,[But051telNo]
                ,[But051Telext]
                ,[But051FaxNo]
                ,[But051FaxExt]
                ,[But051Email]
                ,[But051Curr]
                ,[But051Ruleid]
                ,[But051RuleidVisitm]
                ,[But051RuleCall]
                ,[But051RuleVisit]
                ,[But051Dummy1]
                ,[But051Dummy2]
                ,[BPRelationNo050]
                ,[customer050]
                ,[partner2050]
                ,[validto050]
                ,[Validfrom050]
                ,[reltyp050]
                ,[roledef050]
                ,[reltype050]
                ,[CreationDate050]
                ,[ChangeDat050]
                ,[Relkinddesc]
	            ,IsDeleted       
                ,LDTS
				,[HashDiff]			
			)
	SELECT 
				 stg.CustomerBusinessPartner_BK
				,stg.[BPRelationNo]
				,stg.[But051customer]
				,stg.[But051partner]
				,stg.[But051validto]
				,stg.[DescPartner1]
				,stg.[DescPartner2]
				,stg.[But051Reltyp]
				,stg.[RelationDesc]
				,stg.[But051roledef]
				,stg.[But051FunctionName]
				,stg.[But051Function]
				,stg.[FunctionDesc]
				,stg.[But051CompDept]
				,stg.[But051Departm]
				,stg.[But051Auth]
				,stg.[But051Vip]
				,stg.[But051Note]
				,stg.[But051telNo]
				,stg.[But051Telext]
				,stg.[But051FaxNo]
				,stg.[But051FaxExt]
				,stg.[But051Email]
				,stg.[But051Curr]
				,stg.[But051Ruleid]
				,stg.[But051RuleidVisitm]
				,stg.[But051RuleCall]
				,stg.[But051RuleVisit]
				,stg.[But051Dummy1]
				,stg.[But051Dummy2]
				,stg.[BPRelationNo050]
				,stg.[customer050]
				,stg.[partner2050]
				,stg.[validto050]
				,stg.[Validfrom050]
				,stg.[reltyp050]
				,stg.[roledef050]
				,stg.[reltype050]
				,stg.[CreationDate050]
				,stg.[ChangeDat050]
				,stg.[Relkinddesc]
				,stg.IsDeleted       
				,stg.LDTS
				,stg.[HashDiff]			


		 FROM #cbp AS stg LEFT JOIN biz.S4Hana_CustomerBusinessPartner AS prd 
		 ON prd.CustomerBusinessPartner_BK = stg.CustomerBusinessPartner_BK 
		 WHERE prd.CustomerBusinessPartner_BK IS NULL
	
		UPDATE DTlogs
		SET Inserted = @AffectedRows
		FROM etl.DataTransferLogs DTlogs
		WHERE DataTransferLogId = @DataTransferLogId


		-- count new Records for S4Hana_CustomerBusinessPartner
		SELECT @AffectedRows = COUNT(*)
		FROM #cbp AS stg JOIN biz.S4Hana_CustomerBusinessPartner AS prd 
		ON prd.CustomerBusinessPartner_BK = stg.CustomerBusinessPartner_BK
		WHERE stg.HashDiff <> prd.HashDiff

		UPDATE DTlogs
		SET Updated = @AffectedRows
		, ExecEnd = GETDATE()
		FROM etl.DataTransferLogs DTlogs
		WHERE DataTransferLogId = @DataTransferLogId

		--update non deleted records
		  UPDATE prd SET	
				 prd.CustomerBusinessPartner_BK  = stg.CustomerBusinessPartner_BK
				,prd.[BPRelationNo]				 = stg.[BPRelationNo]			
				,prd.[But051customer]			 = stg.[But051customer]			
				,prd.[But051partner]			 = stg.[But051partner]			
				,prd.[But051validto]			 = stg.[But051validto]			
				,prd.[DescPartner1]				 = stg.[DescPartner1]			
				,prd.[DescPartner2]				 = stg.[DescPartner2]			
				,prd.[But051Reltyp]				 = stg.[But051Reltyp]			
				,prd.[RelationDesc]				 = stg.[RelationDesc]			
				,prd.[But051roledef]			 = stg.[But051roledef]			
				,prd.[But051FunctionName]		 = stg.[But051FunctionName]		
				,prd.[But051Function]			 = stg.[But051Function]			
				,prd.[FunctionDesc]				 = stg.[FunctionDesc]			
				,prd.[But051CompDept]			 = stg.[But051CompDept]			
				,prd.[But051Departm]			 = stg.[But051Departm]			
				,prd.[But051Auth]				 = stg.[But051Auth]				
				,prd.[But051Vip]				 = stg.[But051Vip]				
				,prd.[But051Note]				 = stg.[But051Note]				
				,prd.[But051telNo]				 = stg.[But051telNo]			
				,prd.[But051Telext]				 = stg.[But051Telext]			
				,prd.[But051FaxNo]				 = stg.[But051FaxNo]			
				,prd.[But051FaxExt]				 = stg.[But051FaxExt]			
				,prd.[But051Email]				 = stg.[But051Email]			
				,prd.[But051Curr]				 = stg.[But051Curr]				
				,prd.[But051Ruleid]				 = stg.[But051Ruleid]			
				,prd.[But051RuleidVisitm]		 = stg.[But051RuleidVisitm]		
				,prd.[But051RuleCall]			 = stg.[But051RuleCall]			
				,prd.[But051RuleVisit]			 = stg.[But051RuleVisit]		
				,prd.[But051Dummy1]				 = stg.[But051Dummy1]			
				,prd.[But051Dummy2]				 = stg.[But051Dummy2]			
				,prd.[BPRelationNo050]			 = stg.[BPRelationNo050]		
				,prd.[customer050]				 = stg.[customer050]			
				,prd.[partner2050]				 = stg.[partner2050]			
				,prd.[validto050]				 = stg.[validto050]				
				,prd.[Validfrom050]				 = stg.[Validfrom050]			
				,prd.[reltyp050]				 = stg.[reltyp050]				
				,prd.[roledef050]				 = stg.[roledef050]				
				,prd.[reltype050]				 = stg.[reltype050]				
				,prd.[CreationDate050]			 = stg.[CreationDate050]		
				,prd.[ChangeDat050]				 = stg.[ChangeDat050]			
				,prd.[Relkinddesc]				 = stg.[Relkinddesc]			
				,prd.IsDeleted       			 = stg.IsDeleted       			
				,prd.LDTS						 = stg.LDTS						
				,prd.[HashDiff]					 = stg.[HashDiff]					


			FROM #cbp AS stg JOIN biz.S4Hana_CustomerBusinessPartner AS prd 
			ON prd.CustomerBusinessPartner_BK = stg.CustomerBusinessPartner_BK
			WHERE stg.HashDiff <> prd.HashDiff and stg.IsDeleted = 0

		 --update deletions (only deleted status and LDTS)
		 UPDATE prd SET
				 prd.LDTS				= stg.LDTS
				,prd.IsDeleted			= stg.IsDeleted
				,prd.[HashDiff]			= stg.[HashDiff]
		 	FROM #cbp AS stg JOIN biz.S4Hana_CustomerBusinessPartner AS prd 
			ON prd.CustomerBusinessPartner_BK = stg.CustomerBusinessPartner_BK
			WHERE stg.HashDiff <> prd.HashDiff and stg.IsDeleted = 1


END

--truncate table biz.S4Hana_CustomerBusinessPartner
-- exec [biz].[S4Hana_spCustomerBusinessPartner]'1900-01-01'