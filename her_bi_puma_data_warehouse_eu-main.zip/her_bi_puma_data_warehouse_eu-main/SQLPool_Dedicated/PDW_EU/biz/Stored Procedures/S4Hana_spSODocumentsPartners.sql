﻿CREATE PROC [biz].[S4Hana_spSODocumentsPartners] @ldts [DATETIME2](7) AS
BEGIN
	SET NOCOUNT ON;
	SET ANSI_WARNINGS ON;

	DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
	DECLARE @ExecStart DATETIME2(7) = GETDATE()
	DECLARE @SourceLastLoadDate DATETIME2(7)
	DECLARE @DestinationLastLoadDate DATETIME2(7)
	DECLARE @BatchLdts DATETIME2(7) = @LDTS
	DECLARE @AffectedRows BIGINT = NULL

	IF(EXISTS(SELECT 1 FROM [biz].[S4Hana_SODocumentsPartners]))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(LDTS))
	FROM [biz].[S4Hana_SODocumentsPartners]
	END
	ELSE BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

	IF(EXISTS(SELECT 1 FROM stag.[S4Hana_SODocumentsPartners]))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(_LDTS))
		FROM stag.[S4Hana_SODocumentsPartners]
	END
	ELSE BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END 


	--Log Data load
	INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'S4Hana_spSODocumentsPartners'
			,'biz_SODocuments'
			,'S4Hana_SODocumentsPartners'
			,'Stag'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts

     --truncate table etl.S4Hana_SODocumentsPartners 
	 IF NOT EXISTS ( SELECT TOP 1 1 FROM etl.S4Hana_SODocumentsPartners )
	 BEGIN
     SELECT @LDTS = '19000101';
	 END

	 --get latest batch
	 IF OBJECT_ID('tempdb..#SOP') IS NOT NULL BEGIN drop table #SOP END

     SELECT   [SalesDocument]     -- BK
			 ,[SalesDocumentItem] -- BK
			 ,[PartnerFunction]	  -- BK
			 ,PartnerNo
			 ,LDTS 
	 INTO #SOP
	 FROM  [stag].[S4Hana_fnSODocumentsPartners] (@LDTS) 

   --load new stg rows
   INSERT INTO etl.S4Hana_SODocumentsPartners

			(
			  [SalesDocument]     -- BK
			 ,[SalesDocumentItem] -- BK
			 ,[PartnerFunction]	  -- BK
			 ,PartnerNo
			 ,LDTS
			 )
	SELECT 
			  stg.[SalesDocument]     -- BK
			 ,stg.[SalesDocumentItem] -- BK
			 ,stg.[PartnerFunction]	  -- BK
			 ,stg.PartnerNo
			 ,stg.LDTS

	 FROM #SOP AS stg LEFT JOIN etl.S4Hana_SODocumentsPartners AS prd 
	 	ON prd.[SalesDocument] = stg.[SalesDocument] AND stg.SalesDocumentItem = prd.SalesDocumentItem AND stg.PartnerFunction=prd.PartnerFunction
	 WHERE prd.[SalesDocument] IS NULL OR prd.SalesDocumentItem IS NULL OR prd.PartnerFunction IS NULL

	--update existing
		  UPDATE prd SET
		  
			  prd.PartnerNo			  =	stg.PartnerNo			 
			 ,prd.LDTS				  =	stg.LDTS				 

	 FROM #SOP AS stg JOIN etl.S4Hana_SODocumentsPartners AS prd 
	 	ON prd.[SalesDocument] = stg.[SalesDocument] AND stg.SalesDocumentItem = prd.SalesDocumentItem AND stg.PartnerFunction=prd.PartnerFunction
			WHERE stg.PartnerNo <> prd.PartnerNo

	--assign max LDTS per BK
	IF OBJECT_ID('tempdb..#LDTS') IS NOT NULL BEGIN drop table #LDTS END	
	(
	SELECT etl.SalesDocument, etl.SalesDocumentItem, MAX(etl.LDTS) LDTS 
	INTO #LDTS
	FROM etl.S4Hana_SODocumentsPartners etl
	inner join #SOP temp on etl.SalesDocument=temp.SalesDocument and etl.SalesDocumentItem=temp.SalesDocumentItem
	GROUP BY etl.SalesDocument, etl.SalesDocumentItem
	)
	
	--pivot
	IF OBJECT_ID('tempdb..#PIVOT') IS NOT NULL BEGIN drop table #PIVOT END	

	select * INTO #PIVOT from (
	select  etl.SalesDocument, etl.SalesDocumentItem, etl.PartnerFunction, etl.PartnerNo, ldts.LDTS from etl.S4Hana_SODocumentsPartners etl
	inner join #SOP temp on etl.SalesDocument=temp.SalesDocument and etl.SalesDocumentItem=temp.SalesDocumentItem
	inner join #LDTS ldts on etl.SalesDocument=ldts.SalesDocument and etl.SalesDocumentItem=ldts.SalesDocumentItem
	) as src
	PIVOT ( MAX(PartnerNo)
			FOR
			PartnerFunction in (AD,AP,ZW,SP) ) pvt

    INSERT INTO biz.S4Hana_SODocumentsPartners

			(
			  [SalesDocument]     -- BK
			 ,[SalesDocumentItem] -- BK
			 ,AD                  -- SalesRep
			 ,AP				  -- ContactPerson
			 ,ZW				  -- OwnerGroup
			 ,SP				  -- ForwardingAgent
			 ,LDTS
			 )
	SELECT 
			  stg.[SalesDocument]     -- BK
			 ,stg.[SalesDocumentItem] -- BK
			 ,stg.AD
			 ,stg.AP
			 ,stg.ZW
			 ,stg.SP
			 ,stg.LDTS

	FROM #PIVOT AS stg LEFT JOIN biz.S4Hana_SODocumentsPartners AS prd 
	ON prd.[SalesDocument] = stg.[SalesDocument] AND stg.SalesDocumentItem = prd.SalesDocumentItem
	WHERE prd.[SalesDocument] IS NULL OR prd.SalesDocumentItem IS NULL

	UPDATE prd SET
		  
			  prd.AD        = stg.AD   
			 ,prd.AP        = stg.AP   
			 ,prd.ZW		= stg.ZW
			 ,prd.SP		= stg.SP
			 ,prd.LDTS		= stg.LDTS

	 FROM #PIVOT AS stg LEFT JOIN biz.S4Hana_SODocumentsPartners AS prd 
	 ON prd.[SalesDocument] = stg.[SalesDocument] AND stg.SalesDocumentItem = prd.SalesDocumentItem
	 WHERE 
	    isnull(prd.AP,'') <> isnull(stg.AP,'')
	 OR isnull(prd.ZW,'') <> isnull(stg.ZW,'')
	 OR isnull(prd.SP,'') <> isnull(stg.SP,'')
	 OR isnull(prd.AD,'') <> isnull(stg.AD,'')



END

--truncate table etl.S4Hana_SODocumentsPartners
--truncate table biz.S4Hana_SODocumentsPartners
--exec [biz].[S4Hana_spSODocumentsPartners]'1900-01-01'