﻿CREATE PROC [biz].[S4Hana_spCustomers] @ldts [DATETIME2](7) AS
BEGIN
	SET NOCOUNT ON;
	SET ANSI_WARNINGS ON;

	DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
	DECLARE @ExecStart DATETIME2(7) = GETDATE()
	DECLARE @SourceLastLoadDate DATETIME2(7)
	DECLARE @DestinationLastLoadDate DATETIME2(7)
	DECLARE @BatchLdts DATETIME2(7) = @LDTS
	DECLARE @AffectedRows BIGINT = NULL

	IF(EXISTS(SELECT 1 FROM [biz].[S4Hana_Customers]))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(LDTS))
	FROM [biz].[S4Hana_Customers]
	END
	ELSE BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

	IF(EXISTS(SELECT 1 FROM stag.[S4Hana_Customers]))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(_LDTS))
		FROM stag.[S4Hana_Customers]
	END
	ELSE BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END 


	--Log Data load
	INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'S4Hana_spCustomers'
			,'biz_Customers'
			,'S4Hana_Customers'
			,'biz'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts


	IF OBJECT_ID(N'tempdb..#customer') IS NOT NULL
	DROP TABLE #customer;

	SELECT
	   [Customer]
	  ,[CustomerName]
	  ,[CustomerFullName]
	  ,[CreatedByUser]
	  ,[CreationDate]
	  ,[AddressID]
	  ,[CustomerClassification]
	  ,[VATRegistration]
	  ,[CustomerAccountGroup]
	  ,[AuthorizationGroup]
	  ,[DeliveryIsBlocked]
	  ,[PostingIsBlocked]
	  ,[BillingIsBlockedForCustomer]
	  ,[OrderIsBlockedForCustomer]
	  ,[InternationalLocationNumber1]
	  ,[IsOneTimeAccount]
	  ,[TaxJurisdiction]
	  ,[Industry]
	  ,[TaxNumberType]
	  ,[TaxNumber1]
	  ,[TaxNumber2]
	  ,[TaxNumber3]
	  ,[TaxNumber4]
	  ,[TaxNumber5]
	  ,[CustomerCorporateGroup]
	  ,[Supplier]
	  ,[NielsenRegion]
	  ,[IndustryCode1]
	  ,[IndustryCode2]
	  ,[IndustryCode3]
	  ,[IndustryCode4]
	  ,[IndustryCode5]
	  ,[Country]
	  ,[OrganizationBPName1]
	  ,[OrganizationBPName2]
	  ,[CityName]
	  ,[PostalCode]
	  ,[StreetName]
	  ,[SortField]
	  ,[FaxNumber]
	  ,[BR_SUFRAMACode]
	  ,[Region]
	  ,[AlternativePayerAccount]
	  ,[DataMediumExchangeIndicator]
	  ,[VATLiability]
	  ,[IsBusinessPurposeCompleted]
	  ,[ResponsibleType]
	  ,[FiscalAddress]
	  ,[NFPartnerIsNaturalPerson]
	  ,[DeletionIndicator]
	  ,[Language]
	  ,[TaxInvoiceRepresentativeName]
	  ,[BusinessType]
	  ,[IndustryType]
	  ,IsDeleted  
	  ,ISNULL(ConditionGroup1,'') ConditionGroup1
	  ,ISNULL(ConditionGroup2,'') ConditionGroup2
      ,[_LDTS] as LDTS
	  ,CONVERT([BINARY](16),
				HASHBYTES('MD5',CONCAT(
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [Customer]                        )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [CustomerName] 					 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [CustomerFullName]				 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [CreatedByUser]					 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [CreationDate]					 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [AddressID]						 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [CustomerClassification]			 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [VATRegistration]				 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [CustomerAccountGroup]			 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [AuthorizationGroup]				 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DeliveryIsBlocked]				 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [PostingIsBlocked]				 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [BillingIsBlockedForCustomer]	 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [OrderIsBlockedForCustomer]		 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [InternationalLocationNumber1]	 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [IsOneTimeAccount]				 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [TaxJurisdiction]				 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [Industry]						 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [TaxNumberType]					 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [TaxNumber1]						 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [TaxNumber2]						 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [TaxNumber3]						 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [TaxNumber4]						 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [TaxNumber5]						 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [CustomerCorporateGroup]			 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [Supplier]						 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [NielsenRegion]					 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [IndustryCode1]					 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [IndustryCode2]					 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [IndustryCode3]					 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [IndustryCode4]					 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [IndustryCode5]					 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [Country]						 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [OrganizationBPName1]			 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [OrganizationBPName2]			 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [CityName]						 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [PostalCode]						 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [StreetName]						 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [SortField]						 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [FaxNumber]						 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [BR_SUFRAMACode]					 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [Region]							 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [AlternativePayerAccount]		 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DataMediumExchangeIndicator]	 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [VATLiability]					 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [IsBusinessPurposeCompleted]		 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [ResponsibleType]				 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [FiscalAddress]					 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [NFPartnerIsNaturalPerson]		 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DeletionIndicator]				 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [Language]						 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [TaxInvoiceRepresentativeName]	 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [BusinessType]					 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [IndustryType]					 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ISNULL(ConditionGroup1,'')		 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ISNULL(ConditionGroup2,'')		 )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [IsDeleted]))))))       
			) AS HashDiff
INTO #customer
FROM 
(
	SELECT
	 *
	, CAST(CASE WHEN __operation_type = 'X' 
		THEN 1 ELSE 0 END AS BIT)				AS IsDeleted
	, ROW_NUMBER() OVER (PARTITION BY Customer 
					ORDER BY _LDTS DESC
						, __timestamp DESC)		AS RN
	FROM stag.S4Hana_Customers
) X
WHERE RN = 1
and [_LDTS] > @ldts
	
		-- count new Records for S4Hana_Customers
		    SELECT @AffectedRows = COUNT(*)
			FROM #customer AS stg LEFT JOIN biz.S4Hana_Customers AS prd 
			ON prd.Customer = stg.Customer 
			WHERE prd.Customer IS NULL

   --load new
   INSERT INTO biz.S4Hana_Customers
			(
				[Customer]
	           ,[CustomerName]
	           ,[CustomerFullName]
	           ,[CreatedByUser]
	           ,[CreationDate]
	           ,[AddressID]
	           ,[CustomerClassification]
	           ,[VATRegistration]
	           ,[CustomerAccountGroup]
	           ,[AuthorizationGroup]
	           ,[DeliveryIsBlocked]
	           ,[PostingIsBlocked]
	           ,[BillingIsBlockedForCustomer]
	           ,[OrderIsBlockedForCustomer]
	           ,[InternationalLocationNumber1]
	           ,[IsOneTimeAccount]
	           ,[TaxJurisdiction]
	           ,[Industry]
	           ,[TaxNumberType]
	           ,[TaxNumber1]
	           ,[TaxNumber2]
	           ,[TaxNumber3]
	           ,[TaxNumber4]
	           ,[TaxNumber5]
	           ,[CustomerCorporateGroup]
	           ,[Supplier]
	           ,[NielsenRegion]
	           ,[IndustryCode1]
	           ,[IndustryCode2]
	           ,[IndustryCode3]
	           ,[IndustryCode4]
	           ,[IndustryCode5]
	           ,[Country]
	           ,[OrganizationBPName1]
	           ,[OrganizationBPName2]
	           ,[CityName]
	           ,[PostalCode]
	           ,[StreetName]
	           ,[SortField]
	           ,[FaxNumber]
	           ,[BR_SUFRAMACode]
	           ,[Region]
	           ,[AlternativePayerAccount]
	           ,[DataMediumExchangeIndicator]
	           ,[VATLiability]
	           ,[IsBusinessPurposeCompleted]
	           ,[ResponsibleType]
	           ,[FiscalAddress]
	           ,[NFPartnerIsNaturalPerson]
	           ,[DeletionIndicator]
	           ,[Language]
	           ,[TaxInvoiceRepresentativeName]
	           ,[BusinessType]
	           ,[IndustryType]
			   ,ConditionGroup1
			   ,ConditionGroup2
	           ,IsDeleted       
               ,LDTS
			   ,[HashDiff]			
			)
	SELECT 
				stg.[Customer]
	           ,stg.[CustomerName]
	           ,stg.[CustomerFullName]
	           ,stg.[CreatedByUser]
	           ,stg.[CreationDate]
	           ,stg.[AddressID]
	           ,stg.[CustomerClassification]
	           ,stg.[VATRegistration]
	           ,stg.[CustomerAccountGroup]
	           ,stg.[AuthorizationGroup]
	           ,stg.[DeliveryIsBlocked]
	           ,stg.[PostingIsBlocked]
	           ,stg.[BillingIsBlockedForCustomer]
	           ,stg.[OrderIsBlockedForCustomer]
	           ,stg.[InternationalLocationNumber1]
	           ,stg.[IsOneTimeAccount]
	           ,stg.[TaxJurisdiction]
	           ,stg.[Industry]
	           ,stg.[TaxNumberType]
	           ,stg.[TaxNumber1]
	           ,stg.[TaxNumber2]
	           ,stg.[TaxNumber3]
	           ,stg.[TaxNumber4]
	           ,stg.[TaxNumber5]
	           ,stg.[CustomerCorporateGroup]
	           ,stg.[Supplier]
	           ,stg.[NielsenRegion]
	           ,stg.[IndustryCode1]
	           ,stg.[IndustryCode2]
	           ,stg.[IndustryCode3]
	           ,stg.[IndustryCode4]
	           ,stg.[IndustryCode5]
	           ,stg.[Country]
	           ,stg.[OrganizationBPName1]
	           ,stg.[OrganizationBPName2]
	           ,stg.[CityName]
	           ,stg.[PostalCode]
	           ,stg.[StreetName]
	           ,stg.[SortField]
	           ,stg.[FaxNumber]
	           ,stg.[BR_SUFRAMACode]
	           ,stg.[Region]
	           ,stg.[AlternativePayerAccount]
	           ,stg.[DataMediumExchangeIndicator]
	           ,stg.[VATLiability]
	           ,stg.[IsBusinessPurposeCompleted]
	           ,stg.[ResponsibleType]
	           ,stg.[FiscalAddress]
	           ,stg.[NFPartnerIsNaturalPerson]
	           ,stg.[DeletionIndicator]
	           ,stg.[Language]
	           ,stg.[TaxInvoiceRepresentativeName]
	           ,stg.[BusinessType]
	           ,stg.[IndustryType]
			   ,stg.ConditionGroup1
			   ,stg.ConditionGroup2
	           ,stg.IsDeleted       
               ,stg.LDTS
			   ,stg.[HashDiff]				


		 FROM #customer AS stg LEFT JOIN biz.S4Hana_Customers AS prd 
		 ON prd.Customer = stg.Customer 
		 WHERE prd.Customer IS NULL
	
		UPDATE DTlogs
		SET Inserted = @AffectedRows
		FROM etl.DataTransferLogs DTlogs
		WHERE DataTransferLogId = @DataTransferLogId


		-- count new Records for S4Hana_Customers
		SELECT @AffectedRows = COUNT(*)
		FROM #customer AS stg JOIN biz.S4Hana_Customers AS prd 
		ON prd.Customer = stg.Customer
		WHERE stg.HashDiff <> prd.HashDiff

		UPDATE DTlogs
		SET Updated = @AffectedRows
		, ExecEnd = GETDATE()
		FROM etl.DataTransferLogs DTlogs
		WHERE DataTransferLogId = @DataTransferLogId

		--update non deleted records
		  UPDATE prd SET	
				prd.[Customer]                       = stg.[Customer]                    
	           ,prd.[CustomerName]					 = stg.[CustomerName]
	           ,prd.[CustomerFullName]				 = stg.[CustomerFullName]
	           ,prd.[CreatedByUser]					 = stg.[CreatedByUser]
	           ,prd.[CreationDate]					 = stg.[CreationDate]
	           ,prd.[AddressID]						 = stg.[AddressID]
	           ,prd.[CustomerClassification]		 = stg.[CustomerClassification]
	           ,prd.[VATRegistration]				 = stg.[VATRegistration]
	           ,prd.[CustomerAccountGroup]			 = stg.[CustomerAccountGroup]
	           ,prd.[AuthorizationGroup]			 = stg.[AuthorizationGroup]
	           ,prd.[DeliveryIsBlocked]				 = stg.[DeliveryIsBlocked]
	           ,prd.[PostingIsBlocked]				 = stg.[PostingIsBlocked]
	           ,prd.[BillingIsBlockedForCustomer]	 = stg.[BillingIsBlockedForCustomer]
	           ,prd.[OrderIsBlockedForCustomer]		 = stg.[OrderIsBlockedForCustomer]
	           ,prd.[InternationalLocationNumber1]	 = stg.[InternationalLocationNumber1]
	           ,prd.[IsOneTimeAccount]				 = stg.[IsOneTimeAccount]
	           ,prd.[TaxJurisdiction]				 = stg.[TaxJurisdiction]
	           ,prd.[Industry]						 = stg.[Industry]
	           ,prd.[TaxNumberType]					 = stg.[TaxNumberType]
	           ,prd.[TaxNumber1]					 = stg.[TaxNumber1]
	           ,prd.[TaxNumber2]					 = stg.[TaxNumber2]
	           ,prd.[TaxNumber3]					 = stg.[TaxNumber3]
	           ,prd.[TaxNumber4]					 = stg.[TaxNumber4]
	           ,prd.[TaxNumber5]					 = stg.[TaxNumber5]
	           ,prd.[CustomerCorporateGroup]		 = stg.[CustomerCorporateGroup]
	           ,prd.[Supplier]						 = stg.[Supplier]
	           ,prd.[NielsenRegion]					 = stg.[NielsenRegion]
	           ,prd.[IndustryCode1]					 = stg.[IndustryCode1]
	           ,prd.[IndustryCode2]					 = stg.[IndustryCode2]
	           ,prd.[IndustryCode3]					 = stg.[IndustryCode3]
	           ,prd.[IndustryCode4]					 = stg.[IndustryCode4]
	           ,prd.[IndustryCode5]					 = stg.[IndustryCode5]
	           ,prd.[Country]						 = stg.[Country]
	           ,prd.[OrganizationBPName1]			 = stg.[OrganizationBPName1]
	           ,prd.[OrganizationBPName2]			 = stg.[OrganizationBPName2]
	           ,prd.[CityName]						 = stg.[CityName]
	           ,prd.[PostalCode]					 = stg.[PostalCode]
	           ,prd.[StreetName]					 = stg.[StreetName]
	           ,prd.[SortField]						 = stg.[SortField]
	           ,prd.[FaxNumber]						 = stg.[FaxNumber]
	           ,prd.[BR_SUFRAMACode]				 = stg.[BR_SUFRAMACode]
	           ,prd.[Region]						 = stg.[Region]
	           ,prd.[AlternativePayerAccount]		 = stg.[AlternativePayerAccount]
	           ,prd.[DataMediumExchangeIndicator]	 = stg.[DataMediumExchangeIndicator]
	           ,prd.[VATLiability]					 = stg.[VATLiability]
	           ,prd.[IsBusinessPurposeCompleted]	 = stg.[IsBusinessPurposeCompleted]
	           ,prd.[ResponsibleType]				 = stg.[ResponsibleType]
	           ,prd.[FiscalAddress]					 = stg.[FiscalAddress]
	           ,prd.[NFPartnerIsNaturalPerson]		 = stg.[NFPartnerIsNaturalPerson]
	           ,prd.[DeletionIndicator]				 = stg.[DeletionIndicator]
	           ,prd.[Language]						 = stg.[Language]
	           ,prd.[TaxInvoiceRepresentativeName]	 = stg.[TaxInvoiceRepresentativeName]
	           ,prd.[BusinessType]					 = stg.[BusinessType]
	           ,prd.[IndustryType]					 = stg.[IndustryType]
			   ,prd.ConditionGroup1					= stg.ConditionGroup1
			   ,prd.ConditionGroup2					= stg.ConditionGroup2
	           ,prd.IsDeleted       				 = stg.IsDeleted       
               ,prd.LDTS							 = stg.LDTS
			   ,prd.[HashDiff]						 = stg.[HashDiff]		


			FROM #customer AS stg JOIN biz.S4Hana_Customers AS prd 
			ON prd.Customer = stg.Customer
			WHERE stg.HashDiff <> prd.HashDiff and stg.IsDeleted = 0

		 --update deletions (only deleted status and LDTS)
		 UPDATE prd SET
				 prd.LDTS				= stg.LDTS
				,prd.IsDeleted			= stg.IsDeleted
				,prd.[HashDiff]						 = stg.[HashDiff]
		 	FROM #customer AS stg JOIN biz.S4Hana_Customers AS prd 
			ON prd.Customer = stg.Customer
			WHERE stg.HashDiff <> prd.HashDiff and stg.IsDeleted = 1


END

--truncate table from biz.S4Hana_Customers
-- exec [biz].[S4Hana_spCustomers]'1900-01-01'
