﻿CREATE PROC [biz].[S4hana_spCOPAPrep] @LDTS [DATETIME2] AS
  BEGIN
      SET nocount ON;
      SET ansi_warnings ON;


      DECLARE @DataTransferLogId UNIQUEIDENTIFIER = Newid();
      DECLARE @ExecStart DATETIME2(7) = Getdate();
      DECLARE @SourceLastLoadDate DATETIME2(7) = Getdate();
      DECLARE @DestinationLastLoadDate DATETIME2(7);
      DECLARE @BatchLdts DATETIME2(7) = @LDTS;
      DECLARE @AffectedRows BIGINT = NULL;

      IF ( EXISTS (SELECT 1
                   FROM   biz.S4hana_COPA_Prep) )
        BEGIN
            SELECT @DestinationLastLoadDate = CONVERT(DATETIME, Max(ldts))
            FROM   biz.s4hana_copa_prep;
        END
      ELSE
        BEGIN
            SELECT @DestinationLastLoadDate = '1990-01-01'; -- for initial load
        END

      INSERT INTO etl.datatransferlogs
                  (datatransferlogid,
                   transfername,
                   transfergroupname,
                   targettablename,
                   targetschemaname,
                   execstart,
                   sourcelastloaddate,
                   destinationlastloaddate,
                   batchldts)
      SELECT @DataTransferLogId,
             'S4Hana_spCOPAPrep',
             'biz_S4Hana_COPA_Prep',
             'S4Hana_COPA_Prep',
             'biz',
             @ExecStart,
             @SourceLastLoadDate,
             @DestinationLastLoadDate,
             @BatchLdts;

    IF OBJECT_ID(N'tempdstg..#COPA') IS NOT NULL
    	DROP TABLE #COPA;

      SELECT co.natsalesorderno,
             co.natsalesorderitemno,
             co.ldts,
             Sum(Cast(co.quantity AS DECIMAL(24, 12))) * ( -1 ) AS quantity
      INTO #COPA
      FROM   stag.s4hana_vcopasemantictags tg
             JOIN stag.S4hana_fncoparaw(@LDTS) co
               ON tg.glaccount = co.glaccount
                  AND tg.chartofaccounts = co.chartofaccounts
             JOIN pdwref.s4hana_copa_billtypebusclass ref
               ON ref.billingdoctypecode = co.billingdoctypecode
             JOIN pdwref.s4hana_copa_activesemantictags atg
               ON atg.semantictag = tg.semantictag
                  AND atg.isactive = 1
      WHERE  tg.semantictag IN ( 'ZR3041NSTP', 'ZR3042NSIC', 'ZR3044NSIF' ) and co.ReferenceDocumentType = 'VBRK'
      GROUP  BY co.natsalesorderno,
                co.natsalesorderitemno,
                co.ldts;
    
    --Count new records
	SELECT @AffectedRows = COUNT(*)
    FROM biz.#COPA stg
    LEFT JOIN biz.S4hana_COPA_Prep prd ON prd.NatSalesOrderNo=stg.NatSalesOrderNo AND prd.NatSalesOrderItemNo=stg.NatSalesOrderItemNo AND prd.LDTS=stg.LDTS
    WHERE prd.NatSalesOrderNo IS NULL AND prd.NatSalesOrderItemNo IS NULL AND prd.LDTS IS NULL

    --insert new rows
    INSERT INTO biz.S4hana_COPA_Prep
    (NatSalesOrderNo	 -- BK
    ,NatSalesOrderItemNo -- BK
    ,LDTS	             -- BK
    ,Quantity)
    SELECT 
     stg.NatSalesOrderNo	
    ,stg.NatSalesOrderItemNo	
    ,stg.LDTS	
    ,stg.Quantity
    FROM biz.#COPA stg
    LEFT JOIN biz.S4hana_COPA_Prep prd ON prd.NatSalesOrderNo=stg.NatSalesOrderNo AND prd.NatSalesOrderItemNo=stg.NatSalesOrderItemNo AND prd.LDTS=stg.LDTS
    WHERE prd.NatSalesOrderNo IS NULL AND prd.NatSalesOrderItemNo IS NULL AND prd.LDTS IS NULL

    UPDATE DTlogs
    SET Inserted = @AffectedRows
    FROM etl.DataTransferLogs DTlogs
    WHERE DataTransferLogId = @DataTransferLogId

    --count updates 
    SELECT @AffectedRows = COUNT(*)
    FROM biz.#COPA stg
    INNER JOIN biz.S4hana_COPA_Prep prd ON prd.NatSalesOrderNo=stg.NatSalesOrderNo AND prd.NatSalesOrderItemNo=stg.NatSalesOrderItemNo AND prd.LDTS=stg.LDTS
    WHERE prd.Quantity <> stg.Quantity

    --update part
    UPDATE prd
    SET prd.Quantity = stg.Quantity
    FROM biz.#COPA stg
    INNER JOIN biz.S4hana_COPA_Prep prd ON prd.NatSalesOrderNo=stg.NatSalesOrderNo AND prd.NatSalesOrderItemNo=stg.NatSalesOrderItemNo AND prd.LDTS=stg.LDTS
    WHERE prd.Quantity <> stg.Quantity

    UPDATE DTlogs
    SET Updated = @AffectedRows
    , ExecEnd = GETDATE()
    FROM etl.DataTransferLogs DTlogs
    WHERE DataTransferLogId = @DataTransferLogId


   --exec [biz].[S4hana_spCOPAPrep] '1900-01-01'

  END