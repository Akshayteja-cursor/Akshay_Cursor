﻿CREATE PROC [biz].[S4Hana_spSoDocItemPriceConditionsHistory] @LDTS [DATETIME2](7) AS
BEGIN
SET NOCOUNT ON
--DECLARE @LDTS DATETIME2(7) = '2000-01-01'
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(7) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(7)
DECLARE @DestinationLastLoadDate DATETIME2(7)
DECLARE @BatchLdts DATETIME2(7) = @LDTS

-- do not use the input parameter, in case of an failur or reload situartion take the last tranfered LDTS from the Hist table
IF(EXISTS(SELECT 1 FROM biz.S4Hana_SoDocItemPriceConditionsHistory))
BEGIN
	SELECT @DestinationLastLoadDate = MAX(LDTS)
	FROM biz.S4Hana_SoDocItemPriceConditionsHistory
END
ELSE BEGIN
	SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
END 

IF(EXISTS(SELECT 1 FROM stag.S4Hana_SOPricingConditions_Full))
BEGIN
	SELECT @SourceLastLoadDate = MAX(_LDTS)
	FROM stag.S4Hana_SOPricingConditions_Full
END
ELSE BEGIN
	SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
END 

--Log Data load
INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'spSoDocumentItemPriceConditionsHistory'
			,'prepSoDocHist'
			,'NatSalesOrdersOohHistory'
			,'sales'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts

-- Add new SO / SOItems
TRUNCATE Table etl.S4Hana_SoDocItemPriceConditionsHistory_T1_DistSoItems  -- temp peristing table 
INSERT INTO etl.S4Hana_SoDocItemPriceConditionsHistory_T1_DistSoItems
 (NatSalesOrderNo
 ,NatSalesOrderItemNo
 ,LDTS)
 SELECT 
     sodi.SalesDocument AS NatSalesOrderNo
    ,sodi.SalesDocumentItem AS NatSalesOrderItemNo
    ,sopStagFull._LDTS AS LDTS
FROM stag.S4Hana_SOPricingConditions_Full  AS sopStagFull
INNER JOIN [stag].[S4Hana_fnSODocumentItems] ('19000101') as sodi
ON sopStagFull.PricingDocument = sodi.SalesDocumentCondition and sopStagFull.PricingDocumentItem = sodi.SalesDocumentItem
WHERE 1=1
	AND sopStagFull._LDTS > @DestinationLastLoadDate 
	AND sopStagFull.__operation_type <> 'X' 
    AND ConditionInactiveReason = ''  -- take only not delted onec (real delated and deactivated)
UNION
SELECT --> add Deletion 
     NatSalesOrderNo
    ,NatSalesOrderItemNo
    ,LDTS
FROM biz.S4Hana_SoDocItemPriceConditionDeletions 
WHERE 1=1
	AND LDTS > @DestinationLastLoadDate 
	AND LEDTS = '9999-12-31'
Option (LABEL='biz.S4Hana_SoDocItemPriceConditionsHistory : etl.S4Hana_SoDocItemPriceConditionsHistory_T1_DistSoItems')

IF OBJECT_ID('tempdb..#SoPriceConditionsDistSoItemLastBatchWithOutLDTS') IS NOT NULL
BEGIN
    DROP TABLE #SoPriceConditionsDistSoItemLastBatchWithOutLDTS
END

CREATE TABLE #SoPriceConditionsDistSoItemLastBatchWithOutLDTS --> get all entires from the past to this SO / SOItem
WITH
(DISTRIBUTION = HASH(NatSalesOrderNo)
,HEAP)
AS(SELECT DISTINCT
		 NatSalesOrderNo
		,NatSalesOrderItemNo
	FROM etl.S4Hana_SoDocItemPriceConditionsHistory_T1_DistSoItems 
)

TRUNCATE TABLE  etl.S4Hana_SoDocItemPriceConditionsHistory_T2_GetNormalizeConAmount; -- temp peristing table 

WITH CombineFullDeletion AS (
SELECT 
     sodi.SalesDocument AS NatSalesOrderNo
    ,sodi.SalesDocumentItem AS NatSalesOrderItemNo
	,sopStagFull.PricingDocument AS PricingDocument
	,sopStagFull.PricingDocumentItem AS PricingDocumentItem
    ,sopStagFull.PricingProcedureStep AS PricingProcedureStep
    ,sopStagFull.PricingProcedureCounter AS PricingProcedureCounter
    ,sopStagFull.ConditionType AS ConditionTypeCode 
    ,sopStagFull._LDTS AS LDTS
	,sopStagFull.__timestamp AS __timestamp
    ,CONVERT(DECIMAL(38,25), --<-- Final Datatype interal highest precision 
	          CONVERT(DECIMAL(15,2),sopStagFull.ConditionAmount) --<-- KWERT Convert to SAP Datatype from Metafile 
			 / -- Divide 
			 --CASE WHEN sopStagFull.ConditionQuantity = 0 THEN 1 ELSE CONVERT(NUMERIC(15,3),sopStagFull.ConditionQuantity) END ) -- <-- Convert to SAP Datatype and ensure no 0 DIV
			 CASE WHEN sodi.OrderQuantity = 0 THEN 1 ELSE CONVERT(NUMERIC(15,3),sodi.OrderQuantity) END )
	 AS ConditionAmount    
FROM stag.S4Hana_SOPricingConditions_Full AS sopStagFull
INNER JOIN [stag].[S4Hana_fnSODocumentItems] ('19000101') as sodi
	ON sopStagFull.PricingDocument = sodi.SalesDocumentCondition and sopStagFull.PricingDocumentItem = sodi.SalesDocumentItem
INNER JOIN #SoPriceConditionsDistSoItemLastBatchWithOutLDTS AS soSoItem  -- Filter just enties from this batch (LDTS)
	ON sodi.SalesDocument  = soSoItem.NatSalesOrderNo 
    AND sodi.SalesDocumentItem  = soSoItem.NatSalesOrderItemNo
WHERE 1=1
AND sopStagFull.ConditionInactiveReason = '' -- need to be filtered out because have a valid SalesDocument & SalesDocumentItem in case of ConditionInactiveReason is already provided from deletion
AND sopStagFull.ConditionType IN ('DIFF','GRWR','MWST','PNTP','VPRS','ZACC','ZAFG','ZART','ZB2B','ZBOL','ZCC1','ZCCE',
			'ZCIT','ZCO1','ZCWD','ZDIS','ZDNP','ZDVG','ZEQU','ZFMW','ZFOC','ZGS1','ZICV','ZIDU','ZIF%','ZIFV','ZIHF',
			'ZIIN','ZINM','ZINV','ZIUP','ZLOG','ZLSM','ZMD0','ZMOV','ZNEP','ZOFF','ZOPX','ZORD','ZOUT','ZPAR','ZPAY',
			'ZPR0','ZPRF','ZRAC','ZRAS','ZRDI','ZRMP','ZRY1','ZRY2','ZSF1','ZSFP','ZSPR','ZSRD','ZSSC','ZSSM', 'ZST1',
			'ZSTS','ZSWC','ZVP1','ZVPR','ZXDU','ZXF%','ZXFP','ZXFV','ZXHF','ZXIN','ZXRD','ZXSC','ZXSM','ZXWC','ZZCR',
			'ZZD1','ZZDR','ZZP1','ZZSR','ZERR','ZDIF','ZECR','ZXCF','ZECN','ZNRR','ZBGD','ZBUY','ZCOC','ZDIR','ZEBD',
			'ZESC','ZEXL','ZFRH','ZICF','ZRY3','ZSIS','ZVAS','ZCOB','ZNTS','ZRRP','ZDSB','ZDSD','ZDSN','ZBD1','ZBD2',
			'ZBD3','ZBD4','ZBD5','ZBD6','ZBD7','ZCOS','ZDP2','ZDCL','ZCOI','ZCDI','ZARC','ZOFP','ZDAC','ZOFV','ZOF%',
			'ZOIC','ZOVA','ZSIM','ZFAS','ZFAG','ZCLP','ZEDC','ZSW1','ZSKT','ZNPA','ZDPA','ZCBD')

			
UNION ALL
SELECT soPrDel.NatSalesOrderNo
      ,soPrDel.NatSalesOrderItemNo
	  ,soPrDel.PricingDocument
      ,soPrDel.PricingDocumentItem
      ,soPrDel.PricingProcedureStep
      ,soPrDel.PricingProcedureCounter
	  ,soPrDel.ConditionTypeCode
      ,soPrDel.LDTS
      ,soPrDel.__timestamp
	  ,NULL AS ConditionAmount    --> Deletion entry
  FROM biz.S4Hana_SoDocItemPriceConditionDeletions AS soPrDel
  INNER JOIN #SoPriceConditionsDistSoItemLastBatchWithOutLDTS AS soSoItem  -- Filter just enties from this batch (LDTS)
	ON soPrDel.NatSalesOrderNo  = soSoItem.NatSalesOrderNo 
    AND soPrDel.NatSalesOrderItemNo  = soSoItem.NatSalesOrderItemNo
)
INSERT INTO etl.S4Hana_SoDocItemPriceConditionsHistory_T2_GetNormalizeConAmount -- temp peristing table 
( 	 NatSalesOrderNo
    ,NatSalesOrderItemNo
	,PricingDocument
	,PricingDocumentItem
    ,PricingProcedureStep
    ,PricingProcedureCounter
    ,ConditionTypeCode
    ,LDTS
    ,ConditionAmount
    ,rn_PerLdts)
SELECT NatSalesOrderNo
    ,NatSalesOrderItemNo
	,PricingDocument
	,PricingDocumentItem
    ,PricingProcedureStep
    ,PricingProcedureCounter
    ,ConditionTypeCode
    ,LDTS
    ,ConditionAmount
    ,ROW_NUMBER() OVER (PARTITION BY NatSalesOrderNo, PricingDocument, PricingDocumentItem, PricingProcedureStep, PricingProcedureCounter, LDTS ORDER BY __timestamp DESC) AS rn_PerLdts
FROM CombineFullDeletion
Option (LABEL='biz.S4Hana_SoDocItemPriceConditionsHistory : etl.S4Hana_SoDocItemPriceConditionsHistory_T2_GetNormalizeConAmount')	

-- Additional etl table to avoid ram issues 
Truncate table etl.S4Hana_SoDocItemPriceConditionsHistory_T21_FilterNormalizeConAmount
INSERT INTO etl.S4Hana_SoDocItemPriceConditionsHistory_T21_FilterNormalizeConAmount
      (NatSalesOrderNo
      ,NatSalesOrderItemNo
      ,PricingDocument
      ,PricingDocumentItem
      ,PricingProcedureStep
      ,PricingProcedureCounter
      ,ConditionTypeCode
      ,PreviewsLDTS
      ,LDTS
      ,ConditionAmount
      ,rn)
SELECT sopNorm.NatSalesOrderNo
      ,sopNorm.NatSalesOrderItemNo
      ,sopNorm.PricingDocument
      ,sopNorm.PricingDocumentItem
      ,sopNorm.PricingProcedureStep
      ,sopNorm.PricingProcedureCounter
      ,sopNorm.ConditionTypeCode
      ,sopNorm.LDTS AS PreviewsLDTS
      ,distSoPrLdts.LDTS -- artificial entrie for the last value for this LDTS
      ,sopNorm.ConditionAmount
      ,ROW_NUMBER() OVER (PARTITION BY sopNorm.NatSalesOrderNo, sopNorm.PricingDocument, sopNorm.PricingDocumentItem, sopNorm.PricingProcedureStep, sopNorm.PricingProcedureCounter, distSoPrLdts.LDTS ORDER BY sopNorm.LDTS DESC) AS rn
FROM etl.S4Hana_SoDocItemPriceConditionsHistory_T1_DistSoItems AS distSoPrLdts
INNER JOIN etl.S4Hana_SoDocItemPriceConditionsHistory_T2_GetNormalizeConAmount AS sopNorm 
    ON distSoPrLdts.NatSalesOrderNo = sopNorm.NatSalesOrderNo
    AND distSoPrLdts.NatSalesOrderItemNo = sopNorm.NatSalesOrderItemNo
    AND distSoPrLdts.LDTS >= sopNorm.LDTS 
WHERE sopNorm.rn_PerLdts = 1 -- only the last entry per Batch
Option (LABEL='biz.S4Hana_SoDocItemPriceConditionsHistory : etl.S4Hana_SoDocItemPriceConditionsHistory_T21_FilterNormalizeConAmount')

Truncate table etl.S4Hana_SoDocItemPriceConditionsHistory_T3_ExtendLdtsPreValues
INSERT INTO etl.S4Hana_SoDocItemPriceConditionsHistory_T3_ExtendLdtsPreValues
       (NatSalesOrderNo
       ,NatSalesOrderItemNo
       ,PricingDocument
       ,PricingDocumentItem
       ,PricingProcedureStep
       ,PricingProcedureCounter
       ,ConditionTypeCode
       ,PreviewsLDTS
       ,LDTS
       ,ConditionAmount
       ,rn)
SELECT 
        NatSalesOrderNo
       ,NatSalesOrderItemNo
       ,PricingDocument
       ,PricingDocumentItem
       ,PricingProcedureStep
       ,PricingProcedureCounter
       ,ConditionTypeCode
       ,PreviewsLDTS
       ,LDTS
       ,ConditionAmount
       ,rn
FROM etl.S4Hana_SoDocItemPriceConditionsHistory_T21_FilterNormalizeConAmount 
WHERE rn = 1 -- leave just pre values per new artificial LDTS  
Option (LABEL='biz.S4Hana_SoDocItemPriceConditionsHistory : etl.S4Hana_SoDocItemPriceConditionsHistory_T3_ExtendLdtsPreValues 1')

TRUNCATE TABLE etl.S4Hana_SoDocItemPriceConditionsHistory_T4_Pivot
INSERT INTO etl.S4Hana_SoDocItemPriceConditionsHistory_T4_Pivot
      (NatSalesOrderNo
      ,NatSalesOrderItemNo
      ,LDTS
	  ,HashDiff
      ,DIFF ,GRWR ,MWST ,PNTP ,VPRS ,ZACC ,ZAFG ,ZART ,ZB2B ,ZBOL ,ZCC1 ,ZCCE ,ZCIT ,ZCO1 ,ZCWD ,ZDIS ,ZDNP ,ZDVG ,ZEQU ,ZFMW ,ZFOC ,ZGS1 ,ZICV ,ZIDU ,[ZIF%] ,ZIFV ,ZIHF 
      ,ZIIN ,ZINM ,ZINV ,ZIUP ,ZLOG ,ZLSM ,ZMD0 ,ZMOV ,ZNEP ,ZOFF ,ZOPX ,ZORD ,ZOUT ,ZPAR ,ZPAY ,ZPR0 ,ZPRF ,ZRAC ,ZRAS ,ZRDI ,ZRMP ,ZRY1 ,ZRY2 ,ZSF1 ,ZSFP ,ZSPR ,ZSRD 
      ,ZSSC ,ZSSM, ZST1 ,ZSTS ,ZSWC ,ZVP1 ,ZVPR ,ZXDU ,[ZXF%] ,ZXFP ,ZXFV ,ZXHF ,ZXIN ,ZXRD ,ZXSC ,ZXSM ,ZXWC ,ZZCR ,ZZD1 ,ZZDR ,ZZP1 ,ZZSR ,ZERR ,ZDIF ,ZECR ,ZXCF ,ZECN 
      ,ZNRR ,ZBGD ,ZBUY ,ZCOC ,ZDIR ,ZEBD ,ZESC ,ZEXL ,ZFRH ,ZICF ,ZRY3 ,ZSIS ,ZVAS ,ZCOB ,ZNTS ,ZRRP ,ZDSB ,ZDSD ,ZDSN ,ZBD1 ,ZBD2 ,ZBD3 ,ZBD4 ,ZBD5 ,ZBD6 ,ZBD7 ,ZCOS 
	  ,ZDP2, ZDCL, ZCOI, ZCDI, ZARC, ZOFP, ZDAC, ZOFV, [ZOF%], ZOIC, ZOVA, ZSIM, ZFAS, ZFAG, ZCLP, ZEDC, ZSW1, ZSKT, ZNPA, ZDPA, ZCBD
      ,SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist
	   )
SELECT NatSalesOrderNo
    ,NatSalesOrderItemNo
    ,LDTS
    ,CONVERT(BINARY(16), 
        HASHBYTES('MD5',CONCAT( 
        UPPER(LTRIM(RTRIM(NatSalesOrderNo)) + '_'), 
        UPPER(LTRIM(RTRIM(NatSalesOrderItemNo)) + '_'), 
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),DIFF ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),GRWR ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),MWST ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),PNTP ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),VPRS ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZACC ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZAFG ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZART ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZB2B ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZBOL ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZCC1 ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZCCE ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZCIT ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZCO1 ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZCWD ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZDIS ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZDNP ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZDVG ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZEQU ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZFMW ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZFOC ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZGS1 ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZICV ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZIDU ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),[ZIF%] )))+ '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZIFV ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZIHF ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZIIN ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZINM ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZINV ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZIUP ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZLOG ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZLSM ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZMD0 ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZMOV ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZNEP ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZOFF ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZOPX ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZORD ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZOUT ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZPAR ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZPAY ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZPR0 ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZPRF ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZRAC ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZRAS ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZRDI ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZRMP ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZRY1 ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZRY2 ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZSF1 ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZSFP ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZSPR ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZSRD ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZSSC ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZSSM ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZST1 ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZSTS ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZSWC ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZVP1 ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZVPR ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZXDU ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),[ZXF%] ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZXFP ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZXFV ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZXHF ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZXIN ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZXRD ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZXSC ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZXSM ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZXWC ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZZCR ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZZD1 ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZZDR ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZZP1 ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZZSR ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZERR ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZDIF ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZECR ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZXCF ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZECN ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZNRR ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZBGD ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZBUY ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZCOC ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZDIR ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZEBD ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZESC ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZEXL ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZFRH ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZICF ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZRY3 ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZSIS ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZVAS ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZCOB ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZNTS ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZRRP ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZDSB ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZDSD ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZDSN ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZBD1 ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZBD2 ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZBD3 ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZBD4 ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZBD5 ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZBD6 ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZBD7 ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZCOS ))) + '_'),
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZDP2 ))) + '_'),
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZDCL ))) + '_'),
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZCOI ))) + '_'),
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZCDI ))) + '_'),
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZARC ))) + '_'),
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZOFP ))) + '_'),
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZDAC ))) + '_'),
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZOFV ))) + '_'),
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),[ZOF%] ))) + '_'),
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZOIC ))) + '_'),
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZOVA ))) + '_'),
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZSIM ))) + '_'),
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZFAS ))) + '_'),
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZFAG ))) + '_'),
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZCLP ))) + '_'),
        UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZEDC ))) + '_'),
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZSW1 ))) + '_'),
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZCBD ))) + '_'),
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZDPA ))) + '_'),
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZNPA ))) + '_'),
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ZSKT ))))		
      ))) AS HashDiff
	,DIFF ,GRWR ,MWST ,PNTP ,VPRS ,ZACC ,ZAFG ,ZART ,ZB2B ,ZBOL ,ZCC1 ,ZCCE ,ZCIT ,ZCO1 ,ZCWD ,ZDIS ,ZDNP ,ZDVG ,ZEQU ,ZFMW ,ZFOC ,ZGS1 ,ZICV ,ZIDU ,[ZIF%] ,ZIFV ,ZIHF 
    ,ZIIN ,ZINM ,ZINV ,ZIUP ,ZLOG ,ZLSM ,ZMD0 ,ZMOV ,ZNEP ,ZOFF ,ZOPX ,ZORD ,ZOUT ,ZPAR ,ZPAY ,ZPR0 ,ZPRF ,ZRAC ,ZRAS ,ZRDI ,ZRMP ,ZRY1 ,ZRY2 ,ZSF1 ,ZSFP ,ZSPR ,ZSRD 
    ,ZSSC ,ZSSM, ZST1 ,ZSTS ,ZSWC ,ZVP1 ,ZVPR ,ZXDU ,[ZXF%] ,ZXFP ,ZXFV ,ZXHF ,ZXIN ,ZXRD ,ZXSC ,ZXSM ,ZXWC ,ZZCR ,ZZD1 ,ZZDR ,ZZP1 ,ZZSR ,ZERR ,ZDIF ,ZECR ,ZXCF ,ZECN 
    ,ZNRR ,ZBGD ,ZBUY ,ZCOC ,ZDIR ,ZEBD ,ZESC ,ZEXL ,ZFRH ,ZICF ,ZRY3 ,ZSIS ,ZVAS ,ZCOB ,ZNTS ,ZRRP ,ZDSB ,ZDSD ,ZDSN ,ZBD1 ,ZBD2 ,ZBD3 ,ZBD4 ,ZBD5 ,ZBD6 ,ZBD7 ,ZCOS, ZDP2, ZDCL, ZCOI, ZCDI, ZARC
	,ZOFP, ZDAC, ZOFV, [ZOF%], ZOIC, ZOVA, ZSIM, ZFAS, ZFAG, ZCLP, ZEDC, ZSW1, ZSKT, ZNPA, ZDPA, ZCBD
	,CONVERT(TINYINT,1) AS SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist 
 FROM (
    SELECT PriCon.NatSalesOrderNo
          ,PriCon.NatSalesOrderItemNo
          ,PriCon.ConditionTypeCode
          ,PriCon.LDTS
          ,PriCon.ConditionAmount
        FROM etl.S4Hana_SoDocItemPriceConditionsHistory_T3_ExtendLdtsPreValues AS PriCon
        ) AS src 
    PIVOT(    
    SUM(ConditionAmount) 
    FOR ConditionTypeCode IN (
     DIFF ,GRWR ,MWST ,PNTP ,VPRS ,ZACC ,ZAFG ,ZART ,ZB2B ,ZBOL ,ZCC1 ,ZCCE ,ZCIT ,ZCO1 ,ZCWD ,ZDIS ,ZDNP ,ZDVG ,ZEQU ,ZFMW ,ZFOC ,ZGS1 ,ZICV ,ZIDU ,[ZIF%] ,ZIFV ,ZIHF 
    ,ZIIN ,ZINM ,ZINV ,ZIUP ,ZLOG ,ZLSM ,ZMD0 ,ZMOV ,ZNEP ,ZOFF ,ZOPX ,ZORD ,ZOUT ,ZPAR ,ZPAY ,ZPR0 ,ZPRF ,ZRAC ,ZRAS ,ZRDI ,ZRMP ,ZRY1 ,ZRY2 ,ZSF1 ,ZSFP ,ZSPR ,ZSRD 
    ,ZSSC ,ZSSM, ZST1 ,ZSTS ,ZSWC ,ZVP1 ,ZVPR ,ZXDU ,[ZXF%] ,ZXFP ,ZXFV ,ZXHF ,ZXIN ,ZXRD ,ZXSC ,ZXSM ,ZXWC ,ZZCR ,ZZD1 ,ZZDR ,ZZP1 ,ZZSR ,ZERR ,ZDIF ,ZECR ,ZXCF ,ZECN 
    ,ZNRR ,ZBGD ,ZBUY ,ZCOC ,ZDIR ,ZEBD ,ZESC ,ZEXL ,ZFRH ,ZICF ,ZRY3 ,ZSIS ,ZVAS ,ZCOB ,ZNTS ,ZRRP ,ZDSB ,ZDSD ,ZDSN ,ZBD1 ,ZBD2 ,ZBD3 ,ZBD4 ,ZBD5 ,ZBD6 ,ZBD7 ,ZCOS, ZDP2, ZDCL, ZCOI, ZCDI, ZARC
	,ZOFP, ZDAC, ZOFV, [ZOF%], ZOIC, ZOVA, ZSIM, ZFAS, ZFAG, ZCLP, ZEDC, ZSW1, ZSKT, ZNPA, ZDPA, ZCBD)
    ) pvt
Option (LABEL='biz.S4Hana_SoDocItemPriceConditionsHistory : etl.S4Hana_SoDocItemPriceConditionsHistory_T4_Pivot 1')


-- Add last related entires from Hist which are in the new batch
INSERT INTO etl.S4Hana_SoDocItemPriceConditionsHistory_T4_Pivot
      (NatSalesOrderNo
      ,NatSalesOrderItemNo
      ,LDTS
	  ,HashDiff
      ,DIFF ,GRWR ,MWST ,PNTP ,VPRS ,ZACC ,ZAFG ,ZART ,ZB2B ,ZBOL ,ZCC1 ,ZCCE ,ZCIT ,ZCO1 ,ZCWD ,ZDIS ,ZDNP ,ZDVG ,ZEQU ,ZFMW ,ZFOC ,ZGS1 ,ZICV ,ZIDU ,[ZIF%] ,ZIFV ,ZIHF 
      ,ZIIN ,ZINM ,ZINV ,ZIUP ,ZLOG ,ZLSM ,ZMD0 ,ZMOV ,ZNEP ,ZOFF ,ZOPX ,ZORD ,ZOUT ,ZPAR ,ZPAY ,ZPR0 ,ZPRF ,ZRAC ,ZRAS ,ZRDI ,ZRMP ,ZRY1 ,ZRY2 ,ZSF1 ,ZSFP ,ZSPR ,ZSRD 
      ,ZSSC ,ZSSM, ZST1 ,ZSTS ,ZSWC ,ZVP1 ,ZVPR ,ZXDU ,[ZXF%] ,ZXFP ,ZXFV ,ZXHF ,ZXIN ,ZXRD ,ZXSC ,ZXSM ,ZXWC ,ZZCR ,ZZD1 ,ZZDR ,ZZP1 ,ZZSR ,ZERR ,ZDIF ,ZECR ,ZXCF ,ZECN 
      ,ZNRR ,ZBGD ,ZBUY ,ZCOC ,ZDIR ,ZEBD ,ZESC ,ZEXL ,ZFRH ,ZICF ,ZRY3 ,ZSIS ,ZVAS ,ZCOB ,ZNTS ,ZRRP ,ZDSB ,ZDSD ,ZDSN ,ZBD1 ,ZBD2 ,ZBD3 ,ZBD4 ,ZBD5 ,ZBD6 ,ZBD7 ,ZCOS ,ZDP2, ZDCL, ZCOI, ZCDI, ZARC
	  ,ZOFP ,ZDAC ,ZOFV, [ZOF%], ZOIC, ZOVA, ZSIM, ZFAS, ZFAG, ZCLP, ZEDC, ZSW1, ZSKT, ZNPA, ZDPA, ZCBD, SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist
	   )
SELECT SoPrCoHist.NatSalesOrderNo
	  ,SoPrCoHist.NatSalesOrderItemNo
	  ,SoPrCoHist.LDTS
	  ,SoPrCoHist.HashDiff
	  ,SoPrCoHist.DIFF ,SoPrCoHist.GRWR ,SoPrCoHist.MWST ,SoPrCoHist.PNTP ,SoPrCoHist.VPRS ,SoPrCoHist.ZACC ,SoPrCoHist.ZAFG ,SoPrCoHist.ZART ,SoPrCoHist.ZB2B 
	  ,SoPrCoHist.ZBOL ,SoPrCoHist.ZCC1 ,SoPrCoHist.ZCCE ,SoPrCoHist.ZCIT ,SoPrCoHist.ZCO1 ,SoPrCoHist.ZCWD ,SoPrCoHist.ZDIS ,SoPrCoHist.ZDNP ,SoPrCoHist.ZDVG 
	  ,SoPrCoHist.ZEQU ,SoPrCoHist.ZFMW ,SoPrCoHist.ZFOC ,SoPrCoHist.ZGS1 ,SoPrCoHist.ZICV ,SoPrCoHist.ZIDU ,SoPrCoHist.[ZIF%] ,SoPrCoHist.ZIFV ,SoPrCoHist.ZIHF 
	  ,SoPrCoHist.ZIIN ,SoPrCoHist.ZINM ,SoPrCoHist.ZINV ,SoPrCoHist.ZIUP ,SoPrCoHist.ZLOG ,SoPrCoHist.ZLSM ,SoPrCoHist.ZMD0 ,SoPrCoHist.ZMOV ,SoPrCoHist.ZNEP 
	  ,SoPrCoHist.ZOFF ,SoPrCoHist.ZOPX ,SoPrCoHist.ZORD ,SoPrCoHist.ZOUT ,SoPrCoHist.ZPAR ,SoPrCoHist.ZPAY ,SoPrCoHist.ZPR0 ,SoPrCoHist.ZPRF ,SoPrCoHist.ZRAC 
	  ,SoPrCoHist.ZRAS ,SoPrCoHist.ZRDI ,SoPrCoHist.ZRMP ,SoPrCoHist.ZRY1 ,SoPrCoHist.ZRY2 ,SoPrCoHist.ZSF1 ,SoPrCoHist.ZSFP ,SoPrCoHist.ZSPR ,SoPrCoHist.ZSRD 
	  ,SoPrCoHist.ZSSC ,SoPrCoHist.ZSSM, SoPrCoHist.ZST1 ,SoPrCoHist.ZSTS ,SoPrCoHist.ZSWC ,SoPrCoHist.ZVP1 ,SoPrCoHist.ZVPR ,SoPrCoHist.ZXDU ,SoPrCoHist.[ZXF%] 
	  ,SoPrCoHist.ZXFP ,SoPrCoHist.ZXFV ,SoPrCoHist.ZXHF ,SoPrCoHist.ZXIN ,SoPrCoHist.ZXRD ,SoPrCoHist.ZXSC ,SoPrCoHist.ZXSM ,SoPrCoHist.ZXWC ,SoPrCoHist.ZZCR 
	  ,SoPrCoHist.ZZD1 ,SoPrCoHist.ZZDR ,SoPrCoHist.ZZP1 ,SoPrCoHist.ZZSR ,SoPrCoHist.ZERR ,SoPrCoHist.ZDIF ,SoPrCoHist.ZECR ,SoPrCoHist.ZXCF ,SoPrCoHist.ZECN 
	  ,SoPrCoHist.ZNRR ,SoPrCoHist.ZBGD ,SoPrCoHist.ZBUY ,SoPrCoHist.ZCOC ,SoPrCoHist.ZDIR ,SoPrCoHist.ZEBD ,SoPrCoHist.ZESC ,SoPrCoHist.ZEXL ,SoPrCoHist.ZFRH 
	  ,SoPrCoHist.ZICF ,SoPrCoHist.ZRY3 ,SoPrCoHist.ZSIS ,SoPrCoHist.ZVAS ,SoPrCoHist.ZCOB ,SoPrCoHist.ZNTS ,SoPrCoHist.ZRRP ,SoPrCoHist.ZDSB ,SoPrCoHist.ZDSD 
	  ,SoPrCoHist.ZDSN ,SoPrCoHist.ZBD1 ,SoPrCoHist.ZBD2 ,SoPrCoHist.ZBD3 ,SoPrCoHist.ZBD4 ,SoPrCoHist.ZBD5 ,SoPrCoHist.ZBD6 ,SoPrCoHist.ZBD7 ,SoPrCoHist.ZCOS 
	  ,SoPrCoHist.ZDP2 ,SoPrCoHist.ZDCL ,SoPrCoHist.ZCOI, SoPrCoHist.ZCDI ,SoPrCoHist.ZARC ,SoPrCoHist.ZOFP ,SoPrCoHist.ZDAC ,SoPrCoHist.ZOFV ,SoPrCoHist.[ZOF%]
	  ,SoPrCoHist.ZOIC ,SoPrCoHist.ZOVA ,SoPrCoHist.ZSIM ,SoPrCoHist.ZFAS ,SoPrCoHist.ZFAG ,SoPrCoHist.ZCLP ,SoPrCoHist.ZEDC, SoPrCoHist.ZSW1, SoPrCoHist.ZSKT
	  ,SoPrCoHist.ZNPA, SoPrCoHist.ZDPA, SoPrCoHist.ZCBD
	  ,CONVERT(TINYINT,2) AS SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist
FROM biz.S4Hana_SoDocItemPriceConditionsHistory AS SoPrCoHist
INNER JOIN #SoPriceConditionsDistSoItemLastBatchWithOutLDTS AS soSoItemLast
		ON soSoItemLast.NatSalesOrderNo = SoPrCoHist.NatSalesOrderNo
		AND soSoItemLast.NatSalesOrderItemNo = SoPrCoHist.NatSalesOrderItemNo
		AND SoPrCoHist.LEDTS = '9999-12-31' ---> Get latest entrie from the hist table 	
Option (LABEL='biz.S4Hana_SoDocItemPriceConditionsHistory : etl.S4Hana_SoDocItemPriceConditionsHistory_T4_Pivot 2')

TRUNCATE TABLE etl.S4Hana_SoDocItemPriceConditionsHistory
-- remove duplictes and point to the first entry
;WITH preHash AS (
	SELECT NatSalesOrderNo
		  ,NatSalesOrderItemNo
		  ,LDTS
		  ,LAG(HashDiff) OVER (PARTITION BY NatSalesOrderNo, NatSalesOrderItemNo ORDER BY LDTS, SourceIdentifier DESC) AS pre_HashDiff
		  ,ROW_NUMBER() OVER (PARTITION BY NatSalesOrderNo, NatSalesOrderItemNo ORDER BY LDTS, SourceIdentifier DESC) AS RankOverAll
		  ,HashDiff
		  ,DIFF ,GRWR ,MWST ,PNTP ,VPRS ,ZACC ,ZAFG ,ZART ,ZB2B ,ZBOL ,ZCC1 ,ZCCE ,ZCIT ,ZCO1 ,ZCWD ,ZDIS ,ZDNP ,ZDVG ,ZEQU ,ZFMW ,ZFOC ,ZGS1 ,ZICV ,ZIDU ,[ZIF%] ,ZIFV ,ZIHF 
		  ,ZIIN ,ZINM ,ZINV ,ZIUP ,ZLOG ,ZLSM ,ZMD0 ,ZMOV ,ZNEP ,ZOFF ,ZOPX ,ZORD ,ZOUT ,ZPAR ,ZPAY ,ZPR0 ,ZPRF ,ZRAC ,ZRAS ,ZRDI ,ZRMP ,ZRY1 ,ZRY2 ,ZSF1 ,ZSFP ,ZSPR ,ZSRD 
		  ,ZSSC ,ZSSM, ZST1 ,ZSTS ,ZSWC ,ZVP1 ,ZVPR ,ZXDU ,[ZXF%] ,ZXFP ,ZXFV ,ZXHF ,ZXIN ,ZXRD ,ZXSC ,ZXSM ,ZXWC ,ZZCR ,ZZD1 ,ZZDR ,ZZP1 ,ZZSR ,ZERR ,ZDIF ,ZECR ,ZXCF ,ZECN 
		  ,ZNRR ,ZBGD ,ZBUY ,ZCOC ,ZDIR ,ZEBD ,ZESC ,ZEXL ,ZFRH ,ZICF ,ZRY3 ,ZSIS ,ZVAS ,ZCOB ,ZNTS ,ZRRP ,ZDSB ,ZDSD ,ZDSN ,ZBD1 ,ZBD2 ,ZBD3 ,ZBD4 ,ZBD5 ,ZBD6 ,ZBD7 ,ZCOS ,ZDP2
		  ,ZDCL ,ZCOI, ZCDI, ZARC ,ZOFP, ZDAC, ZOFV, [ZOF%], ZOIC, ZOVA, ZSIM, ZFAS, ZFAG, ZCLP,ZEDC, ZSW1, ZSKT, ZNPA, ZDPA, ZCBD
		  ,SourceIdentifier
FROM etl.S4Hana_SoDocItemPriceConditionsHistory_T4_Pivot
)
,DiffCheck AS (
	SELECT NatSalesOrderNo
	      ,NatSalesOrderItemNo
	      ,LDTS
		  ,ISNULL((DateAdd(ss ,-1, LEAD(LDTS) OVER (PARTITION BY NatSalesOrderNo, NatSalesOrderItemNo ORDER BY LDTS))),'9999-12-31') AS LEDTS
		  ,HashDiff
	      ,DIFF ,GRWR ,MWST ,PNTP ,VPRS ,ZACC ,ZAFG ,ZART ,ZB2B ,ZBOL ,ZCC1 ,ZCCE ,ZCIT ,ZCO1 ,ZCWD ,ZDIS ,ZDNP ,ZDVG ,ZEQU ,ZFMW ,ZFOC ,ZGS1 ,ZICV ,ZIDU ,[ZIF%] ,ZIFV ,ZIHF 
	      ,ZIIN ,ZINM ,ZINV ,ZIUP ,ZLOG ,ZLSM ,ZMD0 ,ZMOV ,ZNEP ,ZOFF ,ZOPX ,ZORD ,ZOUT ,ZPAR ,ZPAY ,ZPR0 ,ZPRF ,ZRAC ,ZRAS ,ZRDI ,ZRMP ,ZRY1 ,ZRY2 ,ZSF1 ,ZSFP ,ZSPR ,ZSRD 
	      ,ZSSC ,ZSSM, ZST1 ,ZSTS ,ZSWC ,ZVP1 ,ZVPR ,ZXDU ,[ZXF%] ,ZXFP ,ZXFV ,ZXHF ,ZXIN ,ZXRD ,ZXSC ,ZXSM ,ZXWC ,ZZCR ,ZZD1 ,ZZDR ,ZZP1 ,ZZSR ,ZERR ,ZDIF ,ZECR ,ZXCF ,ZECN 
	      ,ZNRR ,ZBGD ,ZBUY ,ZCOC ,ZDIR ,ZEBD ,ZESC ,ZEXL ,ZFRH ,ZICF ,ZRY3 ,ZSIS ,ZVAS ,ZCOB ,ZNTS ,ZRRP ,ZDSB ,ZDSD ,ZDSN ,ZBD1 ,ZBD2 ,ZBD3 ,ZBD4 ,ZBD5 ,ZBD6 ,ZBD7 ,ZCOS ,ZDP2
		  ,ZDCL ,ZCOI, ZCDI, ZARC ,ZOFP, ZDAC, ZOFV, [ZOF%], ZOIC, ZOVA, ZSIM, ZFAS, ZFAG, ZCLP,ZEDC, ZSW1, ZSKT, ZNPA, ZDPA, ZCBD
		  ,SourceIdentifier
	FROM preHash
	WHERE HashDiff <> pre_HashDiff
	   OR RankOverAll = 1 -- to get the first entry
)
INSERT INTO etl.S4Hana_SoDocItemPriceConditionsHistory
      (NatSalesOrderNo
      ,NatSalesOrderItemNo
      ,LDTS
	  ,LEDTS
	  ,HashDiff
      ,DIFF ,GRWR ,MWST ,PNTP ,VPRS ,ZACC ,ZAFG ,ZART ,ZB2B ,ZBOL ,ZCC1 ,ZCCE ,ZCIT ,ZCO1 ,ZCWD ,ZDIS ,ZDNP ,ZDVG ,ZEQU ,ZFMW ,ZFOC ,ZGS1 ,ZICV ,ZIDU ,[ZIF%] ,ZIFV ,ZIHF 
      ,ZIIN ,ZINM ,ZINV ,ZIUP ,ZLOG ,ZLSM ,ZMD0 ,ZMOV ,ZNEP ,ZOFF ,ZOPX ,ZORD ,ZOUT ,ZPAR ,ZPAY ,ZPR0 ,ZPRF ,ZRAC ,ZRAS ,ZRDI ,ZRMP ,ZRY1 ,ZRY2 ,ZSF1 ,ZSFP ,ZSPR ,ZSRD 
      ,ZSSC ,ZSSM, ZST1 ,ZSTS ,ZSWC ,ZVP1 ,ZVPR ,ZXDU ,[ZXF%] ,ZXFP ,ZXFV ,ZXHF ,ZXIN ,ZXRD ,ZXSC ,ZXSM ,ZXWC ,ZZCR ,ZZD1 ,ZZDR ,ZZP1 ,ZZSR ,ZERR ,ZDIF ,ZECR ,ZXCF ,ZECN 
      ,ZNRR ,ZBGD ,ZBUY ,ZCOC ,ZDIR ,ZEBD ,ZESC ,ZEXL ,ZFRH ,ZICF ,ZRY3 ,ZSIS ,ZVAS ,ZCOB ,ZNTS ,ZRRP ,ZDSB ,ZDSD ,ZDSN ,ZBD1 ,ZBD2 ,ZBD3 ,ZBD4 ,ZBD5 ,ZBD6 ,ZBD7 ,ZCOS ,ZDP2
	  ,ZDCL ,ZCOI, ZCDI, ZARC ,ZOFP, ZDAC, ZOFV, [ZOF%], ZOIC, ZOVA, ZSIM, ZFAS, ZFAG, ZCLP,ZEDC, ZSW1, ZSKT, ZNPA, ZDPA, ZCBD
	  ,SourceIdentifier
       )
SELECT NatSalesOrderNo
      ,NatSalesOrderItemNo
      ,LDTS
	  ,LEDTS
	  ,HashDiff
      ,DIFF ,GRWR ,MWST ,PNTP ,VPRS ,ZACC ,ZAFG ,ZART ,ZB2B ,ZBOL ,ZCC1 ,ZCCE ,ZCIT ,ZCO1 ,ZCWD ,ZDIS ,ZDNP ,ZDVG ,ZEQU ,ZFMW ,ZFOC ,ZGS1 ,ZICV ,ZIDU ,[ZIF%] ,ZIFV ,ZIHF 
      ,ZIIN ,ZINM ,ZINV ,ZIUP ,ZLOG ,ZLSM ,ZMD0 ,ZMOV ,ZNEP ,ZOFF ,ZOPX ,ZORD ,ZOUT ,ZPAR ,ZPAY ,ZPR0 ,ZPRF ,ZRAC ,ZRAS ,ZRDI ,ZRMP ,ZRY1 ,ZRY2 ,ZSF1 ,ZSFP ,ZSPR ,ZSRD 
      ,ZSSC ,ZSSM, ZST1 ,ZSTS ,ZSWC ,ZVP1 ,ZVPR ,ZXDU ,[ZXF%] ,ZXFP ,ZXFV ,ZXHF ,ZXIN ,ZXRD ,ZXSC ,ZXSM ,ZXWC ,ZZCR ,ZZD1 ,ZZDR ,ZZP1 ,ZZSR ,ZERR ,ZDIF ,ZECR ,ZXCF ,ZECN 
      ,ZNRR ,ZBGD ,ZBUY ,ZCOC ,ZDIR ,ZEBD ,ZESC ,ZEXL ,ZFRH ,ZICF ,ZRY3 ,ZSIS ,ZVAS ,ZCOB ,ZNTS ,ZRRP ,ZDSB ,ZDSD ,ZDSN ,ZBD1 ,ZBD2 ,ZBD3 ,ZBD4 ,ZBD5 ,ZBD6 ,ZBD7 ,ZCOS ,ZDP2
	  ,ZDCL ,ZCOI, ZCDI, ZARC ,ZOFP, ZDAC, ZOFV, [ZOF%], ZOIC, ZOVA, ZSIM, ZFAS, ZFAG, ZCLP,ZEDC, ZSW1, ZSKT, ZNPA, ZDPA, ZCBD
	  ,SourceIdentifier
FROM DiffCheck
WHERE SourceIdentifier = 1 -- only new entiers 
	OR (SourceIdentifier = 2 AND LEDTS <> '9999-12-31') -- keep existing entries to update LEDTS in the Hist table 
Option (LABEL='biz.S4Hana_SoDocItemPriceConditionsHistory : S4Hana_SoDocItemPriceConditionsHistoryNew')
-- Insert new entries to S4Hana_SoDocItemPriceConditionsHistoryNew.

BEGIN TRAN -- Make sure Insert and Update are done in the same transaction
	INSERT INTO biz.S4Hana_SoDocItemPriceConditionsHistory
		  (NatSalesOrderNo
		  ,NatSalesOrderItemNo
		  ,LDTS
		  ,LEDTS
		  ,HashDiff
		  ,DIFF ,GRWR ,MWST ,PNTP ,VPRS ,ZACC ,ZAFG ,ZART ,ZB2B ,ZBOL ,ZCC1 ,ZCCE ,ZCIT ,ZCO1 ,ZCWD ,ZDIS ,ZDNP ,ZDVG ,ZEQU ,ZFMW ,ZFOC ,ZGS1 ,ZICV ,ZIDU ,[ZIF%] ,ZIFV ,ZIHF 
		  ,ZIIN ,ZINM ,ZINV ,ZIUP ,ZLOG ,ZLSM ,ZMD0 ,ZMOV ,ZNEP ,ZOFF ,ZOPX ,ZORD ,ZOUT ,ZPAR ,ZPAY ,ZPR0 ,ZPRF ,ZRAC ,ZRAS ,ZRDI ,ZRMP ,ZRY1 ,ZRY2 ,ZSF1 ,ZSFP ,ZSPR ,ZSRD 
		  ,ZSSC ,ZSSM, ZST1 ,ZSTS ,ZSWC ,ZVP1 ,ZVPR ,ZXDU ,[ZXF%] ,ZXFP ,ZXFV ,ZXHF ,ZXIN ,ZXRD ,ZXSC ,ZXSM ,ZXWC ,ZZCR ,ZZD1 ,ZZDR ,ZZP1 ,ZZSR ,ZERR ,ZDIF ,ZECR ,ZXCF ,ZECN 
		  ,ZNRR ,ZBGD ,ZBUY ,ZCOC ,ZDIR ,ZEBD ,ZESC ,ZEXL ,ZFRH ,ZICF ,ZRY3 ,ZSIS ,ZVAS ,ZCOB ,ZNTS ,ZRRP ,ZDSB ,ZDSD ,ZDSN ,ZBD1 ,ZBD2 ,ZBD3 ,ZBD4 ,ZBD5 ,ZBD6 ,ZBD7 ,ZCOS ,ZDP2
		  ,ZDCL ,ZCOI, ZCDI, ZARC ,ZOFP, ZDAC, ZOFV, [ZOF%], ZOIC, ZOVA, ZSIM, ZFAS, ZFAG, ZCLP,ZEDC, ZSW1, ZSKT, ZNPA, ZDPA, ZCBD
		   )
	SELECT NatSalesOrderNo
		  ,NatSalesOrderItemNo
		  ,LDTS
		  ,LEDTS
		  ,HashDiff
		  ,DIFF ,GRWR ,MWST ,PNTP ,VPRS ,ZACC ,ZAFG ,ZART ,ZB2B ,ZBOL ,ZCC1 ,ZCCE ,ZCIT ,ZCO1 ,ZCWD ,ZDIS ,ZDNP ,ZDVG ,ZEQU ,ZFMW ,ZFOC ,ZGS1 ,ZICV ,ZIDU ,[ZIF%] ,ZIFV ,ZIHF 
		  ,ZIIN ,ZINM ,ZINV ,ZIUP ,ZLOG ,ZLSM ,ZMD0 ,ZMOV ,ZNEP ,ZOFF ,ZOPX ,ZORD ,ZOUT ,ZPAR ,ZPAY ,ZPR0 ,ZPRF ,ZRAC ,ZRAS ,ZRDI ,ZRMP ,ZRY1 ,ZRY2 ,ZSF1 ,ZSFP ,ZSPR ,ZSRD 
		  ,ZSSC ,ZSSM, ZST1 ,ZSTS ,ZSWC ,ZVP1 ,ZVPR ,ZXDU ,[ZXF%] ,ZXFP ,ZXFV ,ZXHF ,ZXIN ,ZXRD ,ZXSC ,ZXSM ,ZXWC ,ZZCR ,ZZD1 ,ZZDR ,ZZP1 ,ZZSR ,ZERR ,ZDIF ,ZECR ,ZXCF ,ZECN 
		  ,ZNRR ,ZBGD ,ZBUY ,ZCOC ,ZDIR ,ZEBD ,ZESC ,ZEXL ,ZFRH ,ZICF ,ZRY3 ,ZSIS ,ZVAS ,ZCOB ,ZNTS ,ZRRP ,ZDSB ,ZDSD ,ZDSN ,ZBD1 ,ZBD2 ,ZBD3 ,ZBD4 ,ZBD5 ,ZBD6 ,ZBD7 ,ZCOS ,ZDP2
		  ,ZDCL ,ZCOI, ZCDI, ZARC ,ZOFP, ZDAC, ZOFV, [ZOF%], ZOIC, ZOVA, ZSIM, ZFAS, ZFAG, ZCLP,ZEDC, ZSW1, ZSKT, ZNPA, ZDPA, ZCBD
	FROM etl.S4Hana_SoDocItemPriceConditionsHistory
	WHERE SourceIdentifier = 1 -- only new entiers 
	Option (LABEL='biz.S4Hana_SoDocItemPriceConditionsHistory : S4Hana_SoDocItemPriceConditionsHistory Insert')
	--Update LEDTS for entires with fresh inserted entries for this BK

	UPDATE histPre
	SET histPre.LEDTS = new.LEDTS
	FROM biz.S4Hana_SoDocItemPriceConditionsHistory AS histPre
	INNER JOIN etl.S4Hana_SoDocItemPriceConditionsHistory AS new
		ON histPre.NatSalesOrderNo = new.NatSalesOrderNo  -- join over NatSalesOrderNo and not HashDiff because the distribution of the tables via NatSalesOrderNo order by LDTS
		AND histPre.NatSalesOrderItemNo = new.NatSalesOrderItemNo
		AND histPre.LDTS = new.LDTS
	WHERE histPre.LEDTS = '9999-12-31'
	  AND new.SourceIdentifier = 2 -- only update Objects loaded from Hist table
	Option (LABEL='biz.S4Hana_SoDocItemPriceConditionsHistory : S4Hana_SoDocItemPriceConditionsHistory Update')
COMMIT TRAN; 

-- Update End of the load
UPDATE DTlogs
SET ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

END -- END SP
