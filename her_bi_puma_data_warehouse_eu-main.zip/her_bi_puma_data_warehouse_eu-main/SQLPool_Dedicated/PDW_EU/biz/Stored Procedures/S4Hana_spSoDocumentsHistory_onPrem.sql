﻿CREATE PROC [biz].[S4Hana_spSoDocumentsHistory_onPrem] @LDTS [DATETIME2](7) AS
BEGIN
SET NOCOUNT ON
-- DECLARE @LDTS DATETIME2(7) = '2000-01-02'
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(7) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(7)
DECLARE @DestinationLastLoadDate DATETIME2(7)
DECLARE @BatchLdts DATETIME2(7) = @LDTS

-- do not use the input parameter, in case of an failur or reload situartion take the last tranfered LDTS from the Hist table
IF(EXISTS(SELECT 1 FROM biz.S4Hana_SoDocumentsHistory_onPrem))
BEGIN
	SELECT @DestinationLastLoadDate =  MAX(LDTS)
	FROM biz.S4Hana_SoDocumentsHistory_onPrem
END
ELSE BEGIN
	SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
END 

IF(EXISTS(SELECT 1 FROM stag.S4Hana_SODocuments_full_onPrem))
BEGIN
	SELECT @SourceLastLoadDate = MAX(_LDTS)
	FROM stag.S4Hana_SODocuments_full_onPrem
END
ELSE BEGIN
	SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
END 

--Log Data load
INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'spSoDocumentsHistory_onPrem'
			,'prepSoDocHist_OnPrem'
			,'NatSalesOrdersOohHistory_onPrem'
			,'sales'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts

IF OBJECT_ID('tempdb..#SoDocumentFullLastIncrement') IS NOT NULL
BEGIN
    DROP TABLE #SoDocumentFullLastIncrement
END

CREATE TABLE #SoDocumentFullLastIncrement
WITH
(DISTRIBUTION = HASH(NatSalesOrderNo)
,HEAP)
AS(
SELECT CAST(stagSoDocFull.VBELN AS NVARCHAR(10)) AS NatSalesOrderNo 
		  ,CAST(stagSoDocFull.AUART AS NCHAR(4)) AS SOTypeCode
		  ,CAST(stagSoDocFull.BUKRS AS NCHAR(4)) AS CompanyCode
		  ,CAST(stagSoDocFull.WAERK AS NVARCHAR(5)) AS CurrencyCode
		  ,CAST(stagSoDocFull.VTWEG AS NCHAR(2)) AS DistributionChannelCode
		  ,CAST(stagSoDocFull.[/PUMA/PARVW_AG] AS NVARCHAR(10)) AS CustomerCode_SoldTo
		  ,CAST(CASE WHEN stagSoDocFull.ODQ_CHANGEMODE = 'D' THEN 1 ELSE 0 END AS BIT) AS IsDeleted
		  ,CAST(stagSoDocFull._LDTS AS Datetime2(0)) AS LDTS
		  ,ROW_NUMBER() OVER (PARTITION BY stagSoDocFull.VBELN, stagSoDocFull._LDTS ORDER BY stagSoDocFull.TS_SEQUENCE_NUMBER DESC) rn_PerLdts 
  		  ,CONVERT(BINARY(16),
  		  	HASHBYTES('MD5', CONCAT(
		  		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),stagSoDocFull.VBELN)))), '_',
		  		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),stagSoDocFull.AUART)))), '_',
		  		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),stagSoDocFull.BUKRS)))), '_',
		  		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),stagSoDocFull.WAERK)))), '_',
		  		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),stagSoDocFull.VTWEG)))), '_',
		  		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),stagSoDocFull.[/PUMA/PARVW_AG])))), '_',
		  		--UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),stagSoDocFull.ODQ_CHANGEMODE)))) -- to avoid changes from NULL --> 'U'
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),CASE WHEN stagSoDocFull.ODQ_CHANGEMODE = 'D' THEN 1 ELSE 0 END))))
  		  ))) AS HashDiff
		  ,CONVERT(TINYINT,1) AS SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist
FROM stag.S4Hana_SODocuments_full_onPrem AS stagSoDocFull
INNER JOIN stag.S4Hana_vSalesOrgToCompanyCode AS sct01 
			ON stagSoDocFull.BUKRS = sct01.CompanyCode	
WHERE stagSoDocFull._LDTS > @DestinationLastLoadDate	
)

INSERT INTO #SoDocumentFullLastIncrement
	(NatSalesOrderNo 
	,SOTypeCode
	,CompanyCode
	,CurrencyCode
	,DistributionChannelCode
	,CustomerCode_SoldTo
	,IsDeleted
	,LDTS
	,rn_PerLdts
	,HashDiff
	,SourceIdentifier)
	SELECT SoHist.NatSalesOrderNo 
		  ,SoHist.SOTypeCode
		  ,SoHist.CompanyCode
		  ,SoHist.CurrencyCode
		  ,SoHist.DistributionChannelCode
		  ,SoHist.CustomerCode_SoldTo
		  ,SoHist.IsDeleted
		  ,SoHist.LDTS
		  ,CONVERT(INT,1) AS rn_PerLdts
  		  ,SoHist.HashDiff
		  ,CONVERT(TINYINT,2) AS SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist
FROM #SoDocumentFullLastIncrement AS stagNew
INNER JOIN biz.S4Hana_SoDocumentsHistory_onPrem AS SoHist
	ON stagNew.NatSalesOrderNo = SoHist.NatSalesOrderNo
	AND SoHist.LEDTS = '9999-12-31'

;CREATE TABLE #SODocumentsHistNew
WITH
(DISTRIBUTION = HASH(NatSalesOrderNo)
,HEAP)
AS
WITH preHash AS 
	(SELECT NatSalesOrderNo
		   ,SOTypeCode
		   ,CompanyCode
		   ,CurrencyCode
		   ,DistributionChannelCode
		   ,CustomerCode_SoldTo
		   ,IsDeleted
		   ,LDTS
		   ,HashDiff
		   ,SourceIdentifier
		   ,LAG(HashDiff) OVER (PARTITION BY NatSalesOrderNo ORDER BY LDTS) AS pre_HashDiff
		   ,ROW_NUMBER() OVER (PARTITION BY NatSalesOrderNo ORDER BY LDTS) AS RankOverAll
	FROM #SoDocumentFullLastIncrement
	WHERE rn_PerLdts = 1
	)
, DiffCheck AS (
SELECT NatSalesOrderNo
	  ,LDTS
	  ,ISNULL((DateAdd(ss ,-1, LEAD(LDTS) OVER (PARTITION BY NatSalesOrderNo ORDER BY LDTS))),'9999-12-31') AS LEDTS
	  ,HashDiff
	  ,SOTypeCode
      ,CompanyCode
      ,CurrencyCode
      ,DistributionChannelCode
      ,CustomerCode_SoldTo
	  ,IsDeleted
	  ,SourceIdentifier
FROM preHash
WHERE HashDiff <> pre_HashDiff
	  OR RankOverAll = 1 -- to get the first entry
)
SELECT NatSalesOrderNo
	  ,LDTS
	  ,LEDTS
	  ,HashDiff
	  ,SOTypeCode
      ,CompanyCode
      ,CurrencyCode
      ,DistributionChannelCode
      ,CustomerCode_SoldTo
	  ,IsDeleted
	  ,SourceIdentifier
FROM DiffCheck
WHERE SourceIdentifier = 1 -- only new entiers 
	OR (SourceIdentifier = 2 AND LEDTS <> '9999-12-31') -- existing entries to update LEDTS in the HIST table 

-- Insert new entries to S4Hana_SODocumentsHistPre
INSERT INTO biz.S4Hana_SoDocumentsHistory_onPrem
	  (NatSalesOrderNo
      ,LDTS
      ,LEDTS
      ,HashDiff
      ,SOTypeCode
      ,CompanyCode
      ,CurrencyCode
      ,DistributionChannelCode
      ,CustomerCode_SoldTo
      ,IsDeleted)
SELECT NatSalesOrderNo
	  ,LDTS
	  ,LEDTS
	  ,HashDiff
	  ,SOTypeCode
      ,CompanyCode
      ,CurrencyCode
      ,DistributionChannelCode
      ,CustomerCode_SoldTo
	  ,IsDeleted
FROM #SODocumentsHistNew
WHERE SourceIdentifier = 1  -- only new Objects from the Incremental 

--Update LEDTS for entires with fresh inserted entries for this BK
UPDATE histPre
SET histPre.LEDTS = new.LEDTS
FROM biz.S4Hana_SoDocumentsHistory_onPrem AS histPre
INNER JOIN #SODocumentsHistNew AS new
	ON histPre.NatSalesOrderNo = new.NatSalesOrderNo
	AND histPre.LDTS = new.LDTS
WHERE histPre.LEDTS = '9999-12-31'
  AND new.SourceIdentifier = 2 -- only update Objects loaded from Hist table

  -- Update End of the load
UPDATE DTlogs
SET ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

END -- END SP