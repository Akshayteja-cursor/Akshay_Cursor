﻿CREATE PROC [biz].[S4Hana_spDeliveryDocumentAggSoItemsHistory] @LDTS [DATETIME2](7) AS
BEGIN
SET NOCOUNT ON
--DECLARE @LDTS DATETIME2(7) = '2000-01-01'
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(7) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(7)
DECLARE @DestinationLastLoadDate DATETIME2(7)
DECLARE @BatchLdts DATETIME2(7) = @LDTS

-- do not use the input parameter, in case of an failur or reload situartion take the last tranfered LDTS from the Hist table
IF(EXISTS(SELECT 1 FROM biz.S4Hana_DeliveryDocumentAggSoItemsHistory))
BEGIN
	SELECT @DestinationLastLoadDate =  MAX(LDTS)
	FROM biz.S4Hana_DeliveryDocumentAggSoItemsHistory
END
ELSE BEGIN
	SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
END 

IF(EXISTS(SELECT 1 FROM biz.S4Hana_DeliveryDocumentItemsHistory))
BEGIN
	SELECT @SourceLastLoadDate = MAX(LDTS)
	FROM biz.S4Hana_DeliveryDocumentItemsHistory
END
ELSE BEGIN
	SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
END 


--Log Data load
INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'S4Hana_spDeliveryDocumentAggSoItemsHistory'
			,'prepSoDocHist'
			,'NatSalesOrdersOohHistory'
			,'sales'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts

IF OBJECT_ID('tempdb..#DistDeliveryDocumentLdts') IS NOT NULL
BEGIN
    DROP TABLE #DistDeliveryDocumentLdts
END

IF OBJECT_ID('tempdb..#DistDeliveryDocumentLdts') IS NOT NULL
BEGIN
    DROP TABLE #DistDeliveryDocumentLdts
END

CREATE TABLE #DistDeliveryDocumentLdts 
WITH
(DISTRIBUTION = HASH(DeliveryNoteNumber)
,HEAP)
AS(	SELECT DeliveryNoteNumber
		  ,LDTS 
	FROM biz.S4Hana_DeliveryDocumentItemsHistory 
	WHERE LDTS > @DestinationLastLoadDate
	UNION
	SELECT DeliveryNoteNumber
		  ,LDTS
	FROM biz.S4Hana_DeliveryDocumentsHistory 
	WHERE LDTS > @DestinationLastLoadDate
	)

IF OBJECT_ID('tempdb..#DistSoItems') IS NOT NULL
BEGIN
    DROP TABLE #DistSoItems
END
CREATE TABLE #DistSoItems 
WITH
(DISTRIBUTION = HASH(NatSalesOrderNo)
,HEAP)
AS(	SELECT DISTINCT 
		   DelSoItems.NatSalesOrderNo	
		  ,DelSoItems.NatSalesOrderItemNo	
	FROM biz.S4Hana_DeliveryDocumentItemsHistory AS DelSoItems
	INNER JOIN #DistDeliveryDocumentLdts AS DistDelDoc
		ON DelSoItems.DeliveryNoteNumber = DistDelDoc.DeliveryNoteNumber
	)

IF OBJECT_ID('tempdb..#DistDelDocSoItemsLdts') IS NOT NULL
BEGIN
    DROP TABLE #DistDelDocSoItemsLdts
END
CREATE TABLE #DistDelDocSoItemsLdts 
WITH
(DISTRIBUTION = HASH(NatSalesOrderNo)
,HEAP)
AS(	SELECT DelNotItems.DeliveryNoteNumber
		  ,DelNotItems.DeliveryNoteItemNo 
		  ,DistSoItems.NatSalesOrderNo	
		  ,DistSoItems.NatSalesOrderItemNo	
		  ,DelNotItems.LDTS
	FROM #DistSoItems AS DistSoItems 
	INNER JOIN biz.S4Hana_DeliveryDocumentItemsHistory AS DelNotItems
		ON  DistSoItems.NatSalesOrderNo = DelNotItems.NatSalesOrderNo
		AND DistSoItems.NatSalesOrderItemNo = DelNotItems.NatSalesOrderItemNo
	UNION 
	SELECT DelNotItems.DeliveryNoteNumber
		  ,DelNotItems.DeliveryNoteItemNo 
		  ,DistSoItems.NatSalesOrderNo	
		  ,DistSoItems.NatSalesOrderItemNo	
		  ,DelNot.LDTS
	FROM #DistSoItems AS DistSoItems 
	INNER JOIN biz.S4Hana_DeliveryDocumentItemsHistory AS DelNotItems
		ON  DistSoItems.NatSalesOrderNo =DelNotItems.NatSalesOrderNo
		AND DistSoItems.NatSalesOrderItemNo = DelNotItems.NatSalesOrderItemNo
	INNER JOIN biz.S4Hana_DeliveryDocumentsHistory AS DelNot
		ON DelNotItems.DeliveryNoteNumber = DelNot.DeliveryNoteNumber
	)


IF OBJECT_ID('tempdb..#ExtDelDocSoItemsLdts') IS NOT NULL
BEGIN
    DROP TABLE #ExtDelDocSoItemsLdts
END
CREATE TABLE #ExtDelDocSoItemsLdts 
WITH
(DISTRIBUTION = HASH(NatSalesOrderNo)
,HEAP)
AS 
WITH ExtDelItemsNotesAggLDTS AS(	
	SELECT DISTINCT
		   DelSoItems.DeliveryNoteNumber
		  ,DelSoItems.DeliveryNoteItemNo 
		  ,DelSoItems.NatSalesOrderNo	
		  ,DelSoItems.NatSalesOrderItemNo	
		  ,DelSoItems.LDTS
		  ,DistSoItemsLdts.LDTS AS LdtsAgg
		  ,DelSoItems.ActualDeliveryQuantity
		  ,bizDelDocNote.OverallBillingStatus
		  ,bizDelDocNote.ActualGoodsMovementDate
		  ,CONVERT(TINYINT,CASE WHEN bizDelDocNote.IsDeleted = 1 OR DelSoItems.IsDeleted = 1 THEN 1 ELSE 0 END) AS IsDeleted
	FROM #DistDelDocSoItemsLdts AS DistSoItemsLdts 	
	INNER JOIN biz.S4Hana_DeliveryDocumentItemsHistory AS DelSoItems
		ON DistSoItemsLdts.NatSalesOrderNo = DelSoItems.NatSalesOrderNo
		AND DistSoItemsLdts.NatSalesOrderItemNo = DelSoItems.NatSalesOrderItemNo
		AND DistSoItemsLdts.LDTS BETWEEN DelSoItems.LDTS AND DelSoItems.LEDTS
	INNER JOIN biz.S4Hana_DeliveryDocumentsHistory AS bizDelDocNote
		ON DelSoItems.DeliveryNoteNumber = bizDelDocNote.DeliveryNoteNumber
		AND DistSoItemsLdts.LDTS BETWEEN bizDelDocNote.LDTS AND bizDelDocNote.LEDTS
	WHERE DelSoItems.LDTS <= DistSoItemsLdts.LDTS
	)
,ExtDelNotesAggLDTS AS( 
	SELECT extItem.DeliveryNoteNumber
		  ,extItem.DeliveryNoteItemNo
		  ,extItem.NatSalesOrderNo
		  ,extItem.NatSalesOrderItemNo
		  ,extItem.LDTS
		  ,extItem.LdtsAgg
		  ,extItem.ActualDeliveryQuantity
		  ,extItem.OverallBillingStatus
		  ,extItem.ActualGoodsMovementDate
		  ,extItem.IsDeleted
		  ,ROW_NUMBER() OVER (PARTITION BY extItem.DeliveryNoteNumber ,extItem.DeliveryNoteItemNo ,extItem.NatSalesOrderNo ,extItem.NatSalesOrderItemNo, extItem.LdtsAgg ORDER BY extItem.LDTS DESC) AS rn_DelNotBk
	FROM ExtDelItemsNotesAggLDTS AS extItem
	)
	SELECT NatSalesOrderNo
		  ,NatSalesOrderItemNo
		  ,SUM(CASE WHEN IsDeleted = 1 OR ActualGoodsMovementDate IS NULL THEN 0 ELSE ActualDeliveryQuantity END) AS ActualDeliveryQuantity  -- consider ActDelQty if ActualGMovementDate is availible 
		  --,SUM(CASE WHEN IsDeleted = 1 THEN 0 ELSE ActualDeliveryQuantity END) AS ActualDeliveryQuantity  -- consider ActDelQty independent of the ActualGMovementDate 
		  ,SUM(CASE WHEN IsDeleted = 0 and OverallBillingStatus = 'C' THEN ActualDeliveryQuantity ELSE 0 END) AS CompletedDeliveryQuantity
		  ,MIN(IsDeleted) AS IsDeleted
		  ,LdtsAgg AS LDTS
	FROM ExtDelNotesAggLDTS
	WHERE rn_DelNotBk = 1
	GROUP BY NatSalesOrderNo
			,NatSalesOrderItemNo
			,LdtsAgg

OPTION (LABEL='biz.S4Hana_spDeliveryDocumentAggSoItemsHistory : #ExtDelDocSoItemsLdts')

IF OBJECT_ID('tempdb..#DeliveryDocumentAggSoItemsFull') IS NOT NULL
BEGIN
    DROP TABLE #DeliveryDocumentAggSoItemsFull
END

CREATE TABLE #DeliveryDocumentAggSoItemsFull
WITH
(DISTRIBUTION = HASH(NatSalesOrderNo)
,HEAP)
AS (
SELECT NatSalesOrderNo
	  ,NatSalesOrderItemNo	  
	  ,LDTS
	  ,CONVERT(BINARY(16),
  		  HASHBYTES('MD5', CONCAT(
		  		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),NatSalesOrderNo)))), '_',
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),NatSalesOrderItemNo)))), '_',
		  		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ActualDeliveryQuantity)))) ,'_',
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),CompletedDeliveryQuantity)))) ,'_',
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),IsDeleted))))
	   ))) AS HashDiff
	   ,ActualDeliveryQuantity
	   ,CompletedDeliveryQuantity
	   ,IsDeleted
	  ,CONVERT(TINYINT,1) AS SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist
FROM #ExtDelDocSoItemsLdts
)
OPTION (LABEL='biz.S4Hana_spDeliveryDocumentAggSoItemsHistory : #DeliveryDocumentAggSoItemsFull 1')

INSERT INTO #DeliveryDocumentAggSoItemsFull
	  (NatSalesOrderNo
	  ,NatSalesOrderItemNo	  
	  ,LDTS
	  ,HashDiff
	  ,ActualDeliveryQuantity
	  ,CompletedDeliveryQuantity
	  ,IsDeleted
	  ,SourceIdentifier)
SELECT bizHist.NatSalesOrderNo
	  ,bizHist.NatSalesOrderItemNo	  
	  ,bizHist.LDTS
	  ,bizHist.HashDiff
	  ,bizHist.ActualDeliveryQuantity
	  ,bizHist.CompletedDeliveryQuantity
	  ,bizHist.IsDeleted
	  ,CONVERT(TINYINT,2) AS SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist
FROM #DeliveryDocumentAggSoItemsFull AS DDSoItemNew
INNER JOIN biz.S4Hana_DeliveryDocumentAggSoItemsHistory AS bizHist
		ON DDSoItemNew.NatSalesOrderNo = bizHist.NatSalesOrderNo
		AND DDSoItemNew.NatSalesOrderItemNo = bizHist.NatSalesOrderItemNo
		AND bizHist.LEDTS = '9999-12-31' ---> Get latest entrie from the hist table 
OPTION (LABEL='biz.S4Hana_spDeliveryDocumentAggSoItemsHistory : #DeliveryDocumentAggSoItemsFull 2')

IF OBJECT_ID('tempdb..#DeliveryDocumentAggSoItemsHistory') IS NOT NULL
BEGIN
    DROP TABLE #DeliveryDocumentAggSoItemsHistory
END

CREATE TABLE #DeliveryDocumentAggSoItemsHistory
WITH
(DISTRIBUTION = HASH(NatSalesOrderNo)
,HEAP)
AS 
WITH preHash AS (
	 SELECT NatSalesOrderNo
		   ,NatSalesOrderItemNo	  
		   ,LDTS
		   ,HashDiff
		   ,ActualDeliveryQuantity
		   ,CompletedDeliveryQuantity
		   ,IsDeleted
		   ,SourceIdentifier
		   ,LAG(HashDiff) OVER (PARTITION BY NatSalesOrderNo, NatSalesOrderItemNo ORDER BY LDTS, SourceIdentifier DESC) AS pre_HashDiff -- add SourceIdentifier DESC to make sure if an exiting record from the final table get detected as the first one 
		   ,ROW_NUMBER() OVER (PARTITION BY NatSalesOrderNo, NatSalesOrderItemNo ORDER BY LDTS, SourceIdentifier DESC) AS RankOverAll
	FROM #DeliveryDocumentAggSoItemsFull
)
,DiffCheck AS (
	SELECT NatSalesOrderNo
		  ,NatSalesOrderItemNo
		  ,LDTS
		  ,ISNULL((DateAdd(ss ,-1, LEAD(LDTS) OVER (PARTITION BY NatSalesOrderNo, NatSalesOrderItemNo ORDER BY LDTS))),'9999-12-31') AS LEDTS
		  ,HashDiff
		  ,ActualDeliveryQuantity
		  ,CompletedDeliveryQuantity
		  ,IsDeleted
		  ,SourceIdentifier
	FROM preHash
	WHERE HashDiff <> pre_HashDiff
	   OR RankOverAll = 1 -- to get the first entry
)
SELECT NatSalesOrderNo
	  ,NatSalesOrderItemNo
	  ,LDTS
	  ,LEDTS
	  ,HashDiff
	  ,ActualDeliveryQuantity
	  ,CompletedDeliveryQuantity
	  ,IsDeleted
	  ,SourceIdentifier
FROM DiffCheck
WHERE SourceIdentifier = 1 -- only new entiers 
	OR (SourceIdentifier = 2 AND LEDTS <> '9999-12-31') -- existing entries to update LEDTS in the HIST table 
OPTION (LABEL='biz.S4Hana_spDeliveryDocumentAggSoItemsHistory : #DeliveryDocumentAggSoItemsHistory')

BEGIN TRAN -- Make sure Insert and Update are done in the same transaction
	-- Insert new entries to S4Hana_DeliveryDocumentAggSoItemsHistory
	INSERT INTO biz.S4Hana_DeliveryDocumentAggSoItemsHistory
		  (NatSalesOrderNo
		  ,NatSalesOrderItemNo
		  ,LDTS
		  ,LEDTS
		  ,HashDiff
		  ,ActualDeliveryQuantity
		  ,CompletedDeliveryQuantity
		  ,IsDeleted)
	SELECT NatSalesOrderNo
		  ,NatSalesOrderItemNo
		  ,LDTS
		  ,LEDTS
		  ,HashDiff
		  ,ActualDeliveryQuantity
		  ,CompletedDeliveryQuantity
		  ,IsDeleted
	FROM #DeliveryDocumentAggSoItemsHistory
	WHERE SourceIdentifier = 1 -- only new entiers 

	--Update LEDTS for entires with fresh inserted entries for this BK
	UPDATE histPre
	SET histPre.LEDTS = new.LEDTS
	FROM biz.S4Hana_DeliveryDocumentAggSoItemsHistory AS histPre
	INNER JOIN #DeliveryDocumentAggSoItemsHistory AS new
		ON histPre.NatSalesOrderNo = new.NatSalesOrderNo  -- join over NatSalesOrderNo and not HashDiff because the distribution of the tables via NatSalesOrderNo order by LDTS
		AND histPre.NatSalesOrderItemNo = new.NatSalesOrderItemNo
		AND histPre.LDTS = new.LDTS
	WHERE histPre.LEDTS = '9999-12-31'
	  AND new.SourceIdentifier = 2 -- only update Objects loaded from Hist table
COMMIT TRAN; 

-- Update End of the load
UPDATE DTlogs
SET ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

EXEC [biz].[S4Hana_spDeliveryDocumentAggSoItemsHistory_CEU] @LDTS

END -- END SP