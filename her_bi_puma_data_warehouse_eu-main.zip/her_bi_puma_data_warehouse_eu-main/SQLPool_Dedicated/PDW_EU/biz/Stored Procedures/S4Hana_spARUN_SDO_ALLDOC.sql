﻿CREATE PROC [biz].[S4Hana_spARUN_SDO_ALLDOC] @ldts [DATETIME2](7) AS
BEGIN
    SET NOCOUNT ON;
    SET ANSI_WARNINGS ON;

	DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
    DECLARE @ExecStart DATETIME2(7)             = GETDATE()
    DECLARE @SourceLastLoadDate DATETIME2(7)
    DECLARE @DestinationLastLoadDate DATETIME2(7) = '1990-01-01'
    DECLARE @BatchLdts DATETIME2(7) = @LDTS
    DECLARE @AffectedRows BIGINT    = NULL

    
	--Log Data load
    INSERT INTO etl.DataTransferLogs
           (DataTransferLogId
                , TransferName
                , TransferGroupName
                , TargetTableName
                , TargetSchemaName
                , ExecStart
                , SourceLastLoadDate
                , DestinationLastLoadDate
                , BatchLdts
           )
    SELECT
           @DataTransferLogId
         ,'S4Hana_spARUN_SDO_ALLDOC'
         ,'ARUN_SDO_ALLDOC'
         ,'S4Hana_ARUN_SDO_ALLDOC'
         ,'biz'
         , @ExecStart
         , @SourceLastLoadDate
         , @DestinationLastLoadDate
         , @BatchLdts
    
    

/*Get the Deleted records*/    
	
	IF OBJECT_ID(N'tempdb..#Deleted') IS NOT NULL
    DROP TABLE #Deleted
    ;

    SELECT ARunid , max(_LDTS) as _LDTS
		INTO #Deleted
    FROM [stag].[S4Hana_vARUN_Latest_WithDeletionStatus]
			WHERE [__operation_type] = 'X'
			AND _LDTS > @DestinationLastLoadDate
    GROUP BY ARunid


/*Get the Deleted records attributes*/    

    IF OBJECT_ID(N'tempdb..#del_attrb') IS NOT NULL
    DROP TABLE #del_attrb
    ;
    
    SELECT		 s.arunid
				,s.Salesdoc_Num
				,s.salesdoc_item
				,s.PONumberStock
				,s.supplytype
				,s.Delivery_Date_PO
				,s.ALLOC_QTY
				,d._LDTS
    into #del_attrb
    from #Deleted d inner join [stag].[S4Hana_vARUN_OriginalRecords] s
                    on d.arunid = s.arunid
					AND s.supplytype in ('A','B','C','L','E', 'T')
 
 /*create the records with BK and HashDiff*/    
 
 IF OBJECT_ID(N'tempdb..#ARun') IS NOT NULL
    DROP TABLE #ARun;
    
    SELECT
           ARunid
         , SalesOrderNo + SalesOrderItemNo+ '|' +PONo AS [SOPO_bk]
         , SalesOrderNo
         , SalesOrderItemNo
         , PONo
		 , supplytype
	     , Delivery_Date_PO
		 , ALLOC_QTY
         , LDTS
         , IsDeleted
         , CONVERT([BINARY](16), 
			HASHBYTES('MD5',CONCAT( 
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),SalesOrderNo + SalesOrderItemNo+ '|' +PONo )))),'_', 
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),SalesOrderNo )))),'_', 
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),SalesOrderItemNo )))),'_', 
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),PONo )))),'_', 
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),supplytype )))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),Delivery_Date_PO )))),'_', 
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),ALLOC_QTY )))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),IsDeleted)))))) 
			) AS HashDiff
		INTO #ARun
    FROM (
			SELECT
                         ARunid
                       , Salesdoc_Num                       AS SalesOrderNo     --BK
                       , RIGHT('000000' + salesdoc_item, 6) AS SalesOrderItemNo --BK
                       , PONumberStock                      AS PONo             --BK
					   , supplytype
                       , Delivery_Date_PO                   AS Delivery_Date_PO
					   , ALLOC_QTY
                       , CAST(_LDTS AS SMALLDATETIME)       AS LDTS
                       , 0                                  AS IsDeleted
                  FROM [stag].[S4Hana_vARUN_Latest_WithDeletionStatus]
                  WHERE  [__operation_type]   <> 'X'
                         AND Delivery_Date_PO <> '9999-99-99'
                         AND STORAGE_LOCATION NOT IN ('0008') --remove the dedicated and returns
                         AND REQ_type NOT  IN ('BB','U1')
                         AND supplytype IN ('A','B','C','L','E', 'T')
                         AND _LDTS > @DestinationLastLoadDate
                  UNION
			SELECT
                         ARunid
                       , Salesdoc_Num                       AS SalesOrderNo     --BK
                       , RIGHT('000000' + salesdoc_item, 6) AS SalesOrderItemNo --BK
                       , PONumberStock                      AS PONo             --BK
					   , supplytype
                       , Delivery_Date_PO                   AS Delivery_Date_PO
					   , ALLOC_QTY
                       , CAST(_LDTS AS SMALLDATETIME)       AS LDTS
                       , 1                                  AS IsDeleted
                  FROM
                         #del_attrb
           ) ARUN
 
 
 /*count new Records */

    SELECT @AffectedRows = COUNT(*)
    FROM #ARun AS stg

TRUNCATE TABLE biz.[S4Hana_ARUN_SDO_ALLDOC]
 /*insert bnew records*/

INSERT INTO biz.[S4Hana_ARUN_SDO_ALLDOC]
           ( ARunid
                , SOPO_bk
                , SalesOrderNo
                , SalesOrderItemNo
                , PONo
				, supplytype
                , Delivery_Date_PO
				, ALLOC_QTY
                , LDTS
                , IsDeleted
                , HashDiff
           )
    SELECT
              stg.ARunid
            , stg.SOPO_bk
            , stg.SalesOrderNo
            , stg.SalesOrderItemNo
            , stg.PONo
			, stg.supplytype
            , stg.Delivery_Date_PO
			, stg.ALLOC_QTY
            , stg.LDTS
            , stg.IsDeleted
            , stg.HashDiff
    FROM #ARun AS stg 

UPDATE DTlogs
SET    Inserted = @AffectedRows
FROM etl.DataTransferLogs DTlogs
WHERE  DataTransferLogId = @DataTransferLogId

-- truncate table biz.[S4Hana_ARUN_SDO_ALLDOC]
-- exec [biz].[S4Hana_spARUN_SDO_ALLDOC]'1900-01-01'

END