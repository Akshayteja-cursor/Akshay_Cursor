﻿CREATE PROC [biz].[S4Hana_spPOPricingConditions] @LDTS [DATETIME2](7) AS
BEGIN
    SET NOCOUNT ON;
    SET ANSI_WARNINGS ON;

    IF OBJECT_ID(N'tempdb..#POPricingConditions') IS NOT NULL
        DROP TABLE #POPricingConditions

    CREATE TABLE #POPricingConditions
    WITH
    (
      DISTRIBUTION = HASH(PricingDocument),
	  CLUSTERED INDEX ([PricingDocument] ASC, [PricingDocumentItem] ASC, [PricingProcedureStep] ASC, [PricingProcedureCounter] ASC)
    )
    AS
    SELECT
         PricingDocument         --BK
       , PricingDocumentItem     --BK
       , PricingProcedureStep    --BK
       , PricingProcedureCounter --BK
       , CompanyCode
       , ConditionApplication
       , ConditionTypeCode
       , ConditionAmount
       , IsDeleted
       , LDTS
	   , CONVERT([BINARY](16),
				HASHBYTES('MD5',CONCAT(
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PricingDocument)))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PricingDocumentItem)))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PricingProcedureStep)))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PricingProcedureCounter)))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CompanyCode)))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ConditionApplication)))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ConditionTypeCode)))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ConditionAmount)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), IsDeleted))))))
			) AS HashDiff
    FROM stag.S4Hana_fnPOPricingConditions(@LDTS)
    OPTION (LABEL = 'biz.S4Hana_spPOPricingConditions: DeltaTempTableFromFunctionStatement')

    --update changed
    UPDATE
          dest
    SET
          dest.CompanyCode = src.CompanyCode
        , dest.ConditionApplication = src.ConditionApplication
        , dest.ConditionTypeCode = src.ConditionTypeCode
        , dest.ConditionAmount = src.ConditionAmount
        , dest.IsDeleted = src.IsDeleted
        , dest.LDTS = src.LDTS
        , dest.HashDiff = src.HashDiff
    FROM  biz.S4Hana_POPricingConditions AS dest
    JOIN  #POPricingConditions           AS src ON src.PricingDocument = dest.PricingDocument
                                                   AND src.PricingDocumentItem = dest.PricingDocumentItem
                                                   AND src.PricingProcedureStep = dest.PricingProcedureStep
                                                   AND src.PricingProcedureCounter = dest.PricingProcedureCounter
    WHERE src.IsDeleted = 0 AND src.HashDiff <> dest.HashDiff
    OPTION (LABEL = 'biz.S4Hana_spPOPricingConditions: UpdateStatement')

    --load new
    INSERT INTO biz.S4Hana_POPricingConditions
    (
        PricingDocument         --BK
      , PricingDocumentItem     --BK
      , PricingProcedureStep    --BK
      , PricingProcedureCounter --BK
      , CompanyCode
      , ConditionApplication
      , ConditionTypeCode
      , ConditionAmount
      , IsDeleted
      , LDTS
      , HashDiff
    )    
    SELECT
              src.PricingDocument         --BK
            , src.PricingDocumentItem     --BK
            , src.PricingProcedureStep    --BK
            , src.PricingProcedureCounter --BK
            , src.CompanyCode
            , src.ConditionApplication
            , src.ConditionTypeCode
            , src.ConditionAmount
            , src.IsDeleted
            , src.LDTS
            , src.HashDiff
    FROM      #POPricingConditions           AS src
    LEFT JOIN biz.S4Hana_POPricingConditions AS dest ON src.PricingDocument = dest.PricingDocument
                                                        AND src.PricingDocumentItem = dest.PricingDocumentItem
                                                        AND src.PricingProcedureStep = dest.PricingProcedureStep
                                                        AND src.PricingProcedureCounter = dest.PricingProcedureCounter
    WHERE     src.IsDeleted = 0 AND dest.PricingDocument IS NULL
    OPTION (LABEL = 'biz.S4Hana_spPOPricingConditions: InsertStatement')

    IF OBJECT_ID(N'tempdb..#DeletedPOPricingConditions') IS NOT NULL
        DROP TABLE #DeletedPOPricingConditions

    CREATE TABLE #DeletedPOPricingConditions
    WITH
    (
      DISTRIBUTION = HASH(PricingDocument),
      CLUSTERED INDEX ([PricingDocument] ASC, [PricingDocumentItem] ASC, [PricingProcedureStep] ASC, [PricingProcedureCounter] ASC)
    )
    AS
    SELECT
          PricingDocument         --BK
        , PricingDocumentItem     --BK
        , PricingProcedureStep    --BK
        , PricingProcedureCounter --BK
        , CompanyCode
        , ConditionApplication
        , ConditionTypeCode
        , ConditionAmount
        , IsDeleted
        , LDTS
        , HashDiff
    FROM  #POPricingConditions
    WHERE IsDeleted = 1

    --update deleted
    UPDATE
          dest
    SET
          dest.IsDeleted = src.IsDeleted
        , dest.LDTS = src.LDTS
        , dest.HashDiff = CONVERT([BINARY](16),
                                HASHBYTES('MD5',CONCAT(
                                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), dest.PricingDocument)))),'_',
                                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), dest.PricingDocumentItem)))),'_',
                                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), dest.PricingProcedureStep)))),'_',
                                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), dest.PricingProcedureCounter)))),'_',
                                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), dest.CompanyCode)))),'_',
                                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), dest.ConditionApplication)))),'_',
                                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), dest.ConditionTypeCode)))),'_',
                                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), dest.ConditionAmount)))),'_',
                                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), src.IsDeleted))))))
                            )
    FROM  biz.S4Hana_POPricingConditions AS dest
    JOIN  #DeletedPOPricingConditions    AS src ON src.PricingDocument = dest.PricingDocument
                                                   AND src.PricingDocumentItem = dest.PricingDocumentItem
                                                   AND src.PricingProcedureStep = dest.PricingProcedureStep
                                                   AND src.PricingProcedureCounter = dest.PricingProcedureCounter
    WHERE src.IsDeleted <> dest.IsDeleted
    OPTION (LABEL='biz.S4Hana_spPOPricingConditions: UpdateDeletedStatement')
END