﻿CREATE PROC [biz].[S4Hana_spPOScheduleLines] @LDTS [DATETIME2](7) AS
BEGIN
    SET NOCOUNT ON;
    SET ANSI_WARNINGS ON;

    IF OBJECT_ID(N'tempdb..#POScheduleLines') IS NOT NULL
        DROP TABLE #POScheduleLines;

    CREATE TABLE #POScheduleLines
    WITH
    (
      DISTRIBUTION = HASH(PONo),
      CLUSTERED INDEX ([PONo] ASC, [POItemNo] ASC, [ScheduleLineCount] ASC)
    )
    AS
    SELECT
         PONo              --BK
       , POItemNo          --BK
       , ScheduleLineCount --BK
       , DeliveryDate
       , RoughGoodsReceiptQuantity
       , IsDeleted
       , LDTS
	   , CONVERT([BINARY](16),
                HASHBYTES('MD5',CONCAT(
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PONo)))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), POItemNo)))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ScheduleLineCount)))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), DeliveryDate)))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), RoughGoodsReceiptQuantity)))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), IsDeleted))))))
			) AS HashDiff
    FROM stag.S4Hana_fnPOScheduleLines(@LDTS)
    OPTION (LABEL = 'biz.S4Hana_spPOScheduleLines: DeltaTempTableFromFunctionStatement')

    --update changed
    UPDATE
          dest
    SET
          dest.DeliveryDate = src.DeliveryDate
        , dest.RoughGoodsReceiptQuantity = src.RoughGoodsReceiptQuantity
        , dest.IsDeleted = src.IsDeleted
        , dest.LDTS = src.LDTS
        , dest.HashDiff = src.HashDiff
    FROM  biz.S4Hana_POScheduleLines AS dest
    JOIN  #POScheduleLines           AS src ON src.PONo = dest.PONo AND src.POItemNo = dest.POItemNo
                                               AND src.ScheduleLineCount = dest.ScheduleLineCount
    WHERE src.HashDiff <> dest.HashDiff
    OPTION (LABEL = 'biz.S4Hana_spPOScheduleLines: UpdateStatement')

    --load new
    INSERT INTO biz.S4Hana_POScheduleLines
    (
        PONo              --BK
      , POItemNo          --BK
      , ScheduleLineCount --BK
      , DeliveryDate
      , RoughGoodsReceiptQuantity
      , IsDeleted
      , LDTS
      , HashDiff
    )
    SELECT
              src.PONo              --BK
            , src.POItemNo          --BK
            , src.ScheduleLineCount --BK
            , src.DeliveryDate
            , src.RoughGoodsReceiptQuantity
            , src.IsDeleted
            , src.LDTS
            , src.HashDiff
    FROM      #POScheduleLines           AS src
    LEFT JOIN biz.S4Hana_POScheduleLines AS dest ON src.PONo = dest.PONo AND src.POItemNo = dest.POItemNo
                                                    AND src.ScheduleLineCount = dest.ScheduleLineCount
    WHERE     dest.PONo IS NULL
    OPTION (LABEL = 'biz.S4Hana_spPOScheduleLines: InsertStatement')
END