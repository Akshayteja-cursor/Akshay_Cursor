﻿CREATE PROC [biz].[S4Hana_spSoDocumentItemDeletionAttributes] @LDTS [DATETIME2](7) AS
BEGIN
SET NOCOUNT ON
--DECLARE @LDTS DATETIME2(7) = '2000-01-01'
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(7) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(7)
DECLARE @DestinationLastLoadDate DATETIME2(7)
DECLARE @BatchLdts DATETIME2(7) = @LDTS

-- do not use the input parameter, in case of an failur or reload situartion take the last tranfered LDTS from the Hist table
IF(EXISTS(SELECT 1 FROM biz.S4Hana_SoDocumentItemDeletionAttributes))
BEGIN
	SELECT @DestinationLastLoadDate = MAX(LDTS)
	FROM biz.S4Hana_SoDocumentItemDeletionAttributes
END
ELSE BEGIN
	SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
END 

IF(EXISTS(SELECT 1 FROM stag.S4Hana_SODocumentItems_full))
BEGIN
	SELECT @SourceLastLoadDate = MAX(_LDTS)
	FROM stag.S4Hana_SODocumentItems_full
END
ELSE BEGIN
	SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
END 

--Log Data load
INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'SoDocumentItemValidAttributes'
			,'prepEtlSoDocHistory'
			,'NatSalesOrdersOohHistory'
			,'sales'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts

IF OBJECT_ID('tempdb..#SoDocumentItemDeletionAttributesFullLast') IS NOT NULL
BEGIN
    DROP TABLE #SoDocumentItemDeletionAttributesFullLast
END

CREATE TABLE #SoDocumentItemDeletionAttributesFullLast
WITH
(DISTRIBUTION = HASH(NatSalesOrderNo)
,HEAP)
AS
WITH SoDocItemRank AS (
SELECT SoDocItems.SalesDocument AS NatSalesOrderNo 
	  ,SoDocItems.SalesDocumentItem  AS NatSalesOrderItemNo
	  ,SoDocHeader.SalesDocumentType AS SOTypeCode
	  ,SoDocItems.Material AS MaterialNumber
	  ,SoDocItems.ReferenceSDDocument AS ReferenceSDDocument
	  ,SoDocItems.ReferenceDocumentItemNumber  AS ReferenceDocumentItemNumber
	  ,SoDocItems.PrecedingDocumentCategory AS PrecedingDocumentCategory
	  ,SoDocItems._LDTS AS LDTS 
	  ,ROW_NUMBER() OVER (PARTITION BY SoDocItems.SalesDocument, SoDocItems.SalesDocumentItem ORDER BY SoDocItems._LDTS DESC, SoDocItems.__timestamp DESC) AS rn_PerLdts
	  ,CONVERT(BINARY(16), 
		HASHBYTES('MD5',CONCAT( 
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),SoDocItems.SalesDocument)))),'_', 
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),SoDocItems.SalesDocumentItem)))),'_', 
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),SoDocHeader.SalesDocumentType)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),SoDocItems.Material)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),SoDocItems.ReferenceSDDocument)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),SoDocItems.ReferenceDocumentItemNumber)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),SoDocItems.PrecedingDocumentCategory))))

	  ))) AS HashDiff 
FROM stag.S4Hana_SODocumentItems_full SoDocItems
INNER JOIN [stag].[S4Hana_fnSODocumentsHeader]('19000101') SoDocHeader /*for full load do 1900-01-01, then switch to @LDTS*/
ON SoDocHeader.SalesDocument = SoDocItems.SalesDocument
WHERE SoDocItems._LDTS > @DestinationLastLoadDate
  AND SoDocItems.__operation_type <> 'X'
)
SELECT NatSalesOrderNo,
	   NatSalesOrderItemNo,
	   SOTypeCode,
	   MaterialNumber,
	   ReferenceSDDocument,
	   ReferenceDocumentItemNumber,
	   PrecedingDocumentCategory,
	   LDTS,
	   HashDiff
FROM SoDocItemRank
WHERE rn_PerLdts = 1

OPTION (LABEL='biz.spSoDocumentItemDeletionAttributes : #SoDocumentItemDeletionAttributesFullLast')


BEGIN TRAN -- Make sure Insert and Update are done in the same transaction
-- Update changed objects
Update SoItemDelAtt
	SET SoItemDelAtt.SOTypeCode = new.SOTypeCode
	   ,SoItemDelAtt.MaterialNumber = new.MaterialNumber
	   ,SoItemDelAtt.ReferenceSDDocument = new.ReferenceSDDocument
	   ,SoItemDelAtt.ReferenceDocumentItemNumber = new.ReferenceDocumentItemNumber
	   ,SoItemDelAtt.PrecedingDocumentCategory = new.PrecedingDocumentCategory
	   ,SoItemDelAtt.LDTS = new.LDTS
FROM #SoDocumentItemDeletionAttributesFullLast AS new
INNER JOIN biz.S4Hana_SoDocumentItemDeletionAttributes AS SoItemDelAtt
	ON new.NatSalesOrderNo = SoItemDelAtt.NatSalesOrderNo
	AND new.NatSalesOrderItemNo = SoItemDelAtt.NatSalesOrderItemNo
WHERE new.HashDiff <> SoItemDelAtt.HashDiff

-- Insert new entries to S4Hana_SoDocumentItemsHistPre
INSERT INTO biz.S4Hana_SoDocumentItemDeletionAttributes
	  (NatSalesOrderNo,
	   NatSalesOrderItemNo,
	   SOTypeCode,
	   MaterialNumber,
	   ReferenceSDDocument,
	   ReferenceDocumentItemNumber,
	   PrecedingDocumentCategory,
	   LDTS,
	   HashDiff)
SELECT new.NatSalesOrderNo,
	   new.NatSalesOrderItemNo,
	   new.SOTypeCode,
	   new.MaterialNumber,
	   new.ReferenceSDDocument,
	   new.ReferenceDocumentItemNumber,
	   new.PrecedingDocumentCategory,
	   new.LDTS,
	   new.HashDiff
FROM #SoDocumentItemDeletionAttributesFullLast AS new
LEFT JOIN biz.S4Hana_SoDocumentItemDeletionAttributes AS SoItemDelAtt
	ON new.NatSalesOrderNo = SoItemDelAtt.NatSalesOrderNo
	AND new.NatSalesOrderItemNo = SoItemDelAtt.NatSalesOrderItemNo
WHERE SoItemDelAtt.HashDiff IS NULL

COMMIT TRAN; 

-- Update End of the load
UPDATE DTlogs
SET ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

END -- END SP


--exec [biz].[S4Hana_spSoDocumentItemDeletionAttributes] '1900-01-01'