﻿CREATE PROC [biz].[S4Hana_spBPLegacyPartnerData] @ldts [DATETIME2](7) AS
BEGIN
	SET NOCOUNT ON;
	SET ANSI_WARNINGS ON;

	DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
	DECLARE @ExecStart DATETIME2(7) = GETDATE()
	DECLARE @SourceLastLoadDate DATETIME2(7)
	DECLARE @DestinationLastLoadDate DATETIME2(7)
	DECLARE @BatchLdts DATETIME2(7) = @LDTS
	DECLARE @AffectedRows BIGINT = NULL

	IF(EXISTS(SELECT 1 FROM [biz].[S4Hana_BPLegacyPartnerData]))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(LDTS))
	FROM [biz].[S4Hana_BPLegacyPartnerData]
	END
	ELSE BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

	IF(EXISTS(SELECT 1 FROM stag.[S4Hana_BPLegacyPartnerData]))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(_LDTS))
		FROM stag.[S4Hana_BPLegacyPartnerData]
	END
	ELSE BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END 

	--Log Data load
	INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'S4Hana_spBPLegacyPartnerData'
			,'biz_BPLegacyPartnerData'
			,'S4Hana_BPLegacyPartnerData'
			,'biz'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts


	IF OBJECT_ID(N'tempdb..#bplpd1') IS NOT NULL
	DROP TABLE #bplpd1;

	SELECT
		concat([partner], '|',[LegacyPartnerType], '|',[LegacyPartnerNumber]) AS [LegacyPartnerData_bk]
		,[partner]
		,[LegacyPartnerType]
		,[LegacyPartnerNumber]
		,[ValidityDtFrom]
		,[ValidityDtTo]
		,[IsDeleted]       
		,[_LDTS] as LDTS
		,CONVERT([BINARY](16),
				HASHBYTES('MD5',CONCAT(
	            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[partner]					)))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[LegacyPartnerType] 		)))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[LegacyPartnerNumber] 	)))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ValidityDtFrom] 			)))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ValidityDtTo] 			)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[IsDeleted]))))))       
			) AS HashDiff
	INTO #bplpd1
	FROM stag.S4Hana_vBPLegacyPartnerData
	WHERE [_LDTS] > @ldts
	
		-- count new Records for S4Hana_vBPLegacyPartnerData
		    SELECT @AffectedRows = COUNT(*)
			FROM #bplpd1 AS stg LEFT JOIN biz.S4Hana_BPLegacyPartnerData AS prd 
				ON prd.[LegacyPartnerData_bk] = stg.[LegacyPartnerData_bk] 
			WHERE prd.[LegacyPartnerData_bk] IS NULL

   --load new
   INSERT INTO biz.S4Hana_BPLegacyPartnerData
			(
				[LegacyPartnerData_bk]
				,[partner]
				,[LegacyPartnerType]
				,[LegacyPartnerNumber]
				,[ValidityDtFrom]
				,[ValidityDtTo]
				,[IsDeleted]
				,[LDTS]
				,[HashDiff]
			)
	SELECT  
				 stg.[LegacyPartnerData_bk]
				,stg.[partner]
				,stg.[LegacyPartnerType]
				,stg.[LegacyPartnerNumber]
				,stg.[ValidityDtFrom]
				,stg.[ValidityDtTo]
				,stg.[IsDeleted]
				,stg.[LDTS]
				,stg.[HashDiff]			

		FROM #bplpd1 AS stg LEFT JOIN biz.S4Hana_BPLegacyPartnerData AS prd 
			ON prd.[LegacyPartnerData_bk] = stg.[LegacyPartnerData_bk] 
		WHERE prd.[LegacyPartnerData_bk] IS NULL
	
		UPDATE DTlogs
		SET Inserted = @AffectedRows
		FROM etl.DataTransferLogs DTlogs
		WHERE DataTransferLogId = @DataTransferLogId


		-- count Records to update for S4Hana_BPLegacyPartnerData
		SELECT @AffectedRows = COUNT(*)
		FROM #bplpd1 AS stg LEFT JOIN biz.S4Hana_BPLegacyPartnerData AS prd 
			ON prd.[LegacyPartnerData_bk] = stg.[LegacyPartnerData_bk] 
		WHERE stg.HashDiff <> prd.HashDiff

		UPDATE DTlogs
		SET Updated = @AffectedRows
		, ExecEnd = GETDATE()
		FROM etl.DataTransferLogs DTlogs
		WHERE DataTransferLogId = @DataTransferLogId

		--update non deleted records
		  UPDATE prd SET	
				 prd.[LegacyPartnerData_bk]	= stg.[LegacyPartnerData_bk]
				,prd.[partner]				= stg.[partner]
				,prd.[LegacyPartnerType]	= stg.[LegacyPartnerType]
				,prd.[LegacyPartnerNumber]	= stg.[LegacyPartnerNumber]
				,prd.[ValidityDtFrom]		= stg.[ValidityDtFrom]
				,prd.[ValidityDtTo]			= stg.[ValidityDtTo]
				,prd.[IsDeleted]			= stg.[IsDeleted]
				,prd.[LDTS]					= stg.[LDTS]
				,prd.[HashDiff]				= stg.[HashDiff]		

			FROM #bplpd1 AS stg JOIN biz.S4Hana_BPLegacyPartnerData AS prd 
				ON prd.[LegacyPartnerData_bk] = stg.[LegacyPartnerData_bk] 
			WHERE stg.HashDiff <> prd.HashDiff and stg.IsDeleted = 0

		 --update deletions (only deleted status and LDTS)
		 UPDATE prd SET
				 prd.LDTS				= stg.LDTS
				,prd.IsDeleted			= stg.IsDeleted
				,prd.[HashDiff]			= stg.[HashDiff]
		 	FROM #bplpd1 AS stg JOIN biz.S4Hana_BPLegacyPartnerData AS prd 
				ON prd.[LegacyPartnerData_bk] = stg.[LegacyPartnerData_bk] 
			WHERE stg.HashDiff <> prd.HashDiff and stg.IsDeleted = 1


END

-- truncate table biz.S4Hana_BPLegacyPartnerData
-- exec [biz].[S4Hana_spBPLegacyPartnerData]'1900-01-01'