﻿CREATE PROC [biz].[S4Hana_spSoDocItemPriceConditionDeletions] @LDTS [DATETIME2](7) AS
BEGIN
SET NOCOUNT ON
 
--DECLARE @LDTS DATETIME2(7) = '2000-01-01'

DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(7) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(7)
DECLARE @DestinationLastLoadDate DATETIME2(7)
DECLARE @BatchLdts DATETIME2(7) = @LDTS
DECLARE @AffectedRows BIGINT = NULL

-- do not use the input parameter, in case of an failur or reload situartion take the last tranfered LDTS from the Hist table
IF(EXISTS(SELECT 1 FROM biz.S4Hana_SoDocItemPriceConditionDeletions))
BEGIN
	SELECT @DestinationLastLoadDate =  MAX(LDTS)
	FROM biz.S4Hana_SoDocItemPriceConditionDeletions
END
ELSE BEGIN
	SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
END 

IF(EXISTS(SELECT 1 FROM stag.S4Hana_SOPricingConditions_full))
BEGIN
	SELECT @SourceLastLoadDate = MAX(_LDTS)
	FROM stag.S4Hana_SOPricingConditions_full
END
ELSE BEGIN
	SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
END 

--Log Data load
INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'spSoDocItemPriceConditionDeletions'
			,'prepEtlSoDocHist'
			,'NatSalesOrdersOohHistory'
			,'sales'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts

-- S4Hana_SOPricingConditions_full_Deletion - add deleted entries 
IF OBJECT_ID('tempdb..#SoNewDeletedPriceConditionBKs') IS NOT NULL
BEGIN
    DROP TABLE #SoNewDeletedPriceConditionBKs
END

CREATE TABLE #SoNewDeletedPriceConditionBKs
WITH
(DISTRIBUTION = HASH(seq_nmbr))
AS(SELECT sopStagFull.PricingDocument
		 ,sopStagFull.PricingDocumentItem
		 ,sopStagFull.PricingProcedureStep
		 ,sopStagFull.PricingProcedureCounter
		 ,sopStagFull._LDTS AS LDTS
		 ,ROW_NUMBER() OVER(ORDER BY (SELECT NULL)) AS seq_nmbr
		 ,MAX(sopStagFull.__timestamp) AS __timestamp
	FROM stag.S4Hana_SOPricingConditions_full AS sopStagFull 
	WHERE 1=1
		AND sopStagFull._LDTS > @DestinationLastLoadDate 
		AND (sopStagFull.__operation_type = 'X')
	GROUP BY sopStagFull.PricingDocument
			,sopStagFull.PricingDocumentItem
			,sopStagFull.PricingProcedureStep
			,sopStagFull.PricingProcedureCounter
			,sopStagFull._LDTS
	)Option (LABEL='etl.S4Hana_spSoDocItemPriceConditionDeletions : #SoNewDeletedPriceConditionBKs')

 -- Enrich the deleted entires 
IF OBJECT_ID('tempdb..#SoNewDeletedPriceConditions') IS NOT NULL
BEGIN
    DROP TABLE #SoNewDeletedPriceConditions
END

CREATE TABLE #SoNewDeletedPriceConditions
WITH
(DISTRIBUTION = HASH(NatSalesOrderNo))
AS(SELECT PricingDocument
		 ,PricingDocumentItem
		 ,PricingProcedureStep
		 ,PricingProcedureCounter
		 ,NatSalesOrderNo
		 ,NatSalesOrderItemNo
		 ,ConditionTypeCode
		 ,1 AS IsDeleted
		 ,ROW_NUMBER() OVER (PARTITION BY PricingDocument, PricingDocumentItem, PricingProcedureStep, PricingProcedureCounter, LDTS ORDER BY __timestamp DESC) AS rn_NewDelPerLdts 
		 ,LDTS
		 ,__timestamp
		 FROM (
			SELECT delBk.PricingDocument
				  ,delBk.PricingDocumentItem
				  ,delBk.PricingProcedureStep
				  ,delBk.PricingProcedureCounter
				  ,sodi.SalesDocument AS NatSalesOrderNo -- enrich data 
				  ,sodi.SalesDocumentItem AS NatSalesOrderItemNo -- enrich data
				  ,sopStagFull.ConditionType AS ConditionTypeCode -- enrich data
				  ,delBk.LDTS AS LDTS
				  ,delBk.__timestamp
			FROM stag.S4Hana_SOPricingConditions_full  AS sopStagFull
			INNER JOIN [stag].[S4Hana_fnSODocumentItems] ('19000101') as sodi
				ON sopStagFull.PricingDocument = sodi.SalesDocumentCondition and sopStagFull.PricingDocumentItem = sodi.SalesDocumentItem
			INNER JOIN #SoNewDeletedPriceConditionBKs AS delBk
				ON sopStagFull.PricingDocument = delBk.PricingDocument 
				and sopStagFull.PricingDocumentItem = delBk.PricingDocumentItem 
				and sopStagFull.PricingProcedureStep = delBk.PricingProcedureStep
				and sopStagFull.PricingProcedureCounter = delBk.PricingProcedureCounter
			WHERE 1 = 1
			  AND sopStagFull._LDTS < delBk.LDTS 
			  AND (sopStagFull.__operation_type <> 'X')
		   UNION ALL
		   SELECT sopStagFull.PricingDocument
				 ,sopStagFull.PricingDocumentItem
				 ,sopStagFull.PricingProcedureStep
				 ,sopStagFull.PricingProcedureCounter
				 ,sodi.SalesDocument AS NatSalesOrderNo 
				 ,sodi.SalesDocumentItem AS NatSalesOrderItemNo
				 ,sopStagFull.ConditionType AS ConditionTypeCode
				 ,sopStagFull._LDTS AS LDTS
				 ,MAX(sopStagFull.__timestamp) AS __timestamp
			FROM stag.S4Hana_SOPricingConditions_full AS sopStagFull 
			INNER JOIN [stag].[S4Hana_fnSODocumentItems] ('19000101') as sodi
				ON sopStagFull.PricingDocument = sodi.SalesDocumentCondition and sopStagFull.PricingDocumentItem = sodi.SalesDocumentItem
			WHERE 1=1
				AND sopStagFull._LDTS > @DestinationLastLoadDate 
				AND (sopStagFull.ConditionInactiveReason <> '') -- filter delted and ConditionInactiveReason out 
			GROUP BY sopStagFull.PricingDocument
					,sopStagFull.PricingDocumentItem
					,sopStagFull.PricingProcedureStep
					,sopStagFull.PricingProcedureCounter
					,sodi.SalesDocument 
					,sodi.SalesDocumentItem
					,sopStagFull.ConditionType
					,sopStagFull._LDTS
			) T
	)Option (LABEL='etl.S4Hana_spSoDocItemPriceConditionDeletions : #SoNewDeletedPriceConditions')


-- load all active Delted BK into Memory 
IF OBJECT_ID('tempdb..#SoPriceConditionsDeletionBKs') IS NOT NULL
BEGIN
    DROP TABLE #SoPriceConditionsDeletionBKs
END

CREATE TABLE #SoPriceConditionsDeletionBKs --> get all "active" Delted BK's
WITH
(DISTRIBUTION = HASH(NatSalesOrderNo))
 AS(
  SELECT PricingDocument
		,PricingDocumentItem
		,PricingProcedureStep
		,PricingProcedureCounter
		,NatSalesOrderNo
		,LDTS
		,__timestamp
		FROM ( 
		SELECT PricingDocument
			  ,PricingDocumentItem
			  ,PricingProcedureStep
			  ,PricingProcedureCounter
			  ,NatSalesOrderNo
			  ,LDTS
			  ,__timestamp
		  FROM biz.S4Hana_SoDocItemPriceConditionDeletions
		  WHERE LEDTS = '9999-12-31' 
		  UNION ALL
		  SELECT PricingDocument
			  ,PricingDocumentItem
			  ,PricingProcedureStep
			  ,PricingProcedureCounter
			  ,NatSalesOrderNo
			  ,LDTS
			  ,__timestamp
		  FROM #SoNewDeletedPriceConditions
		  ) T
	) Option (LABEL='etl.S4Hana_spSoDocItemPriceConditionDeletions : #SoPriceConditionsDeletionBKs')

-- Get "reactived" BK's from the last batch(s) --> already deleted BK's which are active again
IF OBJECT_ID('tempdb..#SoReActivatePriceConditions') IS NOT NULL
BEGIN
    DROP TABLE #SoReActivatePriceConditions
END

CREATE TABLE #SoReActivatePriceConditions --> all relevant data for "reactived" BK's
WITH
(DISTRIBUTION = HASH(NatSalesOrderNo))
 AS(SELECT sopStagFull.PricingDocument
		  ,sopStagFull.PricingDocumentItem
		  ,sopStagFull.PricingProcedureStep
		  ,sopStagFull.PricingProcedureCounter
		  ,sodi.SalesDocument AS NatSalesOrderNo
		  ,sodi.SalesDocumentItem AS NatSalesOrderItemNo
		  ,sopStagFull.ConditionType AS ConditionTypeCode
		  ,CONVERT(TINYINT,CASE WHEN sopStagFull.__operation_type = 'X' OR ConditionInactiveReason <> '' THEN 1 ELSE 0 END) AS IsDeleted -- Flag delted and ConditionInactiveReason
		  ,sopStagFull._LDTS AS LDTS
		  ,sopStagFull.__timestamp
	FROM stag.S4Hana_SOPricingConditions_full  AS sopStagFull
	INNER JOIN [stag].[S4Hana_fnSODocumentItems] ('19000101') as sodi
		ON sopStagFull.PricingDocument = sodi.SalesDocumentCondition and sopStagFull.PricingDocumentItem = sodi.SalesDocumentItem
	INNER JOIN #SoPriceConditionsDeletionBKs AS delBk
		ON sopStagFull.PricingDocument = delBk.PricingDocument 
		and sopStagFull.PricingDocumentItem = delBk.PricingDocumentItem 
		and sopStagFull.PricingProcedureStep = delBk.PricingProcedureStep
		and sopStagFull.PricingProcedureCounter = delBk.PricingProcedureCounter
	WHERE sopStagFull._LDTS > delBk.LDTS -- prevent problems at reloads
	)Option (LABEL='etl.S4Hana_spSoDocItemPriceConditionDeletions : #SoReActivatePriceConditions')


-- compine data
IF OBJECT_ID('tempdb..#SoDocPriceConditionDeletionLastIncrement') IS NOT NULL
BEGIN
    DROP TABLE #SoDocPriceConditionDeletionLastIncrement
END
CREATE TABLE #SoDocPriceConditionDeletionLastIncrement
WITH
(DISTRIBUTION = HASH(NatSalesOrderNo)
,HEAP)
AS(SELECT PricingDocument
	     ,PricingDocumentItem
	     ,PricingProcedureStep
	     ,PricingProcedureCounter
	     ,NatSalesOrderNo
	     ,NatSalesOrderItemNo
		 ,ConditionTypeCode
	     ,IsDeleted
	     ,LDTS
		 ,__timestamp
	     ,ROW_NUMBER() OVER (PARTITION BY PricingDocument, PricingDocumentItem, PricingProcedureStep, PricingProcedureCounter, LDTS ORDER BY __timestamp DESC) rn_PerLdts 
	     ,CONVERT(BINARY(16),
 		  		HASHBYTES('MD5', CONCAT(
	  			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),PricingDocument)))), '_',
	  			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),PricingDocumentItem)))), '_',
	  			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),PricingProcedureStep)))), '_',
	  			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),PricingProcedureCounter)))), '_',
	  			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),NatSalesOrderNo)))), '_',
	  			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),NatSalesOrderItemNo)))), '_',
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ConditionTypeCode)))), '_',
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),IsDeleted))))
 		 ))) AS HashDiff
		 ,CONVERT(TINYINT,1) AS SourceIdentifier --> 1 = new from Stag ; 2 = last entry from History table
	FROM (SELECT PricingDocument
				,PricingDocumentItem
				,PricingProcedureStep
				,PricingProcedureCounter
				,NatSalesOrderNo
				,NatSalesOrderItemNo
				,ConditionTypeCode
				,IsDeleted
				,LDTS
				,__timestamp
		 FROM #SoNewDeletedPriceConditions
		 WHERE rn_NewDelPerLdts = 1 -- get only the latest entry
		UNION ALL
		 SELECT PricingDocument
			   ,PricingDocumentItem
			   ,PricingProcedureStep
			   ,PricingProcedureCounter
			   ,NatSalesOrderNo
			   ,NatSalesOrderItemNo
			   ,ConditionTypeCode
			   ,IsDeleted
			   ,LDTS
			   ,__timestamp
			FROM #SoReActivatePriceConditions
			) AS UnionTable
	)Option (LABEL='etl.S4Hana_spSoDocItemPriceConditionDeletions : #SoDocPriceConditionDeletionLastIncrement SourceIdentifier = 1')
	

INSERT INTO #SoDocPriceConditionDeletionLastIncrement
	(PricingDocument
	,PricingDocumentItem
	,PricingProcedureStep
	,PricingProcedureCounter
	,NatSalesOrderNo
	,NatSalesOrderItemNo
	,ConditionTypeCode
	,IsDeleted
	,LDTS
	,__timestamp
	,rn_PerLdts
	,HashDiff
	,SourceIdentifier)
	SELECT CoDel.PricingDocument 
		  ,CoDel.PricingDocumentItem
		  ,CoDel.PricingProcedureStep
		  ,CoDel.PricingProcedureCounter
		  ,CoDel.NatSalesOrderNo
		  ,CoDel.NatSalesOrderItemNo
		  ,CoDel.ConditionTypeCode
		  ,CONVERT(TINYINT,1) AS IsDeleted  -- all entries with LEDTS '9999-12-31' are deleted 
		  ,CoDel.LDTS
		  ,CoDel.__timestamp
		  ,CONVERT(INT,1) AS rn_PerLdts
  		  ,CoDel.HashDiff
		  ,CONVERT(TINYINT,2) AS SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist
FROM #SoDocPriceConditionDeletionLastIncrement AS stagNew
INNER JOIN biz.S4Hana_SoDocItemPriceConditionDeletions AS CoDel
	ON  stagNew.PricingDocument = CoDel.PricingDocument 
	AND stagNew.PricingDocumentItem = CoDel.PricingDocumentItem
	AND stagNew.PricingProcedureStep = CoDel.PricingProcedureStep
	AND stagNew.PricingProcedureCounter = CoDel.PricingProcedureCounter
	AND stagNew.NatSalesOrderNo = CoDel.NatSalesOrderNo
WHERE CoDel.LEDTS = '9999-12-31'
Option (LABEL='etl.S4Hana_spSoDocItemPriceConditionDeletions : #SoDocPriceConditionDeletionLastIncrement SourceIdentifier = 2')

TRUNCATE TABLE etl.S4Hana_SoDocItemPriceConditionDeletions

;WITH preHash AS 
	(SELECT PricingDocument
		   ,PricingDocumentItem
		   ,PricingProcedureStep
		   ,PricingProcedureCounter
		   ,NatSalesOrderNo
		   ,NatSalesOrderItemNo
		   ,ConditionTypeCode
		   ,IsDeleted
		   ,LDTS
		   ,__timestamp
		   ,rn_PerLdts
		   ,HashDiff
		   ,SourceIdentifier
		   ,LAG(HashDiff) OVER (PARTITION BY PricingDocument, PricingDocumentItem, PricingProcedureStep, PricingProcedureCounter ORDER BY LDTS, SourceIdentifier DESC) AS pre_HashDiff
		   ,ROW_NUMBER() OVER (PARTITION BY PricingDocument, PricingDocumentItem, PricingProcedureStep, PricingProcedureCounter ORDER BY LDTS, SourceIdentifier DESC) AS RankOverAll
	FROM #SoDocPriceConditionDeletionLastIncrement
	WHERE rn_PerLdts = 1
	)
, DiffCheck AS (
SELECT PricingDocument
	  ,PricingDocumentItem
	  ,PricingProcedureStep
	  ,PricingProcedureCounter
	  ,NatSalesOrderNo
	  ,NatSalesOrderItemNo
	  ,ConditionTypeCode
	  ,LDTS
	  ,ISNULL((DateAdd(ss ,-1, LEAD(LDTS) OVER (PARTITION BY PricingDocument, PricingDocumentItem, PricingProcedureStep, PricingProcedureCounter ORDER BY LDTS))),'9999-12-31') AS LEDTS
	  ,__timestamp
	  ,HashDiff
	  ,IsDeleted
	  ,SourceIdentifier
FROM preHash
WHERE HashDiff <> pre_HashDiff
	  OR RankOverAll = 1 -- to get the first entry
)
INSERT INTO etl.S4Hana_SoDocItemPriceConditionDeletions
	  ( PricingDocument
       ,PricingDocumentItem
       ,PricingProcedureStep
       ,PricingProcedureCounter
       ,LDTS
       ,LEDTS
	   ,__timestamp
       ,HashDiff
       ,NatSalesOrderNo
       ,NatSalesOrderItemNo
	   ,ConditionTypeCode
	   ,IsDeleted
       ,SourceIdentifier)
SELECT  PricingDocument
       ,PricingDocumentItem
       ,PricingProcedureStep
       ,PricingProcedureCounter
       ,LDTS
       ,LEDTS
	   ,__timestamp
       ,HashDiff
       ,NatSalesOrderNo
       ,NatSalesOrderItemNo
	   ,ConditionTypeCode
	   ,IsDeleted
       ,SourceIdentifier
FROM DiffCheck
WHERE SourceIdentifier = 1 -- only new entiers 
	OR (SourceIdentifier = 2 AND LEDTS <> '9999-12-31') -- existing entries to update LEDTS in the HIST table 
Option (LABEL='etl.S4Hana_spSoDocItemPriceConditionDeletions : S4Hana_SoDocItemPriceConditionDeletionsNew')

-- Insert new entries to S4Hana_SoDocItemPriceConditionDeletions
INSERT INTO biz.S4Hana_SoDocItemPriceConditionDeletions
	  (PricingDocument
      ,PricingDocumentItem
      ,PricingProcedureStep
      ,PricingProcedureCounter
      ,LDTS
      ,LEDTS
	  ,__timestamp
      ,HashDiff
      ,NatSalesOrderNo
      ,NatSalesOrderItemNo
      ,ConditionTypeCode)
SELECT PricingDocument
      ,PricingDocumentItem
      ,PricingProcedureStep
      ,PricingProcedureCounter
      ,LDTS
      ,LEDTS
	  ,__timestamp
      ,HashDiff
      ,NatSalesOrderNo
      ,NatSalesOrderItemNo
      ,ConditionTypeCode
FROM etl.S4Hana_SoDocItemPriceConditionDeletions
WHERE SourceIdentifier = 1 -- only new entiers
AND IsDeleted = 1
Option (LABEL='etl.S4Hana_spSoDocItemPriceConditionDeletions : S4Hana_SoDocItemPriceConditionDeletions  SourceIdentifier = 1')

-- New inserted entries 
SELECT @AffectedRows = COUNT(*)
FROM etl.S4Hana_SoDocItemPriceConditionDeletions
WHERE SourceIdentifier = 1 -- only new entiers 
-- Update Inserted of the load
UPDATE DTlogs
SET Inserted = @AffectedRows
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId
Option (LABEL='etl.S4Hana_spSoDocItemPriceConditionDeletions : DataTransferLogs Inserted')

SET @AffectedRows = NULL 
--Update LEDTS for entires with fresh inserted entries for this BK
UPDATE ConDel
SET ConDel.LEDTS = new.LEDTS
FROM biz.S4Hana_SoDocItemPriceConditionDeletions AS ConDel
INNER JOIN etl.S4Hana_SoDocItemPriceConditionDeletions AS new
	ON 	ConDel.PricingDocument = new.PricingDocument 
	AND ConDel.PricingDocumentItem = new.PricingDocumentItem
	AND ConDel.PricingProcedureStep = new.PricingProcedureStep
	AND ConDel.PricingProcedureCounter = new.PricingProcedureCounter
	AND ConDel.NatSalesOrderNo = new.NatSalesOrderNo
	AND ConDel.LDTS = new.LDTS
WHERE ConDel.LEDTS = '9999-12-31'
  AND new.SourceIdentifier = 2 -- only update Objects loaded from Hist table
Option (LABEL='etl.S4Hana_spSoDocItemPriceConditionDeletions : S4Hana_SoDocItemPriceConditionDeletions  SourceIdentifier = 2')

-- New Updated entries 
SELECT @AffectedRows = COUNT(*)
FROM etl.S4Hana_SoDocItemPriceConditionDeletions
WHERE SourceIdentifier = 2 -- only new entiers 
-- Update Inserted of the load

-- Update End of the load
UPDATE DTlogs
SET ExecEnd = GETDATE(),
	Updated = @AffectedRows
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

END -- END SP
