﻿CREATE PROC [biz].[S4Hana_spAggMaterialStockPricesHistory] AS
BEGIN
	--Script for processing MaterialStockPricesHistory table for first and only time. Delta loads of MaterialStockPricesHistory are not inserted into this table because for the newer changes actual prices table is used.
	DECLARE @LDTS DATETIME2(7), @DataTransferLogId UNIQUEIDENTIFIER=NEWID(), @ExecStart DATETIME2(0)=GETDATE()
	SELECT @LDTS=MIN(SHMSPH._LDTS)
	FROM stag.S4Hana_MaterialStockPricesHistory AS SHMSPH

	IF NOT EXISTS	(SELECT 1 FROM biz.S4Hana_AggMaterialStockPricesHistory AS SHAMSPH) AND @LDTS IS NOT NULL
	BEGIN
		--Logging begining of the process
		INSERT INTO etl.DataTransferLogs (DataTransferLogId,TransferName,TransferGroupName,TargetTableName,TargetSchemaName,ExecStart,SourceLastLoadDate,DestinationLastLoadDate,BatchLdts)
		VALUES (@DataTransferLogId,'S4Hana_spAggMaterialStockPricesHistory','Inventories','S4Hana_AggMaterialStockPricesHistory','biz',@ExecStart,@LDTS,NULL,@LDTS)

		INSERT INTO etl.LdtsProcessingLog (ProcessingDate,ObjectName,ProvidedLdts,ProcessedLdts)
		SELECT DISTINCT @ExecStart, 'biz.S4Hana_spAggMaterialStockPricesHistory', @LDTS, SHAMSPH._LDTS
		FROM biz.S4Hana_AggMaterialStockPricesHistory AS SHAMSPH

		IF OBJECT_ID('tempdb..#Periods') IS NOT NULL DROP TABLE #Periods
		CREATE TABLE #Periods (PriceValidityPeriod INT NOT NULL, Completed BIT NULL)

		INSERT INTO #Periods (PriceValidityPeriod)
		SELECT DISTINCT CONVERT(INT, MSPH.FISCALYEAR)*100+CONVERT(INT, MSPH.PERIOD)
		FROM [stag].[S4Hana_MaterialStockPricesHistory] AS MSPH
		WHERE MSPH._LDTS=@LDTS

		WHILE EXISTS (SELECT 1
						  FROM #Periods AS P
						  WHERE P.Completed IS NULL)
		BEGIN
			DECLARE @PeriodForInsert INT, @StartTime DATETIME=GETDATE(), @PeriodInsertDuration INT

			SELECT TOP(1) @PeriodForInsert=P.PriceValidityPeriod
			FROM #Periods AS P
			WHERE P.Completed IS NULL
			ORDER BY P.PriceValidityPeriod

			--NOT SURE WHY IS THIS UPDATE
			--UPDATE EMSPH SET EMSPH.MOVINGAVERAGEPRICE=MSPH.MOVINGAVERAGEPRICE, EMSPH.STANDARDPRICE=MSPH.STANDARDPRICE, EMSPH.PRICEUNIT=MSPH.PRICEUNIT
			--FROM [etl].[S4Hana_AggMaterialStockPricesHistory] AS EMSPH
			--	JOIN [dbo].[S4Hana_MaterialStockPricesHistory] AS MSPH ON MSPH.MATERIAL = EMSPH.MATERIAL AND MSPH.PLANT = EMSPH.PLANT AND MSPH.FISCALYEAR = EMSPH.FISCALYEAR AND MSPH.PERIOD=EMSPH.FISCALMONTH
			--WHERE MSPH.TS_SEQUENCE_NUMBER IS NULL

			--Updating VALIDTODAT when new period is inserted
			UPDATE EMSPH SET EMSPH.ValidToDat=DATEADD(DAY, -1, DATEFROMPARTS(MSPH.FiscalYear, MSPH.Period, 1))
			FROM [biz].[S4Hana_AggMaterialStockPricesHistory] AS EMSPH
				JOIN stag.S4Hana_fnMaterialStockPricesHistory(@LDTS) AS MSPH ON	MSPH.Material = EMSPH.Material
																										AND MSPH.Plant = EMSPH.Plant
																										AND MSPH.ValuationType = EMSPH.ValuationType
																										AND CONVERT(INT, EMSPH.FiscalYear)*100+CONVERT(INT, EMSPH.FiscalMonth)<>CONVERT(INT, MSPH.FiscalYear)*100+CONVERT(INT, MSPH.Period)
																										AND CONVERT(INT, MSPH.FiscalYear)*100+CONVERT(INT, MSPH.Period)=@PeriodForInsert
																										AND (MSPH.StandardPrice<>EMSPH.StandardPrice OR MSPH.MovingAveragePrice<>EMSPH.MovingAveragePrice)
			WHERE EMSPH.ValidToDat='9999-12-31'

			--Inserting ETL MaterialStockPriceHistory table from price history table
			INSERT INTO biz.S4Hana_AggMaterialStockPricesHistory
				(__timestamp,Material,Plant,ValuationType,
				FiscalYear,FiscalMonth,FiscalDay,
				PriceControlIndicator,MovingAveragePrice,StandardPrice,PriceUnit,PriceCurrency,
				LastChangedAt,
				ValidFromDat,
				ValidToDat,
				CompanyCode,Country,__operation_type,_LDTS,ModifiedOn)
			SELECT	MSPH.__timestamp,MSPH.Material,MSPH.Plant,MSPH.ValuationType,
						MSPH.FiscalYear,MSPH.Period AS FiscalPeriod,'01' AS FiscalDay,
						MSPH.PriceControlIndicator,MSPH.MovingAveragePrice,MSPH.StandardPrice,MSPH.PriceUnit,MSPH.PriceCurrency,
						CONVERT(NUMERIC,MSPH.FiscalYear)*10000000000+CONVERT(NUMERIC,MSPH.Period)*100000000+1000000 AS LastChangedAt,
						CONVERT(DATE, CONCAT(MSPH.FiscalYear, '-', MSPH.Period, '-01')) AS ValidFromDat,
						'9999-12-31' AS ValidToDat,
						MSPH.CompanyCode,MSPH.Country,MSPH.__operation_type,MSPH._LDTS,GETDATE() AS ModifiedOn
			FROM stag.S4Hana_fnMaterialStockPricesHistory(@LDTS) AS MSPH
				LEFT JOIN [biz].[S4Hana_AggMaterialStockPricesHistory] AS EMSPH ON	EMSPH.Material = MSPH.Material
																											AND EMSPH.Plant = MSPH.Plant
																											AND EMSPH.ValuationType = MSPH.ValuationType
																											AND EMSPH.ValidToDat='9999-12-31'
																											AND MSPH.StandardPrice=EMSPH.StandardPrice
																											AND MSPH.MovingAveragePrice=EMSPH.MovingAveragePrice
			WHERE EMSPH.Material IS NULL AND CONVERT(INT, MSPH.FiscalYear)*100+CONVERT(INT, MSPH.Period)=@PeriodForInsert

			UPDATE P SET P.Completed=1
			FROM #Periods AS P
			WHERE P.PriceValidityPeriod=@PeriodForInsert

			--PRINT CONCAT('Period ', CONVERT(VARCHAR(20), @PeriodForInsert), ' is inserted successfully.')
			--PRINT CONCAT('Inserting took ', CONVERT(VARCHAR(20), DATEDIFF(MINUTE, @PeriodInsertDuration, GETDATE())), ' minutes.')
		END
	END
	--Logging end of the process
	UPDATE DTL SET DTL.ExecEnd=GETDATE()
	FROM etl.DataTransferLogs AS DTL
	WHERE DTL.DataTransferLogId=@DataTransferLogId
END