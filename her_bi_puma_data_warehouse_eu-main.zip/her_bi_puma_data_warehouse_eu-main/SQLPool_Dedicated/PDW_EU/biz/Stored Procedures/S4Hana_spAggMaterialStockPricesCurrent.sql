﻿CREATE PROC [biz].[S4Hana_spAggMaterialStockPricesCurrent] AS
BEGIN
	DECLARE @DataTransferLogId UNIQUEIDENTIFIER=NEWID(), @ExecStart DATETIME=GETDATE(), @ExecEnd DATETIME=GETDATE()

	INSERT INTO etl.DataTransferLogs (DataTransferLogId,TransferName,TransferGroupName,TargetTableName,TargetSchemaName,ExecStart)
	VALUES (@DataTransferLogId,'S4Hana_spAggMaterialStockPricesCurrent','LandedCosts','S4Hana_AggMaterialStockPricesCurrent','biz',@ExecStart)

	TRUNCATE TABLE biz.S4Hana_AggMaterialStockPricesCurrent

	INSERT INTO biz.S4Hana_AggMaterialStockPricesCurrent
				(Material,Plant,PriceControlIndicator,MovingAveragePrice,StandardPrice,PriceCurrency)
	SELECT	SHAMSP.Material,SHAMSP.Plant,SHAMSP.PriceControlIndicator,SHAMSP.MovingAveragePrice,SHAMSP.StandardPrice,SHAMSP.PriceCurrency
	FROM biz.S4Hana_AggMaterialStockPrices AS SHAMSP
	WHERE SHAMSP.VALIDTODAT='99991231'

	INSERT INTO biz.S4Hana_AggMaterialStockPricesCurrent
				(Material,Plant,PriceControlIndicator,MovingAveragePrice,StandardPrice,PriceCurrency)
	SELECT SHAMSPH.Material,SHAMSPH.Plant,SHAMSPH.PriceControlIndicator,SHAMSPH.MovingAveragePrice,SHAMSPH.StandardPrice,SHAMSPH.PriceCurrency
	FROM biz.S4Hana_AggMaterialStockPricesHistory AS SHAMSPH
		LEFT JOIN biz.S4Hana_AggMaterialStockPricesCurrent AS SHAMSPC ON SHAMSPC.Material = SHAMSPH.Material AND SHAMSPC.Plant = SHAMSPH.Plant
	WHERE SHAMSPH.ValidToDat='99991231' AND SHAMSPC.Material IS NULL

	SET @ExecEnd=GETDATE()

	UPDATE DTL SET DTL.ExecEnd=@ExecEnd
	FROM etl.DataTransferLogs AS DTL
	WHERE DTL.DataTransferLogId=@DataTransferLogId
END