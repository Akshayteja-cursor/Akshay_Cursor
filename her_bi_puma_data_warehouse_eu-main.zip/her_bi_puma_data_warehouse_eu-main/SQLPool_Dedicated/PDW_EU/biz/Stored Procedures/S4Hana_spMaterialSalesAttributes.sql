﻿CREATE PROC [biz].[S4Hana_spMaterialSalesAttributes] @ldts [DATETIME2](7) AS
BEGIN
	SET NOCOUNT ON;
	SET ANSI_WARNINGS ON;

	DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
	DECLARE @ExecStart DATETIME2(7) = GETDATE()
	DECLARE @SourceLastLoadDate DATETIME2(7)
	DECLARE @DestinationLastLoadDate DATETIME2(7)
	DECLARE @BatchLdts DATETIME2(7) = @LDTS
	DECLARE @AffectedRows BIGINT = NULL

	IF(EXISTS(SELECT 1 FROM [biz].[S4Hana_MaterialSalesAttributes]))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(LDTS))
	FROM [biz].[S4Hana_MaterialSalesAttributes]
	END
	ELSE BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

	IF(EXISTS(SELECT 1 FROM stag.[S4Hana_MaterialSalesAttributes]))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(_LDTS))
		FROM stag.[S4Hana_MaterialSalesAttributes]
	END
	ELSE BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END 


	--Log Data load
	INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'S4Hana_spMaterialSalesAttributes'
			,'biz_MaterialSalesAttributess'
			,'S4Hana_MaterialSalesAttributes'
			,'biz'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts


	IF OBJECT_ID(N'tempdb..#msa') IS NOT NULL
	DROP TABLE #msa;

	SELECT
	   CONCAT([Product], '|', [ProductSalesOrg], '|', [ProductDistributionChnl]) AS MaterialSalesAttributes_BK
	  ,[Product]
      ,[ProductSalesOrg]
      ,[ProductDistributionChnl]
      ,[SupplyingPlant]
      ,[DeliveryQuantityUnit]
      ,[DeliveryQuantity]
      ,[ProductSalesStatus]
      ,[ProductSalesStatusValidityDate]
      ,[IsMarkedForDeletion]
      ,[IsActiveEntity]
      ,[ArticleLaunchDate]
      ,[ArticleLaunchFlag]
      ,[ArticlePricingFlag]
      ,[OutletBFOSeason]
      ,[QuarterInfo]
      ,[Theme]
      ,[FirstAssortment]
      ,[LatestAssortment]
      ,[LocalDC]
      ,[Exclusivity]
      ,[CoreSelection]
      ,[SalesPack]
      ,[Specialist1]
      ,[Specialist2]
      ,[Specialist3]
      ,[Specialist4]
      ,[Specialist5]
      ,[Specialist6]
      ,[Specialist7]
      ,[Specialist8]
      ,[NeveroutofStock]
      ,[ProductStatus]
      ,[ProductLifecycle]
      ,[Embargo]
      ,[ProductFamily]
      ,[ProductSubFamily]
      ,[AssortmentCategory1]
      ,[AssortmentCategory2]
	  ,[KeyInitiative]
	  ,RN_2
	  ,IsDeleted       
      ,[_LDTS] as LDTS
	  ,CONVERT([BINARY](16),
				HASHBYTES('MD5',CONCAT(
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Product]                            )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ProductSalesOrg]					   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ProductDistributionChnl]			   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SupplyingPlant]					   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DeliveryQuantityUnit]			   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DeliveryQuantity]				   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ProductSalesStatus]				   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ProductSalesStatusValidityDate]	   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[IsMarkedForDeletion]				   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[IsActiveEntity]					   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ArticleLaunchDate]				   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ArticleLaunchFlag]				   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ArticlePricingFlag]				   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[OutletBFOSeason]					   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[QuarterInfo]						   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Theme]							   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FirstAssortment]					   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[LatestAssortment]				   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[LocalDC]							   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Exclusivity]						   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CoreSelection]					   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SalesPack]						   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Specialist1]						   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Specialist2]						   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Specialist3]						   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Specialist4]						   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Specialist5]						   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Specialist6]						   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Specialist7]						   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Specialist8]						   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[NeveroutofStock]					   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ProductStatus]					   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ProductLifecycle]				   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Embargo]							   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ProductFamily]					   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ProductSubFamily]				   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[AssortmentCategory1]				   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[AssortmentCategory2]				   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[KeyInitiative]					   )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[IsDeleted]))))))       
			) AS HashDiff

INTO #msa
FROM
(
	SELECT
	   *
	  ,CAST(CASE WHEN __operation_type = 'X' 
					THEN 1 ELSE 0 END AS BIT)					AS IsDeleted
      ,ROW_NUMBER() OVER (PARTITION BY [Product]
									, [ProductSalesOrg]
									, [ProductDistributionChnl]	
									
						ORDER BY _LDTS DESC
								, __timestamp DESC)				AS RN

	, ROW_NUMBER() OVER (PARTITION BY [Product]
								, [ProductSalesOrg]
					 ORDER BY  _LDTS DESC
								, __timestamp DESC)				AS RN_2
	FROM [stag].[S4Hana_MaterialSalesAttributes]

) X
WHERE RN = 1
and [_LDTS] > @ldts
	
		-- count new Records for S4Hana_MaterialSalesAttributes
		    SELECT @AffectedRows = COUNT(*)
			FROM #msa AS stg LEFT JOIN biz.S4Hana_MaterialSalesAttributes AS prd 
			ON prd.MaterialSalesAttributes_BK = stg.MaterialSalesAttributes_BK 
			WHERE prd.MaterialSalesAttributes_BK IS NULL

   --load new
   INSERT INTO biz.S4Hana_MaterialSalesAttributes
			(
			     MaterialSalesAttributes_BK
				,[Product]
                ,[ProductSalesOrg]
                ,[ProductDistributionChnl]
                ,[SupplyingPlant]
                ,[DeliveryQuantityUnit]
                ,[DeliveryQuantity]
                ,[ProductSalesStatus]
                ,[ProductSalesStatusValidityDate]
                ,[IsMarkedForDeletion]
                ,[IsActiveEntity]
                ,[ArticleLaunchDate]
                ,[ArticleLaunchFlag]
                ,[ArticlePricingFlag]
                ,[OutletBFOSeason]
                ,[QuarterInfo]
                ,[Theme]
                ,[FirstAssortment]
                ,[LatestAssortment]
                ,[LocalDC]
                ,[Exclusivity]
                ,[CoreSelection]
                ,[SalesPack]
                ,[Specialist1]
                ,[Specialist2]
                ,[Specialist3]
                ,[Specialist4]
                ,[Specialist5]
                ,[Specialist6]
                ,[Specialist7]
                ,[Specialist8]
                ,[NeveroutofStock]
                ,[ProductStatus]
                ,[ProductLifecycle]
                ,[Embargo]
                ,[ProductFamily]
                ,[ProductSubFamily]
                ,[AssortmentCategory1]
                ,[AssortmentCategory2]
				,[KeyInitiative]
	            ,RN_2
	            ,IsDeleted       
                ,LDTS
				,[HashDiff]			
			)
	SELECT 
				 stg.MaterialSalesAttributes_BK
				,stg.[Product]
                ,stg.[ProductSalesOrg]
                ,stg.[ProductDistributionChnl]
                ,stg.[SupplyingPlant]
                ,stg.[DeliveryQuantityUnit]
                ,stg.[DeliveryQuantity]
                ,stg.[ProductSalesStatus]
                ,stg.[ProductSalesStatusValidityDate]
                ,stg.[IsMarkedForDeletion]
                ,stg.[IsActiveEntity]
                ,stg.[ArticleLaunchDate]
                ,stg.[ArticleLaunchFlag]
                ,stg.[ArticlePricingFlag]
                ,stg.[OutletBFOSeason]
                ,stg.[QuarterInfo]
                ,stg.[Theme]
                ,stg.[FirstAssortment]
                ,stg.[LatestAssortment]
                ,stg.[LocalDC]
                ,stg.[Exclusivity]
                ,stg.[CoreSelection]
                ,stg.[SalesPack]
                ,stg.[Specialist1]
                ,stg.[Specialist2]
                ,stg.[Specialist3]
                ,stg.[Specialist4]
                ,stg.[Specialist5]
                ,stg.[Specialist6]
                ,stg.[Specialist7]
                ,stg.[Specialist8]
                ,stg.[NeveroutofStock]
                ,stg.[ProductStatus]
                ,stg.[ProductLifecycle]
                ,stg.[Embargo]
                ,stg.[ProductFamily]
                ,stg.[ProductSubFamily]
                ,stg.[AssortmentCategory1]
                ,stg.[AssortmentCategory2]
				,stg.[KeyInitiative]
	            ,stg.RN_2
	            ,stg.IsDeleted       
                ,stg.LDTS
				,stg.[HashDiff]					


		 FROM #msa AS stg LEFT JOIN biz.S4Hana_MaterialSalesAttributes AS prd 
		 ON prd.MaterialSalesAttributes_BK = stg.MaterialSalesAttributes_BK 
		 WHERE prd.MaterialSalesAttributes_BK IS NULL
	
		UPDATE DTlogs
		SET Inserted = @AffectedRows
		FROM etl.DataTransferLogs DTlogs
		WHERE DataTransferLogId = @DataTransferLogId


		-- count new Records for S4Hana_MaterialSalesAttributes
		SELECT @AffectedRows = COUNT(*)
		FROM #msa AS stg JOIN biz.S4Hana_MaterialSalesAttributes AS prd 
		ON prd.MaterialSalesAttributes_BK = stg.MaterialSalesAttributes_BK
		WHERE stg.HashDiff <> prd.HashDiff

		UPDATE DTlogs
		SET Updated = @AffectedRows
		, ExecEnd = GETDATE()
		FROM etl.DataTransferLogs DTlogs
		WHERE DataTransferLogId = @DataTransferLogId

		--update non deleted records
		  UPDATE prd SET	
				     
				 prd.[Product]							= stg.[Product]							
                ,prd.[ProductSalesOrg]					= stg.[ProductSalesOrg]					
                ,prd.[ProductDistributionChnl]			= stg.[ProductDistributionChnl]
                ,prd.[SupplyingPlant]					= stg.[SupplyingPlant]
                ,prd.[DeliveryQuantityUnit]				= stg.[DeliveryQuantityUnit]				
                ,prd.[DeliveryQuantity]					= stg.[DeliveryQuantity]					
                ,prd.[ProductSalesStatus]				= stg.[ProductSalesStatus]				
                ,prd.[ProductSalesStatusValidityDate]	= stg.[ProductSalesStatusValidityDate]
                ,prd.[IsMarkedForDeletion]				= stg.[IsMarkedForDeletion]
                ,prd.[IsActiveEntity]					= stg.[IsActiveEntity]
                ,prd.[ArticleLaunchDate]				= stg.[ArticleLaunchDate]				
                ,prd.[ArticleLaunchFlag]				= stg.[ArticleLaunchFlag]				
                ,prd.[ArticlePricingFlag]				= stg.[ArticlePricingFlag]				
                ,prd.[OutletBFOSeason]					= stg.[OutletBFOSeason]					
                ,prd.[QuarterInfo]						= stg.[QuarterInfo]						
                ,prd.[Theme]							= stg.[Theme]							
                ,prd.[FirstAssortment]					= stg.[FirstAssortment]					
                ,prd.[LatestAssortment]					= stg.[LatestAssortment]					
                ,prd.[LocalDC]							= stg.[LocalDC]							
                ,prd.[Exclusivity]						= stg.[Exclusivity]						
                ,prd.[CoreSelection]					= stg.[CoreSelection]					
                ,prd.[SalesPack]						= stg.[SalesPack]
                ,prd.[Specialist1]						= stg.[Specialist1]						
                ,prd.[Specialist2]						= stg.[Specialist2]						
                ,prd.[Specialist3]						= stg.[Specialist3]						
                ,prd.[Specialist4]						= stg.[Specialist4]						
                ,prd.[Specialist5]						= stg.[Specialist5]						
                ,prd.[Specialist6]						= stg.[Specialist6]						
                ,prd.[Specialist7]						= stg.[Specialist7]						
                ,prd.[Specialist8]						= stg.[Specialist8]						
                ,prd.[NeveroutofStock]					= stg.[NeveroutofStock]					
                ,prd.[ProductStatus]					= stg.[ProductStatus]					
                ,prd.[ProductLifecycle]					= stg.[ProductLifecycle]					
                ,prd.[Embargo]							= stg.[Embargo]							
                ,prd.[ProductFamily]					= stg.[ProductFamily]					
                ,prd.[ProductSubFamily]					= stg.[ProductSubFamily]					
                ,prd.[AssortmentCategory1]				= stg.[AssortmentCategory1]				
                ,prd.[AssortmentCategory2]				= stg.[AssortmentCategory2]				
                ,prd.[KeyInitiative]					= stg.[KeyInitiative]
	            ,prd.RN_2								= stg.RN_2								
	            ,prd.IsDeleted       					= stg.IsDeleted       					
                ,prd.LDTS								= stg.LDTS								
				,prd.[HashDiff]							= stg.[HashDiff]							


			FROM #msa AS stg JOIN biz.S4Hana_MaterialSalesAttributes AS prd 
			ON prd.MaterialSalesAttributes_BK = stg.MaterialSalesAttributes_BK
			WHERE stg.HashDiff <> prd.HashDiff and stg.IsDeleted = 0

		 --update deletions (only deleted status and LDTS)
		 UPDATE prd SET
				 prd.LDTS				= stg.LDTS
				,prd.IsDeleted			= stg.IsDeleted
				,prd.[HashDiff]			= stg.[HashDiff]

		 	FROM #msa AS stg JOIN biz.S4Hana_MaterialSalesAttributes AS prd 
			ON prd.MaterialSalesAttributes_BK = stg.MaterialSalesAttributes_BK
			WHERE stg.HashDiff <> prd.HashDiff and stg.IsDeleted = 1


END

--truncate table biz.S4Hana_MaterialSalesAttributes
-- exec [biz].[S4Hana_spMaterialSalesAttributes]'1900-01-01'