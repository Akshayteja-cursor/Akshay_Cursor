﻿CREATE PROC [biz].[S4Hana_spSODocumentItemsHistory] @LDTS [DATETIME2](7) AS
BEGIN
SET NOCOUNT ON
--DECLARE @LDTS DATETIME2(7) = '2000-01-01'
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(7) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(7)
DECLARE @DestinationLastLoadDate DATETIME2(7)
DECLARE @BatchLdts DATETIME2(7) = @LDTS

-- do not use the input parameter, in case of an failur or reload situartion take the last tranfered LDTS from the Hist table
IF(EXISTS(SELECT 1 FROM biz.S4Hana_SoDocumentItemsHistory))
BEGIN
	SELECT @DestinationLastLoadDate = MAX(LDTS)
	FROM biz.S4Hana_SoDocumentItemsHistory
END
ELSE BEGIN
	SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
END 

IF(EXISTS(SELECT 1 FROM stag.S4Hana_SODocumentItems_full))
BEGIN
	SELECT @SourceLastLoadDate = MAX(_LDTS)
	FROM stag.S4Hana_SODocumentItems_full
END
ELSE BEGIN
	SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
END 

--Log Data load
INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'spSODocumentItemsHistory'
			,'prepSoDocHistory'
			,'NatSalesOrdersOohHistory'
			,'sales'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts


IF OBJECT_ID('tempdb..#SoDocumentItemsFullLast') IS NOT NULL
BEGIN
    DROP TABLE #SoDocumentItemsFullLast
END

CREATE TABLE #SoDocumentItemsFullLast
WITH
(DISTRIBUTION = HASH(NatSalesOrderNo)
,HEAP)
AS
WITH CteStagSoDocItem AS (
SELECT stagSoDocItemFull.SalesDocument AS NatSalesOrderNo 
	  ,stagSoDocItemFull.SalesDocumentItem  AS NatSalesOrderItemNo
	  ,stagSoDocItemFull.BillingCompanyCode AS CompanyCode
	  ,stagSoDocItemFull.SalesOrganization AS SalesOrganization
	  ,stagSoDocItemFull.SoldToParty AS CustomerCode_SoldTo
	  ,stagSoDocItemFull.TransactionCurrency AS CurrencyCode
	  ,stagSoDocHeader.DistributionChannel AS DistributionChannelCode
	  ,stagSoDocHeader.SalesDocumentType AS SOTypeCode
	  ,stagSoDocItemFull.Material AS MaterialNumber	  
	  ,CONVERT(DECIMAL(15, 3),stagSoDocItemFull.OrderQuantity) AS OrderQuantity
	  ,CONVERT(DECIMAL(15, 2),stagSoDocItemFull.NetAmount) AS NetAmount
	  ,CONVERT(DECIMAL(38,25), 
			CONVERT(DECIMAL(15,2),stagSoDocItemFull.NetAmount) / 
				(CASE WHEN stagSoDocItemFull.OrderQuantity <> 0 THEN CONVERT(DECIMAL(15, 3),stagSoDocItemFull.OrderQuantity)
																ELSE 1 END ))
	   AS NetAmountUnit
	  ,stagSoDocItemFull.SalesDocumentRjcnReason AS RejectionReason
	  ,stagSoDocItemFull.ReferenceSDDocument AS ReferenceDocumentNumber
	  ,stagSoDocItemFull.ReferenceDocumentItemNumber AS ReferenceDocumentItemNumber
	  ,PrecedingDocumentCategory AS PrecedingDocumentCategory
	  ,CONVERT(DECIMAL(15, 2),stagSoDocItemFull.Subtotal1Amount) AS GrossSalesValue
	  ,CONVERT(DECIMAL(38,25), 
			CONVERT(DECIMAL(15,2),stagSoDocItemFull.Subtotal1Amount) / 
				(CASE WHEN stagSoDocItemFull.OrderQuantity <> 0 THEN CONVERT(DECIMAL(15, 3),stagSoDocItemFull.OrderQuantity)
																ELSE 1 END ))
	   AS GrossSalesValueUnit
	  ,CONCAT(stagSoDocItemFull.ProductSeasonyear, stagSoDocItemFull.ProductSeason)	AS SalesSeason
	  ,stagSoDocItemFull.LatestCDD as LatestCDD
	  ,stagSoDocItemFull.LatestRDD as LatestRDD
	  ,stagSoDocItemFull.[OriginalRequestedDeliveryDate]
	  ,stagSoDocItemFull.[FirstConfirmedDeliveryDate]
	  ,stagSoDocItemFull.[SalesDocumentItemCategory]
	  ,CONVERT(TINYINT,CASE WHEN stagSoDocItemFull.__operation_type = 'X' THEN 1 
							WHEN stagSoDocItemFull.SalesDocumentItemCategory = 'ZTAG' THEN 1
							ELSE 0 END) AS IsDeleted
	  ,stagSoDocItemFull._LDTS AS LDTS 
	  ,ROW_NUMBER() OVER (PARTITION BY stagSoDocItemFull.SalesDocument, stagSoDocItemFull.SalesDocumentItem, stagSoDocItemFull._LDTS ORDER BY stagSoDocItemFull.__timestamp DESC) AS rn_PerLdts
FROM stag.S4Hana_SODocumentItems_full AS stagSoDocItemFull
INNER JOIN [stag].[S4Hana_fnSODocumentsHeader]('19000101') stagSoDocHeader on stagSoDocItemFull.SalesDocument=stagSoDocHeader.SalesDocument
WHERE stagSoDocItemFull._LDTS > @DestinationLastLoadDate
)
SELECT CteStagSoDocItem.NatSalesOrderNo 
	  ,CteStagSoDocItem.NatSalesOrderItemNo
	  ,CteStagSoDocItem.CompanyCode
	  ,CteStagSoDocItem.SalesOrganization
	  ,CteStagSoDocItem.CustomerCode_SoldTo
	  ,CteStagSoDocItem.CurrencyCode
	  ,CteStagSoDocItem.DistributionChannelCode
	  ,CASE WHEN CteStagSoDocItem.IsDeleted = 1 THEN bizDocDel.SOTypeCode ELSE CteStagSoDocItem.SOTypeCode END AS SOTypeCode
	  ,CASE WHEN CteStagSoDocItem.IsDeleted = 1 THEN bizDocDel.MaterialNumber ELSE CteStagSoDocItem.MaterialNumber END AS MaterialNumber
	  ,CteStagSoDocItem.OrderQuantity
	  ,CteStagSoDocItem.NetAmount
	  ,CteStagSoDocItem.NetAmountUnit
	  ,CteStagSoDocItem.RejectionReason
	  ,CASE WHEN CteStagSoDocItem.IsDeleted = 1 THEN bizDocDel.ReferenceSDDocument ELSE CteStagSoDocItem.ReferenceDocumentNumber END AS ReferenceDocumentNumber
	  ,CASE WHEN CteStagSoDocItem.IsDeleted = 1 THEN bizDocDel.ReferenceDocumentItemNumber ELSE CteStagSoDocItem.ReferenceDocumentItemNumber END AS ReferenceDocumentItemNumber	  
	  ,CASE WHEN CteStagSoDocItem.IsDeleted = 1 THEN bizDocDel.PrecedingDocumentCategory ELSE CteStagSoDocItem.PrecedingDocumentCategory END AS PrecedingDocumentCategory
	  ,CteStagSoDocItem.GrossSalesValue
	  ,CteStagSoDocItem.GrossSalesValueUnit
	  ,CteStagSoDocItem.SalesSeason
	  ,CteStagSoDocItem.LatestCDD
	  ,CteStagSoDocItem.LatestRDD
	  ,CteStagSoDocItem.[OriginalRequestedDeliveryDate]
	  ,CteStagSoDocItem.[FirstConfirmedDeliveryDate]
	  ,CteStagSoDocItem.[SalesDocumentItemCategory]
	  ,CteStagSoDocItem.IsDeleted
	  ,CteStagSoDocItem.LDTS
	  ,CteStagSoDocItem.rn_PerLdts
	  ,CONVERT(BINARY(16), 
		HASHBYTES('MD5',CONCAT( 
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),CteStagSoDocItem.NatSalesOrderNo)))),'_', 
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),CteStagSoDocItem.NatSalesOrderItemNo)))),'_', 
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),CteStagSoDocItem.CompanyCode)))),'_', 
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),CteStagSoDocItem.SalesOrganization)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),CteStagSoDocItem.CustomerCode_SoldTo)))),'_', 
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),CteStagSoDocItem.CurrencyCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),CteStagSoDocItem.DistributionChannelCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),CASE WHEN CteStagSoDocItem.IsDeleted = 1 THEN bizDocDel.SOTypeCode ELSE CteStagSoDocItem.SOTypeCode END)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),CASE WHEN CteStagSoDocItem.IsDeleted = 1 THEN bizDocDel.MaterialNumber ELSE CteStagSoDocItem.MaterialNumber END)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),CteStagSoDocItem.OrderQuantity)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),CteStagSoDocItem.NetAmount)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),CteStagSoDocItem.NetAmountUnit)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),CteStagSoDocItem.RejectionReason)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),CASE WHEN CteStagSoDocItem.IsDeleted = 1 THEN bizDocDel.ReferenceSDDocument ELSE CteStagSoDocItem.ReferenceDocumentNumber END)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),CASE WHEN CteStagSoDocItem.IsDeleted = 1 THEN bizDocDel.ReferenceDocumentItemNumber ELSE CteStagSoDocItem.ReferenceDocumentItemNumber END)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),CASE WHEN CteStagSoDocItem.IsDeleted = 1 THEN bizDocDel.PrecedingDocumentCategory ELSE CteStagSoDocItem.PrecedingDocumentCategory END)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),CteStagSoDocItem.GrossSalesValue)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),CteStagSoDocItem.SalesSeason)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),CteStagSoDocItem.LatestCDD)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),CteStagSoDocItem.LatestRDD)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),CteStagSoDocItem.[OriginalRequestedDeliveryDate])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),CteStagSoDocItem.[FirstConfirmedDeliveryDate])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),CteStagSoDocItem.[SalesDocumentItemCategory])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),IsDeleted))))
	  ))) AS HashDiff 
	  ,CONVERT(TINYINT,1) AS SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist
FROM CteStagSoDocItem
INNER JOIN biz.S4Hana_SoDocumentItemDeletionAttributes AS bizDocDel
	ON CteStagSoDocItem.NatSalesOrderNo = bizDocDel.NatSalesOrderNo
	AND CteStagSoDocItem.NatSalesOrderItemNo = bizDocDel.NatSalesOrderItemNo
WHERE CteStagSoDocItem.rn_PerLdts = 1

OPTION (LABEL='etl.S4Hana_spSODocumentItemsHistory : #SoDocumentItemsFullLast ScoId1')

-- Add last entires from Hist which are in the new batch
INSERT INTO #SoDocumentItemsFullLast
	(NatSalesOrderNo
    ,NatSalesOrderItemNo
    ,CompanyCode
	,SalesOrganization
    ,CustomerCode_SoldTo
    ,CurrencyCode
    ,DistributionChannelCode
    ,SOTypeCode
    ,MaterialNumber
    ,OrderQuantity
    ,NetAmount
	,NetAmountUnit
    ,RejectionReason
    ,ReferenceDocumentNumber
    ,ReferenceDocumentItemNumber
    ,PrecedingDocumentCategory
	,GrossSalesValue
	,GrossSalesValueUnit
	,LatestCDD
	,LatestRDD
	,[OriginalRequestedDeliveryDate]
	,[FirstConfirmedDeliveryDate]
	,SalesSeason
	,SalesDocumentItemCategory
    ,IsDeleted
    ,LDTS
    ,rn_PerLdts
    ,HashDiff
    ,SourceIdentifier)
SELECT 
     SoItemHist.NatSalesOrderNo
    ,SoItemHist.NatSalesOrderItemNo
    ,SoItemHist.CompanyCode
	,SoItemHist.SalesOrganization
    ,SoItemHist.CustomerCode_SoldTo
    ,SoItemHist.CurrencyCode
    ,SoItemHist.DistributionChannelCode
    ,SoItemHist.SOTypeCode
    ,SoItemHist.MaterialNumber
    ,SoItemHist.OrderQuantity
    ,SoItemHist.NetAmount
	,SoItemHist.NetAmountUnit
    ,SoItemHist.RejectionReason
    ,SoItemHist.ReferenceDocumentNumber
    ,SoItemHist.ReferenceDocumentItemNumber
    ,SoItemHist.PrecedingDocumentCategory
	,SoItemHist.GrossSalesValue
	,SoItemHist.GrossSalesValueUnit
	,SoItemHist.LatestCDD
	,SoItemHist.LatestRDD
	,SoItemHist.[OriginalRequestedDeliveryDate]
	,SoItemHist.[FirstConfirmedDeliveryDate]
	,ISNULL(SoItemHist.SalesSeason,'190011')
	,SoItemHist.SalesDocumentItemCategory
    ,SoItemHist.IsDeleted
	,SoItemHist.LDTS
	,CONVERT(INT,1) AS rn_PerLdts
	,SoItemHist.HashDiff
	,CONVERT(TINYINT,2) AS SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist
	FROM #SoDocumentItemsFullLast AS stagNew
	INNER JOIN biz.S4Hana_SoDocumentItemsHistory AS SoItemHist
		ON stagNew.NatSalesOrderNo = SoItemHist.NatSalesOrderNo
		AND stagNew.NatSalesOrderItemNo = SoItemHist.NatSalesOrderItemNo
		AND SoItemHist.LEDTS = '9999-12-31' ---> Get latest entrie from the hist table 
OPTION (LABEL='etl.S4Hana_spSODocumentItemsHistory : #SoDocumentItemsFullLast ScoId2')

TRUNCATE TABLE etl.S4Hana_SoDocumentItemsHistory

;WITH preHash AS (
	 SELECT NatSalesOrderNo
		   ,NatSalesOrderItemNo
		   ,LDTS
		   ,HashDiff
		   ,CompanyCode
		   ,SalesOrganization
		   ,CustomerCode_SoldTo
		   ,CurrencyCode
		   ,DistributionChannelCode
		   ,SOTypeCode
		   ,MaterialNumber
		   ,OrderQuantity
		   ,NetAmount
		   ,NetAmountUnit
		   ,RejectionReason
		   ,ReferenceDocumentNumber
		   ,ReferenceDocumentItemNumber
		   ,PrecedingDocumentCategory
		   ,GrossSalesValue
		   ,GrossSalesValueUnit
		   ,LatestCDD
		   ,LatestRDD
	       ,[OriginalRequestedDeliveryDate]
	       ,[FirstConfirmedDeliveryDate]
		   ,SalesSeason
		   ,SalesDocumentItemCategory
		   ,IsDeleted
		   ,SourceIdentifier
		   ,LAG(HashDiff) OVER (PARTITION BY NatSalesOrderNo, NatSalesOrderItemNo ORDER BY LDTS, SourceIdentifier DESC) AS pre_HashDiff -- Add SourceIdentifier rank to take first the existing Data in case there are the same content in the source
		   ,ROW_NUMBER() OVER (PARTITION BY NatSalesOrderNo, NatSalesOrderItemNo ORDER BY LDTS, SourceIdentifier DESC) AS RankOverAll
	FROM #SoDocumentItemsFullLast
	WHERE rn_PerLdts = 1
)
,DiffCheck AS (
	SELECT NatSalesOrderNo
		  ,NatSalesOrderItemNo
		  ,LDTS
		  ,ISNULL((DateAdd(ss ,-1, LEAD(LDTS) OVER (PARTITION BY NatSalesOrderNo, NatSalesOrderItemNo ORDER BY LDTS))),'9999-12-31') AS LEDTS
		  ,HashDiff
		  ,CompanyCode
		  ,SalesOrganization
		  ,CustomerCode_SoldTo
		  ,CurrencyCode
		  ,DistributionChannelCode
		  ,SOTypeCode
		  ,MaterialNumber
		  ,OrderQuantity
		  ,NetAmount
		  ,NetAmountUnit
		  ,RejectionReason
		  ,ReferenceDocumentNumber
		  ,ReferenceDocumentItemNumber
		  ,PrecedingDocumentCategory
		  ,GrossSalesValue
		  ,GrossSalesValueUnit
		  ,LatestCDD
	      ,LatestRDD
		  ,[OriginalRequestedDeliveryDate]
	      ,[FirstConfirmedDeliveryDate]
		  ,SalesSeason
		  ,SalesDocumentItemCategory
		  ,IsDeleted
		  ,SourceIdentifier
	FROM preHash
	WHERE HashDiff <> pre_HashDiff
	   OR RankOverAll = 1 -- to get the first entry
)
INSERT INTO etl.S4Hana_SoDocumentItemsHistory
	  (NatSalesOrderNo
	  ,NatSalesOrderItemNo
	  ,LDTS
	  ,LEDTS
	  ,HashDiff
	  ,CompanyCode
	  ,SalesOrganization
	  ,CustomerCode_SoldTo
	  ,CurrencyCode
	  ,DistributionChannelCode
	  ,SOTypeCode
	  ,MaterialNumber
	  ,OrderQuantity
	  ,NetAmount
	  ,NetAmountUnit
	  ,RejectionReason
	  ,ReferenceDocumentNumber
	  ,ReferenceDocumentItemNumber
	  ,PrecedingDocumentCategory
	  ,GrossSalesValue
	  ,GrossSalesValueUnit
	  ,LatestCDD
	  ,LatestRDD
	  ,[OriginalRequestedDeliveryDate]
	  ,[FirstConfirmedDeliveryDate]
	  ,SalesSeason
	  ,SalesDocumentItemCategory
	  ,IsDeleted
	  ,SourceIdentifier)
SELECT NatSalesOrderNo
	  ,NatSalesOrderItemNo
	  ,LDTS
	  ,LEDTS
	  ,HashDiff
	  ,CompanyCode
	  ,SalesOrganization
	  ,CustomerCode_SoldTo
	  ,CurrencyCode
	  ,DistributionChannelCode
	  ,SOTypeCode
	  ,MaterialNumber
	  ,OrderQuantity
	  ,NetAmount
	  ,NetAmountUnit
	  ,RejectionReason
	  ,ReferenceDocumentNumber
	  ,ReferenceDocumentItemNumber
	  ,PrecedingDocumentCategory
	  ,GrossSalesValue
	  ,GrossSalesValueUnit
	  ,LatestCDD
   	  ,LatestRDD
	  ,[OriginalRequestedDeliveryDate]
	  ,[FirstConfirmedDeliveryDate]
	  ,SalesSeason
	  ,SalesDocumentItemCategory
	  ,IsDeleted
	  ,SourceIdentifier
FROM DiffCheck
WHERE SourceIdentifier = 1 -- only new entiers 
	OR (SourceIdentifier = 2 AND LEDTS <> '9999-12-31') -- existing entries to update LEDTS in the HIST table 
OPTION (LABEL='etl.S4Hana_spSODocumentItemsHistory : S4Hana_SoDocumentItemsHistoryNew')

BEGIN TRAN -- Make sure Insert and Update are done in the same transaction
-- Insert new entries to S4Hana_SoDocumentItemsHistPre
	INSERT INTO biz.S4Hana_SoDocumentItemsHistory
		  (NatSalesOrderNo
		  ,NatSalesOrderItemNo
		  ,LDTS
		  ,LEDTS
		  ,HashDiff
		  ,CompanyCode
		  ,SalesOrganization
		  ,CustomerCode_SoldTo
		  ,CurrencyCode
		  ,DistributionChannelCode
		  ,SOTypeCode
		  ,MaterialNumber
		  ,OrderQuantity
		  ,NetAmount
		  ,NetAmountUnit
		  ,RejectionReason
		  ,ReferenceDocumentNumber
		  ,ReferenceDocumentItemNumber
		  ,PrecedingDocumentCategory
		  ,GrossSalesValue
		  ,GrossSalesValueUnit
	      ,LatestCDD
   	      ,LatestRDD
		  ,[OriginalRequestedDeliveryDate]
     	  ,[FirstConfirmedDeliveryDate]
		  ,SalesSeason
		  ,SalesDocumentItemCategory
		  ,IsDeleted)
	SELECT NatSalesOrderNo
		  ,NatSalesOrderItemNo
		  ,LDTS
		  ,LEDTS
		  ,HashDiff
		  ,CompanyCode
		  ,SalesOrganization
		  ,CustomerCode_SoldTo
		  ,CurrencyCode
		  ,DistributionChannelCode
		  ,SOTypeCode
		  ,MaterialNumber
		  ,OrderQuantity
		  ,NetAmount
		  ,NetAmountUnit
		  ,RejectionReason
		  ,ReferenceDocumentNumber
		  ,ReferenceDocumentItemNumber
		  ,PrecedingDocumentCategory
		  ,GrossSalesValue
		  ,GrossSalesValueUnit
	      ,LatestCDD
   	      ,LatestRDD
		  ,[OriginalRequestedDeliveryDate]
	      ,[FirstConfirmedDeliveryDate]
		  ,SalesSeason
		  ,SalesDocumentItemCategory
		  ,IsDeleted
	FROM etl.S4Hana_SoDocumentItemsHistory
	WHERE SourceIdentifier = 1 -- only new entiers 

	--Update LEDTS for entires with fresh inserted entries for this BK
	UPDATE histPre
	SET histPre.LEDTS = new.LEDTS
	FROM biz.S4Hana_SoDocumentItemsHistory AS histPre
	INNER JOIN etl.S4Hana_SoDocumentItemsHistory AS new
		ON histPre.NatSalesOrderNo = new.NatSalesOrderNo  -- join over NatSalesOrderNo and not HashDiff because the distribution of the tables via NatSalesOrderNo order by LDTS
		AND histPre.NatSalesOrderItemNo = new.NatSalesOrderItemNo
		AND histPre.LDTS = new.LDTS
	WHERE histPre.LEDTS = '9999-12-31'
	  AND new.SourceIdentifier = 2 -- only update Objects loaded from Hist table
COMMIT TRAN; 

-- Update End of the load
UPDATE DTlogs
SET ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

END -- END SP
