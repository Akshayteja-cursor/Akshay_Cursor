﻿CREATE PROC [biz].[S4Hana_spSORejectionDates] @ldts [DATETIME2](7) AS
BEGIN
	SET NOCOUNT ON;
	SET ANSI_WARNINGS ON;

DECLARE @sysdate DATETIME;
SET @sysdate = getdate()

--DECLARE @LDTS [DATETIME2](7)
--SET @LDTS = '1900-01-01'

IF OBJECT_ID(N'tempdb..#Result') IS NOT NULL DROP TABLE #Result
IF OBJECT_ID(N'tempdb..#Result_Logic') IS NOT NULL DROP TABLE #Result_Logic
IF OBJECT_ID(N'tempdb..#ResultwithHash') IS NOT NULL DROP TABLE #ResultwithHash
IF OBJECT_ID(N'tempdb..#Result_LastRejectionDate') IS NOT NULL DROP TABLE #Result_LastRejectionDate

-- Declare Variable
		DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
		DECLARE @ExecStart DATETIME2(0) = GETDATE()
		DECLARE @SourceLastLoadDate DATETIME2(0)
		DECLARE @DestinationLastLoadDate DATETIME2(0)
		DECLARE @BatchLdts DATETIME2(0) = @LDTS
		DECLARE @AffectedRows BIGINT = NULL

		--logging DataTransferLogs
		IF(EXISTS(SELECT 1 FROM [biz].[S4Hana_SORejectionDates]))
		BEGIN
			SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(LDTS))
			FROM [biz].[S4Hana_SORejectionDates]
		END
		ELSE BEGIN
			SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
		END 


		IF(EXISTS(SELECT 1 FROM [stag].[S4Hana_SORejectionDates]))
		BEGIN
			SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(_LDTS))
			FROM [stag].[S4Hana_SORejectionDates]
		END
		ELSE BEGIN
			SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
		END 

		--Log Data load
		INSERT INTO etl.DataTransferLogs
			  (DataTransferLogId
			  ,TransferName
			  ,TransferGroupName
			  ,TargetTableName
			  ,TargetSchemaName
			  ,ExecStart
			  ,SourceLastLoadDate
			  ,DestinationLastLoadDate
			  ,BatchLdts)
			  SELECT @DataTransferLogId 
					,'S4Hana_spSoRejectionDates'
					,'biz_SoRejectionDates'
					,'SoRejectionDates'
					,'Stag'
					,@ExecStart
					,@SourceLastLoadDate
					,@DestinationLastLoadDate
					,@BatchLdts


CREATE TABLE #Result
WITH
(

		DISTRIBUTION = HASH(SalesDocument)
		, CLUSTERED INDEX (SalesDocument ASC, SalesDocumentItem ASC)

)
AS
SELECT
T1.SalesDocument
,T1.SalesDocumentItem
,T1.Value_NEW
,T1.Value_OLD
,T1.Changenr
,T1.RejectionDate
,T1.isDeleted
,T1.LDTS
FROM [stag].[S4Hana_fnSoRejectionDates] (@LDTS) AS T1
UNION ALL
SELECT distinct
T1.SalesDocument
,T1.SalesDocumentItem
,'biz' AS Value_NEW
,'' AS Value_OLD
,'0000000000' as Changenr
,T1.RejectionDate
,T1.isDeleted
,T1.LDTS
FROM [biz].[S4Hana_SORejectionDates] T1
INNER JOIN [stag].[S4Hana_fnSoRejectionDates] (@LDTS) AS T2 ON T1.SalesDocument = T2.SalesDocument AND T1.SalesDocumentItem = T2.SalesDocumentItem

CREATE TABLE #Result_LastRejectionDate
	WITH
	(
		DISTRIBUTION = HASH(SalesDocument)
		, CLUSTERED INDEX (SalesDocument ASC, SalesDocumentItem ASC)
	)
	AS

SELECT MAX(RejectionDate) OrigRejectionDate, SalesDocument, SalesDocumentItem
FROM #Result
WHERE Value_OLD ='' and Value_NEW <> ''
GROUP BY  SalesDocument, SalesDocumentItem

CREATE TABLE #Result_Logic
	WITH
	(
		DISTRIBUTION = HASH(SalesDocument)
		, CLUSTERED INDEX (SalesDocument ASC, SalesDocumentItem ASC)
	)
	AS

select
		CAST(CONCAT(LTRIM(RTRIM(Rej.SalesDocument)),LTRIM(RTRIM(Rej.SalesDocumentItem)))AS BIGINT) AS SoRejectionDate_BK
		,Rej.SalesDocument
		,Rej.SalesDocumentItem
		,CASE WHEN VALUE_NEW <>'' AND VALUE_OLD = '' THEN RejectionDate    -- First condition: Value_NEW yes, Value_Old no --> RejectionDate from that row RNG=1
				WHEN VALUE_NEW = '' THEN NULL -- Second condition: Value_NEW NULL --> Rejection Date is null - no rejection anymore
				WHEN VALUE_NEW <>'' AND Value_OLD <> '' 
					THEN ISNULL(LastRej.OrigRejectionDate,RejectionDate)	-- Third condition:	change on the Rejection Reason -> take first Rejection date (udate)
				ELSE NULL END
				AS RejectionDate_NEW --solution to bring previous rejection date, currently not in use (potential issue 2 or more rows outputet from stag function) 
		,Rej.Value_NEW
		,Rej.Value_OLD
		,Rej.RejectionDate
		,Rej.isDeleted
		,Rej.LDTS
		,Row_NUMBER()OVER(Partition by Rej.SalesDocument, Rej.SalesDocumentItem ORDER BY LDTS DESC, Changenr DESC) AS RNG
FROM #Result Rej 
LEFT JOIN #Result_LastRejectionDate LastRej on Rej.SalesDocument = LastRej.SalesDocument AND Rej.SalesDocumentItem = LastRej.SalesDocumentItem
where isDeleted = 0

CREATE TABLE #ResultwithHash
	WITH
	(
		DISTRIBUTION = HASH(SoRejectionDate_BK)
		, CLUSTERED INDEX (SalesDocument ASC, SalesDocumentItem ASC)
	)
	AS
Select 
 T1.SoRejectionDate_BK
,T1.SalesDocument
,T1.SalesDocumentItem
,T1.RejectionDate_NEW AS RejectionDate
,T1.IsDeleted
,T1.LDTS
,CONVERT([BINARY](16),
				HASHBYTES('MD5',CONCAT(
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), SalesDocument)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), SalesDocumentItem)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), RejectionDate)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), IsDeleted))))))
			) AS HashDiff

from #Result_Logic T1
WHERE rng = 1



-- count new Records for S4Hana_DeliveryDocumentItems
SELECT @AffectedRows = COUNT(*)
FROM #ResultwithHash as stg INNER JOIN [biz].[S4Hana_SORejectionDates] prd
	on stg.SoRejectionDate_BK = prd.SoRejectionDate_BK
WHERE stg.HashDiff <> prd.Hashdiff


-- Update

UPDATE prd
   SET prd.[RejectionDate] = stg.[RejectionDate]
      ,prd.[isDeleted] = stg.[isDeleted]
      ,prd.[ModifiedOn] = @sysdate
      ,prd.[HashDiff] = stg.[HashDiff]
FROM #ResultwithHash as stg INNER JOIN [biz].[S4Hana_SORejectionDates] prd
	on stg.SoRejectionDate_BK = prd.SoRejectionDate_BK
WHERE stg.HashDiff <> prd.Hashdiff

UPDATE DTlogs
SET Updated = @AffectedRows
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId


-- count new Records for S4Hana_DeliveryDocumentItems
SELECT @AffectedRows = COUNT(*)
FROM #ResultwithHash AS stg LEFT JOIN [biz].[S4Hana_SORejectionDates] prd
	on stg.[SoRejectionDate_BK] = prd.[SoRejectionDate_BK]
	WHERE prd.[SoRejectionDate_BK] IS NULL

INSERT INTO [biz].[S4Hana_SORejectionDates]
           ([SoRejectionDate_BK]
           ,[SalesDocument]
           ,[SalesDocumentItem]
           ,[RejectionDate]
           ,[isDeleted]
           ,[CreatedOn]
           ,[ModifiedOn]
           ,[LDTS]
           ,[HashDiff])
select

			stg.[SoRejectionDate_BK]
           ,stg.[SalesDocument]
           ,stg.[SalesDocumentItem]
           ,stg.[RejectionDate]
           ,stg.[isDeleted]
           ,@sysdate
           ,@sysdate
           ,stg.[LDTS]
           ,stg.[HashDiff]
FROM #ResultwithHash AS stg LEFT JOIN [biz].[S4Hana_SORejectionDates] prd
	on stg.[SoRejectionDate_BK] = prd.[SoRejectionDate_BK]
	WHERE prd.[SoRejectionDate_BK] IS NULL

UPDATE DTlogs
SET Inserted = @AffectedRows
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId


END

-- exec [biz].[S4Hana_spSoRejectionDates] '1900-01-01'
-- truncate table [biz].[S4Hana_SORejectionDates]