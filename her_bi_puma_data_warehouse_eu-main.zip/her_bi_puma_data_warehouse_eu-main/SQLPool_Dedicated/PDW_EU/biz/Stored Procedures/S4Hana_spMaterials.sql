﻿CREATE PROC [biz].[S4Hana_spMaterials] @ldts [DATETIME2](7) AS
BEGIN
	SET NOCOUNT ON;
	SET ANSI_WARNINGS ON;

	DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
	DECLARE @ExecStart DATETIME2(7) = GETDATE()
	DECLARE @SourceLastLoadDate DATETIME2(7)
	DECLARE @DestinationLastLoadDate DATETIME2(7)
	DECLARE @BatchLdts DATETIME2(7) = @LDTS
	DECLARE @AffectedRows BIGINT = NULL

	IF(EXISTS(SELECT 1 FROM [biz].[S4Hana_Materials]))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(LDTS))
	FROM [biz].[S4Hana_Materials]
	END
	ELSE BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

	IF(EXISTS(SELECT 1 FROM stag.[S4Hana_Materials]))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(_LDTS))
		FROM stag.[S4Hana_Materials]
	END
	ELSE BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END 


	--Log Data load
	INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'S4Hana_spMaterials'
			,'biz_Materials'
			,'S4Hana_Materials'
			,'biz'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts


	IF OBJECT_ID(N'tempdb..#materials') IS NOT NULL
	DROP TABLE #materials;

	SELECT
	   [Material]
      ,[MaterialType]
      ,[MaterialGroup]
      ,[MaterialBaseUnit]
      ,[MaterialGrossWeight]
      ,[MaterialNetWeight]
      ,[MaterialWeightUnit]
      ,[MaterialManufacturerNumber]
      ,[MaterialManufacturerPartNumber]
      ,[AuthorizationGroup]
      ,[IsBatchManagementRequired]
      ,[WeightUnit]
      ,[ntgew]
      ,[brgew]
      ,[meins]
      ,[matkl]
      ,[mtart]
      ,[brand_id]
      ,[fsh_mg_at1]
      ,[zcoldesc]
      ,[zcolor]
      ,[size1]
      ,[ean11]
      ,[zage_group_code]
      ,[zline_name_code]
      ,[zbus_unit]
      ,[zcategory]
      ,[zactgrp]
      ,[zart_grp_code]
      ,[zart_typ_code]
      ,[zgender_code]
      ,[zdcs_class]
      ,[zmkt_st_code]
      ,[zrepcat]
      ,[zrep_line]
      ,[zrepcon]
      ,[pod_code]
      ,[zprodiv]
      ,[mstae]
      ,[mstav]
      ,[zprd_chr_code]
      ,[zrbu]
      ,[zbusseg]
      ,[zbussub]
      ,[zret_gender]
      ,[zbfo_season]
      ,[zqinfo]
      ,[zfp_promo]
      ,[GenericMaterial]
      ,[zdcs_sclass]
      ,[fsh_mg_at2]
      ,[fsh_mg_at3]
      ,[MaterialCategory]
      ,[maindc]
      ,[free_char]
      ,[zlaunch]
      ,[DateOfLastChange]
      ,[DateChanged]
      ,[PIDFlag]
      ,[Master_Staging_werks]
      ,[Master_Staging_vtweg]
      ,[FirstPIDSeason]
      ,[LastPIDSeason]
      ,[RetailDCSDepCode]
      ,[OutletTheme]
      ,[FPeComTheme]
	  ,IsDeleted       
      ,[_LDTS] as LDTS
	  ,CONVERT([BINARY](16),
				HASHBYTES('MD5',CONCAT(
			    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Material]                       )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[MaterialType]				   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[MaterialGroup]				   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[MaterialBaseUnit]			   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[MaterialGrossWeight]			   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[MaterialNetWeight]			   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[MaterialWeightUnit]			   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[MaterialManufacturerNumber]	   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[MaterialManufacturerPartNumber] )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[AuthorizationGroup]			   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[IsBatchManagementRequired]	   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[WeightUnit]					   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ntgew]						   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[brgew]						   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[meins]						   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[matkl]						   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[mtart]						   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[brand_id]					   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[fsh_mg_at1]					   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[zcoldesc]					   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[zcolor]						   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[size1]						   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ean11]						   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[zage_group_code]				   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[zline_name_code]				   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[zbus_unit]					   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[zcategory]					   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[zactgrp]						   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[zart_grp_code]				   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[zart_typ_code]				   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[zgender_code]				   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[zdcs_class]					   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[zmkt_st_code]				   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[zrepcat]						   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[zrep_line]					   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[zrepcon]						   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[pod_code]					   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[zprodiv]						   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[mstae]						   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[mstav]						   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[zprd_chr_code]				   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[zrbu]						   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[zbusseg]						   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[zbussub]						   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[zret_gender]					   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[zbfo_season]					   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[zqinfo]						   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[zfp_promo]					   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[GenericMaterial]				   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[zdcs_sclass]					   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[fsh_mg_at2]					   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[fsh_mg_at3]					   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[MaterialCategory]			   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[maindc]						   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[free_char]					   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[zlaunch]						   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DateOfLastChange]			   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DateChanged]					   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PIDFlag]						   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Master_Staging_werks]		   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Master_Staging_vtweg]		   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FirstPIDSeason]				   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[LastPIDSeason]				   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[RetailDCSDepCode]			   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[OutletTheme]					   )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FPeComTheme]					   )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[IsDeleted]))))))       
			) AS HashDiff
INTO #materials
FROM 
(
	SELECT
	 *
	, CAST(CASE WHEN __operation_type = 'X' 
		THEN 1 ELSE 0 END AS BIT)				AS IsDeleted
	, _LDTS										AS ModifiedOn
	, ROW_NUMBER() OVER (PARTITION BY Material 
					ORDER BY _LDTS DESC
						, __timestamp DESC)		AS RN
	FROM [stag].[S4Hana_Materials]
) X
WHERE RN = 1
and [_LDTS] > @ldts
	
		-- count new Records for S4Hana_Materials
		    SELECT @AffectedRows = COUNT(*)
			FROM #materials AS stg LEFT JOIN biz.S4Hana_Materials AS prd 
			ON prd.Material = stg.Material 
			WHERE prd.Material IS NULL

   --load new
   INSERT INTO biz.S4Hana_Materials
			(
				[Material]
               ,[MaterialType]
               ,[MaterialGroup]
               ,[MaterialBaseUnit]
               ,[MaterialGrossWeight]
               ,[MaterialNetWeight]
               ,[MaterialWeightUnit]
               ,[MaterialManufacturerNumber]
               ,[MaterialManufacturerPartNumber]
               ,[AuthorizationGroup]
               ,[IsBatchManagementRequired]
               ,[WeightUnit]
               ,[ntgew]
               ,[brgew]
               ,[meins]
               ,[matkl]
               ,[mtart]
               ,[brand_id]
               ,[fsh_mg_at1]
               ,[zcoldesc]
               ,[zcolor]
               ,[size1]
               ,[ean11]
               ,[zage_group_code]
               ,[zline_name_code]
               ,[zbus_unit]
               ,[zcategory]
               ,[zactgrp]
               ,[zart_grp_code]
               ,[zart_typ_code]
               ,[zgender_code]
               ,[zdcs_class]
               ,[zmkt_st_code]
               ,[zrepcat]
               ,[zrep_line]
               ,[zrepcon]
               ,[pod_code]
               ,[zprodiv]
               ,[mstae]
               ,[mstav]
               ,[zprd_chr_code]
               ,[zrbu]
               ,[zbusseg]
               ,[zbussub]
               ,[zret_gender]
               ,[zbfo_season]
               ,[zqinfo]
               ,[zfp_promo]
               ,[GenericMaterial]
               ,[zdcs_sclass]
               ,[fsh_mg_at2]
               ,[fsh_mg_at3]
               ,[MaterialCategory]
               ,[maindc]
               ,[free_char]
               ,[zlaunch]
               ,[DateOfLastChange]
               ,[DateChanged]
               ,[PIDFlag]
               ,[Master_Staging_werks]
               ,[Master_Staging_vtweg]
               ,[FirstPIDSeason]
               ,[LastPIDSeason]
               ,[RetailDCSDepCode]
               ,[OutletTheme]
               ,[FPeComTheme]
	           ,IsDeleted       
               ,LDTS
			   ,[HashDiff]			
			)
	SELECT 
				stg.[Material]
               ,stg.[MaterialType]
               ,stg.[MaterialGroup]
               ,stg.[MaterialBaseUnit]
               ,stg.[MaterialGrossWeight]
               ,stg.[MaterialNetWeight]
               ,stg.[MaterialWeightUnit]
               ,stg.[MaterialManufacturerNumber]
               ,stg.[MaterialManufacturerPartNumber]
               ,stg.[AuthorizationGroup]
               ,stg.[IsBatchManagementRequired]
               ,stg.[WeightUnit]
               ,stg.[ntgew]
               ,stg.[brgew]
               ,stg.[meins]
               ,stg.[matkl]
               ,stg.[mtart]
               ,stg.[brand_id]
               ,stg.[fsh_mg_at1]
               ,stg.[zcoldesc]
               ,stg.[zcolor]
               ,stg.[size1]
               ,stg.[ean11]
               ,stg.[zage_group_code]
               ,stg.[zline_name_code]
               ,stg.[zbus_unit]
               ,stg.[zcategory]
               ,stg.[zactgrp]
               ,stg.[zart_grp_code]
               ,stg.[zart_typ_code]
               ,stg.[zgender_code]
               ,stg.[zdcs_class]
               ,stg.[zmkt_st_code]
               ,stg.[zrepcat]
               ,stg.[zrep_line]
               ,stg.[zrepcon]
               ,stg.[pod_code]
               ,stg.[zprodiv]
               ,stg.[mstae]
               ,stg.[mstav]
               ,stg.[zprd_chr_code]
               ,stg.[zrbu]
               ,stg.[zbusseg]
               ,stg.[zbussub]
               ,stg.[zret_gender]
               ,stg.[zbfo_season]
               ,stg.[zqinfo]
               ,stg.[zfp_promo]
               ,stg.[GenericMaterial]
               ,stg.[zdcs_sclass]
               ,stg.[fsh_mg_at2]
               ,stg.[fsh_mg_at3]
               ,stg.[MaterialCategory]
               ,stg.[maindc]
               ,stg.[free_char]
               ,stg.[zlaunch]
               ,stg.[DateOfLastChange]
               ,stg.[DateChanged]
               ,stg.[PIDFlag]
               ,stg.[Master_Staging_werks]
               ,stg.[Master_Staging_vtweg]
               ,stg.[FirstPIDSeason]
               ,stg.[LastPIDSeason]
               ,stg.[RetailDCSDepCode]
               ,stg.[OutletTheme]
               ,stg.[FPeComTheme]
	           ,stg.IsDeleted       
               ,stg.LDTS
			   ,stg.[HashDiff]				


		 FROM #materials AS stg LEFT JOIN biz.S4Hana_Materials AS prd 
		 ON prd.Material = stg.Material 
		 WHERE prd.Material IS NULL
	
		UPDATE DTlogs
		SET Inserted = @AffectedRows
		FROM etl.DataTransferLogs DTlogs
		WHERE DataTransferLogId = @DataTransferLogId


		-- count new Records for S4Hana_Materials
		SELECT @AffectedRows = COUNT(*)
		FROM #materials AS stg JOIN biz.S4Hana_Materials AS prd 
		ON prd.Material = stg.Material
		WHERE stg.HashDiff <> prd.HashDiff

		UPDATE DTlogs
		SET Updated = @AffectedRows
		, ExecEnd = GETDATE()
		FROM etl.DataTransferLogs DTlogs
		WHERE DataTransferLogId = @DataTransferLogId

		--update non deleted records
		  UPDATE prd SET	
				prd.[Material]                        = stg.[Material]
               ,prd.[MaterialType]					  = stg.[MaterialType]
               ,prd.[MaterialGroup]					  = stg.[MaterialGroup]
               ,prd.[MaterialBaseUnit]				  = stg.[MaterialBaseUnit]
               ,prd.[MaterialGrossWeight]			  = stg.[MaterialGrossWeight]
               ,prd.[MaterialNetWeight]				  = stg.[MaterialNetWeight]
               ,prd.[MaterialWeightUnit]			  = stg.[MaterialWeightUnit]
               ,prd.[MaterialManufacturerNumber]	  = stg.[MaterialManufacturerNumber]
               ,prd.[MaterialManufacturerPartNumber]  = stg.[MaterialManufacturerPartNumber]
               ,prd.[AuthorizationGroup]			  = stg.[AuthorizationGroup]
               ,prd.[IsBatchManagementRequired]		  = stg.[IsBatchManagementRequired]
               ,prd.[WeightUnit]					  = stg.[WeightUnit]
               ,prd.[ntgew]							  = stg.[ntgew]
               ,prd.[brgew]							  = stg.[brgew]
               ,prd.[meins]							  = stg.[meins]
               ,prd.[matkl]							  = stg.[matkl]
               ,prd.[mtart]							  = stg.[mtart]
               ,prd.[brand_id]						  = stg.[brand_id]
               ,prd.[fsh_mg_at1]					  = stg.[fsh_mg_at1]
               ,prd.[zcoldesc]						  = stg.[zcoldesc]
               ,prd.[zcolor]						  = stg.[zcolor]
               ,prd.[size1]							  = stg.[size1]
               ,prd.[ean11]							  = stg.[ean11]
               ,prd.[zage_group_code]				  = stg.[zage_group_code]
               ,prd.[zline_name_code]				  = stg.[zline_name_code]
               ,prd.[zbus_unit]						  = stg.[zbus_unit]
               ,prd.[zcategory]						  = stg.[zcategory]
               ,prd.[zactgrp]						  = stg.[zactgrp]
               ,prd.[zart_grp_code]					  = stg.[zart_grp_code]
               ,prd.[zart_typ_code]					  = stg.[zart_typ_code]
               ,prd.[zgender_code]					  = stg.[zgender_code]
               ,prd.[zdcs_class]					  = stg.[zdcs_class]
               ,prd.[zmkt_st_code]					  = stg.[zmkt_st_code]
               ,prd.[zrepcat]						  = stg.[zrepcat]
               ,prd.[zrep_line]						  = stg.[zrep_line]
               ,prd.[zrepcon]						  = stg.[zrepcon]
               ,prd.[pod_code]						  = stg.[pod_code]
               ,prd.[zprodiv]						  = stg.[zprodiv]
               ,prd.[mstae]							  = stg.[mstae]
               ,prd.[mstav]							  = stg.[mstav]
               ,prd.[zprd_chr_code]					  = stg.[zprd_chr_code]
               ,prd.[zrbu]							  = stg.[zrbu]
               ,prd.[zbusseg]						  = stg.[zbusseg]
               ,prd.[zbussub]						  = stg.[zbussub]
               ,prd.[zret_gender]					  = stg.[zret_gender]
               ,prd.[zbfo_season]					  = stg.[zbfo_season]
               ,prd.[zqinfo]						  = stg.[zqinfo]
               ,prd.[zfp_promo]						  = stg.[zfp_promo]
               ,prd.[GenericMaterial]				  = stg.[GenericMaterial]
               ,prd.[zdcs_sclass]					  = stg.[zdcs_sclass]
               ,prd.[fsh_mg_at2]					  = stg.[fsh_mg_at2]
               ,prd.[fsh_mg_at3]					  = stg.[fsh_mg_at3]
               ,prd.[MaterialCategory]				  = stg.[MaterialCategory]
               ,prd.[maindc]						  = stg.[maindc]
               ,prd.[free_char]						  = stg.[free_char]
               ,prd.[zlaunch]						  = stg.[zlaunch]
               ,prd.[DateOfLastChange]				  = stg.[DateOfLastChange]
               ,prd.[DateChanged]					  = stg.[DateChanged]
               ,prd.[PIDFlag]						  = stg.[PIDFlag]
               ,prd.[Master_Staging_werks]			  = stg.[Master_Staging_werks]
               ,prd.[Master_Staging_vtweg]			  = stg.[Master_Staging_vtweg]
               ,prd.[FirstPIDSeason]				  = stg.[FirstPIDSeason]
               ,prd.[LastPIDSeason]					  = stg.[LastPIDSeason]
               ,prd.[RetailDCSDepCode]				  = stg.[RetailDCSDepCode]
               ,prd.[OutletTheme]					  = stg.[OutletTheme]
               ,prd.[FPeComTheme]					  = stg.[FPeComTheme]
	           ,prd.IsDeleted       				  = stg.IsDeleted       
               ,prd.LDTS							  = stg.LDTS
			   ,prd.[HashDiff]						  = stg.[HashDiff]		


			FROM #materials AS stg JOIN biz.S4Hana_Materials AS prd 
			ON prd.Material = stg.Material
			WHERE stg.HashDiff <> prd.HashDiff and stg.IsDeleted = 0

		 --update deletions (only deleted status and LDTS)
		 UPDATE prd SET
				 prd.LDTS				= stg.LDTS
				,prd.IsDeleted			= stg.IsDeleted
				,prd.[HashDiff]			= stg.[HashDiff]
		 	FROM #materials AS stg JOIN biz.S4Hana_Materials AS prd 
			ON prd.Material = stg.Material
			WHERE stg.HashDiff <> prd.HashDiff and stg.IsDeleted = 1


END

--truncate table from biz.S4Hana_Materials
-- exec [biz].[S4Hana_spMaterials]'1900-01-01'