﻿CREATE PROC [biz].[s4hana_spSoDocumentItemQtysHistory_onPrem] @LDTS [DATETIME2](7) AS 
BEGIN
SET NOCOUNT ON
--ReloadFull
-- DECLARE @LDTS DATETIME2(7) = '20220102'
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(7) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(7)
DECLARE @DestinationLastLoadDate DATETIME2(7)
DECLARE @BatchLdts DATETIME2(7) = @LDTS

-- do not use the input parameter, in case of an failur or reload situartion take the last tranfered LDTS from the Hist table
IF(EXISTS(SELECT 1 FROM stag.S4Hana_SODocumentItems_full_onPrem))
BEGIN
	SELECT @SourceLastLoadDate =  MAX(_LDTS)
	FROM stag.S4Hana_SODocumentItems_full_onPrem
END
ELSE BEGIN
	SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
END 

IF(EXISTS(SELECT 1 FROM [biz].[s4hana_SoDocumentItemQtysHistory_onPrem]))
BEGIN
	SELECT @DestinationLastLoadDate =  MAX(LDTS)
	FROM [biz].[s4hana_SoDocumentItemQtysHistory_onPrem]
END;
ELSE BEGIN
	SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
END 

--Log Data load

INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'s4hana_spSoDocumentItemQtysHistory_onPrem'
			,'prepSoDocItemPriceConditionsHist_onPrem'
			,'NatSalesOrdersOohHistory_onPrem'
			,'sales'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts

IF @SourceLastLoadDate > @DestinationLastLoadDate
BEGIN -- only truncate insert new data if a new batch is loaded. for reload data are already in

Truncate Table [biz].[s4hana_SoDocumentItemQtysHistory_onPrem]

;WITH DataPrep
AS (
	SELECT DISTINCT CONVERT(CHAR(10), stagSoDocItemFull.VBELN) AS NatSalesorderNo,
		CONVERT(CHAR(6), stagSoDocItemFull.POSNR) AS NatSalesOrderItemNo,
		CONVERT(DATETIME2(0), stagSoDocItemFull._LDTS) AS LDTS,
		CONVERT(INT, (CONVERT(NUMERIC(15, 3), stagSoDocItemFull.KWMENG))) AS OrderQuantity,
		CONVERT(BIT, CASE 
				WHEN stagSoDocItemFull.ODQ_CHANGEMODE = 'D'
					THEN 1
				ELSE 0
				END) AS IsDeleted
	FROM stag.S4Hana_SODocumentItems_full_onPrem AS stagSoDocItemFull
		--WHERE VBELN = '1014092200'
		--AND POSNR = '000420'
	)
INSERT INTO [biz].[s4hana_SoDocumentItemQtysHistory_onPrem] (
	NatSalesorderNo,
	NatSalesOrderItemNo,
	LDTS,
	LEDTS,
	OrderQuantity,
	IsDeleted
	)
SELECT NatSalesorderNo,
	NatSalesOrderItemNo,
	LDTS,
	ISNULL(dateadd(ss, - 1, next_date), '9999-12-31') AS LEDTS,
	OrderQuantity,
	IsDeleted
FROM (
	SELECT NatSalesorderNo,
		NatSalesOrderItemNo,
		LDTS,
		lead(LDTS) OVER (
			PARTITION BY NatSalesorderNo,
			NatSalesOrderItemNo ORDER BY LDTS
			) AS next_date,
		OrderQuantity,
		IsDeleted
	FROM DataPrep
	) x

END -- Data already in for a reload

UPDATE DTlogs
SET ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

END -- Proc