﻿CREATE PROC [biz].[S4Hana_spBPAddresses] @ldts [DATETIME2](7) AS
BEGIN
	SET NOCOUNT ON;
	SET ANSI_WARNINGS ON;

	DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
	DECLARE @ExecStart DATETIME2(7) = GETDATE()
	DECLARE @SourceLastLoadDate DATETIME2(7)
	DECLARE @DestinationLastLoadDate DATETIME2(7)
	DECLARE @BatchLdts DATETIME2(7) = @LDTS
	DECLARE @AffectedRows BIGINT = NULL

	IF(EXISTS(SELECT 1 FROM [biz].[S4Hana_BPAddresses]))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(LDTS))
	FROM [biz].[S4Hana_BPAddresses]
	END
	ELSE BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

	IF(EXISTS(SELECT 1 FROM stag.[S4Hana_BPAddresses]))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(_LDTS))
		FROM stag.[S4Hana_BPAddresses]
	END
	ELSE BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END 


	--Log Data load
	INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'S4Hana_spBPAddresses'
			,'biz_BPAddressess'
			,'S4Hana_BPAddresses'
			,'biz'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts


	IF OBJECT_ID(N'tempdb..#bpa') IS NOT NULL
	DROP TABLE #bpa;

	SELECT
	   CONCAT(BusinessPartner, '|', AdrcAddressNumber, '|', ValidFrom, '|',IntAddress) AS BPAddresses_BK
	  ,[BusinessPartner]
      ,[AddressNumber]
      ,[StrdAddress]
      ,[AdrcAddressNumber]
      ,[ValidFrom]
      ,[IntAddress]
      ,[ValidToDflt]
      ,[title]
      ,[Name1]
      ,[name2]
      ,[name3]
      ,[name4]
      ,[convertedName]
      ,[COName]
      ,[City]
      ,[District]
      ,[CityCode]
      ,[CityCode2]
      ,[City2]
      ,[CityFTest]
      ,[TestStatus]
      ,[RegionalGroup]
      ,[PostalCode1]
      ,[PostalCode2]
      ,[PostalCode3]
      ,[PostalCode1ex]
      ,[PostalCode2ex]
      ,[PostalCode3ex]
      ,[POBox]
      ,[BoxWoutNo]
      ,[POBoxcity]
      ,[CITY_CODE2]
      ,[RegionPOBox]
      ,[POboxcountry]
      ,[PostDeliveryDistrict]
      ,[TranspZone]
      ,[Street]
      ,[StreetCity]
      ,[AbbrStreet]
      ,[HouseNumber]
      ,[HouseSuppl]
      ,[HouseRange]
      ,[Street2]
      ,[Street3]
      ,[Street4]
      ,[Street5]
      ,[Building]
      ,[Floor]
      ,[Room]
      ,[COUNTRY]
      ,[Language]
      ,[Region]
      ,[AddressGroup]
      ,[FlagGroup]
      ,[flagPersADDR]
      ,[SearchTerm1]
      ,[SearchTerm2]
      ,[PhoneticSearch]
      ,[DfltCommMtd]
      ,[FirstTel]
      ,[TelExtension]
      ,[FAX_NUMBER]
      ,[FaxExtension]
      ,[FlagTeldef]
      ,[FlagFax]
      ,[Flagteletex]
      ,[Flagtelex]
      ,[FlagEmail]
      ,[FlagRML]
      ,[FlagX400]
      ,[FlagRFC]
      ,[FlagPrinter]
      ,[FlagSSF]
      ,[FlagURI]
      ,[Pager]
      ,[AddressDataSource]
      ,[NameUpper]
      ,[CityUpper]
      ,[StreetUpper]
      ,[EXTENSIONDataLine]
      ,[EXTENSIONTelebox]
      ,[TIME_ZONE]
      ,[TAXJURCODE]
      ,[ADDRESS_ID]
      ,[OrigLanguage]
      ,[UUIDAddress]
      ,[IndUUIDAddress]
      ,[CategoryAddress]
      ,[ErrorStatusAddress]
      ,[POBoxLobby]
      ,[TypeDeliveryService]
      ,[NumberDeliveryService]
      ,[Countycode]
      ,[County]
      ,[Townshipcode]
      ,[Township]
      ,[CuontyUpper]
      ,[TownshipUpper]
      ,[BusinessPurpose]
      ,[DunsBradstreet]
      ,[DUNSplus4]
	  ,IsDeleted       
      ,[_LDTS] as LDTS
	  ,CONVERT([BINARY](16),
				HASHBYTES('MD5',CONCAT(
	            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[BusinessPartner]		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[AddressNumber]		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[StrdAddress]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[AdrcAddressNumber]	  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ValidFrom]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[IntAddress]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ValidToDflt]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[title]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Name1]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[name2]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[name3]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[name4]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[convertedName]		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[COName]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[City]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[District]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CityCode]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CityCode2]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[City2]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CityFTest]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TestStatus]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[RegionalGroup]		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PostalCode1]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PostalCode2]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PostalCode3]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PostalCode1ex]		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PostalCode2ex]		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PostalCode3ex]		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[POBox]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[BoxWoutNo]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[POBoxcity]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CITY_CODE2]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[RegionPOBox]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[POboxcountry]		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PostDeliveryDistrict]  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TranspZone]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Street]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[StreetCity]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[AbbrStreet]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[HouseNumber]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[HouseSuppl]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[HouseRange]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Street2]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Street3]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Street4]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Street5]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Building]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Floor]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Room]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[COUNTRY]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Language]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Region]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[AddressGroup]		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FlagGroup]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[flagPersADDR]		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SearchTerm1]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SearchTerm2]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PhoneticSearch]		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DfltCommMtd]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FirstTel]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TelExtension]		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FAX_NUMBER]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FaxExtension]		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FlagTeldef]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FlagFax]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Flagteletex]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Flagtelex]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FlagEmail]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FlagRML]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FlagX400]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FlagRFC]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FlagPrinter]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FlagSSF]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FlagURI]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Pager]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[AddressDataSource]	  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[NameUpper]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CityUpper]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[StreetUpper]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[EXTENSIONDataLine]	  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[EXTENSIONTelebox]	  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TIME_ZONE]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TAXJURCODE]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ADDRESS_ID]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[OrigLanguage]		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[UUIDAddress]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[IndUUIDAddress]		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CategoryAddress]		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ErrorStatusAddress]	  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[POBoxLobby]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TypeDeliveryService]	  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[NumberDeliveryService] )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Countycode]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[County]				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Townshipcode]		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Township]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CuontyUpper]			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TownshipUpper]		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[BusinessPurpose]		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DunsBradstreet]		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DUNSplus4]			  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[IsDeleted]))))))       
			) AS HashDiff

INTO #bpa
FROM
  ( SELECT *
    ,CAST(CASE WHEN __operation_type = 'X' THEN 1 ELSE 0 END AS BIT)				AS IsDeleted
	, ROW_NUMBER() OVER (PARTITION BY BusinessPartner,AdrcAddressNumber,ValidFrom,IntAddress 
						 ORDER BY __sequence_number, _LDTS DESC
								, __timestamp DESC)		AS RN
FROM [stag].[S4Hana_BPAddresses]
) X
WHERE RN = 1
and [_LDTS] > @ldts
	
		-- count new Records for S4Hana_BPAddresses
		    SELECT @AffectedRows = COUNT(*)
			FROM #bpa AS stg LEFT JOIN biz.S4Hana_BPAddresses AS prd 
			ON prd.BPAddresses_BK = stg.BPAddresses_BK 
			WHERE prd.BPAddresses_BK IS NULL

   --load new
   INSERT INTO biz.S4Hana_BPAddresses
			(
				 BPAddresses_BK
	            ,[BusinessPartner]
                ,[AddressNumber]
                ,[StrdAddress]
                ,[AdrcAddressNumber]
                ,[ValidFrom]
                ,[IntAddress]
                ,[ValidToDflt]
                ,[title]
                ,[Name1]
                ,[name2]
                ,[name3]
                ,[name4]
                ,[convertedName]
                ,[COName]
                ,[City]
                ,[District]
                ,[CityCode]
                ,[CityCode2]
                ,[City2]
                ,[CityFTest]
                ,[TestStatus]
                ,[RegionalGroup]
                ,[PostalCode1]
                ,[PostalCode2]
                ,[PostalCode3]
                ,[PostalCode1ex]
                ,[PostalCode2ex]
                ,[PostalCode3ex]
                ,[POBox]
                ,[BoxWoutNo]
                ,[POBoxcity]
                ,[CITY_CODE2]
                ,[RegionPOBox]
                ,[POboxcountry]
                ,[PostDeliveryDistrict]
                ,[TranspZone]
                ,[Street]
                ,[StreetCity]
                ,[AbbrStreet]
                ,[HouseNumber]
                ,[HouseSuppl]
                ,[HouseRange]
                ,[Street2]
                ,[Street3]
                ,[Street4]
                ,[Street5]
                ,[Building]
                ,[Floor]
                ,[Room]
                ,[COUNTRY]
                ,[Language]
                ,[Region]
                ,[AddressGroup]
                ,[FlagGroup]
                ,[flagPersADDR]
                ,[SearchTerm1]
                ,[SearchTerm2]
                ,[PhoneticSearch]
                ,[DfltCommMtd]
                ,[FirstTel]
                ,[TelExtension]
                ,[FAX_NUMBER]
                ,[FaxExtension]
                ,[FlagTeldef]
                ,[FlagFax]
                ,[Flagteletex]
                ,[Flagtelex]
                ,[FlagEmail]
                ,[FlagRML]
                ,[FlagX400]
                ,[FlagRFC]
                ,[FlagPrinter]
                ,[FlagSSF]
                ,[FlagURI]
                ,[Pager]
                ,[AddressDataSource]
                ,[NameUpper]
                ,[CityUpper]
                ,[StreetUpper]
                ,[EXTENSIONDataLine]
                ,[EXTENSIONTelebox]
                ,[TIME_ZONE]
                ,[TAXJURCODE]
                ,[ADDRESS_ID]
                ,[OrigLanguage]
                ,[UUIDAddress]
                ,[IndUUIDAddress]
                ,[CategoryAddress]
                ,[ErrorStatusAddress]
                ,[POBoxLobby]
                ,[TypeDeliveryService]
                ,[NumberDeliveryService]
                ,[Countycode]
                ,[County]
                ,[Townshipcode]
                ,[Township]
                ,[CuontyUpper]
                ,[TownshipUpper]
                ,[BusinessPurpose]
                ,[DunsBradstreet]
                ,[DUNSplus4]
	            ,IsDeleted       
                ,LDTS
				,[HashDiff]			
			)
	SELECT 
				 stg.BPAddresses_BK
	            ,stg.[BusinessPartner]
                ,stg.[AddressNumber]
                ,stg.[StrdAddress]
                ,stg.[AdrcAddressNumber]
                ,stg.[ValidFrom]
                ,stg.[IntAddress]
                ,stg.[ValidToDflt]
                ,stg.[title]
                ,stg.[Name1]
                ,stg.[name2]
                ,stg.[name3]
                ,stg.[name4]
                ,stg.[convertedName]
                ,stg.[COName]
                ,stg.[City]
                ,stg.[District]
                ,stg.[CityCode]
                ,stg.[CityCode2]
                ,stg.[City2]
                ,stg.[CityFTest]
                ,stg.[TestStatus]
                ,stg.[RegionalGroup]
                ,stg.[PostalCode1]
                ,stg.[PostalCode2]
                ,stg.[PostalCode3]
                ,stg.[PostalCode1ex]
                ,stg.[PostalCode2ex]
                ,stg.[PostalCode3ex]
                ,stg.[POBox]
                ,stg.[BoxWoutNo]
                ,stg.[POBoxcity]
                ,stg.[CITY_CODE2]
                ,stg.[RegionPOBox]
                ,stg.[POboxcountry]
                ,stg.[PostDeliveryDistrict]
                ,stg.[TranspZone]
                ,stg.[Street]
                ,stg.[StreetCity]
                ,stg.[AbbrStreet]
                ,stg.[HouseNumber]
                ,stg.[HouseSuppl]
                ,stg.[HouseRange]
                ,stg.[Street2]
                ,stg.[Street3]
                ,stg.[Street4]
                ,stg.[Street5]
                ,stg.[Building]
                ,stg.[Floor]
                ,stg.[Room]
                ,stg.[COUNTRY]
                ,stg.[Language]
                ,stg.[Region]
                ,stg.[AddressGroup]
                ,stg.[FlagGroup]
                ,stg.[flagPersADDR]
                ,stg.[SearchTerm1]
                ,stg.[SearchTerm2]
                ,stg.[PhoneticSearch]
                ,stg.[DfltCommMtd]
                ,stg.[FirstTel]
                ,stg.[TelExtension]
                ,stg.[FAX_NUMBER]
                ,stg.[FaxExtension]
                ,stg.[FlagTeldef]
                ,stg.[FlagFax]
                ,stg.[Flagteletex]
                ,stg.[Flagtelex]
                ,stg.[FlagEmail]
                ,stg.[FlagRML]
                ,stg.[FlagX400]
                ,stg.[FlagRFC]
                ,stg.[FlagPrinter]
                ,stg.[FlagSSF]
                ,stg.[FlagURI]
                ,stg.[Pager]
                ,stg.[AddressDataSource]
                ,stg.[NameUpper]
                ,stg.[CityUpper]
                ,stg.[StreetUpper]
                ,stg.[EXTENSIONDataLine]
                ,stg.[EXTENSIONTelebox]
                ,stg.[TIME_ZONE]
                ,stg.[TAXJURCODE]
                ,stg.[ADDRESS_ID]
                ,stg.[OrigLanguage]
                ,stg.[UUIDAddress]
                ,stg.[IndUUIDAddress]
                ,stg.[CategoryAddress]
                ,stg.[ErrorStatusAddress]
                ,stg.[POBoxLobby]
                ,stg.[TypeDeliveryService]
                ,stg.[NumberDeliveryService]
                ,stg.[Countycode]
                ,stg.[County]
                ,stg.[Townshipcode]
                ,stg.[Township]
                ,stg.[CuontyUpper]
                ,stg.[TownshipUpper]
                ,stg.[BusinessPurpose]
                ,stg.[DunsBradstreet]
                ,stg.[DUNSplus4]
	            ,stg.IsDeleted       
                ,stg.LDTS
				,stg.[HashDiff]		


		 FROM #bpa AS stg LEFT JOIN biz.S4Hana_BPAddresses AS prd 
		 ON prd.BPAddresses_BK = stg.BPAddresses_BK 
		 WHERE prd.BPAddresses_BK IS NULL
	
		UPDATE DTlogs
		SET Inserted = @AffectedRows
		FROM etl.DataTransferLogs DTlogs
		WHERE DataTransferLogId = @DataTransferLogId


		-- count new Records for S4Hana_BPAddresses
		SELECT @AffectedRows = COUNT(*)
		FROM #bpa AS stg JOIN biz.S4Hana_BPAddresses AS prd 
		ON prd.BPAddresses_BK = stg.BPAddresses_BK
		WHERE stg.HashDiff <> prd.HashDiff

		UPDATE DTlogs
		SET Updated = @AffectedRows
		, ExecEnd = GETDATE()
		FROM etl.DataTransferLogs DTlogs
		WHERE DataTransferLogId = @DataTransferLogId

		--update non deleted records
		  UPDATE prd SET	
				 prd.BPAddresses_BK         = stg.BPAddresses_BK
	            ,prd.[BusinessPartner]		= stg.[BusinessPartner]
                ,prd.[AddressNumber]		= stg.[AddressNumber]
                ,prd.[StrdAddress]			= stg.[StrdAddress]
                ,prd.[AdrcAddressNumber]	= stg.[AdrcAddressNumber]
                ,prd.[ValidFrom]			= stg.[ValidFrom]
                ,prd.[IntAddress]			= stg.[IntAddress]
                ,prd.[ValidToDflt]			= stg.[ValidToDflt]
                ,prd.[title]				= stg.[title]
                ,prd.[Name1]				= stg.[Name1]
                ,prd.[name2]				= stg.[name2]
                ,prd.[name3]				= stg.[name3]
                ,prd.[name4]				= stg.[name4]
                ,prd.[convertedName]		= stg.[convertedName]
                ,prd.[COName]				= stg.[COName]
                ,prd.[City]					= stg.[City]
                ,prd.[District]				= stg.[District]
                ,prd.[CityCode]				= stg.[CityCode]
                ,prd.[CityCode2]			= stg.[CityCode2]
                ,prd.[City2]				= stg.[City2]
                ,prd.[CityFTest]			= stg.[CityFTest]
                ,prd.[TestStatus]			= stg.[TestStatus]
                ,prd.[RegionalGroup]		= stg.[RegionalGroup]
                ,prd.[PostalCode1]			= stg.[PostalCode1]
                ,prd.[PostalCode2]			= stg.[PostalCode2]
                ,prd.[PostalCode3]			= stg.[PostalCode3]
                ,prd.[PostalCode1ex]		= stg.[PostalCode1ex]
                ,prd.[PostalCode2ex]		= stg.[PostalCode2ex]
                ,prd.[PostalCode3ex]		= stg.[PostalCode3ex]
                ,prd.[POBox]				= stg.[POBox]
                ,prd.[BoxWoutNo]			= stg.[BoxWoutNo]
                ,prd.[POBoxcity]			= stg.[POBoxcity]
                ,prd.[CITY_CODE2]			= stg.[CITY_CODE2]
                ,prd.[RegionPOBox]			= stg.[RegionPOBox]
                ,prd.[POboxcountry]			= stg.[POboxcountry]
                ,prd.[PostDeliveryDistrict]	= stg.[PostDeliveryDistrict]
                ,prd.[TranspZone]			= stg.[TranspZone]
                ,prd.[Street]				= stg.[Street]
                ,prd.[StreetCity]			= stg.[StreetCity]
                ,prd.[AbbrStreet]			= stg.[AbbrStreet]
                ,prd.[HouseNumber]			= stg.[HouseNumber]
                ,prd.[HouseSuppl]			= stg.[HouseSuppl]
                ,prd.[HouseRange]			= stg.[HouseRange]
                ,prd.[Street2]				= stg.[Street2]
                ,prd.[Street3]				= stg.[Street3]
                ,prd.[Street4]				= stg.[Street4]
                ,prd.[Street5]				= stg.[Street5]
                ,prd.[Building]				= stg.[Building]
                ,prd.[Floor]				= stg.[Floor]
                ,prd.[Room]					= stg.[Room]
                ,prd.[COUNTRY]				= stg.[COUNTRY]
                ,prd.[Language]				= stg.[Language]
                ,prd.[Region]				= stg.[Region]
                ,prd.[AddressGroup]			= stg.[AddressGroup]
                ,prd.[FlagGroup]			= stg.[FlagGroup]
                ,prd.[flagPersADDR]			= stg.[flagPersADDR]
                ,prd.[SearchTerm1]			= stg.[SearchTerm1]
                ,prd.[SearchTerm2]			= stg.[SearchTerm2]
                ,prd.[PhoneticSearch]		= stg.[PhoneticSearch]
                ,prd.[DfltCommMtd]			= stg.[DfltCommMtd]
                ,prd.[FirstTel]				= stg.[FirstTel]
                ,prd.[TelExtension]			= stg.[TelExtension]
                ,prd.[FAX_NUMBER]			= stg.[FAX_NUMBER]
                ,prd.[FaxExtension]			= stg.[FaxExtension]
                ,prd.[FlagTeldef]			= stg.[FlagTeldef]
                ,prd.[FlagFax]				= stg.[FlagFax]
                ,prd.[Flagteletex]			= stg.[Flagteletex]
                ,prd.[Flagtelex]			= stg.[Flagtelex]
                ,prd.[FlagEmail]			= stg.[FlagEmail]
                ,prd.[FlagRML]				= stg.[FlagRML]
                ,prd.[FlagX400]				= stg.[FlagX400]
                ,prd.[FlagRFC]				= stg.[FlagRFC]
                ,prd.[FlagPrinter]			= stg.[FlagPrinter]
                ,prd.[FlagSSF]				= stg.[FlagSSF]
                ,prd.[FlagURI]				= stg.[FlagURI]
                ,prd.[Pager]				= stg.[Pager]
                ,prd.[AddressDataSource]	= stg.[AddressDataSource]
                ,prd.[NameUpper]			= stg.[NameUpper]
                ,prd.[CityUpper]			= stg.[CityUpper]
                ,prd.[StreetUpper]			= stg.[StreetUpper]
                ,prd.[EXTENSIONDataLine]	= stg.[EXTENSIONDataLine]
                ,prd.[EXTENSIONTelebox]		= stg.[EXTENSIONTelebox]
                ,prd.[TIME_ZONE]			= stg.[TIME_ZONE]
                ,prd.[TAXJURCODE]			= stg.[TAXJURCODE]
                ,prd.[ADDRESS_ID]			= stg.[ADDRESS_ID]
                ,prd.[OrigLanguage]			= stg.[OrigLanguage]
                ,prd.[UUIDAddress]			= stg.[UUIDAddress]
                ,prd.[IndUUIDAddress]		= stg.[IndUUIDAddress]
                ,prd.[CategoryAddress]		= stg.[CategoryAddress]
                ,prd.[ErrorStatusAddress]	= stg.[ErrorStatusAddress]
                ,prd.[POBoxLobby]			= stg.[POBoxLobby]
                ,prd.[TypeDeliveryService]	= stg.[TypeDeliveryService]
                ,prd.[NumberDeliveryService]= stg.[NumberDeliveryService]
                ,prd.[Countycode]			= stg.[Countycode]
                ,prd.[County]				= stg.[County]
                ,prd.[Townshipcode]			= stg.[Townshipcode]
                ,prd.[Township]				= stg.[Township]
                ,prd.[CuontyUpper]			= stg.[CuontyUpper]
                ,prd.[TownshipUpper]		= stg.[TownshipUpper]
                ,prd.[BusinessPurpose]		= stg.[BusinessPurpose]
                ,prd.[DunsBradstreet]		= stg.[DunsBradstreet]
                ,prd.[DUNSplus4]			= stg.[DUNSplus4]
	            ,prd.IsDeleted       		= stg.IsDeleted       
                ,prd.LDTS					= stg.LDTS
				,prd.[HashDiff]				= stg.[HashDiff]					


			FROM #bpa AS stg JOIN biz.S4Hana_BPAddresses AS prd 
			ON prd.BPAddresses_BK = stg.BPAddresses_BK
			WHERE stg.HashDiff <> prd.HashDiff and stg.IsDeleted = 0

		 --update deletions (only deleted status and LDTS)
		 UPDATE prd SET
				 prd.LDTS				= stg.LDTS
				,prd.IsDeleted			= stg.IsDeleted
				,prd.[HashDiff]			= stg.[HashDiff]
		 	FROM #bpa AS stg JOIN biz.S4Hana_BPAddresses AS prd 
			ON prd.BPAddresses_BK = stg.BPAddresses_BK
			WHERE stg.HashDiff <> prd.HashDiff and stg.IsDeleted = 1


END

--truncate table biz.S4Hana_BPAddresses
-- exec [biz].[S4Hana_spBPAddresses]'1900-01-01'