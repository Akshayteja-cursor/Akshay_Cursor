﻿CREATE PROC [biz].[S4Hana_spDeliveryDocumentItems] @ldts [DATETIME2](7) AS
BEGIN
	SET NOCOUNT ON;
	SET ANSI_WARNINGS ON;

	-- Declare Variable
		DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
		DECLARE @ExecStart DATETIME2(7) = GETDATE()
		DECLARE @SourceLastLoadDate DATETIME2(7)
		DECLARE @DestinationLastLoadDate DATETIME2(7)
		DECLARE @BatchLdts DATETIME2(7) = @LDTS
		DECLARE @AffectedRows BIGINT = NULL

		--logging DataTransferLogs
		IF(EXISTS(SELECT 1 FROM biz.S4Hana_DeliveryDocumentItems))
		BEGIN
			SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(LDTS))
			FROM biz.S4Hana_DeliveryDocumentItems
		END
		ELSE BEGIN
			SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
		END 


		IF(EXISTS(SELECT 1 FROM stag.S4Hana_DeliveryDocumentItems))
		BEGIN
			SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(_LDTS))
			FROM stag.S4Hana_DeliveryDocumentItems
		END
		ELSE BEGIN
			SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
		END 

		--Log Data load
		INSERT INTO etl.DataTransferLogs
			  (DataTransferLogId
			  ,TransferName
			  ,TransferGroupName
			  ,TargetTableName
			  ,TargetSchemaName
			  ,ExecStart
			  ,SourceLastLoadDate
			  ,DestinationLastLoadDate
			  ,BatchLdts)
			  SELECT @DataTransferLogId 
					,'S4Hana_spDeliveryDocumentItems'
					,'biz_DeliveryDocumentItems'
					,'DeliveryDocumentsItems'
					,'Stag'
					,@ExecStart
					,@SourceLastLoadDate
					,@DestinationLastLoadDate
					,@BatchLdts

	IF OBJECT_ID(N'tempdb..#di') IS NOT NULL
	DROP TABLE #di;

	SELECT	 DeliveryNoteItemNo --BK
			,DeliveryNoteNumber --BK
			,ReferenceDocumentNo
			,ReferenceDocumentItemNo
			,MaterialNumber
			,SiteCode
			,ActualDeliveryQuantity
			,ActualDeliveryQuantityBaseUnit
			,OriginalDeliveryQuantity
			,CreatedByUser
			,DistributionChannel
			,StorageLocation
			,ProfitCenter
			,SDProcessStatus
			,RequirementSegment
			,StockSegment 
			,ProductAvailabilityDate
			,ProductAvailabilityTime
			,IsDeleted
			,LDTS
			,CONVERT([BINARY](16),
				HASHBYTES('MD5',CONCAT(
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), DeliveryNoteItemNo)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), DeliveryNoteNumber)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ReferenceDocumentNo)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ReferenceDocumentItemNo)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), MaterialNumber)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), SiteCode)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ActualDeliveryQuantity)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ActualDeliveryQuantityBaseUnit)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), OriginalDeliveryQuantity)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CreatedByUser)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), DistributionChannel)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), StorageLocation)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ProfitCenter)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), SDProcessStatus)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), RequirementSegment)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), StockSegment )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ProductAvailabilityDate )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ProductAvailabilityTime )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), IsDeleted))))))
			) AS HashDiff
		INTO #di
		FROM stag.S4Hana_fnDeliveryDocumentItems(@ldts) --OPTION (MAXDOP 1);


		-- count new Records for S4Hana_DeliveryDocumentItems
		SELECT @AffectedRows = COUNT(*)
		 FROM #di AS stg LEFT JOIN biz.S4Hana_DeliveryDocumentItems AS prd 
			ON prd.DeliveryNoteItemNo = stg.DeliveryNoteItemNo AND prd.DeliveryNoteNumber = stg.DeliveryNoteNumber 
		 WHERE prd.DeliveryNoteItemNo IS NULL AND prd.DeliveryNoteNumber IS NULL	

   --load new
   INSERT INTO biz.S4Hana_DeliveryDocumentItems
			(DeliveryNoteItemNo --BK
			,DeliveryNoteNumber --BK
			,ReferenceDocumentNo
			,ReferenceDocumentItemNo
			,MaterialNumber
			,SiteCode
			,ActualDeliveryQuantity
			,ActualDeliveryQuantityBaseUnit
			,OriginalDeliveryQuantity
			,CreatedByUser
			,DistributionChannel
			,StorageLocation
			,ProfitCenter
			,SDProcessStatus
			,RequirementSegment
			,StockSegment 
			,ProductAvailabilityDate
			,ProductAvailabilityTime
			,IsDeleted 
			,LDTS
			,HashDiff)
	SELECT stg.DeliveryNoteItemNo --BK
			,stg.DeliveryNoteNumber --BK
			,stg.ReferenceDocumentNo
			,stg.ReferenceDocumentItemNo
			,stg.MaterialNumber
			,stg.SiteCode
			,stg.ActualDeliveryQuantity
			,stg.ActualDeliveryQuantityBaseUnit
			,stg.OriginalDeliveryQuantity
			,stg.CreatedByUser
			,stg.DistributionChannel
			,stg.StorageLocation
			,stg.ProfitCenter
			,stg.SDProcessStatus
			,stg.RequirementSegment
			,stg.StockSegment 
			,stg.ProductAvailabilityDate
			,stg.ProductAvailabilityTime
			,stg.IsDeleted
			,stg.LDTS
			,stg.HashDiff
		 FROM #di AS stg LEFT JOIN biz.S4Hana_DeliveryDocumentItems AS prd 
			ON prd.DeliveryNoteItemNo = stg.DeliveryNoteItemNo AND prd.DeliveryNoteNumber = stg.DeliveryNoteNumber 
		 WHERE prd.DeliveryNoteItemNo IS NULL AND prd.DeliveryNoteNumber IS NULL

UPDATE DTlogs
SET Inserted = @AffectedRows
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId


		-- count new Records for S4Hana_DeliveryDocuments
		SELECT @AffectedRows = COUNT(*)
		FROM #di AS stg JOIN biz.S4Hana_DeliveryDocumentItems AS prd 
		ON prd.DeliveryNoteItemNo = stg.DeliveryNoteItemNo AND prd.DeliveryNoteNumber = stg.DeliveryNoteNumber  
		WHERE stg.HashDiff <> prd.HashDiff


		  UPDATE prd SET	
			prd.ReferenceDocumentNo	= stg.ReferenceDocumentNo
			,prd.ReferenceDocumentItemNo= stg.ReferenceDocumentItemNo
			,prd.MaterialNumber			= stg.MaterialNumber
			,prd.SiteCode				= stg.SiteCode
			,prd.ActualDeliveryQuantity	= stg.ActualDeliveryQuantity
			,prd.ActualDeliveryQuantityBaseUnit = stg.ActualDeliveryQuantityBaseUnit
			,prd.OriginalDeliveryQuantity = stg.OriginalDeliveryQuantity
			,prd.CreatedByUser           =stg.CreatedByUser
			,prd.DistributionChannel	 =stg.DistributionChannel
			,prd.StorageLocation		 =stg.StorageLocation
			,prd.ProfitCenter			 =stg.ProfitCenter
			,prd.SDProcessStatus		 =stg.SDProcessStatus
			,prd.RequirementSegment		 =stg.RequirementSegment
			,prd.StockSegment 			 =stg.StockSegment 
			,prd.ProductAvailabilityDate =stg.ProductAvailabilityDate
			,prd.ProductAvailabilityTime =stg.ProductAvailabilityTime
			,prd.IsDeleted				= stg.IsDeleted
			,prd.LDTS					= stg.LDTS
			,prd.HashDiff				= stg.HashDiff
			FROM #di AS stg JOIN biz.S4Hana_DeliveryDocumentItems AS prd 
				ON prd.DeliveryNoteItemNo = stg.DeliveryNoteItemNo AND prd.DeliveryNoteNumber = stg.DeliveryNoteNumber  
			WHERE stg.HashDiff <> prd.HashDiff

			UPDATE DTlogs
			SET Updated = @AffectedRows
			, ExecEnd = GETDATE()
			FROM etl.DataTransferLogs DTlogs
			WHERE DataTransferLogId = @DataTransferLogId
	
END