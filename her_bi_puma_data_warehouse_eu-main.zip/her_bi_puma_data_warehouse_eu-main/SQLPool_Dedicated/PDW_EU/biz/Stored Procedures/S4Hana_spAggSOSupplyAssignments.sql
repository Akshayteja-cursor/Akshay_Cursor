﻿CREATE PROC [biz].[S4Hana_spAggSOSupplyAssignments] @LDTS [DATETIME2](7) AS
BEGIN
    SET NOCOUNT ON
    SET ANSI_WARNINGS ON

    IF OBJECT_ID(N'tempdb..#SOsWithChangedSupplyAssignments') IS NOT NULL
        DROP TABLE #SOsWithChangedSupplyAssignments

    CREATE TABLE #SOsWithChangedSupplyAssignments
    WITH
    (
      DISTRIBUTION = HASH(SalesOrderNo)
    , CLUSTERED INDEX (SalesOrderNo, SalesOrderItemNo, IntPupMasterId)
    )
    AS
    SELECT DISTINCT
           sosa.SalesOrderNo
         , sosa.SalesOrderItemNo
         , i.IntPupMasterId
    FROM   biz.S4Hana_SOSupplyAssignments       sosa
    JOIN   pdwref.S4Hana_Interfaces             i ON sosa.SalesOrganizationCode = i.SalesOrg AND i.Interface = 'EBP'
    WHERE  sosa.LDTS >= @LDTS
    OPTION (LABEL = 'biz.S4Hana_spAggSOSupplyAssignments: IdentifyChangedSOsStatement')

    IF OBJECT_ID(N'tempdb..#AggSOSupplyAssignments') IS NOT NULL
        DROP TABLE #AggSOSupplyAssignments

    CREATE TABLE #AggSOSupplyAssignments
    WITH
    (
      DISTRIBUTION = HASH(SalesOrderNo)
    , CLUSTERED INDEX (SalesOrderNo, SalesOrderItemNo, IntPupMasterId)
    )
    AS
    SELECT
        PT.SalesOrderNo     --BK
      , PT.SalesOrderItemNo --BK
      , PT.IntPupMasterId
      , ISNULL(PT.[F], 0)   AS FQty
      , ISNULL(PT.[H], 0)   AS HQty
      , ISNULL(PT.[R], 0)   AS RQty
      , @LDTS               AS LDTS
      , CONVERT([BINARY](16),
            HASHBYTES('MD5',CONCAT(
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.SalesOrderNo)))),'_',     --BK
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.SalesOrderItemNo)))),'_', --BK
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.IntPupMasterId)))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[F])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[H])))),'_',  
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[R]))))))
        )                   AS HashDiff
    FROM
        (
            SELECT
                  sosa.SalesOrderNo
                , sosa.SalesOrderItemNo
                , sowcsa.IntPupMasterId
                , sosa.ARunStatus
                , SUM(CASE
                        WHEN sosa.IsDeleted = 1
                            THEN 0
                        ELSE sosa.AssignedQuantityARun
                      END) AS AssignedQuantityARun
            FROM  biz.S4Hana_SOSupplyAssignments    sosa
            JOIN  #SOsWithChangedSupplyAssignments  sowcsa ON sosa.SalesOrderNo = sowcsa.SalesOrderNo AND sosa.SalesOrderItemNo = sowcsa.SalesOrderItemNo
            GROUP BY
                  sosa.SalesOrderNo
                , sosa.SalesOrderItemNo
                , sowcsa.IntPupMasterId
                , sosa.ARunStatus
        ) AS ST
    PIVOT
    (
        MIN(ST.AssignedQuantityARun)
        FOR ARunStatus IN ([F], [H], [R])
    ) PT
    OPTION (LABEL = 'biz.S4Hana_spAggSOSupplyAssignments: PivotStatement')

   --update changed
    UPDATE
          dest
    SET          
          dest.IntPupMasterId = src.IntPupMasterId
        , dest.[FQty] = src.[FQty]
        , dest.[HQty] = src.[HQty]
        , dest.[RQty] = src.[RQty]
        , dest.LDTS = src.LDTS
        , dest.HashDiff = src.HashDiff
    FROM  biz.S4Hana_AggSOSupplyAssignments  AS dest
    JOIN  #AggSOSupplyAssignments            AS src ON src.SalesOrderNo = dest.SalesOrderNo AND src.SalesOrderItemNo = dest.SalesOrderItemNo
    WHERE dest.HashDiff <> src.HashDiff
    OPTION (LABEL = 'biz.S4Hana_spAggSOSupplyAssignments: UpdateStatement')

    --load new
    INSERT INTO biz.S4Hana_AggSOSupplyAssignments
    (
        SalesOrderNo        --BK
      , SalesOrderItemNo    --BK
      , IntPupMasterId       
      , [FQty]
      , [HQty]
      , [RQty]
      , LDTS
      , HashDiff
    )
    SELECT
              src.SalesOrderNo      --BK
            , src.SalesOrderItemNo  --BK
            , src.IntPupMasterId    
            , src.[FQty]
            , src.[HQty]
            , src.[RQty]
            , src.LDTS
            , src.HashDiff
    FROM      #AggSOSupplyAssignments            AS src
    LEFT JOIN biz.S4Hana_AggSOSupplyAssignments  AS dest ON src.SalesOrderNo = dest.SalesOrderNo AND src.SalesOrderItemNo = dest.SalesOrderItemNo AND src.IntPupMasterId = dest.IntPupMasterId
    WHERE     dest.SalesOrderNo IS NULL
    OPTION (LABEL = 'biz.S4Hana_spAggSOSupplyAssignments: InsertStatement')
END