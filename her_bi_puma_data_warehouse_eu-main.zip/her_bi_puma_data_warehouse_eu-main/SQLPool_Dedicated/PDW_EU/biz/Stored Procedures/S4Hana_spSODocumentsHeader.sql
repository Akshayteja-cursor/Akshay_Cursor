﻿CREATE PROC [biz].[S4Hana_spSODocumentsHeader] @ldts [DATETIME2](7) AS
BEGIN
	SET NOCOUNT ON;
	SET ANSI_WARNINGS ON;

	DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
	DECLARE @ExecStart DATETIME2(7) = GETDATE()
	DECLARE @SourceLastLoadDate DATETIME2(7)
	DECLARE @DestinationLastLoadDate DATETIME2(7)
	DECLARE @BatchLdts DATETIME2(7) = @LDTS
	DECLARE @AffectedRows BIGINT = NULL

	IF(EXISTS(SELECT 1 FROM [biz].[S4Hana_SODocumentsHeader]))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(LDTS))
	FROM [biz].[S4Hana_SODocumentsHeader]
	END
	ELSE BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

	IF(EXISTS(SELECT 1 FROM stag.[S4Hana_SODocumentsHeader]))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(_LDTS))
		FROM stag.[S4Hana_SODocumentsHeader]
	END
	ELSE BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END 

	--Log Data load
	INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'S4Hana_spSODocumentsHeader'
			,'biz_SODocuments'
			,'S4Hana_SODocumentsHeader'
			,'Stag'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts

	IF OBJECT_ID(N'tempdb..#del') IS NOT NULL
	DROP TABLE #del;

	SELECT NatSalesOrderNo, MAX(SOTypeCode) SOTypeCode
	INTO #del
	FROM biz.S4Hana_SoDocumentItemDeletionAttributes 
	WHERE NatSalesOrderNo in 
	(SELECT distinct [SalesDocument] from stag.S4hana_fnSODocumentsHeader('1900-01-01'))
	GROUP BY NatSalesOrderNo
	

	IF OBJECT_ID(N'tempdb..#soh') IS NOT NULL
	DROP TABLE #soh;

	SELECT 
	     soh.[SalesDocument]
		,soh.[NameOfOrderer]
		,soh.[version]
		,soh.[Customdata2]
		,soh.[Searchproductproposal]
		,soh.[SDDocumentCategory]
		,CASE WHEN soh.[IsDeleted] = 0 THEN soh.[SalesDocumentType] ELSE DEL.SOTypeCode END AS SalesDocumentType
		,soh.[OverallPurchaseConfStatus]
		,soh.[CreationDate]
		,soh.[OverallBillingBlockStatus]
		,soh.[OverallDeliveryBlockStatus]
		,soh.[StatisticsCurrency]
		,soh.[SalesOrganization]
		,soh.[DistributionChannel]
		,soh.[SalesGroup]
		,soh.[SalesOffice]
		,soh.[CustomerPurchaseOrderSuplmnt]
		,soh.[AdditionalCustomerGroup1]
		,soh.[AdditionalCustomerGroup2]
		,soh.[AdditionalCustomerGroup3]
		,soh.[AdditionalCustomerGroup4]
		,soh.[AdditionalCustomerGroup5]
		,soh.[SDDocumentReason]
		,soh.[RequestedDeliveryDate]
		,soh.[DeliveryBlockReason]
		,soh.[BindingPeriodValidityEndDate]
		,soh.[BillingCompanyCode]
		,soh.[HeaderBillingBlockReason]
		,soh.[ExchangeRateType]
		,soh.[OverallTotalDeliveryStatus]
		,soh.[OverallOrdReltdBillgStatus]
		,soh.[OverallSDDocumentRejectionSts]
		,soh.[OverallDelivConfStatus]
		,soh.[OverallDeliveryStatus]
		,soh.[CustomerPurchaseOrderDate]
		,soh.[AgrmtValdtyStartDate]
		,soh.[AgrmtValdtyEndDate]
		,soh.[ShippingCondition]
		,soh.[SDDocumentCollectiveNumber]
		,soh.[CreatedByUser]
		,soh.[CustomerReference]
		,soh.[BindingPeriodValidityStartDate]
		,soh.[SalesDocumentDate]
		,soh.[DeliveryWindowStart]
		,soh.[DeliveryWindowEnd]
		,soh.[IsDeleted]
		,soh.[LDTS]
		,CONVERT([BINARY](16),
				HASHBYTES('MD5',CONCAT(
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[SalesDocument]                        )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[NameOfOrderer]            			  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[version]							  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[Customdata2]						  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[Searchproductproposal]				  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[SDDocumentCategory]					  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),CASE WHEN soh.[IsDeleted] = 0 THEN soh.[SalesDocumentType] ELSE DEL.SOTypeCode END)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[OverallPurchaseConfStatus]			  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[CreationDate]						  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[OverallBillingBlockStatus]			  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[OverallDeliveryBlockStatus]			  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[StatisticsCurrency]					  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[SalesOrganization]					  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[DistributionChannel]				  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[SalesGroup]							  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[SalesOffice]						  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[CustomerPurchaseOrderSuplmnt]		  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[AdditionalCustomerGroup1]			  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[AdditionalCustomerGroup2]			  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[AdditionalCustomerGroup3]			  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[AdditionalCustomerGroup4]			  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[AdditionalCustomerGroup5]			  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[SDDocumentReason]					  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[RequestedDeliveryDate]				  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[DeliveryBlockReason]				  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[BindingPeriodValidityEndDate]		  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[BillingCompanyCode]					  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[HeaderBillingBlockReason]			  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[ExchangeRateType]					  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[OverallTotalDeliveryStatus]			  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[OverallOrdReltdBillgStatus]			  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[OverallSDDocumentRejectionSts]		  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[OverallDelivConfStatus]				  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[OverallDeliveryStatus]				  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[CustomerPurchaseOrderDate]			  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[AgrmtValdtyStartDate]				  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[AgrmtValdtyEndDate]					  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[ShippingCondition]					  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[SDDocumentCollectiveNumber]			  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[CreatedByUser]						  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[CustomerReference]					  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[BindingPeriodValidityStartDate]		  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[SalesDocumentDate]					  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[DeliveryWindowStart]				  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[DeliveryWindowEnd]					  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),soh.[IsDeleted]))))
	
			))) AS HashDiff
		INTO #soh
		FROM stag.S4hana_fnSODocumentsHeader('1900-01-01') AS soh
		INNER JOIN #Del as del
		ON soh.SalesDocument = Del.NatSalesOrderNo

		-- count new Records for S4Hana_SODocumentsHeader
		SELECT @AffectedRows = COUNT(*)
			FROM #soh AS stg LEFT JOIN biz.S4Hana_SODocumentsHeader AS prd 
			ON prd.[SalesDocument] = stg.[SalesDocument]
			WHERE prd.[SalesDocument] IS NULL

   --load new
   INSERT INTO biz.S4Hana_SODocumentsHeader
			(
				 [SalesDocument]
				,[NameOfOrderer]
				,[version]
				,[Customdata2]
				,[Searchproductproposal]
				,[SDDocumentCategory]
				,[SalesDocumentType]
				,[OverallPurchaseConfStatus]
				,[CreationDate]
				,[OverallBillingBlockStatus]
				,[OverallDeliveryBlockStatus]
				,[StatisticsCurrency]
				,[SalesOrganization]
				,[DistributionChannel]
				,[SalesGroup]
				,[SalesOffice]
				,[CustomerPurchaseOrderSuplmnt]
				,[AdditionalCustomerGroup1]
				,[AdditionalCustomerGroup2]
				,[AdditionalCustomerGroup3]
				,[AdditionalCustomerGroup4]
				,[AdditionalCustomerGroup5]
				,[SDDocumentReason]
				,[RequestedDeliveryDate]
				,[DeliveryBlockReason]
				,[BindingPeriodValidityEndDate]
				,[BillingCompanyCode]
				,[HeaderBillingBlockReason]
				,[ExchangeRateType]
				,[OverallTotalDeliveryStatus]
				,[OverallOrdReltdBillgStatus]
				,[OverallSDDocumentRejectionSts]
				,[OverallDelivConfStatus]
				,[OverallDeliveryStatus]
				,[CustomerPurchaseOrderDate]
				,[AgrmtValdtyStartDate]
				,[AgrmtValdtyEndDate]
				,[ShippingCondition]
				,[SDDocumentCollectiveNumber]
				,[CreatedByUser]
				,[CustomerReference]
				,[BindingPeriodValidityStartDate]
				,[SalesDocumentDate]
				,[DeliveryWindowStart]
				,[DeliveryWindowEnd]
				,[IsDeleted]
				,[LDTS]
				,[HashDiff]
			
			)
	SELECT 
				 stg.[SalesDocument]
				,stg.[NameOfOrderer]
				,stg.[version]
				,stg.[Customdata2]
				,stg.[Searchproductproposal]
				,stg.[SDDocumentCategory]
				,stg.[SalesDocumentType]
				,stg.[OverallPurchaseConfStatus]
				,stg.[CreationDate]
				,stg.[OverallBillingBlockStatus]
				,stg.[OverallDeliveryBlockStatus]
				,stg.[StatisticsCurrency]
				,stg.[SalesOrganization]
				,stg.[DistributionChannel]
				,stg.[SalesGroup]
				,stg.[SalesOffice]
				,stg.[CustomerPurchaseOrderSuplmnt]
				,stg.[AdditionalCustomerGroup1]
				,stg.[AdditionalCustomerGroup2]
				,stg.[AdditionalCustomerGroup3]
				,stg.[AdditionalCustomerGroup4]
				,stg.[AdditionalCustomerGroup5]
				,stg.[SDDocumentReason]
				,stg.[RequestedDeliveryDate]
				,stg.[DeliveryBlockReason]
				,stg.[BindingPeriodValidityEndDate]
				,stg.[BillingCompanyCode]
				,stg.[HeaderBillingBlockReason]
				,stg.[ExchangeRateType]
				,stg.[OverallTotalDeliveryStatus]
				,stg.[OverallOrdReltdBillgStatus]
				,stg.[OverallSDDocumentRejectionSts]
				,stg.[OverallDelivConfStatus]
				,stg.[OverallDeliveryStatus]
				,stg.[CustomerPurchaseOrderDate]
				,stg.[AgrmtValdtyStartDate]
				,stg.[AgrmtValdtyEndDate]
				,stg.[ShippingCondition]
				,stg.[SDDocumentCollectiveNumber]
				,stg.[CreatedByUser]
				,stg.[CustomerReference]
				,stg.[BindingPeriodValidityStartDate]
				,stg.[SalesDocumentDate]
				,stg.[DeliveryWindowStart]
				,stg.[DeliveryWindowEnd]
				,stg.[IsDeleted]
				,stg.[LDTS]
				,stg.[HashDiff]
		 FROM #soh AS stg LEFT JOIN biz.S4Hana_SODocumentsHeader AS prd 
			ON prd.[SalesDocument] = stg.[SalesDocument]
		 WHERE prd.[SalesDocument] IS NULL
	
		UPDATE DTlogs
		SET Inserted = @AffectedRows
		FROM etl.DataTransferLogs DTlogs
		WHERE DataTransferLogId = @DataTransferLogId


		-- count new Records for S4Hana_SODocumentsHeader
		SELECT @AffectedRows = COUNT(*)
		FROM #soh AS stg JOIN biz.S4Hana_SODocumentsHeader AS prd 
		ON prd.[SalesDocument] = stg.[SalesDocument]
		WHERE stg.HashDiff <> prd.HashDiff


		  UPDATE prd SET	
				 prd.[NameOfOrderer]                     =    stg.[NameOfOrderer]
				,prd.[version]							 =    stg.[version]
				,prd.[Customdata2]						 =    stg.[Customdata2]
				,prd.[Searchproductproposal]			 =    stg.[Searchproductproposal]
				,prd.[SDDocumentCategory]				 =    stg.[SDDocumentCategory]
				,prd.[SalesDocumentType]				 =    stg.[SalesDocumentType]
				,prd.[OverallPurchaseConfStatus]		 =    stg.[OverallPurchaseConfStatus]
				,prd.[CreationDate]						 =    stg.[CreationDate]
				,prd.[OverallBillingBlockStatus]		 =    stg.[OverallBillingBlockStatus]
				,prd.[OverallDeliveryBlockStatus]		 =    stg.[OverallDeliveryBlockStatus]
				,prd.[StatisticsCurrency]				 =    stg.[StatisticsCurrency]
				,prd.[SalesOrganization]				 =    stg.[SalesOrganization]
				,prd.[DistributionChannel]				 =    stg.[DistributionChannel]
				,prd.[SalesGroup]						 =    stg.[SalesGroup]
				,prd.[SalesOffice]						 =    stg.[SalesOffice]
				,prd.[CustomerPurchaseOrderSuplmnt]		 =    stg.[CustomerPurchaseOrderSuplmnt]
				,prd.[AdditionalCustomerGroup1]			 =    stg.[AdditionalCustomerGroup1]
				,prd.[AdditionalCustomerGroup2]			 =    stg.[AdditionalCustomerGroup2]
				,prd.[AdditionalCustomerGroup3]			 =    stg.[AdditionalCustomerGroup3]
				,prd.[AdditionalCustomerGroup4]			 =    stg.[AdditionalCustomerGroup4]
				,prd.[AdditionalCustomerGroup5]			 =    stg.[AdditionalCustomerGroup5]
				,prd.[SDDocumentReason]					 =    stg.[SDDocumentReason]
				,prd.[RequestedDeliveryDate]			 =    stg.[RequestedDeliveryDate]
				,prd.[DeliveryBlockReason]				 =    stg.[DeliveryBlockReason]
				,prd.[BindingPeriodValidityEndDate]		 =    stg.[BindingPeriodValidityEndDate]
				,prd.[BillingCompanyCode]				 =    stg.[BillingCompanyCode]
				,prd.[HeaderBillingBlockReason]			 =    stg.[HeaderBillingBlockReason]
				,prd.[ExchangeRateType]					 =    stg.[ExchangeRateType]
				,prd.[OverallTotalDeliveryStatus]		 =    stg.[OverallTotalDeliveryStatus]
				,prd.[OverallOrdReltdBillgStatus]		 =    stg.[OverallOrdReltdBillgStatus]
				,prd.[OverallSDDocumentRejectionSts]	 =    stg.[OverallSDDocumentRejectionSts]
				,prd.[OverallDelivConfStatus]			 =    stg.[OverallDelivConfStatus]
				,prd.[OverallDeliveryStatus]			 =    stg.[OverallDeliveryStatus]
				,prd.[CustomerPurchaseOrderDate]		 =    stg.[CustomerPurchaseOrderDate]
				,prd.[AgrmtValdtyStartDate]				 =    stg.[AgrmtValdtyStartDate]
				,prd.[AgrmtValdtyEndDate]				 =    stg.[AgrmtValdtyEndDate]
				,prd.[ShippingCondition]				 =    stg.[ShippingCondition]
				,prd.[SDDocumentCollectiveNumber]		 =    stg.[SDDocumentCollectiveNumber]
				,prd.[CreatedByUser]					 =    stg.[CreatedByUser]
				,prd.[CustomerReference]				 =    stg.[CustomerReference]
				,prd.[BindingPeriodValidityStartDate]	 =    stg.[BindingPeriodValidityStartDate]
				,prd.[SalesDocumentDate]				 =    stg.[SalesDocumentDate]
				,prd.[DeliveryWindowStart]				 =    stg.[DeliveryWindowStart]
				,prd.[DeliveryWindowEnd]				 =    stg.[DeliveryWindowEnd]
				,prd.[IsDeleted]						 =    stg.[IsDeleted]
				,prd.[LDTS]								 =    stg.[LDTS]
				,prd.[HashDiff]							 =    stg.[HashDiff]

			FROM #soh AS stg JOIN biz.S4Hana_SODocumentsHeader AS prd 
				ON prd.[SalesDocument] = stg.[SalesDocument]
			WHERE stg.HashDiff <> prd.HashDiff

			UPDATE DTlogs
			SET Updated = @AffectedRows
			, ExecEnd = GETDATE()
			FROM etl.DataTransferLogs DTlogs
			WHERE DataTransferLogId = @DataTransferLogId


END

--truncate table biz.S4Hana_SODocumentsHeader
--exec [biz].[S4Hana_spSODocumentsHeader]'1900-01-01'