﻿CREATE PROC [biz].[S4Hana_spBPAddressEmail] @ldts [DATETIME2](7) AS
BEGIN
	SET NOCOUNT ON;
	SET ANSI_WARNINGS ON;

	DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
	DECLARE @ExecStart DATETIME2(7) = GETDATE()
	DECLARE @SourceLastLoadDate DATETIME2(7)
	DECLARE @DestinationLastLoadDate DATETIME2(7)
	DECLARE @BatchLdts DATETIME2(7) = @LDTS
	DECLARE @AffectedRows BIGINT = NULL

	IF(EXISTS(SELECT 1 FROM [biz].[S4Hana_BPAddressEmail]))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(LDTS))
	FROM [biz].[S4Hana_BPAddressEmail]
	END
	ELSE BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

	IF(EXISTS(SELECT 1 FROM stag.[S4Hana_BPAddressEmail]))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(_LDTS))
		FROM stag.[S4Hana_BPAddressEmail]
	END
	ELSE BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END 


	--Log Data load
	INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'S4Hana_spBPAddressEmail'
			,'biz_BPAddressEmails'
			,'S4Hana_BPAddressEmail'
			,'biz'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts


	IF OBJECT_ID(N'tempdb..#email') IS NOT NULL
	DROP TABLE #email;

	SELECT
	   CONCAT(BusinessPartner, '|', addrnumber, '|', persnumber, '|', ValidFromDflt, '|', SequenceNumber) AS BPAddressEmail_BK
	  ,[BusinessPartner]                               
      ,[AddressNumber]
      ,[StrdAddress]
      ,[addrnumber]
      ,[persnumber]
      ,[ValidFromDflt]
      ,[SequenceNumber]
      ,[StdSender]
      ,[NotUsed]
      ,[HomeFlag]
      ,[EmailAddress]
      ,[FlagStdRecipient]
      ,[COnSapSys]
      ,[RequiredEncoding]
      ,[TNEFEncode]
      ,[ValidFrom]
      ,[ValidTo]
	  ,IsDeleted       
      ,[_LDTS] as LDTS
	  ,CONVERT([BINARY](16),
				HASHBYTES('MD5',CONCAT(
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [BusinessPartner]  )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [AddressNumber]    )))),'_',  
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [StrdAddress]	  )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [addrnumber]		  )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [persnumber]		  )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [ValidFromDflt]	  )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [SequenceNumber]	  )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [StdSender]		  )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [NotUsed]		  )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [HomeFlag]		  )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [EmailAddress]	  )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [FlagStdRecipient] )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [COnSapSys]		  )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [RequiredEncoding] )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [TNEFEncode]		  )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [ValidFrom]		  )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [ValidTo]		  )))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [IsDeleted]))))))       
			) AS HashDiff

INTO #email
FROM
(
	SELECT
	   *
	  ,CAST(CASE WHEN __operation_type = 'X' 
					THEN 1 ELSE 0 END AS BIT)					AS IsDeleted
      ,ROW_NUMBER() OVER (PARTITION BY BusinessPartner
									, addrnumber
									, persnumber	
									, ValidFromDflt
									, SequenceNumber
						ORDER BY _LDTS DESC
								, __timestamp DESC)				AS RN
	FROM [stag].[S4Hana_BPAddressEmail]
) X
WHERE RN = 1 
and (EmailAddress <> '' or IsDeleted=1) 
and [_LDTS] > @ldts
	
		-- count new Records for S4Hana_BPAddressEmail
		    SELECT @AffectedRows = COUNT(*)
			FROM #email AS stg LEFT JOIN biz.S4Hana_BPAddressEmail AS prd 
			ON prd.BPAddressEmail_BK = stg.BPAddressEmail_BK 
			WHERE prd.BPAddressEmail_BK IS NULL

   --load new
   INSERT INTO biz.S4Hana_BPAddressEmail
			(
				 BPAddressEmail_BK
	            ,[BusinessPartner]                               
                ,[AddressNumber]
                ,[StrdAddress]
                ,[addrnumber]
                ,[persnumber]
                ,[ValidFromDflt]
                ,[SequenceNumber]
                ,[StdSender]
                ,[NotUsed]
                ,[HomeFlag]
                ,[EmailAddress]
                ,[FlagStdRecipient]
                ,[COnSapSys]
                ,[RequiredEncoding]
                ,[TNEFEncode]
                ,[ValidFrom]
                ,[ValidTo]
	            ,IsDeleted       
                ,LDTS
				,[HashDiff]			
			)
	SELECT 
				 stg.BPAddressEmail_BK
				,stg.[BusinessPartner] 
				,stg.[AddressNumber]
				,stg.[StrdAddress]
				,stg.[addrnumber]
				,stg.[persnumber]
				,stg.[ValidFromDflt]
				,stg.[SequenceNumber]
				,stg.[StdSender]
				,stg.[NotUsed]
				,stg.[HomeFlag]
				,stg.[EmailAddress]
				,stg.[FlagStdRecipient]
				,stg.[COnSapSys]
				,stg.[RequiredEncoding]
				,stg.[TNEFEncode]
				,stg.[ValidFrom]
				,stg.[ValidTo]
				,stg.IsDeleted       
				,stg.LDTS
				,stg.[HashDiff]

		 FROM #email AS stg LEFT JOIN biz.S4Hana_BPAddressEmail AS prd 
		 ON prd.BPAddressEmail_BK = stg.BPAddressEmail_BK 
		 WHERE prd.BPAddressEmail_BK IS NULL
	
		UPDATE DTlogs
		SET Inserted = @AffectedRows
		FROM etl.DataTransferLogs DTlogs
		WHERE DataTransferLogId = @DataTransferLogId


		-- count new Records for S4Hana_BPAddressEmail
		SELECT @AffectedRows = COUNT(*)
		FROM #email AS stg JOIN biz.S4Hana_BPAddressEmail AS prd 
		ON prd.BPAddressEmail_BK = stg.BPAddressEmail_BK
		WHERE stg.HashDiff <> prd.HashDiff

		UPDATE DTlogs
		SET Updated = @AffectedRows
		, ExecEnd = GETDATE()
		FROM etl.DataTransferLogs DTlogs
		WHERE DataTransferLogId = @DataTransferLogId

		--update non deleted records
		  UPDATE prd SET	
				 prd.BPAddressEmail_BK  = stg.BPAddressEmail_BK
				,prd.[BusinessPartner] 	= stg.[BusinessPartner] 
				,prd.[AddressNumber]	= stg.[AddressNumber]
				,prd.[StrdAddress]		= stg.[StrdAddress]
				,prd.[addrnumber]		= stg.[addrnumber]
				,prd.[persnumber]		= stg.[persnumber]
				,prd.[ValidFromDflt]	= stg.[ValidFromDflt]
				,prd.[SequenceNumber]	= stg.[SequenceNumber]
				,prd.[StdSender]		= stg.[StdSender]
				,prd.[NotUsed]			= stg.[NotUsed]
				,prd.[HomeFlag]			= stg.[HomeFlag]
				,prd.[EmailAddress]		= stg.[EmailAddress]
				,prd.[FlagStdRecipient]	= stg.[FlagStdRecipient]
				,prd.[COnSapSys]		= stg.[COnSapSys]
				,prd.[RequiredEncoding]	= stg.[RequiredEncoding]
				,prd.[TNEFEncode]		= stg.[TNEFEncode]
				,prd.[ValidFrom]		= stg.[ValidFrom]
				,prd.[ValidTo]			= stg.[ValidTo]
				,prd.IsDeleted       	= stg.IsDeleted       
				,prd.LDTS				= stg.LDTS
				,prd.[HashDiff]			= stg.[HashDiff]



			FROM #email AS stg JOIN biz.S4Hana_BPAddressEmail AS prd 
			ON prd.BPAddressEmail_BK = stg.BPAddressEmail_BK
			WHERE stg.HashDiff <> prd.HashDiff and stg.IsDeleted = 0

		 --update deletions (only deleted status and LDTS)
		 UPDATE prd SET
				 prd.LDTS				= stg.LDTS
				,prd.IsDeleted			= stg.IsDeleted
				,prd.[HashDiff]			= stg.[HashDiff]
		 	FROM #email AS stg JOIN biz.S4Hana_BPAddressEmail AS prd 
			ON prd.BPAddressEmail_BK = stg.BPAddressEmail_BK
			WHERE stg.HashDiff <> prd.HashDiff and stg.IsDeleted = 1


END

--truncate table biz.S4Hana_BPAddressEmail
-- exec [biz].[S4Hana_spBPAddressEmail]'1900-01-01'