﻿CREATE PROC [biz].[S4Hana_spFreeAvailableStocksHistory] @LDTS [DATETIME2](7) AS
BEGIN
SET NOCOUNT ON
/*DECLARE @LDTS DATETIME2(7) = '2000-01-01'*/
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(7) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(7)
DECLARE @DestinationLastLoadDate DATETIME2(7)
DECLARE @BatchLdts DATETIME2(7) = @LDTS

/* do not use the input parameter, in case of an failure or reload situartion take the last tranfered LDTS from the Hist table*/
IF(EXISTS(SELECT 1 FROM biz.S4Hana_FreeAvailableStocksHistory))
BEGIN
	SELECT @DestinationLastLoadDate = MAX(LDTS)
	FROM biz.S4Hana_FreeAvailableStocksHistory
END
ELSE BEGIN
	SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
END 

IF(EXISTS(SELECT 1 FROM stag.S4Hana_FreeAvailableStock))
BEGIN
	SELECT @SourceLastLoadDate = MAX(_LDTS)
	FROM stag.S4Hana_FreeAvailableStock
END
ELSE BEGIN
	SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
END 

--Log Data load
INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'spFreeAvailableStocksHistory'
			,'prepFASH'
			,'FreeAvailableStocks'
			,'sourcing'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts

IF OBJECT_ID('tempdb..#FreeAvailableStocksFullLast') IS NOT NULL
BEGIN
    DROP TABLE #FreeAvailableStocksFullLast
END

CREATE TABLE #FreeAvailableStocksFullLast
WITH
(DISTRIBUTION = HASH(Material)
,HEAP)
AS
WITH CteStagFAS AS (
            SELECT		 
						SHFAS.Plant
						,SHFAS.Material
						,CASE WHEN SHFAS.StockSegment='' THEN SHFAS.RequirementSegment ELSE SHFAS.StockSegment END StockSegment
						,SHFAS.MRPElement
						,CONVERT(DECIMAL(15,3), SHFAS.quantity) AS RunningTotal
						,SHFAS.BaseUnitOfMeasure
						,DATEADD(DAY, -1, CONVERT(DATE, DATEADD(s, __timestamp / 1000000, CONVERT(DATETIME, '1-1-1970 00:00:00')))) AS PostingDate
						,ROW_NUMBER() OVER(PARTITION BY SHFAS.Plant, SHFAS.Material, SHFAS.RequirementSegment, SHFAS.StockSegment, DATEADD(DAY, -1, CONVERT(DATE, DATEADD(s, __timestamp / 1000000, CONVERT(DATETIME, '1-1-1970 00:00:00')))) ORDER BY SHFAS.MRPElement DESC, SHFAS.__timestamp) AS Rnk
						,_LDTS as LDTS
			FROM stag.S4Hana_FreeAvailableStock AS SHFAS
			WHERE   SHFAS._LDTS>@DestinationLastLoadDate
					AND (SHFAS.MRPElement='WB' OR SHFAS.__operation_type='X')
					AND CASE WHEN SHFAS.StockSegment='' THEN SHFAS.RequirementSegment ELSE SHFAS.StockSegment END='WHS'	
					--AND SHFAS.Material='021269-07-110'
)
/*cte required to get one row per POSTINGDATE*/
,CTE_one_pd as (
select Plant
	  ,Material
	  ,StockSegment
	  ,PostingDate
	  ,max(BaseUnitOfMeasure) BaseUnitOfMeasure
	  ,max(MRPElement) MRPElement
	  ,max(RunningTotal) RunningTotal
	  ,max(LDTS) LDTS
	  from CteStagFAS
	  WHERE CteStagFAS.Rnk = 1
	  group by Plant
	  ,Material
	  ,StockSegment
	  ,PostingDate
)
SELECT Plant
	  ,Material
	  ,StockSegment
	  ,MRPElement
	  ,RunningTotal
	  ,BaseUnitOfMeasure  
	  ,PostingDate
	  ,CONVERT(BINARY(16), 
		HASHBYTES('MD5',CONCAT(
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),Plant)))),'_', 
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),Material)))),'_', 
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),StockSegment)))),'_',  
	/*  UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),MRPElement)))),'_',  taken out to get rid of spare records without RunningTotal changes
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),BaseUnitOfMeasure)))) taken out to get rid of spare records without RunningTotal changes*/
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),RunningTotal))))
	  ))) AS HashDiff
	  ,LDTS
	  ,CONVERT(TINYINT,1) AS SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist
FROM CTE_one_pd

OPTION (LABEL='etl.S4Hana_spFreeAvailableStocksHistory : #FreeAvailableStocksFullLast ScoId1')

-- Add last entires from Hist which are in the new batch
INSERT INTO #FreeAvailableStocksFullLast
	(Plant
    ,Material
    ,StockSegment
    ,MRPElement
    ,RunningTotal
    ,BaseUnitOfMeasure  
    ,PostingDate
    ,HashDiff
	,LDTS
    ,SourceIdentifier)
SELECT 
     FASH.Plant
    ,FASH.Material
    ,FASH.StockSegment
    ,FASH.MRPElement
    ,FASH.RunningTotal
    ,FASH.BaseUnitOfMeasure 
    ,FASH.PostingDate
	,FASH.HashDiff
	,FASH.LDTS
	,CONVERT(TINYINT,2) AS SourceIdentifier --> 1 = new from Stag ; 2 = last entry from biz Hist
	FROM #FreeAvailableStocksFullLast AS stagNew
	INNER JOIN biz.S4Hana_FreeAvailableStocksHistory AS FASH
		ON 	stagNew.Plant              =FASH.Plant             
		AND stagNew.Material		   =FASH.Material		  
		AND stagNew.StockSegment	   =FASH.StockSegment		  
		AND FASH.PostingDateValidTo = '9999-12-31' ---> Get latest entry from the hist table 
OPTION (LABEL='etl.S4Hana_spFreeAvailableStocksHistory : #FreeAvailableStocksFullLast ScoId2')

TRUNCATE TABLE etl.S4Hana_FreeAvailableStocksHistory
;WITH preHash AS (
	 SELECT Plant
		   ,Material
		   ,StockSegment
		   ,MRPElement
		   ,RunningTotal
		   ,BaseUnitOfMeasure 
		   ,PostingDate
		   ,HashDiff
		   ,LDTS
		   ,SourceIdentifier
		   ,LAG(HashDiff) OVER (PARTITION BY Plant,Material,StockSegment ORDER BY PostingDate, SourceIdentifier DESC) AS pre_HashDiff -- Add SourceIdentifier rank to take first the existing Data in case there are the same content in the source
		   ,ROW_NUMBER() OVER (PARTITION BY Plant,Material,StockSegment ORDER BY PostingDate, SourceIdentifier DESC) AS RankOverAll
	FROM #FreeAvailableStocksFullLast
)
,DiffCheck AS (
	SELECT Plant
		  ,Material
		  ,StockSegment
		  ,MRPElement
		  ,RunningTotal
		  ,BaseUnitOfMeasure 
		  ,PostingDate
		  ,ISNULL(LEAD(PostingDate) OVER (PARTITION BY Plant, Material, StockSegment  ORDER BY PostingDate),'9999-12-31') AS PostingDateValidTo
		  ,HashDiff
		  ,LDTS
		  ,SourceIdentifier
	FROM preHash
	WHERE HashDiff <> pre_HashDiff
	   OR RankOverAll = 1 -- to get the first entry
)
INSERT INTO etl.S4Hana_FreeAvailableStocksHistory
	   (Plant
	   ,Material
	   ,StockSegment
	   ,PostingDate
	   ,PostingDateValidTo
	   ,MRPElement
	   ,RunningTotal
	   ,BaseUnitOfMeasure 
	   ,HashDiff
	   ,LDTS
	   ,SourceIdentifier)
SELECT Plant
	   ,Material
	   ,StockSegment
	   ,PostingDate
	   ,PostingDateValidTo
	   ,MRPElement
	   ,RunningTotal
	   ,BaseUnitOfMeasure 
	   ,HashDiff
	   ,LDTS
	   ,SourceIdentifier
FROM DiffCheck
WHERE SourceIdentifier = 1 -- only new entiers 
	OR (SourceIdentifier = 2 AND PostingDateValidTo <> '9999-12-31') -- existing entries to update PostingDateValidTo in the HIST table 
OPTION (LABEL='etl.S4Hana_spFreeAvailableStocksHistory : S4Hana_FreeAvailableStocksHistoryNew')

BEGIN TRAN -- Make sure Insert and Update are done in the same transaction
-- Insert new entries to S4Hana_FreeAvailableStocksHistory
	INSERT INTO biz.S4Hana_FreeAvailableStocksHistory
	   (Plant
	   ,Material
	   ,StockSegment
	   ,PostingDate
	   ,PostingDateValidTo
	   ,MRPElement
	   ,RunningTotal
	   ,BaseUnitOfMeasure 
	   ,HashDiff
	   ,LDTS)
SELECT Plant
	   ,Material
	   ,StockSegment
	   ,PostingDate
	   ,PostingDateValidTo
	   ,MRPElement
	   ,RunningTotal
	   ,BaseUnitOfMeasure 
	   ,HashDiff
	   ,LDTS
	FROM etl.S4Hana_FreeAvailableStocksHistory
	WHERE SourceIdentifier = 1 -- only new entiers 

	--Update PostingDateValidTo for entires with fresh inserted entries for this BK
	UPDATE histPre
	SET histPre.PostingDateValidTo = new.PostingDateValidTo
	FROM biz.S4Hana_FreeAvailableStocksHistory AS histPre
	INNER JOIN etl.S4Hana_FreeAvailableStocksHistory AS new
		ON 	histPre.Plant              =new.Plant             
		AND histPre.Material		   =new.Material		  
		AND histPre.StockSegment	   =new.StockSegment	
		AND histPre.LDTS = new.LDTS
	WHERE histPre.PostingDateValidTo = '9999-12-31'
	  AND new.SourceIdentifier = 2 -- only update Objects loaded from Hist table
COMMIT TRAN; 

-- Update End of the load
UPDATE DTlogs
SET ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

--exec [biz].[S4Hana_spFreeAvailableStocksHistory] '19000101'

END -- END SP