﻿CREATE PROC [biz].[S4Hana_spSoScheduleLinesHistory_onPrem] @LDTS [DATETIME2](7) AS
BEGIN
SET NOCOUNT ON

--DECLARE @LDTS DATETIME2(7) = '2000-01-01'
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(0) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(0)
DECLARE @DestinationLastLoadDate DATETIME2(0)
DECLARE @BatchLdts DATETIME2(0) = @LDTS

IF(EXISTS(SELECT 1 FROM biz.S4Hana_SoScheduleLinesHistory_onPrem))
BEGIN
	SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(LDTS))
	FROM biz.S4Hana_SoScheduleLinesHistory_onPrem
END
ELSE BEGIN
	SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
END 

IF(EXISTS(SELECT 1 FROM stag.S4Hana_SOScheduleLines_full_onPrem))
BEGIN
	SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(_LDTS))
	FROM stag.S4Hana_SOScheduleLines_full_onPrem
END
ELSE BEGIN
	SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
END 

--Log Data load
INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'spSoScheduleLinesHistory_onPrem'
			,'prepSoDocHist_OnPrem'
			,'NatSalesOrdersOohHistory_onPrem'
			,'sales'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts


IF OBJECT_ID('tempdb..#SoScheduleLinesFullLastIncrement') IS NOT NULL
BEGIN
    DROP TABLE #SoScheduleLinesFullLastIncrement
END

CREATE TABLE #SoScheduleLinesFullLastIncrement
WITH
(DISTRIBUTION = HASH(NatSalesOrderNo)
,HEAP)
AS WITH SOScheduleLines 
AS( SELECT CAST(stagSoDocSchLFull.VBELN AS NVARCHAR(10)) as NatSalesOrderNo
		  ,CAST(stagSoDocSchLFull.POSNR AS NVARCHAR(6)) as NatSalesOrderItemNo
		  ,CAST(stagSoDocSchLFull.ETENR AS NVARCHAR(4)) AS ScheduleLine
		  ,CAST(stagSoDocSchLFull.EDATU AS DATE) AS ScheduleLineDate
		  ,CAST(stagSoDocSchLFull.BMENG AS DECIMAL(13, 3)) AS ConfirmedOrderQuantity
		  ,CAST(CASE WHEN stagSoDocSchLFull.ODQ_CHANGEMODE = 'D' THEN 1 ELSE 0 END AS SMALLINT) AS IsDeleted
		  ,CAST(stagSoDocSchLFull._LDTS AS DateTime2(7)) as LDTS
		  ,ROW_NUMBER() OVER (PARTITION BY stagSoDocSchLFull.VBELN, stagSoDocSchLFull.POSNR, stagSoDocSchLFull.ETENR ,stagSoDocSchLFull._LDTS ORDER BY stagSoDocSchLFull.TS_SEQUENCE_NUMBER DESC) AS rn_PerLdts
	FROM stag.S4Hana_SOScheduleLines_full_onPrem AS stagSoDocSchLFull
	WHERE stagSoDocSchLFull._LDTS > @DestinationLastLoadDate 
)
SELECT NatSalesOrderNo
	  ,NatSalesOrderItemNo
	  ,ScheduleLine
	  ,ScheduleLineDate
	  ,ConfirmedOrderQuantity
	  ,IsDeleted
	  ,LDTS
	  ,CONVERT(BINARY(16), 
			HASHBYTES('MD5',CONCAT( 
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),NatSalesOrderNo)))),'_', 
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),NatSalesOrderItemNo)))),'_', 
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ScheduleLine)))),'_', 
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ScheduleLineDate)))),'_', 
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ConfirmedOrderQuantity)))),'_', 
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),IsDeleted))))
         ))) AS HashDiff 
	  ,CONVERT(TINYINT,1) AS SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist
FROM SOScheduleLines
WHERE rn_PerLdts = 1


-- Add last related entires from Hist which are in the new batch
INSERT INTO #SoScheduleLinesFullLastIncrement
	  (NatSalesOrderNo
      ,NatSalesOrderItemNo
      ,ScheduleLine
      ,ScheduleLineDate
      ,ConfirmedOrderQuantity
      ,IsDeleted
      ,LDTS
      ,HashDiff
	  ,SourceIdentifier)
SELECT SoSchHist.NatSalesOrderNo
	  ,SoSchHist.NatSalesOrderItemNo
	  ,SoSchHist.ScheduleLine
	  ,SoSchHist.ScheduleLineDate
	  ,SoSchHist.ConfirmedOrderQuantity
	  ,SoSchHist.IsDeleted
	  ,SoSchHist.LDTS
	  ,SoSchHist.HashDiff
	  ,CONVERT(TINYINT,2) AS SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist
FROM #SoScheduleLinesFullLastIncrement AS stagNew
INNER JOIN [biz].[S4Hana_SoScheduleLinesHistory_onPrem] AS SoSchHist
		ON stagNew.NatSalesOrderNo = SoSchHist.NatSalesOrderNo
		AND stagNew.NatSalesOrderItemNo = SoSchHist.NatSalesOrderItemNo
		AND stagNew.ScheduleLine = SoSchHist.ScheduleLine
		AND SoSchHist.LEDTS = '9999-12-31' ---> Get latest entrie from the hist table 

CREATE TABLE #SoScheduleLinesNew
WITH
(DISTRIBUTION = HASH(NatSalesOrderNo)
,HEAP)
AS WITH preHash 
AS( SELECT  NatSalesOrderNo
		   ,NatSalesOrderItemNo
		   ,ScheduleLine
		   ,ScheduleLineDate
		   ,ConfirmedOrderQuantity
		   ,IsDeleted
		   ,SourceIdentifier
		   ,LDTS
		   ,HashDiff
		   ,LAG(HashDiff) OVER (PARTITION BY NatSalesOrderNo, NatSalesOrderItemNo, ScheduleLine ORDER BY LDTS) AS pre_HashDiff
		   ,ROW_NUMBER() OVER (PARTITION BY NatSalesOrderNo, NatSalesOrderItemNo, ScheduleLine ORDER BY LDTS) AS RankOverAll
	FROM #SoScheduleLinesFullLastIncrement
)
,DiffCheck AS (	
	SELECT NatSalesOrderNo
		  ,NatSalesOrderItemNo
		  ,ScheduleLine
		  ,LDTS
		  ,ISNULL((DateAdd(ss ,-1, LEAD(LDTS) OVER (PARTITION BY NatSalesOrderNo, NatSalesOrderItemNo, ScheduleLine ORDER BY LDTS))),'9999-12-31') AS LEDTS
		  ,HashDiff
		  ,ScheduleLineDate
		  ,ConfirmedOrderQuantity
		  ,IsDeleted
		  ,SourceIdentifier
	FROM preHash
	WHERE HashDiff <> pre_HashDiff
	   OR RankOverAll = 1 -- to get the first entry
) 
SELECT NatSalesOrderNo
	  ,NatSalesOrderItemNo
	  ,ScheduleLine
	  ,LDTS
	  ,LEDTS
	  ,HashDiff
	  ,ScheduleLineDate
	  ,ConfirmedOrderQuantity
	  ,IsDeleted
	  ,SourceIdentifier
FROM DiffCheck
WHERE SourceIdentifier = 1 -- only new entiers 
  OR (SourceIdentifier = 2 AND LEDTS <> '9999-12-31') -- existing entries to update LEDTS in the HIST table 

-- Insert new entries to 
INSERT INTO biz.S4Hana_SoScheduleLinesHistory_onPrem
	  (NatSalesOrderNo
	  ,NatSalesOrderItemNo
	  ,ScheduleLine
      ,LDTS
      ,LEDTS
      ,HashDiff
	  ,ScheduleLineDate
	  ,ConfirmedOrderQuantity
	  ,IsDeleted)
SELECT NatSalesOrderNo
	  ,NatSalesOrderItemNo
	  ,ScheduleLine
	  ,LDTS
	  ,LEDTS
	  ,HashDiff
	  ,ScheduleLineDate
	  ,ConfirmedOrderQuantity
	  ,IsDeleted
FROM  #SoScheduleLinesNew
WHERE SourceIdentifier = 1 -- only new entiers 

--Update LEDTS for entires with fresh inserted entries for this BK
UPDATE histPre
SET histPre.LEDTS = new.LEDTS
FROM biz.S4Hana_SoScheduleLinesHistory_onPrem AS histPre
INNER JOIN #SoScheduleLinesNew AS new
	ON histPre.NatSalesOrderNo = new.NatSalesOrderNo  -- join over SalesOrderNo and not HashDiff because the distribution of the tables via SalesOrderNo order by LDTS
	AND histPre.NatSalesOrderItemNo = new.NatSalesOrderItemNo
	AND histPre.ScheduleLine = new.ScheduleLine
	AND histPre.LDTS = new.LDTS
WHERE histPre.LEDTS = '9999-12-31'
  AND new.SourceIdentifier = 2 -- only update Objects loaded from Hist table

-- Update End of the load
UPDATE DTlogs
SET ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

END -- END SP