﻿CREATE PROC [biz].[S4Hana_spDeliveryDocumentsHistory] @LDTS [DATETIME2](7) AS
BEGIN
SET NOCOUNT ON
--DECLARE @LDTS DATETIME2(7) = '2000-01-01'
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(7) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(7)
DECLARE @DestinationLastLoadDate DATETIME2(7)
DECLARE @BatchLdts DATETIME2(7) = @LDTS

-- do not use the input parameter, in case of an failur or reload situartion take the last tranfered LDTS from the Hist table
IF(EXISTS(SELECT 1 FROM biz.S4Hana_DeliveryDocumentsHistory))
BEGIN
	SELECT @DestinationLastLoadDate = MAX(LDTS)
	FROM biz.S4Hana_DeliveryDocumentsHistory
END
ELSE BEGIN
	SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
END 

IF(EXISTS(SELECT 1 FROM stag.S4Hana_DeliveryDocuments_full))
BEGIN
	SELECT @SourceLastLoadDate = MAX(_LDTS)
	FROM stag.S4Hana_DeliveryDocuments_full
END
ELSE BEGIN
	SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
END 


--Log Data load
INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'spDeliveryDocumentsHistory'
			,'prepSoDocHist'
			,'NatSalesOrdersOohHistory'
			,'sales'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts

IF OBJECT_ID('tempdb..#DeliveryDocumentsFullLast') IS NOT NULL
BEGIN
    DROP TABLE #DeliveryDocumentsFullLast
END

CREATE TABLE #DeliveryDocumentsFullLast
WITH
(DISTRIBUTION = HASH(DeliveryNoteNumber)
,HEAP)
AS(
SELECT stagDDocFull.DeliveryDocument AS DeliveryNoteNumber-- BK 
	  ,stagDDocFull._LDTS AS LDTS
	  ,ROW_NUMBER() OVER (PARTITION BY stagDDocFull.DeliveryDocument, stagDDocFull._LDTS ORDER BY stagDDocFull.__timestamp DESC) rn_PerLdts
	  ,CONVERT(BINARY(16),
  		  HASHBYTES('MD5', CONCAT(
		  		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),stagDDocFull.DeliveryDocument)))), '_',
		  		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),stagDDocFull.ActualGoodsMovementDate,126)))), '_',
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),stagDDocFull.OVERALLDELIVRELTDBILLGSTATUS)))), '_',
		  		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),CASE WHEN stagDDocFull.__operation_type = 'X' THEN 1 ELSE 0 END))))
	   ))) AS HashDiff
	  ,stagDDocFull.ActualGoodsMovementDate AS ActualGoodsMovementDate
	  ,stagDDocFull.OVERALLDELIVRELTDBILLGSTATUS as OverallBillingStatus
	  ,CONVERT(TINYINT,CASE WHEN stagDDocFull.__operation_type = 'X' THEN 1 ELSE 0 END) AS IsDeleted
	  ,CONVERT(TINYINT,1) AS SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist
FROM stag.S4Hana_DeliveryDocuments_full AS stagDDocFull
WHERE 1=1 
  AND stagDDocFull._LDTS > @DestinationLastLoadDate
  AND stagDDocFull.SDDocumentCategory IN('J','')
) 
OPTION (LABEL='etl.S4Hana_spDeliveryDocumentsHistory : #DeliveryDocumentsFullLast ScoId1')

INSERT INTO #DeliveryDocumentsFullLast
	(DeliveryNoteNumber
	,LDTS
	,rn_PerLdts
	,HashDiff
	,ActualGoodsMovementDate
	,OverallBillingStatus
	,IsDeleted
	,SourceIdentifier)
	SELECT DDocHist.DeliveryNoteNumber
		  ,DDocHist.LDTS
		  ,CONVERT(INT,1) AS rn_PerLdts
		  ,DDocHist.HashDiff
		  ,DDocHist.ActualGoodsMovementDate
		  ,DDocHist.OverallBillingStatus
		  ,DDocHist.IsDeleted
		  ,CONVERT(TINYINT,2) AS SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist
	FROM #DeliveryDocumentsFullLast AS DDocLast
	INNER JOIN biz.S4Hana_DeliveryDocumentsHistory AS DDocHist
	   ON DDocLast.DeliveryNoteNumber = DDocHist.DeliveryNoteNumber
	WHERE DDocHist.LEDTS = '9999-12-31'
OPTION (LABEL='etl.S4Hana_spDeliveryDocumentsHistory : #DeliveryDocumentsFullLast ScoId2')


TRUNCATE TABLE etl.S4Hana_DeliveryDocumentsHistory
;WITH preHash AS (
	 SELECT DeliveryNoteNumber
		   ,LDTS
		   ,rn_PerLdts
		   ,HashDiff
		   ,ActualGoodsMovementDate
		   ,OverallBillingStatus
		   ,IsDeleted
		   ,SourceIdentifier
		   ,LAG(HashDiff) OVER (PARTITION BY DeliveryNoteNumber ORDER BY LDTS, SourceIdentifier DESC) AS pre_HashDiff
		   ,ROW_NUMBER() OVER (PARTITION BY DeliveryNoteNumber ORDER BY LDTS, SourceIdentifier DESC) AS RankOverAll
	FROM #DeliveryDocumentsFullLast
	WHERE rn_PerLdts = 1
)
,DiffCheck AS (
	SELECT DeliveryNoteNumber
		  ,LDTS
		  ,ISNULL((DateAdd(ss ,-1, LEAD(LDTS) OVER (PARTITION BY DeliveryNoteNumber ORDER BY LDTS))),'9999-12-31') AS LEDTS
		  ,HashDiff
		  ,ActualGoodsMovementDate
		  ,OverallBillingStatus
		  ,IsDeleted
		  ,SourceIdentifier
	FROM preHash
	WHERE HashDiff <> pre_HashDiff
	   OR RankOverAll = 1 -- to get the first entry
)
INSERT INTO etl.S4Hana_DeliveryDocumentsHistory
	  (DeliveryNoteNumber
	  ,LDTS
	  ,LEDTS
	  ,HashDiff
	  ,ActualGoodsMovementDate
	  ,OverallBillingStatus
	  ,IsDeleted
	  ,SourceIdentifier)
SELECT DeliveryNoteNumber
	  ,LDTS
	  ,LEDTS
	  ,HashDiff
	  ,ActualGoodsMovementDate
	  ,OverallBillingStatus
	  ,IsDeleted
	  ,SourceIdentifier
FROM DiffCheck
WHERE SourceIdentifier = 1 -- only new entiers 
	OR (SourceIdentifier = 2 AND LEDTS <> '9999-12-31') -- existing entries to update LEDTS in the HIST table 
OPTION (LABEL='etl.S4Hana_spDeliveryDocumentsHistory : S4Hana_DeliveryDocumentsHistoryNew')

BEGIN TRAN -- Make sure Insert and Update are done in the same transaction
	INSERT INTO biz.S4Hana_DeliveryDocumentsHistory 
		  (DeliveryNoteNumber
		  ,LDTS
		  ,LEDTS
		  ,HashDiff
		  ,ActualGoodsMovementDate
		  ,OverallBillingStatus
		  ,IsDeleted)
	SELECT DeliveryNoteNumber
		  ,LDTS
		  ,LEDTS
		  ,HashDiff
		  ,ActualGoodsMovementDate
		  ,OverallBillingStatus
		  ,IsDeleted
	FROM etl.S4Hana_DeliveryDocumentsHistory
	WHERE SourceIdentifier = 1 -- only new entiers
	OPTION (LABEL='etl.S4Hana_spDeliveryDocumentsHistory : S4Hana_DeliveryDocumentsHistory Insert')

	--Update LEDTS for entires with fresh inserted entries for this BK
	UPDATE hist
	SET hist.LEDTS = new.LEDTS
	FROM biz.S4Hana_DeliveryDocumentsHistory AS hist
	INNER JOIN etl.S4Hana_DeliveryDocumentsHistory AS new
		ON hist.DeliveryNoteNumber = new.DeliveryNoteNumber
		AND hist.LDTS = new.LDTS
	WHERE hist.LEDTS = '9999-12-31'
	  AND new.SourceIdentifier = 2 -- only update Objects loaded from Hist table
	OPTION (LABEL='etl.S4Hana_spDeliveryDocumentsHistory : S4Hana_DeliveryDocumentsHistory Update')
COMMIT TRAN; 
-- Update End of the load
UPDATE DTlogs
SET ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

EXEC [biz].[S4Hana_spDeliveryDocumentsHistory_CEU] @LDTS

END -- END SP