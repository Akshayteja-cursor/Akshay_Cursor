﻿CREATE PROC [biz].[S4Hana_spSoDocumentItemsHistory_onPrem] @LDTS [DATETIME2](7) AS
BEGIN
SET NOCOUNT ON
-- DECLARE @LDTS DATETIME2(7) = '20000102'
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(7) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(7)
DECLARE @DestinationLastLoadDate DATETIME2(7)
DECLARE @BatchLdts DATETIME2(7) = @LDTS

-- do not use the input parameter, in case of an failur or reload situartion take the last tranfered LDTS from the Hist table
IF(EXISTS(SELECT 1 FROM biz.S4Hana_SoDocumentItemsHistory_onPrem)) 
BEGIN
	SELECT @DestinationLastLoadDate = MAX(LDTS) 
	FROM biz.S4Hana_SoDocumentItemsHistory_onPrem
END
ELSE BEGIN
	SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
END 

IF(EXISTS(SELECT 1 FROM stag.S4Hana_SODocumentItems_full_onPrem))
BEGIN
	SELECT @SourceLastLoadDate = MAX(_LDTS)
	FROM stag.S4Hana_SODocumentItems_full_onPrem
END
ELSE BEGIN
	SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
END 

--Log Data load
INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'spSoDocumentItemsHistory_onPrem'
			,'prepSoDocHist'
			,'NatSalesOrdersOohHistory_onPrem'
			,'sales'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts

IF OBJECT_ID('tempdb..#SoDocumentItemsFullLastIncrement') IS NOT NULL
BEGIN
    DROP TABLE #SoDocumentItemsFullLastIncrement
END

CREATE TABLE #SoDocumentItemsFullLastIncrement
WITH
(DISTRIBUTION = HASH(NatSalesOrderNo)
,HEAP)
AS(
SELECT CAST(stagSoDocItemFull.VBELN AS NVARCHAR(10)) AS NatSalesOrderNo 
	  ,CAST(stagSoDocItemFull.POSNR AS NVARCHAR(6)) AS NatSalesOrderItemNo
	  ,CAST(stagSoDocItemFull.MATNR AS NVARCHAR(40)) AS MaterialNumber
	  ,CAST(stagSoDocItemFull.KWMENG AS Decimal(15, 3)) AS OrderQuantity
	  ,CAST(stagSoDocItemFull.NETWR AS Decimal(15, 2)) AS NetAmount
	  ,CAST(stagSoDocItemFull.ABGRU AS NCHAR(2)) AS RejectionReason
	  ,CAST(stagSoDocItemFull.VGBEL AS NVARCHAR(10)) AS ReferenceDocumentNumber
	  ,CAST(stagSoDocItemFull.VGPOS AS NVARCHAR(6)) AS ReferenceDocumentItemNumber
	  ,CAST(stagSoDocItemFull.VGTYP AS NCHAR(4)) AS PrecedingDocumentCategory
	  ,Try_Convert(Decimal(15, 3),stagSoDocItemFull.KZWI1) AS GrossSalesValue
	  ,CAST(CASE WHEN stagSoDocItemFull.ODQ_CHANGEMODE = 'D' THEN 1 ELSE 0 END AS BIT) AS IsDeleted
	  ,CAST(stagSoDocItemFull._LDTS AS DATETIME2(7)) AS LDTS 
	  ,ROW_NUMBER() OVER (PARTITION BY stagSoDocItemFull.VBELN, stagSoDocItemFull.POSNR, stagSoDocItemFull._LDTS ORDER BY stagSoDocItemFull.TS_SEQUENCE_NUMBER DESC) AS rn_PerLdts
	  ,CONVERT(BINARY(16), 
		HASHBYTES('MD5',CONCAT( 
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),stagSoDocItemFull.VBELN)))),'_', 
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),stagSoDocItemFull.POSNR)))),'_', 
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),stagSoDocItemFull.MATNR)))),'_', 
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),stagSoDocItemFull.KWMENG)))),'_', 
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),stagSoDocItemFull.NETWR)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),stagSoDocItemFull.ABGRU)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),stagSoDocItemFull.VGBEL)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),stagSoDocItemFull.VGPOS)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),stagSoDocItemFull.VGTYP)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),stagSoDocItemFull.KZWI1)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),CASE WHEN stagSoDocItemFull.ODQ_CHANGEMODE = 'D' THEN 1 ELSE 0 END))))
	  ))) AS HashDiff 
	  ,CONVERT(TINYINT,1) AS SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist
FROM stag.S4Hana_SODocumentItems_full_onPrem AS stagSoDocItemFull
WHERE stagSoDocItemFull._LDTS > @DestinationLastLoadDate
)

-- Add last entires from Hist which are in the new batch
INSERT INTO #SoDocumentItemsFullLastIncrement
	(NatSalesOrderNo
	,NatSalesOrderItemNo
	,MaterialNumber
	,OrderQuantity
	,NetAmount
	,RejectionReason
	,ReferenceDocumentNumber
	,ReferenceDocumentItemNumber
	,PrecedingDocumentCategory
	,GrossSalesValue
	,IsDeleted
	,LDTS
	,rn_PerLdts
	,HashDiff
	,SourceIdentifier)
SELECT SoItemHist.NatSalesOrderNo
	,SoItemHist.NatSalesOrderItemNo
	,SoItemHist.MaterialNumber
	,SoItemHist.OrderQuantity
	,SoItemHist.NetAmount
	,SoItemHist.RejectionReason
	,SoItemHist.ReferenceDocumentNumber
	,SoItemHist.ReferenceDocumentItemNumber
	,SoItemHist.PrecedingDocumentCategory
	,SoItemHist.GrossSalesValue
	,SoItemHist.IsDeleted
	,SoItemHist.LDTS
	,CONVERT(INT,1) AS rn_PerLdts
	,SoItemHist.HashDiff
	,CONVERT(TINYINT,2) AS SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist
	FROM #SoDocumentItemsFullLastIncrement AS stagNew
	INNER JOIN biz.S4Hana_SoDocumentItemsHistory_onPrem AS SoItemHist
		ON stagNew.NatSalesOrderNo = SoItemHist.NatSalesOrderNo
		AND stagNew.NatSalesOrderItemNo = SoItemHist.NatSalesOrderItemNo
		AND SoItemHist.LEDTS = '9999-12-31' ---> Get latest entrie from the hist table 

;CREATE TABLE #SoDocumentItemsHistNew
WITH
(DISTRIBUTION = HASH(NatSalesOrderNo)
,HEAP)
AS
WITH preHash AS (
	 SELECT NatSalesOrderNo
		   ,NatSalesOrderItemNo
		   ,MaterialNumber
		   ,OrderQuantity
		   ,NetAmount
		   ,RejectionReason
		   ,ReferenceDocumentNumber
		   ,ReferenceDocumentItemNumber
		   ,PrecedingDocumentCategory
		   ,GrossSalesValue
		   ,IsDeleted
		   ,SourceIdentifier
		   ,LDTS
		   ,HashDiff
		   ,LAG(HashDiff) OVER (PARTITION BY NatSalesOrderNo, NatSalesOrderItemNo ORDER BY LDTS) AS pre_HashDiff
		   ,ROW_NUMBER() OVER (PARTITION BY NatSalesOrderNo, NatSalesOrderItemNo ORDER BY LDTS) AS RankOverAll
	FROM #SoDocumentItemsFullLastIncrement
	WHERE rn_PerLdts = 1
)
,DiffCheck AS (
	SELECT NatSalesOrderNo
		  ,NatSalesOrderItemNo
		  ,LDTS
		  ,ISNULL((DateAdd(ss ,-1, LEAD(LDTS) OVER (PARTITION BY NatSalesOrderNo, NatSalesOrderItemNo ORDER BY LDTS))),'9999-12-31') AS LEDTS
		  ,HashDiff
		  ,MaterialNumber
		  ,OrderQuantity
		  ,NetAmount
		  ,RejectionReason
		  ,ReferenceDocumentNumber
		  ,ReferenceDocumentItemNumber
		  ,PrecedingDocumentCategory
		  ,GrossSalesValue
		  ,IsDeleted
		  ,SourceIdentifier
	FROM preHash
	WHERE HashDiff <> pre_HashDiff
	   OR RankOverAll = 1 -- to get the first entry
)
SELECT NatSalesOrderNo
	  ,NatSalesOrderItemNo
	  ,LDTS
	  ,LEDTS
	  ,HashDiff
	  ,MaterialNumber
	  ,OrderQuantity
	  ,NetAmount
	  ,RejectionReason
	  ,ReferenceDocumentNumber
	  ,ReferenceDocumentItemNumber
	  ,PrecedingDocumentCategory
	  ,GrossSalesValue
	  ,IsDeleted
	  ,SourceIdentifier
FROM DiffCheck
WHERE SourceIdentifier = 1 -- only new entiers 
	OR (SourceIdentifier = 2 AND LEDTS <> '9999-12-31') -- existing entries to update LEDTS in the HIST table 

-- Insert new entries to S4Hana_SoDocumentItemsHistPre
INSERT INTO biz.S4Hana_SoDocumentItemsHistory_onPrem
	  (NatSalesOrderNo
	  ,NatSalesOrderItemNo
	  ,LDTS
	  ,LEDTS
	  ,HashDiff
	  ,MaterialNumber
	  ,OrderQuantity
	  ,NetAmount
	  ,RejectionReason
	  ,ReferenceDocumentNumber
	  ,ReferenceDocumentItemNumber
	  ,PrecedingDocumentCategory
	  ,GrossSalesValue
	  ,IsDeleted)
SELECT NatSalesOrderNo
	  ,NatSalesOrderItemNo
	  ,LDTS
	  ,LEDTS
	  ,HashDiff
	  ,MaterialNumber
	  ,OrderQuantity
	  ,NetAmount
	  ,RejectionReason
	  ,ReferenceDocumentNumber
	  ,ReferenceDocumentItemNumber
	  ,PrecedingDocumentCategory
	  ,GrossSalesValue
	  ,IsDeleted
FROM #SoDocumentItemsHistNew
WHERE SourceIdentifier = 1 -- only new entiers 

--Update LEDTS for entires with fresh inserted entries for this BK
UPDATE histPre
SET histPre.LEDTS = new.LEDTS
FROM biz.S4Hana_SoDocumentItemsHistory_onPrem AS histPre
INNER JOIN #SoDocumentItemsHistNew AS new
	ON histPre.NatSalesOrderNo = new.NatSalesOrderNo  -- join over NatSalesOrderNo and not HashDiff because the distribution of the tables via NatSalesOrderNo order by LDTS
	AND histPre.NatSalesOrderItemNo = new.NatSalesOrderItemNo
	AND histPre.LDTS = new.LDTS
WHERE histPre.LEDTS = '9999-12-31'
  AND new.SourceIdentifier = 2 -- only update Objects loaded from Hist table

-- Update End of the load
UPDATE DTlogs
SET ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

END -- END SP