﻿CREATE PROC [biz].[S4Hana_spSOScheduleLineItemsAggHistory] @LDTS [DATETIME2](7) AS
BEGIN
SET NOCOUNT ON

-- DECLARE @LDTS DATETIME2(7) = '2000-01-01'
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(7) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(7)
DECLARE @DestinationLastLoadDate DATETIME2(7)
DECLARE @BatchLdts DATETIME2(7) = @LDTS

IF(EXISTS(SELECT 1 FROM biz.S4Hana_SOScheduleLineItemsAggHistory))
BEGIN
	SELECT @DestinationLastLoadDate = MAX(LDTS)
	FROM biz.S4Hana_SOScheduleLineItemsAggHistory
END
ELSE BEGIN
	SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
END 

IF(EXISTS(SELECT 1 FROM biz.S4Hana_SOScheduleLineItemsHistory))
BEGIN
	SELECT @SourceLastLoadDate = MAX(LDTS)
	FROM biz.S4Hana_SOScheduleLineItemsHistory
END
ELSE BEGIN
	SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
END 

--Log Data load
INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'spSoScheduleLinesHistoryAgg'
			,'prepSoDocHistory'
			,'NatSalesOrdersOohHistory'
			,'sales'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts

-- get all touched NatSo / NatSoItems
IF OBJECT_ID('tempdb..#DistLdtsScheduleLinesHistory') IS NOT NULL
BEGIN
    DROP TABLE #DistLdtsScheduleLinesHistory
END

CREATE TABLE #DistLdtsScheduleLinesHistory
WITH
(DISTRIBUTION = HASH(NatSalesOrderNo)
,HEAP)
AS(
SELECT NatSalesOrderNo
      ,NatSalesOrderItemNo
      ,LDTS
FROM biz.S4Hana_SOScheduleLineItemsHistory
WHERE LDTS > @DestinationLastLoadDate
)

-- build a list of all NatSo / NatSoItems / NatSOItemScheduleLine
IF OBJECT_ID('tempdb..#DistLdtsSoItemSchLine') IS NOT NULL
BEGIN
    DROP TABLE #DistLdtsSoItemSchLine
END

CREATE TABLE #DistLdtsSoItemSchLine
WITH
(DISTRIBUTION = HASH(NatSalesOrderNo)
,HEAP)
AS(
SELECT DISTINCT 
	   schL.NatSalesOrderNo
      ,schL.NatSalesOrderItemNo
      ,schL.NatSalesOrderItemScheduleLineNo
	  ,soItemLdts.LDTS
  FROM biz.S4Hana_SOScheduleLineItemsHistory AS schL
  INNER JOIN #DistLdtsScheduleLinesHistory AS soItemLdts
	ON schL.NatSalesOrderNo = soItemLdts.NatSalesOrderNo
	AND schL.NatSalesOrderItemNo = soItemLdts.NatSalesOrderItemNo)


IF OBJECT_ID('tempdb..#SoScheduleLinesAggFullLast') IS NOT NULL
BEGIN
    DROP TABLE #SoScheduleLinesAggFullLast
END

CREATE TABLE #SoScheduleLinesAggFullLast
WITH
(DISTRIBUTION = HASH(NatSalesOrderNo)
,HEAP)
AS
WITH ExtScheduleLine AS
( SELECT distLDTS.NatSalesOrderNo
		,distLDTS.NatSalesOrderItemNo
		,distLDTS.NatSalesOrderItemScheduleLineNo
		,distLDTS.LDTS
	--	,SoSchLines.SODeliveryDate
		,SoSchLines.ConfirmedQty
		,SoSchLines.ConfirmedDeliveryDate
		,SoSchLines.IsDeleted		
	FROM #DistLdtsSoItemSchLine AS distLDTS
	INNER JOIN biz.S4Hana_SOScheduleLineItemsHistory AS SoSchLines
		ON distLDTS.NatSalesOrderNo = SoSchLines.NatSalesOrderNo
		AND distLDTS.NatSalesOrderItemNo = SoSchLines.NatSalesOrderItemNo
		AND distLDTS.NatSalesOrderItemScheduleLineNo = SoSchLines.NatSalesOrderItemScheduleLineNo	
		AND distLDTS.LDTS BETWEEN SoSchLines.LDTS AND SoSchLines.LEDTS
)
,AggSaleDocItem AS
( SELECT NatSalesOrderNo
		,NatSalesOrderItemNo
		,LDTS
		,MIN(CASE WHEN IsDeleted = 1 THEN NULL ELSE ConfirmedDeliveryDate END) AS MinSODeliveryDate
		,MAX(CASE WHEN IsDeleted = 1 THEN NULL ELSE ConfirmedDeliveryDate END) AS MaxSODeliveryDate
		,ISNULL(
		CONVERT(DECIMAL(13, 3),SUM(CASE WHEN IsDeleted = 1 THEN NULL ELSE ConfirmedQty END)),0) AS ConfirmedQty
		,MAX(ConfirmedDeliveryDate) AS ConfirmedDeliveryDate
		,MIN(IsDeleted) AS IsDeleted		
	FROM ExtScheduleLine
	GROUP BY NatSalesOrderNo
			,NatSalesOrderItemNo
			,LDTS
)
SELECT NatSalesOrderNo
	  ,NatSalesOrderItemNo
	  ,LDTS
	  ,CONVERT(BINARY(16), 
			HASHBYTES('MD5',CONCAT( 
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),NatSalesOrderNo)))),'_', 
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),NatSalesOrderItemNo)))),'_',		
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),MinSODeliveryDate, 126)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),MaxSODeliveryDate, 126)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ConfirmedQty)))),'_', 
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),IsDeleted))))
         ))) AS HashDiff 
	  ,MinSODeliveryDate
	  ,MaxSODeliveryDate
	  ,ConfirmedQty
	  ,ConfirmedDeliveryDate
	  ,IsDeleted
	  ,CONVERT(TINYINT,1) AS SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist
FROM AggSaleDocItem
OPTION (LABEL='etl.S4Hana_spSOScheduleLineItemsAggHistory : #SoScheduleLinesFullLast ScoId1')

-- Add last related entires from Hist which are in the new batch
INSERT INTO #SoScheduleLinesAggFullLast
	(NatSalesOrderNo
	,NatSalesOrderItemNo
	,LDTS
	,HashDiff
	,MinSODeliveryDate
	,MaxSODeliveryDate
	,ConfirmedQty
	,ConfirmedDeliveryDate
	,IsDeleted
	,SourceIdentifier)
SELECT SoSchHist.NatSalesOrderNo
	  ,SoSchHist.NatSalesOrderItemNo
	  ,SoSchHist.LDTS
	  ,SoSchHist.HashDiff
	  ,SoSchHist.MinSODeliveryDate
	  ,SoSchHist.MaxSODeliveryDate
	  ,SoSchHist.ConfirmedQty
	  ,SoSchHist.ConfirmedDeliveryDate
	  ,SoSchHist.IsDeleted	  
	  ,CONVERT(TINYINT,2) AS SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist
FROM #SoScheduleLinesAggFullLast AS stagNew
INNER JOIN biz.S4Hana_SOScheduleLineItemsAggHistory AS SoSchHist
		ON stagNew.NatSalesOrderNo = SoSchHist.NatSalesOrderNo
		AND stagNew.NatSalesOrderItemNo = SoSchHist.NatSalesOrderItemNo
		AND SoSchHist.LEDTS = '9999-12-31' ---> Get latest entrie from the hist table 

TRUNCATE TABLE etl.S4Hana_SOScheduleLineItemsAggHistory
;WITH preHash AS 
	(SELECT NatSalesOrderNo
		   ,NatSalesOrderItemNo
		   ,LDTS
		   ,HashDiff
		   ,MinSODeliveryDate
		   ,MaxSODeliveryDate
		   ,ConfirmedQty
		   ,ConfirmedDeliveryDate
		   ,IsDeleted
		   ,SourceIdentifier
		   ,LAG(HashDiff) OVER (PARTITION BY NatSalesOrderNo, NatSalesOrderItemNo ORDER BY LDTS, SourceIdentifier DESC) AS pre_HashDiff
		   ,ROW_NUMBER() OVER (PARTITION BY NatSalesOrderNo, NatSalesOrderItemNo ORDER BY LDTS, SourceIdentifier DESC) AS RankOverAll
	FROM #SoScheduleLinesAggFullLast
)
,DiffCheck AS (	
	SELECT NatSalesOrderNo
		  ,NatSalesOrderItemNo
		  ,LDTS
		  ,ISNULL((DateAdd(ss ,-1, LEAD(LDTS) OVER (PARTITION BY NatSalesOrderNo, NatSalesOrderItemNo ORDER BY LDTS))),'9999-12-31') AS LEDTS
		  ,HashDiff
		  ,MinSODeliveryDate
		  ,MaxSODeliveryDate
		  ,ConfirmedQty
		  ,ConfirmedDeliveryDate
		  ,IsDeleted
		  ,SourceIdentifier
	FROM preHash
	WHERE HashDiff <> pre_HashDiff
	   OR RankOverAll = 1 -- to get the first entry
) 
INSERT INTO etl.S4Hana_SOScheduleLineItemsAggHistory
	  (NatSalesOrderNo
	  ,NatSalesOrderItemNo
      ,LDTS
      ,LEDTS
      ,HashDiff
	  ,MinSODeliveryDate
	  ,MaxSODeliveryDate
	  ,ConfirmedQty
	  ,ConfirmedDeliveryDate
	  ,IsDeleted
	  ,SourceIdentifier)
SELECT NatSalesOrderNo
	  ,NatSalesOrderItemNo
	  ,LDTS
	  ,LEDTS
	  ,HashDiff
	  ,MinSODeliveryDate
	  ,MaxSODeliveryDate
	  ,ConfirmedQty
	  ,ConfirmedDeliveryDate
	  ,IsDeleted
	  ,SourceIdentifier
FROM DiffCheck
WHERE SourceIdentifier = 1 -- only new entiers 
  OR (SourceIdentifier = 2 AND LEDTS <> '9999-12-31') -- existing entries to update LEDTS in the HIST table 

BEGIN TRAN -- Make sure Insert and Update are done in the same transaction
	-- Insert new entries to 
	INSERT INTO biz.S4Hana_SOScheduleLineItemsAggHistory
		  (NatSalesOrderNo
		  ,NatSalesOrderItemNo
		  ,LDTS
		  ,LEDTS
		  ,HashDiff
		  ,MinSODeliveryDate
		  ,MaxSODeliveryDate
		  ,ConfirmedQty
		  ,ConfirmedDeliveryDate
		  ,IsDeleted)
	SELECT NatSalesOrderNo
		  ,NatSalesOrderItemNo
		  ,LDTS
		  ,LEDTS
		  ,HashDiff
		  ,MinSODeliveryDate
		  ,MaxSODeliveryDate
		  ,ConfirmedQty
		  ,ConfirmedDeliveryDate
		  ,IsDeleted
	FROM  etl.S4Hana_SOScheduleLineItemsAggHistory
	WHERE SourceIdentifier = 1 -- only new entiers 

	--Update LEDTS for entires with fresh inserted entries for this BK
	UPDATE histPre
	SET histPre.LEDTS = new.LEDTS
	FROM biz.S4Hana_SOScheduleLineItemsAggHistory AS histPre
	INNER JOIN etl.S4Hana_SOScheduleLineItemsAggHistory AS new
		ON histPre.NatSalesOrderNo = new.NatSalesOrderNo  -- join over SalesOrderNo and not HashDiff because the distribution of the tables via SalesOrderNo order by LDTS
		AND histPre.NatSalesOrderItemNo = new.NatSalesOrderItemNo
		AND histPre.LDTS = new.LDTS
	WHERE histPre.LEDTS = '9999-12-31'
	  AND new.SourceIdentifier = 2 -- only update Objects loaded from Hist table
COMMIT TRAN; 

-- Update End of the load
UPDATE DTlogs
SET ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

END -- END SP