﻿CREATE PROC [biz].[S4Hana_spMaterialPrices] @ldts [DATETIME2](7) AS
BEGIN
	SET NOCOUNT ON;
	SET ANSI_WARNINGS ON;

	DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
	DECLARE @ExecStart DATETIME2(7) = GETDATE()
	DECLARE @SourceLastLoadDate DATETIME2(7)
	DECLARE @DestinationLastLoadDate DATETIME2(7)
	DECLARE @BatchLdts DATETIME2(7) = @LDTS
	DECLARE @AffectedRows BIGINT = NULL

	IF(EXISTS(SELECT 1 FROM [biz].[S4Hana_MaterialPrices]))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(_LDTS))
	FROM [biz].[S4Hana_MaterialPrices]
	END
	ELSE BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

	IF(EXISTS(SELECT 1 FROM stag.[S4Hana_vWSPriceMaster977_Currency]))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(_LDTS))
		FROM stag.[S4Hana_vWSPriceMaster977_Currency]
	END
	ELSE BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END 

	--Log Data load
	INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'S4Hana_spMaterialPrices'
			,'biz_MaterialPrices'
			,'S4Hana_MaterialPrices'
			,'biz'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts

	IF OBJECT_ID(N'tempdb..#MaterialPrices') IS NOT NULL
	DROP TABLE #MaterialPrices;
	
	SELECT
		MaterialNumber
		,SalesOrganisation
		,CompanyCode
		,DistributionChannel
		,Currency
		,MaterialPrice_bk
		,ConditionType
		,PriceType
		,PivotKey
		,ValidityStartDate
		,ValidityEndDate
		,ConditionRecordNumber
		,WHPrice
		,_LDTS
		,IsDeleted
		,CONVERT([BINARY](16),
					HASHBYTES('MD5',CONCAT(
		                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[MaterialNumber] 	)))),'_',
		                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[MaterialPrice_bk] 	)))),'_',
		                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SalesOrganisation] 	)))),'_',
		                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CompanyCode] 	)))),'_',
		                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DistributionChannel] 	)))),'_',
		                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Currency] 	)))),'_',
		                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ConditionType] 	)))),'_',
		                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PriceType] 	)))),'_',
		                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PivotKey] 	)))),'_',
		                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ValidityStartDate] 	)))),'_',
		                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ValidityEndDate] 	)))),'_',
		                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ConditionRecordNumber] 	)))),'_',
		                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[WHPrice] 	)))),'_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),IsDeleted))))))       
					) AS HashDiff
	INTO #MaterialPrices
	FROM
		(SELECT
			MP.MaterialNumber
			,MP.SalesOrganisation
			,SHI.CompanyCode
			,MP.DistributionChannel
			,MP.Currency
			,MP.MaterialNumber + '|' + MP.SalesOrganisation + '|' + MP.DistributionChannel + '|' + MP.Currency		AS MaterialPrice_bk
			,MP.ConditionType
			,CASE MP.ConditionType	WHEN 'ZVP1' THEN 'RRP'
									WHEN 'ZPR0' THEN 'WSP'
				END PriceType
			,CASE MP.ConditionType	WHEN 'ZVP1' THEN 'RRP'
									WHEN 'ZPR0' THEN 'WSP'
				END + '_' + SHI.CompanyCode + '_' + MP.Currency	AS PivotKey	-- RRP_CH19_EUR
			,MP.ValidityStartDate
			,MP.ValidityEndDate
			,MP.ConditionRecordNumber
			,MP.WHPrice
			,MP._LDTS
			,MP.IsDeleted
		FROM stag.S4Hana_vWSPriceMaster977_Currency MP
 			INNER JOIN pdwref.S4Hana_Interfaces AS SHI ON SHI.SalesOrg = MP.SalesOrganisation
		WHERE
			MP.ConditionType IN ('ZPR0'
								,'ZVP1')
			AND SalesOrganisation IN ('1130'
									 ,'1070'
									 ,'2000'
									 ,'1110'
									 ,'1090')
			AND Currency IN ('CHF'
							,'EUR')
		) A

	
	-- count new Records for biz.S4Hana_vHangerVas
	    SELECT @AffectedRows = COUNT(*)
		FROM #MaterialPrices AS stg LEFT JOIN biz.S4Hana_MaterialPrices AS prd 
			ON prd.[MaterialPrice_bk] = stg.[MaterialPrice_bk] 
		WHERE prd.[MaterialPrice_bk] IS NULL

   --load new
   INSERT INTO biz.S4Hana_MaterialPrices
			(
				[MaterialNumber]
				,[SalesOrganisation]
				,[CompanyCode]
				,[DistributionChannel]
				,[Currency]
				,[MaterialPrice_bk]
				,[ConditionType]
				,[PriceType]
				,[PivotKey]
				,[ValidityStartDate]
				,[ValidityEndDate]
				,[ConditionRecordNumber]
				,[WHPrice]
				,[_LDTS]
				,[IsDeleted]
				,[HashDiff]
			)
	SELECT  
				stg.[MaterialNumber]
				,stg.[SalesOrganisation]
				,stg.[CompanyCode]
				,stg.[DistributionChannel]
				,stg.[Currency]
				,stg.[MaterialPrice_bk]
				,stg.[ConditionType]
				,stg.[PriceType]
				,stg.[PivotKey]
				,stg.[ValidityStartDate]
				,stg.[ValidityEndDate]
				,stg.[ConditionRecordNumber]
				,stg.[WHPrice]
				,stg.[_LDTS]
				,stg.[IsDeleted]
				,stg.[HashDiff]

		FROM #MaterialPrices AS stg LEFT JOIN biz.S4Hana_MaterialPrices AS prd 
			ON prd.[MaterialPrice_bk] = stg.[MaterialPrice_bk] 
		WHERE prd.[MaterialPrice_bk] IS NULL
	
	UPDATE DTlogs
	SET Inserted = @AffectedRows
	FROM etl.DataTransferLogs DTlogs
	WHERE DataTransferLogId = @DataTransferLogId


	-- count Records to update for S4Hana_BPLegacyPartnerData
	SELECT @AffectedRows = COUNT(*)
	FROM #MaterialPrices AS stg LEFT JOIN biz.S4Hana_MaterialPrices AS prd 
		ON prd.[MaterialPrice_bk] = stg.[MaterialPrice_bk] 
	WHERE stg.HashDiff <> prd.HashDiff

	UPDATE DTlogs
	SET Updated = @AffectedRows
	, ExecEnd = GETDATE()
	FROM etl.DataTransferLogs DTlogs
	WHERE DataTransferLogId = @DataTransferLogId

	--update non deleted records
	UPDATE prd SET					
				 prd.[MaterialNumber]			= stg.[MaterialNumber]
				,prd.[SalesOrganisation]		= stg.[SalesOrganisation]
				,prd.[CompanyCode]				= stg.[CompanyCode]
				,prd.[DistributionChannel]		= stg.[DistributionChannel]
				,prd.[Currency]					= stg.[Currency]
				,prd.[MaterialPrice_bk]			= stg.[MaterialPrice_bk]
				,prd.[ConditionType]			= stg.[ConditionType]
				,prd.[PriceType]				= stg.[PriceType]
				,prd.[PivotKey]					= stg.[PivotKey]
				,prd.[ValidityStartDate]		= stg.[ValidityStartDate]
				,prd.[ValidityEndDate]			= stg.[ValidityEndDate]
				,prd.[ConditionRecordNumber]	= stg.[ConditionRecordNumber]
				,prd.[WHPrice]					= stg.[WHPrice]
				,prd.[_LDTS]					= stg.[_LDTS]
				,prd.[IsDeleted]				= stg.[IsDeleted]
				,prd.[HashDiff]					= stg.[HashDiff]	
	FROM #MaterialPrices AS stg JOIN biz.S4Hana_MaterialPrices AS prd 
		ON prd.[MaterialPrice_bk] = stg.[MaterialPrice_bk] 
	WHERE stg.HashDiff <> prd.HashDiff and stg.IsDeleted = 0

	--update deletions (only deleted status and LDTS)
	UPDATE prd SET
		 prd._LDTS				= stg._LDTS
		,prd.IsDeleted			= stg.IsDeleted
		,prd.[HashDiff]			= stg.[HashDiff]
	FROM #MaterialPrices AS stg JOIN biz.S4Hana_MaterialPrices AS prd 
		ON prd.[MaterialPrice_bk] = stg.[MaterialPrice_bk] 
	WHERE stg.HashDiff <> prd.HashDiff and stg.IsDeleted = 1


END

-- truncate table biz.S4Hana_MaterialPrices
-- exec [biz].[S4Hana_spMaterialPrices] '1900-01-01'