﻿CREATE PROC [biz].[S4Hana_spBPGeneralData1] @ldts [DATETIME2](7) AS
BEGIN
	SET NOCOUNT ON;
	SET ANSI_WARNINGS ON;

	DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
	DECLARE @ExecStart DATETIME2(7) = GETDATE()
	DECLARE @SourceLastLoadDate DATETIME2(7)
	DECLARE @DestinationLastLoadDate DATETIME2(7)
	DECLARE @BatchLdts DATETIME2(7) = @LDTS
	DECLARE @AffectedRows BIGINT = NULL

	IF(EXISTS(SELECT 1 FROM [biz].[S4Hana_BPGeneralData1]))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(LDTS))
	FROM [biz].[S4Hana_BPGeneralData1]
	END
	ELSE BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

	IF(EXISTS(SELECT 1 FROM stag.[S4Hana_BPGeneralData1]))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(_LDTS))
		FROM stag.[S4Hana_BPGeneralData1]
	END
	ELSE BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END 


	--Log Data load
	INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'S4Hana_spBPGeneralData1'
			,'biz_BPGeneralData1'
			,'S4Hana_BPGeneralData1'
			,'biz'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts


	IF OBJECT_ID(N'tempdb..#bpgd1') IS NOT NULL
	DROP TABLE #bpgd1;

	SELECT
	   [BusinessPartner]
      ,[FirstNameBP] 
      ,[LastNameBP] 
      ,[ILN1] 
      ,[ILN2] 
      ,[ILNchk] 
      ,[SearchHelp1] 
      ,[SearchHelp2] 
      ,[BPCategory] 
      ,[BPType] 
      ,[BPGroup] 
      ,[BPextSys] 
      ,[BPSearch1] 
      ,[BPSearch2] 
      ,[FlagArchive] 
      ,[BPCentralBlk] 
      ,[Costtype] 
      ,[NameOrg1] 
      ,[NameOrg2] 
      ,[NameOrg3] 
      ,[NameOrg4] 
      ,[Industry] 
      ,[OrgFounded] 
      ,[OrgLiquidt] 
      ,[Occupation] 
      ,[Nationality] 
      ,[gender] 
      ,[CreationDate] 
      ,[ChangeDate] 
      ,[ValidFrom] 
      ,[Valid_to] 
	  ,IsDeleted       
      ,[_LDTS] as LDTS
	  ,CONVERT([BINARY](16),
				HASHBYTES('MD5',CONCAT(
	            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[BusinessPartner]		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FirstNameBP] 		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[LastNameBP] 			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ILN1] 				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ILN2] 				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ILNchk] 				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SearchHelp1] 		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SearchHelp2] 		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[BPCategory] 			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[BPType] 				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[BPGroup] 			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[BPextSys] 			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[BPSearch1] 			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[BPSearch2] 			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FlagArchive] 		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[BPCentralBlk] 		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Costtype] 			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[NameOrg1] 			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[NameOrg2] 			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[NameOrg3] 			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[NameOrg4] 			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Industry] 			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[OrgFounded] 			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[OrgLiquidt] 			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Occupation] 			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Nationality] 		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[gender] 				  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CreationDate] 		  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ChangeDate] 			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ValidFrom] 			  )))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Valid_to] 			  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[IsDeleted]))))))       
			) AS HashDiff

INTO #bpgd1
from 
(
select 
*,CAST(CASE WHEN __operation_type = 'X' 
				THEN 1 ELSE 0 END AS BIT)				AS IsDeleted
 ,ROW_NUMBER() OVER (PARTITION BY [BusinessPartner] 
						 ORDER BY _LDTS DESC
								, __timestamp DESC)		AS RN
from [stag].[S4Hana_BPGeneralData1]) X
where RN = 1
and [_LDTS] > @ldts
	
		-- count new Records for S4Hana_BPGeneralData1
		    SELECT @AffectedRows = COUNT(*)
			FROM #bpgd1 AS stg LEFT JOIN biz.S4Hana_BPGeneralData1 AS prd 
			ON prd.[BusinessPartner] = stg.[BusinessPartner] 
			WHERE prd.[BusinessPartner] IS NULL

   --load new
   INSERT INTO biz.S4Hana_BPGeneralData1
			(
				 [BusinessPartner]
                ,[FirstNameBP] 
                ,[LastNameBP] 
                ,[ILN1] 
                ,[ILN2] 
                ,[ILNchk] 
                ,[SearchHelp1] 
                ,[SearchHelp2] 
                ,[BPCategory] 
                ,[BPType] 
                ,[BPGroup] 
                ,[BPextSys] 
                ,[BPSearch1] 
                ,[BPSearch2] 
                ,[FlagArchive] 
                ,[BPCentralBlk] 
                ,[Costtype] 
                ,[NameOrg1] 
                ,[NameOrg2] 
                ,[NameOrg3] 
                ,[NameOrg4] 
                ,[Industry] 
                ,[OrgFounded] 
                ,[OrgLiquidt] 
                ,[Occupation] 
                ,[Nationality] 
                ,[gender] 
                ,[CreationDate] 
                ,[ChangeDate] 
                ,[ValidFrom] 
                ,[Valid_to] 
	            ,IsDeleted       
                ,LDTS
				,[HashDiff]			
			)
	SELECT  
				 stg.[BusinessPartner]
                ,stg.[FirstNameBP] 
                ,stg.[LastNameBP] 
                ,stg.[ILN1] 
                ,stg.[ILN2] 
                ,stg.[ILNchk] 
                ,stg.[SearchHelp1] 
                ,stg.[SearchHelp2] 
                ,stg.[BPCategory] 
                ,stg.[BPType] 
                ,stg.[BPGroup] 
                ,stg.[BPextSys] 
                ,stg.[BPSearch1] 
                ,stg.[BPSearch2] 
                ,stg.[FlagArchive] 
                ,stg.[BPCentralBlk] 
                ,stg.[Costtype] 
                ,stg.[NameOrg1] 
                ,stg.[NameOrg2] 
                ,stg.[NameOrg3] 
                ,stg.[NameOrg4] 
                ,stg.[Industry] 
                ,stg.[OrgFounded] 
                ,stg.[OrgLiquidt] 
                ,stg.[Occupation] 
                ,stg.[Nationality] 
                ,stg.[gender] 
                ,stg.[CreationDate] 
                ,stg.[ChangeDate] 
                ,stg.[ValidFrom] 
                ,stg.[Valid_to] 
	            ,stg.IsDeleted       
                ,stg.LDTS
				,stg.[HashDiff]	


		 FROM #bpgd1 AS stg LEFT JOIN biz.S4Hana_BPGeneralData1 AS prd 
		 ON prd.[BusinessPartner] = stg.[BusinessPartner] 
		 WHERE prd.[BusinessPartner] IS NULL
	
		UPDATE DTlogs
		SET Inserted = @AffectedRows
		FROM etl.DataTransferLogs DTlogs
		WHERE DataTransferLogId = @DataTransferLogId


		-- count new Records for S4Hana_BPGeneralData1
		SELECT @AffectedRows = COUNT(*)
		FROM #bpgd1 AS stg JOIN biz.S4Hana_BPGeneralData1 AS prd 
		ON prd.[BusinessPartner] = stg.[BusinessPartner]
		WHERE stg.HashDiff <> prd.HashDiff

		UPDATE DTlogs
		SET Updated = @AffectedRows
		, ExecEnd = GETDATE()
		FROM etl.DataTransferLogs DTlogs
		WHERE DataTransferLogId = @DataTransferLogId

		--update non deleted records
		  UPDATE prd SET	
				 prd.[BusinessPartner]		= stg.[BusinessPartner]
                ,prd.[FirstNameBP] 			= stg.[FirstNameBP] 
                ,prd.[LastNameBP] 			= stg.[LastNameBP] 
                ,prd.[ILN1] 				= stg.[ILN1] 
                ,prd.[ILN2] 				= stg.[ILN2] 
                ,prd.[ILNchk] 				= stg.[ILNchk] 
                ,prd.[SearchHelp1] 			= stg.[SearchHelp1] 
                ,prd.[SearchHelp2] 			= stg.[SearchHelp2] 
                ,prd.[BPCategory] 			= stg.[BPCategory] 
                ,prd.[BPType] 				= stg.[BPType] 
                ,prd.[BPGroup] 				= stg.[BPGroup] 
                ,prd.[BPextSys] 			= stg.[BPextSys] 
                ,prd.[BPSearch1] 			= stg.[BPSearch1] 
                ,prd.[BPSearch2] 			= stg.[BPSearch2] 
                ,prd.[FlagArchive] 			= stg.[FlagArchive] 
                ,prd.[BPCentralBlk] 		= stg.[BPCentralBlk] 
                ,prd.[Costtype] 			= stg.[Costtype] 
                ,prd.[NameOrg1] 			= stg.[NameOrg1] 
                ,prd.[NameOrg2] 			= stg.[NameOrg2] 
                ,prd.[NameOrg3] 			= stg.[NameOrg3] 
                ,prd.[NameOrg4] 			= stg.[NameOrg4] 
                ,prd.[Industry] 			= stg.[Industry] 
                ,prd.[OrgFounded] 			= stg.[OrgFounded] 
                ,prd.[OrgLiquidt] 			= stg.[OrgLiquidt] 
                ,prd.[Occupation] 			= stg.[Occupation] 
                ,prd.[Nationality] 			= stg.[Nationality] 
                ,prd.[gender] 				= stg.[gender] 
                ,prd.[CreationDate] 		= stg.[CreationDate] 
                ,prd.[ChangeDate] 			= stg.[ChangeDate] 
                ,prd.[ValidFrom] 			= stg.[ValidFrom] 
                ,prd.[Valid_to] 			= stg.[Valid_to] 
	            ,prd.IsDeleted       		= stg.IsDeleted       
                ,prd.LDTS					= stg.LDTS
				,prd.[HashDiff]				= stg.[HashDiff]


			FROM #bpgd1 AS stg JOIN biz.S4Hana_BPGeneralData1 AS prd 
			ON prd.[BusinessPartner] = stg.[BusinessPartner]
			WHERE stg.HashDiff <> prd.HashDiff and stg.IsDeleted = 0

		 --update deletions (only deleted status and LDTS)
		 UPDATE prd SET
				 prd.LDTS				= stg.LDTS
				,prd.IsDeleted			= stg.IsDeleted
				,prd.[HashDiff]			= stg.[HashDiff]
		 	FROM #bpgd1 AS stg JOIN biz.S4Hana_BPGeneralData1 AS prd 
			ON prd.[BusinessPartner] = stg.[BusinessPartner]
			WHERE stg.HashDiff <> prd.HashDiff and stg.IsDeleted = 1


END

--truncate table biz.S4Hana_BPGeneralData1
-- exec [biz].[S4Hana_spBPGeneralData1]'1900-01-01'