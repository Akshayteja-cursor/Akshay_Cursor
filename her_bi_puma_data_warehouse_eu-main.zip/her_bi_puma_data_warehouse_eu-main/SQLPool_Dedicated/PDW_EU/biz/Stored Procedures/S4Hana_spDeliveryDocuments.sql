﻿CREATE PROC [biz].[S4Hana_spDeliveryDocuments] @ldts [DATETIME2](7) AS
BEGIN
	SET NOCOUNT ON;
	SET ANSI_WARNINGS ON;
	DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
	DECLARE @ExecStart DATETIME2(0) = GETDATE()
	DECLARE @SourceLastLoadDate DATETIME2(0)
	DECLARE @DestinationLastLoadDate DATETIME2(0)
	DECLARE @BatchLdts DATETIME2(0) = @LDTS
	DECLARE @AffectedRows BIGINT = NULL

	IF(EXISTS(SELECT 1 FROM [biz].[S4Hana_DeliveryDocuments]))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(LDTS))
	FROM [biz].[S4Hana_DeliveryDocuments]
	END
	ELSE BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

	IF(EXISTS(SELECT 1 FROM stag.[S4Hana_DeliveryDocuments]))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(_LDTS))
		FROM stag.[S4Hana_DeliveryDocuments]
	END
	ELSE BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END 

--Log Data load
INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'S4Hana_spDeliveryDocuments'
			,'biz_DeliveryDocuments'
			,'DeliveryDocuments'
			,'Stag'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts


	IF OBJECT_ID(N'tempdb..#s_d') IS NOT NULL
	DROP TABLE #s_d;

	SELECT	DeliveryNoteNumber --BK
			,CreationDate 
			,DeliveryDate
			,OverallGoodsMovementStatus
			,OverallPackingStatus
			,OverallBillingStatus
			,OverallSDProcessStatus
			,CustomerCode_SoldTo
			,TransactionCurrency
			,ActualGoodsMovementDate
			,DeliveryNoteDocType
			,SalesOrganization
			,TotalCreditCheckStatus   
			,[MeansOfTransport]
			,SpecialProcessingCode
			,ActualLoadingDate
			,GrossWeight
			,DeliveryDocumentBySupplier
			,SDDocumentCategory
			,SpecialLogisticsProcess
			,PlannedGoodsIssueDate
			,GoodsIssueDate
			,ConfBookingInDate
			,ConfBookingInTime
			,BookingInDate
			,LDTS
			,CONVERT([BINARY](16),
				HASHBYTES('MD5',CONCAT(
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), DeliveryNoteNumber)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CreationDate)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), DeliveryDate)))),'_',	
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), OverallGoodsMovementStatus)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), OverallPackingStatus)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), OverallBillingStatus)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), OverallSDProcessStatus)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CustomerCode_SoldTo)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), TransactionCurrency)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ActualGoodsMovementDate)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), DeliveryNoteDocType)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), SalesOrganization)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), TotalCreditCheckStatus)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [MeansOfTransport])))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), SpecialProcessingCode)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ActualLoadingDate)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), GrossWeight)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), SDDocumentCategory)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), SpecialLogisticsProcess)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PlannedGoodsIssueDate)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), GoodsIssueDate)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ConfBookingInDate)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ConfBookingInTime)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), BookingInDate)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), DeliveryDocumentBySupplier))))))
			) AS HashDiff
		INTO #s_d
		FROM
				(
		select 
			DD.DeliveryNoteNumber --BK
			,DD.CreationDate 
			,DD.DeliveryDate
			,DD.OverallGoodsMovementStatus
			,DD.OverallPackingStatus
			,DD.OverallBillingStatus
			,DD.OverallSDProcessStatus
			,DD.CustomerCode_SoldTo
			,DD.TransactionCurrency
			,DD.ActualGoodsMovementDate
			,DD.DeliveryNoteDocType
			,DD.SalesOrganization
			,DD.TotalCreditCheckStatus   
			,DD.[MeansOfTransport]
			,DD.SpecialProcessingCode
			,DD.ActualLoadingDate
			,case when DD.WeightUnit = 'KG' then DD.GrossWeight*1000
				else DD.GrossWeight 
				end  GrossWeight
			,DD.DeliveryDocumentBySupplier
			,DD.SDDocumentCategory
			,DD.SpecialLogisticsProcess
			,DD.LDTS
			,DD.PlannedGoodsIssueDate
			,DDD_1.MileStoneDate AS  GoodsIssueDate
			,DDD_2.MileStoneDate AS  ConfBookingInDate
			,DDD_2.MileStoneTime AS  ConfBookingInTime
			,DDD_3.MileStoneDate AS  BookingInDate
		FROM stag.S4Hana_fnDeliveryDocuments(@LDTS) DD
			LEFT JOIN stag.S4Hana_vDeliveryDocumentDates DDD_1
				ON DD.TimeSegHeader = DDD_1.TimeSegHeader AND DDD_1.MileStone = 'PU_GDISSUE'
			LEFT JOIN stag.S4Hana_vDeliveryDocumentDates DDD_2 
				ON DD.TimeSegHeader = DDD_2.TimeSegHeader AND DDD_2.MileStone = 'PU_BOKCF'
			LEFT JOIN stag.S4Hana_vDeliveryDocumentDates DDD_3 
				ON DD.TimeSegHeader = DDD_3.TimeSegHeader AND DDD_3.MileStone = 'PUMA_BOK'
		)   result

		-- count new Records for S4Hana_DeliveryDocuments
		SELECT @AffectedRows = COUNT(*)
		FROM #s_d AS stg LEFT JOIN biz.S4Hana_DeliveryDocuments AS prd 
		ON prd.DeliveryNoteNumber = stg.DeliveryNoteNumber 
		WHERE prd.DeliveryNoteNumber IS NULL


   --load new
   INSERT INTO biz.S4Hana_DeliveryDocuments
			(DeliveryNoteNumber --BK
			,CreationDate 
			,DeliveryDate
			,OverallGoodsMovementStatus
			,OverallPackingStatus
			,OverallBillingStatus
			,OverallSDProcessStatus
			,CustomerCode_SoldTo
			,TransactionCurrency
			,ActualGoodsMovementDate
			,DeliveryNoteDocType
			,SalesOrganization
			,TotalCreditCheckStatus
			,[MeansOfTransport]
			,SpecialProcessingCode
			,ActualLoadingDate
			,GrossWeight
			,DeliveryDocumentBySupplier
			,SDDocumentCategory
			,SpecialLogisticsProcess
			,PlannedGoodsIssueDate
			,GoodsIssueDate
			,ConfBookingInDate
			,ConfBookingInTime
			,BookingInDate
			,LDTS
			,HashDiff)
	SELECT stg.DeliveryNoteNumber --BK
			,stg.CreationDate
			,stg.DeliveryDate
			,stg.OverallGoodsMovementStatus
			,stg.OverallPackingStatus
			,stg.OverallBillingStatus
			,stg.OverallSDProcessStatus
			,stg.CustomerCode_SoldTo
			,stg.TransactionCurrency
			,stg.ActualGoodsMovementDate
			,stg.DeliveryNoteDocType
			,stg.SalesOrganization
			,stg.TotalCreditCheckStatus
			,stg.[MeansOfTransport]
			,stg.SpecialProcessingCode
			,stg.ActualLoadingDate
			,stg.GrossWeight
			,stg.DeliveryDocumentBySupplier
			,stg.SDDocumentCategory
			,stg.SpecialLogisticsProcess
			,stg.PlannedGoodsIssueDate
			,stg.GoodsIssueDate
			,stg.ConfBookingInDate
			,stg.ConfBookingInTime
			,stg.BookingInDate
			,stg.LDTS
			,stg.HashDiff
		 FROM #s_d AS stg LEFT JOIN biz.S4Hana_DeliveryDocuments AS prd 
			ON prd.DeliveryNoteNumber = stg.DeliveryNoteNumber 
		 WHERE prd.DeliveryNoteNumber IS NULL



UPDATE DTlogs
SET Inserted = @AffectedRows
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId


-- count new Records for S4Hana_DeliveryDocuments
	SELECT @AffectedRows = COUNT(*)
	FROM #s_d AS stg JOIN biz.S4Hana_DeliveryDocuments AS prd 
	ON prd.DeliveryNoteNumber = stg.DeliveryNoteNumber  
	WHERE stg.HashDiff <> prd.HashDiff


	--update existing
		  UPDATE prd SET	
			prd.CreationDate				= stg.CreationDate 
			,prd.DeliveryDate				= stg.DeliveryDate
			,prd.OverallGoodsMovementStatus	= stg.OverallGoodsMovementStatus
			,prd.OverallPackingStatus		= stg.OverallPackingStatus
			,prd.OverallBillingStatus		= stg.OverallBillingStatus
			,prd.OverallSDProcessStatus		= stg.OverallSDProcessStatus
			,prd.CustomerCode_SoldTo		= stg.CustomerCode_SoldTo
			,prd.TransactionCurrency		= stg.TransactionCurrency
			,prd.ActualGoodsMovementDate	= stg.ActualGoodsMovementDate
			,prd.DeliveryNoteDocType		= stg.DeliveryNoteDocType
			,prd.SalesOrganization			= stg.SalesOrganization
			,prd.TotalCreditCheckStatus		= stg.TotalCreditCheckStatus
			,prd.[MeansOfTransport]         = stg.[MeansOfTransport]
			,prd.SpecialProcessingCode		= stg.SpecialProcessingCode
			,prd.ActualLoadingDate			= stg.ActualLoadingDate
			,prd.GrossWeight				= stg.GrossWeight
			,prd.DeliveryDocumentBySupplier	= stg.DeliveryDocumentBySupplier
			,prd.SDDocumentCategory			= stg.SDDocumentCategory
			,prd.LDTS						= stg.LDTS
			,prd.HashDiff					= stg.HashDiff
			,prd.SpecialLogisticsProcess	= stg.SpecialLogisticsProcess
			,prd.PlannedGoodsIssueDate		= stg.PlannedGoodsIssueDate
			,prd.GoodsIssueDate				= stg.GoodsIssueDate
			,prd.ConfBookingInDate			= stg.ConfBookingInDate
			,prd.ConfBookingInTime			= stg.ConfBookingInTime
			,prd.BookingInDate				= stg.BookingInDate
			FROM #s_d AS stg JOIN biz.S4Hana_DeliveryDocuments AS prd 
				ON prd.DeliveryNoteNumber = stg.DeliveryNoteNumber  
			WHERE stg.HashDiff <> prd.HashDiff


UPDATE DTlogs
SET Updated = @AffectedRows
, ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId


END

-- exec  [biz].[S4Hana_spDeliveryDocuments] '1900-01-01'