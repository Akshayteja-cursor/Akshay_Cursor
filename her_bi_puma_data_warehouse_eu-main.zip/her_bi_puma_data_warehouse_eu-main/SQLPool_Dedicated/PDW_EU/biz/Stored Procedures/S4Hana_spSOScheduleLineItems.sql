﻿CREATE PROC [biz].[S4Hana_spSOScheduleLineItems] @ldts [DATETIME2](7) AS
BEGIN

	--declare @ldts [DATETIME2](7)
	--SET @ldts = '1900-01-01'
	
	SET NOCOUNT ON;
	SET ANSI_WARNINGS ON;
	DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
	DECLARE @ExecStart DATETIME2(7) = GETDATE()
	DECLARE @SourceLastLoadDate DATETIME2(7)
	DECLARE @BatchLdts DATETIME2(7) = @ldts
	DECLARE @AffectedRows BIGINT = NULL

	IF(EXISTS(SELECT 1 FROM stag.[S4Hana_SOScheduleLineItems]))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(_LDTS))
		FROM stag.[S4Hana_SOScheduleLineItems]
	END
	ELSE BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END 

--Log Data load
INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'S4Hana_spSOScheduleLineItems'
			,'BIZ_SOScheduleLineItems'
			,'SOScheduleLineItems'
			,'Stag'
			,@ExecStart
			,@SourceLastLoadDate
			,NULL
			,@BatchLdts

	IF OBJECT_ID(N'tempdb..#s_d') IS NOT NULL
	DROP TABLE #s_d;

WITH CTE_AggScheduline
AS
(
SELECT
	sosl.SalesDocument
	,sosl.SalesDocumentItem
	,MIN(CASE WHEN sosl.isDeleted = 1 THEN NULL ELSE sodi.RequestedDeliveryDate END) AS RequestedDeliveryDate
	,MIN(CASE WHEN ConfirmedOrderQuantity = 0 THEN NULL ELSE ConfirmedDeliveryDate END) AS DeliveryDateMin
	,MAX(CASE WHEN ConfirmedOrderQuantity = 0 THEN NULL ELSE ConfirmedDeliveryDate END) AS DeliveryDateMax
	,MAX(CASE WHEN sosl.isDeleted = 1 THEN NULL ELSE ProductAvailabilityDate END) AS MaterialAvailabilityDate 
	,MIN(CASE WHEN sosl.isDeleted = 1 THEN NULL ELSE ProductAvailabilityDate END) AS MinMaterialAvailabilityDate 
	,MAX(DelivBlockReasonForSchedLine) as DelivBlockReasonForSchedLine
	,SUM(CONVERT(DECIMAL(13, 3),CASE WHEN sosl.IsDeleted = 1 THEN 0 ELSE ConfirmedOrderQuantity END)) AS ConfirmedQty 
	,SUM(CONVERT(DECIMAL(13, 3),CASE WHEN sosl.IsDeleted = 1 THEN 0 ELSE DeliveredQtyInOrderQtyUnit END)) AS DeliveredQty
	,MAX(PurchaseRequisition) AS PurchaseRequisition
	FROM [stag].[S4Hana_vSOScheduleLineItems] sosl
	INNER JOIN [stag].[S4Hana_fnSODocumentItems] ('19000101') sodi on sosl.SalesDocument=sodi.SalesDocument and sosl.SalesDocumentItem=sodi.SalesDocumentItem
	INNER JOIN (SELECT DISTINCT SalesDocument,SalesDocumentItem,MAX(SalesOrganization) as SalesOrganization from [stag].[S4Hana_vSOScheduleLineItems_deletionAttributes] group by SalesDocument,SalesDocumentItem) del
	on sodi.SalesDocument = del.SalesDocument and sodi.SalesDocumentItem = del.SalesDocumentItem
	where del.SalesOrganization not in ('1010','1030','1050')
	GROUP BY sosl.SalesDocument
	,sosl.SalesDocumentItem
UNION
SELECT
	sosl.SalesDocument
	,sosl.SalesDocumentItem
	,MIN(CASE WHEN sosl.isDeleted = 1 THEN NULL ELSE ConfirmedDeliveryDate END) AS RequestedDeliveryDate
	,MIN(CASE WHEN ConfirmedOrderQuantity = 0 THEN NULL ELSE ConfirmedDeliveryDate END) AS DeliveryDateMin
	,MAX(CASE WHEN ConfirmedOrderQuantity = 0 THEN NULL ELSE ConfirmedDeliveryDate END) AS DeliveryDateMax
	,MAX(CASE WHEN sosl.isDeleted = 1 THEN NULL ELSE ProductAvailabilityDate END) AS MaterialAvailabilityDate 
	,MIN(CASE WHEN sosl.isDeleted = 1 THEN NULL ELSE ProductAvailabilityDate END) AS MinMaterialAvailabilityDate 
	,MAX(DelivBlockReasonForSchedLine) as DelivBlockReasonForSchedLine
	,SUM(CONVERT(DECIMAL(13, 3),CASE WHEN sosl.IsDeleted = 1 THEN 0 ELSE ConfirmedOrderQuantity END)) AS ConfirmedQty 
	,SUM(CONVERT(DECIMAL(13, 3),CASE WHEN sosl.IsDeleted = 1 THEN 0 ELSE DeliveredQtyInOrderQtyUnit END)) AS DeliveredQty
	,MAX(PurchaseRequisition) AS PurchaseRequisition
	FROM [stag].[S4Hana_vSOScheduleLineItems] sosl
	INNER JOIN [stag].[S4Hana_fnSODocumentItems] ('19000101') sodi on sosl.SalesDocument=sodi.SalesDocument and sosl.SalesDocumentItem=sodi.SalesDocumentItem
	INNER JOIN (SELECT DISTINCT SalesDocument,SalesDocumentItem,MAX(SalesOrganization) as SalesOrganization from [stag].[S4Hana_vSOScheduleLineItems_deletionAttributes] group by SalesDocument,SalesDocumentItem) del
	on sodi.SalesDocument = del.SalesDocument and sodi.SalesDocumentItem = del.SalesDocumentItem
	where del.SalesOrganization in ('1010','1030','1050')
	GROUP BY sosl.SalesDocument
	,sosl.SalesDocumentItem
	)

SELECT 
	SalesDocument
	,SalesDocumentItem
	,RequestedDeliveryDate
	,DeliveryDateMin
	,DeliveryDateMax
	,MaterialAvailabilityDate
	,MinMaterialAvailabilityDate
	,DelivBlockReasonForSchedLine
	,ConfirmedQty
	,DeliveredQty
	,PurchaseRequisition
	,CONVERT(BINARY(16), 
			HASHBYTES('MD5',CONCAT(
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), 	SalesDocument					)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), 	SalesDocumentItem				)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), 	RequestedDeliveryDate			)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), 	DeliveryDateMin					)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), 	DeliveryDateMax					)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), 	MaterialAvailabilityDate		)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), 	MinMaterialAvailabilityDate		)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), 	DelivBlockReasonForSchedLine	)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), 	ConfirmedQty					)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), 	DeliveredQty					)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), 	PurchaseRequisition				))))
			))) AS HashDiff 
		INTO #s_d
		FROM CTE_AggScheduline

		-- count new Records for S4Hana_DeliveryDocuments
		SELECT @AffectedRows = COUNT(*)
		FROM #s_d AS stg LEFT JOIN biz.S4Hana_SOScheduleLineItems AS prd 
		ON prd.[SalesDocument] = stg.[SalesDocument] 
		AND prd.[SalesDocumentItem] = stg.[SalesDocumentItem]
		WHERE prd.[SalesDocument] IS NULL
		
   --load new
   INSERT INTO biz.S4Hana_SOScheduleLineItems
			(	   [SalesDocument]
				  ,[SalesDocumentItem]
				  ,RequestedDeliveryDate
				  ,DeliveryDateMin
				  ,DeliveryDateMax
				  ,MaterialAvailabilityDate
				  ,MinMaterialAvailabilityDate
				  ,DelivBlockReasonForSchedLine
				  ,ConfirmedQty
				  ,DeliveredQty
				  ,PurchaseRequisition
				  ,HashDiff)
	SELECT 
				   stg.SalesDocument
				  ,stg.SalesDocumentItem
				  ,stg.RequestedDeliveryDate
				  ,stg.DeliveryDateMin
				  ,stg.DeliveryDateMax
				  ,stg.MaterialAvailabilityDate
				  ,stg.MinMaterialAvailabilityDate
				  ,stg.DelivBlockReasonForSchedLine
				  ,stg.ConfirmedQty
				  ,stg.DeliveredQty
				  ,stg.PurchaseRequisition
				  ,stg.HashDiff

		 FROM #s_d AS stg LEFT JOIN biz.S4Hana_SOScheduleLineItems AS prd 
				ON prd.[SalesDocument] = stg.[SalesDocument] 
				AND prd.[SalesDocumentItem] = stg.[SalesDocumentItem]
				WHERE prd.[SalesDocument] IS NULL



UPDATE DTlogs
SET Inserted = @AffectedRows
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId


-- count new Records for S4Hana_DeliveryDocuments
	SELECT @AffectedRows = COUNT(*)
	FROM #s_d AS stg JOIN biz.S4Hana_SOScheduleLineItems AS prd 
				ON prd.[SalesDocument] = stg.[SalesDocument] 
				AND prd.[SalesDocumentItem] = stg.[SalesDocumentItem]
	WHERE stg.HashDiff <> prd.HashDiff

--	update existing
UPDATE prd SET	
prd.SalesDocument	=			  stg.SalesDocument
,prd.SalesDocumentItem	=			  stg.SalesDocumentItem
,prd.RequestedDeliveryDate =			stg.RequestedDeliveryDate
,prd.DeliveryDateMin		=		  stg.DeliveryDateMin
,prd.DeliveryDateMax		=		  stg.DeliveryDateMax
,prd.MaterialAvailabilityDate	=			  stg.MaterialAvailabilityDate
,prd.MinMaterialAvailabilityDate	=			stg.MinMaterialAvailabilityDate
,prd.DelivBlockReasonForSchedLine= stg.DelivBlockReasonForSchedLine
,prd.ConfirmedQty				=  stg.ConfirmedQty
,prd.DeliveredQty				=  stg.DeliveredQty
,prd.PurchaseRequisition				=  stg.PurchaseRequisition
,prd.HashDiff	=			  stg.HashDiff

	FROM #s_d AS stg JOIN biz.S4Hana_SOScheduleLineItems AS prd 
				ON prd.[SalesDocument] = stg.[SalesDocument] 
				AND prd.[SalesDocumentItem] = stg.[SalesDocumentItem]
	WHERE stg.HashDiff <> prd.HashDiff


UPDATE DTlogs
SET Updated = @AffectedRows
, ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

	
END


--truncate table biz.S4Hana_SOScheduleLineItems
--execute [biz].[S4Hana_spSOScheduleLineItems]'1900-01-01'
