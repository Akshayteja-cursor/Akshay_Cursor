﻿CREATE PROC [biz].[S4Hana_spSoDocumentDeliveriesHistory_onPrem] @LDTS [DATETIME2](7) AS
BEGIN
SET NOCOUNT ON

--DECLARE @LDTS DATETIME2(7) = '20000102'
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(7) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(7)
DECLARE @DestinationLastLoadDate DATETIME2(7)
DECLARE @BatchLdts DATETIME2(7) = @LDTS

-- do not use the input parameter, in case of an failur or reload situartion take the last tranfered LDTS from the Hist table
IF(EXISTS(SELECT 1 FROM biz.S4Hana_SODocumentDeliveriesHistory_onPrem))
BEGIN
	SELECT @DestinationLastLoadDate =  MAX(LDTS)
	FROM biz.S4Hana_SODocumentDeliveriesHistory_onPrem
END
ELSE BEGIN
	SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
END 

IF(EXISTS(SELECT 1 FROM stag.S4Hana_SODocumentDeliveries_full_onPrem))
BEGIN
	SELECT @SourceLastLoadDate = MAX(_LDTS)
	FROM stag.S4Hana_SODocumentDeliveries_full_onPrem
END
ELSE BEGIN
	SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
END 

--Log Data load
INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'spSoDocumentDeliveriesHistory_onPrem'
			,'prepSoDocHistory_onPrem'
			,'NatSalesOrdersOohHistory_onPrem'
			,'sales'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts


IF OBJECT_ID('tempdb..#SoDocumentDeliveriesFullLastIncrement') IS NOT NULL
BEGIN
    DROP TABLE #SoDocumentDeliveriesFullLastIncrement
END

Create TABLE #SoDocumentDeliveriesFullLastIncrement
WITH
(DISTRIBUTION = HASH(NatSalesOrderNo)
,HEAP)
AS( SELECT CAST(VBELN AS NVARCHAR(10)) AS NatSalesOrderNo  --BK
		  ,CAST(POSNR AS NVARCHAR(6)) AS NatSalesOrderItemNo --BK
		  ,CAST(ETENR AS NVARCHAR(4)) AS ScheduleLine --BK
		  ,CAST(VBELN_VL AS NVARCHAR(10)) AS DeliveryNoteNumber --BK
		  ,CAST(POSNR_VL AS NVARCHAR(6)) AS DeliveryNoteItemNo --BK
		  ,CAST(LFSTA AS NCHAR(1)) AS DeliveryStatus
		  ,CAST(MCEX_I_WADAT AS DATE) AS ActualGoodsMovementDate
		  ,CAST(RECORD_DELETED AS NCHAR(1)) AS NatSalesOrderDeleted
		  ,CAST(CASE WHEN ODQ_CHANGEMODE = 'D' OR RECORD_DELETED = 'X' THEN 1 ELSE 0 END AS BIT) AS IsDeleted
		  ,CAST(_LDTS AS DATETIME2(0)) AS LDTS
  		  ,ROW_NUMBER() OVER (PARTITION BY VBELN, POSNR, ETENR, _LDTS
		  				ORDER BY TS_SEQUENCE_NUMBER DESC, -- this order is not on prem
		  						(CASE WHEN ODQ_CHANGEMODE = 'D' OR RECORD_DELETED = 'X' THEN 1 ELSE 0 END) ASC,  /* #onPrem: New sort for Zero Pics*/
		  						 POSNR_VL DESC,  /* #onPrem:added to avoid picking 000000 delivery notes when others are available*/
		  						 VBELN_VL ASC /*#onPrem: for multiple delivery notes for the same schedule line*/
  		  ) AS rn_PerLdts
  		  ,CONVERT(BINARY(16),
  		  	HASHBYTES('MD5', CONCAT(
		  		UPPER(LTRIM(RTRIM(VBELN))), '_',
		  		UPPER(LTRIM(RTRIM(POSNR))), '_',
		  		UPPER(LTRIM(RTRIM(ETENR))), '_',
		  		UPPER(LTRIM(RTRIM(VBELN_VL))), '_',
		  		UPPER(LTRIM(RTRIM(POSNR_VL))), '_',
		  		UPPER(LTRIM(RTRIM(LFSTA))), '_',
		  		UPPER(LTRIM(RTRIM(MCEX_I_WADAT))), '_',
		  		UPPER(LTRIM(RTRIM(RECORD_DELETED))), '_',
		  		UPPER(LTRIM(RTRIM(ODQ_CHANGEMODE)))
  		  ))) AS HashDiff 
		  ,CONVERT(TINYINT,1) AS SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist
	FROM stag.S4Hana_SODocumentDeliveries_full_onPrem
	WHERE _LDTS > @DestinationLastLoadDate  
)


-- Add last related entires from Hist which are in the new batch
INSERT INTO #SoDocumentDeliveriesFullLastIncrement
	(NatSalesOrderNo
	,NatSalesOrderItemNo
	,ScheduleLine
	,DeliveryNoteNumber
	,DeliveryNoteItemNo
	,DeliveryStatus
	,ActualGoodsMovementDate
	,NatSalesOrderDeleted
	,IsDeleted
	,LDTS
	,rn_PerLdts
	,HashDiff
	,SourceIdentifier)
SELECT SoDelivHist.NatSalesOrderNo
	  ,SoDelivHist.NatSalesOrderItemNo
	  ,SoDelivHist.ScheduleLine
	  ,SoDelivHist.DeliveryNoteNumber
	  ,SoDelivHist.DeliveryNoteItemNo
	  ,SoDelivHist.DeliveryStatus
	  ,SoDelivHist.ActualGoodsMovementDate
	  ,SoDelivHist.NatSalesOrderDeleted
	  ,SoDelivHist.IsDeleted
	  ,SoDelivHist.LDTS
	  ,CONVERT(INT,1) AS rn_PerLdts
	  ,SoDelivHist.HashDiff
	  ,CONVERT(TINYINT,2) AS SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist
FROM #SoDocumentDeliveriesFullLastIncrement AS stagNew
INNER JOIN biz.S4Hana_SODocumentDeliveriesHistory_onPrem AS SoDelivHist
		ON stagNew.NatSalesOrderNo = SoDelivHist.NatSalesOrderNo
		AND stagNew.NatSalesOrderItemNo = SoDelivHist.NatSalesOrderItemNo
		AND stagNew.ScheduleLine = SoDelivHist.ScheduleLine
		AND SoDelivHist.LEDTS = '9999-12-31' ---> Get latest entrie from the hist table 

CREATE TABLE #SODocumentDeliveriesHistNew
WITH
(DISTRIBUTION = HASH(NatSalesOrderNo)
,HEAP)
AS WITH preHash 
AS( SELECT NatSalesOrderNo
		   ,NatSalesOrderItemNo
		   ,ScheduleLine
		   ,DeliveryNoteNumber
		   ,DeliveryNoteItemNo
		   ,DeliveryStatus
		   ,ActualGoodsMovementDate
		   ,NatSalesOrderDeleted
		   ,IsDeleted
		   ,SourceIdentifier
		   ,LDTS
		   ,HashDiff
		   ,LAG(HashDiff) OVER (PARTITION BY NatSalesOrderNo, NatSalesOrderItemNo, ScheduleLine ORDER BY LDTS) AS pre_HashDiff
		   ,ROW_NUMBER() OVER (PARTITION BY NatSalesOrderNo, NatSalesOrderItemNo, ScheduleLine ORDER BY LDTS) AS RankOverAll
	FROM #SoDocumentDeliveriesFullLastIncrement
	WHERE rn_PerLdts = 1
)
,DiffCheck AS (	
	SELECT NatSalesOrderNo
		  ,NatSalesOrderItemNo
		  ,ScheduleLine
		  ,DeliveryNoteNumber
		  ,DeliveryNoteItemNo
		  ,LDTS
		  ,ISNULL((DateAdd(ss ,-1, LEAD(LDTS) OVER (PARTITION BY NatSalesOrderNo, NatSalesOrderItemNo, ScheduleLine ORDER BY LDTS))),'9999-12-31') AS LEDTS
		  ,HashDiff
		  ,DeliveryStatus
		  ,ActualGoodsMovementDate
		  ,NatSalesOrderDeleted
		  ,IsDeleted
		  ,SourceIdentifier
	FROM preHash
	WHERE HashDiff <> pre_HashDiff
	   OR RankOverAll = 1 -- to get the first entry
)
SELECT NatSalesOrderNo
	  ,NatSalesOrderItemNo
	  ,ScheduleLine
	  ,DeliveryNoteNumber
	  ,DeliveryNoteItemNo
	  ,LDTS
	  ,LEDTS
	  ,HashDiff
	  ,DeliveryStatus
	  ,ActualGoodsMovementDate
	  ,NatSalesOrderDeleted
	  ,IsDeleted
	  ,SourceIdentifier
FROM DiffCheck
WHERE SourceIdentifier = 1 -- only new entiers 
	OR (SourceIdentifier = 2 AND LEDTS <> '9999-12-31') -- existing entries to update LEDTS in the HIST table 

-- Insert new entries to S4Hana_SODocumentDeliveriesHistPre

INSERT INTO biz.S4Hana_SODocumentDeliveriesHistory_onPrem
	  (NatSalesOrderNo
      ,NatSalesOrderItemNo
      ,ScheduleLine
      ,DeliveryNoteNumber
      ,DeliveryNoteItemNo
      ,LDTS
      ,LEDTS
      ,HashDiff
      ,DeliveryStatus
      ,ActualGoodsMovementDate
      ,NatSalesOrderDeleted
      ,IsDeleted)
SELECT NatSalesOrderNo
	  ,NatSalesOrderItemNo
	  ,ScheduleLine
	  ,DeliveryNoteNumber
	  ,DeliveryNoteItemNo
	  ,LDTS
	  ,LEDTS
	  ,HashDiff
	  ,DeliveryStatus
	  ,ActualGoodsMovementDate
	  ,NatSalesOrderDeleted
	  ,IsDeleted
FROM #SODocumentDeliveriesHistNew
	WHERE SourceIdentifier = 1 -- only new Objects from the Incremental 

--Update LEDTS for entires with fresh inserted entries for this BK

UPDATE histPre
SET histPre.LEDTS = new.LEDTS
FROM biz.S4Hana_SODocumentDeliveriesHistory_onPrem AS histPre
INNER JOIN #SODocumentDeliveriesHistNew AS new
	ON histPre.NatSalesOrderNo = new.NatSalesOrderNo  -- join over NatSalesOrderNo and not HashDiff because the distribution of the tables via NatSalesOrderNo order by LDTS
	AND histPre.NatSalesOrderItemNo = new.NatSalesOrderItemNo
	AND histPre.ScheduleLine = new.ScheduleLine
	AND histPre.DeliveryNoteNumber = new.DeliveryNoteNumber
	AND histPre.DeliveryNoteItemNo = new.DeliveryNoteItemNo
	AND histPre.LDTS = new.LDTS
WHERE histPre.LEDTS = '9999-12-31'
  AND new.SourceIdentifier = 2 -- only update Objects loaded from Hist table

-- Update End of the load
UPDATE DTlogs
SET ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

END -- END SP