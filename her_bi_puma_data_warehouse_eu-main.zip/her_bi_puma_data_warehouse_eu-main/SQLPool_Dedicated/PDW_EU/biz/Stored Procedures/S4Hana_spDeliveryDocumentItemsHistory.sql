﻿CREATE PROC [biz].[S4Hana_spDeliveryDocumentItemsHistory] @LDTS [DATETIME2](7) AS
BEGIN
SET NOCOUNT ON
--DECLARE @LDTS DATETIME2(7) = '2000-01-01'
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(7) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(7)
DECLARE @DestinationLastLoadDate DATETIME2(7)
DECLARE @BatchLdts DATETIME2(7) = @LDTS

-- do not use the input parameter, in case of an failur or reload situartion take the last tranfered LDTS from the Hist table
IF(EXISTS(SELECT 1 FROM biz.S4Hana_DeliveryDocumentItemsHistory))
BEGIN
	SELECT @DestinationLastLoadDate = MAX(LDTS)
	FROM biz.S4Hana_DeliveryDocumentItemsHistory
END
ELSE BEGIN
	SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
END 

IF(EXISTS(SELECT 1 FROM stag.S4Hana_DeliveryDocumentItems_full))
BEGIN
	SELECT @SourceLastLoadDate = MAX(_LDTS)
	FROM stag.S4Hana_DeliveryDocumentItems_full
END
ELSE BEGIN
	SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
END 

--Log Data load
INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'spDeliveryDocumentItemsHistory'
			,'prepSoDocHist'
			,'NatSalesOrdersOohHistory'
			,'sales'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts


--Get deleted entries and enrich it with SO/SOItem to optimze the load from stag.
IF OBJECT_ID('tempdb..#DeliveryDocumentItemsDeletedLast') IS NOT NULL
BEGIN
    DROP TABLE #DeliveryDocumentItemsDeletedLast
END

CREATE TABLE #DeliveryDocumentItemsDeletedLast
WITH
(DISTRIBUTION = HASH(NatSalesOrderNo)
,HEAP)
AS(
SELECT stagDelDocDeleded.DeliveryDocument AS DeliveryNoteNumber-- BK
      ,stagDelDocDeleded.DeliveryDocumentItem AS DeliveryNoteItemNo --Bk
	  ,stagDelDocDeleded._LDTS AS LDTS
	  ,stagDelDocDeleded. __timestamp
	  ,bizDelDoc.NatSalesOrderNo
	  ,bizDelDoc.NatSalesOrderItemNo
FROM stag.S4Hana_DeliveryDocumentItems_full AS stagDelDocDeleded
INNER JOIN stag.S4Hana_fnDeliveryDocuments('19000101') AS DD
	ON stagDelDocDeleded.DeliveryDocument = DD.DeliveryNoteNumber
INNER JOIN biz.S4Hana_DeliveryDocumentItemsHistory AS bizDelDoc
	ON stagDelDocDeleded.DeliveryDocument = bizDelDoc.DeliveryNoteNumber
	AND stagDelDocDeleded.DeliveryDocumentItem = bizDelDoc.DeliveryNoteItemNo
WHERE 1=1 
  AND stagDelDocDeleded._LDTS > @DestinationLastLoadDate
  AND DD.SDDocumentCategory IN ('J','')
  AND stagDelDocDeleded.__operation_type = 'X'
  AND bizDelDoc.LEDTS = '9999-12-31'
) 
OPTION (LABEL='etl.S4Hana_spDeliveryDocumentItemsHistory : #DeliveryDocumentItemsDeletedLast')

IF OBJECT_ID('tempdb..#DeliveryDocumentItemsFullLast') IS NOT NULL
BEGIN
    DROP TABLE #DeliveryDocumentItemsFullLast
END

CREATE TABLE #DeliveryDocumentItemsFullLast
WITH
(DISTRIBUTION = HASH(NatSalesOrderNo)
,HEAP)
AS
WITH CollectAllActDelObjects AS (
	SELECT DDI.DeliveryDocument AS DeliveryNoteNumber-- BK
		  ,DeliveryDocumentItem AS DeliveryNoteItemNo --Bk
		  ,_LDTS AS LDTS	  
		  ,__timestamp
		  ,ReferenceSDDocument AS NatSalesOrderNo
		  ,ReferenceSDDocumentItem AS NatSalesOrderItemNo
		  ,CONVERT(DECIMAL(13,3),ActualDeliveryQuantity) AS ActualDeliveryQuantity
		  ,CONVERT(TINYINT,0) AS IsDeleted
	FROM stag.S4Hana_DeliveryDocumentItems_full DDI
		INNER JOIN stag.S4Hana_fnDeliveryDocuments('19000101') AS DD
			ON DDI.DeliveryDocument = DD.DeliveryNoteNumber
	WHERE 1=1 
	  AND DDI._LDTS > @DestinationLastLoadDate
	  AND DD.SDDocumentCategory IN('J','')
	  AND DDI.__operation_type <> 'X'
	UNION ALL
	SELECT DeliveryNoteNumber
		  ,DeliveryNoteItemNo
		  ,LDTS
		  ,__timestamp
		  ,NatSalesOrderNo
		  ,NatSalesOrderItemNo
		  ,CONVERT(DECIMAL(13,3),0) AS ActualDeliveryQuantity
		  ,CONVERT(TINYINT,1) AS IsDeleted
	FROM #DeliveryDocumentItemsDeletedLast
)
SELECT DeliveryNoteNumber-- BK
      ,DeliveryNoteItemNo --Bk
	  ,LDTS
	  ,ROW_NUMBER() OVER (PARTITION BY NatSalesOrderNo, DeliveryNoteNumber, DeliveryNoteItemNo, LDTS ORDER BY __timestamp DESC, IsDeleted) AS rn_PerLdts
	  ,CONVERT(BINARY(16),
  		  HASHBYTES('MD5', CONCAT(
		  		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),DeliveryNoteNumber)))), '_',
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),DeliveryNoteItemNo)))), '_',
		  		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),NatSalesOrderNo)))), '_',
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),NatSalesOrderItemNo)))), '_',
		  		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ActualDeliveryQuantity)))), '_',
		  		UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),IsDeleted))))
	   ))) AS HashDiff
	  ,NatSalesOrderNo
	  ,NatSalesOrderItemNo
	  ,ActualDeliveryQuantity
	  ,IsDeleted
	  ,CONVERT(TINYINT,1) AS SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist
FROM CollectAllActDelObjects

OPTION (LABEL='etl.S4Hana_spDeliveryDocumentItemsHistory : #DeliveryDocumentItemsFullLast ScoId1')

INSERT INTO #DeliveryDocumentItemsFullLast
	(DeliveryNoteNumber
	,DeliveryNoteItemNo
	,LDTS
	,rn_PerLdts
	,HashDiff
	,NatSalesOrderNo
	,NatSalesOrderItemNo
	,ActualDeliveryQuantity
	,IsDeleted
	,SourceIdentifier)
	SELECT DDocItemHist.DeliveryNoteNumber
		  ,DDocItemHist.DeliveryNoteItemNo
		  ,DDocItemHist.LDTS
		  ,CONVERT(INT,1) AS rn_PerLdts
		  ,DDocItemHist.HashDiff
		  ,DDocItemHist.NatSalesOrderNo
		  ,DDocItemHist.NatSalesOrderItemNo
		  ,DDocItemHist.ActualDeliveryQuantity
		  ,DDocItemHist.IsDeleted
		  ,CONVERT(TINYINT,2) AS SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist
	FROM #DeliveryDocumentItemsFullLast AS DDocItemLast
	INNER JOIN biz.S4Hana_DeliveryDocumentItemsHistory AS DDocItemHist
		ON DDocItemLast.NatSalesOrderNo = DDocItemHist.NatSalesOrderNo
		AND DDocItemLast.DeliveryNoteNumber = DDocItemHist.DeliveryNoteNumber
		AND DDocItemLast.DeliveryNoteItemNo = DDocItemHist.DeliveryNoteItemNo
	WHERE DDocItemHist.LEDTS = '9999-12-31'
OPTION (LABEL='etl.S4Hana_spDeliveryDocumentItemsHistory : #DeliveryDocumentItemsFullLast ScoId2')


TRUNCATE TABLE etl.S4Hana_DeliveryDocumentItemsHistory
;WITH preHash AS (
	 SELECT DeliveryNoteNumber
		   ,DeliveryNoteItemNo
		   ,LDTS
		   ,rn_PerLdts
		   ,HashDiff
		   ,NatSalesOrderNo
		   ,NatSalesOrderItemNo
		   ,ActualDeliveryQuantity
		   ,IsDeleted
		   ,SourceIdentifier
		   ,LAG(HashDiff) OVER (PARTITION BY NatSalesOrderNo, DeliveryNoteNumber, DeliveryNoteItemNo ORDER BY LDTS, SourceIdentifier DESC) AS pre_HashDiff
		   ,ROW_NUMBER() OVER (PARTITION BY NatSalesOrderNo, DeliveryNoteNumber, DeliveryNoteItemNo ORDER BY LDTS, SourceIdentifier DESC) AS RankOverAll
	FROM #DeliveryDocumentItemsFullLast
	WHERE rn_PerLdts = 1
)
,DiffCheck AS (
	SELECT DeliveryNoteNumber
		  ,DeliveryNoteItemNo
		  ,LDTS
		  ,ISNULL((DateAdd(ss ,-1, LEAD(LDTS) OVER (PARTITION BY NatSalesOrderNo, DeliveryNoteNumber,DeliveryNoteItemNo ORDER BY LDTS))),'9999-12-31') AS LEDTS
		  ,HashDiff
		  ,NatSalesOrderNo
		  ,NatSalesOrderItemNo
		  ,ActualDeliveryQuantity
		  ,IsDeleted
		  ,SourceIdentifier
	FROM preHash
	WHERE HashDiff <> pre_HashDiff
	   OR RankOverAll = 1 -- to get the first entry
)
INSERT INTO etl.S4Hana_DeliveryDocumentItemsHistory
	  (DeliveryNoteNumber
	  ,DeliveryNoteItemNo
	  ,LDTS
	  ,LEDTS
	  ,HashDiff
	  ,NatSalesOrderNo
	  ,NatSalesOrderItemNo
	  ,ActualDeliveryQuantity
	  ,IsDeleted
	  ,SourceIdentifier)
SELECT DeliveryNoteNumber
	  ,DeliveryNoteItemNo
	  ,LDTS
	  ,LEDTS
	  ,HashDiff
	  ,NatSalesOrderNo
	  ,NatSalesOrderItemNo
	  ,ActualDeliveryQuantity
	  ,IsDeleted
	  ,SourceIdentifier
FROM DiffCheck
WHERE SourceIdentifier = 1 -- only new entiers 
	OR (SourceIdentifier = 2 AND LEDTS <> '9999-12-31') -- existing entries to update LEDTS in the HIST table 
OPTION (LABEL='etl.S4Hana_spDeliveryDocumentItemsHistory : S4Hana_DeliveryDocumentItemsHistoryNew')

BEGIN TRAN -- Make sure Insert and Update are done in the same transaction
	INSERT INTO biz.S4Hana_DeliveryDocumentItemsHistory 
		  (DeliveryNoteNumber
		  ,DeliveryNoteItemNo
		  ,LDTS
		  ,LEDTS
		  ,HashDiff
		  ,NatSalesOrderNo
		  ,NatSalesOrderItemNo
		  ,ActualDeliveryQuantity
		  ,IsDeleted)
	SELECT DeliveryNoteNumber
		  ,DeliveryNoteItemNo
		  ,LDTS
		  ,LEDTS
		  ,HashDiff
		  ,NatSalesOrderNo
		  ,NatSalesOrderItemNo
		  ,ActualDeliveryQuantity
		  ,IsDeleted
	FROM etl.S4Hana_DeliveryDocumentItemsHistory
	WHERE SourceIdentifier = 1 -- only new entiers
	OPTION (LABEL='etl.S4Hana_spDeliveryDocumentItemsHistory : S4Hana_DeliveryDocumentItemsHistory Insert')

	--Update LEDTS for entires with fresh inserted entries for this BK
	UPDATE hist
	SET hist.LEDTS = new.LEDTS
	FROM biz.S4Hana_DeliveryDocumentItemsHistory AS hist
	INNER JOIN etl.S4Hana_DeliveryDocumentItemsHistory AS new
		ON hist.NatSalesOrderNo = new.NatSalesOrderNo  -- join over NatSalesOrderNo  because the distribution of the tables via NatSalesOrderNo order by LDTS
		AND hist.DeliveryNoteNumber = new.DeliveryNoteNumber
		AND hist.DeliveryNoteItemNo = new.DeliveryNoteItemNo
		AND hist.LDTS = new.LDTS
	WHERE hist.LEDTS = '9999-12-31'
	  AND new.SourceIdentifier = 2 -- only update Objects loaded from Hist table
	OPTION (LABEL='etl.S4Hana_spDeliveryDocumentItemsHistory : S4Hana_DeliveryDocumentitemsHistory Update')
COMMIT TRAN; 
-- Update End of the load
UPDATE DTlogs
SET ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

END -- END SP