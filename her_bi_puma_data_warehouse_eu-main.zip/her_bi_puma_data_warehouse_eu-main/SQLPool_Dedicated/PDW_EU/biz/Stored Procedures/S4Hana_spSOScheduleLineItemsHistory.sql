﻿CREATE PROC [biz].[S4Hana_spSOScheduleLineItemsHistory] @LDTS [DATETIME2](7) AS
BEGIN
SET NOCOUNT ON

-- DECLARE @LDTS DATETIME2(7) = '2000-01-01'
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(7) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(7)
DECLARE @DestinationLastLoadDate DATETIME2(7)
DECLARE @BatchLdts DATETIME2(7) = @LDTS


IF(EXISTS(SELECT 1 FROM biz.S4Hana_SOScheduleLineItemsHistory))
BEGIN
	SELECT @DestinationLastLoadDate = MAX(LDTS)
	FROM biz.S4Hana_SOScheduleLineItemsHistory
END
ELSE BEGIN
	SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
END 

IF(EXISTS(SELECT 1 FROM stag.S4Hana_SOScheduleLineItems_full))
BEGIN
	SELECT @SourceLastLoadDate = MAX(_LDTS)
	FROM stag.S4Hana_SOScheduleLineItems
END
ELSE BEGIN
	SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
END 

--Log Data load
INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'spSoScheduleLinesHistory'
			,'prepSoDocHistory'
			,'NatSalesOrdersOohHistory'
			,'sales'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts


IF OBJECT_ID('tempdb..#SoScheduleLinesFullLast') IS NOT NULL
BEGIN
    DROP TABLE #SoScheduleLinesFullLast
END

CREATE TABLE #SoScheduleLinesFullLast
WITH
(DISTRIBUTION = HASH(NatSalesOrderNo)
,HEAP)
AS
WITH deDuplicated AS
( SELECT stagSoDocSchLFull.SalesDocument AS NatSalesOrderNo
		,stagSoDocSchLFull.SalesDocumentItem AS NatSalesOrderItemNo
		,stagSoDocSchLFull.ScheduleLine AS NatSalesOrderItemScheduleLineNo
		,stagSoDocSchLFull._LDTS AS LDTS
		--,stagSoDocSchLFull.DeliveryDate AS SODeliveryDate
		,stagSoDocSchLFull.ConfdOrderQtyByMatlAvailCheck AS ConfirmedQty
		,stagSoDocSchLFull.ConfirmedDeliveryDate as ConfirmedDeliveryDate
		,CONVERT(TINYINT,(CASE WHEN stagSoDocSchLFull.__operation_type = 'X' THEN 1 ELSE 0 END)) AS IsDeleted		
		,ROW_NUMBER() OVER (PARTITION BY stagSoDocSchLFull.SalesDocument, stagSoDocSchLFull.SalesDocumentItem, stagSoDocSchLFull.ScheduleLine, stagSoDocSchLFull._LDTS ORDER BY stagSoDocSchLFull.__timestamp DESC) AS rn_deDup
FROM stag.S4Hana_SOScheduleLineItems_full AS stagSoDocSchLFull
	WHERE stagSoDocSchLFull._LDTS > @DestinationLastLoadDate
)
SELECT NatSalesOrderNo
	  ,NatSalesOrderItemNo
	  ,NatSalesOrderItemScheduleLineNo
	  ,LDTS
	  ,CONVERT(BINARY(16), 
			HASHBYTES('MD5',CONCAT( 
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),NatSalesOrderNo)))),'_', 
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),NatSalesOrderItemNo)))),'_',		
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),NatSalesOrderItemScheduleLineNo)))),'_',
--			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),SODeliveryDate, 126)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ConfirmedQty)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ConfirmedDeliveryDate)))),'_', 
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),IsDeleted))))
         ))) AS HashDiff 
	--  ,SODeliveryDate
	  ,ConfirmedQty
	  ,ConfirmedDeliveryDate
	  ,IsDeleted
	  ,CONVERT(TINYINT,1) AS SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist
FROM deDuplicated
WHERE rn_deDup = 1
OPTION (LABEL='etl.S4Hana_spSOScheduleLineItemsHistory : #SoScheduleLinesFullLast ScoId1')

-- Add last related entires from Hist which are in the new batch
INSERT INTO #SoScheduleLinesFullLast
	(NatSalesOrderNo
	,NatSalesOrderItemNo
	,NatSalesOrderItemScheduleLineNo
	,LDTS
	,HashDiff
--	,SODeliveryDate
	,ConfirmedQty
	,ConfirmedDeliveryDate
	,IsDeleted
	,SourceIdentifier)
SELECT SoSchHist.NatSalesOrderNo
	  ,SoSchHist.NatSalesOrderItemNo
	  ,SoSchHist.NatSalesOrderItemScheduleLineNo
	  ,SoSchHist.LDTS
	  ,SoSchHist.HashDiff
--	  ,SoSchHist.SODeliveryDate
	  ,SoSchHist.ConfirmedQty
	  ,SoSchHist.ConfirmedDeliveryDate
	  ,SoSchHist.IsDeleted	  
	  ,CONVERT(TINYINT,2) AS SourceIdentifier --> 1 = new from Stag ; 2 = last entry from Hist
FROM #SoScheduleLinesFullLast AS stagNew
INNER JOIN biz.S4Hana_SOScheduleLineItemsHistory AS SoSchHist
		ON stagNew.NatSalesOrderNo = SoSchHist.NatSalesOrderNo
		AND stagNew.NatSalesOrderItemNo = SoSchHist.NatSalesOrderItemNo
		AND stagNew.NatSalesOrderItemScheduleLineNo = SoSchHist.NatSalesOrderItemScheduleLineNo
		AND SoSchHist.LEDTS = '9999-12-31' ---> Get latest entrie from the hist table 


IF OBJECT_ID('tempdb..#SOScheduleLineItemsNewHistory') IS NOT NULL
BEGIN
    DROP TABLE #SOScheduleLineItemsNewHistory
END


;CREATE TABLE #SOScheduleLineItemsNewHistory
WITH
(DISTRIBUTION = HASH(NatSalesOrderNo)
,HEAP)
AS
WITH preHash AS 
	(SELECT NatSalesOrderNo
		   ,NatSalesOrderItemNo
		   ,NatSalesOrderItemScheduleLineNo
		   ,LDTS
		   ,HashDiff
	--	   ,SODeliveryDate
		   ,ConfirmedQty
		   ,ConfirmedDeliveryDate
		   ,IsDeleted
		   ,SourceIdentifier
		   ,LAG(HashDiff) OVER (PARTITION BY NatSalesOrderNo, NatSalesOrderItemNo, NatSalesOrderItemScheduleLineNo ORDER BY LDTS, SourceIdentifier DESC) AS pre_HashDiff -- Add SourceIdentifier rank to take first the existing Data in case there are the same content in the source
		   ,ROW_NUMBER() OVER (PARTITION BY NatSalesOrderNo, NatSalesOrderItemNo, NatSalesOrderItemScheduleLineNo ORDER BY LDTS, SourceIdentifier DESC) AS RankOverAll
	FROM #SoScheduleLinesFullLast)
,DiffCheck AS (	
	SELECT NatSalesOrderNo
		  ,NatSalesOrderItemNo
		  ,NatSalesOrderItemScheduleLineNo
		  ,LDTS
		  ,ISNULL((DateAdd(ss ,-1, LEAD(LDTS) OVER (PARTITION BY NatSalesOrderNo, NatSalesOrderItemNo, NatSalesOrderItemScheduleLineNo ORDER BY LDTS))),'9999-12-31') AS LEDTS
		  ,HashDiff
	--	  ,SODeliveryDate
		  ,ConfirmedQty
		  ,ConfirmedDeliveryDate
		  ,IsDeleted
		  ,SourceIdentifier
	FROM preHash
	WHERE HashDiff <> pre_HashDiff
	   OR RankOverAll = 1 -- to get the first entry
) 
SELECT NatSalesOrderNo
	  ,NatSalesOrderItemNo
	  ,NatSalesOrderItemScheduleLineNo
	  ,LDTS
	  ,LEDTS
	  ,HashDiff
--	  ,SODeliveryDate
	  ,ConfirmedQty
	  ,ConfirmedDeliveryDate
	  ,IsDeleted
	  ,SourceIdentifier
FROM DiffCheck
WHERE SourceIdentifier = 1 -- only new entiers 
  OR (SourceIdentifier = 2 AND LEDTS <> '9999-12-31') -- existing entries to update LEDTS in the HIST table 

BEGIN TRAN -- Make sure Insert and Update are done in the same transaction
	-- Insert new entries to 
	INSERT INTO biz.S4Hana_SOScheduleLineItemsHistory
		  (NatSalesOrderNo
		  ,NatSalesOrderItemNo
		  ,NatSalesOrderItemScheduleLineNo
		  ,LDTS
		  ,LEDTS
		  ,HashDiff
--		  ,SODeliveryDate
		  ,ConfirmedQty
		  ,ConfirmedDeliveryDate
		  ,IsDeleted)
	SELECT NatSalesOrderNo
		  ,NatSalesOrderItemNo
		  ,NatSalesOrderItemScheduleLineNo
		  ,LDTS
		  ,LEDTS
		  ,HashDiff
--		  ,SODeliveryDate
		  ,ConfirmedQty
		  ,ConfirmedDeliveryDate
		  ,IsDeleted
	FROM  #SOScheduleLineItemsNewHistory
	WHERE SourceIdentifier = 1 -- only new entiers 

	--Update LEDTS for entires with fresh inserted entries for this BK
	UPDATE histPre
	SET histPre.LEDTS = new.LEDTS
	FROM biz.S4Hana_SOScheduleLineItemsHistory AS histPre
	INNER JOIN #SOScheduleLineItemsNewHistory AS new
		ON histPre.NatSalesOrderNo = new.NatSalesOrderNo  -- join over SalesOrderNo and not HashDiff because the distribution of the tables via SalesOrderNo order by LDTS
		AND histPre.NatSalesOrderItemNo = new.NatSalesOrderItemNo
		AND histPre.NatSalesOrderItemScheduleLineNo = new.NatSalesOrderItemScheduleLineNo
		AND histPre.LDTS = new.LDTS
	WHERE histPre.LEDTS = '9999-12-31'
	  AND new.SourceIdentifier = 2 -- only update Objects loaded from Hist table
COMMIT TRAN; 

-- Update End of the load
UPDATE DTlogs
SET ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

END -- END SP