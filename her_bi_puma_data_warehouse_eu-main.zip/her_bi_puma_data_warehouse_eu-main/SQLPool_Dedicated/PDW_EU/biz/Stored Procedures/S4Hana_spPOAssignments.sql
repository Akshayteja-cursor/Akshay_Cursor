﻿CREATE PROC [biz].[S4Hana_spPOAssignments] @ldts [DATETIME2](7) AS
BEGIN
	SET NOCOUNT ON;
	SET ANSI_WARNINGS ON;

	DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
	DECLARE @ExecStart DATETIME2(7) = GETDATE()
	DECLARE @SourceLastLoadDate DATETIME2(7)
	DECLARE @DestinationLastLoadDate DATETIME2(7)
	DECLARE @BatchLdts DATETIME2(7) = @LDTS
	DECLARE @AffectedRows BIGINT = NULL

	IF(EXISTS(SELECT 1 FROM biz.S4Hana_POAssignments))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(LDTS))
	FROM biz.S4Hana_POAssignments
	END
	ELSE BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

	IF(EXISTS(SELECT 1 FROM stag.S4Hana_POAssignments))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(_LDTS))
		FROM stag.S4Hana_POAssignments
	END
	ELSE BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END 


	--Log Data load
	INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'S4Hana_spPOAssignments'
			,'biz_POAssignments'
			,'S4Hana_POAssignments'
			,'biz'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts


	IF OBJECT_ID(N'tempdb..#POA') IS NOT NULL
	DROP TABLE #POA;

	SELECT
	   CONCAT(PONo, '|', POItemNo, '|', AccountAssignmentNumber) AS POAssignments_BK
	  ,PONo
	  ,POItemNo
	  ,AccountAssignmentNumber
	  ,SalesOrderNo
	  ,SalesOrderItemNo
	  ,SalesOrderScheduleLine
	  ,IsDeleted
	  ,LDTS
	  ,CONVERT([BINARY](16),
				HASHBYTES('MD5',CONCAT(
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),PONo 							  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),POItemNo						  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),AccountAssignmentNumber		  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),SalesOrderNo					  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),SalesOrderItemNo				  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),SalesOrderScheduleLine		  )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[IsDeleted]))))))       
			) AS HashDiff
INTO #POA
FROM
      (
          SELECT
               poa.PONo								AS PONo                    -- BK
             , poa.POItemNo							AS POItemNo                -- BK
             , poa.AccountAssignmentNumber			AS AccountAssignmentNumber -- BK
             , poa.SalesOrderNo                     AS SalesOrderNo
             , poa.SalesOrderItemNo                 AS SalesOrderItemNo
             , poa.SalesOrderScheduleLine			AS SalesOrderScheduleLine
             , IsDeleted
             , poa.LDTS								AS LDTS
           
         FROM stag.S4Hana_vPOAssignments poa
		) X
WHERE LDTS >= @ldts
	
		-- count new Records for S4Hana_POAssignments
		    SELECT @AffectedRows = COUNT(*)
			FROM #POA AS stg LEFT JOIN biz.S4Hana_POAssignments AS prd 
			ON prd.POAssignments_BK = stg.POAssignments_BK 
			WHERE prd.POAssignments_BK IS NULL

   --load new
   INSERT INTO biz.S4Hana_POAssignments
			(
				 POAssignments_BK
	            ,PONo
	            ,POItemNo
	            ,AccountAssignmentNumber
	            ,SalesOrderNo
	            ,SalesOrderItemNo
	            ,SalesOrderScheduleLine
	            ,IsDeleted
	            ,LDTS
				,[HashDiff]			
			)
	SELECT 
				 stg.POAssignments_BK
	            ,stg.PONo
                ,stg.POItemNo
                ,stg.AccountAssignmentNumber
                ,stg.SalesOrderNo
                ,stg.SalesOrderItemNo
                ,stg.SalesOrderScheduleLine
                ,stg.IsDeleted
                ,stg.LDTS
                ,stg.[HashDiff]			
                

		 FROM #POA AS stg LEFT JOIN biz.S4Hana_POAssignments AS prd 
		 ON prd.POAssignments_BK = stg.POAssignments_BK 
		 WHERE prd.POAssignments_BK IS NULL
	
		UPDATE DTlogs
		SET Inserted = @AffectedRows
		FROM etl.DataTransferLogs DTlogs
		WHERE DataTransferLogId = @DataTransferLogId


		-- count new Records for S4Hana_POAssignments
		SELECT @AffectedRows = COUNT(*)
		FROM #POA AS stg JOIN biz.S4Hana_POAssignments AS prd 
		ON prd.POAssignments_BK = stg.POAssignments_BK
		WHERE stg.HashDiff <> prd.HashDiff

		UPDATE DTlogs
		SET Updated = @AffectedRows
		, ExecEnd = GETDATE()
		FROM etl.DataTransferLogs DTlogs
		WHERE DataTransferLogId = @DataTransferLogId

		--update non deleted records
		  UPDATE prd SET	
				 prd.PONo                       = stg.PONo                     
                ,prd.POItemNo				    = stg.POItemNo
                ,prd.AccountAssignmentNumber    = stg.AccountAssignmentNumber
                ,prd.SalesOrderNo			    = stg.SalesOrderNo
                ,prd.SalesOrderItemNo		    = stg.SalesOrderItemNo
                ,prd.SalesOrderScheduleLine	    = stg.SalesOrderScheduleLine
	            ,prd.IsDeleted       			= stg.IsDeleted       
                ,prd.LDTS						= stg.LDTS
				,prd.[HashDiff]					= stg.[HashDiff]	


			FROM #POA AS stg JOIN biz.S4Hana_POAssignments AS prd 
			ON prd.POAssignments_BK = stg.POAssignments_BK
			WHERE stg.HashDiff <> prd.HashDiff and stg.IsDeleted = 0

		 --update deletions (only deleted status and LDTS)
		 UPDATE prd SET
				 prd.LDTS				= stg.LDTS
				,prd.IsDeleted			= stg.IsDeleted
				,prd.[HashDiff]			= stg.[HashDiff]

		 	FROM #POA AS stg JOIN biz.S4Hana_POAssignments AS prd 
			ON prd.POAssignments_BK = stg.POAssignments_BK
			WHERE stg.HashDiff <> prd.HashDiff and stg.IsDeleted = 1


END

-- truncate table biz.S4Hana_POAssignments
-- exec [biz].[S4Hana_spPOAssignments]'1900-01-01'