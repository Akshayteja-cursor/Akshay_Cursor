﻿CREATE PROC [biz].[S4Hana_spAggPOPricingConditions] @LDTS [DATETIME2](7) AS
BEGIN
    SET NOCOUNT ON
    SET ANSI_WARNINGS ON

    IF OBJECT_ID(N'tempdb..#POsWithChangedConditions') IS NOT NULL
        DROP TABLE #POsWithChangedConditions

    CREATE TABLE #POsWithChangedConditions
    WITH
    (
      DISTRIBUTION = HASH(PONo)
    , CLUSTERED INDEX (PONo, POItemNo, IntPupMasterId)
    )
    AS
    SELECT DISTINCT
           podi.PONo
         , podi.POItemNo
         , i.IntPupMasterId
    FROM   biz.S4Hana_POPricingConditions    popc
    JOIN   stag.S4Hana_vPODocuments          pod  ON popc.PricingDocument = pod.PurchasingDocumentCondition
	JOIN   biz.S4Hana_PODocumentItems		 podi ON RIGHT(popc.PricingDocumentItem, 5) = podi.POItemNo AND pod.PONo = podi.PONo
    JOIN   pdwref.S4Hana_PurchaseOrderTypes  pot  ON pod.POTypeCode = pot.EBPIndicator
	JOIN   stag.S4Hana_vPlants		         SHVP ON SHVP.StoreCode = podi.SiteCode
	JOIN   pdwref.S4Hana_Interfaces          i    ON i.SalesOrg = SHVP.SalesOrganizationCode AND i.Interface='EBP'
    WHERE  popc.LDTS >= @LDTS
    OPTION (LABEL = 'biz.S4Hana_spAggPOPricingConditions: IdentifyChangedPOsStatement')

    IF OBJECT_ID(N'tempdb..#AggPOPricingConditions') IS NOT NULL
        DROP TABLE #AggPOPricingConditions

    CREATE TABLE #AggPOPricingConditions
    WITH
    (
      DISTRIBUTION = HASH(PONo)
    , CLUSTERED INDEX (PONo, POItemNo, IntPupMasterId)
    )
    AS
    SELECT
        PT.PONo     --BK
      , PT.POItemNo --BK
      , PT.IntPupMasterId
      , PT.[GRWR]
      , PT.[NAVS]
      , PT.[P101]
      , PT.[PB00]
      , PT.[PBXX]
      , PT.[SKTO]
      , PT.[WOTB]
      , PT.[ZDIS]
      , PT.[ZDVG]
      , PT.[ZFR1]
      , PT.[ZIDU]
      , PT.[ZIF%]
      , PT.[ZIFV]
      , PT.[ZIHF]
      , PT.[ZIIN]
      , PT.[ZINC]
      , PT.[ZINM]
      , PT.[ZIUP]
      , PT.[ZMAN]
      , PT.[ZNF%]
      , PT.[ZPB0]
      , PT.[ZPBX]
      , PT.[ZSD1]
      , PT.[ZSD2]
      , PT.[ZSFP]
      , PT.[ZSH1]
      , PT.[ZSL1]
      , PT.[ZSL2]
      , PT.[ZSL3]
      , PT.[ZSM1]
      , PT.[ZSMS]
      , PT.[ZSO1]
      , PT.[ZSO2]
      , PT.[ZSOC]
      , PT.[ZSP1]
      , PT.[ZSP4]
      , PT.[ZSQ1]
      , PT.[ZSQ2]
      , PT.[ZSR1]
      , PT.[ZSRD]
      , PT.[ZSSC]
      , PT.[ZSSM]
      , PT.[ZSV1]
      , PT.[ZSV2]
      , PT.[ZSWC]
      , PT.[ZVAT]
      , @LDTS    AS LDTS
      , CONVERT([BINARY](16),
            HASHBYTES('MD5',CONCAT(
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.PONo)))),'_',     --BK
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.POItemNo)))),'_', --BK
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.IntPupMasterId)))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[GRWR])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[NAVS])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[P101])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[PB00])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[PBXX])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[SKTO])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[WOTB])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZDIS])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZDVG])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZFR1])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZIDU])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZIF%])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZIFV])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZIHF])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZIIN])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZINC])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZINM])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZIUP])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZMAN])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZNF%])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZPB0])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZPBX])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZSD1])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZSD2])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZSFP])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZSH1])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZSL1])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZSL2])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZSL3])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZSM1])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZSMS])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZSO1])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZSO2])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZSOC])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZSP1])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZSP4])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZSQ1])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZSQ2])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZSR1])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZSRD])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZSSC])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZSSM])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZSV1])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZSV2])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZSWC])))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PT.[ZVAT]))))))
        )       AS HashDiff
    FROM
        (
            SELECT
                  powcc.PONo
                , powcc.POItemNo
                , powcc.IntPupMasterId
                , popc.ConditionTypeCode
                , CASE
                      WHEN popc.IsDeleted = 1
                          THEN 0
                      ELSE popc.ConditionAmount
                  END AS ConditionAmount
			FROM   biz.S4Hana_POPricingConditions    popc
			JOIN   stag.S4Hana_vPODocuments          pod ON popc.PricingDocument = pod.PurchasingDocumentCondition
			JOIN   biz.S4Hana_PODocumentItems		 podi ON RIGHT(popc.PricingDocumentItem, 5) = podi.POItemNo AND pod.PONo = podi.PONo
			JOIN   #POsWithChangedConditions         powcc ON podi.PONo = powcc.PONo AND podi.POItemNo = powcc.POItemNo
			WHERE  popc.ConditionApplication = 'M'
        ) AS ST
    PIVOT
    (
        SUM(ST.ConditionAmount)
        FOR ConditionTypeCode IN ([GRWR], [NAVS], [P101], [PB00], [PBXX], [SKTO], [WOTB], [ZDIS], [ZDVG], [ZFR1]
                                , [ZIDU], [ZIF%], [ZIFV], [ZIHF], [ZIIN], [ZINC], [ZINM], [ZIUP], [ZMAN], [ZNF%]
                                , [ZPB0], [ZPBX], [ZSD1], [ZSD2], [ZSFP], [ZSH1], [ZSL1], [ZSL2], [ZSL3], [ZSM1]
                                , [ZSMS], [ZSO1], [ZSO2], [ZSOC], [ZSP1], [ZSP4], [ZSQ1], [ZSQ2], [ZSR1], [ZSRD]
                                , [ZSSC], [ZSSM], [ZSV1], [ZSV2], [ZSWC], [ZVAT]
                                 )
    ) PT
    OPTION (LABEL = 'biz.S4Hana_spAggPOPricingConditions: PivotStatement')

   --update changed
    UPDATE
          dest
    SET          
          dest.[GRWR] = src.[GRWR]
        , dest.[NAVS] = src.[NAVS]
        , dest.[P101] = src.[P101]
        , dest.[PB00] = src.[PB00]
        , dest.[PBXX] = src.[PBXX]
        , dest.[SKTO] = src.[SKTO]
        , dest.[WOTB] = src.[WOTB]
        , dest.[ZDIS] = src.[ZDIS]
        , dest.[ZDVG] = src.[ZDVG]
        , dest.[ZFR1] = src.[ZFR1]
        , dest.[ZIDU] = src.[ZIDU]
        , dest.[ZIF%] = src.[ZIF%]
        , dest.[ZIFV] = src.[ZIFV]
        , dest.[ZIHF] = src.[ZIHF]
        , dest.[ZIIN] = src.[ZIIN]
        , dest.[ZINC] = src.[ZINC]
        , dest.[ZINM] = src.[ZINM]
        , dest.[ZIUP] = src.[ZIUP]
        , dest.[ZMAN] = src.[ZMAN]
        , dest.[ZNF%] = src.[ZNF%]
        , dest.[ZPB0] = src.[ZPB0]
        , dest.[ZPBX] = src.[ZPBX]
        , dest.[ZSD1] = src.[ZSD1]
        , dest.[ZSD2] = src.[ZSD2]
        , dest.[ZSFP] = src.[ZSFP]
        , dest.[ZSH1] = src.[ZSH1]
        , dest.[ZSL1] = src.[ZSL1]
        , dest.[ZSL2] = src.[ZSL2]
        , dest.[ZSL3] = src.[ZSL3]
        , dest.[ZSM1] = src.[ZSM1]
        , dest.[ZSMS] = src.[ZSMS]
        , dest.[ZSO1] = src.[ZSO1]
        , dest.[ZSO2] = src.[ZSO2]
        , dest.[ZSOC] = src.[ZSOC]
        , dest.[ZSP1] = src.[ZSP1]
        , dest.[ZSP4] = src.[ZSP4]
        , dest.[ZSQ1] = src.[ZSQ1]
        , dest.[ZSQ2] = src.[ZSQ2]
        , dest.[ZSR1] = src.[ZSR1]
        , dest.[ZSRD] = src.[ZSRD]
        , dest.[ZSSC] = src.[ZSSC]
        , dest.[ZSSM] = src.[ZSSM]
        , dest.[ZSV1] = src.[ZSV1]
        , dest.[ZSV2] = src.[ZSV2]
        , dest.[ZSWC] = src.[ZSWC]
        , dest.[ZVAT] = src.[ZVAT]
        , dest.LDTS = src.LDTS
        , dest.HashDiff = src.HashDiff
    FROM  biz.S4Hana_AggPOPricingConditions  AS dest
    JOIN  #AggPOPricingConditions            AS src ON src.PONo = dest.PONo AND src.POItemNo = dest.POItemNo AND src.IntPupMasterId = dest.IntPupMasterId
    WHERE dest.HashDiff <> src.HashDiff
    OPTION (LABEL = 'biz.S4Hana_spAggPOPricingConditions: UpdateStatement')

    --load new
    INSERT INTO biz.S4Hana_AggPOPricingConditions
    (
        PONo            --BK
      , POItemNo        --BK
      , IntPupMasterId  --BK
      , [GRWR]
      , [NAVS]
      , [P101]
      , [PB00]
      , [PBXX]
      , [SKTO]
      , [WOTB]
      , [ZDIS]
      , [ZDVG]
      , [ZFR1]
      , [ZIDU]
      , [ZIF%]
      , [ZIFV]
      , [ZIHF]
      , [ZIIN]
      , [ZINC]
      , [ZINM]
      , [ZIUP]
      , [ZMAN]
      , [ZNF%]
      , [ZPB0]
      , [ZPBX]
      , [ZSD1]
      , [ZSD2]
      , [ZSFP]
      , [ZSH1]
      , [ZSL1]
      , [ZSL2]
      , [ZSL3]
      , [ZSM1]
      , [ZSMS]
      , [ZSO1]
      , [ZSO2]
      , [ZSOC]
      , [ZSP1]
      , [ZSP4]
      , [ZSQ1]
      , [ZSQ2]
      , [ZSR1]
      , [ZSRD]
      , [ZSSC]
      , [ZSSM]
      , [ZSV1]
      , [ZSV2]
      , [ZSWC]
      , [ZVAT]
      , LDTS
      , HashDiff
    )
    SELECT
              src.PONo            --BK
            , src.POItemNo        --BK
            , src.IntPupMasterId  --BK
            , src.[GRWR]
            , src.[NAVS]
            , src.[P101]
            , src.[PB00]
            , src.[PBXX]
            , src.[SKTO]
            , src.[WOTB]
            , src.[ZDIS]
            , src.[ZDVG]
            , src.[ZFR1]
            , src.[ZIDU]
            , src.[ZIF%]
            , src.[ZIFV]
            , src.[ZIHF]
            , src.[ZIIN]
            , src.[ZINC]
            , src.[ZINM]
            , src.[ZIUP]
            , src.[ZMAN]
            , src.[ZNF%]
            , src.[ZPB0]
            , src.[ZPBX]
            , src.[ZSD1]
            , src.[ZSD2]
            , src.[ZSFP]
            , src.[ZSH1]
            , src.[ZSL1]
            , src.[ZSL2]
            , src.[ZSL3]
            , src.[ZSM1]
            , src.[ZSMS]
            , src.[ZSO1]
            , src.[ZSO2]
            , src.[ZSOC]
            , src.[ZSP1]
            , src.[ZSP4]
            , src.[ZSQ1]
            , src.[ZSQ2]
            , src.[ZSR1]
            , src.[ZSRD]
            , src.[ZSSC]
            , src.[ZSSM]
            , src.[ZSV1]
            , src.[ZSV2]
            , src.[ZSWC]
            , src.[ZVAT]
            , src.LDTS
            , src.HashDiff
    FROM      #AggPOPricingConditions            AS src
    LEFT JOIN biz.S4Hana_AggPOPricingConditions  AS dest ON src.PONo = dest.PONo AND src.POItemNo = dest.POItemNo AND src.IntPupMasterId = dest.IntPupMasterId
    WHERE     dest.PONo IS NULL
    OPTION (LABEL = 'biz.S4Hana_spAggPOPricingConditions: InsertStatement')
END