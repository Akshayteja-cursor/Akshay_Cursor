﻿CREATE FUNCTION [biz].[S4Hana_fnFreeAvailableStock] (@LDTS [DATETIME2](7)) RETURNS TABLE
AS
RETURN SELECT Ranking.__operation_type,
       Ranking.HASH_BK,
       Ranking.AggInventoryMovements_HASH,
       Ranking.HASH_Diff,
       Ranking.Plant,
       Ranking.Material,
       Ranking.RequirementSegment,
       Ranking.StockSegment,
       Ranking.SequentialNumber,
       Ranking.MRPElement,
       Ranking.RunningTotal,
       Ranking.InventoryStatusType,
       Ranking.BaseUnitOfMeasure,
       Ranking.PostingDate,
       Ranking._LDTS,
       Ranking.Rnk
FROM (
			SELECT SHFAS.__operation_type,
					 SHFAS.HASH_BK,
					 SHFAS.AggInventoryMovements_HASH,
					 SHFAS.HASH_Diff,
					 SHFAS.Plant,
					 SHFAS.Material,
					 SHFAS.RequirementSegment,
					 SHFAS.StockSegment,
					 SHFAS.SequentialNumber,
					 SHFAS.MRPElement,
					 SHFAS.RunningTotal,
					 SHFAS.InventoryStatusType,
					 SHFAS.BaseUnitOfMeasure,
					 SHFAS.PostingDate,
					 SHFAS._LDTS,
					 RANK() OVER(PARTITION BY SHFAS.Plant, SHFAS.Material, SHFAS.StockSegment, SHFAS.RequirementSegment, SHFAS.SequentialNumber ORDER BY SHFAS.PostingDate DESC) AS Rnk
			FROM biz.S4Hana_FreeAvailableStock AS SHFAS
			WHERE SHFAS.OriginalLdts<@LDTS
					--AND SHFAS.Material='104050-01-110' AND SHFAS.Plant='IT01' AND SHFAS.SequentialNumber='0000000143'
		) AS Ranking
WHERE Ranking.Rnk=1
