﻿CREATE EXTERNAL DATA SOURCE [ds_bieurope_encur_curated] 
WITH (LOCATION = N'abfss://curated@bieuropeprdencur.blob.core.windows.net'
)
