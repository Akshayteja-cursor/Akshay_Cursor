﻿CREATE EXTERNAL DATA SOURCE [ds_bigbd_encur_curated]
    WITH (
    LOCATION = N'abfss://curated@bigbdprdencur.dfs.core.windows.net'
    );