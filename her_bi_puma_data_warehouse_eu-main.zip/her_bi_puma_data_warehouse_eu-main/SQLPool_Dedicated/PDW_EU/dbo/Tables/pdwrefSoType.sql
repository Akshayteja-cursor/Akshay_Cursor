﻿CREATE TABLE [dbo].[pdwrefSoType] (
    [IntSOPriceTypeCode] INT          NOT NULL,
    [MappingDesc]        VARCHAR (9)  NOT NULL,
    [SOTypeCode]         VARCHAR (4)  NOT NULL,
    [EBPDesc]            VARCHAR (30) NOT NULL,
    [ID]                 INT          IDENTITY (1, 1) NOT NULL
)
WITH (CLUSTERED COLUMNSTORE INDEX, DISTRIBUTION = ROUND_ROBIN);

