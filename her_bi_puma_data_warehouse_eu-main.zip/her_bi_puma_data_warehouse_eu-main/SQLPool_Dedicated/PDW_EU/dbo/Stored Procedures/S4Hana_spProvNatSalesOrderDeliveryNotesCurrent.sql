﻿CREATE PROC [dbo].[S4Hana_spProvNatSalesOrderDeliveryNotesCurrent] @ldts [DATETIME2](7) AS
BEGIN
    SET NOCOUNT ON;
    SET ANSI_WARNINGS ON;
    IF OBJECT_ID(N'tempdb..#tmp_result') IS not NULL
    DROP TABLE #tmp_result;
	IF OBJECT_ID(N'tempdb..#Hanger') IS not NULL
    DROP TABLE #Hanger;
    
	
	DECLARE @sysdate DATETIME;

	--for test runs
	--DECLARE @LDTS [SMALLDATETIME] = '1900-01-01'
	
	-- logging informations - BEGIN
	DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
	DECLARE @ExecStart DATETIME2(7) = GETDATE()
	DECLARE @SourceLastLoadDate DATETIME2(7)
	DECLARE @DestinationLastLoadDate DATETIME2(7)
	DECLARE @BatchLdts DATETIME2(7) = @LDTS
	DECLARE @AffectedRows BIGINT = NULL


	-- logging Informations - END

	-- get last LDTS Informations for Logging
	IF(EXISTS(SELECT 1 FROM sales.NatSalesOrderDeliveryNotesCurrent))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(LDTS))
	FROM sales.NatSalesOrderDeliveryNotesCurrent
	END
	ELSE BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

	IF(EXISTS(SELECT 1 FROM sales.NatSalesOrderDeliveryNotesCurrent))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(LDTS))
		FROM sales.NatSalesOrderDeliveryNotesCurrent
	END
	ELSE BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END
	-- Logging Informations END

	-- Log first DATA Informations

		INSERT INTO etl.DataTransferLogs
			  (DataTransferLogId
			  ,TransferName
			  ,TransferGroupName
			  ,TargetTableName
			  ,TargetSchemaName
			  ,ExecStart
			  ,SourceLastLoadDate
			  ,DestinationLastLoadDate
			  ,BatchLdts)
			  SELECT @DataTransferLogId 
					,'spProvNatSalesOrderDeliveryNotesCurrent'
					,'NatSalesOrderDeliveryDocuments'
					,'NatSalesOrderDeliveryNotesCurrent'
					,'sales'
					,@ExecStart
					,@SourceLastLoadDate
					,@DestinationLastLoadDate
					,@BatchLdts

	-- Log first DATA Informations END

/* inheriting Hanger VAS and SUB VAS */
CREATE TABLE #Hanger
WITH
(
DISTRIBUTION = HASH(refdoc)
, CLUSTERED INDEX (refdoc ASC)
)
AS
WITH Base AS (
    SELECT DISTINCT 
        hn.refdoc,
        hn.refdocitem,
        hn.field1,
        hn.vasservicetype AS VASCode,
        hn.vassubservice AS SubVASCode,
        vas.VASSERVICETYPEDESCRIPTION AS VASDesc,
        subvas.VASSUBSERVICETYPEDESCRIPTION AS SubVASDesc
    FROM stag.s4hana_vhangervas hn
    LEFT JOIN stag.S4Hana_vVASServiceTypeText vas
        ON hn.vasservicetype = vas.vasservicetype
    LEFT JOIN stag.S4Hana_vVASSubServiceTypeText subvas
        ON hn.vassubservice = subvas.vassubservicetype
    WHERE hn.isdeleted = 0
),
HangertypeAgg AS (
    SELECT refdoc, refdocitem,
           STRING_AGG(field1, ',') within GROUP ( ORDER BY field1) AS hangertype
    FROM (
        SELECT DISTINCT refdoc, refdocitem, field1 FROM Base
    ) AS DistinctHangertype
    GROUP BY refdoc, refdocitem
),
VASCodeAgg AS (
    SELECT refdoc, refdocitem,
           STRING_AGG(VASCode, ',') within GROUP ( ORDER BY VASCode) AS VASCode
    FROM (
        SELECT DISTINCT refdoc, refdocitem, VASCode FROM Base
    ) AS DistinctVASCode
    GROUP BY refdoc, refdocitem
),
SubVASCodeAgg AS (
    SELECT refdoc, refdocitem,
           STRING_AGG(SubVASCode, ',') within GROUP ( ORDER BY SubVASCode) AS SubVASCode
    FROM (
        SELECT DISTINCT refdoc, refdocitem, SubVASCode FROM Base
    ) AS DistinctSubVASCode
    GROUP BY refdoc, refdocitem
),
VASDescAgg AS (
    SELECT refdoc, refdocitem,
           STRING_AGG(VASDesc, ',') within GROUP ( ORDER BY VASDesc) AS VASDesc
    FROM (
        SELECT DISTINCT refdoc, refdocitem, VASDesc FROM Base
    ) AS DistinctVASDesc
    GROUP BY refdoc, refdocitem
),
SubVASDescAgg AS (
    SELECT refdoc, refdocitem,
           STRING_AGG(SubVASDesc, ',') within GROUP ( ORDER BY SubVASDesc) AS SubVASDesc
    FROM (
        SELECT DISTINCT refdoc, refdocitem, SubVASDesc FROM Base
    ) AS DistinctSubVASDesc
    GROUP BY refdoc, refdocitem
)
SELECT 
    b.refdoc,
    RIGHT(CONCAT('000000000', b.refdocitem), 6) AS refdocitem,
    ht.hangertype,
    vc.VASCode,
    svc.SubVASCode,
    vd.VASDesc,
    svd.SubVASDesc
FROM (
    SELECT DISTINCT refdoc, refdocitem FROM Base
) b
LEFT JOIN HangertypeAgg ht ON b.refdoc = ht.refdoc AND b.refdocitem = ht.refdocitem
LEFT JOIN VASCodeAgg vc ON b.refdoc = vc.refdoc AND b.refdocitem = vc.refdocitem
LEFT JOIN SubVASCodeAgg svc ON b.refdoc = svc.refdoc AND b.refdocitem = svc.refdocitem
LEFT JOIN VASDescAgg vd ON b.refdoc = vd.refdoc AND b.refdocitem = vd.refdocitem
LEFT JOIN SubVASDescAgg svd ON b.refdoc = svd.refdoc AND b.refdocitem = svd.refdocitem;




;WITH CTE_tmp_del AS
    (
        SELECT DISTINCT 
            delh.DeliveryNoteNumber
            ,deli.DeliveryNoteItemNo    
            ,delh.CreationDate 
            ,delh.OverallGoodsMovementStatus
            ,deli.ActualDeliveryQuantity AS ActualDeliveryQuantity
            ,cast(REPLACE(ISNULL(delh.ActualGoodsMovementDate,'1900-01-01'),'-', '') as int) AS ActualGoodsMovementDate
			,cast(REPLACE(ISNULL(delh.PlannedGoodsIssueDate,'1900-01-01'),'-', '') as int) AS PlannedGoodsIssueDate
			,CASE WHEN ISNULL(delh.ActualGoodsMovementDate , '') <> '' THEN cast(REPLACE(ISNULL(delh.ActualGoodsMovementDate,'1900-01-01'),'-', '') as int)
					ELSE cast(REPLACE(ISNULL(delh.PlannedGoodsIssueDate,'1900-01-01'),'-', '') as int)
					END AS DeliveryDate
            ,delh.OverallPackingStatus
			,delh.OverallBillingStatus
            ,delh.OverallSDProcessStatus
            ,delh.CustomerCode_SoldTo
            ,deli.SiteCode 
            ,CASE WHEN deli.IsDeleted = 1 THEN 1 ELSE 0 END AS IsDeleted 
            ,m.MaterialNumber
            ,delh.SalesOrganization
              --calculate netAmount
			,CASE WHEN deli.ActualDeliveryQuantity IS NULL THEN soi.NetAmount ELSE
					CASE WHEN soi.OrderQuantity = 0 OR deli.ActualDeliveryQuantity = 0 THEN 0 ELSE
					soi.NetAmount / soi.OrderQuantity * deli.ActualDeliveryQuantity END 
			END NetAmount
            ,deli.ActualDeliveryQuantityBaseUnit AS OrderQuantity 
            ,delh.TransactionCurrency AS CurrencyCode
            ,m.StyleNo
            ,m.ColorNo
            ,CAST(m.ProdDivCode AS INT) AS ProdDivCode
            ,m.RBUCode
            ,m.BrandCode
            ,m.MaterialCategoryCode
            ,delh.LDTS
            ,deli.ReferenceDocumentNo AS NatSalesOrderNo
			,delh.TotalCreditCheckStatus as TotalCreditCheckStatus
            ,deli.ReferenceDocumentItemNo AS NatSalesOrderItemNo
            ,delh.DeliveryNoteDocType AS DeliveryNoteTypeCode
			,dtt.DeliveryDocumentTypeDesc AS DeliveryNoteTypeDesc 
			,sodh.SalesDocumentType -- EBPRP-190
			,COALESCE(CAST(REPLACE(Sosl.RequestedDeliveryDate,'-', '') AS INT),CAST(REPLACE(soi.RequestedDeliveryDate,'-', '') AS INT))	AS RequestedDeliveryDate -- EBPRP-190
			,delh.MeansOfTransport
			,delh.SpecialProcessingCode
			,delh.GrossWeight
			,delh.ActualLoadingDate
			,delh.DeliveryDocumentBySupplier 
			,delh.GoodsIssueDate
			,delh.ConfBookingInDate
			,ConfBookingInTime
			,delh.BookingInDate
			,delh.SpecialLogisticsProcess
			,sup.SupplierName AS ActualForwardingAgentName
			,deli.OriginalDeliveryQuantity
			,CONCAT(soi.ProductSeasonyear, ProductSeason) AS SalesSeason -- EBPRP-1559
		FROM biz.S4Hana_DeliveryDocuments AS delh
		JOIN biz.S4Hana_DeliveryDocumentItems AS deli ON delh.DeliveryNoteNumber = deli.DeliveryNoteNumber
														 AND (delh.SDDocumentCategory= 'J' or delh.SDDocumentCategory ='')
		LEFT JOIN [biz].[S4Hana_SoDocumentsPartners] sdp ON sdp.SalesDocument = delh.DeliveryNoteNumber
															AND sdp.SalesDocumentItem = '000000'
		LEFT JOIN [biz].[S4Hana_SoDocumentsPartners] sdp1 ON sdp1.SalesDocument = delh.DeliveryNoteNumber
															AND sdp1.SalesDocumentItem = deli.DeliveryNoteItemNo
		LEFT JOIN stag.S4Hana_vSuppliers sup ON COALESCE(sdp1.SP,sdp.SP) = sup.SupplierCode
		LEFT JOIN [stag].[S4Hana_vDeliveryDocumentTypeTexts] dtt ON dtt.DeliveryDocumentType = delh.DeliveryNoteDocType
        LEFT JOIN biz.S4Hana_SoDocumentItems AS soi on soi.SalesDocument = deli.ReferenceDocumentNo AND soi.SalesDocumentItem = deli.ReferenceDocumentItemNo
		LEFT JOIN [biz].[S4Hana_SoDocumentsHeader] as sodh on soi.salesdocument=sodh.salesdocument
        LEFT JOIN [stag].[S4Hana_vMaterials] AS m ON deli.MaterialNumber = m.MaterialNumber
		LEFT JOIN [pdwref].vS4Hana_SalesTypes AS st 	ON st.SoTypeCode =  sodh.SalesDocumentType --> Filter in the View
		LEFT JOIN biz.S4Hana_SOScheduleLineItems Sosl ON soi.SalesDocument=sosl.SalesDocument and soi.SalesDocumentItem=sosl.SalesDocumentItem -- EBPRP-190
        WHERE (delh.LDTS >= @ldts 
					OR deli.LDTS >= @ldts
					OR soi.ldts >= @ldts
					OR m.LDTS >= @ldts
					OR dtt.LDTS >= @ldts
					OR sdp.LDTS >= @ldts
					OR sdp1.LDTS >= @ldts
					OR sup.LDTS >= @ldts
					)
    ), 

	   
CTE_result AS 
        (SELECT 
		CAST(CONCAT(LTRIM(RTRIM(del.DeliveryNoteNumber)),LTRIM(RTRIM(del.DeliveryNoteItemNo)))AS BIGINT) AS NatDeliveryNote_BK
            ,del.LDTS                                                               AS LDTS
            ,del.DeliveryNoteNumber						                            AS NatDeliveryNoteNo--BK  
            ,del.DeliveryNoteItemNo						                            AS NatDeliveryNoteItemNo--BK    
            ,i.CompanyCode                                                          AS CompanyCode                  
            ,i.IntPupMasterId                                                       AS IntPupMasterId
            ,i.PDUCode                                                              AS PDUCode
            ,del.NatSalesOrderNo                                                    AS NatSalesOrderNo
            ,del.NatSalesOrderItemNo                                                AS NatSalesOrderItemNo
            ,LEFT(del.MaterialNumber,CHARINDEX('-',del.MaterialNumber)-1)                                                        AS StyleNumber_BK 
            ,REPLACE(LEFT(del.MaterialNumber,CHARINDEX('-',del.MaterialNumber,(CHARINDEX('-',del.MaterialNumber)+1))-1),'-',' ') AS ArticleNumber_BK
            ,REPLACE(MaterialNumber,'-',' ') AS ArticleSize_BK
			,CONCAT(del.MaterialNumber ,'|',CASE WHEN TRIM(i.CompanyCode) = 'PT10' THEN 'ES10'
								  ELSE TRIM(i.CompanyCode) END)                     AS NatArticle_BK            
		    ,CONCAT(del.CustomerCode_SoldTo,'|',del.SalesOrganization)              AS NatCustomer_BK
            ,CONCAT(del.SiteCode,'|',i.CompanyCode)                                 AS NatStoreDC_BK
            ,CAST(
                CASE
                    WHEN del.OverallGoodsMovementStatus = 'C' AND del.ActualDeliveryQuantity = 0    THEN 'Cancelled'
                    WHEN del.OverallGoodsMovementStatus = 'C' AND del.ActualDeliveryQuantity > 0    THEN 'Delivered'
                    WHEN del.OverallPackingStatus = 'C'     THEN 'Packed'
                    WHEN del.OverallSDProcessStatus = 'A'   THEN 'Created'
                ELSE 'n/a' END AS VARCHAR(40))                                      AS DeliveryNoteStatusDesc       
            ,cast(REPLACE(ISNULL(CREATIONDATE,'1900-01-01'),'-', '') as int)        AS DeliveryNoteCreationDate   
            ,CAST(del.ActualDeliveryQuantity AS int)                                AS Qty
            ,CASE
                WHEN del.ActualDeliveryQuantity = 0 OR del.ActualDeliveryQuantity =0 THEN 0.00
                ELSE del.NetAmount / del.OrderQuantity * del.ActualDeliveryQuantity
            END                                                                     AS InvoicedSalesValueLC     
            ,CASE WHEN del.IsDeleted = 0 THEN 1 ELSE 0 END                          AS ACTIVE
            ,try_cast(del.RBUCode AS int)                                           AS RBUCode
            ,del.BrandCode                                                          AS BrandCode                    
            ,del.ProdDivCode                                                        AS ProdDivCode                  
            ,CAST(del.CurrencyCode AS CHAR(3))                                      AS CurrencyCode                 
            ,del.DeliveryNoteTypeCode                                               AS DeliveryNoteTypeCode
            ,del.ActualGoodsMovementDate                                            AS ActualGoodsMovementDate
			,del.PlannedGoodsIssueDate												AS PlannedGoodsIssueDate
			,del.DeliveryDate														AS DeliveryDate
			,del.DeliveryNoteTypeDesc												AS DeliveryNoteTypeDesc
			,del.SalesDocumentType
			,del.RequestedDeliveryDate
			,del.TotalCreditCheckStatus
			,del.MeansOfTransport
			,del.SpecialProcessingCode
			,del.GrossWeight
            ,case when del.ActualDeliveryQuantity = 0 then 0 
				else del.GrossWeight/del.ActualDeliveryQuantity end as GrossWeightPerUnit
			,del.ActualLoadingDate
			,del.DeliveryDocumentBySupplier
			,del.GoodsIssueDate
			,del.ConfBookingInDate
			,del.ConfBookingInTime
			,del.BookingInDate
			,del.SpecialLogisticsProcess
			,del.ActualForwardingAgentName
			,del.OriginalDeliveryQuantity
			,del.ActualDeliveryQuantity
			,CASE WHEN del.TotalCreditCheckStatus= 'A' THEN 'Credit check was executed, document OK'
				 WHEN del.TotalCreditCheckStatus= 'B' THEN 'Credit check was executed, document not OK'
				 WHEN del.TotalCreditCheckStatus= 'C' THEN 'Credit check was executed, document not OK, partial release'
				 WHEN del.TotalCreditCheckStatus= 'D' THEN 'Document released by credit representative'
				 ELSE Null END AS TotalCreditCheckStatusDesc
			,del.OverallPackingStatus 
			,del.OverallBillingStatus 
			,hn.VASCode
			,hn.SubVASCode
			,hn.VASDesc
			,hn.SubVASDesc
			,del.SalesSeason
    FROM CTE_tmp_del AS del
    JOIN stag.S4Hana_vSalesOrgToCompanyCode AS socomp ON del.SalesOrganization = socomp.Code
    JOIN pdwref.S4Hana_Interfaces AS i ON socomp.CompanyCode = i.CompanyCode AND i.Interface ='EBP'
	LEFT JOIN #Hanger hn on del.DeliveryNoteNumber = hn.refdoc AND del.DeliveryNoteItemNo = hn.refdocitem
    WHERE (del.MaterialCategoryCode <> '01' OR del.MaterialCategoryCode is null)
   /*AND ISNUMERIC(del.ColorNo) = 1 AND ISNUMERIC(del.StyleNo) = 1*/
        AND del.CustomerCode_SoldTo <> ''
    )

    SELECT NatDeliveryNote_BK
        ,LDTS
        ,NatDeliveryNoteNo
        ,NatDeliveryNoteItemNo
        ,CompanyCode
        ,IntPupMasterId
        ,PDUCode
        ,NatSalesOrderNo
        ,NatSalesOrderItemNo
		,SalesDocumentType -- EBPRP-190
		,RequestedDeliveryDate -- EBPRP-190
        ,StyleNumber_BK
        ,ArticleNumber_BK
        ,ArticleSize_BK 
        ,NatArticle_BK 
        ,NatCustomer_BK 
        ,NatStoreDC_BK 
        ,DeliveryNoteStatusDesc
        ,DeliveryNoteCreationDate
        ,Qty
        ,InvoicedSalesValueLC
        ,Active
        ,RBUCode 
        ,BrandCode
        ,ProdDivCode
        ,CurrencyCode
        ,DeliveryNoteTypeCode
		,DeliveryNoteTypeDesc
        ,ActualGoodsMovementDate
		,PlannedGoodsIssueDate
		,DeliveryDate
		,TotalCreditCheckStatus
		,TotalCreditCheckStatusDesc
		,MeansOfTransport
		,SpecialProcessingCode
		,GrossWeight
		,GrossWeightPerUnit
		,ActualLoadingDate
		,DeliveryDocumentBySupplier
		,GoodsIssueDate
		,ConfBookingInDate
		,ConfBookingInTime
		,BookingInDate
		,SpecialLogisticsProcess
		,ActualForwardingAgentName
		,OriginalDeliveryQuantity
		,ActualDeliveryQuantity
		,OverallPackingStatus
		,OverallBillingStatus
		,VASCode
		,SubVASCode
		,VASDesc
		,SubVASDesc
		,SalesSeason
		,CONVERT(BINARY(16),
            HASHBYTES('MD5',CONCAT(
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), NatDeliveryNote_BK)))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), NatDeliveryNoteNo)))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), NatDeliveryNoteItemNo)))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), CompanyCode)))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), IntPupMasterId)))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), PDUCode)))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), NatSalesOrderNo)))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), NatSalesOrderItemNo)))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), StyleNumber_BK)))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), ArticleNumber_BK)))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), ArticleSize_BK)))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), NatArticle_BK)))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), NatCustomer_BK)))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), NatStoreDC_BK)))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), DeliveryNoteStatusDesc)))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), DeliveryNoteCreationDate)))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), Qty)))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), InvoicedSalesValueLC)))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), RBUCode)))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), BrandCode)))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), ProdDivCode)))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), CurrencyCode)))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), DeliveryNoteTypeCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), DeliveryNoteTypeDesc)))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), ActualGoodsMovementDate)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), PlannedGoodsIssueDate)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), DeliveryDate)))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), SalesDocumentType)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), TotalCreditCheckStatus)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), MeansOfTransport)))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), SpecialProcessingCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), GrossWeight)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), GrossWeightPerUnit)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), ActualLoadingDate)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), DeliveryDocumentBySupplier)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), GoodsIssueDate)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), ConfBookingInDate)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), ConfBookingInTime)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), BookingInDate)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), SpecialLogisticsProcess)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), ActualForwardingAgentName)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), OriginalDeliveryQuantity)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), ActualDeliveryQuantity)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), OverallPackingStatus)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), OverallBillingStatus)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), VASCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), SubVASCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), VASDesc)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), SubVASDesc)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), SalesSeason)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), RequestedDeliveryDate))))
            ))) AS HASHDIFF
        INTO #tmp_result
        FROM CTE_result

   
   -- count new Records for NatSalesOrderDeliveryNotesCurrent
	SELECT @AffectedRows = COUNT(*)
    FROM sales.NatSalesOrderDeliveryNotesCurrent AS prd JOIN #tmp_result AS stg 
    ON prd.NatDeliveryNote_BK = stg.NatDeliveryNote_BK AND stg.HashDiff <> prd.HashDiff

	
   
   SET @sysdate= GETDATE();
    
                UPDATE prd SET  
                  prd.ModifiedOn                        = @sysdate 
                  ,prd.CompanyCode                      = stg.CompanyCode
                  ,prd.IntPupMasterId                   = stg.IntPupMasterId
                  ,prd.PDUCode                          = stg.PDUCode
                  ,prd.NatSalesOrderNo                  = stg.NatSalesOrderNo
                  ,prd.NatSalesOrderItemNo              = stg.NatSalesOrderItemNo
				  ,prd.SalesDocumentType				= stg.SalesDocumentType -- EBPRP-190
				  ,prd.RequestedDeliveryDate			= stg.RequestedDeliveryDate -- EBPRP-190
                  ,prd.StyleNumber_BK                   = CAST(ISNULL(TRY_CAST(stg.StyleNumber_BK AS INT), 0) AS INT)
                  ,prd.ArticleNumber_BK                 = stg.ArticleNumber_BK
                  ,prd.ArticleSize_BK                   = stg.ArticleSize_BK
                  ,prd.NatArticle_BK                    = stg.NatArticle_BK
                  ,prd.NatCustomer_BK                   = stg.NatCustomer_BK
                  ,prd.NatStoreDC_BK                    = stg.NatStoreDC_BK
                  ,prd.DeliveryNoteStatusDesc           = stg.DeliveryNoteStatusDesc
                  ,prd.DeliveryNoteCreationDate         = stg.DeliveryNoteCreationDate
                  ,prd.Qty                              = stg.Qty
                  ,prd.InvoicedSalesValueLC             = stg.InvoicedSalesValueLC
                  ,prd.Active                           = stg.Active
                  ,prd.RBUCode                          = stg.RBUCode
                  ,prd.BrandCode                        = stg.BrandCode
                  ,prd.ProdDivCode                      = stg.ProdDivCode
                  ,prd.CurrencyCode                     = stg.CurrencyCode
                  ,prd.DeliveryNoteTypeCode             = stg.DeliveryNoteTypeCode
                  ,prd.DeliveryNoteTypeDesc             = stg.DeliveryNoteTypeDesc
				  ,prd.ActualGoodsMovementDate          = stg.ActualGoodsMovementDate
				  ,prd.PlannedGoodsIssueDate			= stg.PlannedGoodsIssueDate
				  ,prd.DeliveryDate						= stg.DeliveryDate
				  ,prd.TotalCreditCheckStatus			= stg.TotalCreditCheckStatus
				  ,prd.TotalCreditCheckStatusDesc		= stg.TotalCreditCheckStatusDesc
				  ,prd.MeansOfTransport                 = stg.MeansOfTransport
				  ,prd.SpecialProcessingCode			= stg.SpecialProcessingCode
				  ,prd.GrossWeight						= stg.GrossWeight
				  ,prd.GrossWeightPerUnit				= stg.GrossWeightPerUnit
				  ,prd.ActualLoadingDate				= stg.ActualLoadingDate
				  ,prd.DeliveryDocumentBySupplier		= stg.DeliveryDocumentBySupplier
				  ,prd.GoodsIssueDate					= stg.GoodsIssueDate
				  ,prd.ConfBookingInDate				= stg.ConfBookingInDate
				  ,prd.ConfBookingInTime				= stg.ConfBookingInTime
				  ,prd.BookingInDate					= stg.BookingInDate
				  ,prd.SpecialLogisticsProcess			= stg.SpecialLogisticsProcess
				  ,prd.ActualForwardingAgentName		= stg.ActualForwardingAgentName
				  ,prd.OriginalDeliveryQuantity			= stg.OriginalDeliveryQuantity
				  ,prd.ActualDeliveryQuantity			= stg.ActualDeliveryQuantity
				  ,prd.OverallPackingStatus				= stg.OverallPackingStatus
				  ,prd.OverallBillingStatus				= stg.OverallBillingStatus
				  ,prd.VASCode							= stg.VASCode
				  ,prd.SubVASCode						= stg.SubVASCode
				  ,prd.VASDesc							= stg.VASDesc
				  ,prd.SubVASDesc						= stg.SubVASDesc
				  ,prd.SalesSeason						= stg.SalesSeason
                  ,prd.HashDiff                         = stg.HashDiff
                  ,prd.LDTS                             = stg.LDTS 
             FROM sales.NatSalesOrderDeliveryNotesCurrent AS prd JOIN #tmp_result AS stg 
                ON prd.NatDeliveryNote_BK = stg.NatDeliveryNote_BK AND stg.HashDiff <> prd.HashDiff
	

		-- insert Logging Informations to DataTransferLogs
		UPDATE DTlogs
		SET Updated = @AffectedRows
		, ExecEnd = GETDATE()
		FROM etl.DataTransferLogs DTlogs
		WHERE DataTransferLogId = @DataTransferLogId


		-- count new Records for S4Hana_DeliveryDocuments
		SELECT @AffectedRows = COUNT(*)
		FROM #tmp_result AS stg LEFT JOIN sales.NatSalesOrderDeliveryNotesCurrent AS prd 
		ON prd.NatDeliveryNote_BK = stg.NatDeliveryNote_BK
		WHERE prd.NatDeliveryNote_BK IS NULL
		
        --populate Fact table
    INSERT sales.NatSalesOrderDeliveryNotesCurrent(NatDeliveryNote_BK
                                          ,CreatedOn
                                          ,ModifiedOn
                                          ,NatDeliveryNoteNo
                                          ,NatDeliveryNoteItemNo
                                          ,CompanyCode
                                          ,IntPupMasterId
                                          ,PDUCode
                                          ,NatSalesOrderNo -- EBPRP-190
                                          ,NatSalesOrderItemNo -- EBPRP-190
										  ,SalesDocumentType
										  ,RequestedDeliveryDate
                                          ,StyleNumber_BK
                                          ,ArticleNumber_BK
                                          ,ArticleSize_BK
                                          ,NatArticle_BK
                                          ,NatCustomer_BK
                                          ,NatStoreDC_BK
                                          ,DeliveryNoteStatusDesc
                                          ,DeliveryNoteCreationDate
                                          ,Qty
                                          ,InvoicedSalesValueLC
                                          ,Active
                                          ,RBUCode
                                          ,BrandCode
                                          ,ProdDivCode
                                          ,CurrencyCode
                                          ,DeliveryNoteTypeCode
										  ,DeliveryNoteTypeDesc
                                          ,ActualGoodsMovementDate
										  ,PlannedGoodsIssueDate
										  ,DeliveryDate
										  ,TotalCreditCheckStatus
										  ,TotalCreditCheckStatusDesc
										  ,MeansOfTransport
										  ,SpecialProcessingCode
										  ,GrossWeight
										  ,GrossWeightPerUnit
										  ,ActualLoadingDate
										  ,DeliveryDocumentBySupplier
										  ,GoodsIssueDate
										  ,ConfBookingInDate
										  ,ConfBookingInTime
										  ,BookingInDate
										  ,SpecialLogisticsProcess
										  ,ActualForwardingAgentName
										  ,OriginalDeliveryQuantity
										  ,ActualDeliveryQuantity
										  ,OverallPackingStatus
										  ,OverallBillingStatus
										  ,VASCode
										  ,SubVASCode
										  ,VASDesc
										  ,SubVASDesc
										  ,SalesSeason
                                          ,HashDiff
                                          ,LDTS)
            SELECT  stg.NatDeliveryNote_BK
                  ,@sysdate AS CreatedOn
                  ,@sysdate AS ModifiedOn
                  ,stg.NatDeliveryNoteNo
                  ,stg.NatDeliveryNoteItemNo
                  ,stg.CompanyCode
                  ,stg.IntPupMasterId
                  ,stg.PDUCode
                  ,stg.NatSalesOrderNo
                  ,stg.NatSalesOrderItemNo
				  ,stg.SalesDocumentType -- EBPRP-190
				  ,stg.RequestedDeliveryDate -- EBPRP-190
                  ,CAST(ISNULL(TRY_CAST(stg.StyleNumber_BK AS INT), 0) AS INT) AS StyleNumber_BK
                  ,stg.ArticleNumber_BK
                  ,stg.ArticleSize_BK
                  ,stg.NatArticle_BK
                  ,stg.NatCustomer_BK
                  ,stg.NatStoreDC_BK
                  ,stg.DeliveryNoteStatusDesc
                  ,stg.DeliveryNoteCreationDate
                  ,stg.Qty
                  ,stg.InvoicedSalesValueLC
                  ,stg.Active
                  ,stg.RBUCode
                  ,stg.BrandCode
                  ,stg.ProdDivCode
                  ,stg.CurrencyCode
                  ,stg.DeliveryNoteTypeCode
				  ,stg.DeliveryNoteTypeDesc
                  ,stg.ActualGoodsMovementDate
				  ,stg.PlannedGoodsIssueDate
				  ,stg.DeliveryDate
				  ,stg.TotalCreditCheckStatus
				  ,stg.TotalCreditCheckStatusDesc
				  ,stg.MeansOfTransport
				  ,stg.SpecialProcessingCode
				  ,stg.GrossWeight
				  ,stg.GrossWeightPerUnit
				  ,stg.ActualLoadingDate
				  ,stg.DeliveryDocumentBySupplier
				  ,stg.GoodsIssueDate
				  ,stg.ConfBookingInDate
				  ,stg.ConfBookingInTime
				  ,stg.BookingInDate
				  ,stg.SpecialLogisticsProcess
				  ,stg.ActualForwardingAgentName
				  ,stg.OriginalDeliveryQuantity
				  ,stg.ActualDeliveryQuantity
				  ,stg.OverallPackingStatus
				  ,stg.OverallBillingStatus
				  ,stg.VASCode
				  ,stg.SubVASCode
				  ,stg.VASDesc
				  ,stg.SubVASDesc
				  ,stg.SalesSeason
                  ,stg.HashDiff
                  ,stg.LDTS
            FROM #tmp_result AS stg LEFT JOIN sales.NatSalesOrderDeliveryNotesCurrent AS prd ON prd.NatDeliveryNote_BK = stg.NatDeliveryNote_BK
            WHERE prd.NatDeliveryNote_BK IS NULL


		-- insert Logging Informations to DataTransferLogs
		UPDATE DTlogs
		SET Inserted = @AffectedRows
		FROM etl.DataTransferLogs DTlogs
		WHERE DataTransferLogId = @DataTransferLogId



	-- set Logging Informations

	-- count deleted Records for NatSalesOrderDeliveryNotesCurrent
	SELECT @AffectedRows = COUNT(*)
	from [biz].[S4Hana_DeliveryDocumentItems]del
	INNER JOIN sales.NatSalesOrderDeliveryNotesCurrent natSales 
					on natSales.NatDeliveryNote_BK = CAST(CONCAT(LTRIM(RTRIM(del.DeliveryNoteNumber)),LTRIM(RTRIM(del.DeliveryNoteItemNo)))AS BIGINT)
			WHERE del.IsDeleted = 1
			AND (del.LDTS            >= @ldts )


	-- update Deleted Records

	UPDATE natSales
	SET natSales.Active = CASE WHEN del.IsDeleted = 0 THEN 1 ELSE 0 END
	,natSales.ModifiedOn                        = @sysdate 
	from [biz].[S4Hana_DeliveryDocumentItems]del
	INNER JOIN sales.NatSalesOrderDeliveryNotesCurrent natSales 
					on natSales.NatDeliveryNote_BK = CAST(CONCAT(LTRIM(RTRIM(del.DeliveryNoteNumber)),LTRIM(RTRIM(del.DeliveryNoteItemNo)))AS BIGINT)
			WHERE del.IsDeleted = 1
			AND (del.LDTS            >= @ldts )

-- set loggingInformations for deletion records
UPDATE DTlogs
SET Deleted = @AffectedRows
, ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId


END

--truncate table sales.NatSalesOrderDeliveryNotesCurrent
--exec [dbo].[S4Hana_spProvNatSalesOrderDeliveryNotesCurrent]'1900-01-01'
