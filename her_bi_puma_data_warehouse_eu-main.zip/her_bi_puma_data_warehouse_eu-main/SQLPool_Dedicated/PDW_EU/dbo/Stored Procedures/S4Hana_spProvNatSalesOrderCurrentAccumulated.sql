﻿CREATE PROC [dbo].[S4Hana_spProvNatSalesOrderCurrentAccumulated] @LDTS [DATETIME2](7) AS
BEGIN
	SET NOCOUNT ON;
    SET ANSI_WARNINGS ON;
	
	DECLARE @sysdate DATETIME;
	SET @sysdate = getdate()

	----Manuell run Variable
	--DECLARE @LDTS AS [DATETIME2](7)
	--SET @LDTS = '1900-01-01'

	--Deletion of temp Tables
	IF OBJECT_ID(N'tempdb..#ChangedSOs') IS NOT NULL DROP TABLE #ChangedSOs
    IF OBJECT_ID(N'tempdb..#ChangedContrCallOff') IS NOT NULL DROP TABLE #ChangedContrCallOff
	IF OBJECT_ID(N'tempdb..#ScheduleLines') IS NOT NULL DROP TABLE #ScheduleLines
	IF OBJECT_ID(N'tempdb..#POs') IS NOT NULL DROP TABLE #POs
	IF OBJECT_ID(N'tempdb..#ChangedSOsFiltered') IS NOT NULL DROP TABLE #ChangedSOsFiltered
	IF OBJECT_ID(N'tempdb..#Result') IS NOT NULL DROP TABLE #Result
	IF OBJECT_ID(N'tempdb..#Delivery') IS NOT NULL DROP TABLE #Delivery
	IF OBJECT_ID(N'tempdb..#ResultAdd_Calloffs') IS NOT NULL DROP TABLE #ResultAdd_Calloffs
	IF OBJECT_ID(N'tempdb..#ResultwithHashdiff') IS NOT NULL DROP TABLE #ResultwithHashdiff
	IF OBJECT_ID(N'tempdb..#HangerType') IS NOT NULL DROP TABLE #HangerType
	IF OBJECT_ID(N'tempdb..#StockSource') IS NOT NULL DROP TABLE #StockSource
	IF OBJECT_ID(N'tempdb..#POUnits') IS NOT NULL DROP TABLE #POUnits
	IF OBJECT_ID(N'tempdb..#PackingRatio') IS NOT NULL DROP TABLE #PackingRatio
																		  

	-- logging informations - BEGIN
	DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
	DECLARE @ExecStart DATETIME2(7) = GETDATE()
	DECLARE @DestinationLastLoadDate DATETIME2(7)
	DECLARE @BatchLdts DATETIME2(7) = @LDTS
	DECLARE @AffectedRows BIGINT = NULL
	-- logging Informations - END

	-- get last LDTS Informations for Logging
	IF(EXISTS(SELECT 1 FROM [sales].[NatSalesOrderCurrentAccumulated]))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(modifiedOn))
	FROM [sales].[NatSalesOrderCurrentAccumulated]
	END
	ELSE BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 
	-- Logging Informations END


	-- Log first DATA Informations

	INSERT INTO etl.DataTransferLogs
			(DataTransferLogId
			,TransferName
			,TransferGroupName
			,TargetTableName
			,TargetSchemaName
			,ExecStart
			,SourceLastLoadDate
			,DestinationLastLoadDate
			,BatchLdts)
			SELECT @DataTransferLogId 
				,'S4Hana_spProvSOCurrentAccumulated'
				,'SOCurrentAccumulated'
				,'SOCurrentAccumulated'
				,'sales'
				,@ExecStart
				,NULL
				,@DestinationLastLoadDate
				,@BatchLdts

-- Log first DATA Informations END

	CREATE TABLE #ChangedSOs
	WITH
	(
		DISTRIBUTION = HASH(SONo)
		, CLUSTERED INDEX (SONo ASC)
	)
	AS
	Select
		chSos.SONo
	FROM
	(   SELECT DISTINCT
			Sodh.SalesDocument AS SONo
		FROM [biz].[S4Hana_SoDocumentsHeader] Sodh
			WHERE Sodh.LDTS >=@LDTS

		UNION
		
		SELECT DISTINCT
			Sodp.SalesDocument AS SONo
		FROM [biz].[S4Hana_SODocumentsPartners] sodp
			WHERE Sodp.LDTS >=@LDTS

		UNION


		SELECT DISTINCT
			Sodi.SalesDocument AS SONo
		FROM biz.S4Hana_SODocumentItems Sodi
			WHERE Sodi.LDTS >=@LDTS
  
	    UNION
  
		SELECT DISTINCT
			SOSch.SalesDocument AS SoNo
		FROM [stag].[S4Hana_vSOScheduleLineItems] AS SOSch
			WHERE SoSch.LDTS >=@LDTS
			
		UNION
	
		SELECT DISTINCT
			PRICE.NatSalesOrderNo AS SoNo
		FROM [biz].[S4Hana_fnSoDocItemPriceConditionsLast](@LDTS) PRICE
		
		UNION
		
		SELECT DISTINCT
			ddi.ReferenceDocumentNo AS SoNo
		FROM [biz].[S4Hana_DeliveryDocuments] dd
		INNER JOIN [biz].[S4Hana_DeliveryDocumentItems] ddi on dd.DeliveryNoteNumber = ddi.DeliveryNoteNumber
		WHERE dd.LDTS >=@LDTS 
				OR ddi.LDTS>=@LDTS

		UNION

		SELECT DISTINCT 
			assi.SalesOrderNo AS SoNo
		FROM [biz].[S4Hana_AggSOSupplyAssignments] assi
		WHERE assi.LDTS >=@LDTS
		
		UNION

		SELECT DISTINCT 
			poa.SalesOrderNo AS SoNo
		FROM stag.S4Hana_vPOAssignments poa
		INNER JOIN biz.S4Hana_PODocumentItems podi ON poa.PONo = podi.PONo AND poa.POItemNo = podi.POItemNo
		WHERE poa.LDTS >=@LDTS 
		   or podi.LDTS >=@LDTS
				
  
	)chSos

	CREATE TABLE #ChangedContrCallOff
	WITH
	(
		DISTRIBUTION = HASH(SONo)
		, CLUSTERED INDEX (SONo ASC)
	)
	AS
	Select
		chSos.SONo
	FROM
	(
	 SELECT SONo from #ChangedSOs

	 UNION
	 --WL_20240522-- Adding calloffs that might be outside of batch LDTS
	 SELECT	calloff.SalesDocument AS SONo
		FROM biz.S4Hana_SODocumentItems calloff
		inner join biz.S4Hana_SODocumentItems contract on contract.SalesDocument=calloff.ReferenceSDDocument and contract.SalesDocumentItem=calloff.ReferenceDocumentItemNumber
		inner join #ChangedSOs ChSOs on ChSOs.SONo = contract.SalesDocument
	 UNION
	 --WL_20240919-- Adding contracts that might be outside of batch LDTS
	 SELECT calloff.ReferenceSDDocument AS SoNo
		FROM biz.S4Hana_SODocumentItems calloff
		inner join #ChangedSOs ChSOs on ChSOs.SONo = calloff.SalesDocument
	) chSos

CREATE TABLE #ScheduleLines
WITH
(
DISTRIBUTION = HASH(SONo)
, CLUSTERED INDEX (SONo ASC)
)
AS
			SELECT
				chSos.SONo																			AS SoNo
				,Sosl.SalesDocumentItem																AS SoItemNo
				,CAST(REPLACE(ISNULL(Sosl.DeliveryDateMin,'1900-01-01'),'-', '') AS INT)			AS DeliveryDateMin
				,CAST(REPLACE(ISNULL(Sosl.DeliveryDateMax,'1900-01-01'),'-', '') AS INT)			AS DeliveryDateMax
				,CAST(REPLACE(ISNULL(Sosl.MaterialAvailabilityDate,'1900-01-01'),'-', '') AS INT)	AS MaterialAvailabilityDate
				,CAST(REPLACE(ISNULL(Sosl.MinMaterialAvailabilityDate,'1900-01-01'),'-', '') AS INT)	AS MinMaterialAvailabilityDate
				,DelivBlockReasonForSchedLine														AS DelivBlockReasonForSchedLine
				,Sosl.ConfirmedQty																	AS ConfirmedQty
				,Sosl.DeliveredQty																	AS DeliveredQty
				,Sosl.PurchaseRequisition															AS PurchaseRequisition
				,Sosl.HashDiff																		AS Scheduline_Hashdiff
		    FROM    #ChangedContrCallOff chSos
		    JOIN     biz.S4Hana_SOScheduleLineItems Sosl        ON chSos.SoNo = Sosl.SalesDocument

CREATE TABLE #StockSource
WITH
(
      DISTRIBUTION = HASH(SalesOrderNo)
    , CLUSTERED INDEX (SalesOrderNo ASC, SalesOrderItemNo ASC)
)
AS 
SELECT 
SalesOrderNo , 
SalesOrderItemNo ,
StockSource
FROM (
	SELECT 
	a.SalesOrderNo , 
	a.SalesOrderItemNo ,
	StockSource,
	ROW_NUMBER() OVER (PARTITION BY a.SalesOrderNo , a.SalesOrderItemNo
										   ORDER BY LDTS DESC , 
												  StockSource  DESC
										  )  as rnk 
	FROM  biz.S4Hana_SOSupplyAssignments a
	INNER JOIN #ChangedContrCallOff b on a.SalesOrderNo=b.Sono
) X
WHERE rnk = 1


CREATE TABLE #POs
WITH
(
      DISTRIBUTION = HASH(NatSalesOrderNo)
    , CLUSTERED INDEX (NatSalesOrderNo ASC, NatSalesOrderItemNo ASC)
)
AS
SELECT 
	 SalesOrderNo as NatSalesOrderNo
	,SalesOrderItemNo as NatSalesOrderItemNo
	,(SELECT STRING_AGG(PurchaseOrderNumber,',') WITHIN GROUP (ORDER BY PurchaseOrderNumber) 
                        FROM 
                          (SELECT DISTINCT value AS PurchaseOrderNumber 
					FROM STRING_SPLIT(STRING_AGG(CASE WHEN CONCAT(pod.DeletionCode,podi.DeletionCode) = '' THEN poa.PONo ELSE NULL END, ','), ',')
					) t
                )     AS NatPurchaseOrders
	,max(DeliveryDate) as Max_PODeliveryDate
	,min(DeliveryDate) as Min_PODeliveryDate
FROM biz.S4Hana_POAssignments poa
INNER JOIN #ChangedContrCallOff b on poa.SalesOrderNo=b.Sono
INNER JOIN biz.S4Hana_POScheduleLines posl ON poa.PONo = posl.PONo AND poa.POItemNo = posl.POItemNo
INNER JOIN stag.S4Hana_vPODocuments   pod  ON poa.PONo = pod.PONo
INNER JOIN biz.S4Hana_PODocumentItems podi ON poa.PONo = podi.PONo AND poa.POItemNo = podi.POItemNo
WHERE poa.AccountAssignmentNumber = '01' AND poa.SalesOrderNo <> ''
GROUP BY poa.SalesOrderNo, poa.SalesOrderItemNo

CREATE TABLE #Delivery
WITH
   (
     DISTRIBUTION = HASH(SoNo)
   , CLUSTERED INDEX (SoNo ASC, SoItemNo ASC)
   )
   AS (
 SELECT
	ddi.ReferenceDocumentNo														AS SoNo
	,ddi.ReferenceDocumentItemNo												AS SoItemNo
	,MAX(CASE WHEN (dd.OverallGoodsMovementStatus = 'C' AND ddi.ActualDeliveryQuantity = 0) --cancelled
		   	 	   OR ddi.IsDeleted = 1
			  THEN 19000101
			  ELSE CAST(REPLACE(ISNULL(dd.ActualGoodsMovementDate, '1900-01-01'), '-', '') AS INT)
		 END) 																	AS ActualGoodsMovementDate
	,SUM(CASE WHEN ddi.IsDeleted = 0 and dd.OverallBillingStatus = 'C' THEN ddi.ActualDeliveryQuantity 
					ELSE 0
		 END)																	AS CompletedDeliveryQuantity
	,SUM(CASE WHEN (dd.OverallGoodsMovementStatus = 'C' AND ddi.ActualDeliveryQuantity = 0)
					OR ddi.IsDeleted = 1
				    OR dd.ActualGoodsMovementDate IS NULL
			  THEN 0
			  ELSE ISNULL(ddi.ActualDeliveryQuantity,0)
		 END)																	AS ActualDeliveryQuantity
	,SUM(CASE WHEN (dd.OverallGoodsMovementStatus = 'C' AND ddi.ActualDeliveryQuantity = 0)
					OR ddi.IsDeleted = 1
			  THEN 0
			  ELSE ISNULL(ddi.ActualDeliveryQuantity,0)
		 END)																	AS DelNoteQty
	,SUM(CASE WHEN (dd.OverallGoodsMovementStatus = 'C' AND ddi.ActualDeliveryQuantity = 0)
					OR ddi.IsDeleted = 1
			  THEN 0
			  ELSE ISNULL(ddi.OriginalDeliveryQuantity,0)
		 END)																	AS OriginalDeliveryQuantity
             --------------------------------------------------------------------------------------------------------------------------------
             --this section not currently in use as DeliveryNoteStatusDesc is hidden in the cube
	,MIN(CASE WHEN (dd.OverallGoodsMovementStatus = 'C' AND ddi.ActualDeliveryQuantity = 0)
					OR ddi.IsDeleted = 1
                       THEN NULL
                       ELSE dd.OverallGoodsMovementStatus
                  END)											                        AS OverallGoodsMovementStatus
             ,MIN(CASE WHEN (dd.OverallGoodsMovementStatus = 'C' AND ddi.ActualDeliveryQuantity = 0)
					OR ddi.IsDeleted = 1
                       THEN NULL
                       ELSE dd.OverallPackingStatus
	     END)												                    AS OverallPackingStatus
             ,MIN(CASE WHEN (dd.OverallGoodsMovementStatus = 'C' AND ddi.ActualDeliveryQuantity = 0)
					OR ddi.IsDeleted = 1
                       THEN NULL
                       ELSE dd.OverallSDProcessStatus
	     END)												                    AS OverallSDProcessStatus
             --------------------------------------------------------------------------------------------------------------------------------
    ,(SELECT STRING_AGG(DeliveryNoteNumber,',') WITHIN GROUP (ORDER BY DeliveryNoteNumber) 
                     FROM 
                       (SELECT DISTINCT value AS DeliveryNoteNumber 
		FROM STRING_SPLIT(STRING_AGG(CASE WHEN (dd.OverallGoodsMovementStatus = 'C' AND ddi.ActualDeliveryQuantity = 0) OR ddi.IsDeleted = 1 THEN NULL ELSE ddi.DeliveryNoteNumber END, ',') ,',')
		) t
             )                                                                           AS DeliveryNoteNumbers
FROM biz.S4Hana_DeliveryDocuments dd
INNER JOIN biz.S4Hana_DeliveryDocumentItems ddi ON dd.DeliveryNoteNumber = ddi.DeliveryNoteNumber
													  
         INNER JOIN #ChangedContrCallOff chSos					ON ddi.ReferenceDocumentNo = chSos.Sono
GROUP BY
ddi.ReferenceDocumentNo
,ddi.ReferenceDocumentItemNo
    )

CREATE TABLE #ChangedSOsFiltered
    WITH
    (
      DISTRIBUTION = HASH(SONo)
    , CLUSTERED INDEX (SONo ASC, SOItemNo ASC, IntPupMasterId ASC)
    )
	AS
	SELECT
	 chsos.SoNo																AS SoNo
	 ,sodi.SalesDocumentItem												AS SoItemNo
	 ,i.RegionCode															AS RegionCode
	 ,Sodi.BillingCompanyCode												AS CompanyCode
	 ,sodi.SalesOrganization												AS SalesOrganization	
	 ,sodi.SHIPTOPARTY														AS ShipToParty
	 ,sodi.Material															AS Material
	 ,sodi.TransactionCurrency												AS TransactionCurrency
	 ,sodi.SalesDocumentRjcnReason											AS RejectionReason
	 ,CR.EBPDesc															AS RejectionReasonDesc
	 ,CAST(REPLACE(ISNULL(sodh.CreationDate,'1900-01-01'),'-', '') AS INT)	AS CreationDate
	 ,CAST(REPLACE(COALESCE(contracts.CreationDate, sodh.CreationDate, '1900-01-01'),'-', '') AS INT) AS CreationDate_Contract
	 ,CAST(REPLACE(ISNULL(sodh.RequestedDeliveryDate,'1900-01-01'),'-', '')	AS INT) AS RequestedDeliveryDateHeader
	 ,CAST(REPLACE(ISNULL(sodi.RequestedDeliveryDate,'1900-01-01'),'-', '')	AS INT) AS RequestedDeliveryDateItem
	 ,sodh.SalesDocumentType												AS SalesDocumentType
	 ,sodi.CustomerConditionGroup1											AS CustomerConditionGroup1
	 ,ISNULL(sodi.OrderQuantity,0)											AS OrderQuantity
	 ,sodi.BillToParty														AS BillToParty
	 ,ISNULL(COALESCE(sodpi.ZW,sodp.ZW),'')									AS OwnerGrParty
	 ,ISNULL(COALESCE(sodpi.AD,sodp.AD),'')									AS SalesRepParty
	 ,sodi.PayerParty														AS PayerParty
	 ,sodi.SoldToParty														AS SoldToParty
	 ,sodi.CustomerPaymentTerms												AS CustomerPaymentTerms
	 ,CAST(REPLACE(ISNULL(sodi.PricingDate,'1900-01-01'),'-', '') AS int)	AS PricingDate
	 ,sodh.DeliveryBlockReason												AS DeliveryBlockReason_header
	 ,sch.DelivBlockReasonForSchedLine									    AS DeliveryBlockReason
	 ,sch.PurchaseRequisition												AS PurchaseRequisition
	 ,sodi.StorageLocation													AS StorageLocation
	 ,sodi.Subtotal1Amount													AS Subtotal1Amount
	 ,sodi.GrossSalesValueUnit												AS GrossSalesValueUnit
	 ,sodi.NetAmount														AS NetAmount
	 ,sodi.NetAmountUnit													AS NetAmountUnit
	 ,sodi.PurchaseOrderByCustomer											AS CustomerPONumber
	 ,CONCAT(sodi.ProductSeasonyear, ProductSeason)							AS SalesSeason 
	 ,i.IntPupMasterId														AS IntPupMasterId
	 ,i.PDUCode																AS PDUCode
	 ,st.EBPDesc															AS EBPDesc
	 ,CAST(REPLACE(ISNULL(sodh.AgrmtValdtyStartDate,'1900-01-01'),'-', '') AS INT) AS ContractValidFrom
	 ,CAST(REPLACE(ISNULL(sodh.AgrmtValdtyEndDate,'1900-01-01'),'-', '') AS INT) AS ContractValidTo
	 ,sodi.Plant															AS Plant
	 ,pl.GSMCode															AS GSMStoreCode
	 ,CASE WHEN sodi.IsDeleted >= 1 
			THEN 0 
			ELSE 1 
	  END																	AS Active
	,sodi.ReferenceSDDocument												AS ReferenceSDDocument
	,sodi.ReferenceDocumentItemNumber										AS ReferenceDocumentItemNumber
	,sodi.PrecedingDocumentCategory											AS PrecedingDocumentCategory
	,CASE WHEN sodi.SalesDocumentRjcnReason <>'' AND ISNULL(RD.[RejectionDate],'1900-01-01')='1900-01-01' 
			THEN CAST(REPLACE(ISNULL(sodi.CreationDateItem,'1900-01-01'),'-', '') AS INT) -- as CREATION_DATE
			ELSE CAST(REPLACE(ISNULL(RD.RejectionDate,'1900-01-01'),'-', '') AS INT)
		END																	AS RejectionDate
	,sodi.[IncotermsClassification]											AS [IncotermsClassification]		
	,sodi.[FixedValueDate]													AS [FixedValueDate]				
	,sodh.[version]															AS [version]						
	,sodi.[CustomerPurchaseOrderType]										AS [CustomerPurchaseOrderType]	
	,sodi.[Route]															AS [Route]						
	,sodi.[YourReference]													AS [YourReference]				
	,sodi.[SalesDocumentItemCategory]										AS [SalesDocumentItemCategory]
	,sodi.[PoType]
	,sodh.[DistributionChannel]
	,sodh.[SDDocumentReason]
	,CAST(REPLACE(ISNULL(sodi.[FirstConfirmedDeliveryDate],'1900-01-01'),'-', '') AS int)		AS [FirstConfirmedDeliveryDate]
	,CAST(REPLACE(ISNULL(sodi.[OriginalRequestedDeliveryDate],'1900-01-01'),'-', '') AS int)	AS [OriginalRequestedDeliveryDate]
	,CAST(REPLACE(ISNULL(sodi.[LatestRDD],'1900-01-01'),'-', '') AS int)						AS [LatestRDD]
	,CAST(REPLACE(ISNULL(sodi.[LatestFCDD],'1900-01-01'),'-', '') AS int)						AS [LatestFCDD]
	,CAST(REPLACE(ISNULL(sodi.[LatestCdd],'1900-01-01'),'-', '') AS int)						AS [LatestCdd]
	,sodi.[UltimateCustomerBarcode]
	,sodi.[OuterCartonPackFactor]
	,sodh.[NameOfOrderer]			
	,sodi.[MaterialByCustomer]		
	,sodh.[SDDocumentCollectiveNumber]
	,sodh.CustomerPurchaseOrderSuplmnt
	,sodh.HeaderBillingBlockReason
	,sodi.NetPriceAmount
	,CASE WHEN sodi.totalSDDocReferenceStatus = '' THEN 'Z' ELSE sodi.totalSDDocReferenceStatus END AS totalSDDocReferenceStatus
	,sodh.CreatedByUser
	,sodi.RequirementSegment
	,sodi.CustomerOrdertype
	,sodi.CorrespncExternalReference
	,sodh.OverallTotalDeliveryStatus
	,po.NatPurchaseOrders
	,po.Max_PODeliveryDate
	,po.Min_PODeliveryDate
	,st.OperatorSwitch
	,sodi.InnerCartonPackFactor
	,trim(sodi.CustomerPurchaseOrderType)+ '_'+ trim(sodi.CustomerConditionGroup1) as NatOrderEntrySys
	,sodh.DeliveryWindowStart
	,sodh.DeliveryWindowEnd
	,sodi.AdditionalValueDays
	,sodh.CustomerReference
	,MaterialAvailabilityDate
    ,MinMaterialAvailabilityDate
	,mat.MaterialNumber
	,mat.StyleNo
    ,mat.RBUCode
    ,mat.BrandCode
    ,mat.ProdDivCode
    ,mat.RetailGenderCode
    ,mat.AgeGrpCode
    ,mat.ProdChrCode
    ,mat.BusSegCode    
	,sch.ConfirmedQty
    ,sch.DeliveryDateMin
    ,sch.DeliveryDateMax    
	,ddi.CompletedDeliveryQuantity
	,ddi.DeliveryNoteNumbers
	,ddi.ActualGoodsMovementDate
	,ddi.DelNoteQty
	,ddi.ActualDeliveryQuantity
	,ddi.OriginalDeliveryQuantity
	,ddi.OverallGoodsMovementStatus
	,ddi.OverallPackingStatus  
	,ddi.OverallSDProcessStatus
	,qty.FQTY
    ,qty.HQTY
    ,qty.RQTY
	,price.ZXFP
    ,price.ZXRD    ,price.ZXSM    ,price.ZXSC    ,price.ZXWC    ,price.ZXHF    ,price.ZXFV    ,price.[ZXF%]    ,price.ZXIN    ,price.ZXDU    ,price.ZIUP    ,price.ZDVS    ,price.ZIUC
    ,price.ZSFP    ,price.ZSRD    ,price.ZSSM    ,price.ZSSC    ,price.ZSWC    ,price.ZICF    ,price.ZIHF    ,price.ZIFV    ,price.[ZIF%]    ,price.ZIIN    ,price.ZIDU    ,price.VPRS
    ,price.ZCOS    ,price.ZRAS    ,price.ZGS1    ,price.ZLSM    ,price.ZST1    ,price.ZCO1    ,price.ZDCL    ,price.ZSW1    ,price.ZCDI    ,price.ZOFP    ,price.[ZOF%]    ,price.ZOFV
    ,price.ZOVA    ,price.ZOIC    ,price.ZFRH    ,price.ZRY1    ,price.ZRY2    ,price.ZRY3    ,price.ZESC    ,price.ZCOC    ,price.ZRAC
	,StockSource
	,isfinanceooh
	FROM #ChangedContrCallOff chsos
	INNER JOIN [biz].S4Hana_SODocumentItems sodi						ON sodi.SalesDocument = chsos.SoNo
	INNER JOIN [biz].[S4Hana_SODocumentsHeader] sodh					ON sodi.SalesDocument = sodh.SalesDocument
	LEFT JOIN [biz].[S4Hana_SoDocumentsHeader] contracts				ON sodi.ReferenceSDDocument = contracts.SalesDocument
	LEFT JOIN [biz].[S4Hana_SODocumentsPartners] sodp					ON sodi.SalesDocument = sodp.SalesDocument AND right(sodp.SalesDocumentItem, 6) = '000000'
	LEFT JOIN [biz].[S4Hana_SODocumentsPartners] sodpi					ON sodi.SalesDocument = sodpi.SalesDocument AND sodi.SalesDocumentItem = sodpi.SalesDocumentItem 
	INNER JOIN pdwref.vS4Hana_SalesTypes st 							ON st.SoTypeCode =  sodh.SalesDocumentType --> Filter in the View
	LEFT JOIN [pdwref].S4Hana_Interfaces i								ON i.SalesOrg = Sodi.SalesOrganization	
	LEFT JOIN [stag].[S4Hana_vPlants] Pl								ON sodi.Plant = Pl.StoreCode
	LEFT JOIN [pdwref].S4Hana_CancelReasons CR							ON sodi.SalesDocumentRjcnReason = CR.EBPIndicator
	LEFT JOIN [biz].[S4Hana_SORejectionDates] RD						ON sodi.SalesDocument = RD.SalesDocument AND sodi.SalesDocumentItem = RD.SalesDocumentItem
	LEFT JOIN #POs po												ON sodi.SalesDocument = po.NatSalesOrderNo and sodi.SalesDocumentItem = po.NatSalesOrderItemNo
	LEFT JOIN #ScheduleLines sch										ON sch.Sono = sodi.SalesDocument AND sch.SoItemNo = sodi.SalesDocumentItem
	INNER JOIN stag.S4Hana_vMaterials mat							ON mat.MaterialNumber = Sodi.Material
    LEFT JOIN [biz].[S4Hana_SoDocItemPriceConditionsHistory] Price   ON Sodi.SalesDocument = Price.NatSalesOrderNo AND Sodi.SalesDocumentItem = Price.NatSalesOrderItemNo AND Price.LEDTS = '9999-12-31'
	LEFT JOIN biz.S4Hana_AggSOSupplyAssignments qty					ON qty.SalesOrderNo = sodi.SalesDocument AND qty.SalesOrderItemNo = Sodi.SalesDocumentItem
	LEFT JOIN #StockSource stk										ON Sodi.SalesDocument = stk.SalesOrderNo and Sodi.SalesDocumentItem = stk.SalesOrderItemNo
	LEFT JOIN #Delivery AS ddi									    ON sodi.SalesDocument = ddi.SoNo AND sodi.SalesDocumentItem = ddi.SoItemNo
	WHERE mat.MaterialCategoryCode <> '01'

CREATE TABLE #Result
WITH
(
  DISTRIBUTION = HASH(NatSalesOrderNo)
, CLUSTERED INDEX (NatSalesOrderNo ASC, NatSalesOrderItemNo ASC)
)
	AS		
SELECT
CONCAT(sodi.SoNo,sodi.SoItemNo)																	AS NatSalesOrderCurrentAccumulated_BK
,sodi.SoNo																						AS NatSalesOrderNo
,sodi.SoItemNo																					AS NatSalesOrderItemNo
,sodi.ReferenceSDDocument
,sodi.ReferenceDocumentItemNumber
,sodi.CompanyCode																				AS CompanyCode
,sodi.IntPupMasterId																			AS IntPupMasterId
,sodi.PDUCode																					AS PDUCode
,CASE WHEN (ISNULL(sodi.SoldToParty,''))= '' THEN NULL ELSE CONCAT(sodi.SoldToParty, '|', sodi.SalesOrganization) END 
																								AS NatCustomer_BK
,CASE WHEN (ISNULL(Sodi.Material,''))= '' THEN NULL ELSE CONCAT(Sodi.Material, '|', 
													CASE WHEN TRIM(sodi.CompanyCode) = 'PT10' THEN 'ES10'
													ELSE TRIM(Sodi.CompanyCode) END) 
									END															AS NatArticle_BK
,CAST(ISNULL(TRY_CAST(sodi.StyleNo AS INT), 0) AS INT)											AS StyleNumber_BK
,CONVERT(CHAR(9), CASE WHEN CHARINDEX('-',LTRIM(sodi.MaterialNumber)) <> 7 
						THEN NULL 
						ELSE REPLACE(LEFT(sodi.MaterialNumber,9),'-',' ') END)					AS ArticleNumber_BK
,REPLACE(ISNULL(sodi.MaterialNumber,''),'-',' ')												AS ArticleSize_BK
,sodi.TransactionCurrency																		AS CurrencyCode

,CASE 
	WHEN (ISNULL(sodi.SalesRepParty,''))= '' 
		THEN NULL 
	ELSE CONCAT(sodi.SalesRepParty, '|', sodi.CompanyCode) 
	END																							AS NatSalesman_BK
,CASE 
	WHEN (ISNULL(sodi.Plant,''))= '' 
		THEN NULL 
	ELSE CONCAT(sodi.Plant, '|', sodi.CompanyCode) 
	END																							AS NatStoreDC_BK
,CASE   
	WHEN Sodi.SalesDocumentType in('ZDRR','ZCRR','ZPCR','ZPDR')
		THEN 3
	WHEN sodi.[RejectionReason] <> '' 
		THEN 2 --Cancelled
	WHEN (CASE WHEN isfinanceooh=1 THEN sodi.CompletedDeliveryQuantity ELSE ActualDeliveryQuantity END) > 0 
		AND (CASE WHEN isfinanceooh=1 THEN sodi.CompletedDeliveryQuantity ELSE ActualDeliveryQuantity END) < sodi.ConfirmedQty 
		THEN 5 --Partially Shipped
	WHEN (CASE WHEN isfinanceooh=1 THEN sodi.CompletedDeliveryQuantity ELSE ActualDeliveryQuantity END) >= sodi.ConfirmedQty 
		THEN 3 --Shipped
	ELSE 1 --Open
	END
																								AS SOStatusCode 
,
CASE
   
			WHEN Sodi.SalesDocumentType in('ZDRR','ZCRR','ZPCR', 'ZPDR') THEN 'Shipped'
			WHEN sodi.[RejectionReason] <> '' THEN 'Cancelled'
			WHEN (CASE WHEN isfinanceooh=1 THEN sodi.CompletedDeliveryQuantity ELSE ActualDeliveryQuantity END) > 0 
				AND (CASE WHEN isfinanceooh=1 THEN sodi.CompletedDeliveryQuantity ELSE ActualDeliveryQuantity END) < sodi.ConfirmedQty THEN 'Partially Shipped'
			WHEN (CASE WHEN isfinanceooh=1 THEN sodi.CompletedDeliveryQuantity ELSE ActualDeliveryQuantity END) >= sodi.ConfirmedQty THEN 'Shipped'
			ELSE 'Open'
			END  
																								AS SOStatusDesc
,sodi.CreationDate																				AS SOCreationDate
,sodi.RequestedDeliveryDateHeader																AS RequestedDeliveryDateHeader
,sodi.RequestedDeliveryDateItem																	AS RequestedDeliveryDateItem
,sodi.DeliveryDateMin																			AS DeliveryDateMin
,sodi.DeliveryDateMax																			AS DeliveryDateMax
,case when Sodi.RejectionReason <> '' and Sodi.SalesDocumentType in( 'ZPTO', 'ZPKP','ZCCD','ZARC') then  Sodi.OrderQuantity else sodi.ConfirmedQty end
														* sodi.OperatorSwitch										AS Qty 
,CAST( ISNULL((CASE WHEN sodi.ZXFP IS NOT NULL OR sodi.ZXFP <> 0 THEN 
                ISNULL(sodi.ZXFP,0)
                + ISNULL(sodi.ZXRD,0)
                + ISNULL(sodi.ZXSM,0)
                + ISNULL(sodi.ZXSC,0)
                + ISNULL(sodi.ZXWC,0)
                + ISNULL(sodi.ZXHF,0)
                + ISNULL(sodi.ZXFV,0)
                + ISNULL(sodi.[ZXF%],0)
                + ISNULL(sodi.ZXIN,0)
                + ISNULL(sodi.ZXDU,0)
				+ ISNULL(sodi.ZIUP,0)
				+ ISNULL(sodi.ZDVS,0)
				+ ISNULL(sodi.ZIUC,0)
			ELSE sodi.GrossSalesValueUnit	END) * ABS
              (CASE WHEN sodi.RejectionReason <> '' AND sodi.SalesDocumentType IN ( 'ZPTO', 'ZPKP','ZCCD')
								THEN sodi.OrderQuantity 
						  WHEN Sodi.SalesDocumentType in('ZDRR','ZCRR','ZPCR', 'ZPDR')
								THEN 1 
					      ELSE sodi.ConfirmedQty END)
			, 0)  * sodi.OperatorSwitch
           AS DECIMAL(38,25))	                            AS GrossValueLC
,CAST( ISNULL( sodi.NetAmountUnit * ABS
					(CASE WHEN sodi.RejectionReason <> '' AND sodi.SalesDocumentType IN ( 'ZPTO', 'ZPKP','ZCCD', 'ZARC') 
								THEN sodi.OrderQuantity 
						  WHEN Sodi.SalesDocumentType in('ZDRR','ZCRR','ZPCR', 'ZPDR')
								THEN 1 
					      ELSE sodi.ConfirmedQty END)
	 
			, 0)  * sodi.OperatorSwitch
												 AS DECIMAL(38,24))								AS InvoicedSalesValueLC
,sodi.Active																					AS Active
,CONVERT(INT,ISNULL(TRY_CONVERT(INT,sodi.RBUCode),0))                     			            AS RBUCode
,sodi.BrandCode																					AS BrandCode
,CONVERT(INT,ISNULL(TRY_CONVERT(INT,sodi.ProdDivCode),0))    			                        AS ProdDivCode
,sodi.RetailGenderCode																			AS RepGenderCode
,sodi.AgeGrpCode																					AS RepAgeGroupCode
,sodi.ProdChrCode																				AS ProductCreationModelCode
,sodi.BusSegCode																					AS BusSegmentCode
,CAST((CASE WHEN sodi.ZSFP IS NOT NULL THEN 
				ISNULL(sodi.ZSFP,0)
				+ ISNULL(sodi.ZSRD,0)
				+ ISNULL(sodi.ZSSM,0)
				+ ISNULL(sodi.ZSSC,0)
				+ ISNULL(sodi.ZSWC,0)
				+ ISNULL(sodi.ZICF,0) 
				+ ISNULL(sodi.ZIHF,0)
				+ ISNULL(sodi.ZIFV,0)
				+ ISNULL(sodi.[ZIF%],0)
				+ ISNULL(sodi.ZIIN,0)
				+ ISNULL(sodi.ZIDU,0)
			WHEN sodi.VPRS IS NOT NULL THEN sodi.VPRS
			ELSE ISNULL(sodi.ZCOS,0)	END) 
			* ABS( CASE WHEN sodi.RejectionReason <> '' AND sodi.SalesDocumentType IN ( 'ZPTO', 'ZPKP','ZCCD', 'ZARC') 						
			                  THEN sodi.OrderQuantity 
						WHEN Sodi.SalesDocumentType in('ZDRR','ZCRR','ZPCR', 'ZPDR')
							THEN 1 
					    ELSE sodi.ConfirmedQty END)  * sodi.OperatorSwitch
	            AS DECIMAL(38,25))																AS LandedCostValueLC
,CAST(( ISNULL(sodi.NetAmountUnit,0)
		+ISNULL(sodi.ZRAS,0)--Return Accruals
        +ISNULL(sodi.ZGS1,0)
		+ISNULL(sodi.ZLSM,0)--Off-Invoice Growth Bonus
        +ISNULL(sodi.ZST1,0)--Off-Invoice Sell Through Bonus
        +ISNULL(sodi.ZCO1,0)--Off-Invoice Mark Down Bonus CCM
        +ISNULL(sodi.ZDCL,0)--Delcredere provision
		+ISNULL(sodi.ZSW1,0)-- Mkt SS Bonus
		/*+ISNULL(sodi.ZSKT,0)--cash discount removed EBPRP-1141*/
		+ISNULL(sodi.ZCDI,0))--cash discount
       -- +ISNULL(sodi.ZCOI,0)) --Payment Disc (Cash Disc)
              * ABS(
         CASE WHEN sodi.RejectionReason <> '' AND sodi.SalesDocumentType IN ( 'ZPTO', 'ZPKP','ZCCD', 'ZARC') 
                            THEN sodi.OrderQuantity 
						WHEN Sodi.SalesDocumentType in('ZDRR','ZCRR','ZPCR', 'ZPDR')
							THEN 1 
					    ELSE sodi.ConfirmedQty END)  * sodi.OperatorSwitch
		   
																		AS DECIMAL(38,25)) AS OffInvoiceSalesValueLC  -- OnPrem NatSalesAttribute6 / Net2
,CAST((ISNULL(sodi.ZSFP,0)
		+ISNULL(sodi.ZSRD,0)
		+ISNULL(sodi.ZSSM,0)
		+ISNULL(sodi.ZSSC,0)
		+ISNULL(sodi.ZSWC,0)
		+ISNULL(sodi.ZICF,0)
		+ISNULL(sodi.ZIHF,0) 
		+ISNULL(sodi.ZIFV,0)
		+ISNULL(sodi.[ZIF%],0)
		+ISNULL(sodi.ZIIN,0)
		+ISNULL(sodi.ZIDU,0)
			) * ABS(CASE WHEN sodi.RejectionReason <> '' AND sodi.SalesDocumentType IN( 'ZPTO', 'ZPKP','ZCCD', 'ZARC') 
						    THEN sodi.OrderQuantity 
						 WHEN Sodi.SalesDocumentType in('ZDRR','ZCRR','ZPCR', 'ZPDR')
							THEN 1 
					     ELSE sodi.ConfirmedQty END)  * sodi.OperatorSwitch    AS DECIMAL(13,2))
																								AS TotalCogsSplitValueLC
,CAST((ISNULL(sodi.ZSFP,0)
		+ISNULL(sodi.ZIFV,0)
		+ISNULL(sodi.[ZIF%],0)
		+ISNULL(sodi.ZIIN,0)
		+ISNULL(sodi.ZIDU,0)
			) * ABS(CASE WHEN sodi.RejectionReason <> '' and sodi.SalesDocumentType in( 'ZPTO', 'ZPKP','ZCCD', 'ZARC') 
						    THEN sodi.OrderQuantity 
						WHEN Sodi.SalesDocumentType in('ZDRR','ZCRR','ZPCR', 'ZPDR')
							THEN 1 
					    ELSE sodi.ConfirmedQty END)  * sodi.OperatorSwitch AS DECIMAL(13,2))
																								AS TotalCogsSplitExclIntCompValueLC

,CAST((ISNULL(sodi.ZSRD,0)
		+ISNULL(sodi.ZSSM,0)
		+ISNULL(sodi.ZSSC,0)
		+ISNULL(sodi.ZSWC,0)
		+ISNULL(sodi.ZICF,0)
		+ISNULL(sodi.ZIHF,0)
			) * ABS(CASE WHEN sodi.RejectionReason <> '' AND sodi.SalesDocumentType IN( 'ZPTO', 'ZPKP','ZCCD', 'ZARC')
						    THEN sodi.OrderQuantity 
						WHEN Sodi.SalesDocumentType in('ZDRR','ZCRR','ZPCR', 'ZPDR')
							THEN 1 
					    ELSE sodi.ConfirmedQty END)  * sodi.OperatorSwitch AS DECIMAL(13,2))
																								AS TotalIntCompCostValueLC
,sodi.OrderQuantity	  * sodi.OperatorSwitch														AS OrderQuantity
,sodi.ConfirmedQty     * sodi.OperatorSwitch													    AS ConfirmedQty
,CAST((CASE 
			WHEN sodi.ZOFP IS NOT NULL THEN 
					sodi.ZOFP
					+ISNULL(sodi.[ZOF%],0)
					+ISNULL(sodi.[ZOFV],0)
					+ISNULL(sodi.[ZOVA],0)
					+ISNULL(sodi.ZOIC,0)
			WHEN sodi.ZSFP IS NOT NULL THEN 
					sodi.ZSFP
					+ISNULL(sodi.[ZIF%],0)
					+ISNULL(sodi.[ZIFV],0)
					+ISNULL(sodi.ZIIN,0)
					+ISNULL(sodi.ZICF,0) --added according to EBPRP-258 COGS4.0
					+ISNULL(sodi.ZIDU,0)
			WHEN sodi.VPRS IS NOT NULL THEN
					sodi.VPRS 
					-(ISNULL(sodi.ZSRD,0)
					+ISNULL(sodi.ZSSM,0)
					+ISNULL(sodi.ZSSC,0)
					+ISNULL(sodi.ZSWC,0)
					--+ISNULL(sodi.ZICF,0) --removed according to EBPRP-258 COGS4.0
					+ISNULL(sodi.ZIHF,0))
					
			ELSE
				ISNULL(sodi.ZCOS,0)
			END
			) * ABS(CASE WHEN sodi.RejectionReason <> '' AND sodi.SalesDocumentType IN( 'ZPTO', 'ZPKP','ZCCD', 'ZARC')
						    THEN sodi.OrderQuantity 
						WHEN Sodi.SalesDocumentType in('ZDRR','ZCRR','ZPCR', 'ZPDR')
							THEN 1 
					    ELSE sodi.ConfirmedQty END)  * sodi.OperatorSwitch AS DECIMAL(13,2))
																	AS MgmtCostValueLC
,CASE 
			WHEN sodi.ZOFP IS NOT NULL AND sodi.ZOIC IS NULL THEN 'Repricing necessary'
			WHEN sodi.ZSFP IS NOT NULL AND sodi.ZIDU IS NULL THEN 'Repricing necessary'
			END	AS RepricingFlag
,CASE
			WHEN sodi.ZOFP IS NOT NULL THEN 'C1 Purchase Order'
			WHEN sodi.ZSFP IS NOT NULL THEN 'C2 PriCat'
			WHEN sodi.VPRS IS NOT NULL THEN 'C3 Inventory Value'
			ELSE 'C4 Estimated COGS'
			END	AS COGSCascadeLvl
,CAST((
					ISNULL(sodi.ZFRH,0)
				   +ISNULL(sodi.ZRY1,0)
				   +ISNULL(sodi.ZRY2,0)
				   +ISNULL(sodi.ZRY3,0)
				   +ISNULL(sodi.ZESC,0)
				   +ISNULL(sodi.ZCOC,0)
			) * ABS(CASE WHEN sodi.RejectionReason <> '' AND sodi.SalesDocumentType IN( 'ZPTO', 'ZPKP','ZCCD', 'ZARC') 
						                  THEN sodi.OrderQuantity 
						WHEN Sodi.SalesDocumentType in('ZDRR','ZCRR','ZPCR', 'ZPDR')
										  THEN 1 
					    ELSE sodi.ConfirmedQty END)  * sodi.OperatorSwitch AS DECIMAL(13,2))																
																								AS TotalOVCValueLC
,CAST(COALESCE(sodi.ZOFP,sodi.ZSFP,0) * ABS(CASE WHEN sodi.RejectionReason <> '' AND sodi.SalesDocumentType IN ( 'ZPTO', 'ZPKP','ZCCD', 'ZARC') 	
											THEN sodi.OrderQuantity 
										 WHEN Sodi.SalesDocumentType in('ZDRR','ZCRR','ZPCR', 'ZPDR')
											THEN 1 
										 ELSE sodi.ConfirmedQty END)  * sodi.OperatorSwitch AS DECIMAL(13,2)) AS FPriceValueLC
,CAST(CASE WHEN sodi.ZOFP IS NOT NULL THEN ISNULL(sodi.[ZOF%],0) + ISNULL(sodi.ZOFV,0)
		   WHEN sodi.ZSFP IS NOT NULL THEN ISNULL(sodi.[ZIF%],0) + ISNULL(sodi.ZIFV,0)
		   END 
									     * ABS(CASE WHEN sodi.RejectionReason <> '' AND sodi.SalesDocumentType IN ( 'ZPTO', 'ZPKP','ZCCD', 'ZARC') 	
											THEN sodi.OrderQuantity 
										 WHEN Sodi.SalesDocumentType in('ZDRR','ZCRR','ZPCR', 'ZPDR')
											THEN 1 
										 ELSE sodi.ConfirmedQty END)  * sodi.OperatorSwitch AS DECIMAL(13,2)) AS FreightValueLC
,CAST(CASE WHEN sodi.ZOFP IS NOT NULL THEN sodi.ZOIC
		   WHEN sodi.ZSFP IS NOT NULL THEN sodi.ZIDU
		   END * ABS(CASE WHEN sodi.RejectionReason <> '' AND sodi.SalesDocumentType IN ( 'ZPTO', 'ZPKP','ZCCD', 'ZARC') 	
											THEN sodi.OrderQuantity 
										 WHEN Sodi.SalesDocumentType in('ZDRR','ZCRR','ZPCR', 'ZPDR')
											THEN 1 
										 ELSE sodi.ConfirmedQty END)  * sodi.OperatorSwitch AS DECIMAL(13,2)) AS DutiesValueLC
,CAST(CASE WHEN sodi.ZOFP IS NOT NULL THEN 0 
		   WHEN sodi.ZSFP IS NOT NULL THEN ISNULL(sodi.ZIIN,0)
		   END * ABS(CASE WHEN sodi.RejectionReason <> '' AND sodi.SalesDocumentType IN ( 'ZPTO', 'ZPKP','ZCCD', 'ZARC') 	
											THEN sodi.OrderQuantity 
										 WHEN Sodi.SalesDocumentType in('ZDRR','ZCRR','ZPCR', 'ZPDR')
											THEN 1 
										 ELSE sodi.ConfirmedQty END)  * sodi.OperatorSwitch AS DECIMAL(13,2)) AS InsuranceValueLC
,CAST(CASE WHEN sodi.ZOFP IS NOT NULL THEN ISNULL(sodi.ZOVA,0)
		   END * ABS(CASE WHEN sodi.RejectionReason <> '' AND sodi.SalesDocumentType IN ( 'ZPTO', 'ZPKP','ZCCD', 'ZARC') 	
											THEN sodi.OrderQuantity 
										 WHEN Sodi.SalesDocumentType in('ZDRR','ZCRR','ZPCR', 'ZPDR')
											THEN 1 
										 ELSE sodi.ConfirmedQty END)  * sodi.OperatorSwitch AS DECIMAL(13,2)) AS VASValueLC
,CAST(ISNULL(sodi.ZRAC,0) * ABS(CASE WHEN sodi.RejectionReason <> '' AND sodi.SalesDocumentType IN ( 'ZPTO', 'ZPKP','ZCCD', 'ZARC') 
												THEN sodi.OrderQuantity 
										 WHEN Sodi.SalesDocumentType in('ZDRR','ZCRR','ZPCR', 'ZPDR')
												THEN 1 
										 ELSE sodi.ConfirmedQty END)  * sodi.OperatorSwitch AS DECIMAL(13,2)) AS ReturnAccrualsValueLC
,Sodi.GSMStoreCode																				AS GSMStoreCode
,Sodi.SalesDocumentType																			AS NatSOTypeCode
,Sodi.EBPDesc																					AS NatSOTypeDesc
,CASE 
	WHEN (ISNULL(sodi.[BillToParty],''))= '' 
		THEN NULL 
	ELSE CONCAT(sodi.[BillToParty], '|', sodi.SalesOrganization) 
	END																							AS NatCustomerBillTo_BK
,CASE 
	WHEN (ISNULL(sodi.[OwnerGrParty],''))= '' 
		THEN NULL 
	ELSE CONCAT(sodi.[OwnerGrParty], '|', sodi.SalesOrganization) 
	END																							AS NatCustomerOwnerGroup_BK
,sodi.[CustomerPaymentTerms]																	AS TermsOfPaymentKey
,sodi.[PricingDate]																				AS PricingDate
,sodi.DeliveryBlockReason																		AS DeliveryBlock
,sodi.DeliveryBlockReason_header																AS DeliveryBlock_header
,sodi.PurchaseRequisition																		AS PurchaseRequisition
,sodi.StorageLocation																			AS StorageLocation
,sodi.ContractValidFrom																			AS ContractValidFrom
,sodi.ContractValidTo																			AS ContractValidTo
,MaterialAvailabilityDate																		AS MaterialAvailabilityDate
,MinMaterialAvailabilityDate																	AS MinMaterialAvailabilityDate
,sodi.DeliveryNoteNumbers																		AS DeliveryNoteNumbers
,sodi.ActualGoodsMovementDate																	AS PostingGoodsIssueDate
,CASE 
	WHEN (ISNULL(sodi.PayerParty,''))= '' 
		THEN NULL 
	ELSE CONCAT(sodi.PayerParty, '|', sodi.SalesOrganization) 
	END																							AS NatCustomerPayer_BK
,CASE 
	WHEN (ISNULL(sodi.SHIPTOPARTY,''))= '' 
		THEN NULL 
	ELSE CONCAT(sodi.SHIPTOPARTY, '|', sodi.SalesOrganization) 
	END																							AS NatCustomerShipTo_BK
,CASE WHEN sodi.SalesDocumentType in ('ZORR','ZORP') 
		THEN 
			CASE WHEN sodi.CustomerConditionGroup1 = 'ZB'
			THEN 1	ELSE 2
			END
		ELSE 0
		END															AS OrderEntrySystem
,sodi.SalesSeason													AS SalesSeason
,CustomerPONumber													AS CustomerPONumber
,sodi.RejectionDate													AS RejectionDate
,sodi.RejectionReason												AS RejectionReasonCode  
,sodi.RejectionReasonDesc											AS RejectionReasonDesc
,sodi.FQTY * sodi.OperatorSwitch										AS FQty
,sodi.HQTY * sodi.OperatorSwitch										AS HQty
,sodi.RQTY * sodi.OperatorSwitch										AS RQty
,CAST(sodi.DelNoteQty AS int)							            AS DeliveryNoteQty
,CAST(sodi.ActualDeliveryQuantity AS int)                            AS ActualDeliveredQuantity
,CAST(sodi.OriginalDeliveryQuantity AS int)                          AS OriginalDeliveredQuantity
,CASE WHEN (ISNULL(sodi.DelNoteQty,0)=0 OR ISNULL(sodi.OrderQuantity,0)= 0 )THEN 0.00 
	WHEN sodi.ActualDeliveryQuantity IS NULL THEN sodi.NetAmount
	ELSE (ISNULL(sodi.NetAmount,0)/sodi.OrderQuantity*sodi.ActualDeliveryQuantity) --> calculating NetAmount Delivery
END																			AS DeliveryNoteInvoicedSalesValueLC
,CAST(
                CASE
                    WHEN sodi.OverallGoodsMovementStatus = 'C' AND sodi.DelNoteQty = 0    THEN 'Cancelled'
                    WHEN sodi.OverallGoodsMovementStatus = 'C' AND sodi.DelNoteQty > 0    THEN 'Delivered'
                    WHEN sodi.OverallPackingStatus = 'C'     THEN 'Packed'
                    WHEN sodi.OverallSDProcessStatus = 'A'   THEN 'Created'
                ELSE 'n/a' END AS VARCHAR(40))                      AS DeliveryNoteStatusDesc --field is currently hidden in the cube as it's not entirely accurate in all cases
,CAST(CASE WHEN sodi.PrecedingDocumentCategory = 'G' THEN 1 ELSE 0 END AS BIT) AS CallOffFlag
,sodi.PrecedingDocumentCategory
,sodi.[IncotermsClassification]																	AS [IncotermsClassification]		
,sodi.[FixedValueDate]																			AS [FixedValueDate]				
,sodi.[version]																					AS [version]						
,sodi.[CustomerPurchaseOrderType]																AS [CustomerPurchaseOrderType]	
,sodi.[Route]																					AS [Route]						
,sodi.[YourReference]																			AS [YourReference]				
,sodi.[SalesDocumentItemCategory]																AS [SalesDocumentItemCategory]
,CAST(REPLACE(sodi.CreationDate,'-', '') AS INT)												AS SalesSemesterCreationDate
,sodi.CreationDate_Contract																		AS SalesSemesterCreationDate_Contract
,sodi.[PoType]
,sodi.[DistributionChannel]
,sodi.[SDDocumentReason] 
,sodi.[FirstConfirmedDeliveryDate]
,sodi.[OriginalRequestedDeliveryDate]
,sodi.[LatestRDD]
,sodi.[LatestFCDD]
,sodi.[LatestCdd]
,sodi.[UltimateCustomerBarcode]
,cast(sodi.[OuterCartonPackFactor] as int) as OuterCartonPackFactor
,sodi.NameOfOrderer			
,sodi.MaterialByCustomer		
,sodi.SDDocumentCollectiveNumber
,sodi.CustomerPurchaseOrderSuplmnt
,sodi.HeaderBillingBlockReason
,sodi.NetPriceAmount
,sodi.totalSDDocReferenceStatus
,sodi.CreatedByUser
,sodi.RequirementSegment
,sodi.CustomerOrdertype
,sodi.CorrespncExternalReference
,sodi.OverallTotalDeliveryStatus
,sodi.NatPurchaseOrders
,CAST(CONVERT(VARCHAR, sodi.Max_PODeliveryDate, 112) AS INT) as Max_NatPODeliveryDate
,CAST(CONVERT(VARCHAR, sodi.Min_PODeliveryDate, 112) AS INT) as Min_NatPODeliveryDate
,sodi.StockSource
,cast(sodi.InnerCartonPackFactor as int) as InnerCartonPackFactor
,NatOrderEntrySys
,sodi.DeliveryWindowStart
,sodi.DeliveryWindowEnd
,sodi.AdditionalValueDays
,sodi.CustomerReference
FROM #ChangedSOsFiltered AS Sodi

/*C. columns are inherited from Contract. Add fields to #CallOffs temp table if needed from contract*/
CREATE TABLE #ResultAdd_Calloffs
    WITH
    (
      DISTRIBUTION = HASH(NatSalesOrderNo)
    , CLUSTERED INDEX (NatSalesOrderNo ASC, NatSalesOrderItemNo ASC)
    )
	AS
SELECT 
      concat(C.NatSalesOrderNo,UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),CONCAT(C.NatSalesOrderItemNo, '-',R1.[NatSalesOrderNo], '-', R1.[NatSalesOrderItemNo], '_OoH')))))) AS [NatSalesOrderCurrentAccumulated_BK]
      ,C.NatSalesOrderNo
	  ,UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),CONCAT(C.NatSalesOrderItemNo, '-',R1.[NatSalesOrderNo], '-', R1.[NatSalesOrderItemNo], '_OoH'))))) AS [NatSalesOrderItemNo] 
	  ,R1.ReferenceSDDocument
	  ,R1.ReferenceDocumentItemNumber
      ,C.[CompanyCode]
      ,C.[IntPupMasterId]
      ,C.[PDUCode]
      ,C.[NatCustomer_BK]
      ,R1.[NatArticle_BK]     /*Calloff*/
      ,R1.[StyleNumber_BK]	   /*Calloff*/
      ,R1.[ArticleNumber_BK]  /*Calloff*/
      ,R1.[ArticleSize_BK]	   /*Calloff*/
      ,C.[CurrencyCode]
      ,C.[NatSalesman_BK]
      ,C.[NatStoreDC_BK]
      ,CASE WHEN ISNULL(R1.[SOStatusCode],0)=2 OR C.SOStatusCode=2 THEN 2 ELSE 1 END AS SOStatusCode
      ,CASE WHEN ISNULL(R1.[SOStatusDesc],'')='Cancelled' OR C.SOStatusCode=2  THEN 'Cancelled' ELSE 'Open' END AS SOStatusDesc
      ,R1.[SOCreationDate]    /*Calloff*/
      ,C.[RequestedDeliveryDateHeader]  AS RequestedDeliveryDateHeader
      ,C.[RequestedDeliveryDateItem]	AS [RequestedDeliveryDateItem]
      ,C.[DeliveryDateMin]
      ,C.[DeliveryDateMax]
      ,R1.[Qty]*(-1)	   /*Calloff*/								AS [Qty]
      ,CASE WHEN C.Qty <> 0 THEN C.GrossValueLC/C.Qty*R1.Qty*(-1) ELSE 0 END  AS GrossValueLC
      ,CASE WHEN C.Qty <> 0 THEN C.[InvoicedSalesValueLC]/C.Qty*R1.Qty*(-1) ELSE 0 END					AS [InvoicedSalesValueLC]
	  ,CASE WHEN ISNULL(R1.[SOStatusCode],0)=2 THEN 0 ELSE C.[Active] END AS [Active]
      ,R1.[RBUCode]                     /*Calloff*/
      ,R1.[BrandCode]					/*Calloff*/
      ,R1.[ProdDivCode]					/*Calloff*/
      ,R1.[RepGenderCode]				/*Calloff*/
      ,R1.[RepAgeGroupCode]				/*Calloff*/
      ,R1.[ProductCreationModelCode]	/*Calloff*/
      ,R1.[BusSegmentCode]				/*Calloff*/
      ,CASE WHEN C.Qty <> 0 THEN C.[LandedCostValueLC]/C.Qty*R1.Qty*(-1)						ELSE 0 END				AS [LandedCostValueLC]
      ,CASE WHEN C.Qty <> 0 THEN C.[OffInvoiceSalesValueLC]/C.Qty*R1.Qty*(-1)					ELSE 0 END				AS [OffInvoiceSalesValueLC]
      ,CASE WHEN C.Qty <> 0 THEN C.[TotalCogsSplitValueLC]/C.Qty*R1.Qty*(-1)					ELSE 0 END				AS [TotalCogsSplitValueLC]
      ,CASE WHEN C.Qty <> 0 THEN C.[TotalCogsSplitExclIntCompValueLC]/C.Qty*R1.Qty*(-1)			ELSE 0 END		AS [TotalCogsSplitExclIntCompValueLC]
      ,CASE WHEN C.Qty <> 0 THEN C.[TotalIntCompCostValueLC]/C.Qty*R1.Qty*(-1)					ELSE 0 END				AS [TotalIntCompCostValueLC]
      ,R1.[OrderQuantity]*(-1)	 /*Calloff*/									AS [OrderQuantity]
	  ,R1.ConfirmedQty*(-1)		 /*Calloff*/									AS [ConfirmedQty]
      ,CASE WHEN C.Qty <> 0 THEN C.[MgmtCostValueLC]/C.Qty*R1.Qty*(-1)	ELSE 0 END									AS [MgmtCostValueLC]
	  ,C.RepricingFlag
	  ,C.COGSCascadeLvl
      ,CASE WHEN C.Qty <> 0 THEN C.[TotalOVCValueLC]/C.Qty*R1.Qty*(-1)		ELSE 0 END							AS [TotalOVCValueLC]
      ,CASE WHEN C.Qty <> 0 THEN C.FPriceValueLC/C.Qty*R1.Qty*(-1)	ELSE 0 END   FPriceValueLC
	  ,CASE WHEN C.Qty <> 0 THEN C.FreightValueLC/C.Qty*R1.Qty*(-1)ELSE 0 END	FreightValueLC
	  ,CASE WHEN C.Qty <> 0 THEN C.DutiesValueLC/C.Qty*R1.Qty*(-1)	ELSE 0 END DutiesValueLC
	  ,CASE WHEN C.Qty <> 0 THEN C.InsuranceValueLC/C.Qty*R1.Qty*(-1)	ELSE 0 END InsuranceValueLC
	  ,CASE WHEN C.Qty <> 0 THEN C.[VASValueLC]/C.Qty*R1.Qty*(-1)		ELSE 0 END								AS [VASValueLC]
      ,CASE WHEN C.Qty <> 0 THEN C.[ReturnAccrualsValueLC]/C.Qty*R1.Qty*(-1)	ELSE 0 END						AS [ReturnAccrualsValueLC]
      ,C.[GSMStoreCode]
	  ,c.NatSOTypeCode
      ,C.[NatSOTypeDesc]
      ,C.[NatCustomerBillTo_BK]
      ,C.[NatCustomerOwnerGroup_BK]
      ,C.[TermsOfPaymentKey]
      ,C.[PricingDate]
      ,C.[DeliveryBlock]
      ,C.[DeliveryBlock_header]
	  ,C.PurchaseRequisition
	  ,C.[StorageLocation]
      ,c.[ContractValidFrom]										AS [ContractValidFrom]
      ,c.[ContractValidTo]											AS [ContractValidTo]
      ,C.[MaterialAvailabilityDate]
	  ,C.[MinMaterialAvailabilityDate]
      ,C.[DeliveryNoteNumbers]
      ,C.[PostingGoodsIssueDate]
      ,C.[NatCustomerPayer_BK]
      ,C.[NatCustomerShipTo_BK]
      ,c.[OrderEntrySystem]
      ,C.[SalesSeason]
      ,c.[CustomerPONumber]
	  ,ISNULL(NULLIF(R1.[RejectionDate],'19000101'),C.[RejectionDate])			AS [RejectionDate]
      ,ISNULL(NULLIF(R1.[RejectionReasonCode],'')	,C.[RejectionReasonCode])				AS [RejectionReasonCode]
      ,ISNULL(NULLIF(R1.[RejectionReasonDesc],'')	,C.[RejectionReasonDesc])			AS [RejectionReasonDesc]
      ,NULL         												AS [FQty]  			/*[FQty]*(-1) Ticket Jira EBPRP-240*/
      ,NULL         												AS [HQty]  			/*[HQty]*(-1) Ticket Jira EBPRP-240*/
      ,NULL         												AS [RQty]  			/*[RQty]*(-1) Ticket Jira EBPRP-240*/
     -- for the calloffs we have no DeliveryInformations
	  ,NULL														    AS [DeliveryNoteQty]
      ,NULL                                                         AS [ActualDeliveredQuantity]
	  ,NULL															AS OriginalDeliveredQuantity
      ,NULL														    AS [DeliveryNoteInvoicedSalesValueLC]
      ,NULL														    AS [DeliveryNoteStatusDesc]
      ,CAST(CASE WHEN R1.PrecedingDocumentCategory = 'G' THEN 1 ELSE 0 END AS BIT) AS CallOffFlag
	  ,R1.PrecedingDocumentCategory
	  ,C.[IncotermsClassification]							        AS [IncotermsClassification]		
	  ,C.[FixedValueDate]									            AS [FixedValueDate]				
	  ,C.[version]											        AS [version]						
	  ,C.[CustomerPurchaseOrderType]							        AS [CustomerPurchaseOrderType]	
	  ,C.[Route]												        AS [Route]						
	  ,C.[YourReference]										        AS [YourReference]				
	  ,C.[SalesDocumentItemCategory]							        AS [SalesDocumentItemCategory]
	  ,c.[SOCreationDate]												AS SalesSemesterCreationDate
	  ,c.[SOCreationDate]												AS SalesSemesterCreationDate_Contract
	  ,C.[PoType]
	  ,C.[DistributionChannel]
	  ,C.[SDDocumentReason]
	  ,c.[FirstConfirmedDeliveryDate]
	  ,c.[OriginalRequestedDeliveryDate]
	  ,c.[LatestRDD]
	  ,C.[LatestFCDD]
	  ,c.[LatestCdd]
	  ,C.[UltimateCustomerBarcode]
	  ,C.[OuterCartonPackFactor]
	  ,c.[NameOfOrderer]			
	  ,c.[MaterialByCustomer]		
	  ,c.[SDDocumentCollectiveNumber]
	  ,C.CustomerPurchaseOrderSuplmnt
	  ,C.HeaderBillingBlockReason
	  ,C.NetPriceAmount
	  ,C.totalSDDocReferenceStatus
	  ,C.CreatedByUser
	  ,C.RequirementSegment
	  ,C.CustomerOrdertype
	  ,c.CorrespncExternalReference
	  ,C.OverallTotalDeliveryStatus
	  ,c.NatPurchaseOrders
	  ,c.Max_NatPODeliveryDate
	  ,c.Min_NatPODeliveryDate
      ,C.StockSource
	  ,C.InnerCartonPackFactor
	  ,C.NatOrderEntrySys
	  ,c.DeliveryWindowStart
	  ,c.DeliveryWindowEnd
	  ,c.AdditionalValueDays
	  ,c.CustomerReference

	FROM #Result AS R1 INNER JOIN #Result AS C on R1.ReferenceSDDocument = C.NatSalesOrderNo AND R1.ReferenceDocumentItemNumber = C.NatSalesOrderItemNo
	AND C.NatSOTypeCode  in ('ZPOC', 'ZROC', 'ZCSC', 'ZMKC', 'ZCOC', 'ZRES', 'ZCCD', 'ZCLS', 'ZARC') AND C.ReferenceDocumentItemNumber = '000000'
UNION ALL 
SELECT * FROM #Result

CREATE TABLE #HangerType
WITH
(
DISTRIBUTION = HASH(refdoc)
, CLUSTERED INDEX (refdoc ASC)
)
AS
SELECT String_agg(field1, ',')
         within GROUP (ORDER BY field1)            AS hangertype,
       refdoc,
       Right(Concat('000000000', h.refdocitem), 6) AS REFDOCITEM
FROM   (SELECT DISTINCT field1,
                        refdocitem,
                        refdoc
        FROM   stag.s4hana_vhangervas
	WHERE IsDeleted = 0) h
GROUP  BY refdoc,
          Right(Concat('000000000', h.refdocitem), 6) 


; 
/* inheriting PO units and PO receipt Units */
CREATE TABLE #POUnits
WITH
(
DISTRIBUTION = HASH(SalesOrderNo)
, CLUSTERED INDEX (SalesOrderNo ASC, SalesOrderItemNo ASC)
)
AS
WITH cte_so AS
  (SELECT NatSalesOrderNo,
          NatSalesOrderItemNo
   FROM #Result
   WHERE NatSOTypeCode in ('ZDIS',
                           'ZPTO',
						   'ZCCD') ),
  cte_po AS
  (SELECT po.PONo,
          po.POItemNo,
          po.SalesOrderNo,
          po.SalesOrderItemNo
   FROM stag.S4Hana_vPOAssignments po
   INNER JOIN cte_so so ON po.SalesOrderNo = so.NatSalesOrderNo
   AND po.SalesOrderItemNo = so.NatSalesOrderItemNo), 
   
  cte_units AS
  (SELECT chpos.SalesOrderNo,
          chpos.SalesOrderItemNo,
          podi.OrderQuantity AS POunits,
          CASE
              WHEN posl.IsDeleted = 1 THEN 0
              ELSE posl.RoughGoodsReceiptQuantity
          END AS POreceiptUnits,
          CAST(CASE
                   WHEN pod.DeletionCode <> ''
                        OR podi.DeletionCode <> '' THEN 3 /*Cancelled*/
                   ELSE CASE
                            WHEN podi.IsCompletelyDelivered = 'X' THEN 1 /*Finished Status*/
                            WHEN podi.IsCompletelyDelivered = '' THEN 2 /*Open Status*/
                        END
               END AS INT) AS POSctatusCode
   FROM cte_po chpos
   JOIN stag.S4Hana_vPODocuments pod ON chpos.PONo = pod.PONo
   JOIN biz.S4Hana_PODocumentItems podi ON chpos.PONo = podi.PONo
   AND chpos.POItemNo = podi.POItemNo
   JOIN biz.S4Hana_POScheduleLines posl ON podi.PONo = posl.PONo
   AND podi.POItemNo = posl.POItemNo
   JOIN stag.S4Hana_vPOAssignments poa ON chpos.PONo = poa.PONo
   AND chpos.POItemNo = poa.POItemNo
   AND poa.AccountAssignmentNumber = '01'
   AND poa.SalesOrderItemNo <> ''
   AND poa.SalesOrderNo = chpos.SalesOrderNo
   AND poa.SalesOrderItemNo = chpos.SalesOrderItemNo
   JOIN pdwref.S4Hana_PurchaseOrderTypes pot ON pod.POTypeCode = pot.EBPIndicator)


SELECT SalesOrderNo,
          SalesOrderItemNo,
          sum(POunits) AS POunits,
          sum(POreceiptUnits) AS POreceiptUnits
   FROM cte_units
   WHERE POSctatusCode <> 3 /* excluding cancelled POs */
   GROUP BY SalesOrderNo,
            SalesOrderItemNo
;

/* inheriting PackingRatio and SubPackingRatio */

CREATE TABLE #PackingRatio
WITH
(
    DISTRIBUTION = HASH(SALESDOCUMENT),
    CLUSTERED INDEX (SALESDOCUMENT ASC, SALESDOCUMENTITEM ASC)
)
AS
SELECT 
    [SALESDOCUMENT], 
    [SALESDOCUMENTITEM],
    [SUBPACKINGPIECESPERCARTON] as SubPackingRatio, 
    [PACKINGRATIO] as PackingRatio
FROM 
    [stag].[S4Hana_vPackingRatio];

;
CREATE TABLE #ResultwithHashdiff
	    WITH
    (
      DISTRIBUTION = HASH(NatSalesOrderNo)
    , CLUSTERED INDEX (NatSalesOrderNo ASC, NatSalesOrderItemNo ASC)
    )
	AS	
SELECT 
	   [NatSalesOrderCurrentAccumulated_BK] AS  NatSalesOrderCurrentAccumulated_BK
      ,[NatSalesOrderNo] AS NatSalesOrderNo
      ,[NatSalesOrderItemNo] AS [NatSalesOrderItemNo]
      ,[CompanyCode]
      ,[IntPupMasterId]
      ,[PDUCode]
      ,[NatCustomer_BK]
      ,[NatArticle_BK]
      ,[StyleNumber_BK]
      ,[ArticleNumber_BK]
      ,[ArticleSize_BK]
      ,[CurrencyCode]
      ,[NatSalesman_BK]
      ,[NatStoreDC_BK]
      ,[SOStatusCode]
      ,[SOStatusDesc]
      ,[SOCreationDate]
      ,[RequestedDeliveryDateHeader]
      ,[RequestedDeliveryDateItem]
      ,[DeliveryDateMin]
      ,[DeliveryDateMax]
      ,[Qty]									AS [Qty]
      ,[GrossValueLC]							AS [GrossValueLC]
      ,[InvoicedSalesValueLC]					AS [InvoicedSalesValueLC]
      ,[Active]
      ,[RBUCode]
      ,[BrandCode]
      ,[ProdDivCode]
      ,[RepGenderCode]
      ,[RepAgeGroupCode]
      ,[ProductCreationModelCode]
      ,[BusSegmentCode]
      ,[LandedCostValueLC]						AS [LandedCostValueLC]
      ,OffInvoiceSalesValueLC					AS OffInvoiceSalesValueLC
      ,[TotalCogsSplitValueLC]					AS [TotalCogsSplitValueLC]
      ,[TotalCogsSplitExclIntCompValueLC]		AS [TotalCogsSplitExclIntCompValueLC]
      ,[TotalIntCompCostValueLC]				AS [TotalIntCompCostValueLC]
      ,[OrderQuantity]							AS [OrderQuantity]
      ,[MgmtCostValueLC]			            AS [MgmtCostValueLC]
	  ,COGSCascadeLvl		
	  ,RepricingFlag
      ,[TotalOVCValueLC]			            AS [TotalOVCValueLC]
      ,[FPriceValueLC]				            AS [FPriceValueLC] 
	  ,[FreightValueLC]				            AS [FreightValueLC] 
	  ,[DutiesValueLC]				            AS [DutiesValueLC]
	  ,[InsuranceValueLC]			            AS [InsuranceValueLC]
	  ,[VASValueLC]					            AS [VASValueLC]
      ,[ReturnAccrualsValueLC]					AS [ReturnAccrualsValueLC]
      ,[GSMStoreCode]
      ,[NatSOTypeCode]
      ,[NatSOTypeDesc]
      ,[NatCustomerBillTo_BK]
      ,[NatCustomerOwnerGroup_BK]
      ,[TermsOfPaymentKey]
      ,[PricingDate]
      ,[DeliveryBlock_header]
	  ,PurchaseRequisition
	  ,[DeliveryBlock]
      ,[StorageLocation]
      ,[ContractValidFrom]
      ,[ContractValidTo]
      ,[MaterialAvailabilityDate]
	  ,[MinMaterialAvailabilityDate]
      ,[DeliveryNoteNumbers]
      ,[PostingGoodsIssueDate]
      ,[NatCustomerPayer_BK]
      ,[NatCustomerShipTo_BK]
	  ,[OrderEntrySystem]
      ,[SalesSeason]
      ,[CustomerPONumber]
      ,[RejectionDate]
      ,[RejectionReasonCode]
      ,[RejectionReasonDesc]
      ,[FQty]									AS [FQty]
      ,[HQty]									AS [HQty]
      ,[RQty]									AS [RQty]
      ,[DeliveryNoteQty]						AS [DeliveryNoteQty]
      ,[ActualDeliveredQuantity]                AS [ActualDeliveredQuantity]
	  ,OriginalDeliveredQuantity				AS OriginalDeliveredQuantity
      ,[DeliveryNoteInvoicedSalesValueLC]		AS [DeliveryNoteInvoicedSalesValueLC]
      ,[DeliveryNoteStatusDesc]
	  ,CallOffFlag												AS CallOffFlag
	  ,[IncotermsClassification]							        AS [IncotermsClassification]		
	  ,[FixedValueDate]									            AS [FixedValueDate]				
	  ,[version]											        AS [version]						
	  ,[CustomerPurchaseOrderType]							        AS [CustomerPurchaseOrderType]	
	  ,[Route]												        AS [Route]						
	  ,[YourReference]										        AS [YourReference]				
	  ,[SalesDocumentItemCategory]							        AS [SalesDocumentItemCategory]
	  ,SalesSemesterCreationDate	  
	  ,[PoType]
	  ,[DistributionChannel]
	  ,[SDDocumentReason] 
	  ,[FirstConfirmedDeliveryDate]
	  ,[OriginalRequestedDeliveryDate]
	  ,[LatestRDD]
	  ,[LatestFCDD]
	  ,[LatestCdd]
	  ,[UltimateCustomerBarcode]
	  ,[OuterCartonPackFactor]
	  ,[NameOfOrderer]			
	  ,[MaterialByCustomer]		
	  ,[SDDocumentCollectiveNumber]
	  ,CustomerPurchaseOrderSuplmnt
	  ,Result.HeaderBillingBlockReason
      ,NetPriceAmount
	  ,Result.totalSDDocReferenceStatus
	  ,CreatedByUser
	  ,RequirementSegment
	  ,CustomerOrdertype
	  ,CorrespncExternalReference
	  ,OverallTotalDeliveryStatus
	  ,NatPurchaseOrders
	  ,Max_NatPODeliveryDate
	  ,Min_NatPODeliveryDate
	  ,StockSource
	  ,Result.NatOrderEntrySys
	  ,InnerCartonPackFactor
	  ,h.hangertype
	  ,PO.POunits
	  ,PO.POreceiptUnits
	  ,PR.PackingRatio
	  ,PR.SubPackingRatio
	  ,DeliveryWindowStart
	  ,DeliveryWindowEnd
	  ,AdditionalValueDays
	  ,CustomerReference
	  ,ORD.OrderDescription
	  ,Cncl.IntCancelReasonCode
	  ,BLRSN.ItemBillingBlockReason
	  ,PrcTp.IntSOPriceTypeCode
	  ,SOCntStat.[Description] AS ContractStatDesc
	  ,pay.[Description] AS PaymentTermDesc
	  ,OrdEnt.OrderEntrySys
	  ,SalesSemesterCreationDate_Contract
,CONVERT([BINARY](16),
			HASHBYTES('MD5',CONCAT(
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[NatSalesOrderCurrentAccumulated_BK] )))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[NatSalesOrderNo])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[NatSalesOrderItemNo])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CompanyCode])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[IntPupMasterId])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PDUCode])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[NatCustomer_BK])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[NatArticle_BK])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[StyleNumber_BK])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ArticleNumber_BK])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ArticleSize_BK])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CurrencyCode])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[NatSalesman_BK])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[NatStoreDC_BK])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SOStatusCode])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SOStatusDesc])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SOCreationDate])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[RequestedDeliveryDateHeader])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[RequestedDeliveryDateItem])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DeliveryDateMin])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DeliveryDateMax])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Qty])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[GrossValueLC])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[InvoicedSalesValueLC])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Active])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[RBUCode])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[BrandCode])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ProdDivCode])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[RepGenderCode])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[RepAgeGroupCode])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ProductCreationModelCode])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[BusSegmentCode])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[LandedCostValueLC])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[OffInvoiceSalesValueLC])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TotalCogsSplitValueLC])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TotalCogsSplitExclIntCompValueLC])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TotalIntCompCostValueLC])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[OrderQuantity])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[MgmtCostValueLC])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),COGSCascadeLvl)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),RepricingFlag)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TotalOVCValueLC])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FPriceValueLC] )))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FreightValueLC] )))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DutiesValueLC])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[InsuranceValueLC])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[VASValueLC])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ReturnAccrualsValueLC])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[GSMStoreCode])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[NatSOTypeCode])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[NatSOTypeDesc])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[NatCustomerBillTo_BK])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[NatCustomerOwnerGroup_BK])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TermsOfPaymentKey])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PricingDate])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DeliveryBlock])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DeliveryBlock_header])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),PurchaseRequisition)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[StorageLocation])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ContractValidFrom])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ContractValidTo])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[MaterialAvailabilityDate])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[MinMaterialAvailabilityDate])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](800),[DeliveryNoteNumbers])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PostingGoodsIssueDate])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[NatCustomerPayer_BK])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[NatCustomerShipTo_BK])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SalesSeason])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[OrderEntrySystem])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CustomerPONumber])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[RejectionDate])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[RejectionReasonCode])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[RejectionReasonDesc])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FQty])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[HQty])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[RQty])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DeliveryNoteQty])))),'_',
                    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ActualDeliveredQuantity])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),OriginalDeliveredQuantity)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DeliveryNoteInvoicedSalesValueLC])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DeliveryNoteStatusDesc])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CallOffFlag])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[IncotermsClassification])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FixedValueDate])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[version])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CustomerPurchaseOrderType])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Route])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[YourReference])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SalesDocumentItemCategory])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SalesSemesterCreationDate])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PoType])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DistributionChannel])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SDDocumentReason] )))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FirstConfirmedDeliveryDate] )))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[OriginalRequestedDeliveryDate] )))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[LatestRDD] )))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[LatestFCDD] )))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[LatestCdd] )))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[UltimateCustomerBarcode] )))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[OuterCartonPackFactor] )))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[NameOfOrderer])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[MaterialByCustomer])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SDDocumentCollectiveNumber])))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),CustomerPurchaseOrderSuplmnt)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),Result.HeaderBillingBlockReason)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),NetPriceAmount)))),'_',
					CONCAT(
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),Result.totalSDDocReferenceStatus)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),CreatedByUser)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),RequirementSegment)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),CustomerOrdertype)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),CorrespncExternalReference)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),OverallTotalDeliveryStatus)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),NatPurchaseOrders )))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),h.hangertype )))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),StockSource )))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),Result.NatOrderEntrySys )))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),InnerCartonPackFactor )))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),Min_NatPODeliveryDate )))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),POunits )))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),POreceiptUnits)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),PackingRatio)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),SubPackingRatio)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),Max_NatPODeliveryDate )))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),DeliveryWindowStart )))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),DeliveryWindowEnd )))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),AdditionalValueDays )))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),ORD.OrderDescription )))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),Cncl.IntCancelReasonCode )))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),BLRSN.ItemBillingBlockReason )))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),PrcTp.IntSOPriceTypeCode )))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),SOCntStat.[Description] )))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),pay.[Description] )))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),OrdEnt.OrderEntrySys )))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),CustomerReference )))),'_',
					UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),SalesSemesterCreationDate_Contract ))))
					)
					
		))) AS HashDiff
FROM #ResultAdd_Calloffs AS Result 
LEFT JOIN #HangerType AS h
ON Result.NatSalesOrderNo = h.refdoc
AND Result.NatSalesOrderItemNo  = h.REFDOCITEM
LEFT JOIN #POUnits AS po
ON Result.NatSalesOrderNo = po.SalesOrderNo
AND Result.NatSalesOrderItemNo = po.SalesOrderItemNo
LEFT JOIN #PackingRatio AS PR
ON Result.NatSalesOrderNo = PR.SALESDOCUMENT
AND Result.NatSalesOrderItemNo = PR.SALESDOCUMENTITEM
LEFT JOIN [stag].[S4Hana_vOrderReasonTexts] AS ORD
ON Result.SDDocumentReason = ORD.OrderReason
LEFT JOIN [pdwref].[S4Hana_CancelReasons] AS Cncl 
ON Result.RejectionReasonCode = Cncl.EBPIndicator
LEFT JOIN [pdwref].[S4Hana_BillingBlockReasons] AS BLRSN 
ON Result.HeaderBillingBlockReason=BLRSN.HeaderBillingBlockReason
LEFT JOIN pdwref.S4Hana_SOPriceTypes as PrcTp 
ON Result.NatSOTypeCode = PrcTp.SOTypeCode
LEFT JOIN pdwref.S4Hana_SalesTypes as st 
ON Result.NatSOTypeCode = st.SOTypeCode
LEFT JOIN [pdwref].[S4Hana_SOContractStat] as SOCntStat 
ON Result.totalSDDocReferenceStatus = SOCntStat.totalSDDocReferenceStatus
LEFT JOIN stag.S4Hana_vPaymenttermsTexts AS pay 
ON Result.TermsOfPaymentKey= pay.PAYMENTKEY 
LEFT JOIN [pdwref].[S4Hana_OrderEntrySystem] OrdEnt 
ON Result.NatOrderEntrySys = OrdEnt.NatOrderEntrySys
 
   -- count new Records for [NatSalesOrderCurrentAccumulated]
	SELECT @AffectedRows = COUNT(*)
    FROM #ResultwithHashdiff X LEFT JOIN [sales].[NatSalesOrderCurrentAccumulated] prd
		ON x.NatSalesOrderCurrentAccumulated_BK = prd.NatSalesOrderCurrentAccumulated_BK
		WHERE prd.NatSalesOrderCurrentAccumulated_BK IS NULL

INSERT INTO [sales].[NatSalesOrderCurrentAccumulated]
           ([NatSalesOrderCurrentAccumulated_BK]
           ,[CreatedOn]
           ,[ModifiedOn]
           ,[NatSalesOrderNo]
           ,[NatSalesOrderItemNo]
           ,[CompanyCode]
           ,[IntPupMasterId]
           ,[PDUCode]
           ,[NatCustomer_BK]
           ,[NatArticle_BK]
           ,[StyleNumber_BK]
           ,[ArticleNumber_BK]
           ,[ArticleSize_BK]
           ,[CurrencyCode]
           ,[NatSalesman_BK]
           ,[NatStoreDC_BK]
           ,[SOStatusCode]
           ,[SOStatusDesc]
           ,[SOCreationDate]
           ,[RequestedDeliveryDateHeader]
           ,[RequestedDeliveryDateItem]
           ,[DeliveryDateMin]
           ,[DeliveryDateMax]
           ,[Qty]
           ,[GrossValueLC]
           ,[InvoicedSalesValueLC]
           ,[Active]
           ,[RBUCode]
           ,[BrandCode]
           ,[ProdDivCode]
           ,[RepGenderCode]
           ,[RepAgeGroupCode]
           ,[ProductCreationModelCode]
           ,[BusSegmentCode]
           ,[LandedCostValueLC]
           ,[OffInvoiceSalesValueLC]
           ,[TotalCogsSplitValueLC]
           ,[TotalCogsSplitExclIntCompValueLC]
           ,[TotalIntCompCostValueLC]
           ,[OrderQuantity]
		   ,[MgmtCostValueLC]
		   ,COGSCascadeLvl
		   ,[TotalOVCValueLC]
		   ,[FPriceValueLC] 
		   ,[FreightValueLC] 
		   ,[DutiesValueLC]
		   ,[InsuranceValueLC]
		   ,[VASValueLC]
		   ,[ReturnAccrualsValueLC]
           ,[GSMStoreCode]
           ,[NatSOTypeCode]
           ,[NatSOTypeDesc]
           ,[NatCustomerBillTo_BK]
           ,[NatCustomerOwnerGroup_BK]
           ,[TermsOfPaymentKey]
           ,[PricingDate]
           ,[DeliveryBlock]
           ,[deliveryBlock_header]
		   ,PurchaseRequisition
		   ,[StorageLocation]
           ,[ContractValidFrom]
           ,[ContractValidTo]
           ,[MaterialAvailabilityDate]
		   ,[MinMaterialAvailabilityDate]
           ,[DeliveryNoteNumbers]
           ,[PostingGoodsIssueDate]
           ,[NatCustomerPayer_BK]
           ,[NatCustomerShipTo_BK]
           ,[SalesSeason]
           ,[OrderEntrySystem]
           ,[CustomerPONumber]
           ,[RejectionDate]
           ,[RejectionReasonCode]
           ,[RejectionReasonDesc]
           ,[FQty]
           ,[HQty]
           ,[RQty]
           ,[DeliveryNoteQty]
           ,[ActualDeliveredQuantity]
		   ,OriginalDeliveredQuantity
           ,[DeliveryNoteInvoicedSalesValueLC]
           ,[DeliveryNoteStatusDesc]
	       ,[CallOffFlag]
	       ,[IncotermsClassification]	
	       ,[FixedValueDate]				
	       ,[version]					
	       ,[CustomerPurchaseOrderType]
	       ,[Route]						
	       ,[YourReference]				
	       ,[SalesDocumentItemCategory]
	       ,[PoType]
	       ,[DistributionChannel]
	       ,[SDDocumentReason] 
	       ,[FirstConfirmedDeliveryDate]
	       ,[OriginalRequestedDeliveryDate]
	       ,[LatestRDD]
	       ,[LatestFCDD]
	       ,[LatestCdd]
	       ,[UltimateCustomerBarcode]
	       ,[OuterCartonPackFactor]
	       ,[NameOfOrderer]			
	       ,[MaterialByCustomer]		
	       ,[SDDocumentCollectiveNumber]
	       ,CustomerPurchaseOrderSuplmnt
	       ,HeaderBillingBlockReason
	       ,NetPriceAmount
	       ,totalSDDocReferenceStatus
	       ,CreatedByUser
	       ,RequirementSegment
	       ,CustomerOrdertype
	       ,CorrespncExternalReference
		   ,OverallTotalDeliveryStatus
	       ,NatPurchaseOrders
	       ,Max_NatPODeliveryDate
		   ,Min_NatPODeliveryDate
		   ,StockSource
		   ,InnerCartonPackFactor
		   ,NatOrderEntrySys
	       ,hangertype
		   ,POunits
		   ,POreceiptUnits
		   ,PackingRatio
		   ,SubPackingRatio
	       ,[HashDiff]
		   ,RepricingFlag
		   ,[SalesSemesterCreationDate]
		   ,DeliveryWindowStart
		   ,DeliveryWindowEnd
		   ,AdditionalValueDays
		   ,CustomerReference
		   ,OrderDescription
		   ,IntCancelReasonCode
		   ,ItemBillingBlockReason
		   ,IntSOPriceTypeCode
		   ,ContractStatDesc
		   ,PaymentTermDesc
		   ,OrderEntrySys
		   ,SalesSemesterCreationDate_Contract
)
     SELECT
           x.NatSalesOrderCurrentAccumulated_BK
           ,@sysdate  AS CreatedOn
           ,@sysdate  AS ModifiedOn
           ,x.NatSalesOrderNo
           ,x.NatSalesOrderItemNo
           ,x.CompanyCode
           ,x.IntPupMasterId
           ,x.PDUCode
           ,x.NatCustomer_BK
           ,x.NatArticle_BK
           ,x.StyleNumber_BK
           ,x.ArticleNumber_BK
           ,x.ArticleSize_BK
           ,x.CurrencyCode
           ,x.NatSalesman_BK
           ,x.NatStoreDC_BK
           ,x.SOStatusCode
           ,x.SOStatusDesc
           ,x.SOCreationDate
           ,x.RequestedDeliveryDateHeader
           ,x.RequestedDeliveryDateItem
           ,x.DeliveryDateMin
           ,x.DeliveryDateMax
           ,x.Qty
           ,x.GrossValueLC
           ,x.InvoicedSalesValueLC
           ,x.Active
           ,x.RBUCode
           ,x.BrandCode
           ,x.ProdDivCode
           ,x.RepGenderCode
           ,x.RepAgeGroupCode
           ,x.ProductCreationModelCode
           ,x.BusSegmentCode
           ,x.LandedCostValueLC
           ,x.OffInvoiceSalesValueLC
           ,x.TotalCogsSplitValueLC
           ,x.TotalCogsSplitExclIntCompValueLC
           ,x.TotalIntCompCostValueLC
           ,x.OrderQuantity
           ,x.[MgmtCostValueLC]
		   ,x.COGSCascadeLvl
		   ,x.[TotalOVCValueLC]
		   ,x.[FPriceValueLC] 
		   ,x.[FreightValueLC] 
		   ,x.[DutiesValueLC]
		   ,x.[InsuranceValueLC]
		   ,x.[VASValueLC]
		   ,x.[ReturnAccrualsValueLC]
           ,x.GSMStoreCode
           ,x.NatSOTypeCode
           ,x.NatSOTypeDesc
           ,x.NatCustomerBillTo_BK
           ,x.NatCustomerOwnerGroup_BK
           ,x.TermsOfPaymentKey
           ,x.PricingDate
           ,x.DeliveryBlock
		   ,x.DeliveryBlock_header
		   ,x.PurchaseRequisition
           ,x.StorageLocation
           ,x.ContractValidFrom
           ,x.ContractValidTo
           ,x.MaterialAvailabilityDate
		   ,x.MinMaterialAvailabilityDate
           ,x.DeliveryNoteNumbers
           ,x.PostingGoodsIssueDate
           ,x.NatCustomerPayer_BK
           ,x.NatCustomerShipTo_BK
		   ,x.SalesSeason
           ,x.OrderEntrySystem
           ,x.CustomerPONumber
           ,x.RejectionDate
           ,x.RejectionReasonCode
           ,x.RejectionReasonDesc
           ,x.FQty
           ,x.HQty
           ,x.RQty
           ,x.DeliveryNoteQty
           ,x.ActualDeliveredQuantity
		   ,x.OriginalDeliveredQuantity
           ,x.DeliveryNoteInvoicedSalesValueLC
           ,x.DeliveryNoteStatusDesc
		   ,x.CallOffFlag
		   ,x.[IncotermsClassification]	
		   ,x.[FixedValueDate]				
		   ,x.[version]					
		   ,x.[CustomerPurchaseOrderType]
		   ,x.[Route]						
		   ,x.[YourReference]				
		   ,x.[SalesDocumentItemCategory]
	       ,x.[PoType]
	       ,x.[DistributionChannel]
	       ,x.[SDDocumentReason]
	       ,x.[FirstConfirmedDeliveryDate]
	       ,x.[OriginalRequestedDeliveryDate]
	       ,x.[LatestRDD]
	       ,x.[LatestFCDD]
	       ,x.[LatestCdd]
	       ,x.[UltimateCustomerBarcode]
	       ,x.[OuterCartonPackFactor]
	       ,x.[NameOfOrderer]			
	       ,x.[MaterialByCustomer]		
	       ,x.[SDDocumentCollectiveNumber]
	       ,x.CustomerPurchaseOrderSuplmnt
	       ,x.HeaderBillingBlockReason
	       ,x.NetPriceAmount
	       ,x.totalSDDocReferenceStatus
	       ,x.CreatedByUser
	       ,x.RequirementSegment
	       ,x.CustomerOrdertype
	       ,x.CorrespncExternalReference
		   ,x.OverallTotalDeliveryStatus
	       ,x.NatPurchaseOrders
	       ,x.Max_NatPODeliveryDate
		   ,x.Min_NatPODeliveryDate
	       ,x.StockSource
		   ,x.InnerCartonPackFactor
		   ,x.NatOrderEntrySys
	       ,x.hangertype
		   ,x.POunits
		   ,x.POreceiptUnits
		   ,x.PackingRatio
		   ,x.SubPackingRatio
	       ,x.HashDiff
	       ,x.RepricingFlag
		   ,x.[SalesSemesterCreationDate]
		   ,x.DeliveryWindowStart
		   ,x.DeliveryWindowEnd
		   ,x.AdditionalValueDays
		   ,x.CustomerReference
		   ,x.OrderDescription
		   ,x.IntCancelReasonCode
		   ,x.ItemBillingBlockReason
		   ,x.IntSOPriceTypeCode
		   ,x.ContractStatDesc
		   ,x.PaymentTermDesc
		   ,x.OrderEntrySys
		   ,x.SalesSemesterCreationDate_Contract
FROM #ResultwithHashdiff X
LEFT JOIN [sales].[NatSalesOrderCurrentAccumulated] prd
ON x.NatSalesOrderCurrentAccumulated_BK = prd.NatSalesOrderCurrentAccumulated_BK
WHERE prd.NatSalesOrderCurrentAccumulated_BK IS NULL

		-- insert Logging Informations to DataTransferLogs
		UPDATE DTlogs
		SET Inserted = @AffectedRows
		, ExecEnd = GETDATE()
		FROM etl.DataTransferLogs DTlogs
		WHERE DataTransferLogId = @DataTransferLogId

		-- count new Records for NatSalesOrderCurrentAccumulated
		SELECT @AffectedRows = COUNT(*)
		FROM #ResultwithHashdiff AS x JOIN [sales].[NatSalesOrderCurrentAccumulated] AS prd
		ON x.NatSalesOrderCurrentAccumulated_BK = prd.NatSalesOrderCurrentAccumulated_BK
		WHERE x.Hashdiff <> prd.Hashdiff

UPDATE prd
   SET [ModifiedOn] = getdate()
      ,[NatSalesOrderNo] = x.NatSalesOrderNo
      ,[NatSalesOrderItemNo] = x.NatSalesOrderItemNo
      ,[CompanyCode] = x.CompanyCode
      ,[IntPupMasterId] = x.IntPupMasterId
      ,[PDUCode] = x.PDUCode
      ,[NatCustomer_BK] = x.NatCustomer_BK
      ,[NatArticle_BK] = x.NatArticle_BK
      ,[StyleNumber_BK] = x.StyleNumber_BK
      ,[ArticleNumber_BK] = x.ArticleNumber_BK
      ,[ArticleSize_BK] = x.ArticleSize_BK
      ,[CurrencyCode] = x.CurrencyCode
      ,[NatSalesman_BK] = x.NatSalesman_BK
      ,[NatStoreDC_BK] = x.NatStoreDC_BK
      ,[SOStatusCode] = x.SOStatusCode
      ,[SOStatusDesc] = x.SOStatusDesc
      ,[SOCreationDate] = x.SOCreationDate
      ,[RequestedDeliveryDateHeader] = x.RequestedDeliveryDateHeader
      ,[RequestedDeliveryDateItem] = x.RequestedDeliveryDateItem
      ,[DeliveryDateMin] = x.DeliveryDateMin
      ,[DeliveryDateMax] = x.DeliveryDateMax
      ,[Qty] = x.Qty
      ,[GrossValueLC] = x.GrossValueLC
      ,[InvoicedSalesValueLC] = x.InvoicedSalesValueLC
      ,[Active] = x.Active
      ,[RBUCode] = x.RBUCode
      ,[BrandCode] = x.BrandCode
      ,[ProdDivCode] = x.ProdDivCode
      ,[RepGenderCode] = x.RepGenderCode
      ,[RepAgeGroupCode] = x.RepAgeGroupCode
      ,[ProductCreationModelCode] = x.ProductCreationModelCode
      ,[BusSegmentCode] = x.BusSegmentCode
      ,[LandedCostValueLC] = x.LandedCostValueLC
      ,[OffInvoiceSalesValueLC] = x.OffInvoiceSalesValueLC
      ,[TotalCogsSplitValueLC] = x.TotalCogsSplitValueLC
      ,[TotalCogsSplitExclIntCompValueLC] = x.TotalCogsSplitExclIntCompValueLC
      ,[TotalIntCompCostValueLC] = x.TotalIntCompCostValueLC
      ,[OrderQuantity] = x.OrderQuantity
      ,[MgmtCostValueLC]       = x.[MgmtCostValueLC]
	  ,COGSCascadeLvl		   = x.COGSCascadeLvl
	  ,[TotalOVCValueLC]	   = x.[TotalOVCValueLC]
	  ,[FPriceValueLC] 		   = x.[FPriceValueLC] 
	  ,[FreightValueLC] 	   = x.[FreightValueLC] 
	  ,[DutiesValueLC]		   = x.[DutiesValueLC]
	  ,[InsuranceValueLC]	   = x.[InsuranceValueLC]
	  ,[VASValueLC]			   = x.[VASValueLC]
	  ,[ReturnAccrualsValueLC] = x.[ReturnAccrualsValueLC]
      ,[GSMStoreCode] = x.GSMStoreCode
      ,[NatSOTypeCode] = x.NatSOTypeCode
      ,[NatSOTypeDesc] = x.NatSOTypeDesc
      ,[NatCustomerBillTo_BK] = x.NatCustomerBillTo_BK
      ,[NatCustomerOwnerGroup_BK] = x.NatCustomerOwnerGroup_BK
      ,[TermsOfPaymentKey] = x.TermsOfPaymentKey
      ,[PricingDate] = x.PricingDate
      ,[DeliveryBlock] = x.DeliveryBlock
	  ,[DeliveryBlock_header] = x.DeliveryBlock_header
	  ,PurchaseRequisition = x.PurchaseRequisition
      ,[StorageLocation] = x.StorageLocation
      ,[ContractValidFrom] = x.ContractValidFrom
      ,[ContractValidTo] = x.ContractValidTo
      ,[MaterialAvailabilityDate] = x.MaterialAvailabilityDate
      ,[MinMaterialAvailabilityDate] = x.MinMaterialAvailabilityDate
      ,[DeliveryNoteNumbers] = x.DeliveryNoteNumbers
      ,[PostingGoodsIssueDate] = x.PostingGoodsIssueDate
      ,[NatCustomerPayer_BK] = x.NatCustomerPayer_BK
      ,[NatCustomerShipTo_BK] = x.NatCustomerShipTo_BK
	  ,[SalesSeason] = x.SalesSeason
      ,[OrderEntrySystem] = x.OrderEntrySystem
      ,[CustomerPONumber] = x.CustomerPONumber
      ,[RejectionDate] = x.RejectionDate
      ,[RejectionReasonCode] = x.RejectionReasonCode
      ,[RejectionReasonDesc] = x.RejectionReasonDesc
      ,[FQty] = x.FQty
      ,[HQty] = x.HQty
      ,[RQty] = x.RQty
      ,[DeliveryNoteQty] = x.DeliveryNoteQty
      ,[ActualDeliveredQuantity] = x.[ActualDeliveredQuantity]
	  ,OriginalDeliveredQuantity = x.OriginalDeliveredQuantity
      ,[DeliveryNoteInvoicedSalesValueLC] = x.DeliveryNoteInvoicedSalesValueLC
      ,[DeliveryNoteStatusDesc] = x.DeliveryNoteStatusDesc
      ,[CallOffFlag] = x.CallOffFlag
      ,[IncotermsClassification]	= x.[IncotermsClassification]	
      ,[FixedValueDate]				= x.[FixedValueDate]				
      ,[version]					= x.[version]					
      ,[CustomerPurchaseOrderType]	= x.[CustomerPurchaseOrderType]
      ,[Route]						= x.[Route]						
      ,[YourReference]				= x.[YourReference]				
      ,[SalesDocumentItemCategory]	= x.[SalesDocumentItemCategory]
      ,[SalesSemesterCreationDate]  = x.[SalesSemesterCreationDate]
	  ,[PoType]						= x.[PoType]
	  ,[DistributionChannel]		= x.[DistributionChannel]
	  ,[SDDocumentReason] 			= x.[SDDocumentReason]
	  ,[FirstConfirmedDeliveryDate]		= x.[FirstConfirmedDeliveryDate]
	  ,[OriginalRequestedDeliveryDate]	= x.[OriginalRequestedDeliveryDate]
	  ,[LatestRDD]						= x.[LatestRDD]
	  ,[LatestFCDD]						= x.[LatestFCDD]
	  ,[LatestCdd]						= x.[LatestCdd]
	  ,[UltimateCustomerBarcode]		= x.[UltimateCustomerBarcode]
	  ,[OuterCartonPackFactor]			= x.[OuterCartonPackFactor]
	  ,[NameOfOrderer]						= x.[NameOfOrderer]			
	  ,[MaterialByCustomer]					= x.[MaterialByCustomer]		
	  ,[SDDocumentCollectiveNumber]			= x.[SDDocumentCollectiveNumber]
	  ,CustomerPurchaseOrderSuplmnt			= x.CustomerPurchaseOrderSuplmnt
	  ,HeaderBillingBlockReason			= x.HeaderBillingBlockReason
	  ,NetPriceAmount					= x.NetPriceAmount
	  ,totalSDDocReferenceStatus		= x.totalSDDocReferenceStatus
	  ,CreatedByUser					= x.CreatedByUser
	  ,RequirementSegment				= x.RequirementSegment
	  ,CustomerOrdertype				= x.CustomerOrdertype
	  ,CorrespncExternalReference		= x.CorrespncExternalReference
	  ,OverallTotalDeliveryStatus		= x.OverallTotalDeliveryStatus
	  ,NatPurchaseOrders = x.NatPurchaseOrders
	  ,Max_NatPODeliveryDate= x.Max_NatPODeliveryDate
	  ,Min_NatPODeliveryDate= x.Min_NatPODeliveryDate
	  ,StockSource		= x.StockSource
	  ,InnerCartonPackFactor			= x.InnerCartonPackFactor
	  ,NatOrderEntrySys				= x.NatOrderEntrySys
	  ,hangertype		= x.hangertype
	  ,POunits			= x.POunits
	  ,POreceiptUnits	= x.POreceiptUnits
	  ,PackingRatio		= x.PackingRatio
	  ,SubPackingRatio	= x.SubPackingRatio
	  ,DeliveryWindowStart			= x.DeliveryWindowStart
	  ,DeliveryWindowEnd			= x.DeliveryWindowEnd
	  ,AdditionalValueDays			= x.AdditionalValueDays
	  ,CustomerReference			= x.CustomerReference
      ,[HashDiff] = x.HashDiff
	  ,RepricingFlag	= x.RepricingFlag
	  ,OrderDescription	= x.OrderDescription
	  ,IntCancelReasonCode = x.IntCancelReasonCode
	  ,ItemBillingBlockReason = x.ItemBillingBlockReason 
	  ,IntSOPriceTypeCode = x.IntSOPriceTypeCode
	  ,ContractStatDesc = x.ContractStatDesc
	  ,PaymentTermDesc = x.PaymentTermDesc
	  ,OrderEntrySys = x.OrderEntrySys
	  ,SalesSemesterCreationDate_Contract = x.SalesSemesterCreationDate_Contract
FROM #ResultwithHashdiff AS x JOIN [sales].[NatSalesOrderCurrentAccumulated] AS prd
ON x.NatSalesOrderCurrentAccumulated_BK = prd.NatSalesOrderCurrentAccumulated_BK
WHERE x.Hashdiff <> prd.Hashdiff

	-- insert Logging Informations to DataTransferLogs
	UPDATE DTlogs
	SET Updated = @AffectedRows
	FROM etl.DataTransferLogs DTlogs
	WHERE DataTransferLogId = @DataTransferLogId

END

-- truncate table [sales].[NatSalesOrderCurrentAccumulated]
--exec [dbo].[S4Hana_spProvNatSalesOrderCurrentAccumulated]'1900-01-01'
--exec [dbo].[S4Hana_spSOCurrentAccumulated_Copa_Update] '1900-01-01'
--exec [dbo].[S4Hana_spSOCurrentAccumulated_Iflag_Update] '1900-01-01'