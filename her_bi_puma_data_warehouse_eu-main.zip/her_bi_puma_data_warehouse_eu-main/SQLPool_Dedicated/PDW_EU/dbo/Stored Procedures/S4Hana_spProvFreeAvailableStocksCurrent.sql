﻿CREATE PROC [dbo].[S4Hana_spProvFreeAvailableStocksCurrent] @LDTS [DATETIME2](7) AS
BEGIN
SET NOCOUNT ON

--DECLARE @LDTS DATETIME2(7) = '19000101'
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(7) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(7)
DECLARE @DestinationLastLoadDate DATETIME2(7)
DECLARE @BatchLdts DATETIME2(7) = @LDTS


-- do not use the input parameter, in case of an failure or reload situartion take the last tranfered LDTS from the Hist table
IF(EXISTS(SELECT 1 FROM [sourcing].[FreeAvailableStockCurrent]))
BEGIN
	SELECT @DestinationLastLoadDate = 
	MAX(LDTS)
	FROM [sourcing].[FreeAvailableStockCurrent]
END
ELSE BEGIN
	SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
END 

IF(EXISTS(SELECT 1 FROM [biz].[S4Hana_FreeAvailableStocksHistory]))
BEGIN
	SELECT @SourceLastLoadDate = MAX(LDTS)
	FROM  [biz].[S4Hana_FreeAvailableStocksHistory]
END
ELSE BEGIN
	SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
END



IF OBJECT_ID('tempdb..#FreeAvailableStocksLast') IS NOT NULL
BEGIN
    DROP TABLE #FreeAvailableStocksLast
END


CREATE TABLE #FreeAvailableStocksLast
(
	[HASH_BK] [binary](16) NOT NULL,
	[AggInventoryMovements_HASH] [binary](16) NOT NULL,
	[AggInventoryValuations_HASH] [binary](16) NULL,
	[AggInventoryTypes_HASH] [binary](16) NULL,
	[HASH_Diff] [binary](16) NULL,
	[NatStoreDC_BK] [nvarchar](20) NULL,
	[COMPANYCODE] [nvarchar](4) NULL,
	[PLANT] [nvarchar](4) NULL,
	[MATERIAL] [nvarchar](40) NULL,
	[STORAGELOCATION] [nvarchar](4) NULL,
	[STOCKSEGMENT] [nvarchar](40) NULL,
	[POSTINGDATE] [date] NULL,
	[QTYTYPE] [nvarchar](128) NULL,
	[MATERIALBASEUNIT] [nvarchar](3) NULL,
	[QTY] [decimal](15, 3) NULL,
	--[RunningTotal] [int] NULL,
	[PRICE] [decimal](17, 2) NULL,
	[VALUE] [decimal](17, 2) NULL,
	[PRICECURRENCY] [nvarchar](5) NULL,
	[VALIDFROMDAT] [date] NULL,
	[VALIDTODAT] [date] NULL,
	[BusinessTypeCode] [int] NULL,
	[INSERTTYPE] [int] NULL,
	[ModifiedOn] [datetime2](7) NULL,
	[NatArticle_BK] [nvarchar](50) NULL,
	[PDUCode] [varchar](15) NULL,
	[IntPupMasterId] [varchar](15) NULL,
	[ArticleNumber_BK] [nvarchar](15) NULL,
	[ArticleSize_BK] [nvarchar](50) NULL,
	[BrandCode] [nvarchar](4) NULL,
	[RBUCode] [int] NULL,
	[ProdDivCode] [int] NULL,
	[StyleNumber_BK] [int] NULL,
	[IntAgeingCode] [int] NULL,
	[IntInventoryStatusCode] [int] NULL,
	[IntInventoryTypeCode] [int] NULL,
	[SPECIALSTOCKINDICATOR] [nvarchar](1) NULL,
	[GROSS] [decimal](17, 2) NULL,
	[LDTS] [datetime2](7) NULL,
	[IsDeleted] [bit] NULL
)
WITH
(
	DISTRIBUTION = HASH(AggInventoryTypes_HASH),
	CLUSTERED COLUMNSTORE INDEX
)

;WITH CTE AS (
SELECT	CONVERT([BINARY](16),
			HASHBYTES('MD5',
				CONCAT(		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.Plant)))), '_',
							UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.Material)))), '_',
							UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.InventoryStatusType))))
							))) AS HASH_BK
		,CONVERT([BINARY](16),
			HASHBYTES('MD5',
				CONCAT(	UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.Plant)))), '_',
							UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.Material)))), '_',
							UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.StockSegment)))), '_',
							UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.InventoryStatusType)))), '_',
							UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.PostingDate))))
							))) AS AggInventoryMovements_HASH
		,NULL AS AggInventoryValuations_HASH
		,CONVERT([BINARY](16),
			HASHBYTES('MD5',
				CONCAT(	UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.Plant)))), '_',
							UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.Material)))), '_',
							UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.StockSegment)))), '_', 
							UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.InventoryStatusType))))
							))) AS AggInventoryTypes_HASH
		,NULL AS HASH_Diff
		,CONVERT(NVARCHAR(20),	CASE	WHEN SHVP.PlantCategoryCode='A' THEN CONCAT(FASH.Plant, '|', CASE WHEN SHI.CompanyCode='PT10' THEN 'ES10' ELSE SHI.CompanyCode END)
												WHEN FASH.StockSegment='' THEN CONCAT(FASH.Plant, '|', CASE WHEN SHI.CompanyCode='PT10' THEN 'ES10' ELSE SHI.CompanyCode END)
												ELSE CONCAT(FASH.Plant, '_', FASH.StockSegment,'|', CASE WHEN SHI.CompanyCode='PT10' THEN 'ES10' ELSE SHI.CompanyCode END)
										END) AS NatStoreDC_BK
		,SHI.CompanyCode AS COMPANYCODE
		,FASH.Plant AS PLANT
		,FASH.Material AS MATERIAL
		,'0001' AS STORAGELOCATION
		,FASH.StockSegment AS STOCKSEGMENT
		,'UNRESTRICTEDSTOCK' AS QTYTYPE
		,FASH.BaseUnitOfMeasure AS MATERIALBASEUNIT
		,FASH.RunningTotal AS QTY
		--,NULL AS RunningTotal
		,CASE	WHEN ISNULL(SHAMSP.PriceControlIndicator, SHAMSPH.PriceControlIndicator)='V'
				THEN ISNULL(SHAMSP.MovingAveragePrice, SHAMSPH.MovingAveragePrice)
				ELSE ISNULL(SHAMSP.StandardPrice, SHAMSPH.StandardPrice)
		END AS PRICE
		,CASE	WHEN ISNULL(SHAMSP.PriceControlIndicator, SHAMSPH.PriceControlIndicator)='V'
				THEN ISNULL(SHAMSP.MovingAveragePrice, SHAMSPH.MovingAveragePrice)
				ELSE ISNULL(SHAMSP.StandardPrice, SHAMSPH.StandardPrice)
		END * FASH.RunningTotal AS VALUE
		,ISNULL(SHAMSP.PriceCurrency, SHAMSPH.PriceCurrency) AS PRICECURRENCY
		,ISNULL(SHAMSP.VALIDFROMDAT, SHAMSPH.ValidFromDat) AS VALIDFROMDAT
		,ISNULL(SHAMSP.VALIDTODAT, SHAMSPH.ValidToDat) AS VALIDTODAT
		,FASH.PostingDate AS POSTINGDATE
		,FASH.PostingDateValidTo AS POSTINGDATEVALIDTO 
		,1 AS BusinessTypeCode
		,-1 AS INSERTTYPE
		,GETDATE() AS ModifiedOn
		,CONCAT(FASH.Material,'|', CASE WHEN SHI.CompanyCode='PT10' THEN 'ES10' ELSE SHI.CompanyCode END) AS NatArticle_BK
		,SHI.PDUCode
		,SHI.IntPupMasterId
		,CONCAT(LTRIM(RTRIM(SHVM.StyleNo)), ' ', LTRIM(RTRIM(SHVM.ColorNo))) AS ArticleNumber_BK
		,CONCAT(LTRIM(RTRIM(SHVM.StyleNo)), ' ', LTRIM(RTRIM(SHVM.ColorNo)), ' ', LTRIM(RTRIM(ISNULL(SHVM.SizeNumber, '0')))) AS ArticleSize_BK
		,SHVM.BrandCode
		,ISNULL(TRY_CONVERT(INT, SHVM.RBUCode), 0) AS RBUCode
		,CONVERT(INT, CASE WHEN SHVM.RetailDCSDepCode IN ('31', '32', '33', '34') AND SHVM.ProdDivCode = '2' THEN '3' ELSE SHVM.ProdDivCode END) AS ProdDivCode
		,CONVERT(INT, ISNULL(TRY_CONVERT(INT, SHVM.StyleNo), 0)) AS StyleNumber_BK
		,50 AS IntAgeingCode
		,FASH.InventoryStatusType AS IntInventoryStatusCode
		,CASE WHEN SHVP.PlantCategoryCode='B' THEN 30 ELSE 40 END AS IntInventoryTypeCode
		,'' AS SPECIALSTOCKINDICATOR
		,0.00 AS GROSS
		,GREATEST(FASH.LDTS,SHAMSP._LDTS,SHAMSPH._LDTS) LDTS
FROM (
		SELECT [Plant]
		      ,[Material]
		      ,[StockSegment]
		      ,PostingDate
			  ,PostingDateValidTo
		      ,[MRPElement]
		      ,[RunningTotal]*X.Ratio as [RunningTotal]
		      ,[BaseUnitOfMeasure]
		      ,[HashDiff]
			  ,X.InventoryStatusType
			  ,LDTS
		FROM [biz].[S4Hana_FreeAvailableStocksHistory] FASH
			CROSS APPLY (SELECT -1 AS Ratio, 10 AS InventoryStatusType UNION SELECT 1, 20 AS InventoryStatusType) AS X
		WHERE
			PostingDateValidTo = '9999-12-31'
	) AS FASH
	LEFT JOIN biz.S4Hana_AggMaterialStockPricesHistory AS SHAMSPH ON	SHAMSPH.Material = FASH.Material
																	   AND SHAMSPH.Plant = FASH.Plant
																	   AND FASH.PostingDate BETWEEN SHAMSPH.ValidFromDat AND SHAMSPH.ValidToDat
	LEFT JOIN biz.S4Hana_AggMaterialStockPrices AS SHAMSP ON        	SHAMSP.Material = FASH.Material
															           AND SHAMSP.Plant = FASH.Plant
															           AND FASH.PostingDate BETWEEN SHAMSP.ValidFromDat AND SHAMSP.ValidToDat
	LEFT JOIN stag.S4Hana_vMaterials AS SHVM ON SHVM.MaterialNumber=FASH.Material
	JOIN stag.S4Hana_vPlants AS SHVP ON SHVP.StoreCode=FASH.Plant
	JOIN stag.S4Hana_vSalesOrgToCompanyCode AS SHVSOTCC ON SHVSOTCC.Code = SHVP.SalesOrganizationCode
	JOIN pdwref.S4Hana_Interfaces AS SHI ON SHI.SalesOrg=SHVP.SalesOrganizationCode AND SHI.Interface='EBP'
WHERE 1=1
	AND (FASH.LDTS > @DestinationLastLoadDate
	OR SHAMSP._LDTS  > @DestinationLastLoadDate
	OR SHAMSPH._LDTS   > @DestinationLastLoadDate)
)


INSERT INTO #FreeAvailableStocksLast
(HASH_BK,
 AggInventoryMovements_HASH,
 AggInventoryValuations_HASH,
 AggInventoryTypes_HASH,
 HASH_Diff,
 POSTINGDATE,
 NatStoreDC_BK,
 COMPANYCODE,
 PLANT,
 MATERIAL,
 STORAGELOCATION,
 STOCKSEGMENT,
 QTYTYPE,
 MATERIALBASEUNIT,
 QTY,
 PRICE,
 GROSS,
 PRICECURRENCY,
 VALIDFROMDAT,
 VALIDTODAT,
 BusinessTypeCode,
 INSERTTYPE,
 ModifiedOn,
 NatArticle_BK,
 PDUCode,
 IntPupMasterId,
 ArticleNumber_BK,
 ArticleSize_BK,
 BrandCode,
 RBUCode,
 ProdDivCode,
 StyleNumber_BK,
 IntAgeingCode,
 IntInventoryStatusCode,
 IntInventoryTypeCode,
 SPECIALSTOCKINDICATOR,
 LDTS,
 IsDeleted)
	SELECT 
	HASH_BK,
	AggInventoryMovements_HASH,
	AggInventoryValuations_HASH,
	AggInventoryTypes_HASH,
	CONVERT([BINARY](16),
			HASHBYTES('MD5',
				CONCAT(	UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), NatStoreDC_BK)))), '_',
				        UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), POSTINGDATE			)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), COMPANYCODE			)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PLANT					)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), MATERIAL				)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), STORAGELOCATION		)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), STOCKSEGMENT			)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), QTYTYPE				)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), MATERIALBASEUNIT		)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), QTY			)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PRICE					)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), GROSS					)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PRICECURRENCY			)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), VALIDFROMDAT			)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), VALIDTODAT			)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), BusinessTypeCode		)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), INSERTTYPE			)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), NatArticle_BK			)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PDUCode				)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), IntPupMasterId		)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ArticleNumber_BK		)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ArticleSize_BK		)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), BrandCode				)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), RBUCode				)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ProdDivCode			)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), StyleNumber_BK		)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), IntAgeingCode			)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), IntInventoryStatusCode)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), IntInventoryTypeCode	)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), SPECIALSTOCKINDICATOR))))		
						))) as HASH_Diff,
	POSTINGDATE,
	NatStoreDC_BK,
	COMPANYCODE,
	PLANT,
	MATERIAL,
	STORAGELOCATION,
	STOCKSEGMENT,
	QTYTYPE,
	MATERIALBASEUNIT,
	QTY,
	PRICE,
	GROSS,
	PRICECURRENCY,
	VALIDFROMDAT,
	VALIDTODAT,
	BusinessTypeCode,
	INSERTTYPE,
	ModifiedOn,
	NatArticle_BK,
	PDUCode,
	IntPupMasterId,
	ArticleNumber_BK,
	ArticleSize_BK,
	BrandCode,
	RBUCode,
	ProdDivCode,
	StyleNumber_BK,
	IntAgeingCode,
	IntInventoryStatusCode,
	IntInventoryTypeCode,
	SPECIALSTOCKINDICATOR,
	LDTS,
	0 as IsDeleted
	FROM CTE

	--insert into table when new
	INSERT INTO [sourcing].[FreeAvailableStockCurrent]
	   (	HASH_BK
		   ,AggInventoryMovements_HASH
		   ,AggInventoryValuations_HASH
		   ,AggInventoryTypes_HASH
		   ,HASH_Diff
		   ,POSTINGDATE
		   ,NatStoreDC_BK
		   ,COMPANYCODE
		   ,PLANT
		   ,MATERIAL
		   ,STORAGELOCATION
		   ,STOCKSEGMENT
		   ,QTYTYPE
		   ,MATERIALBASEUNIT
		   ,QTY
		   ,PRICE
		   ,GROSS
		   ,PRICECURRENCY
		   ,VALIDFROMDAT
		   ,VALIDTODAT
		   ,BusinessTypeCode
		   ,INSERTTYPE
		   ,ModifiedOn
		   ,NatArticle_BK
		   ,PDUCode
		   ,IntPupMasterId
		   ,ArticleNumber_BK
		   ,ArticleSize_BK
		   ,BrandCode
		   ,RBUCode
		   ,ProdDivCode
		   ,StyleNumber_BK
		   ,IntAgeingCode
		   ,IntInventoryStatusCode
		   ,IntInventoryTypeCode
		   ,SPECIALSTOCKINDICATOR
		   ,LDTS
		   ,IsDeleted)
SELECT      a.HASH_BK
		   ,a.AggInventoryMovements_HASH
		   ,a.AggInventoryValuations_HASH
		   ,a.AggInventoryTypes_HASH
		   ,a.HASH_Diff
		   ,a.POSTINGDATE
		   ,a.NatStoreDC_BK
		   ,a.COMPANYCODE
		   ,a.PLANT
		   ,a.MATERIAL
		   ,a.STORAGELOCATION
		   ,a.STOCKSEGMENT
		   ,a.QTYTYPE
		   ,a.MATERIALBASEUNIT
		   ,a.QTY
		   ,a.PRICE
		   ,a.GROSS
		   ,a.PRICECURRENCY
		   ,a.VALIDFROMDAT
		   ,a.VALIDTODAT
		   ,a.BusinessTypeCode
		   ,a.INSERTTYPE
		   ,a.ModifiedOn
		   ,a.NatArticle_BK
		   ,a.PDUCode
		   ,a.IntPupMasterId
		   ,a.ArticleNumber_BK
		   ,a.ArticleSize_BK
		   ,a.BrandCode
		   ,a.RBUCode
		   ,a.ProdDivCode
		   ,a.StyleNumber_BK
		   ,a.IntAgeingCode
		   ,a.IntInventoryStatusCode
		   ,a.IntInventoryTypeCode
		   ,a.SPECIALSTOCKINDICATOR
		   ,a.LDTS
		   ,a.IsDeleted
	from #FreeAvailableStocksLast a
	left join [sourcing].[FreeAvailableStockCurrent] b on a.AggInventoryTypes_HASH=b.AggInventoryTypes_HASH
	where b.AggInventoryTypes_HASH is null
	

	--update when matched on hash and LDTS > old LDTS
	UPDATE ATP SET
	        ATP.HASH_BK                       = new.HASH_BK
		   ,ATP.AggInventoryMovements_HASH	  = new.AggInventoryMovements_HASH
		   ,ATP.AggInventoryValuations_HASH	  = new.AggInventoryValuations_HASH
		   ,ATP.AggInventoryTypes_HASH		  = new.AggInventoryTypes_HASH
		   ,ATP.HASH_Diff					  = new.HASH_Diff
		   ,ATP.POSTINGDATE					  = new.POSTINGDATE
		   ,ATP.NatStoreDC_BK				  = new.NatStoreDC_BK
		   ,ATP.COMPANYCODE					  = new.COMPANYCODE
		   ,ATP.PLANT						  = new.PLANT
		   ,ATP.MATERIAL					  = new.MATERIAL
		   ,ATP.STORAGELOCATION				  = new.STORAGELOCATION
		   ,ATP.STOCKSEGMENT				  = new.STOCKSEGMENT
		   ,ATP.QTYTYPE						  = new.QTYTYPE
		   ,ATP.MATERIALBASEUNIT			  = new.MATERIALBASEUNIT
		   ,ATP.QTY				              = new.QTY
		   ,ATP.PRICE						  = new.PRICE
		   ,ATP.GROSS						  = new.GROSS
		   ,ATP.PRICECURRENCY				  = new.PRICECURRENCY
		   ,ATP.VALIDFROMDAT				  = new.VALIDFROMDAT
		   ,ATP.VALIDTODAT					  = new.VALIDTODAT
		   ,ATP.BusinessTypeCode			  = new.BusinessTypeCode
		   ,ATP.INSERTTYPE					  = new.INSERTTYPE
		   ,ATP.ModifiedOn					  = new.ModifiedOn
		   ,ATP.NatArticle_BK				  = new.NatArticle_BK
		   ,ATP.PDUCode						  = new.PDUCode
		   ,ATP.IntPupMasterId				  = new.IntPupMasterId
		   ,ATP.ArticleNumber_BK			  = new.ArticleNumber_BK
		   ,ATP.ArticleSize_BK				  = new.ArticleSize_BK
		   ,ATP.BrandCode					  = new.BrandCode
		   ,ATP.RBUCode						  = new.RBUCode
		   ,ATP.ProdDivCode					  = new.ProdDivCode
		   ,ATP.StyleNumber_BK				  = new.StyleNumber_BK
		   ,ATP.IntAgeingCode				  = new.IntAgeingCode
		   ,ATP.IntInventoryStatusCode		  = new.IntInventoryStatusCode
		   ,ATP.IntInventoryTypeCode		  = new.IntInventoryTypeCode
		   ,ATP.SPECIALSTOCKINDICATOR		  = new.SPECIALSTOCKINDICATOR
		   ,ATP.LDTS						  = new.LDTS
		   ,ATP.IsDeleted					  = new.IsDeleted
	from #FreeAvailableStocksLast new
	join [sourcing].[FreeAvailableStockCurrent] ATP on ATP.AggInventoryTypes_HASH=new.AggInventoryTypes_HASH
	where new.HASH_Diff <> ATP.HASH_Diff

	--update LDTS for same records

	UPDATE ATP SET ATP.LDTS = new.LDTS
	from #FreeAvailableStocksLast new
	join [sourcing].[FreeAvailableStockCurrent] ATP on ATP.AggInventoryTypes_HASH=new.AggInventoryTypes_HASH
	where  new.LDTS > ATP.LDTS and new.HASH_Diff = ATP.HASH_Diff

	--when hashvaluebk does not exist in new load, flag as deleted

--	UPDATE ATP SET ATP.IsDeleted = 1
--	from [sourcing].[FreeAvailableStockCurrent] ATP
--	left join #FreeAvailableStocksLast new on ATP.AggInventoryTypes_HASH=new.AggInventoryTypes_HASH
--	where new.AggInventoryTypes_HASH is null

	--exec [dbo].[S4Hana_spProvAvailableToPromiseCurrent] '19000101'
	
	END
