﻿CREATE PROC [dbo].[S4Hana_spProvOrdersOnHandHistory_onPrem] @LDTS [DATETIME2](7) AS
BEGIN

-- DECLARE @LDTS DATETIME2(7) = '20000102'
DECLARE @CreatedOn DateTime2(7)
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(7) = GETDATE()
DECLARE @DestinationLastLoadDate DATETIME2(0)
DECLARE @BatchLdts DATETIME2(7) = @LDTS
DECLARE @AffectedRows BIGINT = NULL

-- do not use the input parameter, in case of an failur or reload situartion take the last tranfered LDTS from the Hist table
IF(EXISTS(SELECT 1 FROM [sales].[NatSalesOrdersOohHistory_onPrem]))
BEGIN
	SELECT @DestinationLastLoadDate = MAX(
					  (CONVERT(DATETIME, CONVERT(VARCHAR(255), OrdersOnHandDate)) +
					   CONVERT(DATETIME, TIMEFROMPARTS(OrdersOnHandTime / 10000, (OrdersOnHandTime / 100) % 100, OrdersOnHandTime % 100, 0, 0))) 
					  )
	FROM [sales].NatSalesOrdersOohHistory_onPrem
END
ELSE BEGIN
	SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
END 

--Log Data load
INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'spProvOrdersOnHandHistIncrement_onPrem'
			,'SoDocHistory_onPrem'
			,'NatSalesOrdersOohHistory_onPrem'
			,'sales'
			,@ExecStart
			,@DestinationLastLoadDate
			,@BatchLdts

-- collet all bookings SO/SOItem and OOHDates
IF OBJECT_ID('tempdb..#DistLdtsSoItems') IS NOT NULL
BEGIN
    DROP TABLE #DistLdtsSoItems
END

CREATE TABLE #DistLdtsSoItems
WITH
(DISTRIBUTION = HASH(NatSalesOrderNo)
,HEAP)
AS(
SELECT sohH.[NatSalesOrderNo]
,soiH.[NatSalesOrderItemNo]
,sohH.[LDTS]
FROM [biz].[S4Hana_SODocumentsHistory_onPrem] AS sohH
INNER JOIN [biz].[S4Hana_SoDocumentItemsHistory_onPrem] AS soiH 
	ON sohH.[NatSalesOrderNo] = soiH.[NatSalesOrderNo] 
	AND  soiH.LEDTS = '9999-12-31'
WHERE sohH.[LDTS] > @DestinationLastLoadDate
UNION
SELECT [NatSalesOrderNo]
      ,[NatSalesOrderItemNo]
      ,[LDTS]
FROM [biz].[S4Hana_SoDocumentItemsHistory_onPrem]
WHERE [LDTS] > @DestinationLastLoadDate
UNION
SELECT [NatSalesOrderNo]
      ,[NatSalesOrderItemNo]
      ,LDTS
FROM [biz].[S4Hana_SoScheduleLineDeliveriesHistory_onPrem] -- Delivery Notes included
WHERE [LDTS] > @DestinationLastLoadDate
UNION
SELECT [NatSalesOrderNo]
      ,[NatSalesOrderItemNo]
      ,[LDTS]
FROM [etl].[S4Hana_SoDocumentItemPriceConditionsHistory_onPrem]
WHERE [LDTS] > @DestinationLastLoadDate
)

IF OBJECT_ID('tempdb..#DistLdtsSoItemWihtOutLdts') IS NOT NULL
BEGIN
    DROP TABLE #DistLdtsSoItemWihtOutLdts
END

-- Get just effected SO Items Wihtout LDTS
CREATE TABLE #DistLdtsSoItemWihtOutLdts
WITH
(DISTRIBUTION = HASH(NatSalesOrderNo)
,HEAP)
AS(
SELECT DISTINCT
	 NatSalesOrderNo
	,CONVERT(VARCHAR(40),NatSalesOrderItemNo) AS NatSalesOrderItemNo
FROM #DistLdtsSoItems
)

-- preparation for Call off Logic
-- sum up Contract info for RefSo / RefSoItems

IF OBJECT_ID('tempdb..#SoDocumentCallOffRefContractInfo') IS NOT NULL
BEGIN
    DROP TABLE #SoDocumentCallOffRefContractInfo
END

CREATE TABLE #SoDocumentCallOffRefContractInfo
WITH
(DISTRIBUTION = HASH(CalloffNatSalesOrderNo)  -- Join criteria at PreLogicOhhLogic to NatSalesOrderNo
,HEAP)
AS(
SELECT  s_soh_Contract.NatSalesOrderNo AS ContractNatSalesOrderNo,
		s_sch_Contract.NatSalesOrderItemNo AS ContractNatSalesOrderItemNo,
		s_soi_Calloffs.NatSalesOrderNo AS CalloffNatSalesOrderNo,
		s_soi_Calloffs.NatSalesOrderItemNo AS CalloffNatSalesOrderItemNo,
		s_soh_Contract.SOTypeCode,
		SalesTypesContract.IntSalesType,
		CONVERT(INT,FORMAT(s_sch_Contract.MaxScheduleLineDate,'yyyyMMdd')) AS MaxScheduleLineDate, --> NatSalesDelivDate
		CONVERT(TINYINT,1) AS IntCallOffSOStatusCode
	FROM #DistLdtsSoItems AS SoDocItemCalloffs
	INNER JOIN [biz].[S4Hana_SoDocumentItemsHistory_onPrem] AS s_soi_Calloffs
		ON SoDocItemCalloffs.[NatSalesOrderNo] = s_soi_Calloffs.[NatSalesOrderNo]
		AND SoDocItemCalloffs.[NatSalesOrderItemNo] = s_soi_Calloffs.[NatSalesOrderItemNo] 
		AND SoDocItemCalloffs.LDTS BETWEEN s_soi_Calloffs.LDTS AND s_soi_Calloffs.LEDTS
	INNER JOIN biz.S4Hana_SoDocumentItemsHistory AS s_soi_Contract
		ON s_soi_Calloffs.ReferenceDocumentNumber = s_soi_Contract.NatSalesOrderNo
		AND s_soi_Calloffs.ReferenceDocumentItemNumber = s_soi_Contract.NatSalesOrderItemNo
		AND s_soi_Contract.LEDTS = '9999-12-31'
	INNER JOIN biz.[S4Hana_SoScheduleLineDeliveriesHistory_onPrem] AS s_sch_Contract
		ON s_soi_Calloffs.ReferenceDocumentNumber = s_sch_Contract.[NatSalesOrderNo]
		AND s_soi_Calloffs.ReferenceDocumentItemNumber = s_sch_Contract.[NatSalesOrderItemNo]
		AND s_sch_Contract.LEDTS = '9999-12-31'
	INNER JOIN [biz].[S4Hana_SODocumentsHistory_onPrem] AS s_soh_Contract
		ON s_soi_Calloffs.ReferenceDocumentNumber = s_soh_Contract.[NatSalesOrderNo]
		AND s_soh_Contract.LEDTS = '9999-12-31'
	INNER JOIN pdwref.S4Hana_SalesTypes AS SalesTypesContract 
		ON s_soh_Contract.SOTypeCode = SalesTypesContract.SOTypeCode
	WHERE 1=1
		AND SalesTypesContract.IntSalesType <> 3  --IntSalesTypeCode
		AND s_soh_Contract.SOTypeCode IN ('ZPOC', 'ZROC', 'ZCSC', 'ZMKC', 'ZCOC', 'ZRES') -- added for DI 20221025
		AND s_soh_Contract.IsDeleted = 0
		AND s_soi_Contract.RejectionReason = ''
UNION
-- Add related CallOffs for deleded Contracts
SELECT s_soi_Contract.NatSalesOrderNo AS ContractNatSalesOrderNo,
       s_soi_Contract.NatSalesOrderItemNo AS ContractNatSalesOrderItemNo,
	   s_soi_Calloffs.NatSalesOrderNo AS CalloffNatSalesOrderNo,
       s_soi_Calloffs.NatSalesOrderItemNo AS CalloffNatSalesOrderItemNo,
       s_soh_Contract.SOTypeCode,
       SalesTypesContract.IntSalesType,
       CONVERT(INT,FORMAT(s_sch_Contract.MaxScheduleLineDate,'yyyyMMdd')) AS MaxScheduleLineDate, --> NatSalesDelivDate
	   CONVERT(TINYINT,2) AS IntCallOffSOStatusCode
FROM #DistLdtsSoItems AS SoDocItemCalloffs
	INNER JOIN [biz].[S4Hana_SODocumentsHistory_onPrem] AS s_soh_Contract
		ON SoDocItemCalloffs.[NatSalesOrderNo] = s_soh_Contract.[NatSalesOrderNo]
		AND SoDocItemCalloffs.LDTS BETWEEN s_soh_Contract.LDTS AND s_soh_Contract.LEDTS
	INNER JOIN [biz].[S4Hana_SoDocumentItemsHistory_onPrem] AS s_soi_Contract
		ON SoDocItemCalloffs.[NatSalesOrderNo] = s_soi_Contract.[NatSalesOrderNo]
		AND SoDocItemCalloffs.[NatSalesOrderItemNo] = s_soi_Contract.[NatSalesOrderItemNo]
		AND SoDocItemCalloffs.LDTS BETWEEN s_soi_Contract.LDTS AND s_soi_Contract.LEDTS
	INNER JOIN biz.[S4Hana_SoScheduleLineDeliveriesHistory_onPrem] AS s_sch_Contract
		ON SoDocItemCalloffs.[NatSalesOrderNo] = s_sch_Contract.[NatSalesOrderNo]
		AND SoDocItemCalloffs.[NatSalesOrderItemNo] = s_sch_Contract.[NatSalesOrderItemNo]
		AND s_sch_Contract.LEDTS = '9999-12-31' 
	INNER JOIN biz.S4Hana_SoDocumentItemsHistory_onPrem AS s_soi_Calloffs
		ON s_sch_Contract.NatSalesOrderNo = s_soi_Calloffs.ReferenceDocumentNumber  --> Only for SOItems with Ref -- inner join as a filter
		AND s_sch_Contract.NatSalesOrderItemNo = s_soi_Calloffs.ReferenceDocumentItemNumber
		AND s_sch_Contract.LEDTS = '9999-12-31' 
	INNER JOIN pdwref.S4Hana_SalesTypes AS SalesTypesContract 
		ON s_soh_Contract.SOTypeCode = SalesTypesContract.SOTypeCode
    INNER JOIN #DistLdtsSoItemWihtOutLdts AS LastBatch -- Filter on related SO's at the last batch
		ON s_soi_Calloffs.ReferenceDocumentNumber = LastBatch.NatSalesOrderNo
		AND s_soi_Calloffs.ReferenceDocumentItemNumber = LastBatch.NatSalesOrderItemNo
	WHERE 1=1
		AND SalesTypesContract.IntSalesType <> 3  --IntSalesTypeCode
		AND s_soh_Contract.SOTypeCode IN ('ZPOC', 'ZROC', 'ZCSC', 'ZMKC', 'ZCOC', 'ZRES') -- added for DI 20221025
		AND s_soh_Contract.IsDeleted = 0
		AND s_soi_Contract.RejectionReason <> ''
);

-- Clean up Temp table for all bookings 

IF OBJECT_ID('tempdb..#AllSalesOrderOoHHist') IS NOT NULL
	BEGIN DROP TABLE #AllSalesOrderOoHHist END


;CREATE TABLE #AllSalesOrderOoHHist
WITH (DISTRIBUTION = HASH(NatSalesOrderNo),HEAP) AS
WITH PreLogicOhhLogic AS ( -- Collect all data for the basic for Booking in Cross booking
SELECT 
SoDocItem.LDTS AS OrdersOnHandsDateTime, -- cross booking has to be at the same date with the new entry
CASE WHEN s_soi.RejectionReason <> '' then 2 
	 WHEN s_sch.MinPre_IntSOStatusCode = 2 and s_sch.MaxPre_IntSOStatusCode = 2  then 2 
	 ELSE 1 END	
AS IntSOStatusCode,
CASE WHEN s_soh.IsDeleted = 1 THEN 1
	 WHEN s_soi.IsDeleted = 1 THEN 1
	 WHEN s_sch.IsDeleted = 1 THEN 1
	 ELSE 0	END
AS IsDeleted,
SalesTypes.IntSalesType,
s_soh.NatSalesOrderNo AS NatSalesOrderNo,
s_soi.NatSalesOrderItemNo AS NatSalesOrderItemNo,
s_soi.ReferenceDocumentNumber,
s_soi.ReferenceDocumentItemNumber,
s_soh.CompanyCode,
--IntPupMasterId -- via pdwref.S4Hana_Interfaces
--PDUCode --  via pdwref.S4Hana_Interfaces
CONVERT(NVARCHAR(20), CONCAT(LTRIM(RTRIM(s_soh.CustomerCode_SoldTo)), '|',s_soh.CompanyCode)) AS NatCustomer_BK, -- bk at ref.NatCustomers
CONVERT(NVARCHAR(40), CONCAT(LTRIM(RTRIM(s_soi.MaterialNumber)), '|', CASE WHEN LTRIM(RTRIM(s_soh.CompanyCode)) = 'PT10' THEN 'ES10' ELSE LTRIM(RTRIM(s_soh.CompanyCode))END)) AS NatArticle_BK,
CONVERT(NVARCHAR(20), LTRIM(RTRIM(REPLACE(s_soi.MaterialNumber,'-',' ')))) AS ArticleSize_BK, -- bk at ref.ArticleSize			
CONVERT(INT,ISNULL(TRY_CONVERT(INT,stagMaterial.StyleNo),0)) AS StyleNumber_BK,
CONVERT(CHAR(9), CASE WHEN CHARINDEX('-',LTRIM(stagMaterial.MaterialNumber)) <> 7 
						THEN NULL 
						ELSE REPLACE(LEFT(stagMaterial.MaterialNumber,9),'-',' ') END) AS ArticleNumber_BK,
CONVERT(INT,FORMAT(CAST(s_sch.MaxScheduleLineDate AS DATE),'yyyyMMdd')) AS SODeliveryDate,
CONVERT(INT,FORMAT(CAST(s_sch.MinScheduleLineDate AS DATE),'yyyyMMdd' )) AS SOPlannedDeliveryDate,
s_soh.CurrencyCode,
stagMaterial.RBUCode, -- new
stagMaterial.BrandCode, -- new
stagMaterial.ProdDivCode, -- new
s_soh.SOTypeCode,
SalesTypes.IntSalesType AS IntSalesTypeCode,
--CONVERT(INT,s_soi.OrderQuantity) AS OrderedQty,
CONVERT(INT,CASE WHEN s_soi.RejectionReason <> '' and s_soh.SOTypeCode in( 'ZPTO', 'ZPKP') THEN  s_soi.OrderQuantity ELSE s_sch.ConfirmedOrderQuantity  END ) AS OrderedQty,
CONVERT(INT,s_sch.ConfirmedOrderQuantity) AS ConfirmedQty,

CASE WHEN s_soi.RejectionReason <> '' and s_soh.SOTypeCode in( 'ZPTO', 'ZPKP') 
			THEN  s_soi.OrderQuantity - ISNULL(s_sch.Pre_OOHUnits,0) 
			ELSE s_sch.ConfirmedOrderQuantity - ISNULL(s_sch.Pre_OOHUnits,0) END 
AS OOHUnits

,CASE WHEN s_soh.DistributionChannelCode = 10 THEN /*ECOM*/
             (ISNULL(con.ZERR,0)+ISNULL(con.ZDIF,0)+ISNULL(con.ZECR,0)) 
	  WHEN s_soh.DistributionChannelCode = 40 THEN /*WholeSale*/
            ISNULL(con.ZPR0,0) 
      WHEN s_soh.DistributionChannelCode = 50 THEN /*INTERCOMPANY*/
            (ISNULL(con.ZXFP,0)
            +ISNULL(con.ZSF1,0)+ISNULL(con.ZXRD,0)+ISNULL(con.ZXSM,0)+ISNULL(con.ZXSC,0)
            +ISNULL(con.ZXWC,0)+ISNULL(con.ZXHF,0)+ISNULL(con.ZXFV,0)+ISNULL(con.[ZXF%],0)
            +ISNULL(con.ZXIN,0)+ISNULL(con.ZXDU,0)+ISNULL(con.ZXCF,0)+ISNULL(con.ZIUP,0)) 
      WHEN s_soh.DistributionChannelCode = 60 THEN /*Concession (ZECN=Daily Sales, ZNRR=Training Store)*/
            (ISNULL(con.ZECN,0)+ISNULL(con.ZNRR,0))
      ELSE 0 END
AS GrossSalesValueLC_Single  --OnPrem NatDomGrossSalesValue
	   
,s_soi.NetAmount  AS InvoicedSalesValueLC_Single --OnPrem NatDomNetSalesValue 

,(ISNULL(con.ZPR0,0)+--AS Gross Sales
		ISNULL(con.ZAFG,0)+ISNULL(con.ZDNP,0)+ISNULL(con.ZOUT,0)+--AS CleanupDiscount
        ISNULL(con.ZSPR,0)+--AS Growth
        ISNULL(con.ZCWD,0)+ISNULL(con.ZDIR,0)+ISNULL(con.ZLOG,0)+ISNULL(con.ZMOV,0)+ISNULL(con.ZVAS,0)+--AS Logistics
        ISNULL(con.ZMD0,0)+--AS OtherDiscount
        ISNULL(con.ZBGD,0)+ISNULL(con.ZINV,0)+ISNULL(con.ZPAY,0)+--AS PaymentFulfillment
        ISNULL(con.DIFF,0)+ISNULL(con.ZACC,0)+ISNULL(con.ZART,0)+                                          
        ISNULL(con.ZB2B,0)+ISNULL(con.ZBUY,0)+ISNULL(con.ZEBD,0)+
        ISNULL(con.ZEXL,0)+ISNULL(con.ZORD,0)+ISNULL(con.ZRDI,0)+--AS SellInDiscount
        ISNULL(con.ZPAR,0)+ISNULL(con.ZSIS,0)+ISNULL(con.ZSTS,0)+--AS SellThroughDiscount
        ISNULL(con.ZRAS,0)+--Return Accruals
        ISNULL(con.ZGS1,0)+isnull(con.ZLSM,0)+--Off-Invoice Growth Bonus
        ISNULL(con.ZST1,0)+--Off-Invoice Sell Through Bonus
        ISNULL(con.ZCO1,0))--Off-Invoice Mark Down Bonus CCM
AS NetSalesValueLC_Single  -- OnPrem NatSalesAttribute6 / Net2

,(ISNULL(con.ZSFP,0)+
  ISNULL(con.ZSRD,0)+
  ISNULL(con.ZSSM,0)+
  ISNULL(con.ZSSC,0)+
  ISNULL(con.ZSWC,0)+
  isnull(con.ZICF,0)+
  ISNULL(con.ZIHF,0)+
  ISNULL(con.ZIFV,0)+
  ISNULL(con.[ZIF%],0)+
  ISNULL(con.ZIIN,0)+
  ISNULL(con.ZIDU,0))
AS TotalCogsSplitLC_Single -- OnPrem NatSalesAttribute7 
	
,(ISNULL(con.ZSFP,0)+
  ISNULL(con.ZIFV,0)+
  ISNULL(con.[ZIF%],0)+
  ISNULL(con.ZIIN,0)+
  ISNULL(con.ZIDU,0))
AS TotalCogsSplitExclIntCompLC_Single -- On Prem NatSalesAttribute8         

,(ISNULL(con.ZSRD,0)+
  ISNULL(con.ZSSM,0)+
  ISNULL(con.ZSSC,0)+
  ISNULL(con.ZSWC,0)+
  ISNULL(con.ZICF,0)+
  ISNULL(con.ZIHF,0))
AS TotalIntCompCostLC_Single -- OnPrem NatSalesAttribute9

,(CASE WHEN con.ZSFP IS NOT NULL THEN ISNULL(con.ZSFP,0)+
									   ISNULL(con.ZIFV,0)+
									   ISNULL(con.[ZIF%],0)+
									   ISNULL(con.ZIIN,0)+
									   ISNULL(con.ZIDU,0)
		WHEN con.VPRS IS NOT NULL THEN con.VPRS -
									  (ISNULL(con.ZSRD,0)+
									   ISNULL(con.ZSSM,0)+
									   ISNULL(con.ZSSC,0)+
									   ISNULL(con.ZSWC,0)+
									   ISNULL(con.ZICF,0)+
									   ISNULL(con.ZIHF,0)+
									   ISNULL(con.[ZIF%],0)) -- added at DI implementation
		ELSE ISNULL(con.ZCOS,0) END) 
AS ManagementCostLC_Single -- OnPrem NatSalesAttribute11

,(ISNULL(con.ZFRH,0)+
  ISNULL(con.ZRY1,0)+
  ISNULL(con.ZRY2,0)+
  ISNULL(con.ZRY3,0)+
  ISNULL(con.ZESC,0)+
  ISNULL(con.ZCOC,0))
AS TotalOVCLC_Single -- OnPrem NatSalesAttribute12 

,ISNULL(con.ZSFP ,0) AS FPriceLC_Single -- OnPrem NatSalesAttribute13
,ISNULL(con.ZRAC ,0) AS ReturnAccrualsLC_Single -- OnPrem NatSalesAttribute14

,(CASE WHEN ZSFP IS NOT NULL THEN ISNULL(con.ZSFP,0)+
								  ISNULL(con.ZSRD,0)+
								  ISNULL(con.ZSSM,0)+
								  ISNULL(con.ZSSC,0)+
								  ISNULL(con.ZSWC,0)+
								  ISNULL(con.ZICF,0)+
								  ISNULL(con.ZIHF,0)+
								  ISNULL(con.ZIFV,0)+
								  ISNULL(con.[ZIF%],0)+
								  ISNULL(con.ZIIN,0)+
								  ISNULL(con.ZIDU,0)
		WHEN VPRS IS NOT NULL THEN VPRS 						
		ELSE ISNULL(con.ZCOS,0)	END) 
AS LandedCostValueLC_Single 

 ,CONVERT(TINYINT,
			CASE WHEN s_soi.PrecedingDocumentCategory = 'G' THEN 1 
			ELSE 0 END)
	 AS NatSalesCustomFlag
FROM #DistLdtsSoItems AS SoDocItem
INNER JOIN [biz].[S4Hana_SODocumentsHistory_onPrem] AS s_soh
	ON SoDocItem.[NatSalesOrderNo] = s_soh.[NatSalesOrderNo]
	AND SoDocItem.LDTS BETWEEN s_soh.LDTS AND s_soh.LEDTS
INNER JOIN [biz].[S4Hana_SoDocumentItemsHistory_onPrem] AS s_soi
	ON SoDocItem.[NatSalesOrderNo] = s_soi.[NatSalesOrderNo]
	AND SoDocItem.[NatSalesOrderItemNo] = s_soi.[NatSalesOrderItemNo]
	AND SoDocItem.LDTS BETWEEN s_soi.LDTS AND s_soi.LEDTS
INNER JOIN [biz].[S4Hana_SoDocumentItemPriceConditionsHistory_onPrem] AS con
	ON SoDocItem.[NatSalesOrderNo] = con.[NatSalesOrderNo]
	AND SoDocItem.[NatSalesOrderItemNo] = con.[NatSalesOrderItemNo]
	AND SoDocItem.LDTS BETWEEN con.LDTS AND con.LEDTS
INNER JOIN [biz].[S4Hana_SoScheduleLineDeliveriesHistory_onPrem] AS s_sch
	ON SoDocItem.[NatSalesOrderNo] = s_sch.[NatSalesOrderNo]
	AND SoDocItem.[NatSalesOrderItemNo] = s_sch.[NatSalesOrderItemNo]
	AND SoDocItem.LDTS BETWEEN s_sch.LDTS AND s_sch.LEDTS
INNER JOIN stag.S4Hana_vMaterials AS stagMaterial
	ON s_soi.MaterialNumber = stagMaterial.MaterialNumber
INNER JOIN pdwref.S4Hana_SalesTypes AS SalesTypes 
	ON s_soh.SOTypeCode = SalesTypes.SOTypeCode		  
WHERE stagMaterial.MaterialCategoryCode <> '01' -- filter out generic articles
	AND SalesTypes.IntSalesType <> 3
)
SELECT OrdersOnHandsDateTime
	  ,CONVERT(TINYINT,IntSOStatusCode) AS IntSOStatusCode
	  ,CONVERT(TINYINT,IsDeleted) AS IsDeleted
	  ,CONVERT(TINYINT,1) AS BookingDataSourceInfo
      ,NatSalesOrderNo
      ,CONVERT(VARCHAR(40),NatSalesOrderItemNo) AS NatSalesOrderItemNo
	  ,CONVERT(BINARY(16), HASHBYTES('MD5', CONCAT (
					UPPER(LTRIM(RTRIM(NatSalesOrderNo))),'_',
					UPPER(LTRIM(RTRIM(NatSalesOrderItemNo))),'_',
					UPPER(LTRIM(RTRIM(CompanyCode))),'_',
					UPPER(LTRIM(RTRIM(NatCustomer_BK))),'_',
					UPPER(LTRIM(RTRIM(NatArticle_BK))),'_', -- ArticleSize & Article_BK is incl.
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), StyleNumber_BK)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), SODeliveryDate)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), SOPlannedDeliveryDate)))),'_',
					UPPER(LTRIM(RTRIM(CurrencyCode))),'_',
					UPPER(LTRIM(RTRIM(RBUCode))),'_', 
					UPPER(LTRIM(RTRIM(BrandCode))),'_',
					UPPER(LTRIM(RTRIM(ProdDivCode))),'_',
					UPPER(LTRIM(RTRIM(SOTypeCode))),'_',
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), IntSalesTypeCode)))),'_',					
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), OrderedQty)))),'_', 
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), ConfirmedQty)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), OOHUnits)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), GrossSalesValueLC_Single)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), InvoicedSalesValueLC_Single)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), NetSalesValueLC_Single)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), TotalCogsSplitLC_Single)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), TotalCogsSplitExclIntCompLC_Single)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), TotalIntCompCostLC_Single)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), ManagementCostLC_Single)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), TotalOVCLC_Single)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), FPriceLC_Single)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), ReturnAccrualsLC_Single)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), LandedCostValueLC_Single)))),'_',					
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), IntSOStatusCode)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), IsDeleted))))
		))) AS HashDiff 
        ,CompanyCode
        ,NatCustomer_BK
        ,NatArticle_BK
		,ArticleSize_BK
		,StyleNumber_BK
		,ArticleNumber_BK
		,SODeliveryDate
		,SOPlannedDeliveryDate
        ,CurrencyCode
        ,RBUCode
        ,BrandCode
        ,ProdDivCode
		,SOTypeCode
		,IntSalesTypeCode
        ,OrderedQty
        ,ConfirmedQty
		,OOHUnits
        ,CONVERT(DECIMAL(38,25),GrossSalesValueLC_Single * ABS(OOHUnits)) AS GrossSalesValueLC
        ,CONVERT(DECIMAL(38,25),InvoicedSalesValueLC_Single * ABS(OOHUnits)) AS InvoicedSalesValueLC
        ,CONVERT(DECIMAL(38,25),NetSalesValueLC_Single * ABS(OOHUnits)) AS NetSalesValueLC
        ,CONVERT(DECIMAL(38,25),TotalCogsSplitLC_Single * ABS(OOHUnits)) AS TotalCogsSplitLC
        ,CONVERT(DECIMAL(38,25),TotalCogsSplitExclIntCompLC_Single * ABS(OOHUnits)) AS TotalCogsSplitExclIntCompLC
        ,CONVERT(DECIMAL(38,25),TotalIntCompCostLC_Single * ABS(OOHUnits)) AS TotalIntCompCostLC
        ,CONVERT(DECIMAL(38,25),ManagementCostLC_Single * ABS(OOHUnits)) AS ManagementCostLC
        ,CONVERT(DECIMAL(38,25),TotalOVCLC_Single * ABS(OOHUnits)) AS TotalOVCLC
        ,CONVERT(DECIMAL(38,25),FPriceLC_Single * ABS(OOHUnits)) AS FPriceLC
        ,CONVERT(DECIMAL(38,25),ReturnAccrualsLC_Single * ABS(OOHUnits)) AS ReturnAccrualsLC
		,CONVERT(DECIMAL(38,25),LandedCostValueLC_Single * ABS(OOHUnits)) AS LandedCostValueLC
FROM PreLogicOhhLogic
UNION
SELECT CallOff.OrdersOnHandsDateTime
	  ,CASE WHEN CallOff.IntSOStatusCode = 2 OR Contr.IntCallOffSOStatusCode = 2 THEN CONVERT(TINYINT,2) ELSE CONVERT(TINYINT,1) END AS IntSOStatusCode -- has to be always going through at call off, independent of the real status from the Delivery Note Information
	  ,CONVERT(TINYINT,IsDeleted) AS IsDeleted
	  ,CONVERT(TINYINT,2) AS BookingDataSourceInfo -- CallOff / Contract 
      ,Contr.ContractNatSalesOrderNo AS NatSalesOrderNo
     ,CONVERT(VARCHAR(40),CONCAT(Contr.ContractNatSalesOrderItemNo, '-', CallOff.NatSalesOrderNo, '-', CallOff.NatSalesOrderItemNo, '_OoH')) AS NatSalesOrderItemNo
	  ,CONVERT(BINARY(16), HASHBYTES('MD5', CONCAT (
					UPPER(LTRIM(RTRIM(Contr.ContractNatSalesOrderNo))),'_',
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),CONCAT(Contr.ContractNatSalesOrderItemNo, '-', CallOff.NatSalesOrderNo, '-', CallOff.NatSalesOrderItemNo, '_OoH'))))),'_',
					UPPER(LTRIM(RTRIM(CallOff.CompanyCode))),'_',
					UPPER(LTRIM(RTRIM(CallOff.NatCustomer_BK))),'_', 					
					UPPER(LTRIM(RTRIM(CallOff.NatArticle_BK))),'_', 
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), CallOff.ArticleSize_BK)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), CallOff.StyleNumber_BK)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), CallOff.ArticleNumber_BK)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), contr.MaxScheduleLineDate)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), CallOff.SOPlannedDeliveryDate)))),'_',
					UPPER(LTRIM(RTRIM(CallOff.CurrencyCode))),'_',
					UPPER(LTRIM(RTRIM(CallOff.RBUCode))),'_', 
					UPPER(LTRIM(RTRIM(CallOff.BrandCode))),'_',
					UPPER(LTRIM(RTRIM(CallOff.ProdDivCode))),'_',
					UPPER(LTRIM(RTRIM(CallOff.SOTypeCode))),'_',
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), IntSalesTypeCode)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), CallOff.OrderedQty)))),'_', 
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), CallOff.ConfirmedQty)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), CallOff.GrossSalesValueLC_Single)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), CallOff.InvoicedSalesValueLC_Single)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), CallOff.NetSalesValueLC_Single)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), CallOff.TotalCogsSplitLC_Single)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), CallOff.TotalCogsSplitExclIntCompLC_Single)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), CallOff.TotalIntCompCostLC_Single)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), CallOff.ManagementCostLC_Single)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), CallOff.TotalOVCLC_Single)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), CallOff.FPriceLC_Single)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), CallOff.ReturnAccrualsLC_Single)))),'_',
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), CallOff.LandedCostValueLC_Single)))),'_',					
					UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), CallOff.IsDeleted))))																																		  														   
		))) AS HashDiff 
        ,CallOff.CompanyCode
        ,CallOff.NatCustomer_BK
        ,CallOff.NatArticle_BK
		,CallOff.ArticleSize_BK
		,CallOff.StyleNumber_BK
		,CallOff.ArticleNumber_BK
		,contr.MaxScheduleLineDate AS SODeliveryDate
		,CallOff.SOPlannedDeliveryDate AS SOPlannedDeliveryDate
        ,CallOff.CurrencyCode
        ,CallOff.RBUCode
        ,CallOff.BrandCode
        ,CallOff.ProdDivCode
		,CallOff.SOTypeCode
		,CallOff.IntSalesTypeCode
        ,CallOff.OrderedQty * -1 AS  OrderedQty
        ,CallOff.ConfirmedQty * -1 AS ConfirmedQty
		,CallOff.ConfirmedQty * -1  AS OOHUnits -- at the CallOff take always the ConfirmedQty
        ,CONVERT(DECIMAL(38,25),CallOff.GrossSalesValueLC_Single * ABS(CallOff.ConfirmedQty) * -1) AS GrossSalesValueLC
        ,CONVERT(DECIMAL(38,25),CallOff.InvoicedSalesValueLC_Single * ABS(CallOff.ConfirmedQty) * -1) AS InvoicedSalesValueLC
        ,CONVERT(DECIMAL(38,25),CallOff.NetSalesValueLC_Single * ABS(CallOff.ConfirmedQty) * -1) AS NetSalesValueLC
        ,CONVERT(DECIMAL(38,25),CallOff.TotalCogsSplitLC_Single * ABS(CallOff.ConfirmedQty) * -1) AS TotalCogsSplitLC
        ,CONVERT(DECIMAL(38,25),CallOff.TotalCogsSplitExclIntCompLC_Single * ABS(CallOff.ConfirmedQty) * -1) AS TotalCogsSplitExclIntCompLC
        ,CONVERT(DECIMAL(38,25),CallOff.TotalIntCompCostLC_Single * ABS(CallOff.ConfirmedQty) * -1) AS TotalIntCompCostLC
        ,CONVERT(DECIMAL(38,25),CallOff.ManagementCostLC_Single * ABS(CallOff.ConfirmedQty) * -1) AS ManagementCostLC
        ,CONVERT(DECIMAL(38,25),CallOff.TotalOVCLC_Single * ABS(CallOff.ConfirmedQty) * -1) AS TotalOVCLC
        ,CONVERT(DECIMAL(38,25),CallOff.FPriceLC_Single * ABS(CallOff.ConfirmedQty) * -1) AS FPriceLC
        ,CONVERT(DECIMAL(38,25),CallOff.ReturnAccrualsLC_Single * ABS(CallOff.ConfirmedQty) * -1) AS ReturnAccrualsLC
		,CONVERT(DECIMAL(38,25),CallOff.LandedCostValueLC_Single * ABS(CallOff.ConfirmedQty) * -1) AS LandedCostValueLC
FROM PreLogicOhhLogic AS CallOff
INNER JOIN #SoDocumentCallOffRefContractInfo AS contr 
		ON CallOff.NatSalesOrderNo =  Contr.CalloffNatSalesOrderNo
		AND CallOff.NatSalesOrderItemNo = Contr.CalloffNatSalesOrderItemNo
WHERE CallOff.NatSalesCustomFlag = 1 -- only Calloff Records
	
-- Extend list of Distinct new entries with the Contract SalesOrder

;WITH NewDistinctIncrement AS (
SELECT DISTINCT  
       NatSalesOrderNo
      ,NatSalesOrderItemNo
	  FROM #AllSalesOrderOoHHist)
,LastReleatedBookingEntrieFromHist AS (
SELECT CONVERT(DATETIME2(0),(CONVERT(DATETIME, CONVERT(VARCHAR(255), salesHist.OrdersOnHandDate)) +
							 CONVERT(DATETIME, TIMEFROMPARTS(salesHist.OrdersOnHandTime / 10000, (salesHist.OrdersOnHandTime / 100) % 100, salesHist.OrdersOnHandTime % 100, 0, 0)))) 	 
      AS OrdersOnHandsDateTime
      ,CONVERT(TINYINT,1) AS IntSOStatusCode -- Fix value
	  ,CONVERT(TINYINT,0) AS IsDeleted
      ,CONVERT(TINYINT,3) AS BookingDataSourceInfo -- Source from sales.NatSalesOrdersOohHistory
      ,salesHist.NatSalesOrderNo
      ,salesHist.NatSalesOrderItemNo
      ,salesHist.HashDiff
      ,salesHist.CompanyCode
      ,salesHist.NatCustomer_BK
      ,salesHist.NatArticle_BK
	  ,salesHist.ArticleSize_BK
	  ,salesHist.StyleNumber_BK
	  ,salesHist.ArticleNumber_BK
      ,salesHist.SODeliveryDate
      ,salesHist.SOPlannedDeliveryDate
      ,salesHist.CurrencyCode
      ,salesHist.RBUCode
      ,salesHist.BrandCode
      ,salesHist.ProdDivCode
      ,salesHist.SOTypeCode
      ,salesHist.IntSalesTypeCode
      ,salesHist.OrderedQty
      ,salesHist.ConfirmedQty
	  ,salesHist.OOHUnits
      ,salesHist.GrossSalesValueLC
      ,salesHist.InvoicedSalesValueLC
      ,salesHist.NetSalesValueLC
      ,salesHist.TotalCogsSplitLC
      ,salesHist.TotalCogsSplitExclIntCompLC
      ,salesHist.TotalIntCompCostLC
      ,salesHist.ManagementCostLC
      ,salesHist.TotalOVCLC
      ,salesHist.FPriceLC
      ,salesHist.ReturnAccrualsLC
	  ,salesHist.LandedCostValueLC
	  ,salesHist.BookingTypeCode
	  ,ROW_NUMBER() OVER (PARTITION BY salesHist.NatSalesOrderNo, salesHist.NatSalesOrderItemNo ORDER BY salesHist.OrdersOnHandDate DESC, salesHist.OrdersOnHandTime DESC) AS LastEntryInHist
FROM [sales].[NatSalesOrdersOohHistory_onPrem] AS salesHist
INNER JOIN NewDistinctIncrement AS new 
		ON salesHist.NatSalesOrderNo = new.NatSalesOrderNo
		AND salesHist.NatSalesOrderItemNo = new.NatSalesOrderItemNo
WHERE salesHist.BookingTypeCode = 1 -- Just open booking to get the info for the Cross booking
  )
INSERT INTO #AllSalesOrderOoHHist
	 (OrdersOnHandsDateTime
      ,IntSOStatusCode
      ,IsDeleted
      ,BookingDataSourceInfo
      ,NatSalesOrderNo
      ,NatSalesOrderItemNo
      ,HashDiff
      ,CompanyCode
      ,NatCustomer_BK
      ,NatArticle_BK
	  ,ArticleSize_BK
	  ,StyleNumber_BK
	  ,ArticleNumber_BK
      ,SODeliveryDate
      ,SOPlannedDeliveryDate
      ,CurrencyCode
      ,RBUCode
      ,BrandCode
      ,ProdDivCode
      ,SOTypeCode
      ,IntSalesTypeCode
      ,OrderedQty
      ,ConfirmedQty
	  ,OOHUnits
      ,GrossSalesValueLC
      ,InvoicedSalesValueLC
      ,NetSalesValueLC
      ,TotalCogsSplitLC
      ,TotalCogsSplitExclIntCompLC
      ,TotalIntCompCostLC
      ,ManagementCostLC
      ,TotalOVCLC
      ,FPriceLC
      ,ReturnAccrualsLC
	  ,LandedCostValueLC)
SELECT OrdersOnHandsDateTime
      ,IntSOStatusCode
      ,IsDeleted
      ,BookingDataSourceInfo
      ,NatSalesOrderNo
      ,NatSalesOrderItemNo
      ,HashDiff
      ,CompanyCode
      ,NatCustomer_BK
      ,NatArticle_BK
	  ,ArticleSize_BK
	  ,StyleNumber_BK
	  ,ArticleNumber_BK
      ,SODeliveryDate
      ,SOPlannedDeliveryDate
      ,CurrencyCode
      ,RBUCode
      ,BrandCode
      ,ProdDivCode
      ,SOTypeCode
      ,IntSalesTypeCode
      ,OrderedQty
      ,ConfirmedQty
	  ,OOHUnits
      ,GrossSalesValueLC
      ,InvoicedSalesValueLC
      ,NetSalesValueLC
      ,TotalCogsSplitLC
      ,TotalCogsSplitExclIntCompLC
      ,TotalIntCompCostLC
      ,ManagementCostLC
      ,TotalOVCLC
      ,FPriceLC
      ,ReturnAccrualsLC
	  ,LandedCostValueLC
FROM LastReleatedBookingEntrieFromHist
WHERE LastEntryInHist = 1 

--- Load exisinting DATA from final Table

IF OBJECT_ID('tempdb..#FinalSalesOrderOoHHist') IS NOT NULL
	BEGIN DROP TABLE #FinalSalesOrderOoHHist END

CREATE TABLE #FinalSalesOrderOoHHist
WITH(DISTRIBUTION = HASH(NatSalesOrderNo),HEAP) AS
WITH DiffSorting AS(
SELECT OrdersOnHandsDateTime
      ,IntSOStatusCode
	  ,IsDeleted
      ,BookingDataSourceInfo
      ,NatSalesOrderNo
      ,NatSalesOrderItemNo
      ,HashDiff
      ,CompanyCode
      ,NatCustomer_BK
      ,NatArticle_BK
	  ,ArticleSize_BK
	  ,StyleNumber_BK
	  ,ArticleNumber_BK	  
      ,SODeliveryDate
      ,SOPlannedDeliveryDate
      ,CurrencyCode
      ,RBUCode
      ,BrandCode
      ,ProdDivCode
      ,SOTypeCode
      ,IntSalesTypeCode
      ,OrderedQty
      ,ConfirmedQty
	  ,OOHUnits
      ,GrossSalesValueLC
      ,InvoicedSalesValueLC
      ,NetSalesValueLC
      ,TotalCogsSplitLC
      ,TotalCogsSplitExclIntCompLC
      ,TotalIntCompCostLC
      ,ManagementCostLC
      ,TotalOVCLC
      ,FPriceLC
      ,ReturnAccrualsLC
	  ,LandedCostValueLC
      ,LAG(HashDiff) OVER (PARTITION BY NatSalesOrderNo, NatSalesOrderItemNo ORDER BY OrdersOnHandsDateTime) AS pre_HashDiff
      ,ROW_NUMBER() OVER (PARTITION BY NatSalesOrderNo, NatSalesOrderItemNo ORDER BY OrdersOnHandsDateTime) AS RankOverAll
FROM #AllSalesOrderOoHHist
)
SELECT OrdersOnHandsDateTime
      ,LEAD(OrdersOnHandsDateTime) OVER (PARTITION BY NatSalesOrderNo ,NatSalesOrderItemNo ORDER BY OrdersOnHandsDateTime) AS CrossBookingOrdersOnHandsDateTime
	  ,IntSOStatusCode
	  ,LEAD(IntSOStatusCode) OVER (PARTITION BY NatSalesOrderNo ,NatSalesOrderItemNo ORDER BY OrdersOnHandsDateTime) AS CrossBookingIntSOStatusCode
	  ,IsDeleted
      ,BookingDataSourceInfo
      ,NatSalesOrderNo
      ,NatSalesOrderItemNo
      ,HashDiff 
      ,CompanyCode
      ,NatCustomer_BK
      ,NatArticle_BK
	  ,ArticleSize_BK
	  ,StyleNumber_BK
	  ,ArticleNumber_BK	  
      ,SODeliveryDate
      ,SOPlannedDeliveryDate
      ,CurrencyCode
      ,RBUCode
      ,BrandCode
      ,ProdDivCode
      ,SOTypeCode
      ,IntSalesTypeCode
      ,OrderedQty
      ,ConfirmedQty
	  ,OOHUnits
      ,GrossSalesValueLC
      ,InvoicedSalesValueLC
      ,NetSalesValueLC
      ,TotalCogsSplitLC
      ,TotalCogsSplitExclIntCompLC
      ,TotalIntCompCostLC
      ,ManagementCostLC
      ,TotalOVCLC
      ,FPriceLC
      ,ReturnAccrualsLC
	  ,LandedCostValueLC
FROM DiffSorting
WHERE HashDiff <> pre_HashDiff
   OR RankOverAll = 1 -- to get the first entry

-- Build booking / Cross booking
SELECT @CreatedOn = GetDate() 

---- Insert Bookings
INSERT INTO [sales].[NatSalesOrdersOohHistory_onPrem]
			(OrdersOnHandHistory_BK
				,HashValueBK
				,HashDiff
				,CreatedOn
				,OrdersOnHandDate
				,OrdersOnHandTime
				,BookingTypeCode
				,BookingTypeDesc
				,NatSalesOrderNo
				,NatSalesOrderItemNo
				,CompanyCode
				,IntPupMasterId
				,PDUCode
				,NatCustomer_BK
				,NatArticle_BK
				,StyleNumber_BK
				,ArticleNumber_BK
				,ArticleSize_BK
				,SODeliveryDate
				,SOPlannedDeliveryDate
				,CurrencyCode
				,SOTypeCode
				,IntSalesTypeCode
				,RBUCode
				,BrandCode
				,ProdDivCode
				,OrderedQty
				,ConfirmedQty
				,OOHUnits
				,GrossSalesValueLC
				,InvoicedSalesValueLC
				,NetSalesValueLC
				,TotalCogsSplitLC
				,TotalCogsSplitExclIntCompLC
				,TotalIntCompCostLC
				,ManagementCostLC
				,TotalOVCLC
				,FPriceLC
				,ReturnAccrualsLC
				,LandedCostValueLC				
	)
	SELECT CONVERT(VARCHAR(100),CONCAT( ooh.NatSalesOrderNo, '|'
				  ,ooh.NatSalesOrderItemNo,'|'
				  ,CONVERT(CHAR(8),CONVERT(INT,FORMAT(ooh.OrdersOnHandsDateTime,'yyyyMMdd'))),'|'
				  ,CONVERT(CHAR(6),CONVERT(INT,FORMAT(ooh.OrdersOnHandsDateTime,'HHmmss'))),'|'
				  ,CONVERT(CHAR(1),'1')))
			 AS OrdersOnHandHistory_BK
 		  ,CONVERT(BINARY(16), 
				HASHBYTES('MD5',CONCAT( 
				UPPER(LTRIM(RTRIM( ooh.NatSalesOrderNo))),'_', 
				UPPER(LTRIM(RTRIM( ooh.NatSalesOrderItemNo))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), CONVERT(INT,FORMAT(Ooh.OrdersOnHandsDateTime,'yyyyMMdd')))))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), CONVERT(INT,FORMAT(Ooh.OrdersOnHandsDateTime,'HHmmss')))))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), 1)))))) 
			) AS HashValueBK
		  ,Ooh.HashDiff
		  ,@CreatedOn AS CreatedOn
		  ,CONVERT(INT,FORMAT(Ooh.OrdersOnHandsDateTime,'yyyyMMdd')) AS OrdersOnHandDate
		  ,CONVERT(INT,FORMAT(Ooh.OrdersOnHandsDateTime,'HHmmss')) AS OrdersOnHandTime
		  ,1 AS BookingTypeCode
		  ,CONVERT (NVARCHAR(15),'booking') AS BookingTypeDesc
		  ,CONVERT(char(10),Ooh.NatSalesOrderNo) AS NatSalesOrderNo
		  ,CONVERT(VARCHAR(40),Ooh.NatSalesOrderItemNo) AS NatSalesOrderItemNo
		  ,CONVERT(char(4),Ooh.CompanyCode) AS CompanyCode
		  ,s4If.IntPupMasterId
		  ,CONVERT (VARCHAR(10),s4If.PDUCode) AS PDUCode
		  ,Ooh.NatCustomer_BK
		  ,Ooh.NatArticle_BK
		  ,Ooh.StyleNumber_BK
		  ,Ooh.ArticleNumber_BK
		  ,CONVERT(char(20),Ooh.ArticleSize_BK) AS ArticleSize_BK
		  ,Ooh.SODeliveryDate
		  ,Ooh.SOPlannedDeliveryDate  
		  ,CONVERT(NVARCHAR(3),Ooh.CurrencyCode) AS CurrencyCode
		  ,Ooh.SOTypeCode
		  ,Ooh.IntSalesTypeCode
		  ,Ooh.RBUCode
		  ,Ooh.BrandCode
		  ,Ooh.ProdDivCode
		  ,Ooh.OrderedQty
		  ,Ooh.ConfirmedQty
		  ,Ooh.OOHUnits
		  ,Ooh.GrossSalesValueLC
		  ,Ooh.InvoicedSalesValueLC
		  ,Ooh.NetSalesValueLC
		  ,Ooh.TotalCogsSplitLC
		  ,Ooh.TotalCogsSplitExclIntCompLC
		  ,Ooh.TotalIntCompCostLC
		  ,Ooh.ManagementCostLC
		  ,Ooh.TotalOVCLC
		  ,Ooh.FPriceLC
		  ,Ooh.ReturnAccrualsLC
		  ,Ooh.LandedCostValueLC			  
	  FROM #FinalSalesOrderOoHHist AS Ooh
	  INNER JOIN pdwref.S4Hana_Interfaces AS s4If
		ON ooh.CompanyCode = s4If.CompanyCode
		AND s4If.Interface='EBP'
	  WHERE Ooh.IntSOStatusCode = 1   
			AND IsDeleted  = 0
			AND BookingDataSourceInfo IN (1,2)  -- only Bookings & Call offs -- no "new bookings" from the sales.NatSalesOrdersOohHistory
			AND Ooh.ArticleNumber_BK IS NOT NULL -- temp to filter not valid Articles out 

-- New inserted entries 
SELECT @AffectedRows = COUNT(*)
 FROM #FinalSalesOrderOoHHist AS Ooh
	  INNER JOIN pdwref.S4Hana_Interfaces AS s4If
		ON ooh.CompanyCode = s4If.CompanyCode
		AND s4If.Interface='EBP'
	  WHERE Ooh.IntSOStatusCode = 1   
			AND IsDeleted  = 0
			AND BookingDataSourceInfo IN (1,2)  -- only Bookings & Call offs -- no "new bookings" from the sales.NatSalesOrdersOohHistory
			AND Ooh.ArticleNumber_BK IS NOT NULL -- temp to filter not valid Articles out 

-- Update Inserted of the load
UPDATE DTlogs
SET Inserted = @AffectedRows
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

--- Insert cross bookings
INSERT INTO sales.NatSalesOrdersOohHistory_onPrem
                (OrdersOnHandHistory_BK
				,HashValueBK
				,HashDiff
				,CreatedOn
				,OrdersOnHandDate
				,OrdersOnHandTime
				,BookingTypeCode
				,BookingTypeDesc
				,NatSalesOrderNo
				,NatSalesOrderItemNo
				,CompanyCode
				,IntPupMasterId
				,PDUCode
				,NatCustomer_BK
				,NatArticle_BK
				,StyleNumber_BK
				,ArticleNumber_BK
				,ArticleSize_BK
				,SODeliveryDate
				,SOPlannedDeliveryDate
				,CurrencyCode
				,SOTypeCode
				,IntSalesTypeCode
				,RBUCode
				,BrandCode
				,ProdDivCode
				,OrderedQty
				,ConfirmedQty
				,OOHUnits
				,GrossSalesValueLC
				,InvoicedSalesValueLC
				,NetSalesValueLC
				,TotalCogsSplitLC
				,TotalCogsSplitExclIntCompLC
				,TotalIntCompCostLC
				,ManagementCostLC
				,TotalOVCLC
				,FPriceLC
				,ReturnAccrualsLC
				,LandedCostValueLC

	)
		SELECT CONVERT(NVARCHAR(100),CONCAT( ooh.NatSalesOrderNo, '|'
				  ,ooh.NatSalesOrderItemNo,'|'
				  ,CONVERT(CHAR(8),CONVERT(INT,FORMAT(Ooh.CrossBookingOrdersOnHandsDateTime ,'yyyyMMdd'))),'|'											
				  ,CONVERT(CHAR(6),CONVERT(INT,FORMAT(Ooh.CrossBookingOrdersOnHandsDateTime,'HHmmss'))),'|'
				  ,CONVERT(CHAR(1),'2')))
			 AS OrdersOnHandHistory_BK
 		  ,CONVERT(BINARY(16), 
				HASHBYTES('MD5',CONCAT( 
				UPPER(LTRIM(RTRIM( ooh.NatSalesOrderNo))),'_', 
				UPPER(LTRIM(RTRIM( ooh.NatSalesOrderItemNo))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), CONVERT(INT,FORMAT(Ooh.CrossBookingOrdersOnHandsDateTime,'yyyyMMdd')))))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), CONVERT(INT,FORMAT( Ooh.CrossBookingOrdersOnHandsDateTime,'HHmmss')))))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), 2)))))) 
			) AS HashValueBK
		  ,Ooh.HashDiff
		  ,@CreatedOn AS CreatedOn
		  ,CONVERT(INT,FORMAT(Ooh.CrossBookingOrdersOnHandsDateTime,'yyyyMMdd')) AS OrdersOnHandDate
		  ,CONVERT(INT,FORMAT(Ooh.CrossBookingOrdersOnHandsDateTime,'HHmmss')) AS OrdersOnHandTime
		  ,2 AS BookingTypeCode
		  ,CONVERT (NVARCHAR(15),'cross-entry') AS BookingTypeDesc
		  ,CONVERT(char(10),Ooh.NatSalesOrderNo) AS NatSalesOrderNo
		  ,CONVERT(VARCHAR(40),Ooh.NatSalesOrderItemNo) AS NatSalesOrderItemNo
		  ,CONVERT(char(4),Ooh.CompanyCode) AS CompanyCode
		  ,s4If.IntPupMasterId
		  ,CONVERT (VARCHAR(10),s4If.PDUCode) AS PDUCode
		  ,Ooh.NatCustomer_BK
		  ,Ooh.NatArticle_BK
		  ,Ooh.StyleNumber_BK
		  ,Ooh.ArticleNumber_BK
		  ,CONVERT(char(20),Ooh.ArticleSize_BK) AS ArticleSize_BK
		  ,Ooh.SODeliveryDate
		  ,Ooh.SOPlannedDeliveryDate
		  ,CONVERT(NVARCHAR(3),Ooh.CurrencyCode) AS CurrencyCode
		  ,Ooh.SOTypeCode
		  ,Ooh.IntSalesTypeCode
		  ,Ooh.RBUCode
		  ,Ooh.BrandCode
		  ,Ooh.ProdDivCode
		  ,Ooh.OrderedQty * -1 AS OrderedQty
		  ,Ooh.ConfirmedQty * -1 AS ConfirmedQty
		  ,Ooh.OOHUnits * -1 AS OOHUnits
		  ,Ooh.GrossSalesValueLC * -1 AS GrossSalesValueLC
		  ,Ooh.InvoicedSalesValueLC * -1 AS InvoicedSalesValueLC
		  ,Ooh.NetSalesValueLC * -1 AS NetSalesValueLC
		  ,Ooh.TotalCogsSplitLC * -1 AS TotalCogsSplitLC
		  ,Ooh.TotalCogsSplitExclIntCompLC * -1 AS TotalCogsSplitExclIntCompLC
		  ,Ooh.TotalIntCompCostLC * -1 AS TotalIntCompCostLC
		  ,Ooh.ManagementCostLC * -1 AS ManagementCostLC
		  ,Ooh.TotalOVCLC * -1 AS TotalOVCLC
		  ,Ooh.FPriceLC * -1 AS FPriceLC
		  ,Ooh.ReturnAccrualsLC * -1 AS ReturnAccrualsLC
		  ,Ooh.LandedCostValueLC * -1 AS LandedCostValueLC		   
	  FROM #FinalSalesOrderOoHHist AS Ooh
	  INNER JOIN pdwref.S4Hana_Interfaces AS s4If
		on ooh.CompanyCode = s4If.CompanyCode
	  WHERE BookingDataSourceInfo in(1,2,3) -- just crossbookings for bookings (source from increment or Hist table)
		AND CrossBookingOrdersOnHandsDateTime IS NOT NULL AND Ooh.IntSOStatusCode = 1 -- last booking is open and  next booking does not close the SO via StatusCode <>1
		AND IsDeleted  = 0
		AND Ooh.ArticleNumber_BK IS NOT NULL -- temp to filter not valid Articles out 


-- Count Cross booking and use the updated column
SELECT @AffectedRows = NULL -- reset Var

SELECT @AffectedRows = COUNT(*)
 FROM #FinalSalesOrderOoHHist AS Ooh
  INNER JOIN pdwref.S4Hana_Interfaces AS s4If
		on ooh.CompanyCode = s4If.CompanyCode
	  WHERE BookingDataSourceInfo in(1,2,3) -- just crossbookings for bookings (source from increment or Hist table)
		AND CrossBookingOrdersOnHandsDateTime IS NOT NULL AND Ooh.IntSOStatusCode = 1 -- last booking is open and  next booking does not close the SO via StatusCode <>1
		AND IsDeleted  = 0
		AND Ooh.ArticleNumber_BK IS NOT NULL -- temp to filter not valid Articles out 

-- Update End of the load
UPDATE DTlogs
SET ExecEnd = GETDATE()
	,Updated = @AffectedRows
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId


-- to close all open Record for the onPrem History

/* Start here, do it manual
 IF OBJECT_ID('tempdb..#OpenSOItems') IS NOT NULL
BEGIN
    DROP TABLE #OpenSOItems
END

CREATE TABLE #OpenSOItems
WITH
(DISTRIBUTION = HASH(NatSalesOrderNo)
,HEAP)
AS(
	SELECT MAX((CONVERT(DATETIME, CONVERT(VARCHAR(255), OrdersOnHandDate)) +
				 CONVERT(DATETIME, TIMEFROMPARTS(OrdersOnHandTime / 10000, (OrdersOnHandTime / 100) % 100, OrdersOnHandTime % 100, 0, 0)))) AS OrdersOnHandsDateTime
	,NatSalesOrderNo
    ,NatSalesOrderItemNo
	,SUM(OOHUnits) AS SumOohUnits
FROM sales.NatSalesOrdersOohHistory_onPrem
--where NatSalesOrderItemNo not like '%_OoH'
Group by NatSalesOrderNo
		,NatSalesOrderItemNo
	HAVING SUM(OOHUnits) <> 0

)

Declare @OrdersOnHandsDateTime DATETIME2(7) = '2022-11-10 10:10:10.000'
INSERT INTO sales.NatSalesOrdersOohHistory_onPrem
                (OrdersOnHandHistory_BK
				,HashValueBK
				,HashDiff
				,CreatedOn
				,OrdersOnHandDate
				,OrdersOnHandTime
				,BookingTypeCode
				,BookingTypeDesc
				,NatSalesOrderNo
				,NatSalesOrderItemNo
				,CompanyCode
				,IntPupMasterId
				,PDUCode
				,NatCustomer_BK
				,NatArticle_BK
				,StyleNumber_BK
				,ArticleNumber_BK
				,ArticleSize_BK
				,SODeliveryDate
				,SOPlannedDeliveryDate
				,CurrencyCode
				,SOTypeCode
				,IntSalesTypeCode
				,RBUCode
				,BrandCode
				,ProdDivCode
				,OrderedQty
				,ConfirmedQty
				,OOHUnits
				,GrossSalesValueLC
				,InvoicedSalesValueLC
				,NetSalesValueLC
				,TotalCogsSplitLC
				,TotalCogsSplitExclIntCompLC
				,TotalIntCompCostLC
				,ManagementCostLC
				,TotalOVCLC
				,FPriceLC
				,ReturnAccrualsLC
				,LandedCostValueLC
	)
SELECT CONVERT(NVARCHAR(100),CONCAT( ooh.NatSalesOrderNo, '|'
				  ,ooh.NatSalesOrderItemNo,'|'
				  ,CONVERT(CHAR(8),CONVERT(INT,FORMAT(@OrdersOnHandsDateTime ,'yyyyMMdd'))),'|'											
				  ,CONVERT(CHAR(6),CONVERT(INT,FORMAT(@OrdersOnHandsDateTime,'HHmmss'))),'|'
				  ,CONVERT(CHAR(1),'2')))
			 AS OrdersOnHandHistory_BK
 		  ,CONVERT(BINARY(16), 
				HASHBYTES('MD5',CONCAT( 
				UPPER(LTRIM(RTRIM( ooh.NatSalesOrderNo))),'_', 
				UPPER(LTRIM(RTRIM( ooh.NatSalesOrderItemNo))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), CONVERT(INT,FORMAT(@OrdersOnHandsDateTime,'yyyyMMdd')))))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), CONVERT(INT,FORMAT(@OrdersOnHandsDateTime,'HHmmss')))))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), 2)))))) 
			) AS HashValueBK
      ,ooh.HashDiff
      ,GETDate() AS CreatedOn
      ,CONVERT(INT,FORMAT(@OrdersOnHandsDateTime,'yyyyMMdd')) AS OrdersOnHandDate  
      ,CONVERT(INT,FORMAT(@OrdersOnHandsDateTime,'HHmmss')) OrdersOnHandTime 
	  ,2 AS BookingTypeCode
	  ,CONVERT (NVARCHAR(15),'cross-entry') AS BookingTypeDesc
      ,ooh.NatSalesOrderNo
      ,ooh.NatSalesOrderItemNo
      ,ooh.CompanyCode
      ,ooh.IntPupMasterId
      ,ooh.PDUCode
      ,ooh.NatCustomer_BK
      ,ooh.NatArticle_BK
      ,ooh.StyleNumber_BK
      ,ooh.ArticleNumber_BK
      ,ooh.ArticleSize_BK
      ,ooh.SODeliveryDate
      ,ooh.SOPlannedDeliveryDate
      ,ooh.CurrencyCode
      ,ooh.SOTypeCode
      ,ooh.IntSalesTypeCode
      ,ooh.RBUCode
      ,ooh.BrandCode
      ,ooh.ProdDivCode
	  ,ooh.OrderedQty * -1 AS OrderedQty
	  ,ooh.ConfirmedQty * -1 AS ConfirmedQty
	  ,ooh.OOHUnits * -1 AS OOHUnits
	  ,ooh.GrossSalesValueLC * -1 AS GrossSalesValueLC
	  ,ooh.InvoicedSalesValueLC * -1 AS InvoicedSalesValueLC
	  ,ooh.NetSalesValueLC * -1 AS NetSalesValueLC
	  ,ooh.TotalCogsSplitLC * -1 AS TotalCogsSplitLC
	  ,ooh.TotalCogsSplitExclIntCompLC * -1 AS TotalCogsSplitExclIntCompLC
	  ,ooh.TotalIntCompCostLC * -1 AS TotalIntCompCostLC
	  ,ooh.ManagementCostLC * -1 AS ManagementCostLC
	  ,ooh.TotalOVCLC * -1 AS TotalOVCLC
	  ,ooh.FPriceLC * -1 AS FPriceLC
	  ,ooh.ReturnAccrualsLC * -1 AS ReturnAccrualsLC
	  ,ooh.LandedCostValueLC * -1 AS LandedCostValueLC		
  FROM sales.NatSalesOrdersOohHistory_onPrem AS ooh
  INNER JOIN #OpenSOItems As OpenSo 
		ON ooh.NatSalesOrderNo = OpenSo.NatSalesOrderNo
		AND ooh.NatSalesOrderItemNo = OpenSo.NatSalesOrderItemNo
		AND ooh.OrdersOnHandDate = CONVERT(INT,FORMAT(OpenSo.OrdersOnHandsDateTime,'yyyyMMdd'))
		AND ooh.OrdersOnHandTime = CONVERT(INT,FORMAT(OpenSo.OrdersOnHandsDateTime,'HHmmss'))
		AND ooh.BookingTypeCode = 1

-- End of closing process
*/

END -- END SP