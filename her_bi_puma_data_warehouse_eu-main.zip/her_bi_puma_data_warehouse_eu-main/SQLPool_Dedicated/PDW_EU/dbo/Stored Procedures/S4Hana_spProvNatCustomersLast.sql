﻿CREATE PROC [dbo].[S4Hana_spProvNatCustomersLast] @LDTS [DATETIME2](7) AS

-- Should be in Synapse Pipeline
--EXEC [etl].[S4Hana_spMasterCodesCustomers]
--EXEC [etl].[S4Hana_spCustomerBusinessPartner]
--EXEC [etl].[S4Hana_spCustomerSalesPartners]

DECLARE @LoadDate DATETIME2(7) = GETDATE();

TRUNCATE TABLE etl.S4Hana_NatCustomers;

-- logging informations - BEGIN
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(0) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(0)
DECLARE @DestinationLastLoadDate DATETIME2(0)
DECLARE @BatchLdts DATETIME2(0) = @LDTS
DECLARE @AffectedRows BIGINT = NULL
-- logging Informations - END

-- get last LDTS Informations for Logging
IF(EXISTS(SELECT 1 FROM ref.NatCustomers))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(modifiedOn))
		FROM ref.NatCustomers
	END
ELSE 
	BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

IF(EXISTS(SELECT 1 FROM ref.NatCustomers))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(modifiedOn))
		FROM ref.NatCustomers
	END
ELSE 
	BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END
-- Logging Informations END


-- Log first DATA Informations

INSERT INTO etl.DataTransferLogs
(
  DataTransferLogId
, TransferName
, TransferGroupName
, TargetTableName
, TargetSchemaName
, ExecStart
, SourceLastLoadDate
, DestinationLastLoadDate
, BatchLdts
)
SELECT 
  @DataTransferLogId 
, 'S4Hana_spProvNatCustomersLast'
, 'NatCustomers'
, 'NatCustomers'
, 'ref'
, @ExecStart
, @SourceLastLoadDate
, @DestinationLastLoadDate
, @BatchLdts;

-- Log first DATA Informations END

WITH CTE_Customer_Hierarchy AS
(
	SELECT
	  A.CustomerNumber
	, A.SalesOrgCode
	, A.MainCustomer
	, B.CustomerName AS MainCustomerName
	, A.MasterCustomer
	, F.[Description] AS MasterCustomerName
	, A.CustomerStructure
	, A.BuyingGroup
	, A.PUMADistributionChannel
	, D.Account
	, E.[Description] AS AccountName
	, A.AreaAccount
	, A.AccountRole
	, A.ReportingGroup10
	, A.DistributionChannelCode
	, A.CustomerGroup AS CustomerGroupCode
	, C.[Description] AS CustomerGroupDesc
	, A.CreditBlock
	, A.CreditBlockReason
	, A.CustomerGroupName		
	, A.DC31Performance
	, A.Specialist
	, A.NeveroutofStock	
	, A.LocalOwnerGroup
	, A.TeamBusinessSpecIdentification
	, A.ShopName
	, A.AccountType
	, A.EDI
	, A.CallCenterCampaign
	, A.CommercialOperations
	, A.EarlyShipment
	, A.RestrictProdAccess
	, A.credit_limit
	, A.CreditControlArea
	, A.Postingblockforcompanycode
	, A.DeletionFlagCompanyCodeLevel
	, A.BlockKeyforPayment
	, A.DunningArea
	, A.DunningBlock
	, A.dunningclerk
    , A.LocalCustomerGroup  AS LocalCustomerGroupCode
	, G.[Description] 	AS LocalCustomerGroupDesc
	, A.AdditionalCustomerGroup4
	, A.[AccountByCustomer]
	, A.HOAccountNo
	, A.AutomaticDelCreation
	, CONCAT(H.ILN1,H.ILN2,H.ILNchk) as DZBNo
	, A.AccountingClerkAbbreviation
	, CASE WHEN A.TierDC10 != '' THEN A.TierDC10 + ', ' ELSE '' END
		+ CASE WHEN A.TierDC20 != '' THEN A.TierDC20 + ', ' ELSE '' END
		+ CASE WHEN A.TierDC30 != '' THEN A.TierDC30 + ', ' ELSE '' END
		+ CASE WHEN A.TierDC40 != '' THEN A.TierDC40 + ', ' ELSE '' END
		+ CASE WHEN A.TierDC45 != '' THEN A.TierDC45 + ', ' ELSE '' END
		+ CASE WHEN A.TierDC50 != '' THEN A.TierDC50 + ', ' ELSE '' END
		+ CASE WHEN A.TierDC60 != '' THEN A.TierDC60 + ', ' ELSE '' END
			[TieringCode]
	, CASE WHEN Tier_L1.[DESCRIPTION] IS NOT NULL THEN Tier_L1.[DESCRIPTION] + ', ' ELSE '' END
		+ CASE WHEN Tier_L2.[DESCRIPTION] IS NOT NULL THEN Tier_L2.[DESCRIPTION] + ', ' ELSE '' END
		+ CASE WHEN Tier_L3.[DESCRIPTION] IS NOT NULL THEN Tier_L3.[DESCRIPTION] + ', ' ELSE '' END
		+ CASE WHEN Tier_L4.[DESCRIPTION] IS NOT NULL THEN Tier_L4.[DESCRIPTION] + ', ' ELSE '' END
		+ CASE WHEN Tier_L45.[DESCRIPTION] IS NOT NULL THEN Tier_L45.[DESCRIPTION] + ', ' ELSE '' END
		+ CASE WHEN Tier_L5.[DESCRIPTION] IS NOT NULL THEN Tier_L5.[DESCRIPTION] + ', ' ELSE '' END
		+ CASE WHEN Tier_L6.[DESCRIPTION] IS NOT NULL THEN Tier_L6.[DESCRIPTION] + ', ' ELSE '' END
			[TieringName]
	, CAST(CASE WHEN A.OSSTeamshopAccess = 'X' THEN 1 ELSE 0 END AS BIT) AS TeamshopAccessFlag
	, A.DunningLevel
	, CAST(CASE WHEN A.PKFAccess = 'X' THEN 1 ELSE 0 END AS BIT) AS PKFAccessFlag
	--, ROW_NUMBER() OVER (PARTITION BY A.CustomerNumber, A.SalesOrgCode
	--					 ORDER BY CASE WHEN LEFT(A.CustomerNumber , 4) = A.SalesOrgCode THEN 1
	--									ELSE 2  END)	AS rnk
	, ROW_NUMBER() OVER (PARTITION BY A.CustomerNumber ,A.SalesOrgCode
						 ORDER BY CASE WHEN A.DistributionChannelCode = '40' then '00' 
						 WHEN A.DistributionChannelCode = '60' then '01'
						 else A.DistributionChannelCode END) as rnk
	FROM stag.S4Hana_vCustomerSalesAttributes A
	LEFT JOIN stag.S4Hana_vCustomers B ON A.MainCustomer = B.CustomerCode
	LEFT JOIN etl.S4Hana_MasterCodesCustomers C	ON A.CustomerGroup = C.Code 
		AND C.[Group] = 'CustomerGroupTexts'
	LEFT JOIN stag.S4Hana_vCustomerAccountMapping D ON A.MasterCustomer = D.MasterCustomer
	LEFT JOIN stag.S4Hana_vCustomerAccountTexts E ON D.Account = E.Code
	LEFT JOIN stag.S4Hana_vMasterCustomerTexts F ON D.MasterCustomer = F.Code
	LEFT JOIN [stag].[S4Hana_vLocalCustomerGroupTexts] G ON A.LocalCustomerGroup = G.LOCALCUSTGR
	LEFT JOIN stag.S4Hana_vBPGeneralData1 H on A.CustomerNumber = H.BusinessPartner
	LEFT JOIN [stag].[S4Hana_vLocalDCTierText] Tier_L1 ON A.TierDC10 = Tier_L1.TIER
    LEFT JOIN [stag].[S4Hana_vLocalDCTierText] Tier_L2 ON A.TierDC20 = Tier_L2.TIER
    LEFT JOIN [stag].[S4Hana_vLocalDCTierText] Tier_L3 ON A.TierDC30 = Tier_L3.TIER
    LEFT JOIN [stag].[S4Hana_vLocalDCTierText] Tier_L4 ON A.TierDC40 = Tier_L4.TIER
    LEFT JOIN [stag].[S4Hana_vLocalDCTierText] Tier_L45 ON A.TierDC45 = Tier_L45.TIER
    LEFT JOIN [stag].[S4Hana_vLocalDCTierText] Tier_L5 ON A.TierDC50 = Tier_L5.TIER
    LEFT JOIN [stag].[S4Hana_vLocalDCTierText] Tier_L6 ON A.TierDC60 = Tier_L6.TIER
	WHERE  (
			 A.LDTS >= @LDTS 
			 OR B.LDTS >= @LDTS 
			 OR C.LDTS >= @LDTS
			 OR D.LDTS >= @LDTS
			 OR E.LDTS >= @LDTS
			 OR F.LDTS >= @LDTS
			)
)
, CTE_SalesManager AS
(
	SELECT
	  CustomerNo
	, MAX(LDTS) as LDTS
	, String_AGG(SalesManagerCode,', ') as SalesManagerCode
	, String_AGG(SalesManagerName,', ') as SalesManagerName
	FROM etl.s4Hana_CustomerBusinessPartner
	GROUP BY CustomerNo
)
, CTE_SalesAreaManager AS
(
	SELECT DISTINCT 
	  CustomerNo
	, LDTS
	, SalesAreaManagerCode 
	, SalesAreaManagerName 
	FROM etl.s4Hana_CustomerBusinessPartner
	WHERE SalesAreaManagerCode is not null
)
, CTE_CustomerServiceRep AS
(
	SELECT
	  CustomerNo
	, MAX(LDTS) as LDTS
	, String_AGG(CustomerServiceRepCode,', ') as CustomerServiceRepCode
	, String_AGG(CustomerServiceRepName,', ') as CustomerServiceRepName
	FROM etl.s4Hana_CustomerBusinessPartner
	GROUP BY CustomerNo
)
/* Added by Reza PumaDC*/
, CTE_DC as (
select customer, PUMADC , value from (
select 
distinct 
Customer 
,[DC10SportsSpecial]			
,[DC20Sports]					
,[DC30SportStyle]				
,[DC40SportLifest]			  
,[DC50Lifestyle]				
,[DC60Fashion]				   
,[DC35SportStylePlus]			
,[DC45LifestylePlus]			
,[DC90Distributer]			  
,[DC90B2B]					  
,[DC92InternalSales]			
,[DC93MonobrandFranchiseStore]  
,[DC94MassMerchant]			  
,[DC95Clearance]				
,[DC99Others]					
,[DC31Performance]			  
from  [stag].[S4Hana_vCustomerSalesAttributes_all]
) p
unpivot (
Value for PUMADC in (
 [DC10SportsSpecial]			
,[DC20Sports]					
,[DC30SportStyle]				
,[DC40SportLifest]			
,[DC50Lifestyle]			
,[DC60Fashion]			
,[DC35SportStylePlus]
,[DC45LifestylePlus]			
,[DC90Distributer]		
,[DC90B2B]		
,[DC92InternalSales]
,[DC93MonobrandFranchiseStore]
,[DC94MassMerchant]
,[DC95Clearance]			
,[DC99Others]				
,[DC31Performance]
)
) as unpvt 
)
,
CTE_PUMADC as (
select customer ,string_agg(cast(PUMADC as nvarchar(max)),';') within group (order by customer) PUMADC
from CTE_DC
where value <> ''
group by customer)
,
CTE_TAXCAT as (
 select 
  *,
  LEFT(TAXNUMBERCAT , 2) as taxcat,
  ROW_NUMBER() OVER (PARTITION BY BUSINESSPARTNER, LEFT(TAXNUMBERCAT , 2) ORDER BY TAXNUMBERCAT) as rng 
 from [stag].[S4Hana_vTax] 
 )
 , CTE_TAX as (
 select BUSINESSPARTNER ,taxcat ,TAXNUMBER from CTE_TAXCAT 
 where rng= 1 
 )
 ,
 CTE_Insur as (
 select 
 *,
  ROW_NUMBER() OVER (PARTITION BY [partner], CRITER ORDER BY DATA_TYPE) as rng 
 from  [stag].[S4Hana_vInsuranceLimit]
 where ADDTYPE = 40
 )
 ,
 CTE_InsLmt as (
 select [partner], CRITER, INSURANCELIMIT  from CTE_Insur 
 where rng= 1 
 ),
CTE_Risk as
     (
             select
                     p.[PARTNER]       ,
                     p.CREDITSEGMENT   ,
                     p.CHECKRULE       ,
                     p.LIMITRULE       ,
                     p.RISKCLASS       ,
                     seg.CREDITSGMNTTXT,
                     rul.CHECKRULETEXT ,
                     lmt.LIMITRULETEXT ,
                     cls.RISKCLASSTEXT
             from stag.[S4Hana_vCreditLimitandClasses] p
             left join stag.s4hana_vCreditLimitCRDTSgmtText seg
             on p.CREDITSEGMENT = seg.CREDITSEGMENT
             left join stag.s4hana_vCreditLimitCheckRuleText rul
             on p.CHECKRULE = rul.CHECKRULE
             left join stag.s4hana_vCreditLimitLmtRuleText lmt
             on p.LIMITRULE = lmt.LIMITRULE
             left join stag.s4hana_vCreditLimitRiskClassText cls
             on p.RISKCLASS = cls.RISKCLASS )
, CTE_Customers AS
(
	SELECT
	  CONVERT(NVARCHAR(50), CONCAT(LTRIM(RTRIM(A.CustomerCode)), '|',LTRIM(RTRIM(B.SalesOrgCode))))		AS NatCustomer_BK
	, @LoadDate																							AS CreatedOn
	, @LoadDate																							AS ModifiedOn
	, A.CustomerCode																					AS NatCustomerNo 
	, D.CompanyCode																						AS CompanyCode
    , B.SalesOrgCode																					AS SalesOrganization
	, D.IntPupMasterId																					AS IntPupMasterId
	, D.PDUCode																							AS PDUCode
	, A.CustomerName																					AS NatCustomerName																				
	, ISNULL(B.MainCustomer, '')																		AS MainCustomerNo	
	, ISNULL(B.MainCustomerName , '')																	AS MainCustomerName
	--, ISNULL(CASE WHEN ISNULL(B.MasterCustomer, '') = '' THEN 
	--				CASE WHEN ISNULL(B.MainCustomer,'') = '' THEN A.CustomerCode
	--					 ELSE B.MainCustomer
	--				END
	--			  ELSE B.MasterCustomer
	--		 END, '')																					AS MasterCustomerNo
	,ISNULL(B.MasterCustomer, '')																		AS MasterCustomerNo
	--, ISNULL(CASE WHEN B.MasterCustomerName IS NULL THEN
	--				CASE WHEN B.MainCustomerName IS NULL THEN A.CustomerName
	--					 ELSE B.MainCustomerName
	--				END
	--			  ELSE B.MasterCustomerName
	--		 END, '')																					AS MasterCustomerName
	,ISNULL(B.MasterCustomerName, '')																	AS MasterCustomerName
	, CASE WHEN A.CustomerAccountGroup = 'Z005' THEN 30 --Inter Company Customer
		WHEN A.CustomerAccountGroup IN ('Z011','Z012') THEN 20 --Puma Retail Store
		   ELSE 10 --Wholesale Customer
	  END																								AS CustBusClassCode
	, CASE WHEN A.CustomerAccountGroup = 'Z005' THEN 'Inter Company Customer'
		WHEN A.CustomerAccountGroup IN ('Z011','Z012') THEN 'Puma Retail Store'
		   ELSE 'Wholesale Customer'
	  END																								AS CustBusClassDesc
	, B.PUMADistributionChannel																			AS DistChannelCode
	, (
		SELECT [Description]
		FROM [pdwref].[S4Hana_CustomerDistributionChannel] 
		WHERE  [CustDistChannelCode] = B.PUMADistributionChannel
	  )																									AS DistChannelDesc
	, A.Country																							AS CountryCode
	, A.City																							AS City
	, A.PostalCode																						AS PostalCode
	, A.Street																							AS Street
	, A.Region																							AS Region
	, A.[Language]																						AS [Language]
	, A.OrganizationBPName1																				AS OrganizationBPName1
	, A.OrderIsBlockedForCustomer																		AS OrderIsBlockedForCustomer
	, DC.PUMADC																							AS PumaDC
	, E.ISOCountryDesc																					AS CountryDesc
	, A.CustomerAccountGroup																			AS CustomerAccountGroup
	, B.Account																							AS Account
	, B.AccountName																						AS AccountName
	, B.AreaAccount																						AS AreaAccount
	, B.AccountRole																						AS AccountRole
	, B.CustomerGroupCode																				AS CustomerGroupCode
	, B.CustomerGroupDesc																				AS CustomerGroupDesc
	, B.ReportingGroup10																				AS ReportingGroup10
	, A.CustomerCorporateGroup																			AS CustomerCorporateGroup
	, A.OrganizationBpName2																				AS OrganizationBpName2
	, B.CreditBlock																						AS CreditBlock
	, B.CreditBlockReason																				AS CreditBlockReason
	, B.CustomerGroupName																				AS CustomerGroupName
	, B.BuyingGroup																						AS BuyingGroup
	, B.DC31Performance																					AS DC31Performance
	, B.Specialist																						AS Specialist
	, B.NeveroutofStock																					AS NeveroutofStock	
	, B.LocalOwnerGroup																					AS LocalOwnerGroup
	, B.TeamBusinessSpecIdentification																	AS TeamBusinessSpecIdentification
	, B.ShopName																						AS ShopName
	, B.AccountType																						AS AccountType
	, B.EDI																								AS EDI
	, B.CallCenterCampaign																				AS CallCenterCampaign
	, B.CommercialOperations																			AS CommercialOperations
	, B.EarlyShipment																					AS EarlyShipment
	, B.RestrictProdAccess																				AS RestrictProdAccess
	, B.credit_limit																					AS credit_limit
	, B.CreditControlArea																				AS CreditControlArea
	, B.Postingblockforcompanycode																		AS Postingblockforcompanycode
	, B.DeletionFlagCompanyCodeLevel																	AS DeletionFlagCompanyCodeLevel
	, B.BlockKeyforPayment																				AS BlockKeyforPayment
	, B.DunningArea																						AS DunningArea
	, B.DunningBlock																					AS DunningBlock
	, B.dunningclerk																					AS DunningClerk
	, G.SalesManagerCode																				AS SalesManagerCode
	, G.SalesManagerName																				AS SalesManagerName
	, H.SalesAreaManagerCode																			AS SalesAreaManagerCode
	, H.SalesAreaManagerName																			AS SalesAreaManagerName
	, F.SalesmanCode																					AS SalesmanCode
	, F.SalesmanName																					AS SalesmanName
	, F.PayerCode																						AS PayerCode
	, F.PayerName																						AS PayerName
	, F.OwnerGroupCode																					AS OwnerGroupCode
	, F.OwnerGroupName																					AS OwnerGroupName
	, I.CustomerServiceRepCode																			AS CustomerServiceRepCode
	, I.CustomerServiceRepName																			AS CustomerServiceRepName
    , B.LocalCustomerGroupCode                                                                          AS LocalCustomerGroupCode
	, B.LocalCustomerGroupDesc																			AS LocalCustomerGroupDesc
	, B.AdditionalCustomerGroup4																		AS AdditionalCustomerGroup4
	, T.TAXNUMBER																						AS TAXNUMBER
	, Ins.INSURANCELIMIT																				AS InsuranceLimit
	, B.AccountByCustomer
	, B.HOAccountNo
	, B.AutomaticDelCreation
	, B.AccountingClerkAbbreviation
	, A.ConditionGroup1
	, A.ConditionGroup2
	, CH.credit_limit																					AS Payer_credit_limit
    , CH.CreditBlock																					AS Payer_CreditBlock
	, COALESCE(B.DZBNo,CH.DZBNo)                                                                        AS DZBNo
	, A.VATRegistration	
	, CASE WHEN A.isdeleted = 0 THEN 1
		   ELSE 0
	  END																								AS Active
	, CASE WHEN RIGHT(B.[TieringCode], 2) = ', ' THEN LEFT(B.[TieringCode], LEN(B.[TieringCode]) - 1) ELSE '' END	AS [TieringCode]
	, CASE WHEN RIGHT(B.[TieringName], 2) = ', ' THEN LEFT(B.[TieringName], LEN(B.[TieringName]) - 1) ELSE '' END	AS [TieringName]
	--, ROW_NUMBER() OVER (PARTITION BY A.CustomerCode ,C.CompanyCode
	--					 ORDER BY CASE WHEN B.DistributionChannelCode = '40' then '00' 
	--					 WHEN B.DistributionChannelCode = '60' then '01'
	--					 else B.DistributionChannelCode END)	AS RN
	, Rsk.CREDITSGMNTTXT AS CreditSegmnt
	, Rsk.CHECKRULETEXT  AS CheckRule
	, Rsk.LIMITRULETEXT  AS LimitRule
	, Rsk.RISKCLASSTEXT  AS RiskClass
	, B.TeamshopAccessFlag
	, B.DunningLevel
	, B.PKFAccessFlag
	FROM stag.S4Hana_vCustomers A
	INNER JOIN CTE_Customer_Hierarchy B ON A.CustomerCode = B.CustomerNumber and B.rnk = 1
	INNER JOIN stag.S4Hana_vSalesOrgToCompanyCode C ON B.SalesOrgCode = C.Code
	INNER JOIN pdwref.S4Hana_Interfaces D ON B.SalesOrgCode = D.SalesOrg
	LEFT JOIN pdwref.ISOCountries E ON A.Country = E.ISOCountryCode
	LEFT JOIN etl.s4Hana_CustomerSalesPartners F ON A.CustomerCode = F.CustomerNo AND B.SalesOrgCode = F.SalesOrgCode
	LEFT JOIN CTE_Customer_Hierarchy CH on F.PayerCode = CH.CustomerNumber  and CH.SalesOrgCode = B.SalesOrgCode and CH.rnk = 1
	LEFT JOIN CTE_SalesManager G ON F.SalesmanCode = G.CustomerNo
	LEFT JOIN CTE_SalesAreaManager H ON A.CustomerCode = H.CustomerNo
	LEFT JOIN CTE_CustomerServiceRep I ON A.CustomerCode = I.CustomerNo
	LEFT JOIN CTE_PUMADC DC ON A.CustomerCode = DC.customer
	LEFT JOIN CTE_TAX T ON A.CustomerCode = t.BUSINESSPARTNER and A.country = t.taxcat
	LEFT JOIN CTE_InsLmt Ins ON A.CustomerCode = Ins.[partner] and A.country = LEFT(Ins.CRITER , 2)
	LEFT JOIN CTE_Risk Rsk ON A.CustomerCode = Rsk.[PARTNER]
	WHERE (
		   A.LDTS >= @LDTS 
		   OR C.LDTS >= @LDTS
		   OR F.LDTS >= @LDTS
		   OR G.LDTS >= @LDTS
		   OR H.LDTS >= @LDTS
		   OR I.LDTS >= @LDTS
		  ) 
)
-- Load ETL Table
INSERT INTO etl.S4Hana_NatCustomers
(
  NatCustomer_BK
, CreatedOn
, ModifiedOn
, NatCustomerNo 
, CompanyCode
, SalesOrganization
, IntPupMasterId
, PDUCode
, HashDiff
, NatCustomerName
, MainCustomerNo
, MainCustomerName
, MasterCustomerNo
, MasterCustomerName
, CustBusClassCode
, CustBusClassDesc
, DistChannelCode
, DistChannelDesc
, CountryCode
, CountryDesc
, City
, PostalCode
, Street
, Region
, [Language]
, OrganizationBPName1
, OrderIsBlockedForCustomer
, PumaDC
, CustomerAccountGroup
, Account
, AccountName
, AreaAccount
, AccountRole
, CustomerGroupCode
, CustomerGroupDesc
, ReportingGroup10
, CustomerCorporateGroup
, OrganizationBpName2
, CreditBlock
, CreditBlockReason
, CustomerGroupName	
, BuyingGroup
, DC31Performance
, Specialist
, NeveroutofStock	
, LocalOwnerGroup
, TeamBusinessSpecIdentification
, ShopName
, AccountType
, EDI
, CallCenterCampaign
, CommercialOperations
, EarlyShipment
, RestrictProdAccess
, credit_limit
, CreditControlArea
, Postingblockforcompanycode
, DeletionFlagCompanyCodeLevel
, BlockKeyforPayment
, DunningArea
, DunningBlock
, DunningClerk
, SalesManagerCode
, SalesManagerName
, SalesAreaManagerCode
, SalesAreaManagerName
, SalesmanCode
, SalesmanName
, PayerCode
, PayerName
, OwnerGroupCode
, OwnerGroupName
, CustomerServiceRepCode
, CustomerServiceRepName
, LocalCustomerGroupCode
, LocalCustomerGroupDesc
, AdditionalCustomerGroup4
, TAXNUMBER
, InsuranceLimit
, AccountByCustomer
, HOAccountNo
, AutomaticDelCreation
, AccountingClerkAbbreviation
, ConditionGroup1
, ConditionGroup2
, Payer_credit_limit
, Payer_CreditBlock
, DZBNo
, VATRegistration
, Active
, TieringCode
, TieringName
, CreditSegmnt
, CheckRule
, LimitRule
, RiskClass
, TeamshopAccessFlag
, DunningLevel
, PKFAccessFlag
)
SELECT
  NatCustomer_BK
, CreatedOn
, ModifiedOn
, NatCustomerNo 
, CompanyCode
, SalesOrganization
, IntPupMasterId
, PDUCode
, CONVERT(BINARY(16), HASHBYTES('MD5', CONCAT(
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), NatCustomer_BK						)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), NatCustomerNo						)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CompanyCode							)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), SalesOrganization					)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), IntPupMasterId						)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PDUCode								)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), NatCustomerName						)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), MainCustomerNo						)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), MainCustomerName						)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), MasterCustomerNo						)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), MasterCustomerName					)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CustBusClassCode						)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CustBusClassDesc						)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), DistChannelCode						)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), DistChannelDesc						)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CountryCode							)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CountryDesc							)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), City									)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PostalCode							)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), Street								)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), Region								)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [Language]							)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), OrganizationBPName1					)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), OrderIsBlockedForCustomer			)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PumaDC								)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CustomerAccountGroup					)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), Account								)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), AccountName							)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), AreaAccount							)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), AccountRole							)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CustomerGroupCode					)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CustomerGroupDesc					)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ReportingGroup10						)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CustomerCorporateGroup				)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), OrganizationBpName2					)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CreditBlock							)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CreditBlockReason					)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CustomerGroupName					)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), BuyingGroup							)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), DC31Performance						)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), Specialist							)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), NeveroutofStock						)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), LocalOwnerGroup						)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), TeamBusinessSpecIdentification		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ShopName								)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), AccountType							)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), EDI									)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CallCenterCampaign					)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CommercialOperations					)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), EarlyShipment						)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), RestrictProdAccess					)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), credit_limit							)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CreditControlArea					)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), Postingblockforcompanycode			)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), DeletionFlagCompanyCodeLevel			)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), BlockKeyforPayment					)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), DunningArea							)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), DunningBlock							)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), DunningClerk							)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), SalesManagerCode						)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), SalesManagerName						)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), SalesAreaManagerCode					)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), SalesAreaManagerName					)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), SalesmanCode							)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), SalesmanName							)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PayerCode							)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PayerName							)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), OwnerGroupCode						)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), OwnerGroupName						)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CustomerServiceRepCode				)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CustomerServiceRepName				)))),'_',
        UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), LocalCustomerGroupCode			    )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), LocalCustomerGroupDesc			    )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), AdditionalCustomerGroup4				)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), TAXNUMBER							)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), InsuranceLimit						)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), AccountByCustomer					)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), HOAccountNo							)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), AutomaticDelCreation					)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), AccountingClerkAbbreviation			)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ConditionGroup1						)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ConditionGroup2						)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), Payer_credit_limit					)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), Payer_CreditBlock					)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), DZBNo					            )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), VATRegistration					    )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), Active								)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CreditSegmnt							)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CheckRule							)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), LimitRule							)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), RiskClass							)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), TieringCode							)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), TieringName							)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), TeamshopAccessFlag					)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), DunningLevel							)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PKFAccessFlag						))))
  ))) AS HashDiff
, NatCustomerName
, MainCustomerNo
, MainCustomerName
, MasterCustomerNo
, MasterCustomerName
, CustBusClassCode
, CustBusClassDesc
, DistChannelCode
, DistChannelDesc
, CountryCode
, CountryDesc
, City
, PostalCode
, Street
, Region
, [Language]
, OrganizationBPName1
, OrderIsBlockedForCustomer
, PumaDC
, CustomerAccountGroup
, Account
, AccountName
, AreaAccount
, AccountRole
, CustomerGroupCode
, CustomerGroupDesc
, ReportingGroup10
, CustomerCorporateGroup
, OrganizationBpName2
, CreditBlock
, CreditBlockReason
, CustomerGroupName	
, BuyingGroup
, DC31Performance
, Specialist
, NeveroutofStock	
, LocalOwnerGroup
, TeamBusinessSpecIdentification
, ShopName
, AccountType
, EDI
, CallCenterCampaign
, CommercialOperations
, EarlyShipment
, RestrictProdAccess
, credit_limit
, CreditControlArea
, Postingblockforcompanycode
, DeletionFlagCompanyCodeLevel
, BlockKeyforPayment
, DunningArea
, DunningBlock
, DunningClerk
, SalesManagerCode
, SalesManagerName
, SalesAreaManagerCode
, SalesAreaManagerName
, SalesmanCode
, SalesmanName
, PayerCode
, PayerName
, OwnerGroupCode
, OwnerGroupName
, CustomerServiceRepCode
, CustomerServiceRepName
, LocalCustomerGroupCode
, LocalCustomerGroupDesc
, AdditionalCustomerGroup4
, TAXNUMBER
, InsuranceLimit
, AccountByCustomer
, HOAccountNo
, AutomaticDelCreation
, AccountingClerkAbbreviation
, ConditionGroup1
, ConditionGroup2
, Payer_credit_limit
, Payer_CreditBlock
, DZBNo
, VATRegistration
, Active
, TieringCode
, TieringName
, CreditSegmnt
, CheckRule
, LimitRule
, RiskClass
, TeamshopAccessFlag
, DunningLevel
, PKFAccessFlag
FROM CTE_Customers 
--WHERE RN = 1

--Count Records to be updated
SELECT @AffectedRows = COUNT(*)
FROM ref.NatCustomers A
INNER JOIN etl.S4Hana_NatCustomers B ON A.NatCustomer_BK = B.NatCustomer_BK
WHERE A.HashDiff <> B.HashDiff

--Update Final Table
UPDATE A SET
  A.ModifiedOn = @LoadDate
, A.NatCustomerNo = B.NatCustomerNo
, A.CompanyCode = B.CompanyCode
, A.SalesOrganization = B.SalesOrganization
, A.IntPupMasterId = B.IntPupMasterId
, A.PDUCode = B.PDUCode
, A.HashDiff = B.HashDiff
, A.NatCustomerName = B.NatCustomerName
, A.MainCustomerNo = B.MainCustomerNo
, A.MainCustomerName = B.MainCustomerName
, A.MasterCustomerNo = B.MasterCustomerNo
, A.MasterCustomerName = B.MasterCustomerName
, A.CustBusClassCode = B.CustBusClassCode
, A.CustBusClassDesc = B.CustBusClassDesc
, A.DistChannelCode = B.DistChannelCode
, A.DistChannelDesc = B.DistChannelDesc
, A.CountryCode = B.CountryCode
, A.CountryDesc = B.CountryDesc
, A.City = 	B.City
, A.PostalCode = B.PostalCode
, A.Street = B.Street
, A.Region = B.Region
, A.[Language] = B.[Language]
, A.OrganizationBPName1 = B.OrganizationBPName1
, A.OrderIsBlockedForCustomer = B.OrderIsBlockedForCustomer
, A.PumaDC = B.PumaDC
, A.CustomerAccountGroup = B.CustomerAccountGroup
, A.Account = B.Account
, A.AccountName = B.AccountName
, A.AreaAccount = B.AreaAccount
, A.AccountRole = B.AccountRole
, A.CustomerGroupCode = B.CustomerGroupCode
, A.CustomerGroupDesc = B.CustomerGroupDesc
, A.ReportingGroup10 = B.ReportingGroup10
, A.CustomerCorporateGroup = B.CustomerCorporateGroup
, A.OrganizationBpName2 = B.OrganizationBpName2
, A.CreditBlock = B.CreditBlock
, A.CreditBlockReason = B.CreditBlockReason
, A.CustomerGroupName = B.CustomerGroupName
, A.BuyingGroup = B.BuyingGroup
, A.DC31Performance = B.DC31Performance 						
, A.Specialist = B.Specialist 							
, A.NeveroutofStock = B.NeveroutofStock 						
, A.LocalOwnerGroup = B.LocalOwnerGroup 						
, A.TeamBusinessSpecIdentification = B.TeamBusinessSpecIdentification 		
, A.ShopName = B.ShopName 							
, A.AccountType = B.AccountType 							
, A.EDI = B.EDI 									
, A.CallCenterCampaign = B.CallCenterCampaign 					
, A.CommercialOperations = B.CommercialOperations 				
, A.EarlyShipment = B.EarlyShipment 						
, A.RestrictProdAccess = B.RestrictProdAccess 					
, A.credit_limit = B.credit_limit 						
, A.CreditControlArea = B.CreditControlArea 					
, A.Postingblockforcompanycode = B.Postingblockforcompanycode 			
, A.DeletionFlagCompanyCodeLevel = B.DeletionFlagCompanyCodeLevel 		
, A.BlockKeyforPayment = B.BlockKeyforPayment 					
, A.DunningArea = B.DunningArea 							
, A.DunningBlock = B.DunningBlock
, A.DunningClerk = B.DunningClerk
, A.SalesManagerCode = B.SalesManagerCode
, A.SalesManagerName = B.SalesManagerName
, A.SalesAreaManagerCode = B.SalesAreaManagerCode
, A.SalesAreaManagerName = B.SalesAreaManagerName
, A.SalesmanCode = B.SalesmanCode
, A.SalesmanName = B.SalesmanName
, A.PayerCode = B.PayerCode
, A.PayerName = B.PayerName
, A.OwnerGroupCode = B.OwnerGroupCode
, A.OwnerGroupName = B.OwnerGroupName
, A.CustomerServiceRepCode = B.CustomerServiceRepCode
, A.CustomerServiceRepName = B.CustomerServiceRepName
, A.LocalCustomerGroupCode = B.LocalCustomerGroupCode
, A.LocalCustomerGroupDesc = B.LocalCustomerGroupDesc
, A.AdditionalCustomerGroup4 = B.AdditionalCustomerGroup4
, A.TAXNUMBER = B.TAXNUMBER
, A.InsuranceLimit = B.InsuranceLimit
, A.AccountByCustomer = B.AccountByCustomer
, A.HOAccountNo		= B.HOAccountNo
, A.AutomaticDelCreation = B.AutomaticDelCreation
, A.AccountingClerkAbbreviation	= B.AccountingClerkAbbreviation
, A.ConditionGroup1	= B.ConditionGroup1
, A.ConditionGroup2 = B.ConditionGroup2
, A.Payer_credit_limit = B.Payer_credit_limit
, A.Payer_CreditBlock = B.Payer_CreditBlock
, A.DZBNo = B.DZBNo
, A.VATRegistration = B.VATRegistration
, A.Active = B.Active
, A.CreditSegmnt = B.CreditSegmnt
, A.CheckRule = B.CheckRule
, A.LimitRule = B.LimitRule
, A.RiskClass = B.RiskClass
, A.TieringCode	= B.TieringCode
, A.TieringName = B.TieringName
, A.TeamshopAccessFlag = B.TeamshopAccessFlag
, A.DunningLevel = B.DunningLevel
, A.PKFAccessFlag = B.PKFAccessFlag
FROM ref.NatCustomers A
INNER JOIN etl.S4Hana_NatCustomers B ON A.NatCustomer_BK = B.NatCustomer_BK
WHERE A.HashDiff <> B.HashDiff

--Log count of updated records
UPDATE DTlogs SET
  Updated = @AffectedRows
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

--Count Records to be inserted
SELECT @AffectedRows = COUNT(*)
FROM etl.S4Hana_NatCustomers A
LEFT JOIN ref.NatCustomers B ON A.NatCustomer_BK = B.NatCustomer_BK
WHERE B.NatCustomer_BK IS NULL

--Insert to Final Table
INSERT INTO ref.NatCustomers
(
  NatCustomer_BK
, CreatedOn
, ModifiedOn
, NatCustomerNo 
, CompanyCode
, SalesOrganization
, IntPupMasterId
, PDUCode
, HashDiff
, NatCustomerName
, MainCustomerNo
, MainCustomerName
, MasterCustomerNo
, MasterCustomerName
, CustBusClassCode
, CustBusClassDesc
, DistChannelCode
, DistChannelDesc
, CountryCode
, CountryDesc
, City
, PostalCode
, Street
, Region
, [Language]
, OrganizationBPName1
, OrderIsBlockedForCustomer
, PumaDC
, CustomerAccountGroup
, Account
, AccountName
, AreaAccount
, AccountRole
, CustomerGroupCode
, CustomerGroupDesc
, ReportingGroup10
, CustomerCorporateGroup
, OrganizationBpName2
, CreditBlock
, CreditBlockReason
, CustomerGroupName	
, BuyingGroup
, DC31Performance
, Specialist
, NeveroutofStock	
, LocalOwnerGroup
, TeamBusinessSpecIdentification
, ShopName
, AccountType
, EDI
, CallCenterCampaign
, CommercialOperations
, EarlyShipment
, RestrictProdAccess
, credit_limit
, CreditControlArea
, Postingblockforcompanycode
, DeletionFlagCompanyCodeLevel
, BlockKeyforPayment
, DunningArea
, DunningBlock
, DunningClerk
, SalesManagerCode
, SalesManagerName
, SalesAreaManagerCode
, SalesAreaManagerName
, SalesmanCode
, SalesmanName
, PayerCode
, PayerName
, OwnerGroupCode
, OwnerGroupName
, CustomerServiceRepCode
, CustomerServiceRepName
, LocalCustomerGroupCode
, LocalCustomerGroupDesc
, AdditionalCustomerGroup4
, TAXNUMBER
, InsuranceLimit
, AccountByCustomer
, HOAccountNo
, AutomaticDelCreation
, AccountingClerkAbbreviation
, ConditionGroup1
, ConditionGroup2
, Payer_credit_limit
, Payer_CreditBlock
, DZBNo
, VATRegistration
, Active
, TieringCode
, TieringName
, CreditSegmnt
, CheckRule
, LimitRule
, RiskClass
, TeamshopAccessFlag
, DunningLevel
, PKFAccessFlag
)
SELECT
  A.NatCustomer_BK
, A.CreatedOn
, A.ModifiedOn
, A.NatCustomerNo 
, A.CompanyCode
, A.SalesOrganization
, A.IntPupMasterId
, A.PDUCode
, A.HashDiff
, A.NatCustomerName
, A.MainCustomerNo
, A.MainCustomerName
, A.MasterCustomerNo
, A.MasterCustomerName
, A.CustBusClassCode
, A.CustBusClassDesc
, A.DistChannelCode
, A.DistChannelDesc
, A.CountryCode
, A.CountryDesc
, A.City
, A.PostalCode
, A.Street
, A.Region
, A.[Language]
, A.OrganizationBPName1
, A.OrderIsBlockedForCustomer
, A.PumaDC
, A.CustomerAccountGroup
, A.Account
, A.AccountName
, A.AreaAccount
, A.AccountRole
, A.CustomerGroupCode
, A.CustomerGroupDesc
, A.ReportingGroup10
, A.CustomerCorporateGroup
, A.OrganizationBpName2
, A.CreditBlock
, A.CreditBlockReason
, A.CustomerGroupName
, A.BuyingGroup
, A.DC31Performance
, A.Specialist
, A.NeveroutofStock	
, A.LocalOwnerGroup
, A.TeamBusinessSpecIdentification
, A.ShopName
, A.AccountType
, A.EDI
, A.CallCenterCampaign
, A.CommercialOperations
, A.EarlyShipment
, A.RestrictProdAccess
, A.credit_limit
, A.CreditControlArea
, A.Postingblockforcompanycode
, A.DeletionFlagCompanyCodeLevel
, A.BlockKeyforPayment
, A.DunningArea
, A.DunningBlock
, A.DunningClerk
, A.SalesManagerCode
, A.SalesManagerName
, A.SalesAreaManagerCode
, A.SalesAreaManagerName
, A.SalesmanCode
, A.SalesmanName
, A.PayerCode
, A.PayerName
, A.OwnerGroupCode
, A.OwnerGroupName
, A.CustomerServiceRepCode
, A.CustomerServiceRepName
, A.LocalCustomerGroupCode
, A.LocalCustomerGroupDesc
, A.AdditionalCustomerGroup4
, A.TAXNUMBER
, A.InsuranceLimit
, A.AccountByCustomer
, A.HOAccountNo
, A.AutomaticDelCreation
, A.AccountingClerkAbbreviation
, A.ConditionGroup1
, A.ConditionGroup2
, A.Payer_credit_limit
, A.Payer_CreditBlock
, A.DZBNo
, A.VATRegistration
, A.Active
, A.TieringCode
, A.TieringName
, A.CreditSegmnt
, A.CheckRule
, A.LimitRule
, A.RiskClass
, A.TeamshopAccessFlag
, A.DunningLevel
, A.PKFAccessFlag
FROM etl.S4Hana_NatCustomers A
LEFT JOIN ref.NatCustomers B ON A.NatCustomer_BK = B.NatCustomer_BK
WHERE B.NatCustomer_BK IS NULL

--Log count of inserted records
UPDATE DTlogs SET 
  Inserted = @AffectedRows
, ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId