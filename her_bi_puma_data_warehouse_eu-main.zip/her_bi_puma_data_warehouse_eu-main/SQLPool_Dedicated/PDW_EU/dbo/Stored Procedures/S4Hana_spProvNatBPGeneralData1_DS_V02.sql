﻿CREATE PROC [dbo].[S4Hana_spProvNatBPGeneralData1_DS_V02] @LDTS [DATETIME2](7) AS

DECLARE @LoadDate DATETIME2(7) = GETDATE();

IF OBJECT_ID('tempdb..#NatBPGeneralData1') IS NOT NULL DROP TABLE #NatBPGeneralData1;

-- logging informations - BEGIN
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(0) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(0)
DECLARE @DestinationLastLoadDate DATETIME2(0)
DECLARE @BatchLdts DATETIME2(0) = @LDTS
DECLARE @AffectedRows BIGINT = NULL
-- logging Informations - END

-- get last LDTS Informations for Logging
IF(EXISTS(SELECT 1 FROM [ref].[NatBPGeneralData1_DS_V02]))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(ModifiedOn))
		FROM [ref].[NatBPGeneralData1_DS_V02]
	END
ELSE 
	BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

IF(EXISTS(SELECT 1 FROM biz.[S4Hana_BPGeneralData1]))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(LDTS))
		FROM biz.[S4Hana_BPGeneralData1]
	END
ELSE 
	BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END
-- Logging Informations END


-- Log first DATA Informations

INSERT INTO etl.DataTransferLogs
(
  DataTransferLogId
, TransferName
, TransferGroupName
, TargetTableName
, TargetSchemaName
, ExecStart
, SourceLastLoadDate
, DestinationLastLoadDate
, BatchLdts
)
SELECT 
  @DataTransferLogId 
, 'S4Hana_spProvNatBPGeneralData1_DS_V02'
, 'NatBPGeneralData1_DS_V02'
, 'NatBPGeneralData1_DS_V02'
, 'ref'
, @ExecStart
, @SourceLastLoadDate
, @DestinationLastLoadDate
, @BatchLdts;

-- Log first DATA Informations END

-- LegacyPartner aggregation - temp table
IF OBJECT_ID(N'tempdb..#LegacyPartner') IS NOT NULL
DROP TABLE #LegacyPartner;

WITH cte_LegacyPartner_LDTSDates AS
(
	SELECT
		[partner]
		,MAX([LDTS]) LDTS
	FROM biz.S4Hana_BPLegacyPartnerData
	GROUP BY
		[partner]
), cte_LegacyPartner AS
(
	SELECT DISTINCT
		[partner]
		,RTRIM(LegacyPartnerType , '0')	AS LegacyPartnerType
		,LTRIM(LTRIM(LegacyPartnerNumber , ''''), '0')	AS LegacyPartnerNumber
	FROM biz.S4Hana_BPLegacyPartnerData
	WHERE
		IsDeleted = 0
		AND LegacyPartnerType like '%0000'
)

SELECT 
	LPD1.[partner]
	,string_agg(concat(LPD1.LegacyPartnerType, ': ', LPD1.LegacyPartnerNumber),', ') 
			within group (order by LPD1.LegacyPartnerType, LPD1.LegacyPartnerNumber)   LegacyPartners
	,LPD_Dates.LDTS
INTO #LegacyPartner
FROM cte_LegacyPartner LPD1
	INNER JOIN cte_LegacyPartner_LDTSDates LPD_Dates
		ON LPD1.[partner] = LPD_Dates.[partner]
GROUP BY
	LPD1.[partner]
	,LPD_Dates.LDTS;



WITH CTE AS
(
	SELECT distinct /*distinct neccesary due to join [stag].[S4Hana_vCustomers_all] c2 on b.But051customer = c2.[Customer],
	but051customer needed for CustAccGroup,SalesOrg retrieval. One bp has multiple customers /WL 24012024*/
	   a.[BusinessPartner]
	  ,concat(a.[BusinessPartner], '|',d.CustomerAccountGroup, '|',d.ContactFunction) AS NatBPGeneralData1_BK
	  ,@LoadDate	AS CreatedOn
	  ,@LoadDate	AS ModifiedOn
	  ,d.[SalesOrganization]
	  ,d.CustomerAccountGroup
	  ,d.ContactFunction
	  ,a.[FirstNameBP] 
	  ,a.[LastNameBP]
	  ,a.[ILN1] 
	  ,a.[ILN2] 
	  ,a.[ILNchk] 
	  ,a.[SearchHelp1] 
	  ,a.[SearchHelp2] 
	  ,a.[BPCategory] 
	  ,a.[BPType] 
	  ,a.[BPGroup] 
	  ,a.[BPextSys] 
	  ,a.[BPSearch1] 
	  ,a.[BPSearch2] 
	  ,a.[FlagArchive] 
	  ,a.[BPCentralBlk] 
	  ,a.[Costtype] 
	  ,a.[NameOrg1] 
	  ,a.[NameOrg2] 
	  ,a.[NameOrg3] 
	  ,a.[NameOrg4] 
	  ,a.[Industry] 
	  ,a.[OrgFounded] 
	  ,a.[OrgLiquidt] 
	  ,a.[Occupation] 
	  ,a.[Nationality] 
	  ,a.[gender] 
	  ,a.[CreationDate] 
	  ,a.[ChangeDate] 
	  ,a.[ValidFrom] 
	  ,a.[Valid_to] 
	  ,NULL AS [but0idpartner] 
	  ,NULL AS [FRLegacyCustomer]
      ,NULL AS [FRLegacyVendor]
	  ,LEFT(lp.LegacyPartners,1000) as LegacyPartners
	  ,a.IsDeleted

FROM biz.[S4Hana_BPGeneralData1] a
left join biz.[S4Hana_CustomerBusinessPartner] b on a.[BusinessPartner] = b.But051partner
left join biz.[S4Hana_BPGeneralData1] c on a.[BusinessPartner] = c.[BusinessPartner]
left join [stag].[vCustomerAccountGroup_DS] d on a.[BusinessPartner] = d.[BusinessPartner]
left join #LegacyPartner lp on a.[BusinessPartner] = lp.[partner]
--inner join [pdwref].[AreaCodeMapping] acm on d.[SalesOrganization] = acm.SalesOrganization
	WHERE
	d.[SalesOrganization] is not null
	AND(A.LDTS >= @LDTS 
	OR B.LDTS >= @LDTS
	OR C.LDTS >= @LDTS
	OR D.CBP_LDTS >= @LDTS
	OR D.C_LDTS >= @LDTS		
	OR D.CSA_LDTS >= @LDTS
	OR LP.LDTS >= @LDTS)

)

--Insert to temp table
SELECT 
	   [BusinessPartner]
	  ,NatBPGeneralData1_BK
	  ,IsDeleted
	  ,CreatedOn
	  ,ModifiedOn
	  ,[SalesOrganization]
      ,CustomerAccountGroup
	  ,ContactFunction
	  ,[FirstNameBP] 
	  ,[LastNameBP]
	  ,[ILN1] 
	  ,[ILN2] 
	  ,[ILNchk] 
	  ,[SearchHelp1] 
	  ,[SearchHelp2] 
	  ,[BPCategory] 
	  ,[BPType] 
	  ,[BPGroup] 
	  ,[BPextSys] 
	  ,[BPSearch1] 
	  ,[BPSearch2] 
	  ,[FlagArchive] 
	  ,[BPCentralBlk] 
	  ,[Costtype] 
	  ,[NameOrg1] 
	  ,[NameOrg2] 
	  ,[NameOrg3] 
	  ,[NameOrg4] 
	  ,[Industry] 
	  ,[OrgFounded] 
	  ,[OrgLiquidt] 
	  ,[Occupation] 
	  ,[Nationality] 
	  ,[gender] 
	  ,[CreationDate] 
	  ,[ChangeDate] 
	  ,[ValidFrom] 
	  ,[Valid_to] 
	  ,[but0idpartner] 
	  ,[FRLegacyCustomer] 
	  ,[FRLegacyVendor]
	  ,[LegacyPartners]
	  ,CONVERT([BINARY](16), HASHBYTES('MD5',CONCAT(
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[BusinessPartner])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),NatBPGeneralData1_BK)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),IsDeleted)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SalesOrganization])))),'_',
        UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),CustomerAccountGroup)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),ContactFunction)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FirstNameBP] )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[LastNameBP])))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ILN1] )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ILN2] )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ILNchk] )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SearchHelp1] )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SearchHelp2] )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[BPCategory] )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[BPType] )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[BPGroup] )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[BPextSys] )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[BPSearch1] )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[BPSearch2] )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FlagArchive] )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[BPCentralBlk] )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Costtype] )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[NameOrg1] )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[NameOrg2] )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[NameOrg3] )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[NameOrg4] )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Industry] )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[OrgFounded] )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[OrgLiquidt] )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Occupation] )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Nationality] )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[gender] )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CreationDate] )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ChangeDate] )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ValidFrom] )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Valid_to] )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[but0idpartner] )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FRLegacyCustomer] )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FRLegacyVendor])))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](1000),[LegacyPartners]))))
	))) AS HashDiff
	
INTO #NatBPGeneralData1
FROM CTE

--Count Records to be updated
SELECT @AffectedRows = COUNT(*)
FROM [ref].[NatBPGeneralData1_DS_V02] A
INNER JOIN #NatBPGeneralData1 B ON A.NatBPGeneralData1_BK = B.NatBPGeneralData1_BK
WHERE A.HashDiff <> B.HashDiff

--Update Final Table
UPDATE A SET
  A.ModifiedOn = @LoadDate
 ,A.IsDeleted            =B.IsDeleted           
 ,A.[SalesOrganization]	 =B.[SalesOrganization]			
 ,A.CustomerAccountGroup =B.CustomerAccountGroup
 ,A.ContactFunction		 =B.ContactFunction		
 ,A.[FirstNameBP] 		 =B.[FirstNameBP] 		
 ,A.[LastNameBP]		 =B.[LastNameBP]		
 ,A.[ILN1] 				 =B.[ILN1] 				
 ,A.[ILN2] 				 =B.[ILN2] 				
 ,A.[ILNchk] 			 =B.[ILNchk] 			
 ,A.[SearchHelp1] 		 =B.[SearchHelp1] 		
 ,A.[SearchHelp2] 		 =B.[SearchHelp2] 		
 ,A.[BPCategory] 		 =B.[BPCategory] 		
 ,A.[BPType] 			 =B.[BPType] 			
 ,A.[BPGroup] 			 =B.[BPGroup] 			
 ,A.[BPextSys] 			 =B.[BPextSys] 			
 ,A.[BPSearch1] 		 =B.[BPSearch1] 		
 ,A.[BPSearch2] 		 =B.[BPSearch2] 		
 ,A.[FlagArchive] 		 =B.[FlagArchive] 		
 ,A.[BPCentralBlk] 		 =B.[BPCentralBlk] 		
 ,A.[Costtype] 			 =B.[Costtype] 			
 ,A.[NameOrg1] 			 =B.[NameOrg1] 			
 ,A.[NameOrg2] 			 =B.[NameOrg2] 			
 ,A.[NameOrg3] 			 =B.[NameOrg3] 			
 ,A.[NameOrg4] 			 =B.[NameOrg4] 			
 ,A.[Industry] 			 =B.[Industry] 			
 ,A.[OrgFounded] 		 =B.[OrgFounded] 		
 ,A.[OrgLiquidt] 		 =B.[OrgLiquidt] 		
 ,A.[Occupation] 		 =B.[Occupation] 		
 ,A.[Nationality] 		 =B.[Nationality] 		
 ,A.[gender] 			 =B.[gender] 			
 ,A.[CreationDate] 		 =B.[CreationDate] 		
 ,A.[ChangeDate] 		 =B.[ChangeDate] 		
 ,A.[ValidFrom] 		 =B.[ValidFrom] 		
 ,A.[Valid_to] 			 =B.[Valid_to] 			
 ,A.[but0idpartner] 	 =B.[but0idpartner] 	
 ,A.[FRLegacyVendor] 	 =B.[FRLegacyVendor] 	
 ,A.[FRLegacyCustomer]	 =B.[FRLegacyCustomer]
 ,A.[LegacyPartners]	 =B.[LegacyPartners]
 ,A.HashDiff			 =B.HashDiff

FROM [ref].[NatBPGeneralData1_DS_V02] A
INNER JOIN #NatBPGeneralData1 B ON A.NatBPGeneralData1_BK = B.NatBPGeneralData1_BK
WHERE A.HashDiff <> B.HashDiff and B.IsDeleted = 0

--update deletion status
UPDATE A SET
	   A.ModifiedOn = @LoadDate
	  ,A.IsDeleted = 1
	  ,A.HashDiff  = B.HashDiff

FROM [ref].[NatBPGeneralData1_DS_V02] A
INNER JOIN #NatBPGeneralData1 B ON A.NatBPGeneralData1_BK = B.NatBPGeneralData1_BK
WHERE A.HashDiff <> B.HashDiff and B.IsDeleted = 1

--Log count of updated records
UPDATE DTlogs SET
  Updated = @AffectedRows
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

--Count Records to be inserted
SELECT @AffectedRows = COUNT(*)
FROM #NatBPGeneralData1 A
LEFT JOIN [ref].[NatBPGeneralData1_DS_V02] B ON A.NatBPGeneralData1_BK = B.NatBPGeneralData1_BK
WHERE B.NatBPGeneralData1_BK IS NULL

--Insert to Final Table
INSERT INTO [ref].[NatBPGeneralData1_DS_V02]
(
      [BusinessPartner]
	 ,NatBPGeneralData1_BK
     ,IsDeleted
     ,CreatedOn
     ,ModifiedOn
     ,[SalesOrganization]
     ,CustomerAccountGroup
     ,ContactFunction
     ,[FirstNameBP] 
     ,[LastNameBP]
     ,[ILN1] 
     ,[ILN2] 
     ,[ILNchk] 
     ,[SearchHelp1] 
     ,[SearchHelp2] 
     ,[BPCategory] 
     ,[BPType] 
     ,[BPGroup] 
     ,[BPextSys] 
     ,[BPSearch1] 
     ,[BPSearch2] 
     ,[FlagArchive] 
	 ,[BPCentralBlk] 
	 ,[Costtype] 
	 ,[NameOrg1] 
	 ,[NameOrg2] 
	 ,[NameOrg3] 
	 ,[NameOrg4] 
	 ,[Industry] 
	 ,[OrgFounded] 
	 ,[OrgLiquidt] 
	 ,[Occupation] 
	 ,[Nationality] 
	 ,[gender] 
	 ,[CreationDate] 
	 ,[ChangeDate] 
	 ,[ValidFrom] 
	 ,[Valid_to] 
	 ,[but0idpartner] 
	 ,[FRLegacyCustomer] 
	 ,[FRLegacyVendor]
	 ,[LegacyPartners]
	 ,Hashdiff
	  )
SELECT
	  A.[BusinessPartner]
	 ,A.NatBPGeneralData1_BK
     ,A.IsDeleted
     ,A.CreatedOn
     ,A.ModifiedOn
     ,A.[SalesOrganization]
     ,A.CustomerAccountGroup
     ,A.ContactFunction
     ,A.[FirstNameBP] 
     ,A.[LastNameBP]
     ,A.[ILN1] 
     ,A.[ILN2] 
     ,A.[ILNchk] 
     ,A.[SearchHelp1] 
     ,A.[SearchHelp2] 
     ,A.[BPCategory] 
     ,A.[BPType] 
     ,A.[BPGroup] 
     ,A.[BPextSys] 
     ,A.[BPSearch1] 
     ,A.[BPSearch2] 
     ,A.[FlagArchive] 
	 ,A.[BPCentralBlk] 
	 ,A.[Costtype] 
	 ,A.[NameOrg1] 
	 ,A.[NameOrg2] 
	 ,A.[NameOrg3] 
	 ,A.[NameOrg4] 
	 ,A.[Industry] 
	 ,A.[OrgFounded] 
	 ,A.[OrgLiquidt] 
	 ,A.[Occupation] 
	 ,A.[Nationality] 
	 ,A.[gender] 
	 ,A.[CreationDate] 
	 ,A.[ChangeDate] 
	 ,A.[ValidFrom] 
	 ,A.[Valid_to] 
	 ,A.[but0idpartner] 
	 ,A.[FRLegacyCustomer] 
	 ,A.[FRLegacyVendor]
	 ,A.[LegacyPartners]
	 ,A.Hashdiff

FROM #NatBPGeneralData1 A
LEFT JOIN [ref].[NatBPGeneralData1_DS_V02] B ON A.NatBPGeneralData1_BK = B.NatBPGeneralData1_BK
WHERE B.NatBPGeneralData1_BK IS NULL

--Log count of inserted records
UPDATE DTlogs SET 
  Inserted = @AffectedRows
, ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId