﻿CREATE PROC [dbo].[S4Hana_spProvNatMaterialSalesAttributes_DS_V02] @LDTS [DATETIME2](7) AS

DECLARE @LoadDate DATETIME2(7) = GETDATE();

IF OBJECT_ID('tempdb..#NatMaterialSalesAttributes') IS NOT NULL DROP TABLE #NatMaterialSalesAttributes;

-- logging informations - BEGIN
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(0) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(0)
DECLARE @DestinationLastLoadDate DATETIME2(0)
DECLARE @BatchLdts DATETIME2(0) = @LDTS
DECLARE @AffectedRows BIGINT = NULL
-- logging Informations - END

-- get last LDTS Informations for Logging
IF(EXISTS(SELECT 1 FROM [ref].[NatMaterialSalesAttributes_DS_V02]))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(ModifiedOn))
		FROM [ref].[NatMaterialSalesAttributes_DS_V02]
	END
ELSE 
	BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

IF(EXISTS(SELECT 1 FROM biz.[S4Hana_MaterialSalesAttributes]))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(LDTS))
		FROM biz.[S4Hana_MaterialSalesAttributes]
	END
ELSE 
	BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END
-- Logging Informations END


-- Log first DATA Informations

INSERT INTO etl.DataTransferLogs
(
  DataTransferLogId
, TransferName
, TransferGroupName
, TargetTableName
, TargetSchemaName
, ExecStart
, SourceLastLoadDate
, DestinationLastLoadDate
, BatchLdts
)
SELECT 
  @DataTransferLogId 
, 'S4Hana_spProvNatMaterialSalesAttributes_DS_V02'
, 'NatMaterialSalesAttributes_DS_V02'
, 'NatMaterialSalesAttributes_DS_V02'
, 'ref'
, @ExecStart
, @SourceLastLoadDate
, @DestinationLastLoadDate
, @BatchLdts;

-- Log first DATA Informations END
WITH CTE AS
(
  SELECT
  CONCAT(A.[Product], '|', A.[ProductSalesOrg], '|', A.[ProductDistributionChnl], '|',B.MaterialCategory) AS NatMaterialSalesAttributes_BK
  ,@LoadDate	AS CreatedOn
  ,@LoadDate	AS ModifiedOn
  ,a.Product
  ,a.ProductSalesOrg as [SalesOrganization]
  ,a.ProductDistributionChnl
  ,b.MaterialCategory
  ,a.SupplyingPlant
  ,a.DeliveryQuantityUnit
  ,a.DeliveryQuantity
  ,a.ProductSalesStatus
  ,a.ProductSalesStatusValidityDate
  ,a.IsMarkedForDeletion
  ,a.IsActiveEntity
  ,a.ArticleLaunchDate
  ,a.ArticleLaunchFlag
  ,a.ArticlePricingFlag
  ,a.OutletBFOSeason
  ,a.QuarterInfo
  ,a.Theme
  ,a.FirstAssortment
  ,a.LatestAssortment
  ,a.LocalDC
  ,a.Exclusivity
  ,a.CoreSelection
  ,a.SalesPack
  ,a.IsDeleted
  ,(CONVERT(BIGINT, DATEDIFF(sECOND,'1970-01-01', @LoadDate)) * 1000000)  +  DATEPART(MCS,@LoadDate) as modifiedOn_UTC_epoch

FROM
  biz.[S4Hana_MaterialSalesAttributes] a
  left join biz.[S4Hana_Materials] b on a.Product=b.Material
  --inner join [pdwref].[AreaCodeMapping] ACM on a.ProductSalesOrg=ACM.[SalesOrganization]
  WHERE
	A.LDTS >= @LDTS 
	OR B.LDTS >= @LDTS

)

--Insert to temp table
SELECT 
	    NatMaterialSalesAttributes_BK
	   ,CreatedOn
	   ,ModifiedOn
	   ,Product
	   ,[SalesOrganization]
	   ,ProductDistributionChnl
	   ,MaterialCategory
	   ,SupplyingPlant
	   ,DeliveryQuantityUnit
	   ,DeliveryQuantity
	   ,ProductSalesStatus
	   ,ProductSalesStatusValidityDate
	   ,IsMarkedForDeletion
	   ,IsActiveEntity
	   ,ArticleLaunchDate
	   ,ArticleLaunchFlag
	   ,ArticlePricingFlag
	   ,OutletBFOSeason
	   ,QuarterInfo
	   ,Theme
	   ,FirstAssortment
	   ,LatestAssortment
	   ,LocalDC
	   ,Exclusivity
	   ,CoreSelection
	   ,SalesPack
	   ,IsDeleted
	   ,modifiedOn_UTC_epoch
	   ,CONVERT([BINARY](16), HASHBYTES('MD5',CONCAT(                 
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),NatMaterialSalesAttributes_BK   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),Product						 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SalesOrganization]				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),ProductDistributionChnl		 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),MaterialCategory				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),SupplyingPlant				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),DeliveryQuantityUnit			 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),DeliveryQuantity				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),ProductSalesStatus			 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),ProductSalesStatusValidityDate )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),IsMarkedForDeletion			 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),IsActiveEntity				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),ArticleLaunchDate				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),ArticleLaunchFlag				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),ArticlePricingFlag			 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),OutletBFOSeason				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),QuarterInfo					 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),Theme							 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),FirstAssortment				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),LatestAssortment				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),LocalDC						 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),Exclusivity					 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),CoreSelection					 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),SalesPack						 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),IsDeleted))))))) AS HashDiff
	
INTO #NatMaterialSalesAttributes
FROM CTE

--Count Records to be updated
SELECT @AffectedRows = COUNT(*)
FROM [ref].[NatMaterialSalesAttributes_DS_V02] A
INNER JOIN #NatMaterialSalesAttributes B ON A.NatMaterialSalesAttributes_BK = B.NatMaterialSalesAttributes_BK
WHERE A.HashDiff <> B.HashDiff

--Update Final Table 
UPDATE A SET
	   A.ModifiedOn = @LoadDate
	  ,A.modifiedOn_UTC_epoch = (CONVERT(BIGINT, DATEDIFF(SECOND,'1970-01-01', @LoadDate)) * 1000000)  +  DATEPART(MCS,@LoadDate)
	  ,A.Product                              = B.Product                              
	  ,A.IsDeleted							  = 0
	  ,A.[SalesOrganization]				  = B.[SalesOrganization]
	  ,A.ProductDistributionChnl			  = B.ProductDistributionChnl
	  ,A.MaterialCategory					  = B.MaterialCategory
	  ,A.SupplyingPlant						  = B.SupplyingPlant
	  ,A.DeliveryQuantityUnit				  = B.DeliveryQuantityUnit
	  ,A.DeliveryQuantity					  = B.DeliveryQuantity
	  ,A.ProductSalesStatus					  = B.ProductSalesStatus
	  ,A.ProductSalesStatusValidityDate		  = B.ProductSalesStatusValidityDate
	  ,A.IsMarkedForDeletion				  = B.IsMarkedForDeletion
	  ,A.IsActiveEntity						  = B.IsActiveEntity
	  ,A.ArticleLaunchDate					  = B.ArticleLaunchDate
	  ,A.ArticleLaunchFlag					  = B.ArticleLaunchFlag
	  ,A.ArticlePricingFlag					  = B.ArticlePricingFlag
	  ,A.OutletBFOSeason					  = B.OutletBFOSeason
	  ,A.QuarterInfo						  = B.QuarterInfo
	  ,A.Theme								  = B.Theme
	  ,A.FirstAssortment					  = B.FirstAssortment
	  ,A.LatestAssortment					  = B.LatestAssortment
	  ,A.LocalDC							  = B.LocalDC
	  ,A.Exclusivity						  = B.Exclusivity
	  ,A.CoreSelection						  = B.CoreSelection
	  ,A.SalesPack							  = B.SalesPack
	  ,A.HashDiff							  = B.HashDiff

FROM [ref].[NatMaterialSalesAttributes_DS_V02] A
INNER JOIN #NatMaterialSalesAttributes B ON A.NatMaterialSalesAttributes_BK = B.NatMaterialSalesAttributes_BK
WHERE A.HashDiff <> B.HashDiff and B.IsDeleted = 0

--update deletion status
UPDATE A SET
	   A.ModifiedOn = @LoadDate
	  ,A.modifiedOn_UTC_epoch = (CONVERT(BIGINT, DATEDIFF(SECOND,'1970-01-01', @LoadDate)) * 1000000)  +  DATEPART(MCS,@LoadDate)
	  ,A.IsDeleted = 1
	  ,A.HashDiff  = B.HashDiff

FROM [ref].[NatMaterialSalesAttributes_DS_V02] A
INNER JOIN #NatMaterialSalesAttributes B ON A.NatMaterialSalesAttributes_BK = B.NatMaterialSalesAttributes_BK
WHERE A.HashDiff <> B.HashDiff and B.IsDeleted = 1

--Log count of updated records
UPDATE DTlogs SET
  Updated = @AffectedRows
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

--Count Records to be inserted
SELECT @AffectedRows = COUNT(*)
FROM #NatMaterialSalesAttributes A
LEFT JOIN [ref].[NatMaterialSalesAttributes_DS_V02] B ON A.NatMaterialSalesAttributes_BK = B.NatMaterialSalesAttributes_BK
WHERE B.NatMaterialSalesAttributes_BK IS NULL

--Insert to Final Table
INSERT INTO [ref].[NatMaterialSalesAttributes_DS_V02]
(
       NatMaterialSalesAttributes_BK
	  ,CreatedOn
	  ,ModifiedOn
	  ,Product
	  ,[SalesOrganization]
	  ,ProductDistributionChnl
	  ,MaterialCategory
	  ,SupplyingPlant
	  ,DeliveryQuantityUnit
	  ,DeliveryQuantity
	  ,ProductSalesStatus
	  ,ProductSalesStatusValidityDate
	  ,IsMarkedForDeletion
	  ,IsActiveEntity
	  ,ArticleLaunchDate
	  ,ArticleLaunchFlag
	  ,ArticlePricingFlag
	  ,OutletBFOSeason
	  ,QuarterInfo
	  ,Theme
	  ,FirstAssortment
	  ,LatestAssortment
	  ,LocalDC
	  ,Exclusivity
	  ,CoreSelection
	  ,SalesPack
	  ,IsDeleted
	  ,Hashdiff
	  ,modifiedOn_UTC_epoch
	  )
SELECT
	   A.NatMaterialSalesAttributes_BK
	  ,A.CreatedOn
	  ,A.ModifiedOn
	  ,A.Product
	  ,A.[SalesOrganization]
	  ,A.ProductDistributionChnl
	  ,A.MaterialCategory
	  ,A.SupplyingPlant
	  ,A.DeliveryQuantityUnit
	  ,A.DeliveryQuantity
	  ,A.ProductSalesStatus
	  ,A.ProductSalesStatusValidityDate
	  ,A.IsMarkedForDeletion
	  ,A.IsActiveEntity
	  ,A.ArticleLaunchDate
	  ,A.ArticleLaunchFlag
	  ,A.ArticlePricingFlag
	  ,A.OutletBFOSeason
	  ,A.QuarterInfo
	  ,A.Theme
	  ,A.FirstAssortment
	  ,A.LatestAssortment
	  ,A.LocalDC
	  ,A.Exclusivity
	  ,A.CoreSelection
	  ,A.SalesPack
	  ,A.IsDeleted
	  ,A.Hashdiff
	  ,A.modifiedOn_UTC_epoch


FROM #NatMaterialSalesAttributes A
LEFT JOIN [ref].[NatMaterialSalesAttributes_DS_V02] B ON A.NatMaterialSalesAttributes_BK = B.NatMaterialSalesAttributes_BK
WHERE B.NatMaterialSalesAttributes_BK IS NULL

--Log count of inserted records
UPDATE DTlogs SET 
  Inserted = @AffectedRows
, ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId