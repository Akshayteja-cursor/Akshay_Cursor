﻿CREATE PROC [dbo].[S4Hana_spProvNatActiclesLast] @LDTS [DATETIME2](7) AS

DECLARE @LoadDate DATETIME2(7) = GETDATE();

IF OBJECT_ID('tempdb..#MaterialSalesAttributes') IS NOT NULL DROP TABLE #MaterialSalesAttributes;
IF OBJECT_ID('tempdb..#Pre_MaterialHierarchy') IS NOT NULL DROP TABLE #Pre_MaterialHierarchy;
IF OBJECT_ID('tempdb..#Pre_MaterialHierarchyTexts') IS NOT NULL DROP TABLE #Pre_MaterialHierarchyTexts;
IF OBJECT_ID('tempdb..#MaterialHierarchy') IS NOT NULL DROP TABLE #MaterialHierarchy;
IF OBJECT_ID('tempdb..#MaterialPricesDCs') IS NOT NULL DROP TABLE #MaterialPricesDCs;
IF OBJECT_ID('tempdb..#MaterialPricesStores') IS NOT NULL DROP TABLE #MaterialPricesStores;
IF OBJECT_ID('tempdb..#Materials') IS NOT NULL DROP TABLE #Materials;
IF OBJECT_ID('tempdb..#PlantMaterialMaster') IS NOT NULL DROP TABLE #PlantMaterialMaster;
IF OBJECT_ID('tempdb..#NatArticles') IS NOT NULL DROP TABLE #NatArticles;
IF OBJECT_ID('tempdb..#BrutPrice') IS NOT NULL DROP TABLE #BrutPrice;
IF OBJECT_ID('tempdb..#InStoreDatesLocal') IS NOT NULL DROP TABLE #InStoreDatesLocal;
IF OBJECT_ID('tempdb..#InStoreDatesGlobal') IS NOT NULL DROP TABLE #InStoreDatesGlobal;

-- logging informations - BEGIN
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(0) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(0)
DECLARE @DestinationLastLoadDate DATETIME2(0)
DECLARE @BatchLdts DATETIME2(0) = @LDTS
DECLARE @AffectedRows BIGINT = NULL
-- logging Informations - END

-- get last LDTS Informations for Logging
IF(EXISTS(SELECT 1 FROM ref.NatArticles))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(modifiedOn))
		FROM ref.NatArticles
	END
ELSE 
	BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

IF(EXISTS(SELECT 1 FROM ref.NatArticles))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(modifiedOn))
		FROM ref.NatArticles
	END
ELSE 
	BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END
-- Logging Informations END


-- Log first DATA Informations

INSERT INTO etl.DataTransferLogs
(
  DataTransferLogId
, TransferName
, TransferGroupName
, TargetTableName
, TargetSchemaName
, ExecStart
, SourceLastLoadDate
, DestinationLastLoadDate
, BatchLdts
)
SELECT 
  @DataTransferLogId 
, 'S4Hana_spProvNatActiclesLast'
, 'NatArticles'
, 'NatArticles'
, 'ref'
, @ExecStart
, @SourceLastLoadDate
, @DestinationLastLoadDate
, @BatchLdts;

-- Log first DATA Informations END

--MaterialSalesAttributes
SELECT
  MaterialNumber													AS MaterialNumber
, MIN(SalesOrgCode)													AS SalesOrgCode
, MAX(LDTS)															AS LDTS
, MIN(CompanyCode)													AS CompanyCode --Minimum SalesOrg and CompanyCode to get one Iberia-Country only
, IntPupMasterId													AS IntPupMasterId
, PDUCode															AS PDUCode
, MAX(CASE WHEN RN = 1 THEN Theme END)								AS Theme_1 -- rows for SE and PEG (6000)
, MAX(CASE WHEN RN = 2 THEN Theme END)								AS Theme_2 -- rows only for PEG (6000)
, MAX(CASE WHEN RN = 3 THEN Theme END)								AS Theme_3 -- rows only for PEG (6000)
, MAX(CASE WHEN RN = 1 THEN OutletBFOSeason END)					AS OutletBFOSeason_1 --nothing filled
, MAX(CASE WHEN RN = 1 THEN ProductSalesStatusCode END)				AS ProductSalesStatusCode_1 -- many rows for SE and dummy org XX99
, CAST(MAX(CASE WHEN RN = 1 THEN ArticleLaunchDate END) AS DATE)	AS ArticleLaunchDate_1 -- rows for SE only
, MAX(CASE WHEN RN = 1 THEN FirstAssortment END)					AS FirstAssortment_1 -- rows for SE only
, MAX(CASE WHEN RN = 1 THEN LatestAssortment END)					AS LatestAssortment_1 -- rows for SE only
, MAX(CASE WHEN RN = 1 THEN LocalDC END)							AS LocalDC_1 -- rows for SE only
, MAX(CASE WHEN RN = 1 THEN Exclusivity END)						AS Exclusivity
, MAX(CASE WHEN RN = 1 THEN Specialist1 END)						AS Specialist1
, MAX(CASE WHEN RN = 1 THEN Specialist2 END)						AS Specialist2
, MAX(CASE WHEN RN = 1 THEN Specialist3 END)						AS Specialist3
, MAX(CASE WHEN RN = 1 THEN Specialist4 END)						AS Specialist4
, MAX(CASE WHEN RN = 1 THEN Specialist5 END)						AS Specialist5
, MAX(CASE WHEN RN = 1 THEN Specialist6 END)						AS Specialist6
, MAX(CASE WHEN RN = 1 THEN Specialist7 END)						AS Specialist7
, MAX(CASE WHEN RN = 1 THEN Specialist8 END)						AS Specialist8
, MAX(CASE WHEN RN = 1 THEN NeveroutofStock END)					AS NeveroutofStock
, MAX(CASE WHEN RN = 1 THEN ProductStatus END)						AS ProductStatus
, MAX(CASE WHEN RN = 1 THEN ProductLifecycle END)					AS ProductLifecycle
, MAX(CASE WHEN RN = 1 THEN Embargo END)							AS Embargo
, MAX(CASE WHEN RN = 1 THEN ProductFamily END)						AS ProductFamily
, MAX(CASE WHEN RN = 1 THEN ProductSubFamily END)					AS ProductSubFamily
, MAX(CASE WHEN RN = 1 THEN AssortmentCategory1 END)				AS AssortmentCategory1
, MAX(CASE WHEN RN = 1 THEN AssortmentCategory2 END)				AS AssortmentCategory2
, MAX(CASE WHEN RN = 1 THEN ArticleLaunchFlag END)				    AS ArticleLaunchFlag
, MAX(CASE WHEN RN = 1 THEN KeyInitiative END)						AS KeyInitiative
, MAX(CASE WHEN RN = 1 THEN QuarterInfo END)						AS QuarterInfo
INTO #MaterialSalesAttributes
FROM
(
SELECT 
  A.MaterialNumber
, A.SalesOrgCode
, A.DistChannelCode
, A.Theme
, A.OutletBFOSeason
, A.ProductSalesStatusCode
, A.ArticleLaunchDate
, A.FirstAssortment
, A.LatestAssortment
, A.LocalDC
, A.Exclusivity
, A.Specialist1
, A.Specialist2
, A.Specialist3
, A.Specialist4
, A.Specialist5
, A.Specialist6
, A.Specialist7
, A.Specialist8
, A.NeveroutofStock
, A.ProductStatus
, A.ProductLifecycle
, A.Embargo
, A.ProductFamily
, A.ProductSubFamily
, A.AssortmentCategory1
, A.AssortmentCategory2
, A.ArticleLaunchFlag
, A.KeyInitiative
, A.QuarterInfo
, A.LDTS
--, CASE WHEN C.CompanyCode = 'PT10' THEN 'ES10' ELSE C.CompanyCode END CompanyCode --Same logic as MIN(CompanyCode) above
, C.CompanyCode
, C.IntPupMasterId
, C.PDUCode
, ROW_NUMBER() OVER (PARTITION BY A.MaterialNumber
								, A.SalesOrgCode
					 ORDER BY CASE WHEN A.DistChannelCode= '40'
					 THEN '00'
					 ELSE A.DistChannelCode END)				AS RN
FROM stag.S4Hana_vMaterialSalesAttributes A
INNER JOIN stag.S4Hana_vSalesOrgToCompanyCode B ON A.SalesOrgCode = B.Code
INNER JOIN pdwref.S4Hana_Interfaces C ON B.CompanyCode = C.CompanyCode
/*where A.DistChannelCode >= 40 -- updated logic to get the DistChanl = Wholesale **** Added by Reza*/
) X
GROUP BY MaterialNumber
	   , IntPupMasterId
	   , PDUCode;

/*Calculating Brut Price and RRP*/
SELECT MaterialNumber	,SalesOrganisation	,ZVP1	,ZPR0 INTO #BrutPrice
FROM
(SELECT
  MaterialNumber 
, ConditionType	
, whprice
, SalesOrganisation
FROM [stag].[S4Hana_vWSPriceMaster977]
) aa 
Pivot (
MAX(aa.whprice) FOR ConditionType in ([ZVP1], [ZPR0])
) AS pvt
;


--MaterialHierarchy
SELECT * INTO #Pre_MaterialHierarchy FROM stag.S4Hana_vMaterialsHierarchy
SELECT * INTO #Pre_MaterialHierarchyTexts FROM stag.S4Hana_vMaterialsHierarchyTexts

CREATE TABLE #MaterialHierarchy
WITH
(
  DISTRIBUTION = HASH(MaterialNumber)
, CLUSTERED INDEX (MaterialNumber ASC)
)
AS
SELECT 
  A.MaterialNumber
, A.LDTS
, A1.NodeDescription AS NatSubClass
, B1.NodeDescription AS NatClass
, C1.NodeDescription AS NatBusUnit
, D1.NodeDescription AS NatProdDiv
, E1.NodeDescription AS NatGender
, F1.NodeDescription AS NatBrand
FROM #Pre_MaterialHierarchy A
INNER JOIN #Pre_MaterialHierarchyTexts A1 ON A.HierarchyNode = A1.HierarchyNode
	AND A.[HierarchyID] = A1.[HierarchyID]
INNER JOIN #Pre_MaterialHierarchy B ON A.ParentNode = B.HierarchyNode 
	AND A.[HierarchyId] = B.[HierarchyId]
INNER JOIN #Pre_MaterialHierarchyTexts B1 ON B.HierarchyNode = B1.HierarchyNode
	AND B.[HierarchyID] = B1.[HierarchyID]
INNER JOIN #Pre_MaterialHierarchy C ON B.ParentNode = C.HierarchyNode
	AND B.[HierarchyId] = C.[HierarchyId]
INNER JOIN #Pre_MaterialHierarchyTexts C1 ON C.HierarchyNode = C1.HierarchyNode
	AND C.[HierarchyID] = C1.[HierarchyID]
INNER JOIN #Pre_MaterialHierarchy D ON C.ParentNode = D.HierarchyNode
	AND C.[HierarchyId] = D.[HierarchyId]
INNER JOIN #Pre_MaterialHierarchyTexts D1 ON D.HierarchyNode = D1.HierarchyNode
	AND D.[HierarchyID] = D1.[HierarchyID]
INNER JOIN #Pre_MaterialHierarchy E ON D.ParentNode = E.HierarchyNode
	AND D.[HierarchyId] = E.[HierarchyId]
INNER JOIN #Pre_MaterialHierarchyTexts E1 ON E.HierarchyNode = E1.HierarchyNode
	AND E.[HierarchyID] = E1.[HierarchyID]
INNER JOIN #Pre_MaterialHierarchy F ON E.ParentNode = F.HierarchyNode
	AND E.[HierarchyId] = F.[HierarchyId]
INNER JOIN #Pre_MaterialHierarchyTexts F1 ON F.HierarchyNode = F1.HierarchyNode
	AND F.[HierarchyID] = F1.[HierarchyID]
WHERE LEN(A.MaterialNumber) > 0
	AND A.ValidityEndDate = '9999-12-31'


--MaterialPricesDCs
SELECT 
  A.Material																AS MaterialNumber
, A.PriceCurrency															AS CurrencyCode
, MAX(CASE WHEN A.PriceControlIndicator = 'V' THEN A.MovingAveragePrice 
		   ELSE A.StandardPrice 
	  END)																	AS MaterialPrice
INTO #MaterialPricesDCs
FROM biz.S4Hana_AggMaterialStockPricesCurrent A
INNER JOIN stag.S4Hana_vPlants B ON A.Plant = B.StoreCode
INNER JOIN stag.S4Hana_vSalesOrgToCompanyCode C ON B.SalesOrganizationCode = C.Code
INNER JOIN pdwref.S4Hana_Interfaces D ON C.CompanyCode = D.CompanyCode
WHERE B.PlantCategoryCode = 'B'
	AND A.PriceCurrency = 'EUR'
	--AND Material = '021965-02-120'
GROUP BY Material
	   , PriceCurrency


--MaterialPricesStores
SELECT 
  A.Material																AS MaterialNumber
, A.PriceCurrency															AS CurrencyCode
, MAX(CASE WHEN A.PriceControlIndicator = 'V' THEN A.MovingAveragePrice 
		   ELSE A.StandardPrice 
	  END)																	AS MaterialPrice
INTO #MaterialPricesStores
FROM biz.S4Hana_AggMaterialStockPricesCurrent A
INNER JOIN stag.S4Hana_vPlants B ON A.Plant = B.StoreCode
INNER JOIN stag.S4Hana_vSalesOrgToCompanyCode C ON B.SalesOrganizationCode = C.Code
INNER JOIN pdwref.S4Hana_Interfaces D ON C.CompanyCode = D.CompanyCode
WHERE B.PlantCategoryCode = 'A'
	AND A.PriceCurrency = 'EUR'
	--AND Material = '021965-02-120'
GROUP BY Material
	   , PriceCurrency


--Materials
SELECT
  MaterialNumber
, StyleNo
, StyleNo+ '-' + ColorNo as GenericMaterial
, ColorNo
, ColorDesc
, EAN
, SizeScaleCode
, SizeCode
, SizeNumber
, MaterialSite
, DistributionChannel
, BrandCode
, GenderCode
, IntDistChanCode
, DCSClassCode
, DCSSubClassCode
, RetailDCSDepCode
, ProdDivCode
, BusSegCode
, BusSubSegCode
, RBUCode
, OutletTheme
, FPeComTheme
, PIDFlag
, FirstPIDSeason
, LastPIDSeason
, ArtTypeCode
, AgeGrpCode
, LineName
, LDTS
INTO #Materials
FROM stag.S4Hana_vMaterials
WHERE LEN(ISNULL(EAN, '')) > 0 --EAN IS NOT NULL AND EAN <> ''
	/***********Filter-out bad data qualitity***************/
	AND BrandCode <> 'PUMA' 
	--AND A.MaterialNumber = '021965-02-120'

--PlantMaterialMaster
--SELECT 
--  MaterialNumber
--, MAX(LDTS)			AS LDTS
--, MAX(ProfileCode)	AS SiteMaterialStatus
--, MAX(TargetStock)  AS TargetStock
--, MAX(ReorderPoint) AS ReorderPoint
--INTO #PlantMaterialMaster
--FROM stag.S4Hana_vPlantMaterialMaster
--GROUP BY MaterialNumber
;
WITH cte_plant AS (
SELECT 
  MaterialNumber
, LDTS
, ProfileCode AS SiteMaterialStatus
, TargetStock
, ReorderPoint
, CompanyCode
, ROW_NUMBER() OVER (PARTITION BY MaterialNumber , CompanyCode
					 ORDER BY LDTS DESC)				AS RN
FROM stag.S4Hana_vPlantMaterialMaster
)
SELECT 
 MaterialNumber
,LDTS
,SiteMaterialStatus
,TargetStock
,ReorderPoint
,CompanyCode
INTO #PlantMaterialMaster
FROM cte_Plant
WHERE rn = 1

--InStoreDatesLocal
SELECT
	NatArticleNo
	,CompanyCode
	,IsdFrom
	,IsdTo
	,LDTS
INTO #InStoreDatesLocal
FROM (
	SELECT 
		CONCAT(Style, '-', Color)		AS NatArticleNo
		,IsdFrom
		,IsdTo
		,LDTS
		,CASE	WHEN Forecastunit =	'AreITALY'	THEN 'IT10'
				WHEN Forecastunit =	'AreFRANCE'	THEN 'FR10'
				WHEN Forecastunit =	'AreIBERIA'	THEN 'ES10'
				WHEN Forecastunit =	'AreDACH'	THEN 'DE19'
			END CompanyCode
		,ROW_NUMBER() OVER (PARTITION BY CONCAT(Style, '-', Color), Forecastunit ORDER BY SeasonYear DESC, SeasonCategory DESC) RN
	FROM [stag].[S4Hana_vInstoreDatesLocal]
	WHERE 
		IsDeleted = 0
		AND Color <> ''
		AND Forecastunit IN	('AreITALY'
							,'AreFRANCE'
							,'AreIBERIA'
							,'AreDACH')
	) A
WHERE RN = 1

--InStoreDatesGlobal
SELECT
	Brand
	,ProductDiv
	,Linenamecode
	,BusiSeg
	,IsdFrom
	,IsdTo
	,LDTS
INTO #InStoreDatesGlobal
FROM (
	SELECT 
		Brand
		,ProductDiv
		,Linenamecode
		,BusiSeg
		,IsdFrom
		,IsdTo
		,LDTS
		,ROW_NUMBER() OVER (PARTITION BY Brand,ProductDiv,Linenamecode,BusiSeg ORDER BY SeasonYear DESC, SeasonCategory DESC) RN
	FROM [stag].[S4Hana_vInstoreDatesGlobal]
	WHERE 
		IsDeleted = 0
	) A
WHERE RN = 1

--========================================================================================================

--DECLARE @LoadDate DATETIME2(7) = GETDATE();

SELECT
  NatArticle_BK
, CreatedOn
, ModifiedOn
, NatMaterialNo
, NatArticleNo
, CompanyCode
, IntPupMasterId
, PDUCode
, CONVERT(BINARY(16), HASHBYTES('MD5',CONCAT(
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), NatArticle_BK)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), NatMaterialNo)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), NatArticleNo )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CompanyCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), IntPupMasterId)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PDUCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), NatMaterialDesc)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), NatStyleNo)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), NatColorDesc)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), EAN)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), SizeScaleCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), SizeCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), SizeNumber)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), MaterialSite)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), DistributionChannel)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), NatSizeLockFlag)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), NatLaunchDate)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), NatWholesaleCosts)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), NatLandedCosts)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), NatLocalRetailPrice)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CurrencyCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), BrandCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), GenderCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), GenderDesc)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), DistChannelCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), DistChannelDesc)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), DCSClassCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), DCSSubClassCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), RetailDCSDepCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ProdDivCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ProdDivDesc)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), BusSegCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), BusSubSegCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), RBUCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), OutletTheme)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FPeComTheme)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), RetailBusUnit)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), Retailclass)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), RetailSubClass)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), RetailGender)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), RetailProdDiv)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PIDFlag)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CRP)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FirstAssortment)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), LatestAssortment)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), Exclusivity)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), Specialist1)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), Specialist2)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), Specialist3)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), Specialist4)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), Specialist5)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), Specialist6)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), Specialist7)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), Specialist8)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), NeveroutofStock)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ProductStatus)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ProductLifecycle)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), Embargo)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ProductFamily)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ProductSubFamily)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), AssortmentCategory1)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), AssortmentCategory2)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ArticleLaunchFlag)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), KeyInitiative)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), KeyInitiativeDesc)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), QuarterInfo)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FirstPIDSeason)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), LastPIDSeason)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), Theme)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), LocalDC)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), RRPrice)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), BrutPrice)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), TargetStock)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ReorderPoint)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), StyleDesc)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ArtTypeCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), AgeGrpCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), LineName)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), InStoreDateFromLocal)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), InStoreDateToLocal)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), InStoreDateFromGlobal)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), InStoreDateToGlobal))))
  ))) AS HashDiff
, NatMaterialDesc
, NatStyleNo
, NatColorDesc
, EAN
, SizeScaleCode
, SizeCode
, SizeNumber
, MaterialSite
, DistributionChannel
, NatSizeLockFlag
, NatLaunchDate
, NatWholesaleCosts
, NatLandedCosts
, NatLocalRetailPrice
, CurrencyCode
, BrandCode
, GenderCode
, GenderDesc
, DistChannelCode
, DistChannelDesc
, DCSClassCode
, DCSSubClassCode
, RetailDCSDepCode
, ProdDivCode
, ProdDivDesc
, BusSegCode
, BusSubSegCode
, RBUCode
, OutletTheme
, FPeComTheme
, RetailBusUnit
, Retailclass
, RetailSubClass
, RetailGender
, RetailProdDiv
, PIDFlag
, CRP
, FirstAssortment
, LatestAssortment
, Exclusivity
, Specialist1
, Specialist2
, Specialist3
, Specialist4
, Specialist5
, Specialist6
, Specialist7
, Specialist8
, NeveroutofStock
, ProductStatus
, ProductLifecycle
, Embargo
, ProductFamily
, ProductSubFamily
, AssortmentCategory1
, AssortmentCategory2
, ArticleLaunchFlag
, KeyInitiative
, KeyInitiativeDesc
, QuarterInfo
, FirstPIDSeason
, LastPIDSeason
, Theme
, LocalDC
, StyleDesc
, RRPrice
, BrutPrice
, TargetStock	
, ReorderPoint
, ArtTypeCode
, AgeGrpCode
, LineName
, InStoreDateFromLocal
, InStoreDateToLocal
, InStoreDateFromGlobal
, InStoreDateToGlobal
INTO #NatArticles
FROM
(
	SELECT 
	  CONCAT(A.MaterialNumber, '|', B.CompanyCode)								AS NatArticle_BK
	, @LoadDate																	AS CreatedOn
	, @LoadDate																	AS ModifiedOn
	, A.MaterialNumber															AS NatMaterialNo
	, CONCAT(A.StyleNo, '-', A.ColorNo)											AS NatArticleNo
	, B.CompanyCode																AS CompanyCode
	, B.IntPupMasterId															AS IntPupMasterId
	, B.PDUCode																	AS PDUCode
	, C.[Description]															AS NatMaterialDesc
	, A.StyleNo																	AS NatStyleNo
	, A.ColorDesc																AS NatColorDesc
	, A.EAN																		AS EAN
	, A.SizeScaleCode															AS SizeScaleCode
	, A.SizeCode																AS SizeCode
	, A.SizeNumber																AS SizeNumber
	, A.MaterialSite															AS MaterialSite
	, A.DistributionChannel														AS DistributionChannel
	, CASE WHEN B.ProductSalesStatusCode_1 IN ('97','99')
				OR H.SiteMaterialStatus IN ('96','97','99') THEN 1 
		   ELSE 0 
	  END																		AS NatSizeLockFlag
	, B.ArticleLaunchDate_1														AS NatLaunchDate
	, NULL																		AS NatWholesaleCosts -- CAST(coalesce(av.ZPR0,ga.G_ZPR0,0) AS DECIMAL(13, 2))
	, ISNULL(I.MaterialPrice, J.MaterialPrice)									AS NatLandedCosts
	, NULL																		AS NatLocalRetailPrice -- CAST(coalesce(av.ZRRP,ga.G_ZRRP,0) AS DECIMAL(13, 2))
	, ISNULL(I.CurrencyCode, J.CurrencyCode)									AS CurrencyCode
	, A.BrandCode																AS BrandCode
	, A.GenderCode																AS GenderCode
	, E.GenderDesc																AS GenderDesc
	, A.IntDistChanCode															AS DistChannelCode
	, D.[Description]															AS DistChannelDesc
	, A.DCSClassCode															AS DCSClassCode
	, A.DCSSubClassCode															AS DCSSubClassCode
	, A.RetailDCSDepCode														AS RetailDCSDepCode
	, A.ProdDivCode																AS ProdDivCode
	, F.ProdDivDesc																AS ProdDivDesc
	, A.BusSegCode																AS BusSegCode
	, A.BusSubSegCode															AS BusSubSegCode
	, A.RBUCode																	AS RBUCode
	, A.OutletTheme																AS OutletTheme
	, A.FPeComTheme 															AS FPeComTheme

	-- Retail columns from MaterialHierarcies (raw.S_MaterialsHierarchies_EBP)
	, G.NatBusUnit																AS RetailBusUnit
	, G.NatClass																AS Retailclass
	, G.NatSubClass																AS RetailSubClass
	, G.NatGender																AS RetailGender
	, G.NatProdDiv																AS RetailProdDiv
	, A.PIDFlag																	AS PIDFlag

	-- CRP Attribute3 from biz.ArticlePricingConditions_EBP & biz.GenericArticlePricingConditions_EBP -- CAST(coalesce(av.ZCRP,ga.G_ZCRP,0) AS NVARCHAR(120))
	, NULL																		AS CRP
	, B.FirstAssortment_1														AS FirstAssortment
	, B.LatestAssortment_1														AS LatestAssortment
	, B.Exclusivity																AS Exclusivity
	, B.Specialist1																AS Specialist1
    , B.Specialist2																AS Specialist2
    , B.Specialist3																AS Specialist3
    , B.Specialist4																AS Specialist4
    , B.Specialist5																AS Specialist5
    , B.Specialist6																AS Specialist6
    , B.Specialist7																AS Specialist7
    , B.Specialist8																AS Specialist8
	, B.NeveroutofStock															AS NeveroutofStock
	, B.ProductStatus															AS ProductStatus
	, B.ProductLifecycle														AS ProductLifecycle
	, B.Embargo																	AS Embargo
	, B.ProductFamily															AS ProductFamily
	, B.ProductSubFamily														AS ProductSubFamily
	, B.AssortmentCategory1														AS AssortmentCategory1
	, B.AssortmentCategory2														AS AssortmentCategory2
	, B.ArticleLaunchFlag														AS ArticleLaunchFlag
	, B.KeyInitiative															AS KeyInitiative
	, ISNULL(KD.DESCRIPTION,'')													AS KeyInitiativeDesc
	, B.QuarterInfo																AS QuarterInfo
	, A.FirstPIDSeason															AS FirstPIDSeason
	, A.LastPIDSeason															AS LastPIDSeason
	, B.Theme_1																	AS Theme
	, B.LocalDC_1																AS LocalDC
	, S.StyleDesc																AS StyleDesc
	, bp.ZVP1																	AS RRPrice
	, bp.ZPR0																	AS BrutPrice
	, H.TargetStock																AS TargetStock 
	, H.ReorderPoint															AS ReorderPoint
	, A.ArtTypeCode																AS ArtTypeCode	
	, A.AgeGrpCode																AS AgeGrpCode	
	, A.LineName																AS LineName	
	, ISDL.IsdFrom																AS InStoreDateFromLocal
	, ISDL.IsdTo																AS InStoreDateToLocal
	, ISDG.IsdFrom																AS InStoreDateFromGlobal
	, ISDG.IsdTo																AS InStoreDateToGlobal
	FROM #Materials A
	INNER JOIN #MaterialSalesAttributes B ON A.MaterialNumber = B.MaterialNumber
	LEFT JOIN stag.S4Hana_vMaterialTexts C ON A.MaterialNumber = C.MaterialNumber
	LEFT JOIN stag.S4Hana_vPUMADistributionChannelTexts D ON A.IntDistChanCode = D.Code
	LEFT JOIN pdwref.S4Hana_Genders E ON A.GenderCode = E.GenderCode
	LEFT JOIN pdwref.S4Hana_ProductDivisions F ON A.ProdDivCode = F.ProdDivCode
	LEFT JOIN #MaterialHierarchy G ON A.MaterialNumber = G.MaterialNumber
	LEFT JOIN #PlantMaterialMaster H ON A.MaterialNumber = H.MaterialNumber AND H.CompanyCode = B.CompanyCode
	LEFT JOIN #MaterialPricesDCs I ON A.MaterialNumber = I.MaterialNumber
	LEFT JOIN #MaterialPricesStores J ON A.MaterialNumber = J.MaterialNumber
	LEFT JOIN [stag].[S4Hana_vStyleTexts] S ON A.StyleNo = S.Style
	LEFT JOIN #BrutPrice bp ON A.GenericMaterial = bp.MaterialNumber AND bp.SalesOrganisation = b.SalesOrgCode
    LEFT JOIN [stag].[S4Hana_vKeyInitiativeTexts] KD ON B.KeyInitiative = KD.KEYINITIATIVE
	LEFT JOIN #InStoreDatesLocal ISDL ON	CONCAT(A.StyleNo, '-', A.ColorNo) = ISDL.NatArticleNo
											AND B.CompanyCode = ISDL.CompanyCode
	LEFT JOIN #InStoreDatesGlobal ISDG ON	ISDG.Brand = A.BrandCode
											AND ISDG.ProductDiv = A.ProdDivCode
											AND ISDG.Linenamecode = A.LineName
											AND ISDG.BusiSeg = A.BusSegCode


	WHERE (
			A.LDTS >= @LDTS 
			OR B.LDTS >= @LDTS
			OR C.LDTS >= @LDTS
			OR D.LDTS >= @LDTS
			OR G.LDTS >= @LDTS
			OR H.LDTS >= @LDTS
			OR S.LDTS >= @LDTS
			OR ISDL.LDTS >= @LDTS
			OR ISDG.LDTS >= @LDTS
		  )
) X
--ORDER BY 1

--Count Records to be updated
SELECT @AffectedRows = COUNT(*)
FROM ref.NatArticles A
INNER JOIN #NatArticles B ON A.NatArticle_BK = B.NatArticle_BK
WHERE A.HashDiff <> B.HashDiff

--Update Final Table
UPDATE A SET
  A.ModifiedOn = B.ModifiedOn
, A.NatMaterialNo = B.NatMaterialNo
, A.NatArticleNo = B.NatArticleNo
, A.CompanyCode = B.CompanyCode
, A.IntPupMasterId = B.IntPupMasterId
, A.PDUCode = B.PDUCode
, A.HashDiff = B.HashDiff
, A.NatMaterialDesc = B.NatMaterialDesc
, A.NatStyleNo = B.NatStyleNo
, A.NatColorDesc = B.NatColorDesc
, A.EAN = B.EAN
, A.SizeScaleCode = B.SizeScaleCode
, A.SizeCode = B.SizeCode
, A.SizeNumber = B.SizeNumber
, A.MaterialSite = B.MaterialSite
, A.DistributionChannel = B.DistributionChannel
, A.NatSizeLockFlag = B.NatSizeLockFlag
, A.NatLaunchDate = B.NatLaunchDate
, A.NatWholesaleCosts = B.NatWholesaleCosts
, A.NatLandedCosts = B.NatLandedCosts
, A.NatLocalRetailPrice = B.NatLocalRetailPrice
, A.CurrencyCode = B.CurrencyCode
, A.BrandCode = B.BrandCode
, A.GenderCode = B.GenderCode
, A.GenderDesc = B.GenderDesc
, A.DistChannelCode = B.DistChannelCode
, A.DistChannelDesc = B.DistChannelDesc
, A.DCSClassCode = B.DCSClassCode
, A.DCSSubClassCode = B.DCSSubClassCode
, A.RetailDCSDepCode = B.RetailDCSDepCode
, A.ProdDivCode = B.ProdDivCode
, A.ProdDivDesc = B.ProdDivDesc
, A.BusSegCode = B.BusSegCode
, A.BusSubSegCode = B.BusSubSegCode
, A.RBUCode = B.RBUCode
, A.OutletTheme = B.OutletTheme
, A.FPeComTheme = B.FPeComTheme
, A.RetailBusUnit = B.RetailBusUnit
, A.Retailclass = B.Retailclass
, A.RetailSubClass = B.RetailSubClass
, A.RetailGender = B.RetailGender
, A.RetailProdDiv = B.RetailProdDiv
, A.PIDFlag = B.PIDFlag
, A.CRP = B.CRP
, A.FirstAssortment = B.FirstAssortment
, A.LatestAssortment = B.LatestAssortment
, A.Exclusivity = B.Exclusivity
, A.Specialist1 = B.Specialist1
, A.Specialist2 = B.Specialist2
, A.Specialist3 = B.Specialist3
, A.Specialist4 = B.Specialist4
, A.Specialist5 = B.Specialist5
, A.Specialist6 = B.Specialist6
, A.Specialist7 = B.Specialist7
, A.Specialist8 = B.Specialist8
, A.NeveroutofStock = B.NeveroutofStock
, A.ProductStatus = B.ProductStatus
, A.ProductLifecycle = B.ProductLifecycle
, A.Embargo = B.Embargo
, A.ProductFamily = B.ProductFamily
, A.ProductSubFamily = B.ProductSubFamily
, A.AssortmentCategory1 = B.AssortmentCategory1
, A.AssortmentCategory2 = B.AssortmentCategory2
, A.ArticleLaunchFlag = B.ArticleLaunchFlag
, A.KeyInitiative	= B.KeyInitiative
, A.KeyInitiativeDesc = B.KeyInitiativeDesc
, A.QuarterInfo		= B.QuarterInfo
, A.FirstPIDSeason = B.FirstPIDSeason
, A.LastPIDSeason = B.LastPIDSeason
, A.Theme = B.Theme
, A.LocalDC = B.LocalDC
, A.StyleDesc = B.StyleDesc
, A.RRPrice = B.RRPrice
, A.BrutPrice = B.BrutPrice
, A.TargetStock  = B.TargetStock
, A.ReorderPoint = B.ReorderPoint
, A.ArtTypeCode	= B.ArtTypeCode	
, A.AgeGrpCode	= B.AgeGrpCode	
, A.LineName	= B.LineName	
, A.InStoreDateFromLocal	= B.InStoreDateFromLocal	
, A.InStoreDateToLocal	= B.InStoreDateToLocal	
, A.InStoreDateFromGlobal	= B.InStoreDateFromGlobal	
, A.InStoreDateToGlobal	= B.InStoreDateToGlobal	

FROM ref.NatArticles A
INNER JOIN #NatArticles B ON A.NatArticle_BK = B.NatArticle_BK
WHERE A.HashDiff <> B.HashDiff

--UPDATE NatLandedCost from MaterialPrices To be checked with Reza why it was no longer in France solution. It is on SE Prod
SET @AffectedRows = @AffectedRows +
		(
			SELECT COUNT(A.NatMaterialNo)
			FROM ref.NatArticles A
			LEFT JOIN #MaterialPricesDCs B ON A.NatMaterialNo = B.MaterialNumber
			LEFT JOIN #MaterialPricesStores C ON A.NatMaterialNo = C.MaterialNumber
			WHERE A.NatLandedCosts <> ISNULL(B.MaterialPrice, C.MaterialPrice)
		)

UPDATE A SET
  A.ModifiedOn = @LoadDate
, A.NatLandedCosts = ISNULL(B.MaterialPrice, C.MaterialPrice)
, A.CurrencyCode = ISNULL(B.CurrencyCode, C.CurrencyCode)
FROM ref.NatArticles A
LEFT JOIN #MaterialPricesDCs B ON A.NatMaterialNo = B.MaterialNumber
LEFT JOIN #MaterialPricesStores C ON A.NatMaterialNo = C.MaterialNumber
WHERE A.NatLandedCosts <> ISNULL(B.MaterialPrice, C.MaterialPrice)

	
--Log count of updated records
UPDATE DTlogs SET
  Updated = @AffectedRows
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

--Count Records to be inserted
SELECT @AffectedRows = COUNT(*)
FROM #NatArticles A
LEFT JOIN ref.NatArticles B ON A.NatArticle_BK = B.NatArticle_BK
WHERE B.NatArticle_BK IS NULL
	

--Insert to Final Table
INSERT INTO ref.NatArticles
(
  NatArticle_BK
, CreatedOn
, ModifiedOn
, NatMaterialNo
, NatArticleNo
, CompanyCode
, IntPupMasterId
, PDUCode
, HashDiff
, NatMaterialDesc
, NatStyleNo
, NatColorDesc
, EAN
, SizeScaleCode
, SizeCode
, SizeNumber
, MaterialSite
, DistributionChannel
, NatSizeLockFlag
, NatLaunchDate
, NatWholesaleCosts
, NatLandedCosts
, NatLocalRetailPrice
, CurrencyCode
, BrandCode
, GenderCode
, GenderDesc
, DistChannelCode
, DistChannelDesc
, DCSClassCode
, DCSSubClassCode
, RetailDCSDepCode
, ProdDivCode
, ProdDivDesc
, BusSegCode
, BusSubSegCode
, RBUCode
, OutletTheme
, FPeComTheme
, RetailBusUnit
, Retailclass
, RetailSubClass
, RetailGender
, RetailProdDiv
, PIDFlag
, CRP
, FirstAssortment
, LatestAssortment
, Exclusivity
, Specialist1
, Specialist2
, Specialist3
, Specialist4
, Specialist5
, Specialist6
, Specialist7
, Specialist8
, NeveroutofStock
, ProductStatus
, ProductLifecycle
, Embargo
, ProductFamily
, ProductSubFamily
, AssortmentCategory1
, AssortmentCategory2
, ArticleLaunchFlag
, KeyInitiative
, KeyInitiativeDesc
, QuarterInfo
, FirstPIDSeason
, LastPIDSeason
, Theme
, LocalDC
, StyleDesc
, RRPrice
, BrutPrice
, TargetStock
, ReorderPoint
, ArtTypeCode	
, AgeGrpCode	
, LineName	
, InStoreDateFromLocal
, InStoreDateToLocal
, InStoreDateFromGlobal
, InStoreDateToGlobal
)
SELECT
  A.NatArticle_BK
, A.CreatedOn
, A.ModifiedOn
, A.NatMaterialNo
, A.NatArticleNo
, A.CompanyCode
, A.IntPupMasterId
, A.PDUCode
, A.HashDiff
, A.NatMaterialDesc
, A.NatStyleNo
, A.NatColorDesc
, A.EAN
, A.SizeScaleCode
, A.SizeCode
, A.SizeNumber
, A.MaterialSite
, A.DistributionChannel
, A.NatSizeLockFlag
, A.NatLaunchDate
, A.NatWholesaleCosts
, A.NatLandedCosts
, A.NatLocalRetailPrice
, A.CurrencyCode
, A.BrandCode
, A.GenderCode
, A.GenderDesc
, A.DistChannelCode
, A.DistChannelDesc
, A.DCSClassCode
, A.DCSSubClassCode
, A.RetailDCSDepCode
, A.ProdDivCode
, A.ProdDivDesc
, A.BusSegCode
, A.BusSubSegCode
, A.RBUCode
, A.OutletTheme
, A.FPeComTheme
, A.RetailBusUnit
, A.Retailclass
, A.RetailSubClass
, A.RetailGender
, A.RetailProdDiv
, A.PIDFlag
, A.CRP
, A.FirstAssortment
, A.LatestAssortment
, A.Exclusivity
, A.Specialist1
, A.Specialist2
, A.Specialist3
, A.Specialist4
, A.Specialist5
, A.Specialist6
, A.Specialist7
, A.Specialist8
, A.NeveroutofStock
, A.ProductStatus
, A.ProductLifecycle
, A.Embargo
, A.ProductFamily
, A.ProductSubFamily
, A.AssortmentCategory1
, A.AssortmentCategory2
, A.ArticleLaunchFlag
, A.KeyInitiative
, A.KeyInitiativeDesc
, A.QuarterInfo
, A.FirstPIDSeason
, A.LastPIDSeason
, A.Theme
, A.LocalDC
, A.StyleDesc
, A.RRPrice
, A.BrutPrice
, A.TargetStock
, A.ReorderPoint
, A.ArtTypeCode	
, A.AgeGrpCode	
, A.LineName	
, A.InStoreDateFromLocal
, A.InStoreDateToLocal
, A.InStoreDateFromGlobal
, A.InStoreDateToGlobal

FROM #NatArticles A
LEFT JOIN ref.NatArticles B ON A.NatArticle_BK = B.NatArticle_BK
WHERE B.NatArticle_BK IS NULL

--Log count of inserted records
UPDATE DTlogs SET 
  Inserted = @AffectedRows
, ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId