﻿CREATE PROC [dbo].[S4Hana_spProvNatPurchaseOrderDeliveryNotesCurrent] @ldts [DATETIME2](7) AS
BEGIN
    SET NOCOUNT ON;
    SET ANSI_WARNINGS ON;
    IF OBJECT_ID(N'tempdb..#tmp_result') IS not NULL
    DROP TABLE #tmp_result;
    DECLARE @sysdate DATETIME;

	--for test runs
	--DECLARE @LDTS [SMALLDATETIME] = '1900-01-01'
	
	-- logging informations - BEGIN
	DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
	DECLARE @ExecStart DATETIME2(7) = GETDATE()
	DECLARE @SourceLastLoadDate DATETIME2(7)
	DECLARE @DestinationLastLoadDate DATETIME2(7)
	DECLARE @BatchLdts DATETIME2(7) = @LDTS
	DECLARE @AffectedRows BIGINT = NULL


	-- logging Informations - END

	-- get last LDTS Informations for Logging
	IF(EXISTS(SELECT 1 FROM sourcing.NatPurchaseOrderDeliveryNotesCurrent))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(LDTS))
	FROM sourcing.NatPurchaseOrderDeliveryNotesCurrent
	END
	ELSE BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

	IF(EXISTS(SELECT 1 FROM [biz].[S4Hana_DeliveryDocuments]))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(LDTS))
		FROM [biz].[S4Hana_DeliveryDocuments]
	END
	ELSE BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END
	-- Logging Informations END

	-- Log first DATA Informations

		INSERT INTO etl.DataTransferLogs
			  (DataTransferLogId
			  ,TransferName
			  ,TransferGroupName
			  ,TargetTableName
			  ,TargetSchemaName
			  ,ExecStart
			  ,SourceLastLoadDate
			  ,DestinationLastLoadDate
			  ,BatchLdts)
			  SELECT @DataTransferLogId 
					,'spProvNatPurchaseOrderDeliveryNotesCurrent'
					,'NatPurchaseOrderDeliveryDocuments'
					,'NatPurchaseOrderDeliveryNotesCurrent'
					,'sales'
					,@ExecStart
					,@SourceLastLoadDate
					,@DestinationLastLoadDate
					,@BatchLdts

	-- Log first DATA Informations END



;WITH CTE_tmp_del AS
    (
          SELECT DISTINCT
             delh.DeliveryNoteNumber
            ,deli.DeliveryNoteItemNo    
            ,delh.CreationDate 
            ,delh.OverallGoodsMovementStatus
            ,deli.ActualDeliveryQuantity AS ActualDeliveryQuantity
            ,cast(REPLACE(ISNULL(ActualGoodsMovementDate,'1900-01-01'),'-', '') as int) AS ActualGoodsMovementDate
			,cast(REPLACE(ISNULL(delh.PlannedGoodsIssueDate,'1900-01-01'),'-', '') as int) AS PlannedGoodsIssueDate
			,CASE WHEN ISNULL(ActualGoodsMovementDate , '') <> '' THEN cast(REPLACE(ISNULL(ActualGoodsMovementDate,'1900-01-01'),'-', '') as int)
					ELSE cast(REPLACE(ISNULL(delh.PlannedGoodsIssueDate,'1900-01-01'),'-', '') as int)
					END AS DeliveryDate
            ,delh.OverallPackingStatus
            ,delh.OverallSDProcessStatus
            ,delh.CustomerCode_SoldTo
            ,deli.SiteCode 
            ,CASE WHEN deli.IsDeleted = 1 THEN 1 ELSE 0 END AS IsDeleted 
            ,m.MaterialNumber
            ,delh.SalesOrganization
            ,deli.ActualDeliveryQuantityBaseUnit AS OrderQuantity
            ,delh.TransactionCurrency AS CurrencyCode
            ,m.StyleNo
            ,m.ColorNo
            ,CAST(m.ProdDivCode AS INT) AS ProdDivCode
            ,m.RBUCode
            ,m.BrandCode
            ,m.MaterialCategoryCode
            ,delh.LDTS
            ,deli.ReferenceDocumentNo AS NatPurchaseOrderNo
			,deli.ReferenceDocumentItemNo AS NatPurchaseOrderItemNo
		    ,deli.OriginalDeliveryQuantity
			,deli.CreatedByUser
			,deli.DistributionChannel
			,deli.StorageLocation
			,deli.ProductAvailabilityDate
			,deli.ProfitCenter
			,deli.SDProcessStatus
			,deli.RequirementSegment
			,deli.StockSegment 
			,delh.TotalCreditCheckStatus as TotalCreditCheckStatus            
            ,delh.DeliveryNoteDocType AS DeliveryNoteTypeCode
			,dtt.DeliveryDocumentTypeDesc AS DeliveryNoteTypeDesc 
			,delh.MeansOfTransport
			,delh.SpecialProcessingCode
			
		FROM biz.S4Hana_DeliveryDocuments AS delh
		JOIN biz.S4Hana_DeliveryDocumentItems AS deli ON delh.DeliveryNoteNumber = deli.DeliveryNoteNumber
		AND (delh.SDDocumentCategory= 'J' or delh.SDDocumentCategory ='')
		JOIN [stag].[S4Hana_vDeliveryDocumentTypeTexts] dtt ON dtt.DeliveryDocumentType = delh.DeliveryNoteDocType
		JOIN biz.S4Hana_PODocumentItems AS poi on poi.PONo = deli.ReferenceDocumentNo AND poi.POItemNo = right(deli.ReferenceDocumentItemNo,5)
        JOIN [stag].[S4Hana_vMaterials] AS m ON deli.MaterialNumber = m.MaterialNumber
        WHERE (delh.LDTS            >= @ldts 
					OR deli.LDTS        >= @ldts
						OR poi.ldts >= @ldts
							OR m.LDTS       >= @ldts
									OR dtt.LDTS			>= @ldts
									)
    ), 
CTE_result AS 
        (SELECT 
		CAST(CONCAT(LTRIM(RTRIM(del.DeliveryNoteNumber)),LTRIM(RTRIM(del.DeliveryNoteItemNo)))AS BIGINT) AS NatDeliveryNote_BK
            ,del.LDTS                                                               AS LDTS
            ,del.DeliveryNoteNumber						                            AS NatDeliveryNoteNo--BK  
            ,del.DeliveryNoteItemNo						                            AS NatDeliveryNoteItemNo--BK    
            ,i.CompanyCode                                                          AS CompanyCode                  
            ,i.IntPupMasterId                                                       AS IntPupMasterId
            ,i.PDUCode                                                              AS PDUCode
            ,del.NatPurchaseOrderNo                                                 AS NatPurchaseOrderNo
            ,del.NatPurchaseOrderItemNo                                             AS NatPurchaseOrderItemNo
            ,LEFT(del.MaterialNumber,CHARINDEX('-',del.MaterialNumber)-1)                                                        AS StyleNumber_BK 
            ,REPLACE(LEFT(del.MaterialNumber,CHARINDEX('-',del.MaterialNumber,(CHARINDEX('-',del.MaterialNumber)+1))-1),'-',' ') AS ArticleNumber_BK
            ,REPLACE(MaterialNumber,'-',' ') AS ArticleSize_BK
		    ,CONCAT(del.MaterialNumber ,'|',CASE WHEN TRIM(i.CompanyCode) = 'PT10' THEN 'ES10'
													ELSE TRIM(i.CompanyCode) END)                     AS NatArticle_BK            
			,CONCAT(del.CustomerCode_SoldTo,'|',del.SalesOrganization)				AS NatCustomer_BK
            ,CONCAT(del.SiteCode,'|',i.CompanyCode)								    AS NatStoreDC_BK
            ,CAST(
                CASE
                    WHEN del.OverallGoodsMovementStatus = 'C' AND del.ActualDeliveryQuantity = 0    THEN 'Cancelled'
                    WHEN del.OverallGoodsMovementStatus = 'C' AND del.ActualDeliveryQuantity > 0    THEN 'Delivered'
                    WHEN del.OverallPackingStatus = 'C'     THEN 'Packed'
                    WHEN del.OverallSDProcessStatus = 'A'   THEN 'Created'
                ELSE 'n/a' END AS VARCHAR(40))                                      AS DeliveryNoteStatusDesc       
            ,cast(REPLACE(ISNULL(CREATIONDATE,'1900-01-01'),'-', '') as int)        AS DeliveryNoteCreationDate   
            ,CAST(del.ActualDeliveryQuantity AS int)                                AS Qty
            ,CASE WHEN del.IsDeleted = 0 THEN 1 ELSE 0 END                          AS ACTIVE
            ,try_cast(del.RBUCode AS int)                                           AS RBUCode
            ,del.BrandCode                                                          AS BrandCode                    
            ,del.ProdDivCode                                                        AS ProdDivCode                  
            ,CAST(del.CurrencyCode AS CHAR(3))                                      AS CurrencyCode                 
            ,del.DeliveryNoteTypeCode                                               AS DeliveryNoteTypeCode
            ,del.ActualGoodsMovementDate                                            AS ActualGoodsMovementDate
			,del.PlannedGoodsIssueDate												AS PlannedGoodsIssueDate
			,del.DeliveryDate														AS DeliveryDate
			,del.DeliveryNoteTypeDesc												AS DeliveryNoteTypeDesc
			,del.TotalCreditCheckStatus
			,del.MeansOfTransport
			,del.SpecialProcessingCode
			,del.OriginalDeliveryQuantity
			,del.CreatedByUser
			,del.DistributionChannel
			,del.StorageLocation
			,del.ProductAvailabilityDate
			,del.ProfitCenter
			,del.SDProcessStatus
			,del.RequirementSegment
			,del.StockSegment
			,CASE WHEN del.TotalCreditCheckStatus= 'A' THEN 'Credit check was executed, document OK'
				 WHEN del.TotalCreditCheckStatus= 'B' THEN 'Credit check was executed, document not OK'
				 WHEN del.TotalCreditCheckStatus= 'C' THEN 'Credit check was executed, document not OK, partial release'
				 WHEN del.TotalCreditCheckStatus= 'D' THEN 'Document released by credit representative'
				 ELSE Null END AS TotalCreditCheckStatusDesc
    FROM CTE_tmp_del AS del
    JOIN pdwref.S4Hana_Interfaces AS i ON del.SalesOrganization = i.SalesOrg AND i.Interface ='EBP'
    WHERE (del.MaterialCategoryCode <> '01' OR del.MaterialCategoryCode is null)
    /*AND ISNUMERIC(del.ColorNo) = 1 AND ISNUMERIC(del.StyleNo) = 1*/
       /* AND del.CustomerCode_SoldTo <> ''*/
    )

    SELECT 
		 NatDeliveryNote_BK
        ,LDTS
        ,NatDeliveryNoteNo
        ,NatDeliveryNoteItemNo
        ,CompanyCode
        ,IntPupMasterId
        ,PDUCode
        ,NatPurchaseOrderNo
        ,NatPurchaseOrderItemNo
        ,StyleNumber_BK
        ,ArticleNumber_BK
        ,ArticleSize_BK 
        ,NatArticle_BK 
        ,NatCustomer_BK 
        ,NatStoreDC_BK 
        ,DeliveryNoteStatusDesc
        ,DeliveryNoteCreationDate
        ,Qty
        ,Active
        ,RBUCode 
        ,BrandCode
        ,ProdDivCode
        ,CurrencyCode
        ,DeliveryNoteTypeCode
		,DeliveryNoteTypeDesc
        ,ActualGoodsMovementDate
		,PlannedGoodsIssueDate
		,DeliveryDate
		,TotalCreditCheckStatus
		,TotalCreditCheckStatusDesc
		,MeansOfTransport
		,SpecialProcessingCode
		,OriginalDeliveryQuantity
		,CreatedByUser
		,DistributionChannel
		,StorageLocation
		,ProductAvailabilityDate
		,ProfitCenter
		,SDProcessStatus
		,RequirementSegment
		,StockSegment
        ,CONVERT(BINARY(16),
            HASHBYTES('MD5',CONCAT(
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), NatDeliveryNote_BK        )))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), LDTS					   )))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), NatDeliveryNoteNo		   )))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), NatDeliveryNoteItemNo	   )))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), CompanyCode			   )))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), IntPupMasterId			   )))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), PDUCode				   )))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), NatPurchaseOrderNo		   )))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), NatPurchaseOrderItemNo	   )))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), StyleNumber_BK			   )))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), ArticleNumber_BK		   )))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), ArticleSize_BK 		   )))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), NatArticle_BK 			   )))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), NatCustomer_BK 		   )))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), NatStoreDC_BK 			   )))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), DeliveryNoteStatusDesc	   )))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), DeliveryNoteCreationDate  )))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), Qty					   )))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), Active					   )))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), RBUCode 				   )))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), BrandCode				   )))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), ProdDivCode			   )))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), CurrencyCode			   )))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), DeliveryNoteTypeCode	   )))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), DeliveryNoteTypeDesc	   )))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), ActualGoodsMovementDate   )))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), PlannedGoodsIssueDate	   )))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), DeliveryDate			   )))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), TotalCreditCheckStatus	   )))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), TotalCreditCheckStatusDesc)))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), MeansOfTransport		   )))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), SpecialProcessingCode	   )))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), OriginalDeliveryQuantity  )))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), CreatedByUser			   )))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), DistributionChannel	   )))),'_',
            UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), StorageLocation		   )))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), ProductAvailabilityDate   )))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), ProfitCenter			   )))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), SDProcessStatus		   )))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), RequirementSegment		   )))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), StockSegment)))) 

            ))) AS HASHDIFF
        INTO #tmp_result
        FROM CTE_result

   
   -- count new Records for NatPurchaseOrderDeliveryNotesCurrent
	SELECT @AffectedRows = COUNT(*)
    FROM sourcing.NatPurchaseOrderDeliveryNotesCurrent AS prd JOIN #tmp_result AS stg 
    ON prd.NatDeliveryNote_BK = stg.NatDeliveryNote_BK AND stg.HashDiff <> prd.HashDiff

	
   
   SET @sysdate= GETDATE();
    
                UPDATE prd SET  
                   prd.ModifiedOn                       = @sysdate 
                  ,prd.CompanyCode                      = stg.CompanyCode
                  ,prd.IntPupMasterId                   = stg.IntPupMasterId
                  ,prd.PDUCode                          = stg.PDUCode
                  ,prd.NatPurchaseOrderNo               = stg.NatPurchaseOrderNo
                  ,prd.NatPurchaseOrderItemNo           = stg.NatPurchaseOrderItemNo
                  ,prd.StyleNumber_BK                   = CAST(ISNULL(TRY_CAST(stg.StyleNumber_BK AS INT), 0) AS INT)
                  ,prd.ArticleNumber_BK                 = stg.ArticleNumber_BK
                  ,prd.ArticleSize_BK                   = stg.ArticleSize_BK
                  ,prd.NatArticle_BK                    = stg.NatArticle_BK
                  ,prd.NatCustomer_BK                   = stg.NatCustomer_BK
                  ,prd.NatStoreDC_BK                    = stg.NatStoreDC_BK
                  ,prd.DeliveryNoteStatusDesc           = stg.DeliveryNoteStatusDesc
                  ,prd.DeliveryNoteCreationDate         = stg.DeliveryNoteCreationDate
                  ,prd.Qty                              = stg.Qty
                  ,prd.Active                           = stg.Active
                  ,prd.RBUCode                          = stg.RBUCode
                  ,prd.BrandCode                        = stg.BrandCode
                  ,prd.ProdDivCode                      = stg.ProdDivCode
                  ,prd.CurrencyCode                     = stg.CurrencyCode
                  ,prd.DeliveryNoteTypeCode             = stg.DeliveryNoteTypeCode
                  ,prd.DeliveryNoteTypeDesc             = stg.DeliveryNoteTypeDesc
				  ,prd.ActualGoodsMovementDate          = stg.ActualGoodsMovementDate
				  ,prd.PlannedGoodsIssueDate			= stg.PlannedGoodsIssueDate
				  ,prd.DeliveryDate						= stg.DeliveryDate
				  ,prd.TotalCreditCheckStatus			= stg.TotalCreditCheckStatus
				  ,prd.TotalCreditCheckStatusDesc		= stg.TotalCreditCheckStatusDesc
				  ,prd.MeansOfTransport                 = stg.MeansOfTransport
				  ,prd.SpecialProcessingCode			= stg.SpecialProcessingCode
				  ,prd.OriginalDeliveryQuantity 		= stg.OriginalDeliveryQuantity 
				  ,prd.CreatedByUser			  		= stg.CreatedByUser			
				  ,prd.DistributionChannel	  			= stg.DistributionChannel	  	
				  ,prd.StorageLocation		  			= stg.StorageLocation		  	
				  ,prd.ProductAvailabilityDate  		= stg.ProductAvailabilityDate  
				  ,prd.ProfitCenter			  			= stg.ProfitCenter			  	
				  ,prd.SDProcessStatus		  			= stg.SDProcessStatus		  	
				  ,prd.RequirementSegment		  		= stg.RequirementSegment		
				  ,prd.StockSegment						= stg.StockSegment				
                  ,prd.HashDiff                         = stg.HashDiff
                  ,prd.LDTS                             = stg.LDTS 
             FROM sourcing.NatPurchaseOrderDeliveryNotesCurrent AS prd JOIN #tmp_result AS stg 
                ON prd.NatDeliveryNote_BK = stg.NatDeliveryNote_BK AND stg.HashDiff <> prd.HashDiff
	

		-- insert Logging Informations to DataTransferLogs
		UPDATE DTlogs
		SET Updated = @AffectedRows
		, ExecEnd = GETDATE()
		FROM etl.DataTransferLogs DTlogs
		WHERE DataTransferLogId = @DataTransferLogId


		-- count new Records for S4Hana_DeliveryDocuments
		SELECT @AffectedRows = COUNT(*)
		FROM #tmp_result AS stg LEFT JOIN sourcing.NatPurchaseOrderDeliveryNotesCurrent AS prd 
		ON prd.NatDeliveryNote_BK = stg.NatDeliveryNote_BK
		WHERE prd.NatDeliveryNote_BK IS NULL
		
        --populate Fact table
    INSERT sourcing.NatPurchaseOrderDeliveryNotesCurrent(NatDeliveryNote_BK
                                          ,CreatedOn
                                          ,ModifiedOn
                                          ,NatDeliveryNoteNo
                                          ,NatDeliveryNoteItemNo
                                          ,CompanyCode
                                          ,IntPupMasterId
                                          ,PDUCode
                                          ,NatPurchaseOrderNo 
                                          ,NatPurchaseOrderItemNo
                                          ,StyleNumber_BK
                                          ,ArticleNumber_BK
                                          ,ArticleSize_BK
                                          ,NatArticle_BK
                                          ,NatCustomer_BK
                                          ,NatStoreDC_BK
                                          ,DeliveryNoteStatusDesc
                                          ,DeliveryNoteCreationDate
                                          ,Qty
                                          ,Active
                                          ,RBUCode
                                          ,BrandCode
                                          ,ProdDivCode
                                          ,CurrencyCode
                                          ,DeliveryNoteTypeCode
										  ,DeliveryNoteTypeDesc
                                          ,ActualGoodsMovementDate
										  ,PlannedGoodsIssueDate
										  ,DeliveryDate
										  ,TotalCreditCheckStatus
										  ,TotalCreditCheckStatusDesc
										  ,MeansOfTransport
										  ,SpecialProcessingCode
										  ,OriginalDeliveryQuantity 
										  ,CreatedByUser			
										  ,DistributionChannel	  	
										  ,StorageLocation		  	
										  ,ProductAvailabilityDate  
										  ,ProfitCenter			  	
										  ,SDProcessStatus		  	
										  ,RequirementSegment		
										  ,StockSegment				
                                          ,HashDiff
                                          ,LDTS)
            SELECT  stg.NatDeliveryNote_BK
                  ,@sysdate AS CreatedOn
                  ,@sysdate AS ModifiedOn
                  ,stg.NatDeliveryNoteNo
                  ,stg.NatDeliveryNoteItemNo
                  ,stg.CompanyCode
                  ,stg.IntPupMasterId
                  ,stg.PDUCode
                  ,stg.NatPurchaseOrderNo
                  ,stg.NatPurchaseOrderItemNo
                  ,CAST(ISNULL(TRY_CAST(stg.StyleNumber_BK AS INT), 0) AS INT) AS StyleNumber_BK
                  ,stg.ArticleNumber_BK
                  ,stg.ArticleSize_BK
                  ,stg.NatArticle_BK
                  ,stg.NatCustomer_BK
                  ,stg.NatStoreDC_BK
                  ,stg.DeliveryNoteStatusDesc
                  ,stg.DeliveryNoteCreationDate
                  ,stg.Qty
                  ,stg.Active
                  ,stg.RBUCode
                  ,stg.BrandCode
                  ,stg.ProdDivCode
                  ,stg.CurrencyCode
                  ,stg.DeliveryNoteTypeCode
				  ,stg.DeliveryNoteTypeDesc
                  ,stg.ActualGoodsMovementDate
				  ,stg.PlannedGoodsIssueDate
				  ,stg.DeliveryDate
				  ,stg.TotalCreditCheckStatus
				  ,stg.TotalCreditCheckStatusDesc
				  ,stg.MeansOfTransport
				  ,stg.SpecialProcessingCode
				  ,stg.OriginalDeliveryQuantity 
				  ,stg.CreatedByUser			
				  ,stg.DistributionChannel	  	
				  ,stg.StorageLocation		  	
				  ,stg.ProductAvailabilityDate  
				  ,stg.ProfitCenter			  	
				  ,stg.SDProcessStatus		  	
				  ,stg.RequirementSegment		
				  ,stg.StockSegment				
                  ,stg.HashDiff
                  ,stg.LDTS
            FROM #tmp_result AS stg LEFT JOIN sourcing.NatPurchaseOrderDeliveryNotesCurrent AS prd ON prd.NatDeliveryNote_BK = stg.NatDeliveryNote_BK
            WHERE prd.NatDeliveryNote_BK IS NULL


		-- insert Logging Informations to DataTransferLogs
		UPDATE DTlogs
		SET Inserted = @AffectedRows
		FROM etl.DataTransferLogs DTlogs
		WHERE DataTransferLogId = @DataTransferLogId



	-- set Logging Informations

	-- count deleted Records for NatPurchaseOrderDeliveryNotesCurrent
	SELECT @AffectedRows = COUNT(*)
	from [biz].[S4Hana_DeliveryDocumentItems]del
	INNER JOIN sourcing.NatPurchaseOrderDeliveryNotesCurrent natPO 
					on natPO.NatDeliveryNote_BK = CAST(CONCAT(LTRIM(RTRIM(del.DeliveryNoteNumber)),LTRIM(RTRIM(del.DeliveryNoteItemNo)))AS BIGINT)
			WHERE del.IsDeleted = 1
			AND (del.LDTS            >= @ldts )


	-- update Deleted Records

	UPDATE natPO
	SET natPO.Active = CASE WHEN del.IsDeleted = 0 THEN 1 ELSE 0 END
	,natPO.ModifiedOn                        = @sysdate 
	from [biz].[S4Hana_DeliveryDocumentItems]del
	INNER JOIN sourcing.NatPurchaseOrderDeliveryNotesCurrent natPO 
					on natPO.NatDeliveryNote_BK = CAST(CONCAT(LTRIM(RTRIM(del.DeliveryNoteNumber)),LTRIM(RTRIM(del.DeliveryNoteItemNo)))AS BIGINT)
			WHERE del.IsDeleted = 1
			AND (del.LDTS            >= @ldts )

-- set loggingInformations for deletion records
UPDATE DTlogs
SET Deleted = @AffectedRows
, ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId


END

--truncate table sourcing.NatPurchaseOrderDeliveryNotesCurrent
--exec [dbo].[S4Hana_spProvNatPurchaseOrderDeliveryNotesCurrent]'1900-01-01'