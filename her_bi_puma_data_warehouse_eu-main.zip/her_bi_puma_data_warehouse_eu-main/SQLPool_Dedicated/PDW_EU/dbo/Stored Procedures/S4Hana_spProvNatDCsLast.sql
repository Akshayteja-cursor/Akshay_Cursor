﻿CREATE PROC [dbo].[S4Hana_spProvNatDCsLast] @LDTS [DATETIME2](7) AS

DECLARE @LoadDate DATETIME2(7) = GETDATE();

IF OBJECT_ID('tempdb..#NatDCs') IS NOT NULL DROP TABLE #NatDCs;

-- logging informations - BEGIN
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(0) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(0)
DECLARE @DestinationLastLoadDate DATETIME2(0)
DECLARE @BatchLdts DATETIME2(0) = @LDTS
DECLARE @AffectedRows BIGINT = NULL
-- logging Informations - END

-- get last LDTS Informations for Logging
IF(EXISTS(SELECT 1 FROM ref.NatDCs))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(modifiedOn))
		FROM ref.NatDCs
	END
ELSE 
	BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

IF(EXISTS(SELECT 1 FROM ref.NatDCs))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(modifiedOn))
		FROM ref.NatDCs
	END
ELSE 
	BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END
-- Logging Informations END


-- Log first DATA Informations

INSERT INTO etl.DataTransferLogs
(
  DataTransferLogId
, TransferName
, TransferGroupName
, TargetTableName
, TargetSchemaName
, ExecStart
, SourceLastLoadDate
, DestinationLastLoadDate
, BatchLdts
)
SELECT 
  @DataTransferLogId 
, 'S4Hana_spProvNatDCsLast'
, 'NatDCs'
, 'NatDCs'
, 'ref'
, @ExecStart
, @SourceLastLoadDate
, @DestinationLastLoadDate
, @BatchLdts;

-- Log first DATA Informations END

WITH CTE_ArtificialDCs AS
(
	/*add artificial DCs*/
	SELECT 'ECM' AS Channel	UNION
	SELECT 'FOC' AS Channel	UNION
	SELECT 'FPS' AS Channel	UNION
	SELECT 'N/A' AS Channel	UNION
	SELECT 'CON' AS Channel	UNION
	SELECT 'WHS' AS Channel	UNION
	SELECT 'WHC' AS Channel	UNION
	SELECT 'FRA' AS Channel UNION
	SELECT NULL  AS Channel
)
, CTE_NatDC AS
(
	SELECT
	  CONCAT(CASE WHEN B.Channel IS NOT NULL THEN CONCAT(A.StoreCode, '_', B.Channel)
				  ELSE A.StoreCode
			 END, '|', D.CompanyCode)													AS NatDC_BK
	, @LoadDate																			AS CreatedOn
	, @LoadDate																			AS ModifiedOn
	, CASE WHEN B.Channel IS NOT NULL THEN CONCAT(A.StoreCode, '_', B.Channel)
		   ELSE A.StoreCode
	  END																				AS NatDCCode
	, D.CompanyCode																		AS CompanyCode
	, D.IntPupMasterId																	AS IntPupMasterId
	, D.PDUCode																			AS PDUCode
	, A.StoreName																		AS NatDCName
	, A.City																			AS City
	, A.Street																			AS Street
	, A.PostalCode																		AS PostalCode
	, B.Channel																			AS Channel
	, A.CountryCode																		AS CountryCode
	, E.ISOCountryDesc																	AS CountryDesc
	, A.DistributionChannelCode															AS DistChannelCode
	, F.[Description]																	AS DistChannelDesc
	, A.GSMCode																			AS GSMCode
	, CASE WHEN A.StoreName LIKE '%virtual%' THEN 20 
		   ELSE 50 
	  END																				AS IntDCTypeCode
	FROM stag.S4Hana_vPlants A
	CROSS JOIN CTE_ArtificialDCs B
	INNER JOIN pdwref.S4Hana_Interfaces D ON A.SalesOrganizationCode = D.SalesOrg
	INNER JOIN pdwref.ISOCountries E ON A.CountryCode = E.ISOCountryCode
	LEFT JOIN stag.S4Hana_vPUMADistributionChannelTexts F ON A.DistributionChannelCode = F.Code
	WHERE A.PlantCategoryCode = 'B'
	AND (
		 A.LDTS >= @LDTS
		)
)

--Insert to temp table
SELECT
  NatDC_BK
, CreatedOn
, ModifiedOn
, NatDCCode
, CompanyCode
, IntPupMasterId
, PDUCode
, CONVERT([BINARY](16), HASHBYTES('MD5',CONCAT(
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), NatDC_BK)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), NatDCCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CompanyCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), IntPupMasterId)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PDUCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), NatDCName)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), City)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), Street)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PostalCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), Channel)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CountryCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CountryDesc)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), DistChannelCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), DistChannelDesc)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), GSMCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), IntDCTypeCode))))
	))) AS HashDiff
, NatDCName
, City
, Street
, PostalCode
, Channel
, CountryCode
, CountryDesc
, DistChannelCode
, DistChannelDesc
, GSMCode
, IntDCTypeCode
INTO #NatDCs
FROM CTE_NatDC

--Count Records to be updated
SELECT @AffectedRows = COUNT(*)
FROM ref.NatDCs A
INNER JOIN #NatDCs B ON A.NatDC_BK = B.NatDC_BK
WHERE A.HashDiff <> B.HashDiff

--Update Final Table
UPDATE A SET
  A.ModifiedOn = @LoadDate
, A.NatDCCode = B.NatDCCode
, A.CompanyCode = B.CompanyCode
, A.IntPupMasterId = B.IntPupMasterId
, A.PDUCode = B.PDUCode
, A.HashDiff = B.HashDiff
, A.NatDCName = B.NatDCName
, A.City = B.City
, A.Street = B.Street
, A.PostalCode = B.PostalCode
, A.Channel = B.Channel
, A.CountryCode = B.CountryCode
, A.CountryDesc = B.CountryDesc
, A.DistChannelCode = B.DistChannelCode
, A.DistChannelDesc = B.DistChannelDesc
, A.GSMCode = B.GSMCode
, A.IntDCTypeCode = B.IntDCTypeCode
FROM ref.NatDCs A
INNER JOIN #NatDCs B ON A.NatDC_BK = B.NatDC_BK
WHERE A.HashDiff <> B.HashDiff

--Log count of updated records
UPDATE DTlogs SET
  Updated = @AffectedRows
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

--Count Records to be inserted
SELECT @AffectedRows = COUNT(*)
FROM #NatDCs A
LEFT JOIN ref.NatDCs B ON A.NatDC_BK = B.NatDC_BK
WHERE B.NatDC_BK IS NULL

--Insert to Final Table
INSERT INTO ref.NatDCs
(
  NatDC_BK
, CreatedOn
, ModifiedOn
, NatDCCode
, CompanyCode
, IntPupMasterId
, PDUCode
, HashDiff
, NatDCName
, City
, Street
, PostalCode
, Channel
, CountryCode
, CountryDesc
, DistChannelCode
, DistChannelDesc
, GSMCode
, IntDCTypeCode
)
SELECT
  A.NatDC_BK
, A.CreatedOn
, A.ModifiedOn
, A.NatDCCode
, A.CompanyCode
, A.IntPupMasterId
, A.PDUCode
, A.HashDiff
, A.NatDCName
, A.City
, A.Street
, A.PostalCode
, A.Channel
, A.CountryCode
, A.CountryDesc
, A.DistChannelCode
, A.DistChannelDesc
, A.GSMCode
, A.IntDCTypeCode
FROM #NatDCs A
LEFT JOIN ref.NatDCs B ON A.NatDC_BK = B.NatDC_BK
WHERE B.NatDC_BK IS NULL

--Log count of inserted records
UPDATE DTlogs SET 
  Inserted = @AffectedRows
, ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId