﻿CREATE PROC [dbo].[S4Hana_spProvNatCustomerBusinessPartner_DS_V02] @LDTS [DATETIME2](7) AS

DECLARE @LoadDate DATETIME2(7) = GETDATE();

IF OBJECT_ID('tempdb..#NatCustomerBusinessPartner') IS NOT NULL DROP TABLE #NatCustomerBusinessPartner;

-- logging informations - BEGIN
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(0) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(0)
DECLARE @DestinationLastLoadDate DATETIME2(0)
DECLARE @BatchLdts DATETIME2(0) = @LDTS
DECLARE @AffectedRows BIGINT = NULL
-- logging Informations - END

-- get last LDTS Informations for Logging
IF(EXISTS(SELECT 1 FROM [ref].[NatCustomerBusinessPartner_DS_V02]))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(ModifiedOn))
		FROM [ref].[NatCustomerBusinessPartner_DS_V02]
	END
ELSE 
	BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

IF(EXISTS(SELECT 1 FROM [biz].[S4Hana_CustomerBusinessPartner]))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(LDTS))
		FROM [biz].[S4Hana_CustomerBusinessPartner]
	END
ELSE 
	BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END
-- Logging Informations END


-- Log first DATA Informations

INSERT INTO etl.DataTransferLogs
(
  DataTransferLogId
, TransferName
, TransferGroupName
, TargetTableName
, TargetSchemaName
, ExecStart
, SourceLastLoadDate
, DestinationLastLoadDate
, BatchLdts
)
SELECT 
  @DataTransferLogId 
, 'S4Hana_spProvNatCustomerBusinessPartner_DS_V02'
, 'NatCustomerBusinessPartner_DS_V02'
, 'NatCustomerBusinessPartner_DS_V02'
, 'ref'
, @ExecStart
, @SourceLastLoadDate
, @DestinationLastLoadDate
, @BatchLdts;

-- Log first DATA Informations END
WITH CTE AS
( 
	SELECT CONCAT(A.BPRelationNo, '|', A.But051customer, '|', A.But051partner, '|',c.[CustomerAccountGroup], '|',a.[But051Function]) AS NatCustomerBusinessPartner_BK
	  ,@LoadDate	AS CreatedOn
	  ,@LoadDate	AS ModifiedOn
	  ,a.[BPRelationNo]
      ,a.[But051customer]
      ,a.[But051partner]
      ,a.[But051validto]
	  ,c.[CustomerAccountGroup]
	  ,b.[SalesOrganization]
      ,a.[DescPartner1]
      ,a.[DescPartner2]
      ,a.[But051Reltyp]
      ,a.[RelationDesc]
      ,a.[But051roledef]
      ,a.[But051FunctionName]
      ,a.[But051Function]
      ,a.[FunctionDesc]
      ,a.[But051CompDept]
      ,a.[But051Departm]
      ,a.[But051Auth]
      ,a.[But051Vip]
      ,a.[But051Note]
      ,a.[But051telNo]
      ,a.[But051Telext]
      ,a.[But051FaxNo]
      ,a.[But051FaxExt]
      ,a.[But051Email]
      ,a.[But051Curr]
      ,a.[But051Ruleid]
      ,a.[But051RuleidVisitm]
      ,a.[But051RuleCall]
      ,a.[But051RuleVisit]
      ,a.[But051Dummy1]
      ,a.[But051Dummy2]
      ,a.[BPRelationNo050]
      ,a.[customer050]
      ,a.[partner2050]
      ,a.[validto050]
      ,a.[Validfrom050]
      ,a.[reltyp050]
      ,a.[roledef050]
      ,a.[reltype050]
      ,a.[CreationDate050]
      ,a.[ChangeDat050]
      ,a.[Relkinddesc]
	  ,a.IsDeleted

FROM [biz].[S4Hana_CustomerBusinessPartner] a
left join (SELECT DISTINCT CUSTOMER, SalesOrganization FROM [biz].[S4Hana_CustomerSalesAttributes]) b on a.[But051customer]=b.[Customer]
left join biz.[S4Hana_Customers] c on a.[But051customer]=c.[Customer]
--inner join [pdwref].[AreaCodeMapping] acm on b.[SalesOrganization]= acm.SalesOrganization
	WHERE
	b.[SalesOrganization] is not null
	AND (A.LDTS >= @LDTS
	OR C.LDTS >= @LDTS)

)

--Insert to temp table
SELECT 
	   NatCustomerBusinessPartner_BK
	  ,IsDeleted
	  ,CreatedOn
	  ,ModifiedOn
	  ,[BPRelationNo]
	  ,[But051customer]
	  ,[But051partner]
	  ,[But051validto]
      ,[CustomerAccountGroup]
	  ,[SalesOrganization]
      ,[DescPartner1]
      ,[DescPartner2]
      ,[But051Reltyp]
      ,[RelationDesc]
      ,[But051roledef]
      ,[But051FunctionName]
      ,[But051Function]
      ,[FunctionDesc]
      ,[But051CompDept]
      ,[But051Departm]
	  ,[But051Auth]
	  ,[But051Vip]
	  ,[But051Note]
	  ,[But051telNo]
	  ,[But051Telext]
	  ,[But051FaxNo]
	  ,[But051FaxExt]
	  ,[But051Email]
	  ,[But051Curr]
	  ,[But051Ruleid]
	  ,[But051RuleidVisitm]
	  ,[But051RuleCall]
	  ,[But051RuleVisit]
	  ,[But051Dummy1]
	  ,[But051Dummy2]
	  ,[BPRelationNo050]
	  ,[customer050]
	  ,[partner2050]
	  ,[validto050]
	  ,[Validfrom050]
	  ,[reltyp050]
	  ,[roledef050]
	  ,[reltype050]
	  ,[CreationDate050]
	  ,[ChangeDat050]
	  ,[Relkinddesc]
	  ,CONVERT([BINARY](16), HASHBYTES('MD5',CONCAT(
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), NatCustomerBusinessPartner_BK    )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), IsDeleted					 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [BPRelationNo]				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051customer]				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051partner]				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051validto]				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [CustomerAccountGroup]		 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [SalesOrganization]			 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DescPartner1]				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DescPartner2]				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051Reltyp]				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [RelationDesc]				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051roledef]				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051FunctionName]			 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051Function]				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [FunctionDesc]				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051CompDept]				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051Departm]				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051Auth]					 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051Vip]					 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051Note]					 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051telNo]				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051Telext]				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051FaxNo]				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051FaxExt]				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051Email]				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051Curr]					 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051Ruleid]				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051RuleidVisitm]			 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051RuleCall]				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051RuleVisit]			 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051Dummy1]				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [But051Dummy2]				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [BPRelationNo050]			 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [customer050]				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [partner2050]				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [validto050]					 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [Validfrom050]				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [reltyp050]					 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [roledef050]					 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [reltype050]					 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [CreationDate050]			 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [ChangeDat050]				 )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [Relkinddesc]))))
	))) AS HashDiff
	
INTO #NatCustomerBusinessPartner
FROM CTE

--Count Records to be updated
SELECT @AffectedRows = COUNT(*)
FROM [ref].[NatCustomerBusinessPartner_DS_V02] A
INNER JOIN #NatCustomerBusinessPartner B ON A.NatCustomerBusinessPartner_BK = B.NatCustomerBusinessPartner_BK
WHERE A.HashDiff <> B.HashDiff

--Update Final Table
UPDATE A SET
  A.ModifiedOn = @LoadDate
, A.NatCustomerBusinessPartner_BK = B.NatCustomerBusinessPartner_BK
, A.IsDeleted					  = B.IsDeleted					
, A.[BPRelationNo]				  = B.[BPRelationNo]				
, A.[But051customer]			  = B.[But051customer]			
, A.[But051partner]				  = B.[But051partner]				
, A.[But051validto]				  = B.[But051validto]				
, A.[CustomerAccountGroup]		  = B.[CustomerAccountGroup]		
, A.[SalesOrganization]			  = B.[SalesOrganization]							
, A.[DescPartner1]				  = B.[DescPartner1]				
, A.[DescPartner2]				  = B.[DescPartner2]				
, A.[But051Reltyp]				  = B.[But051Reltyp]				
, A.[RelationDesc]				  = B.[RelationDesc]				
, A.[But051roledef]				  = B.[But051roledef]				
, A.[But051FunctionName]		  = B.[But051FunctionName]		
, A.[But051Function]			  = B.[But051Function]			
, A.[FunctionDesc]				  = B.[FunctionDesc]				
, A.[But051CompDept]			  = B.[But051CompDept]			
, A.[But051Departm]				  = B.[But051Departm]				
, A.[But051Auth]				  = B.[But051Auth]				
, A.[But051Vip]					  = B.[But051Vip]					
, A.[But051Note]				  = B.[But051Note]				
, A.[But051telNo]				  = B.[But051telNo]				
, A.[But051Telext]				  = B.[But051Telext]				
, A.[But051FaxNo]				  = B.[But051FaxNo]				
, A.[But051FaxExt]				  = B.[But051FaxExt]				
, A.[But051Email]				  = B.[But051Email]				
, A.[But051Curr]				  = B.[But051Curr]				
, A.[But051Ruleid]				  = B.[But051Ruleid]				
, A.[But051RuleidVisitm]		  = B.[But051RuleidVisitm]		
, A.[But051RuleCall]			  = B.[But051RuleCall]			
, A.[But051RuleVisit]			  = B.[But051RuleVisit]			
, A.[But051Dummy1]				  = B.[But051Dummy1]				
, A.[But051Dummy2]				  = B.[But051Dummy2]				
, A.[BPRelationNo050]			  = B.[BPRelationNo050]			
, A.[customer050]				  = B.[customer050]				
, A.[partner2050]				  = B.[partner2050]				
, A.[validto050]				  = B.[validto050]				
, A.[Validfrom050]				  = B.[Validfrom050]				
, A.[reltyp050]					  = B.[reltyp050]					
, A.[roledef050]				  = B.[roledef050]				
, A.[reltype050]				  = B.[reltype050]				
, A.[CreationDate050]			  = B.[CreationDate050]			
, A.[ChangeDat050]				  = B.[ChangeDat050]				
, A.[Relkinddesc]				  = B.[Relkinddesc]
,A.HashDiff  = B.HashDiff

FROM [ref].[NatCustomerBusinessPartner_DS_V02] A
INNER JOIN #NatCustomerBusinessPartner B ON A.NatCustomerBusinessPartner_BK = B.NatCustomerBusinessPartner_BK
WHERE A.HashDiff <> B.HashDiff and B.IsDeleted = 0

--update deletion status
UPDATE A SET
	   A.ModifiedOn = @LoadDate
	  ,A.IsDeleted = 1
	  ,A.HashDiff  = B.HashDiff

FROM [ref].[NatCustomerBusinessPartner_DS_V02] A
INNER JOIN #NatCustomerBusinessPartner B ON A.NatCustomerBusinessPartner_BK = B.NatCustomerBusinessPartner_BK
WHERE A.HashDiff <> B.HashDiff and B.IsDeleted = 1


--Log count of updated records
UPDATE DTlogs SET
  Updated = @AffectedRows
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

--Count Records to be inserted
SELECT @AffectedRows = COUNT(*)
FROM #NatCustomerBusinessPartner A
LEFT JOIN [ref].[NatCustomerBusinessPartner_DS_V02] B ON A.NatCustomerBusinessPartner_BK = B.NatCustomerBusinessPartner_BK
WHERE B.NatCustomerBusinessPartner_BK IS NULL

--Insert to Final Table
INSERT INTO [ref].[NatCustomerBusinessPartner_DS_V02]
(
      NatCustomerBusinessPartner_BK
     ,IsDeleted
     ,CreatedOn
     ,ModifiedOn
     ,[BPRelationNo]
     ,[But051customer]
     ,[But051partner]
     ,[But051validto]
     ,[CustomerAccountGroup]
     ,[SalesOrganization]
     ,[DescPartner1]
     ,[DescPartner2]
     ,[But051Reltyp]
     ,[RelationDesc]
     ,[But051roledef]
     ,[But051FunctionName]
     ,[But051Function]
     ,[FunctionDesc]
     ,[But051CompDept]
     ,[But051Departm]
     ,[But051Auth]
	 ,[But051Vip]
	 ,[But051Note]
	 ,[But051telNo]
	 ,[But051Telext]
	 ,[But051FaxNo]
	 ,[But051FaxExt]
	 ,[But051Email]
	 ,[But051Curr]
	 ,[But051Ruleid]
	 ,[But051RuleidVisitm]
	 ,[But051RuleCall]
	 ,[But051RuleVisit]
	 ,[But051Dummy1]
	 ,[But051Dummy2]
	 ,[BPRelationNo050]
	 ,[customer050]
	 ,[partner2050]
	 ,[validto050]
	 ,[Validfrom050]
	 ,[reltyp050]
	 ,[roledef050]
	 ,[reltype050]
	 ,[CreationDate050]
	 ,[ChangeDat050]
	 ,[Relkinddesc]
	 ,Hashdiff
	  )
SELECT
	   A.NatCustomerBusinessPartner_BK
      ,A.IsDeleted
      ,A.CreatedOn
      ,A.ModifiedOn
	  ,A.[BPRelationNo]
      ,A.[But051customer]
      ,A.[But051partner]
      ,A.[But051validto]
      ,A.[CustomerAccountGroup]
      ,A.[SalesOrganization]
      ,A.[DescPartner1]
      ,A.[DescPartner2]
      ,A.[But051Reltyp]
      ,A.[RelationDesc]
      ,A.[But051roledef]
      ,A.[But051FunctionName]
      ,A.[But051Function]
      ,A.[FunctionDesc]
      ,A.[But051CompDept]
      ,A.[But051Departm]
      ,A.[But051Auth]
	  ,A.[But051Vip]
	  ,A.[But051Note]
	  ,A.[But051telNo]
	  ,A.[But051Telext]
	  ,A.[But051FaxNo]
	  ,A.[But051FaxExt]
	  ,A.[But051Email]
	  ,A.[But051Curr]
	  ,A.[But051Ruleid]
	  ,A.[But051RuleidVisitm]
	  ,A.[But051RuleCall]
	  ,A.[But051RuleVisit]
	  ,A.[But051Dummy1]
	  ,A.[But051Dummy2]
	  ,A.[BPRelationNo050]
	  ,A.[customer050]
	  ,A.[partner2050]
	  ,A.[validto050]
	  ,A.[Validfrom050]
	  ,A.[reltyp050]
	  ,A.[roledef050]
	  ,A.[reltype050]
	  ,A.[CreationDate050]
	  ,A.[ChangeDat050]
	  ,A.[Relkinddesc]
	  ,A.Hashdiff
FROM #NatCustomerBusinessPartner A
LEFT JOIN [ref].[NatCustomerBusinessPartner_DS_V02] B ON A.NatCustomerBusinessPartner_BK = B.NatCustomerBusinessPartner_BK
WHERE B.NatCustomerBusinessPartner_BK IS NULL

--Log count of inserted records
UPDATE DTlogs SET 
  Inserted = @AffectedRows
, ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId