﻿CREATE PROC [dbo].[S4Hana_spSOCurrentAccumulated_Copa_Update] @ldts [VARCHAR](255) AS  
BEGIN

	--SET NOCOUNT ON;
	SET ANSI_WARNINGS ON;

	DECLARE @LDTSDate DATETIME = CAST(CAST(@ldts AS DATETIME2) AS SMALLDATETIME);
	
			--list of updated BKs
			IF OBJECT_ID('tempdb..#COPA_BKS') IS NOT NULL DROP TABLE #COPA_BKS;
			SELECT DISTINCT co.NatSalesOrderNo,
							co.NatSalesOrderItemNo,
							co.NatArticle_BK, 
							co.CompanyCode,
							max(co.NatSOTypeCode) as NatSOTypeCode
				INTO #COPA_BKS			  
				FROM sales.NatCopaDetails co JOIN pdwref.S4Hana_SalesTypes AS st ON co.NatSOTypeCode = st.SOTypeCode
				WHERE co.ModifiedOn >= @LDTSDate AND co.NatSalesOrderNo <> ''
				group by co.NatSalesOrderNo,
						co.NatSalesOrderItemNo,
						co.NatArticle_BK, 
						co.CompanyCode

			--Calculations for VBRK
			IF OBJECT_ID('tempdb..#COPA_AGG') IS NOT NULL DROP TABLE #COPA_AGG;
			SELECT c.NatSalesOrderNo
				  ,c.NatSalesOrderItemNo 
				  ,c.NatArticle_BK 
				  ,c.CompanyCode
				  ,MAX(c.CreationDate)					AS InvoiceCreationDate 
				  ,MAX(c.PostingDate)					AS InvoicePostingDate 
				  ,MAX(c.CreatedOn)						AS InvoiceCreatedOn 
				  ,MAX(c.ModifiedOn)					AS InvoiceModifiedOn 
				  ,STRING_AGG(c.ReferenceDocNo,',')		AS InvoiceNo 
				  ,STRING_AGG(c.ReferenceDocItemNo,',')	AS InvoiceItemNo 
				  ,STRING_AGG(c.NatInvoiceTypeCode,',')	AS InvoiceTypeCode 
				  ,STRING_AGG(it.EBPDesc,',')			AS InvoiceTypeDesc  
				  ,MAX(c.NatCustomerBillTo_BK)			AS InvoiceNatCustomerBillTo_BK 
				  ,MAX(c.NatCustomerPayer_BK)			AS InvoiceNatCustomerPayer_BK 
				  ,MAX(c.NatCustomerShipTo_BK)			AS InvoiceNatCustomerShipTo_BK 
				   --Measures: 
				  ,SUM(c.InvoicedSalesUnits)			AS InvoiceQty 
			   -- ,SUM(c.TotalCogsLC)					AS InvoiceLandedCostLC -- Landed costs needs all ReferenceDocumentTypes
				  ,SUM(c.InvoicedSalesLC)				AS InvoiceInvoicedSalesValueLC 
				  ,SUM(c.GrossSalesLC)					AS InvoiceGrossValueLC
				  ,SUM(c.NetSalesLC)					AS InvoiceNetSalesLC
				INTO #COPA_AGG
				FROM sales.NatCopaDetails AS c 
				INNER JOIN #COPA_BKS c0 ON c0.NatSalesOrderNo = c.NatSalesOrderNo 
					AND c0.NatSalesOrderItemNo = c.NatSalesOrderItemNo 
					AND c0.NatArticle_BK = c.NatArticle_BK 
					AND c0.CompanyCode	 = c.CompanyCode
				INNER JOIN pdwref.S4Hana_SalesTypes AS st ON c.NatSOTypeCode = st.SOTypeCode
				LEFT JOIN pdwref.S4Hana_InvoiceRecTypes AS it ON c.NatInvoiceTypeCode = it.EBPIndicator 
				WHERE c.ReferenceDocumentType = 'VBRK'
				GROUP BY c.NatSalesOrderNo,
						 c.NatSalesOrderItemNo,
						 c.NatArticle_BK, 
						 c.CompanyCode

			--Calculation of InvoiceLandedCostLC
			IF OBJECT_ID('tempdb..#COGS') IS NOT NULL DROP TABLE #COGS;
			SELECT c.NatSalesOrderNo
				  ,c.NatSalesOrderItemNo 
				  ,c.NatArticle_BK 
				  ,c.CompanyCode
				   --Measures: 
			      ,SUM(c.TotalCogsLC)					AS InvoiceLandedCostLC 
				INTO #COGS
				FROM sales.NatCopaDetails AS c 
				INNER JOIN #COPA_BKS c0 ON c0.NatSalesOrderNo = c.NatSalesOrderNo 
					AND c0.NatSalesOrderItemNo = c.NatSalesOrderItemNo 
					AND c0.NatArticle_BK = c.NatArticle_BK 
					AND c0.CompanyCode	 = c.CompanyCode
				INNER JOIN pdwref.S4Hana_SalesTypes AS st ON c.NatSOTypeCode = st.SOTypeCode
				LEFT JOIN pdwref.S4Hana_InvoiceRecTypes AS it ON c.NatInvoiceTypeCode = it.EBPIndicator
				GROUP BY c.NatSalesOrderNo,
						 c.NatSalesOrderItemNo,
						 c.NatArticle_BK, 
						 c.CompanyCode
				
	  
			 --remove duplicates from STRING_AGG fields
			 IF OBJECT_ID('tempdb..#TMP_STAG') IS NOT NULL DROP TABLE #TMP_STAG;
				SELECT a.NatSalesOrderNo
					  ,a.NatSalesOrderItemNo
					  ,a.NatArticle_BK 
					  ,a.CompanyCode
					  ,a.InvoiceCreationDate 
					  ,a.InvoicePostingDate 
					  ,a.InvoiceCreatedOn 
					  ,a.InvoiceModifiedOn 
					  ,LEFT(CASE WHEN InvoiceNo LIKE '%,%' 
						THEN (SELECT STRING_AGG(InvNo,',') WITHIN GROUP (ORDER BY InvNo) FROM (SELECT DISTINCT value AS InvNo FROM STRING_SPLIT(InvoiceNo,',')) t) 
						ELSE InvoiceNo			END,500) AS InvoiceNo 
					  ,CASE WHEN InvoiceItemNo LIKE '%,%' 
						THEN (SELECT STRING_AGG(InvItemNo,',') WITHIN GROUP (ORDER BY InvItemNo) FROM (SELECT DISTINCT value AS InvItemNo FROM STRING_SPLIT(InvoiceItemNo,',')) t)
						ELSE InvoiceItemNo		END AS InvoiceItemNo
					  ,CASE WHEN InvoiceTypeCode LIKE '%,%' 
						THEN (SELECT STRING_AGG(InvTypeCode,',') WITHIN GROUP (ORDER BY InvTypeCode) FROM (SELECT DISTINCT value AS InvTypeCode FROM STRING_SPLIT(InvoiceTypeCode,',')) t)
						ELSE InvoiceTypeCode	END AS InvoiceTypeCode
					  ,CASE WHEN InvoiceTypeDesc LIKE '%,%' 
						THEN (SELECT STRING_AGG(InvTypeDesc,',') WITHIN GROUP (ORDER BY InvTypeDesc) FROM (SELECT DISTINCT value AS InvTypeDesc FROM STRING_SPLIT(InvoiceTypeDesc,',')) t)
						ELSE InvoiceTypeDesc	END AS InvoiceTypeDesc 
					  ,a.InvoiceNatCustomerBillTo_BK 
					  ,a.InvoiceNatCustomerPayer_BK 
					  ,a.InvoiceNatCustomerShipTo_BK 
					  ,a.InvoiceQty 
					  ,b.InvoiceLandedCostLC 
					  ,a.InvoiceInvoicedSalesValueLC 
					  ,a.InvoiceGrossValueLC
					  ,a.InvoiceNetSalesLC
				INTO #TMP_STAG
				FROM #COPA_AGG a
				LEFT JOIN #COGS b on a.NatSalesOrderNo = b.NatSalesOrderNo
								  and a.NatSalesOrderItemNo = b.NatSalesOrderItemNo
								  and a.NatArticle_BK = b.NatArticle_BK
								  and a.CompanyCode = b.CompanyCode;


	--delete inherited invoice data for deleted SOs from Sales Order Accumulated Table
	UPDATE dest 
			SET dest.InvoiceCreationDate			= NULL
			   ,dest.InvoicePostingDate				= NULL
			   ,dest.InvoiceCreatedOn				= NULL
			   ,dest.InvoiceModifiedOn				= NULL
			   ,dest.InvoiceNo						= NULL
			   ,dest.InvoiceItemNo					= NULL
			   ,dest.InvoiceTypeCode				= NULL
			   ,dest.InvoiceTypeDesc				= NULL
			   ,dest.InvoiceNatCustomerBillTo_BK	= NULL
			   ,dest.InvoiceNatCustomerPayer_BK		= NULL
			   ,dest.InvoiceNatCustomerShipTo_BK	= NULL
			   ,dest.InvoiceQty						= NULL
			   ,dest.InvoiceLandedCostLC			= NULL
			   ,dest.InvoiceInvoicedSalesValueLC	= NULL
			   ,dest.InvoiceGrossValueLC			= NULL
			   ,dest.InvoiceNetSalesLC		     	= NULL

		FROM sales.NatSalesOrderCurrentAccumulated AS dest JOIN #TMP_STAG AS stag ON dest.NatSalesOrderNo = stag.NatSalesOrderNo 
																						AND dest.NatArticle_BK = stag.NatArticle_BK 
																						AND dest.CompanyCode = stag.CompanyCode																						
																						AND Active = 0
																						AND dest.InvoiceNo <> ''



	--identify first Sales Order Item in case of multiple that is not deactivated
	IF OBJECT_ID('tempdb..#TMP_STAG_RANK') IS NOT NULL DROP TABLE #TMP_STAG_RANK;
	
			select  
				 dest.NatSalesOrderNo
				,dest.NatSalesOrderItemNo
				,dest.NatCustomer_BK
				,dest.NatArticle_BK
				,dest.CompanyCode 
				,dest.NatSOTypeCode
				,CASE
					WHEN NatSOTypeCode in ('ZMKC','ZROC','ZRES','ZCCD')  --contract type codes
						THEN CASE WHEN RIGHT(dest.NatSalesOrderItemNo,3)='OOH' THEN --when calloff
						 RANK() OVER (PARTITION BY (CASE WHEN RIGHT(dest.NatSalesOrderItemNo,3)='OOH' THEN concat(dest.NatSalesOrderNo,left(dest.NatSalesOrderItemNo,6)) ELSE NULL END),dest.NatCustomer_BK,dest.NatArticle_BK  
									  ORDER BY CASE WHEN SOStatusCode = 1 THEN 3
										            WHEN SOStatusCode = 2 THEN 4
										            WHEN SOStatusCode = 3 THEN 1
										            WHEN SOStatusCode = 5 THEN 2 END ASC, dest.NatSalesOrderItemNo ) ELSE NULL END -- rank only calloffs items
					ELSE  1 /*RANK() OVER (PARTITION BY dest.NatSalesOrderNo,dest.NatCustomer_BK,dest.NatArticle_BK  
									  ORDER BY CASE WHEN SOStatusCode = 1 THEN 3
												    WHEN SOStatusCode = 2 THEN 4
												    WHEN SOStatusCode = 3 THEN 1
												    WHEN SOStatusCode = 5 THEN 2 END ASC, dest.NatSalesOrderItemNo )*/ END as [rank] --else rank normally
				,stag.InvoiceCreationDate			
			    ,stag.InvoicePostingDate				
			    ,stag.InvoiceCreatedOn				
			    ,stag.InvoiceModifiedOn				
			    ,stag.InvoiceNo						
			    ,stag.InvoiceItemNo					
			    ,stag.InvoiceTypeCode				
			    ,stag.InvoiceTypeDesc				
			    ,stag.InvoiceNatCustomerBillTo_BK	
			    ,stag.InvoiceNatCustomerPayer_BK		
			    ,stag.InvoiceNatCustomerShipTo_BK	
			    ,stag.InvoiceQty						
			    ,stag.InvoiceLandedCostLC			
			    ,stag.InvoiceInvoicedSalesValueLC	
			    ,stag.InvoiceGrossValueLC			
			    ,stag.InvoiceNetSalesLC
			into #TMP_STAG_RANK
			from  sales.NatSalesOrderCurrentAccumulated dest 
			INNER JOIN #TMP_STAG AS stag ON dest.NatSalesOrderNo = stag.NatSalesOrderNo 
										AND left(dest.NatSalesOrderItemNo,6) = stag.NatSalesOrderItemNo 
										AND dest.NatArticle_BK = stag.NatArticle_BK 
										AND dest.CompanyCode = stag.CompanyCode
										AND Active = 1
		

		-- assign values only for first item
		IF OBJECT_ID('tempdb..#RESULT') IS NOT NULL DROP TABLE #RESULT;
			select
				NatSalesOrderNo
				,NatSalesOrderItemNo
				,NatCustomer_BK
				,NatArticle_BK
				,CompanyCode 
				,CASE WHEN RANK = 1 THEN InvoiceCreationDate ELSE NULL END AS InvoiceCreationDate 
				,CASE WHEN RANK = 1 THEN InvoicePostingDate	 ELSE NULL END AS InvoicePostingDate	 
				,CASE WHEN RANK = 1 THEN InvoiceCreatedOn	 ELSE NULL END AS InvoiceCreatedOn	 
				,CASE WHEN RANK = 1 THEN InvoiceModifiedOn	 ELSE NULL END AS InvoiceModifiedOn	 
				,CASE WHEN RANK = 1 THEN InvoiceNo			 ELSE NULL END AS InvoiceNo			 
				,CASE WHEN RANK = 1 THEN InvoiceItemNo		 ELSE NULL END AS InvoiceItemNo		 
				,CASE WHEN RANK = 1 THEN InvoiceTypeCode	 ELSE NULL END AS InvoiceTypeCode	 
				,CASE WHEN RANK = 1 THEN InvoiceTypeDesc	 ELSE NULL END AS InvoiceTypeDesc	 
				,CASE WHEN RANK = 1 THEN InvoiceNatCustomerBillTo_BK	ELSE NULL END AS InvoiceNatCustomerBillTo_BK
				,CASE WHEN RANK = 1 THEN InvoiceNatCustomerPayer_BK		ELSE NULL END AS InvoiceNatCustomerPayer_BK	
				,CASE WHEN RANK = 1 THEN InvoiceNatCustomerShipTo_BK	ELSE NULL END AS InvoiceNatCustomerShipTo_BK
				,CASE WHEN RANK = 1 THEN InvoiceQty						ELSE NULL END AS InvoiceQty					
				,CASE WHEN RANK = 1 THEN InvoiceLandedCostLC			ELSE NULL END AS InvoiceLandedCostLC		
				,CASE WHEN RANK = 1 THEN InvoiceInvoicedSalesValueLC	ELSE NULL END AS InvoiceInvoicedSalesValueLC
				,CASE WHEN RANK = 1 THEN InvoiceGrossValueLC			ELSE NULL END AS InvoiceGrossValueLC		
				,CASE WHEN RANK = 1 THEN InvoiceNetSalesLC				ELSE NULL END AS InvoiceNetSalesLC	
			into #RESULT
			from #TMP_STAG_RANK
 


			--Update dest table
			UPDATE dest 
			SET dest.InvoiceCreationDate			= stag.InvoiceCreationDate 
			   ,dest.InvoicePostingDate				= stag.InvoicePostingDate 
			   ,dest.InvoiceCreatedOn				= stag.InvoiceCreatedOn 
			   ,dest.InvoiceModifiedOn				= stag.InvoiceModifiedOn 
			   ,dest.InvoiceNo						= stag.InvoiceNo 
			   ,dest.InvoiceItemNo					= stag.InvoiceItemNo 
			   ,dest.InvoiceTypeCode				= stag.InvoiceTypeCode 
			   ,dest.InvoiceTypeDesc				= stag.InvoiceTypeDesc 
			   ,dest.InvoiceNatCustomerBillTo_BK	= stag.InvoiceNatCustomerBillTo_BK 
			   ,dest.InvoiceNatCustomerPayer_BK		= stag.InvoiceNatCustomerPayer_BK 
			   ,dest.InvoiceNatCustomerShipTo_BK	= stag.InvoiceNatCustomerShipTo_BK 
			   ,dest.InvoiceQty						= stag.InvoiceQty 
			   ,dest.InvoiceLandedCostLC			= stag.InvoiceLandedCostLC 
			   ,dest.InvoiceInvoicedSalesValueLC	= stag.InvoiceInvoicedSalesValueLC 
			   ,dest.InvoiceGrossValueLC			= stag.InvoiceGrossValueLC 
			   ,dest.InvoiceNetSalesLC		     	= stag.InvoiceNetSalesLC 

		    FROM sales.NatSalesOrderCurrentAccumulated AS dest JOIN #RESULT AS stag ON dest.NatSalesOrderNo = stag.NatSalesOrderNo 
																						AND dest.NatSalesOrderItemNo = stag.NatSalesOrderItemNo
																						AND dest.NatArticle_BK = stag.NatArticle_BK 
																						AND dest.CompanyCode = stag.CompanyCode;	


			--EBPRP-391-- Update Sales Order Status for 'ZDIS','ZCLB','ZTWR' based on Invoice data

			WITH cte_01 AS 
			 		  (SELECT distinct NatSalesOrderNo
			 				  ,NatSalesOrderItemNo
			 				  ,CompanyCode
			 				  ,NatSOTypeCode
			    FROM #COPA_BKS where NatSOTypeCode in ('ZDIS','ZCLB','ZTWR')
				
				UNION
				
				--include SOs with invoices that were modified from SO side (LDTS from SO)
			    SELECT DISTINCT so.NatSalesOrderNo, 
							  so.NatSalesOrderItemNo, 
							  so.CompanyCode,
							  so.NatSOTypeCode		  
				FROM [sales].[NatSalesOrderCurrentAccumulated] so INNER JOIN sales.NatCopaDetails co on so.NatSalesOrderNo=co.NatSalesOrderNo
				and so.NatSalesOrderItemNo = co.NatSalesOrderItemNo
				WHERE so.ModifiedOn >= @LDTSDate and so.NatSOTypeCode in ('ZDIS','ZCLB','ZTWR'))
			,sum_cte AS
			          (SELECT  a.NatSalesOrderNo
			                  ,a.NatSalesOrderItemNo
							  ,a.CompanyCode
			                  ,max(InvoiceQty) as InvoiceQty
			                  ,sum(Qty) as SOQty
			    FROM [sales].[NatSalesOrderCurrentAccumulated] a
			    INNER JOIN cte_01 c01 on a.NatSalesOrderNo=c01.NatSalesOrderNo and a.NatSalesOrderItemNo=c01.NatSalesOrderItemNo and a.CompanyCode=c01.CompanyCode
				WHERE a.SOStatusCode <> 2
				GROUP BY 
				 a.NatSalesOrderNo
				,a.NatSalesOrderItemNo
				,a.CompanyCode)
			,status_cte AS 
					  (SELECT  NatSalesOrderNo
			                  ,NatSalesOrderItemNo
							  ,CompanyCode
							  ,CASE 
									WHEN InvoiceQty>=SOQty THEN 3
									WHEN InvoiceQty > 0 and InvoiceQty < SOQty THEN 5
									ELSE 1 END AS InvStatusCode
			                  ,CASE 
									WHEN InvoiceQty>=SOQty THEN 'Shipped'
									WHEN InvoiceQty > 0 and InvoiceQty < SOQty THEN 'Partially Shipped'
									ELSE 'Open' END AS InvStatusDesc
			                  FROM sum_Cte)

			--Update dest table
			UPDATE dest 
			SET dest.SOStatusCode	= stag.InvStatusCode 
			   ,dest.SOStatusDesc	= stag.InvStatusDesc 

		    FROM sales.NatSalesOrderCurrentAccumulated AS dest 
			JOIN status_cte AS stag ON dest.NatSalesOrderNo = stag.NatSalesOrderNo 
								   AND dest.NatSalesOrderItemNo   = stag.NatSalesOrderItemNo 
								   AND dest.CompanyCode     = stag.CompanyCode
								   AND dest.SOStatusCode    <> 2 ;	

	
	IF OBJECT_ID('tempdb..#Overcalloffs') IS NOT NULL DROP TABLE #Overcalloffs;
	-- FLAGS
	
		SELECT NatSalesOrderNo
		,LEFT(NatSalesOrderItemNo,6) NatSalesOrderItemNo
		INTO #Overcalloffs
		from [sales].[NatSalesOrderCurrentAccumulated]  a
		inner join [pdwref].[S4Hana_SalesTypes] b on a.NatSOTypeCode = b.SOTypeCode
		where active = 1 and sostatuscode=1 and IsFinanceOOH = 1
		GROUP BY NatSalesOrderNo,LEFT(NatSalesOrderItemNo,6)
		HAVING SUM(qty) < 0

		--set flags to 0
		UPDATE dest 
		SET dest.OverCalloffFlag	= 0 
		FROM sales.NatSalesOrderCurrentAccumulated AS dest 
		where dest.OverCalloffFlag <> 0
		

		--Update flags
		UPDATE dest 
		SET dest.OverCalloffFlag	= 1
		FROM sales.NatSalesOrderCurrentAccumulated AS dest 
		JOIN #Overcalloffs AS stag ON dest.NatSalesOrderNo = stag.NatSalesOrderNo 
		AND LEFT(dest.NatSalesOrderItemNo,6)   = stag.NatSalesOrderItemNo 

 	IF OBJECT_ID('tempdb..#ExpiredContracts') IS NOT NULL DROP TABLE #ExpiredContracts;
	
		SELECT distinct
		NatSalesOrderNo
		,NatSalesOrderItemNo
		into #ExpiredContracts
		from [sales].[NatSalesOrderCurrentAccumulated]  a
		inner join [pdwref].[S4Hana_SalesTypes] b on a.NatSOTypeCode = b.SOTypeCode
		where IsFinanceOOH = 1 and a.NatSOTypeCode IN ('ZPOC', 'ZROC', 'ZCSC', 'ZMKC', 'ZCOC', 'ZRES' ,'ZCCD' ,'ZCLS' ,'ZARC')
		AND ContractValidTo < CONVERT(VARCHAR(8), GETDATE(), 112)
		
		--set flags to 0
		UPDATE dest 
		SET dest.ExpiredContractsFlag	= 0 
		FROM sales.NatSalesOrderCurrentAccumulated AS dest 
		where dest.ExpiredContractsFlag <> 0
		

		--Update flags
		UPDATE dest 
		SET dest.ExpiredContractsFlag	= 1
		FROM sales.NatSalesOrderCurrentAccumulated AS dest 
		JOIN #ExpiredContracts AS stag ON dest.NatSalesOrderNo = stag.NatSalesOrderNo 
		AND LEFT(dest.NatSalesOrderItemNo,6)   = stag.NatSalesOrderItemNo 


--exec [dbo].[S4Hana_spSOCurrentAccumulated_Copa_Update] '19000101'

 END