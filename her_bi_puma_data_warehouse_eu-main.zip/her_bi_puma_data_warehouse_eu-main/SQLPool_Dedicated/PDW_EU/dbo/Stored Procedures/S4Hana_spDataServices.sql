﻿CREATE PROC [dbo].[S4Hana_spDataServices] AS
BEGIN
SET NOCOUNT ON;
SET ANSI_WARNINGS ON;

--First load of all DS tables needs to be manual in order to put entry into [etl].[DataTransferLogs]
/*
EXEC [dbo].[S4Hana_spProvNatBPAddressEmail_DS_V02]				'20250616'		
EXEC [dbo].[S4Hana_spProvNatBPAddresses_DS_v02]					'20250616'
EXEC [dbo].[S4Hana_spProvNatBPAddressTelefon_DS_V02]			'20250616'
EXEC [dbo].[S4Hana_spProvNatBPGeneralData1_DS_V02]				'20250616'
EXEC [dbo].[S4Hana_spProvNatCustomerBusinessPartner_DS_V02]		'20250616'
EXEC [dbo].[S4Hana_spProvNatCustomerSalesAttributesLast_DS_V02]	'20250616'
EXEC [dbo].[S4Hana_spProvNatCustomerSalesPartners_DS_V02]		'20250616'
EXEC [dbo].[S4Hana_spProvNatCustomersLast_DS_V02]				'20250616'
EXEC [dbo].[S4Hana_spProvNatMaterials_DS_V02]					'20250616'
EXEC [dbo].[S4Hana_spProvNatMaterialSalesAttributes_DS_V02]		'20250616'
*/

IF OBJECT_ID('tempdb..#cur') IS NOT NULL DROP TABLE #cur;
select name as name  into #cur from sys.tables where name like '%_DS_V02'
--select * from #cur

declare @sql2 nvarchar(max)
declare @Tablename nvarchar(100)
declare @LDTS nvarchar(100)
declare @sp nvarchar(100)
WHILE (SELECT count(1) FROM #cur) > 0
		BEGIN
			SELECT TOP(1) @Tablename = name from #cur
			select @LDTS = coalesce(max(SourceLastLoadDate),'19000101'), @sp = max(TransferName) from [etl].[DataTransferLogs] where TargetTableName = @Tablename and execend is not NULL
			select @sql2 = concat( 'exec dbo.',@sp,' ','''',@LDTS,'''')
			--print concat(@tablename,' | ',@sp,' | ',@LDTS,' | ',@sql2 )
			EXECUTE sp_executesql @sql2;

            DELETE FROM #cur WHERE name = @Tablename
		END
END