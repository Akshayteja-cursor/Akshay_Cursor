﻿CREATE PROC [dbo].[S4Hana_spProvNatStoresLast] @LDTS [DATETIME2](7) AS

DECLARE @LoadDate DATETIME2(7) = GETDATE();

IF OBJECT_ID('tempdb..#NatStores') IS NOT NULL DROP TABLE #NatStores;

-- logging informations - BEGIN
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(0) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(0)
DECLARE @DestinationLastLoadDate DATETIME2(0)
DECLARE @BatchLdts DATETIME2(0) = @LDTS
DECLARE @AffectedRows BIGINT = NULL
-- logging Informations - END

-- get last LDTS Informations for Logging
IF(EXISTS(SELECT 1 FROM ref.NatStores))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(modifiedOn))
		FROM ref.NatStores
	END
ELSE 
	BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

IF(EXISTS(SELECT 1 FROM ref.NatStores))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(modifiedOn))
		FROM ref.NatStores
	END
ELSE 
	BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END
-- Logging Informations END


-- Log first DATA Informations

INSERT INTO etl.DataTransferLogs
(
  DataTransferLogId
, TransferName
, TransferGroupName
, TargetTableName
, TargetSchemaName
, ExecStart
, SourceLastLoadDate
, DestinationLastLoadDate
, BatchLdts
)
SELECT 
  @DataTransferLogId 
, 'S4Hana_spProvNatStoresLast'
, 'NatStores'
, 'NatStores'
, 'ref'
, @ExecStart
, @SourceLastLoadDate
, @DestinationLastLoadDate
, @BatchLdts;

-- Log first DATA Informations END

WITH CTE_NatStores AS
(
	SELECT
	  CONCAT(A.StoreCode, '|', C.CompanyCode)						AS NatStore_BK
	, @LoadDate														AS CreatedOn
	, @LoadDate														AS ModifiedOn
	, A.StoreCode													AS NatStoreCode
	, C.CompanyCode													AS CompanyCode
	, C.IntPupMasterId												AS IntPupMasterId
	, C.PDUCode														AS PDUCode
	, A.StoreName													AS NatStoreName
	, A.City														AS City
	, A.Street														AS Street
	, A.PostalCode													AS PostalCode
	, A.CountryCode													AS CountryCode
	, D.ISOCountryDesc												AS CountryDesc
	, A.DistributionChannelCode										AS DistChannelCode
	, E.[Description]												AS DistChannelDesc
	, A.GSMCode														AS GSMCode
	, CASE WHEN LEFT(A.StoreCode, 1) = 'A' THEN 10 
		   ELSE 60
	  END															AS IntDCTypeCode
	FROM stag.S4Hana_vPlants A
	INNER JOIN pdwref.S4Hana_Interfaces C ON A.SalesOrganizationCode = C.SalesOrg
	INNER JOIN pdwref.ISOCountries D ON A.CountryCode = D.ISOCountryCode
	LEFT JOIN stag.S4Hana_vPUMADistributionChannelTexts E ON A.DistributionChannelCode = E.Code
	WHERE A.PlantCategoryCode = 'A'
	AND (
		 A.LDTS >= @LDTS
		)
)
--Insert to temp table
SELECT
  NatStore_BK
, CreatedOn
, ModifiedOn
, NatStoreCode
, CompanyCode
, IntPupMasterId
, PDUCode
, CONVERT([BINARY](16), HASHBYTES('MD5',CONCAT(
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), NatStore_BK)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), NatStoreCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CompanyCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), IntPupMasterId)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PDUCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), NatStoreName)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), City)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), Street)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PostalCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CountryCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CountryDesc)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), DistChannelCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), DistChannelDesc)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), GSMCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), IntDCTypeCode))))
  ))) AS HashDiff
, NatStoreName
, City
, Street
, PostalCode
, CountryCode
, CountryDesc
, DistChannelCode
, DistChannelDesc
, GSMCode
, IntDCTypeCode
INTO #NatStores
FROM CTE_NatStores

--Count Records to be updated
SELECT @AffectedRows = COUNT(*)
FROM ref.NatStores A
INNER JOIN #NatStores B ON A.NatStore_BK = B.NatStore_BK
WHERE A.HashDiff <> B.HashDiff

--Update Final Table
UPDATE A SET
  A.ModifiedOn = @LoadDate
, A.NatStoreCode = B.NatStoreCode
, A.CompanyCode = B.CompanyCode
, A.IntPupMasterId = B.IntPupMasterId
, A.PDUCode = B.PDUCode
, A.HashDiff = B.HashDiff
, A.NatStoreName = B.NatStoreName
, A.City = B.City
, A.Street = B.Street
, A.PostalCode = B.PostalCode
, A.CountryCode = B.CountryCode
, A.CountryDesc = B.CountryDesc
, A.DistChannelCode = B.DistChannelCode
, A.DistChannelDesc = B.DistChannelDesc
, A.GSMCode = B.GSMCode
, A.IntDCTypeCode = B.IntDCTypeCode
FROM ref.NatStores A
INNER JOIN #NatStores B ON A.NatStore_BK = B.NatStore_BK
WHERE A.HashDiff <> B.HashDiff

--Log count of updated records
UPDATE DTlogs SET
  Updated = @AffectedRows
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

--Count Records to be inserted
SELECT @AffectedRows = COUNT(*)
FROM #NatStores A
LEFT JOIN ref.NatStores B ON A.NatStore_BK = B.NatStore_BK
WHERE B.NatStore_BK IS NULL

--Insert to Final Table
INSERT INTO ref.NatStores
(
  NatStore_BK
, CreatedOn
, ModifiedOn
, NatStoreCode
, CompanyCode
, IntPupMasterId
, PDUCode
, HashDiff
, NatStoreName
, City
, Street
, PostalCode
, CountryCode
, CountryDesc
, DistChannelCode
, DistChannelDesc
, GSMCode
, IntDCTypeCode
)
SELECT
  A.NatStore_BK
, A.CreatedOn
, A.ModifiedOn
, A.NatStoreCode
, A.CompanyCode
, A.IntPupMasterId
, A.PDUCode
, A.HashDiff
, A.NatStoreName
, A.City
, A.Street
, A.PostalCode
, A.CountryCode
, A.CountryDesc
, A.DistChannelCode
, A.DistChannelDesc
, A.GSMCode
, A.IntDCTypeCode
FROM #NatStores A
LEFT JOIN ref.NatStores B ON A.NatStore_BK = B.NatStore_BK
WHERE B.NatStore_BK IS NULL

--Log count of inserted records
UPDATE DTlogs SET 
  Inserted = @AffectedRows
, ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId