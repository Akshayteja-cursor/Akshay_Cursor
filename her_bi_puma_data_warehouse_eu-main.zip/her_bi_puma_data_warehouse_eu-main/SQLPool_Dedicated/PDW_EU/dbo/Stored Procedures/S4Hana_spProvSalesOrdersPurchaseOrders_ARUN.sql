﻿CREATE PROC [dbo].[S4Hana_spProvSalesOrdersPurchaseOrders_ARUN] @LDTS [DATETIME2](7) AS   
BEGIN
	SET NOCOUNT ON;
	SET ANSI_WARNINGS ON;

	DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
	DECLARE @ExecStart DATETIME2(7) = GETDATE()
	DECLARE @SourceLastLoadDate DATETIME2(7)
	DECLARE @DestinationLastLoadDate DATETIME2(7) = '1990-01-01'
	DECLARE @BatchLdts DATETIME2(7) = @LDTS
	DECLARE @AffectedRows BIGINT = NULL


	IF OBJECT_ID(N'tempdb..#Result') IS NOT NULL
	DROP TABLE #Result;
	IF OBJECT_ID(N'tempdb..#Late') IS NOT NULL
	DROP TABLE #Late;
		IF OBJECT_ID(N'tempdb..#onTime') IS NOT NULL
	DROP TABLE #onTime;
			IF OBJECT_ID(N'tempdb..#ResultHash') IS NOT NULL
	DROP TABLE #ResultHash;
			IF OBJECT_ID(N'tempdb..#MinMaxDD') IS NOT NULL
	DROP TABLE #MinMaxDD;

	--Log Data load
	INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,SourceLastLoadDate
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'S4Hana_spProvSalesOrdersPurchaseOrders_ARUN'
			,'SalesOrdersPurchaseOrders'
			,'SalesOrdersPurchaseOrders'
			,'sales'
			,@ExecStart
			,@SourceLastLoadDate
			,@DestinationLastLoadDate
			,@BatchLdts

	IF @DestinationLastLoadDate >= @ldts 
		BEGIN 
			SELECT @DestinationLastLoadDate= @ldts
		END

;
WITH cte_ontime AS (
    SELECT
        arun.SalesOrderNo,
        arun.SalesOrderItemNo,
        arun.PONo,
        arun.Delivery_Date_PO,
        arun.ALLOC_QTY
    FROM [biz].[S4Hana_SoDocumentItems]      AS so
    JOIN biz.[S4Hana_ARUN_SDO_ALLDOC]   AS arun
      ON so.SalesDocument      = arun.SalesOrderNo
     AND so.SalesDocumentItem  = arun.SalesOrderItemNo
	 AND arun.IsDeleted              = 0
	 AND so.IsDeleted              = 0
    WHERE arun.SalesOrderNo           <> ''
      AND arun.supplytype             <> 'C'
      AND arun.Delivery_Date_PO       <=  so.RequestedDeliveryDate
)
SELECT
    f.SalesOrderNo,
    f.SalesOrderItemNo,
    (
        SELECT STRING_AGG(d.PONo, ',') WITHIN GROUP (ORDER BY d.PONo)
        FROM (
            SELECT DISTINCT PONo
            FROM cte_ontime d
            WHERE d.SalesOrderNo      = f.SalesOrderNo
              AND d.SalesOrderItemNo  = f.SalesOrderItemNo
        ) AS d
    ) AS PONo_ontime,
    MAX(f.Delivery_Date_PO) AS PoDate_ontime,
    SUM(f.ALLOC_QTY)        AS qty_ontime
	into #onTime
FROM cte_ontime AS f
GROUP BY
    f.SalesOrderNo,
    f.SalesOrderItemNo;


;WITH cte_late AS (
    SELECT
        arun.SalesOrderNo,
        arun.SalesOrderItemNo,
        arun.PONo,
        arun.Delivery_Date_PO,
        arun.ALLOC_QTY
    FROM [biz].[S4Hana_SoDocumentItems]      AS so
    JOIN biz.[S4Hana_ARUN_SDO_ALLDOC]   AS arun
      ON so.SalesDocument      = arun.SalesOrderNo
     AND so.SalesDocumentItem  = arun.SalesOrderItemNo
	 AND arun.IsDeleted              = 0
	 AND so.IsDeleted              = 0
    WHERE arun.SalesOrderNo           <> ''
      AND arun.supplytype             <> 'C'
      AND arun.Delivery_Date_PO       >  so.RequestedDeliveryDate
)
SELECT
    f.SalesOrderNo,
    f.SalesOrderItemNo,
    (
        SELECT STRING_AGG(d.PONo, ',') WITHIN GROUP (ORDER BY d.PONo)
        FROM (
            SELECT DISTINCT PONo
            FROM cte_late d
            WHERE d.SalesOrderNo      = f.SalesOrderNo
              AND d.SalesOrderItemNo  = f.SalesOrderItemNo
        ) AS d
    ) AS PONo_Late,
    MAX(f.Delivery_Date_PO) AS PoDate_late,
    SUM(f.ALLOC_QTY)        AS qty_late
	into #late
FROM cte_late AS f
GROUP BY
    f.SalesOrderNo,
    f.SalesOrderItemNo;

;
SELECT
        arun.SalesOrderNo,
        arun.SalesOrderItemNo,
        MIN(arun.Delivery_Date_PO) AS MinDate,
		MAX(arun.Delivery_Date_PO) AS MaxDate
	INTO #MinMaxDD
FROM biz.[S4Hana_ARUN_SDO_ALLDOC] AS arun
WHERE supplytype <> 'C'
and  arun.SalesOrderNo <> ''
AND arun.IsDeleted = 0
GROUP BY  arun.SalesOrderNo,
		  arun.SalesOrderItemNo;


;WITH cte_all AS
	 (
		 SELECT DISTINCT
			 SalesOrderNo,
			 SalesOrderItemNo,
			 LDTS
		 FROM
			biz.[S4Hana_ARUN_SDO_ALLDOC]
		 WHERE
			 1            =1
		 AND IsDeleted    = 0
	)
, cte_c AS
	 (
		 select
			 SalesOrderNo    ,
			 SalesOrderItemNo,
			 sum(ALLOC_QTY)AS qty_ONStock
		 FROM
			 biz.[S4Hana_ARUN_SDO_ALLDOC]
		 WHERE
			 supplytype   = 'C'
		 AND IsDeleted    = 0
		 AND SalesOrderNo <> ''
		 GROUP BY
			 SalesOrderNo,
			 SalesOrderItemNo )
select
	a.SalesOrderNo    ,
	a.SalesOrderItemNo,
	a.LDTS			  ,
	b.PONo_Late       ,
	b.qty_late        ,
	b.PoDate_late     ,
	l.PONo_ONtime     ,
	l.PoDate_ONTime   ,
	l.qty_ONtime      ,
	c.qty_ONStock,
	mm.MinDate	,
	mm.MaxDate
	INTO #Result
FROM
	cte_all a
LEFT JOIN
	#late b
ON
	a.SalesOrderNo     = b.SalesOrderNo
AND a.SalesOrderItemNo = b.SalesOrderItemNo
LEFT JOIN
	#ontime l
ON
	a.SalesOrderNo     = l.SalesOrderNo
AND a.SalesOrderItemNo = l.SalesOrderItemNo
LEFT JOIN
	cte_c c
ON
	a.SalesOrderNo     = c.SalesOrderNo
AND a.SalesOrderItemNo = c.SalesOrderItemNo
LEFT JOIN #MinMaxDD mm
ON
	a.SalesOrderNo     = mm.SalesOrderNo
AND a.SalesOrderItemNo = mm.SalesOrderItemNo
WHERE	1=1;



select SalesOrderNo      ,
    SalesOrderItemNo  ,
    PONo_Late         ,
    qty_late          ,
    PoDate_late       ,
    PONo_ONtime       ,
    PoDate_ONTime     ,
    qty_ONtime        ,
    qty_ONStock       ,
	MinDate			  ,
	MaxDate			  ,	
	LDTS, 
	 CONVERT([BINARY](16), 
			HASHBYTES('MD5',CONCAT( 
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),SalesOrderNo )))),'_', 
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),SalesOrderItemNo )))),'_', 
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),PONo_Late )))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),qty_late )))),'_', 
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),PoDate_late )))),'_', 
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),PONo_ONtime )))),'_', 
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),PoDate_ONTime )))),'_', 
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),qty_ONtime )))),'_', 
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),MinDate )))),'_', 
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),MaxDate )))),'_', 
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),qty_ONStock)))))) 

			) HashDiff
	INTO #ResultHash
	FROM #Result

   
  TRUNCATE TABLE sales.NatSalesOrderPurchaseOrders;
  --load new
  INSERT INTO sales.NatSalesOrderPurchaseOrders

   (NatSalesOrderNo,
    NatSalesOrderItemNo,
    NatPurchaseOrders_Late         ,
    units_late          ,
    PO_Delivery_Date_Late       ,
    NatPurchaseOrders_OnTime       ,
    PO_Delivery_Date_OnTime     ,
    units_OnTime        ,
    units_OnStock       ,
	Min_NatPODeliveryDate,
	Max_NatPODeliveryDate,
	LDTS ,
	HashDiff 
	)
	SELECT 
				stg.SalesOrderNo      ,
				stg.SalesOrderItemNo  ,
				stg.PONo_Late         ,
				stg.qty_late          ,
				stg.PoDate_late       ,
				stg.PONo_ONtime       ,
				stg.PoDate_ONTime     ,
				stg.qty_ONtime        ,
				stg.qty_ONStock       ,
				stg.MinDate			  ,
				stg.MaxDate			  ,
				stg.LDTS		      ,
				stg.HashDiff
		FROM #ResultHash AS stg 

---- count new Records for S4Hana_ARUN_SDO_ALLDOC
        SELECT @AffectedRows = COUNT(*)
		FROM #ResultHash 
  
----Log count of inserted records
UPDATE DTlogs SET 
  Inserted = @AffectedRows
, ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId
  
END
