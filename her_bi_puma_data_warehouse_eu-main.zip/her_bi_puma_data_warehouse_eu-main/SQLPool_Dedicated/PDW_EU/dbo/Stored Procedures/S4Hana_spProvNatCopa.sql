﻿CREATE PROC [dbo].[S4Hana_spProvNatCopa] @ldts [VARCHAR](255) AS   
BEGIN

	--SET NOCOUNT ON;
	SET ANSI_WARNINGS ON;

	DECLARE @LDTSDate DATETIME = CAST(CAST(@ldts AS DATETIME2) AS DATETIME);
	DECLARE @LoadDate SMALLDATETIME = GETDATE();

	IF OBJECT_ID('tempdb..#TMP_raw') IS NOT NULL DROP TABLE #TMP_raw;
	IF OBJECT_ID('tempdb..#TMP_window') IS NOT NULL DROP TABLE #TMP_window;
	IF OBJECT_ID('tempdb..#TMP_STAG_COPA') IS NOT NULL DROP TABLE #TMP_STAG_COPA;
	--TRUNCATE TABLE etl.[TMP_COPA] /*Added by Reza*/

	;WITH cte_bk_list AS  (
	--create a list of BK values to process
	SELECT DISTINCT i.RegionCode,
					COALESCE(co.CustomerCode_SoldTo,'') AS CustomerCode_SoldTo,
					co.FiscalYear,
					co.NatSalesOrderNo,
					COALESCE(co.MaterialNumber,'') 		AS NatMaterialNo,
					co.CompanyCode
	FROM stag.S4Hana_fnCopaRaw(@LDTSDate) co JOIN pdwref.S4Hana_COPA_BillTypeBusClass ref	ON ref.BillingDocTypeCode = co.BillingDocTypeCode
															 JOIN pdwref.S4Hana_Interfaces i ON co.CompanyCode = i.CompanyCode AND i.IntPupMasterId <> 1425
	WHERE ref.BusinessClassCode <> 50
	), 
	CTE0 AS ( 
			SELECT co.CompanyCode
				  ,co.AccountingDocNo
				  ,co.ReferenceDocNo
				  ,co.ReferenceDocItemNo
				  ,co.ReferenceDocumentType
				  ,COALESCE(co.MaterialNumber,'') 				AS NatMaterialNo   
				  ,co.FiscalYear
				  ,co.ProfitCenterCode
				  ,co.NatSalesOrderNo  
				  ,d1.DateKey									AS CreationDate  
				  ,d2.DateKey									AS PostingDate
				  ,d2.YYYYMM									AS PostingDate_YYYYMM
				  ,co.BrandCode
				  ,co.RBUCode
				  ,co.RefRBUCode   
				  ,co.BusSegmentCode
				  ,co.BusSubSegmentCode
				  ,co.DistributionChannelCode
				  ,CAST(COALESCE(TRY_CAST(co.ProdDivCode  AS INT), 0) AS INT)				AS ProdDivCode 
				  ,COALESCE(co.CustomerCode_SoldTo,'')										AS CustomerCode_SoldTo
				  ,co.CurrencyCode
				  ,co.GroupKey
				  ,co.SOTypeCode															AS NatSOTypeCode
				  ,co.BillingDocTypeCode													AS NatInvoiceTypeCode
				  ,ref.BusinessClassCode
				 ,COALESCE(CAST(co.AmountInCompanyCodeCurrency * 100 AS DECIMAL(24,8))/100,0) * (-1)											     AS AmountInCompanyCodeCurrency --100 added due to issue with decimal
				  ,COALESCE(CAST(co.Quantity AS DECIMAL(24,12)),0) * (-1)																			 AS Quantity 
				  ,tg.SemanticTag
				  ,CASE WHEN COALESCE(co.CustomerCode_SoldTo,'') = ''		THEN '' ELSE CONCAT(co.CustomerCode_SoldTo ,'|',i.CompanyCode)		END	 AS NatCustomer_BK
				  ,CASE WHEN COALESCE(co.SalesRep,			 '') = ''		THEN '' ELSE CONCAT(co.SalesRep,'|',i.CompanyCode)					END	 AS NatSalesman_BK
				  ,CASE WHEN COALESCE(co.CustomerCode_ShipTo,'') = ''		THEN '' ELSE CONCAT(co.CustomerCode_ShipTo,'|',i.CompanyCode)		END	 AS NatCustomerShipTo_BK
				  ,CASE WHEN COALESCE(co.Payer,				 '') = ''		THEN '' ELSE CONCAT(co.Payer,'|',i.CompanyCode)						END  AS NatCustomerPayer_BK
				  ,CASE WHEN COALESCE(co.CustomerCode_OwnerGroup,'') = ''	THEN '' ELSE CONCAT(co.CustomerCode_OwnerGroup,'|',i.CompanyCode)	END	 AS NatCustomerOwnerGroup_BK
				  ,CASE WHEN COALESCE(co.CustomerCode_BillTo,'') = ''		THEN '' ELSE CONCAT(co.CustomerCode_BillTo,'|',i.CompanyCode)		END  AS NatCustomerBillTo_BK
				  ,CASE WHEN COALESCE(co.Plant,				 '') = ''		THEN '' ELSE CONCAT(co.Plant,'|',i.CompanyCode)						END  AS NatStoreDC_BK -- Added company code to NatStoreDC 
				  ,i.IntPupMasterId  
				  ,i.PDUCode
			FROM stag.S4Hana_vCopaSemanticTags tg	JOIN stag.S4Hana_vCopaRaw co					ON tg.GLAccount				= co.GLAccount AND tg.ChartOfAccounts = co.ChartOfAccounts 
													JOIN pdwref.S4Hana_Interfaces i					ON co.CompanyCode			= i.CompanyCode AND i.IntPupMasterId <> 1425
													JOIN pdwref.S4Hana_COPA_BillTypeBusClass ref	ON ref.BillingDocTypeCode	= co.BillingDocTypeCode AND ref.BusinessClassCode <> 50
													JOIN pdwref.S4Hana_COPA_ActiveSemanticTags atg	ON atg.SemanticTag			= tg.SemanticTag AND atg.IsActive = 1		--filter only SematicTag valid for KPIs
													JOIN cte_bk_list f								ON  f.CustomerCode_SoldTo	= COALESCE(co.CustomerCode_SoldTo,'')		--first part of NatCustomerBK
																			AND f.FiscalYear			= co.FiscalYear 
																			AND f.NatSalesOrderNo		= co.NatSalesOrderNo 
																			AND f.NatMaterialNo			= COALESCE(co.MaterialNumber,'')  
																			AND f.CompanyCode			= co.CompanyCode
											   LEFT JOIN ref.DimDate d1								ON d1.CalendarDate = co.CreationDate
											   LEFT JOIN ref.DimDate d2								ON d2.CalendarDate = co.PostingDate
			WHERE f.RegionCode	= i.RegionCode /*second part of NatCustomerBK*/	
			),
	 ---- create "basic/atomic" KPI fieds 
	 CTEtag_to_fields AS (
	 					SELECT CompanyCode
						  ,AccountingDocNo
						  ,ReferenceDocNo
						  ,ReferenceDocItemNo
						  ,ReferenceDocumentType
						  ,NatMaterialNo
						  ,FiscalYear
						  ,ProfitCenterCode
						  ,NatSalesOrderNo  
						  ,CreationDate
						  ,PostingDate
						  ,PostingDate_YYYYMM
						  ,BrandCode
						  ,RBUCode
						  ,RefRBUCode   
						  ,BusSegmentCode
						  ,BusSubSegmentCode
						  ,DistributionChannelCode
						  ,ProdDivCode  
						  ,NatSalesman_BK
						  ,CustomerCode_SoldTo
						  ,NatCustomerShipTo_BK 
						  ,NatCustomerPayer_BK
						  ,NatCustomerOwnerGroup_BK 
						  ,NatCustomerBillTo_BK
						  ,NatStoreDC_BK
						  ,CurrencyCode
						  ,GroupKey
						  ,NatSOTypeCode
						  ,NatInvoiceTypeCode
						  ,BusinessClassCode
						  ,NatCustomer_BK
						  ,IntPupMasterId  
						  ,PDUCode
						  ,CASE WHEN cte.SemanticTag IN ('ZR3017GS3P','ZR3018GSIC','ZR3020GSBF')THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS GrossSalesLC
						  ,CASE WHEN cte.SemanticTag IN ('ZR3017GS3P','ZR3018GSIC','ZR3020GSBF')THEN cte.Quantity					 ELSE 0 END AS GrossSalesUnits 
						  ,CASE WHEN cte.SemanticTag IN ('ZR3024OIDS','ZR3026OIDI')				THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS OnInvoicePriceReductionsLC
						  ,CASE WHEN cte.SemanticTag IN ('ZR3024OIDS','ZR3026OIDI')				THEN cte.Quantity					 ELSE 0 END AS OnInvoicePriceReductionsUnits 
						  ,CASE WHEN cte.SemanticTag IN ('ZR3032SMSP','ZR3033GRSB','ZR3034DELP','ZR3038OIDA')THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS OffInvoicePriceReductionsLC
						  ,CASE WHEN cte.SemanticTag IN ('ZR3035RETM')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS RetailMarkdownLC
						  ,CASE WHEN cte.SemanticTag IN ('ZR3035RETM')							THEN cte.Quantity					 ELSE 0 END AS RetailMarkdownUnits  
						  ,CASE WHEN cte.SemanticTag IN ('ZR3040RASL')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS SalesAdjustmentsReturnProvisionLC
						  ,CASE WHEN cte.SemanticTag IN ('ZR3152OSA')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS OtherSalesAdjustmentsLC
						  ,CASE WHEN cte.SemanticTag IN ('ZR3041NSTP','ZR3042NSIC','ZR3044NSIF')THEN cte.Quantity					 ELSE 0 END AS NetSalesUnits
						  ,CASE WHEN cte.SemanticTag IN ('ZR3041NSTP','ZR3042NSIC','ZR3044NSIF')THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS NetSalesLC
						  ,CASE WHEN cte.SemanticTag IN ('ZR3046CFTP','ZR3062CFIC','ZR3066CBMP')THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS CogsAtFPriceLC
						  ,CASE WHEN cte.SemanticTag IN ('ZR3059ICCM')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS IcCogsChargesAndMarkupLC  
						  ,CASE WHEN cte.SemanticTag IN ('ZR3069SHRT')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS ShortageLC
						  ,CASE WHEN cte.SemanticTag IN ('ZR3073CIIR')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS ChangeInInventoryReserveLC
						  ,CASE WHEN cte.SemanticTag IN ('ZR3153OCA')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS CogsOtherAdjustmentsLC
						  ,CASE WHEN cte.SemanticTag IN ('ZR3077RACG')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS CogsAdjustmentsReturnsLC
						  --For Calculated KPIs:
						  ,CASE WHEN cte.SemanticTag IN ('ZR3070COGF')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS COGS_Inventory_Revaluation_Transfer
						  ,CASE WHEN cte.SemanticTag IN ('ZR3071OCOG')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS Others_Cost_of_Goods_Warranties
						  ,CASE WHEN cte.SemanticTag IN ('ZR3074CGLD')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS Currency_gain_loss_from_derivates_COGS
						  ,CASE WHEN cte.SemanticTag IN ('ZR3066CBMP')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS COGS_BFT_MAP
						  ,CASE WHEN cte.SemanticTag IN ('ZR3068CBMU')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS COGS_BFT_Markup
						  ,CASE WHEN cte.SemanticTag IN ('ZR3052MCTP')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS Mgmt_COGS_3rd_F_Price_Duty_Freight_Insurance
						  ,CASE WHEN cte.SemanticTag IN ('ZR3064CGIC')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS COGS_IC_Sales
					FROM CTE0 AS cte) 
		--grouping and KPI calculation
					--INSERT INTO etl.[TMP_COPA] /*using persistent table instead of tmp table cause insufficient memory error_ Reza*/
					SELECT 	CompanyCode
					  ,AccountingDocNo
					  ,ReferenceDocNo
					  ,ReferenceDocItemNo
					  ,ReferenceDocumentType
					  ,NatMaterialNo
					  ,FiscalYear
					  ,ProfitCenterCode
					  ,NatSalesOrderNo  
					  ,MAX(CreationDate)					AS CreationDate
					  ,MAX(PostingDate)						AS PostingDate
					  ,PostingDate_YYYYMM
					  ,BrandCode
					  ,RBUCode
					  ,RefRBUCode   
					  ,BusSegmentCode
					  ,BusSubSegmentCode
					  ,DistributionChannelCode
					  ,ProdDivCode  
					  ,NatSalesman_BK
					  ,CustomerCode_SoldTo
					  ,NatCustomerShipTo_BK 
					  ,NatCustomerPayer_BK
					  ,NatCustomerOwnerGroup_BK 
					  ,NatCustomerBillTo_BK
					  ,NatStoreDC_BK
					  ,CurrencyCode
					  ,GroupKey
					  ,NatSOTypeCode
					  ,NatInvoiceTypeCode
					  ,BusinessClassCode
					  ,NatCustomer_BK
					  ,IntPupMasterId  
					  ,PDUCode
					  --------
					  ,SUM(NetSalesUnits)						AS NetSalesUnits
					  ,SUM(GrossSalesLC)						AS GrossSalesLC
					  ,SUM(OnInvoicePriceReductionsLC)			AS OnInvoicePriceReductionsLC
					  ,SUM(OffInvoicePriceReductionsLC)			AS OffInvoicePriceReductionsLC
					  ,SUM(RetailMarkdownLC)					AS RetailMarkdownLC
					  ,SUM(SalesAdjustmentsReturnProvisionLC)	AS SalesAdjustmentsReturnProvisionLC
					  ,SUM(OtherSalesAdjustmentsLC)				AS OtherSalesAdjustmentsLC
					  ,SUM(NetSalesLC)							AS NetSalesLC
					  ,SUM(CogsAtFPriceLC)						AS CogsAtFPriceLC
					  ,SUM(ShortageLC)							AS ShortageLC
					  ,SUM(ChangeInInventoryReserveLC)			AS ChangeInInventoryReserveLC
					  ,SUM(CogsOtherAdjustmentsLC)				AS CogsOtherAdjustmentsLC
					  ,SUM(CogsAdjustmentsReturnsLC)			AS CogsAdjustmentsReturnsLC
					  --KPIs
					  --Cluster
					  ,CASE WHEN BusinessClassCode = 10 THEN SUM(GrossSalesLC) + SUM(OnInvoicePriceReductionsLC) + SUM(RetailMarkdownLC)
							WHEN BusinessClassCode = 30 THEN SUM(GrossSalesLC) + SUM(OnInvoicePriceReductionsLC)
							WHEN BusinessClassCode = 50 THEN SUM(GrossSalesLC)
							ELSE 0 END																																			AS InvoicedSalesLC
					  ,CASE WHEN BusinessClassCode = 10 THEN SUM(GrossSalesUnits) + SUM(OnInvoicePriceReductionsUnits) + SUM(RetailMarkdownUnits)
							WHEN BusinessClassCode = 30 THEN SUM(GrossSalesUnits) + SUM(OnInvoicePriceReductionsUnits)
							WHEN BusinessClassCode = 50 THEN SUM(GrossSalesUnits) 
							ELSE 0 END																																			AS InvoicedSalesUnits 
					  ,CASE WHEN BusinessClassCode = 10 THEN SUM(GrossSalesLC) + SUM(OnInvoicePriceReductionsLC) + SUM(RetailMarkdownLC) + SUM(OffInvoicePriceReductionsLC)
							WHEN BusinessClassCode = 30 THEN SUM(GrossSalesLC) + SUM(OnInvoicePriceReductionsLC) + SUM(RetailMarkdownLC)
							WHEN BusinessClassCode = 50 THEN SUM(GrossSalesLC) + SUM(OnInvoicePriceReductionsLC) + SUM(RetailMarkdownLC) 					  
							ELSE 0 END																																			AS OffInvoiceSales 
					  --COGS
					  ,CASE WHEN BusinessClassCode = 10 THEN SUM(COGS_Inventory_Revaluation_Transfer)+SUM(Others_Cost_of_Goods_Warranties) + SUM(Currency_gain_loss_from_derivates_COGS) 
							ELSE 0 END																																			AS OtherCOGSLS
					  ,CASE WHEN BusinessClassCode = 10 THEN SUM(Mgmt_COGS_3rd_F_Price_Duty_Freight_Insurance)+ SUM(IcCogsChargesAndMarkupLC) /*3rd*/
						    WHEN BusinessClassCode = 30 THEN SUM(COGS_IC_Sales)+ SUM(IcCogsChargesAndMarkupLC)
						    WHEN BusinessClassCode = 50 THEN SUM(COGS_BFT_MAP)+ SUM(COGS_BFT_Markup) 
							ELSE 0 END																																			AS CogsAtLandedCostLC
					  ,CASE WHEN BusinessClassCode = 10 THEN SUM(Mgmt_COGS_3rd_F_Price_Duty_Freight_Insurance) + 
															SUM(IcCogsChargesAndMarkupLC) + 
															SUM(ShortageLC) + 
															SUM(CogsAdjustmentsReturnsLC) + 
															SUM(CogsOtherAdjustmentsLC) + 
															SUM(ChangeInInventoryReserveLC) +
															SUM(COGS_Inventory_Revaluation_Transfer) + 
															SUM(Others_Cost_of_Goods_Warranties)+
															SUM(Currency_gain_loss_from_derivates_COGS) 
							WHEN BusinessClassCode = 30 THEN SUM(COGS_IC_Sales)+ SUM(IcCogsChargesAndMarkupLC) /*IC*/ 
							WHEN BusinessClassCode = 50 THEN SUM(COGS_BFT_MAP)+SUM(COGS_BFT_Markup) /*BFT*/
							ELSE 0 END																																			AS TotalCogsLC
						,CASE WHEN BusinessClassCode = 10 THEN SUM(Mgmt_COGS_3rd_F_Price_Duty_Freight_Insurance) + 
																SUM(ShortageLC) +
																SUM(CogsAdjustmentsReturnsLC)+
																SUM(CogsOtherAdjustmentsLC)
							ELSE 0 END																																			AS MgmtCogsAtCostLC

						--Profit KPIs:
						,SUM(GrossSalesLC) + SUM(CogsAtFPriceLC)																												AS ProductProfitOnFPriceLC
						,CASE WHEN BusinessClassCode = 10 THEN SUM(GrossSalesLC) + SUM(Mgmt_COGS_3rd_F_Price_Duty_Freight_Insurance)/*3rd*/ 
							  WHEN BusinessClassCode = 30 THEN SUM(GrossSalesLC) + SUM(COGS_IC_Sales) /*IC*/ 
							  WHEN BusinessClassCode = 50 THEN SUM(GrossSalesLC) + SUM(COGS_BFT_MAP) + SUM(COGS_BFT_Markup)/*BFT*/												
							  ELSE 0 END																																		AS ProductProfitOn3rdPartyLandedCostLC
						,CASE WHEN BusinessClassCode = 10 THEN SUM(NetSalesLC) + SUM(Mgmt_COGS_3rd_F_Price_Duty_Freight_Insurance)/*3rd*/
							  WHEN BusinessClassCode = 30 THEN SUM(NetSalesLC) + SUM(COGS_IC_Sales) /*IC*/  
							  WHEN BusinessClassCode = 50 THEN SUM(NetSalesLC) + SUM(COGS_BFT_MAP) + SUM(COGS_BFT_Markup)/*BFT*/
							  ELSE 0 END																																		AS MgmtGrossProfitOn3rdPartyLandedCostLC
						,CASE WHEN BusinessClassCode = 10 THEN SUM(NetSalesLC) + 
																SUM(Mgmt_COGS_3rd_F_Price_Duty_Freight_Insurance) + 
																SUM(ShortageLC) + 
																SUM(CogsAdjustmentsReturnsLC) + 
																SUM(CogsOtherAdjustmentsLC) + 
																SUM(ChangeInInventoryReserveLC) +
																SUM(COGS_Inventory_Revaluation_Transfer) + 
																SUM(Others_Cost_of_Goods_Warranties) +
																SUM(Currency_gain_loss_from_derivates_COGS) 
							 ELSE 0 END																																			AS MgmtGrossProfitLC 
						,CASE WHEN BusinessClassCode = 10 THEN SUM(NetSalesLC) + SUM(Mgmt_COGS_3rd_F_Price_Duty_Freight_Insurance) + SUM(IcCogsChargesAndMarkupLC) 
							  WHEN BusinessClassCode = 30 THEN SUM(NetSalesLC) + SUM(COGS_IC_Sales) /*IC specific*/ + SUM(IcCogsChargesAndMarkupLC)
							  WHEN BusinessClassCode = 50 THEN SUM(NetSalesLC) + SUM(COGS_BFT_MAP) + SUM(COGS_BFT_Markup) 
							  ELSE 0 END																																		AS GrossProfitOnLandedCostLC
						,CASE WHEN BusinessClassCode = 10 THEN SUM(NetSalesLC) + 
																SUM(Mgmt_COGS_3rd_F_Price_Duty_Freight_Insurance) + 
																SUM(IcCogsChargesAndMarkupLC) +
																SUM(ShortageLC) + 
																SUM(CogsAdjustmentsReturnsLC) + 
																SUM(CogsOtherAdjustmentsLC) + 
																SUM(ChangeInInventoryReserveLC) +
																SUM(COGS_Inventory_Revaluation_Transfer) + 
																SUM(Others_Cost_of_Goods_Warranties) +
																SUM(Currency_gain_loss_from_derivates_COGS) 
							  WHEN BusinessClassCode = 30 THEN SUM(NetSalesLC) + SUM(COGS_IC_Sales) + SUM(IcCogsChargesAndMarkupLC) 
							  WHEN BusinessClassCode = 50 THEN SUM(NetSalesLC) + SUM(COGS_BFT_MAP) + SUM(COGS_BFT_Markup)		 				
							  ELSE 0 END																																		AS GrossProfitLC
						,SUM(Mgmt_COGS_3rd_F_Price_Duty_Freight_Insurance)																										AS MgmtCOGS3rdFPriceDutyFreightInsuranceLC

					INTO #TMP_raw 
					FROM CTEtag_to_fields 
					GROUP BY CompanyCode
						  ,AccountingDocNo
						  ,ReferenceDocNo
						  ,ReferenceDocItemNo
						  ,ReferenceDocumentType
						  ,NatMaterialNo
						  ,FiscalYear
						  ,PostingDate_YYYYMM
						  ,ProfitCenterCode
						  ,NatSalesOrderNo   
						  ,BrandCode
						  ,RBUCode
						  ,RefRBUCode   
						  ,BusSegmentCode
						  ,BusSubSegmentCode
						  ,DistributionChannelCode
						  ,ProdDivCode  
						  ,NatSalesman_BK
						  ,CustomerCode_SoldTo
						  ,NatCustomerShipTo_BK 
						  ,NatCustomerPayer_BK
						  ,NatCustomerOwnerGroup_BK 
						  ,NatCustomerBillTo_BK
						  ,NatStoreDC_BK
						  ,CurrencyCode
						  ,GroupKey
						  ,NatSOTypeCode 
						  ,NatInvoiceTypeCode
						  ,BusinessClassCode
						  ,NatCustomer_BK
						  ,IntPupMasterId  
						  ,PDUCode;


		--partitioning , windowing & BK calculation
		SELECT CONCAT(cte.NatCustomer_BK,'|',cte.PostingDate_YYYYMM,'|',cte.NatSalesOrderNo,'|',cte.NatMaterialNo,'|',cte.CompanyCode)  AS NatCopa_BK
		  ,cte.CompanyCode
		  ,FIRST_VALUE(AccountingDocNo)			OVER(PARTITION BY cte.NatCustomer_BK,cte.FiscalYear,cte.NatSalesOrderNo,cte.NatMaterialNo,cte.CompanyCode,cte.PostingDate_YYYYMM	ORDER BY ReferenceDocumentType DESC,PostingDate DESC, AccountingDocNo DESC)	AS AccountingDocNo
		  ,FIRST_VALUE(ReferenceDocNo)			OVER(PARTITION BY cte.NatCustomer_BK,cte.FiscalYear,cte.NatSalesOrderNo,cte.NatMaterialNo,cte.CompanyCode,cte.PostingDate_YYYYMM 	ORDER BY ReferenceDocumentType DESC,PostingDate DESC, cte.ReferenceDocNo DESC) AS ReferenceDocNo 
		  ,FIRST_VALUE(ReferenceDocItemNo)		OVER(PARTITION BY cte.NatCustomer_BK,cte.FiscalYear,cte.NatSalesOrderNo,cte.NatMaterialNo,cte.CompanyCode,cte.PostingDate_YYYYMM	ORDER BY ReferenceDocumentType DESC,PostingDate DESC, cte.ReferenceDocItemNo DESC) AS ReferenceDocItemNo 
		  --,cte.ReferenceDocumentType
		  ,cte.NatMaterialNo
		  ,cte.FiscalYear
		  ,FIRST_VALUE(ProfitCenterCode)		OVER(PARTITION BY cte.NatCustomer_BK,cte.FiscalYear,cte.NatSalesOrderNo,cte.NatMaterialNo,cte.CompanyCode,cte.PostingDate_YYYYMM	ORDER BY ReferenceDocumentType DESC,PostingDate DESC, AccountingDocNo DESC, ReferenceDocNo DESC, ReferenceDocItemNo DESC) AS ProfitCenterCode
		  ,cte.NatSalesOrderNo  
		  ,cte.CreationDate  
		  ,cte.PostingDate
		  ,cte.BrandCode
		  ,FIRST_VALUE(RBUCode)					OVER(PARTITION BY cte.NatCustomer_BK,cte.FiscalYear,cte.NatSalesOrderNo,cte.NatMaterialNo,cte.CompanyCode,cte.PostingDate_YYYYMM	ORDER BY ReferenceDocumentType DESC,PostingDate DESC, AccountingDocNo DESC) AS RBUCode
		  ,FIRST_VALUE(RefRBUCode)				OVER(PARTITION BY cte.NatCustomer_BK,cte.FiscalYear,cte.NatSalesOrderNo,cte.NatMaterialNo,cte.CompanyCode,cte.PostingDate_YYYYMM	ORDER BY ReferenceDocumentType DESC,PostingDate DESC, AccountingDocNo DESC) AS RefRBUCode
		  ,FIRST_VALUE(BusSegmentCode)			OVER(PARTITION BY cte.NatCustomer_BK,cte.FiscalYear,cte.NatSalesOrderNo,cte.NatMaterialNo,cte.CompanyCode,cte.PostingDate_YYYYMM	ORDER BY ReferenceDocumentType DESC,PostingDate DESC, AccountingDocNo DESC) AS BusSegmentCode 
		  ,FIRST_VALUE(BusSubSegmentCode)		OVER(PARTITION BY cte.NatCustomer_BK,cte.FiscalYear,cte.NatSalesOrderNo,cte.NatMaterialNo,cte.CompanyCode,cte.PostingDate_YYYYMM	ORDER BY ReferenceDocumentType DESC,PostingDate DESC, AccountingDocNo DESC) AS BusSubSegmentCode 
		  ,FIRST_VALUE(DistributionChannelCode) OVER(PARTITION BY cte.NatCustomer_BK,cte.FiscalYear,cte.NatSalesOrderNo,cte.NatMaterialNo,cte.CompanyCode,cte.PostingDate_YYYYMM	ORDER BY ReferenceDocumentType DESC,PostingDate DESC, AccountingDocNo DESC) AS DistributionChannelCode
		  ,FIRST_VALUE(ProdDivCode)				OVER(PARTITION BY cte.NatCustomer_BK,cte.FiscalYear,cte.NatSalesOrderNo,cte.NatMaterialNo,cte.CompanyCode,cte.PostingDate_YYYYMM	ORDER BY ReferenceDocumentType DESC,PostingDate DESC, AccountingDocNo DESC) AS ProdDivCode  
		  ,FIRST_VALUE(NatSalesman_BK)			OVER(PARTITION BY cte.NatCustomer_BK,cte.FiscalYear,cte.NatSalesOrderNo,cte.NatMaterialNo,cte.CompanyCode,cte.PostingDate_YYYYMM	ORDER BY ReferenceDocumentType DESC,PostingDate DESC, AccountingDocNo DESC) AS NatSalesman_BK
		  ,cte.CustomerCode_SoldTo
		  ,FIRST_VALUE(NatCustomerShipTo_BK)	OVER(PARTITION BY cte.NatCustomer_BK,cte.FiscalYear,cte.NatSalesOrderNo,cte.NatMaterialNo,cte.CompanyCode,cte.PostingDate_YYYYMM	ORDER BY ReferenceDocumentType DESC,PostingDate DESC, AccountingDocNo DESC, ReferenceDocNo DESC, ReferenceDocItemNo DESC) AS NatCustomerShipTo_BK
		  ,FIRST_VALUE(NatCustomerPayer_BK)		OVER(PARTITION BY cte.NatCustomer_BK,cte.FiscalYear,cte.NatSalesOrderNo,cte.NatMaterialNo,cte.CompanyCode,cte.PostingDate_YYYYMM	ORDER BY ReferenceDocumentType DESC,PostingDate DESC, AccountingDocNo DESC, ReferenceDocNo DESC, ReferenceDocItemNo DESC) AS NatCustomerPayer_BK
		  ,FIRST_VALUE(NatCustomerOwnerGroup_BK) OVER(PARTITION BY cte.NatCustomer_BK,cte.FiscalYear,cte.NatSalesOrderNo,cte.NatMaterialNo,cte.CompanyCode,cte.PostingDate_YYYYMM	ORDER BY ReferenceDocumentType DESC,PostingDate DESC, AccountingDocNo DESC, ReferenceDocNo DESC, ReferenceDocItemNo DESC, NatCustomerOwnerGroup_BK DESC) AS NatCustomerOwnerGroup_BK
		  ,FIRST_VALUE(NatCustomerBillTo_BK)	OVER(PARTITION BY cte.NatCustomer_BK,cte.FiscalYear,cte.NatSalesOrderNo,cte.NatMaterialNo,cte.CompanyCode,cte.PostingDate_YYYYMM	ORDER BY ReferenceDocumentType DESC,PostingDate DESC, AccountingDocNo DESC, ReferenceDocNo DESC, ReferenceDocItemNo DESC) AS NatCustomerBillTo_BK
		  ,FIRST_VALUE(NatStoreDC_BK)			OVER(PARTITION BY cte.NatCustomer_BK,cte.FiscalYear,cte.NatSalesOrderNo,cte.NatMaterialNo,cte.CompanyCode,cte.PostingDate_YYYYMM	ORDER BY ReferenceDocumentType DESC,PostingDate DESC, AccountingDocNo DESC, NatStoreDC_BK DESC) AS NatStoreDC_BK
		  ,cte.CurrencyCode
		  ,FIRST_VALUE(GroupKey)				OVER(PARTITION BY cte.NatCustomer_BK,cte.FiscalYear,cte.NatSalesOrderNo,cte.NatMaterialNo,cte.CompanyCode,cte.PostingDate_YYYYMM	ORDER BY ReferenceDocumentType DESC,PostingDate DESC, AccountingDocNo DESC, ReferenceDocNo DESC, ReferenceDocItemNo DESC, GroupKey DESC) AS GroupKey
		  ,cte.NatSOTypeCode  --SOTypeCode
		  ,FIRST_VALUE(NatInvoiceTypeCode)		OVER(PARTITION BY cte.NatCustomer_BK,cte.FiscalYear,cte.NatSalesOrderNo,cte.NatMaterialNo,cte.CompanyCode,cte.PostingDate_YYYYMM	ORDER BY ReferenceDocumentType DESC,PostingDate DESC, AccountingDocNo DESC) AS NatInvoiceTypeCode
		  ,cte.BusinessClassCode
		  ,cte.NatCustomer_BK
		  ,cte.IntPupMasterId  
		  ,cte.PDUCode
		  --measures
		  ,cte.NetSalesUnits
		  ,cte.GrossSalesLC
		  ,cte.OnInvoicePriceReductionsLC
		  ,cte.OffInvoicePriceReductionsLC
		  ,cte.RetailMarkdownLC
		  ,cte.SalesAdjustmentsReturnProvisionLC
		  ,cte.OtherSalesAdjustmentsLC
		  ,cte.NetSalesLC
		  ,cte.CogsAtFPriceLC
		  ,cte.ShortageLC
		  ,cte.ChangeInInventoryReserveLC
		  ,cte.CogsOtherAdjustmentsLC
		  ,cte.CogsAdjustmentsReturnsLC
		  ,cte.InvoicedSalesLC
		  ,cte.InvoicedSalesUnits
		  ,cte.OffInvoiceSales
		  ,cte.OtherCOGSLS
		  ,cte.CogsAtLandedCostLC
		  ,cte.TotalCogsLC
		  ,cte.MgmtCogsAtCostLC
		  ,cte.ProductProfitOnFPriceLC
		  ,cte.ProductProfitOn3rdPartyLandedCostLC
		  ,cte.MgmtGrossProfitOn3rdPartyLandedCostLC
		  ,cte.MgmtGrossProfitLC
		  ,cte.GrossProfitOnLandedCostLC
		  ,cte.GrossProfitLC
		  ,cte.MgmtCOGS3rdFPriceDutyFreightInsuranceLC
		INTO #TMP_window 
		--FROM etl.[TMP_COPA] cte;
		FROM #TMP_raw cte;


		;with CTE_agg AS (
			SELECT NatCopa_BK 
				  ,CompanyCode
				  ,AccountingDocNo
				  ,ReferenceDocNo
				  ,ReferenceDocItemNo
				  ,NatMaterialNo
				  ,FiscalYear
				  ,ProfitCenterCode
				  ,NatSalesOrderNo  
				  ,MAX(CreationDate)					AS CreationDate
				  ,MAX(PostingDate)						AS PostingDate
				  ,BrandCode
				  ,RBUCode
				  ,RefRBUCode   
				  ,BusSegmentCode
				  ,BusSubSegmentCode
				  ,DistributionChannelCode
				  ,ProdDivCode  
				  ,NatSalesman_BK
				  ,CustomerCode_SoldTo
				  ,NatCustomerShipTo_BK 
				  ,NatCustomerPayer_BK
				  ,NatCustomerOwnerGroup_BK 
				  ,NatCustomerBillTo_BK
				  ,NatStoreDC_BK
				  ,CurrencyCode
				  ,GroupKey
				  ,NatSOTypeCode
				  ,NatInvoiceTypeCode
				  ,BusinessClassCode
				  ,NatCustomer_BK
				  ,IntPupMasterId  
				  ,PDUCode
				  ,SUM(NetSalesUnits)						AS NetSalesUnits
				  ,SUM(GrossSalesLC)						AS GrossSalesLC
				  ,SUM(OnInvoicePriceReductionsLC)			AS OnInvoicePriceReductionsLC
				  ,SUM(OffInvoicePriceReductionsLC)			AS OffInvoicePriceReductionsLC
				  ,SUM(RetailMarkdownLC)					AS RetailMarkdownLC
				  ,SUM(SalesAdjustmentsReturnProvisionLC)	AS SalesAdjustmentsReturnProvisionLC
				  ,SUM(OtherSalesAdjustmentsLC)				AS OtherSalesAdjustmentsLC
				  ,SUM(NetSalesLC)							AS NetSalesLC
				  ,SUM(CogsAtFPriceLC)						AS CogsAtFPriceLC
				  ,SUM(ShortageLC)							AS ShortageLC
				  ,SUM(ChangeInInventoryReserveLC)			AS ChangeInInventoryReserveLC
				  ,SUM(CogsOtherAdjustmentsLC)				AS CogsOtherAdjustmentsLC
				  ,SUM(CogsAdjustmentsReturnsLC)			AS CogsAdjustmentsReturnsLC
				  ,SUM(InvoicedSalesLC)						AS InvoicedSalesLC
				  ,SUM(InvoicedSalesUnits)					AS InvoicedSalesUnits
				  ,SUM(OffInvoiceSales)						AS OffInvoiceSales
				  ,SUM(OtherCOGSLS)							AS OtherCOGSLS
				  ,SUM(CogsAtLandedCostLC)					AS CogsAtLandedCostLC
				  ,SUM(TotalCogsLC)							AS TotalCogsLC
				  ,SUM(MgmtCogsAtCostLC)					AS MgmtCogsAtCostLC
				  ,SUM(ProductProfitOnFPriceLC)				AS ProductProfitOnFPriceLC
				  ,SUM(ProductProfitOn3rdPartyLandedCostLC) AS ProductProfitOn3rdPartyLandedCostLC
				  ,SUM(MgmtGrossProfitOn3rdPartyLandedCostLC)		AS MgmtGrossProfitOn3rdPartyLandedCostLC
				  ,SUM(MgmtGrossProfitLC)							AS MgmtGrossProfitLC
				  ,SUM(GrossProfitOnLandedCostLC)					AS GrossProfitOnLandedCostLC
				  ,SUM(GrossProfitLC)								AS GrossProfitLC
				  --Profit Margin KPIs
				  ,SUM(ProductProfitOnFPriceLC)					/NULLIF(SUM(GrossSalesLC),0)	AS ProductMarginOnFPriceLC
				  ,SUM(ProductProfitOn3rdPartyLandedCostLC)		/NULLIF(SUM(GrossSalesLC),0)	AS ProductMarginOn3rdPartyLandedCostLC
				  ,SUM(MgmtGrossProfitOn3rdPartyLandedCostLC)	/NULLIF(SUM(NetSalesLC),0)		AS MgmtGrossProfitMarginOn3rdPartyLandedCostLC
				  ,SUM(MgmtGrossProfitLC)						/NULLIF(SUM(NetSalesLC),0)		AS MgmtGrossProfitMarginLC
				  ,SUM(GrossProfitOnLandedCostLC)				/NULLIF(SUM(NetSalesLC),0)		AS GrossProfitMarginOnLandedCostLC
				  ,SUM(GrossProfitLC)							/NULLIF(SUM(NetSalesLC),0)		AS GrossProfitMarginLC
				  ,SUM(MgmtCOGS3rdFPriceDutyFreightInsuranceLC)		AS MgmtCOGS3rdFPriceDutyFreightInsuranceLC

			FROM #TMP_window
			GROUP BY NatCopa_BK
				  ,CompanyCode
				  ,AccountingDocNo
				  ,ReferenceDocNo
				  ,ReferenceDocItemNo
				  ,NatMaterialNo
				  ,FiscalYear
				  ,ProfitCenterCode
				  ,NatSalesOrderNo  
				  ,BrandCode
				  ,RBUCode
				  ,RefRBUCode   
				  ,BusSegmentCode
				  ,BusSubSegmentCode
				  ,DistributionChannelCode
				  ,ProdDivCode  
				  ,NatSalesman_BK
				  ,CustomerCode_SoldTo
				  ,NatCustomerShipTo_BK 
				  ,NatCustomerPayer_BK
				  ,NatCustomerOwnerGroup_BK 
				  ,NatCustomerBillTo_BK
				  ,NatStoreDC_BK
				  ,CurrencyCode
				  ,GroupKey
				  ,NatSOTypeCode
				  ,NatInvoiceTypeCode
				  ,BusinessClassCode
				  ,NatCustomer_BK
				  ,IntPupMasterId  
				  ,PDUCode
		  )
		  SELECT co.NatCopa_BK
			  ,co.CompanyCode
			  ,co.AccountingDocNo
			  ,co.ReferenceDocNo
			  ,co.ReferenceDocItemNo
			  ,co.NatMaterialNo
			  ,co.FiscalYear
			  ,co.IntPupMasterId  
			  ,co.PDUCode         
			  ,CASE WHEN co.NatMaterialNo = '' THEN '' ELSE CONCAT(co.NatMaterialNo,'|',(CASE WHEN co.CompanyCode = 'PT10' THEN 'ES10' ELSE co.CompanyCode END)) END				AS NatArticle_BK 
			  --,CASE WHEN len(co.NatMaterialNo) >0 THEN REPLACE(LEFT(co.NatMaterialNo,CHARINDEX('-',co.NatMaterialNo,(CHARINDEX('-',co.NatMaterialNo)+1))-1),'-',' ') ELSE '' END	AS ArticleNumber_BK
			  ,CONVERT(CHAR(9), CASE WHEN CHARINDEX('-',LTRIM(co.NatMaterialNo)) <> 7 THEN '' ELSE REPLACE(LEFT(co.NatMaterialNo,9),'-',' ') END)									AS ArticleNumber_BK
			  ,REPLACE(co.NatMaterialNo,'-',' ')																																	AS ArticleSize_BK
			  --,CASE WHEN len(co.NatMaterialNo) >0 THEN LEFT(co.NatMaterialNo,CHARINDEX('-',co.NatMaterialNo)-1) ELSE '' END														AS StyleNumber_BK
			  ,CASE WHEN CHARINDEX('-',LTRIM(co.NatMaterialNo)) <> 7 THEN '' ELSE LEFT(co.NatMaterialNo,CHARINDEX('-',co.NatMaterialNo)-1) END										AS StyleNumber_BK
			  ,co.ProfitCenterCode
			  ,co.NatSalesOrderNo
			  ,co.CreationDate
			  ,co.PostingDate
			  ,co.BrandCode
			  ,co.RBUCode
			  ,co.RefRBUCode
			  ,co.BusSegmentCode
			  ,co.BusSubSegmentCode
			  ,co.DistributionChannelCode
			  ,co.ProdDivCode
			  ,co.NatSalesman_BK  
			  ,co.NatCustomer_BK
			  ,co.NatCustomerShipTo_BK 
			  ,co.NatCustomerPayer_BK 
			  ,co.NatCustomerOwnerGroup_BK
			  ,co.NatCustomerBillTo_BK
			  ,co.NatStoreDC_BK 
			  ,co.CurrencyCode
			  ,co.GroupKey
			  ,co.NatSOTypeCode
			  ,st.EBPDesc			AS NatSOTypeDesc 
			  ,co.NatInvoiceTypeCode
			  ,co.BusinessClassCode
			  ,co.NetSalesUnits
			  ,co.GrossSalesLC
			  ,co.OnInvoicePriceReductionsLC
			  ,co.OffInvoicePriceReductionsLC
			  ,co.RetailMarkdownLC
			  ,co.SalesAdjustmentsReturnProvisionLC
			  ,co.OtherSalesAdjustmentsLC
			  ,co.NetSalesLC
			  ,co.CogsAtFPriceLC
			  ,co.ShortageLC
			  ,co.ChangeInInventoryReserveLC
			  ,co.CogsOtherAdjustmentsLC
			  ,co.CogsAdjustmentsReturnsLC
			  ,co.InvoicedSalesLC
			  ,co.InvoicedSalesUnits
			  ,co.OffInvoiceSales
			  ,co.OtherCOGSLS
			  ,co.CogsAtLandedCostLC
			  ,co.TotalCogsLC
			  ,co.MgmtCogsAtCostLC
			  ,co.ProductProfitOnFPriceLC
			  ,co.ProductProfitOn3rdPartyLandedCostLC
			  ,co.MgmtGrossProfitOn3rdPartyLandedCostLC
			  ,co.MgmtGrossProfitLC
			  ,co.GrossProfitOnLandedCostLC
			  ,co.GrossProfitLC
			  ,co.ProductMarginOnFPriceLC
			  ,co.ProductMarginOn3rdPartyLandedCostLC
			  ,co.MgmtGrossProfitMarginOn3rdPartyLandedCostLC
			  ,co.MgmtGrossProfitMarginLC
			  ,co.GrossProfitMarginOnLandedCostLC
			  ,co.GrossProfitMarginLC
			  ,co.MgmtCOGS3rdFPriceDutyFreightInsuranceLC
			  ,CONVERT([BINARY](16),HASHBYTES('MD5',UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](500), co.NatCopa_BK))) ))) AS HashValueBK 
			  ,CONVERT([BINARY](16), 
				HASHBYTES('MD5',CONCAT( 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.CompanyCode)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.AccountingDocNo)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.ReferenceDocNo)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.ReferenceDocItemNo)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.NatMaterialNo )))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.FiscalYear)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.IntPupMasterId)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.PDUCode)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CASE WHEN co.NatMaterialNo = '' THEN '' ELSE CONCAT(co.NatMaterialNo,'|',(CASE WHEN co.CompanyCode = 'PT10' THEN 'ES10' ELSE co.CompanyCode END)) END )))),'_',		--NatArticle_BK
			--	UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CASE WHEN len(co.NatMaterialNo) >0 THEN REPLACE(LEFT(co.NatMaterialNo,CHARINDEX('-',co.NatMaterialNo,(CHARINDEX('-',co.NatMaterialNo)+1))-1),'-',' ') ELSE '' END )))),'_',	--ArticleNumber_BK
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CONVERT(CHAR(9), CASE WHEN CHARINDEX('-',LTRIM(co.NatMaterialNo)) <> 7 THEN '' ELSE REPLACE(LEFT(co.NatMaterialNo,9),'-',' ') END)  )))),'_',	--ArticleNumber_BK
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), REPLACE(co.NatMaterialNo,'-',' ') )))),'_',		--ArticleSize_BK
			--	UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CASE WHEN len(co.NatMaterialNo) >0 THEN LEFT(co.NatMaterialNo,CHARINDEX('-',co.NatMaterialNo)-1) ELSE '' END )))),'_',	--StyleNumber_BK
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CASE WHEN CHARINDEX('-',LTRIM(co.NatMaterialNo)) <> 7 THEN '' ELSE LEFT(co.NatMaterialNo,CHARINDEX('-',co.NatMaterialNo)-1) END  )))),'_', --StyleNumber_BK
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.ProfitCenterCode)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.NatSalesOrderNo)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.CreationDate)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.PostingDate)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.BrandCode)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.RBUCode)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.RefRBUCode)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.BusSegmentCode)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.BusSubSegmentCode)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.DistributionChannelCode)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.ProdDivCode)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.NatSalesman_BK)))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.NatCustomer_BK)))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.NatCustomerShipTo_BK)))),'_',	
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.NatCustomerPayer_BK)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.NatCustomerOwnerGroup_BK)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.NatCustomerBillTo_BK)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.NatStoreDC_BK)))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.CurrencyCode)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.GroupKey)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.NatSOTypeCode)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), st.EBPDesc)))),'_',											--AS NatSOTypeDesc
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.NatInvoiceTypeCode)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.BusinessClassCode)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.NetSalesUnits)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.GrossSalesLC)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.OnInvoicePriceReductionsLC)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.OffInvoicePriceReductionsLC)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.RetailMarkdownLC)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.SalesAdjustmentsReturnProvisionLC)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.OtherSalesAdjustmentsLC)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.NetSalesLC)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.CogsAtFPriceLC)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.ShortageLC)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.ChangeInInventoryReserveLC)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.CogsOtherAdjustmentsLC)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.CogsAdjustmentsReturnsLC)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.InvoicedSalesLC)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.InvoicedSalesUnits)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.OffInvoiceSales)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.OtherCOGSLS)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.CogsAtLandedCostLC)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.TotalCogsLC)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.MgmtCogsAtCostLC)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.ProductProfitOnFPriceLC)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.ProductProfitOn3rdPartyLandedCostLC)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.MgmtGrossProfitOn3rdPartyLandedCostLC)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.MgmtGrossProfitLC)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.GrossProfitOnLandedCostLC)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.GrossProfitLC)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.ProductMarginOnFPriceLC)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.ProductMarginOn3rdPartyLandedCostLC)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.MgmtGrossProfitMarginOn3rdPartyLandedCostLC)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.MgmtGrossProfitMarginLC)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.GrossProfitMarginOnLandedCostLC)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.GrossProfitMarginLC)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.MgmtCOGS3rdFPriceDutyFreightInsuranceLC))))
						))) AS HashDiff      
		  INTO #TMP_STAG_COPA
		FROM CTE_agg co LEFT JOIN pdwref.S4Hana_SalesTypes  st ON st.SOTypeCode = co.NatSOTypeCode;

	
	--update destination 
		UPDATE dest SET
		--dest.CompanyCode					= stg.CompanyCode			--BK part
		 dest.AccountingDocNo				= stg.AccountingDocNo
		,dest.ReferenceDocNo 				= stg.ReferenceDocNo		
		,dest.ReferenceDocItemNo 			= stg.ReferenceDocItemNo
		--,dest.NatMaterialNo				= stg.NatMaterialNo			--BK part
		--,dest.FiscalYear					= stg.FiscalYear,			--BK part
		,dest.IntPupMasterId				= stg.IntPupMasterId
		,dest.PDUCode						= stg.PDUCode
		,dest.NatArticle_BK					= stg.NatArticle_BK
		,dest.ArticleNumber_BK				= stg.ArticleNumber_BK
		,dest.ArticleSize_BK				= stg.ArticleSize_BK
		,dest.StyleNumber_BK				= stg.StyleNumber_BK
		,dest.ProfitCenterCode				= stg.ProfitCenterCode
		--,dest.NatSalesOrderNo				= stg.NatSalesOrderNo		--BK part
		,dest.CreationDate					= stg.CreationDate
		,dest.PostingDate					= stg.PostingDate
		,dest.BrandCode						= stg.BrandCode
		,dest.RBUCode						= stg.RBUCode
		,dest.RefRBUCode					= stg.RefRBUCode
		,dest.BusSegmentCode				= stg.BusSegmentCode
		,dest.BusSubSegmentCode				= stg.BusSubSegmentCode
		,dest.DistributionChannelCode		= stg.DistributionChannelCode
		,dest.ProdDivCode					= stg.ProdDivCode
		,dest.NatSalesman_BK				= stg.NatSalesman_BK
		--,dest.NatCustomer_BK				= stg.NatCustomer_BK		--BK part
		,dest.NatCustomerShipTo_BK			= stg.NatCustomerShipTo_BK
		,dest.NatCustomerPayer_BK			= stg.NatCustomerPayer_BK
		,dest.NatCustomerOwnerGroup_BK		= stg.NatCustomerOwnerGroup_BK
		,dest.NatCustomerBillTo_BK			= stg.NatCustomerBillTo_BK
		,dest.NatStoreDC_BK					= stg.NatStoreDC_BK
		,dest.CurrencyCode					= stg.CurrencyCode
		,dest.GroupKey						= stg.GroupKey
		,dest.NatSOTypeCode					= stg.NatSOTypeCode
		,dest.NatSOTypeDesc					= stg.NatSOTypeDesc
		,dest.NatInvoiceTypeCode			= stg.NatInvoiceTypeCode
		,dest.BusinessClassCode				= stg.BusinessClassCode 
		,dest.NetSalesUnits					= stg.NetSalesUnits
		,dest.GrossSalesLC					= stg.GrossSalesLC
		,dest.OnInvoicePriceReductionsLC	= stg.OnInvoicePriceReductionsLC
		,dest.OffInvoicePriceReductionsLC	= stg.OffInvoicePriceReductionsLC
		,dest.RetailMarkdownLC				= stg.RetailMarkdownLC
		,dest.SalesAdjustmentsReturnProvisionLC = stg.SalesAdjustmentsReturnProvisionLC
		,dest.OtherSalesAdjustmentsLC		= stg.OtherSalesAdjustmentsLC
		,dest.NetSalesLC					= stg.NetSalesLC
		,dest.CogsAtFPriceLC				= stg.CogsAtFPriceLC
		,dest.ShortageLC					= stg.ShortageLC
		,dest.ChangeInInventoryReserveLC	= stg.ChangeInInventoryReserveLC
		,dest.CogsOtherAdjustmentsLC		= stg.CogsOtherAdjustmentsLC
		,dest.CogsAdjustmentsReturnsLC		= stg.CogsAdjustmentsReturnsLC
		,dest.InvoicedSalesLC				= stg.InvoicedSalesLC
		,dest.InvoicedSalesUnits			= stg.InvoicedSalesUnits
		,dest.OffInvoiceSales				= stg.OffInvoiceSales
		,dest.OtherCOGSLS					= stg.OtherCOGSLS
		,dest.CogsAtLandedCostLC			= stg.CogsAtLandedCostLC
		,dest.TotalCogsLC					= stg.TotalCogsLC
		,dest.MgmtCogsAtCostLC				= stg.MgmtCogsAtCostLC
		,dest.ProductProfitOnFPriceLC		= stg.ProductProfitOnFPriceLC
		,dest.ProductProfitOn3rdPartyLandedCostLC			= stg.ProductProfitOn3rdPartyLandedCostLC
		,dest.MgmtGrossProfitOn3rdPartyLandedCostLC			= stg.MgmtGrossProfitOn3rdPartyLandedCostLC
		,dest.MgmtGrossProfitLC								= stg.MgmtGrossProfitLC
		,dest.GrossProfitOnLandedCostLC						= stg.GrossProfitOnLandedCostLC
		,dest.GrossProfitLC									= stg.GrossProfitLC
		,dest.ProductMarginOnFPriceLC						= stg.ProductMarginOnFPriceLC
		,dest.ProductMarginOn3rdPartyLandedCostLC			= stg.ProductMarginOn3rdPartyLandedCostLC
		,dest.MgmtGrossProfitMarginOn3rdPartyLandedCostLC	= stg.MgmtGrossProfitMarginOn3rdPartyLandedCostLC
		,dest.MgmtGrossProfitMarginLC						= stg.MgmtGrossProfitMarginLC
		,dest.GrossProfitMarginOnLandedCostLC				= stg.GrossProfitMarginOnLandedCostLC
		,dest.GrossProfitMarginLC							= stg.GrossProfitMarginLC
		,dest.MgmtCOGS3rdFPriceDutyFreightInsuranceLC		= stg.MgmtCOGS3rdFPriceDutyFreightInsuranceLC
		,dest.HashDiff										= stg.HashDiff
		,dest.ModifiedOn									= @LoadDate
		FROM #TMP_STAG_COPA AS stg JOIN sales.NatCopa AS dest ON stg.HashValueBK = dest.HashValueBK
		WHERE dest.HashDiff <> stg.HashDiff;

	--insert into dest
	INSERT INTO sales.NatCopa
			( NatCopa_BK
			  ,CompanyCode
			  ,AccountingDocNo
			  ,ReferenceDocNo
			  ,ReferenceDocItemNo
			  ,NatMaterialNo
			  ,FiscalYear
			  ,IntPupMasterId
			  ,PDUCode
			  ,NatArticle_BK
			  ,ArticleNumber_BK
			  ,ArticleSize_BK
			  ,StyleNumber_BK
			  ,ProfitCenterCode
			  ,NatSalesOrderNo
			  ,CreationDate
			  ,PostingDate
			  ,BrandCode
			  ,RBUCode
			  ,RefRBUCode
			  ,BusSegmentCode
			  ,BusSubSegmentCode
			  ,DistributionChannelCode
			  ,ProdDivCode
			  ,NatSalesman_BK
			  ,NatCustomer_BK
			  ,NatCustomerShipTo_BK
			  ,NatCustomerPayer_BK
			  ,NatCustomerOwnerGroup_BK
			  ,NatCustomerBillTo_BK
			  ,NatStoreDC_BK
			  ,CurrencyCode
			  ,GroupKey
			  ,NatSOTypeCode
			  ,NatSOTypeDesc
			  ,NatInvoiceTypeCode
			  ,BusinessClassCode
			  ,NetSalesUnits
			  ,GrossSalesLC
			  ,OnInvoicePriceReductionsLC
			  ,OffInvoicePriceReductionsLC
			  ,RetailMarkdownLC
			  ,SalesAdjustmentsReturnProvisionLC
			  ,OtherSalesAdjustmentsLC
			  ,NetSalesLC
			  ,CogsAtFPriceLC
			  ,ShortageLC
			  ,ChangeInInventoryReserveLC
			  ,CogsOtherAdjustmentsLC
			  ,CogsAdjustmentsReturnsLC
			  ,InvoicedSalesLC
			  ,InvoicedSalesUnits
			  ,OffInvoiceSales
			  ,OtherCOGSLS
			  ,CogsAtLandedCostLC
			  ,TotalCogsLC
			  ,MgmtCogsAtCostLC
			  ,ProductProfitOnFPriceLC
			  ,ProductProfitOn3rdPartyLandedCostLC
			  ,MgmtGrossProfitOn3rdPartyLandedCostLC
			  ,MgmtGrossProfitLC
			  ,GrossProfitOnLandedCostLC
			  ,GrossProfitLC
			  ,ProductMarginOnFPriceLC
			  ,ProductMarginOn3rdPartyLandedCostLC
			  ,MgmtGrossProfitMarginOn3rdPartyLandedCostLC
			  ,MgmtGrossProfitMarginLC
			  ,GrossProfitMarginOnLandedCostLC
			  ,GrossProfitMarginLC
			  ,MgmtCOGS3rdFPriceDutyFreightInsuranceLC
			  ,HashValueBK
			  ,HashDiff
			  ,CreatedOn
			  ,ModifiedOn
		)
		SELECT stg.NatCopa_BK
			  ,stg.CompanyCode
			  ,stg.AccountingDocNo
			  ,stg.ReferenceDocNo
			  ,stg.ReferenceDocItemNo
			  ,stg.NatMaterialNo
			  ,stg.FiscalYear
			  ,stg.IntPupMasterId
			  ,stg.PDUCode
			  ,stg.NatArticle_BK
			  ,stg.ArticleNumber_BK
			  ,stg.ArticleSize_BK
			  ,stg.StyleNumber_BK
			  ,stg.ProfitCenterCode
			  ,stg.NatSalesOrderNo
			  ,stg.CreationDate
			  ,stg.PostingDate
			  ,stg.BrandCode
			  ,stg.RBUCode
			  ,stg.RefRBUCode
			  ,stg.BusSegmentCode
			  ,stg.BusSubSegmentCode
			  ,stg.DistributionChannelCode
			  ,stg.ProdDivCode
			  ,stg.NatSalesman_BK
			  ,stg.NatCustomer_BK
			  ,stg.NatCustomerShipTo_BK
			  ,stg.NatCustomerPayer_BK
			  ,stg.NatCustomerOwnerGroup_BK
			  ,stg.NatCustomerBillTo_BK
			  ,stg.NatStoreDC_BK
			  ,stg.CurrencyCode
			  ,stg.GroupKey
			  ,stg.NatSOTypeCode
			  ,stg.NatSOTypeDesc
			  ,stg.NatInvoiceTypeCode
			  ,stg.BusinessClassCode
			  ,stg.NetSalesUnits
			  ,stg.GrossSalesLC
			  ,stg.OnInvoicePriceReductionsLC
			  ,stg.OffInvoicePriceReductionsLC
			  ,stg.RetailMarkdownLC
			  ,stg.SalesAdjustmentsReturnProvisionLC
			  ,stg.OtherSalesAdjustmentsLC
			  ,stg.NetSalesLC
			  ,stg.CogsAtFPriceLC
			  ,stg.ShortageLC
			  ,stg.ChangeInInventoryReserveLC
			  ,stg.CogsOtherAdjustmentsLC
			  ,stg.CogsAdjustmentsReturnsLC
			  ,stg.InvoicedSalesLC
			  ,stg.InvoicedSalesUnits
			  ,stg.OffInvoiceSales
			  ,stg.OtherCOGSLS
			  ,stg.CogsAtLandedCostLC
			  ,stg.TotalCogsLC
			  ,stg.MgmtCogsAtCostLC
			  ,stg.ProductProfitOnFPriceLC
			  ,stg.ProductProfitOn3rdPartyLandedCostLC
			  ,stg.MgmtGrossProfitOn3rdPartyLandedCostLC
			  ,stg.MgmtGrossProfitLC
			  ,stg.GrossProfitOnLandedCostLC
			  ,stg.GrossProfitLC
			  ,stg.ProductMarginOnFPriceLC
			  ,stg.ProductMarginOn3rdPartyLandedCostLC
			  ,stg.MgmtGrossProfitMarginOn3rdPartyLandedCostLC
			  ,stg.MgmtGrossProfitMarginLC
			  ,stg.GrossProfitMarginOnLandedCostLC
			  ,stg.GrossProfitMarginLC
			  ,stg.MgmtCOGS3rdFPriceDutyFreightInsuranceLC
			  ,stg.HashValueBK
			  ,stg.HashDiff
			  ,@LoadDate AS CreatedOn
			  ,@LoadDate AS ModifiedOn
		FROM #TMP_STAG_COPA AS stg LEFT JOIN sales.NatCopa AS dest ON stg.HashValueBK = dest.HashValueBK
		WHERE dest.HashValueBK IS NULL
		OPTION (MAXDOP 1);
	END