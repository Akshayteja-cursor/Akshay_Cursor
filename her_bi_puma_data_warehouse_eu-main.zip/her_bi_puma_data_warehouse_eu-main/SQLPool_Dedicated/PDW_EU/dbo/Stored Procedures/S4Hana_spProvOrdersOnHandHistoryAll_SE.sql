CREATE PROC [dbo].[S4Hana_spProvOrdersOnHandHistoryAll_SE] @LDTS [DATETIME2](7) AS 
BEGIN
SET NOCOUNT ON

--DECLARE @LDTS DATETIME2(7) = '2024-01-01'
DECLARE @CreatedOn DateTime2(7)
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(7) = GETDATE()
DECLARE @DestinationLastLoadDate DATETIME2(7)
DECLARE @BatchLdts DATETIME2(7) = @LDTS
DECLARE @AffectedRows BIGINT = NULL


-- do not use the input parameter, in case of an failur or reload situartion take the last tranfered LDTS from the Hist table
IF(EXISTS(SELECT 1 FROM [sales].[NatSalesOrdersOohHistory_SE]))
BEGIN
	SELECT @DestinationLastLoadDate = MAX(
					  (CONVERT(DATETIME, CONVERT(VARCHAR(255), OrdersOnHandDate)) +
					   CONVERT(DATETIME, TIMEFROMPARTS(OrdersOnHandTime / 10000, (OrdersOnHandTime / 100) % 100, OrdersOnHandTime % 100, 0, 0))) 
					  )
	FROM sales.NatSalesOrdersOohHistory_SE
END
ELSE BEGIN
	SELECT @DestinationLastLoadDate = '19900101' -- for intial load
END

--Log Data load
INSERT INTO etl.DataTransferLogs
      (DataTransferLogId
	  ,TransferName
      ,TransferGroupName
      ,TargetTableName
      ,TargetSchemaName
      ,ExecStart
      ,DestinationLastLoadDate
      ,BatchLdts)
	  SELECT @DataTransferLogId 
			,'spProvOrdersOnHandHistIncrement'
			,'SoDocHistory'
			,'NatSalesOrdersOohHistory_SE'
			,'sales'
			,@ExecStart
			,@DestinationLastLoadDate
			,@BatchLdts

-- collet all bookings SO/SOItem and OOHDates
IF OBJECT_ID('tempdb..#DistLdtsSoItems') IS NOT NULL
BEGIN
    DROP TABLE #DistLdtsSoItems
END

CREATE TABLE #DistLdtsSoItems
WITH
(DISTRIBUTION = HASH(NatSalesOrderNo)
,HEAP)
AS(
SELECT NatSalesOrderNo
      ,NatSalesOrderItemNo
      ,LDTS
FROM biz.S4Hana_SoDocumentItemsHistory
WHERE LDTS > @DestinationLastLoadDate
UNION
SELECT sodh.SalesDocument as NatSalesOrderNo
      ,sodi.SalesDocumentItem as NatSalesOrderItemNo
      ,sodh.LDTS
									 
FROM [biz].[S4Hana_SoDocumentsHeader] sodh 
INNER JOIN biz.S4Hana_SoDocumentItems sodi on sodh.SalesDocument = sodi.SalesDocument
WHERE sodh.LDTS > @DestinationLastLoadDate
UNION
SELECT sodp.SalesDocument as NatSalesOrderNo
      ,sodi.SalesDocumentItem as NatSalesOrderItemNo
      ,sodp.LDTS
									   
FROM [biz].[S4Hana_SODocumentsPartners] sodp
INNER JOIN biz.S4Hana_SoDocumentItems sodi on sodp.SalesDocument = sodi.SalesDocument
WHERE sodp.LDTS > @DestinationLastLoadDate
UNION
SELECT NatSalesOrderNo
      ,NatSalesOrderItemNo
      ,LDTS
FROM biz.S4Hana_SOScheduleLineItemsAggHistory
WHERE LDTS > @DestinationLastLoadDate
UNION
SELECT NatSalesOrderNo
	  ,NatSalesOrderItemNo
	  ,LDTS
FROM biz.S4Hana_DeliveryDocumentAggSoItemsHistory
WHERE LDTS > @DestinationLastLoadDate
UNION
SELECT NatSalesOrderNo
      ,NatSalesOrderItemNo
      ,LDTS
FROM biz.S4Hana_SoDocItemPriceConditionsHistory
WHERE LDTS > @DestinationLastLoadDate
UNION
-- Add related CallOffs for deleded Contracts to the touched object list to be incl. in the PreLogicOhhLogic CTE part
SELECT s_soi_Calloffs.NatSalesOrderNo
      ,s_soi_Calloffs.NatSalesOrderItemNo
      ,s_soi_Contract.LDTS
FROM biz.S4Hana_SoDocumentItemsHistory AS s_soi_Contract
INNER JOIN biz.S4Hana_SoDocumentItemsHistory AS s_soi_Calloffs
	ON s_soi_Contract.NatSalesOrderNo = s_soi_Calloffs.ReferenceDocumentNumber
	AND s_soi_Contract.NatSalesOrderItemNo = s_soi_Calloffs.ReferenceDocumentItemNumber
	AND s_soi_Contract.LDTS BETWEEN s_soi_Calloffs.LDTS AND s_soi_Calloffs.LEDTS
WHERE 1=1 --s_soi_Contract.NatSalesOrderNo in (select distinct NatSalesOrderNo from biz.S4Hana_SoDocumentItemsHistory where RejectionReason <> '')	
  AND s_soi_Contract.SOTypeCode IN ('ZPOC', 'ZROC', 'ZCSC', 'ZMKC', 'ZCOC', 'ZRES' ,'ZCCD' ,'ZCLS' ,'ZARC')
  AND s_soi_Contract.LDTS > @DestinationLastLoadDate
-- Bringing Calloffs into calculation due to changed DeliveryDate on contract
UNION
SELECT s_soi_Calloffs.NatSalesOrderNo
      ,s_soi_Calloffs.NatSalesOrderItemNo
      ,last_sch.LDTS
from biz.S4Hana_SOScheduleLineItemsAggHistory last_sch
inner join biz.S4Hana_SOScheduleLineItemsAggHistory prev_sch on last_sch.Natsalesorderno     = prev_sch.Natsalesorderno 
                                                     and last_sch.NatSalesOrderItemNo = prev_sch.NatSalesOrderItemNo 
													 and last_sch.LDTS                = DATEADD(SECOND,1,prev_sch.LEDTS)
INNER JOIN biz.S4Hana_SoDocumentItemsHistory AS s_soi_Calloffs
	ON last_sch.NatSalesOrderNo = s_soi_Calloffs.ReferenceDocumentNumber
	AND last_sch.NatSalesOrderItemNo = s_soi_Calloffs.ReferenceDocumentItemNumber
	AND last_sch.LDTS BETWEEN s_soi_Calloffs.LDTS AND s_soi_Calloffs.LEDTS
where 1=1 and last_sch.LDTS > @DestinationLastLoadDate
and last_sch.MinSODeliveryDate <> prev_sch.MinSODeliveryDate
)

-- preparation for Call off Logic
-- sum up Contract info for RefSo / RefSoItems

IF OBJECT_ID('tempdb..#SoDocumentCallOffContractInfo') IS NOT NULL
BEGIN
    DROP TABLE #SoDocumentCallOffContractInfo
END

CREATE TABLE #SoDocumentCallOffContractInfo--#SoDocumentCallOffRefContractInfo
WITH
(DISTRIBUTION = HASH(CalloffNatSalesOrderNo)  -- Enrich calloff order with contrcat information
,HEAP) AS(
SELECT s_soi_Contract.NatSalesOrderNo AS ContractNatSalesOrderNo,
	s_soi_Contract.NatSalesOrderItemNo AS ContractNatSalesOrderItemNo,
	s_soi_Calloffs.NatSalesOrderNo AS CalloffNatSalesOrderNo,
	s_soi_Calloffs.NatSalesOrderItemNo AS CalloffNatSalesOrderItemNo,
	s_soi_Contract.SOTypeCode,
	SalesTypesContract.IntSalesType AS IntSalesTypeCode,
	s_soi_Contract.CompanyCode,
	s_soi_Contract.SalesOrganization,
	s_soi_Contract.CurrencyCode,
       CONVERT(INT,FORMAT(s_sch_Contract.MaxSODeliveryDate,'yyyyMMdd')) AS MaxSODeliveryDate, --> NatSalesDelivDate
	   CONVERT(INT,FORMAT(s_sch_Contract.MinSODeliveryDate,'yyyyMMdd')) AS MinSODeliveryDate,
	CONVERT(TINYINT,1) AS IntCallOffSOStatusCode
,CASE WHEN con.ZXFP IS NOT NULL OR con.ZXFP <> 0 THEN 
                ISNULL(con.ZXFP,0)
                + ISNULL(con.ZXRD,0)
                + ISNULL(con.ZXSM,0)
                + ISNULL(con.ZXSC,0)
                + ISNULL(con.ZXWC,0)
                + ISNULL(con.ZXHF,0)
                + ISNULL(con.ZXFV,0)
                + ISNULL(con.[ZXF%],0)
                + ISNULL(con.ZXIN,0)
                + ISNULL(con.ZXDU,0)
				+ ISNULL(con.ZIUP,0)
			ELSE s_soi_Contract.GrossSalesValueUnit	END AS GrossSalesValueLC_Single --OnPrem NatDomGrossSalesValue
,ISNULL(s_soi_Contract.NetAmountUnit,0) AS InvoicedSalesValueLC_Single --OnPrem NatDomNetSalesValue 

,(ISNULL(s_soi_Contract.NetAmountUnit,0)+
		+ISNULL(con.ZRAS,0)--Return Accruals
        +ISNULL(con.ZGS1,0)
		+ISNULL(con.ZLSM,0)--Off-Invoice Growth Bonus
        +ISNULL(con.ZST1,0)--Off-Invoice Sell Through Bonus
        +ISNULL(con.ZCO1,0)--Off-Invoice Mark Down Bonus CCM
        +ISNULL(con.ZDCL,0)--Delcredere provision
		+ISNULL(con.ZSW1,0)-- Mkt SS Bonus
		/*+ISNULL(con.ZSKT,0)--cash discount removed EBPRP-1141 & EBPRP-1112*/
		+ISNULL(con.ZCDI,0))--cash discount
  AS NetSalesValueLC_Single  -- OnPrem NatSalesAttribute6 / Net2
,(ISNULL(con.ZSFP,0)+
  ISNULL(con.ZSRD,0)+
  ISNULL(con.ZSSM,0)+
  ISNULL(con.ZSSC,0)+
  ISNULL(con.ZSWC,0)+
  isnull(con.ZICF,0)+
  ISNULL(con.ZIHF,0)+
  ISNULL(con.ZIFV,0)+
  ISNULL(con.[ZIF%],0)+
  ISNULL(con.ZIIN,0)+
  ISNULL(con.ZIDU,0))
AS TotalCogsSplitLC_Single -- OnPrem NatSalesAttribute7 
	
,(ISNULL(con.ZSFP,0)+
  ISNULL(con.ZIFV,0)+
  ISNULL(con.[ZIF%],0)+
  ISNULL(con.ZIIN,0)+
  ISNULL(con.ZIDU,0))
AS TotalCogsSplitExclIntCompLC_Single -- On Prem NatSalesAttribute8         

,(ISNULL(con.ZSRD,0)+
  ISNULL(con.ZSSM,0)+
  ISNULL(con.ZSSC,0)+
  ISNULL(con.ZSWC,0)+
  ISNULL(con.ZICF,0)+
  ISNULL(con.ZIHF,0))
AS TotalIntCompCostLC_Single -- OnPrem NatSalesAttribute9

,(CASE 
			WHEN con.ZOFP IS NOT NULL THEN 
					con.ZOFP
					+ISNULL(con.[ZOF%],0)
					+ISNULL(con.[ZOFV],0)
					+ISNULL(con.[ZOVA],0)
					+ISNULL(con.ZOIC,0)
			WHEN con.ZSFP IS NOT NULL THEN 
					con.ZSFP
					+ISNULL(con.[ZIF%],0)
					+ISNULL(con.[ZIFV],0)
					+ISNULL(con.ZIIN,0)
					+ISNULL(con.ZICF,0) --added according to EBPRP-258 COGS4.0
					+ISNULL(con.ZIDU,0)
			WHEN con.VPRS IS NOT NULL THEN
					con.VPRS 
					-(ISNULL(con.ZSRD,0)
					+ISNULL(con.ZSSM,0)
					+ISNULL(con.ZSSC,0)
					+ISNULL(con.ZSWC,0)
					--+ISNULL(con.ZICF,0) --removed according to EBPRP-258 COGS4.0
					+ISNULL(con.ZIHF,0))
			ELSE
				ISNULL(con.ZCOS,0)
			END) 
AS ManagementCostLC_Single -- OnPrem NatSalesAttribute11  

,(ISNULL(con.ZFRH,0)+
  ISNULL(con.ZRY1,0)+
  ISNULL(con.ZRY2,0)+
  ISNULL(con.ZRY3,0)+
  ISNULL(con.ZESC,0)+
  ISNULL(con.ZCOC,0))
AS TotalOVCLC_Single -- OnPrem NatSalesAttribute12 

,ISNULL(con.ZSFP ,0) AS FPriceLC_Single -- OnPrem NatSalesAttribute13
,ISNULL(con.ZRAC ,0) AS ReturnAccrualsLC_Single -- OnPrem NatSalesAttribute14

,(CASE WHEN ZSFP IS NOT NULL THEN ISNULL(con.ZSFP,0)+
								  ISNULL(con.ZSRD,0)+
								  ISNULL(con.ZSSM,0)+
								  ISNULL(con.ZSSC,0)+
								  ISNULL(con.ZSWC,0)+
								  ISNULL(con.ZICF,0)+
								  ISNULL(con.ZIHF,0)+
								  ISNULL(con.ZIFV,0)+
								  ISNULL(con.[ZIF%],0)+
								  ISNULL(con.ZIIN,0)+
								  ISNULL(con.ZIDU,0)
		WHEN VPRS IS NOT NULL THEN VPRS 						
		ELSE ISNULL(con.ZCOS,0)	END) 
AS LandedCostValueLC_Single 
	,SoDocItemCalloffs.LDTS  CalloffContractLDTS

FROM #DistLdtsSoItems AS SoDocItemCalloffs
INNER JOIN biz.S4Hana_SoDocumentItemsHistory AS s_soi_Calloffs
	ON SoDocItemCalloffs.NatSalesOrderNo = s_soi_Calloffs.NatSalesOrderNo
	AND SoDocItemCalloffs.NatSalesOrderItemNo = s_soi_Calloffs.NatSalesOrderItemNo
	AND SoDocItemCalloffs.LDTS BETWEEN s_soi_Calloffs.LDTS AND s_soi_Calloffs.LEDTS
INNER JOIN biz.S4Hana_SoDocumentItemsHistory AS s_soi_Contract
	ON s_soi_Calloffs.ReferenceDocumentNumber = s_soi_Contract.NatSalesOrderNo
	AND s_soi_Calloffs.ReferenceDocumentItemNumber = s_soi_Contract.NatSalesOrderItemNo
	AND SoDocItemCalloffs.LDTS BETWEEN s_soi_Contract.LDTS AND s_soi_Contract.LEDTS
INNER JOIN biz.S4Hana_SOScheduleLineItemsAggHistory AS s_sch_Contract
	ON s_soi_Contract.NatSalesOrderNo = s_sch_Contract.NatSalesOrderNo
	AND s_soi_Contract.NatSalesOrderItemNo = s_sch_Contract.NatSalesOrderItemNo
	AND SoDocItemCalloffs.LDTS BETWEEN s_sch_Contract.LDTS AND s_sch_Contract.LEDTS
LEFT JOIN biz.S4Hana_SoDocItemPriceConditionsHistory AS con 
	ON s_soi_Contract.NatSalesOrderNo = con.NatSalesOrderNo
	AND s_soi_Contract.NatSalesOrderItemNo = con.NatSalesOrderItemNo
	AND SoDocItemCalloffs.LDTS BETWEEN con.LDTS AND con.LEDTS
INNER JOIN pdwref.S4Hana_SalesTypes AS SalesTypesContract
	ON s_soi_Contract.SOTypeCode = SalesTypesContract.SOTypeCode
WHERE 1=1
	AND SalesTypesContract.IntSalesType <> 3  --IntSalesTypeCode														 
	AND s_soi_Contract.SOTypeCode IN ('ZPOC', 'ZROC', 'ZCSC', 'ZMKC', 'ZCOC', 'ZRES','ZCCD','ZCLS') -- added for DI 20221025
	AND s_sch_Contract.IsDeleted = 0
	AND s_soi_Contract.RejectionReason = ''
UNION
-- Add related CallOffs for deleded Contracts
SELECT s_soi_Contract.NatSalesOrderNo AS ContractNatSalesOrderNo,
       s_soi_Contract.NatSalesOrderItemNo AS ContractNatSalesOrderItemNo,
	   s_soi_Calloffs.NatSalesOrderNo AS CalloffNatSalesOrderNo,
       s_soi_Calloffs.NatSalesOrderItemNo AS CalloffNatSalesOrderItemNo,
       s_soi_Contract.SOTypeCode,
       SalesTypesContract.IntSalesType AS IntSalesTypeCode,
	   	s_soi_Contract.CompanyCode,
	s_soi_Contract.SalesOrganization,
	s_soi_Contract.CurrencyCode,
       CONVERT(INT,FORMAT(MAX(s_sch_Contract.MaxSODeliveryDate),'yyyyMMdd')) AS MaxSODeliveryDate, --> NatSalesDelivDate
	   CONVERT(INT,FORMAT(MIN(s_sch_Contract.MinSODeliveryDate),'yyyyMMdd')) AS MinSODeliveryDate,
	   CONVERT(TINYINT,2) AS IntCallOffSOStatusCode
	   

	,CASE WHEN  SUM(con.ZXFP) <> 0 THEN 
					  SUM(ISNULL(con.ZXFP,0)  )
					+ SUM(ISNULL(con.ZXRD,0)  )
					+ SUM(ISNULL(con.ZXSM,0)  )
					+ SUM(ISNULL(con.ZXSC,0)  )
					+ SUM(ISNULL(con.ZXWC,0)  )
					+ SUM(ISNULL(con.ZXHF,0)  )
					+ SUM(ISNULL(con.ZXFV,0)  )
					+ SUM(ISNULL(con.[ZXF%],0))
					+ SUM(ISNULL(con.ZXIN,0)  )
					+ SUM(ISNULL(con.ZXDU,0)  )
					+ SUM(ISNULL(con.ZIUP,0)  )
				ELSE SUM(s_soi_Contract.GrossSalesValueUnit)	END AS GrossSalesValueLC_Single --OnPrem NatDomGrossSalesValue
	,SUM(ISNULL(s_soi_Contract.NetAmountUnit,0)) AS InvoicedSalesValueLC_Single --OnPrem NatDomNetSalesValue 
	
	,	    (SUM(ISNULL(s_soi_Contract.NetAmountUnit,0))
			+SUM(ISNULL(con.ZRAS,0) )--Return Accruals
			+SUM(ISNULL(con.ZGS1,0) )
			+SUM(ISNULL(con.ZLSM,0) )--Off-Invoice Growth Bonus
			+SUM(ISNULL(con.ZST1,0) )--Off-Invoice Sell Through Bonus
			+SUM(ISNULL(con.ZCO1,0) )--Off-Invoice Mark Down Bonus CCM
			+SUM(ISNULL(con.ZDCL,0) )--Delcredere provision
			+SUM(ISNULL(con.ZSW1,0) )-- Mkt SS Bonus
			+SUM(ISNULL(con.ZCDI,0)))--cash discount
	AS NetSalesValueLC_Single  -- OnPrem NatSalesAttribute6 / Net2
	,(  SUM(ISNULL(con.ZSFP,0))+
		SUM(ISNULL(con.ZSRD,0))+
		SUM(ISNULL(con.ZSSM,0))+
		SUM(ISNULL(con.ZSSC,0))+
		SUM(ISNULL(con.ZSWC,0))+
		SUM(isnull(con.ZICF,0))+
		SUM(ISNULL(con.ZIHF,0))+
		SUM(ISNULL(con.ZIFV,0))+
		SUM(ISNULL(con.[ZIF%],0))+
		SUM(ISNULL(con.ZIIN,0))+
		SUM(ISNULL(con.ZIDU,0)))
	AS TotalCogsSplitLC_Single -- OnPrem NatSalesAttribute7 
		
	,(SUM(ISNULL(con.ZSFP,0))+
	  SUM(ISNULL(con.ZIFV,0))+
	  SUM(ISNULL(con.[ZIF%],0))+
	  SUM(ISNULL(con.ZIIN,0))+
	  SUM(ISNULL(con.ZIDU,0)))
	AS TotalCogsSplitExclIntCompLC_Single -- On Prem NatSalesAttribute8         
	
	,(SUM(ISNULL(con.ZSRD,0))+
	  SUM(ISNULL(con.ZSSM,0))+
	  SUM(ISNULL(con.ZSSC,0))+
	  SUM(ISNULL(con.ZSWC,0))+
	  SUM(ISNULL(con.ZICF,0))+
	  SUM(ISNULL(con.ZIHF,0)))
	AS TotalIntCompCostLC_Single -- OnPrem NatSalesAttribute9
	
	,(CASE 
				WHEN SUM(ISNULL(con.ZOFP,0)) <> 0 THEN 
						SUM(con.ZOFP)
						+SUM(ISNULL(con.[ZOF%],0))
						+SUM(ISNULL(con.[ZOFV],0))
						+SUM(ISNULL(con.[ZOVA],0))
						+SUM(ISNULL(con.ZOIC,0)	 )
				WHEN SUM(ISNULL(con.ZSFP,0)) <> 0 THEN 
						SUM(con.ZSFP)
						+SUM(ISNULL(con.[ZIF%],0))
						+SUM(ISNULL(con.[ZIFV],0))
						+SUM(ISNULL(con.ZIIN,0)	 )
						+SUM(ISNULL(con.ZICF,0)  ) --added according to EBPRP-258 COGS4.0
						+SUM(ISNULL(con.ZIDU,0)	 )
				WHEN SUM(ISNULL(con.VPRS,0)) <> 0 THEN 
						SUM(con.VPRS)
						-( SUM(ISNULL(con.ZSRD,0) )
						  +SUM(ISNULL(con.ZSSM,0) )
						  +SUM(ISNULL(con.ZSSC,0) )
						  +SUM(ISNULL(con.ZSWC,0) )
						+  SUM(ISNULL(con.ZIHF,0)))
				ELSE
					SUM(ISNULL(con.ZCOS,0))
				END) 
	AS ManagementCostLC_Single -- OnPrem NatSalesAttribute11  
	
	,(SUM(ISNULL(con.ZFRH,0))+
	  SUM(ISNULL(con.ZRY1,0))+
	  SUM(ISNULL(con.ZRY2,0))+
	  SUM(ISNULL(con.ZRY3,0))+
	  SUM(ISNULL(con.ZESC,0))+
	  SUM(ISNULL(con.ZCOC,0)))
	AS TotalOVCLC_Single -- OnPrem NatSalesAttribute12 
	
	,SUM(ISNULL(con.ZSFP ,0)) AS FPriceLC_Single -- OnPrem NatSalesAttribute13
	,SUM(ISNULL(con.ZRAC ,0)) AS ReturnAccrualsLC_Single -- OnPrem NatSalesAttribute14
	
	,(CASE WHEN SUM(ISNULL(ZSFP,0)) <> 0 THEN 
									  SUM(ISNULL(con.ZSFP,0))+
									  SUM(ISNULL(con.ZSRD,0))+
									  SUM(ISNULL(con.ZSSM,0))+
									  SUM(ISNULL(con.ZSSC,0))+
									  SUM(ISNULL(con.ZSWC,0))+
									  SUM(ISNULL(con.ZICF,0))+
									  SUM(ISNULL(con.ZIHF,0))+
									  SUM(ISNULL(con.ZIFV,0))+
									  SUM(ISNULL(con.[ZIF%],0))+
									  SUM(ISNULL(con.ZIIN,0))+
									  SUM(ISNULL(con.ZIDU,0))
			WHEN SUM(VPRS) <> 0 THEN  SUM(VPRS)						
			ELSE SUM(ISNULL(con.ZCOS,0))	END)
			
	AS LandedCostValueLC_Single 
	,MIN(SoDocItemCalloffs.LDTS) MinOrdersOnHandDateTime	
FROM #DistLdtsSoItems AS SoDocItemCalloffs
INNER JOIN biz.S4Hana_SoDocumentItemsHistory AS s_soi_Calloffs
	ON SoDocItemCalloffs.NatSalesOrderNo = s_soi_Calloffs.ReferenceDocumentNumber
	AND SoDocItemCalloffs.NatSalesOrderItemNo = s_soi_Calloffs.ReferenceDocumentItemNumber
	AND SoDocItemCalloffs.LDTS BETWEEN s_soi_Calloffs.LDTS AND s_soi_Calloffs.LEDTS
INNER JOIN biz.S4Hana_SoDocumentItemsHistory AS s_soi_Contract
	ON SoDocItemCalloffs.NatSalesOrderNo = s_soi_Contract.NatSalesOrderNo
	AND SoDocItemCalloffs.NatSalesOrderItemNo = s_soi_Contract.NatSalesOrderItemNo
	AND SoDocItemCalloffs.LDTS BETWEEN s_soi_Contract.LDTS AND s_soi_Contract.LEDTS
INNER JOIN biz.S4Hana_SOScheduleLineItemsAggHistory AS s_sch_Contract
	ON s_soi_Contract.NatSalesOrderNo = s_sch_Contract.NatSalesOrderNo
	AND s_soi_Contract.NatSalesOrderItemNo = s_sch_Contract.NatSalesOrderItemNo
	AND SoDocItemCalloffs.LDTS BETWEEN s_sch_Contract.LDTS AND s_sch_Contract.LEDTS
LEFT JOIN biz.S4Hana_SoDocItemPriceConditionsHistory AS con 
	ON s_soi_Contract.NatSalesOrderNo = con.NatSalesOrderNo
	AND s_soi_Contract.NatSalesOrderItemNo = con.NatSalesOrderItemNo
	AND SoDocItemCalloffs.LDTS BETWEEN con.LDTS AND con.LEDTS
INNER JOIN pdwref.S4Hana_SalesTypes AS SalesTypesContract
	ON s_soi_Contract.SOTypeCode = SalesTypesContract.SOTypeCode
WHERE 1=1
	AND s_soi_Contract.RejectionReason <> ''
	AND SalesTypesContract.IntSalesType <> 3  --IntSalesTypeCode
	AND s_soi_Calloffs.RejectionReason = ''
	AND s_soi_Contract.SOTypeCode IN ('ZPOC', 'ZROC', 'ZCSC', 'ZMKC', 'ZCOC', 'ZRES','ZCCD','ZCLS')
GROUP BY s_soi_Contract.NatSalesOrderNo,
		 s_soi_Contract.NatSalesOrderItemNo,
		 s_soi_Calloffs.NatSalesOrderNo,
		 s_soi_Calloffs.NatSalesOrderItemNo,
		 s_soi_Contract.SOTypeCode,
		 SalesTypesContract.IntSalesType,
		 	s_soi_Contract.CompanyCode,
	s_soi_Contract.SalesOrganization,
	s_soi_Contract.CurrencyCode
);

IF OBJECT_ID('tempdb..#AllSalesOrderOoHHist') IS NOT NULL
BEGIN
    DROP TABLE #AllSalesOrderOoHHist
END										 

CREATE TABLE #AllSalesOrderOoHHist
WITH (DISTRIBUTION = HASH(NatSalesOrderNo),HEAP) AS
WITH PreLogicOhhLogic AS ( -- Collect all data for the basic for Booking in Cross booking
SELECT 
SoDocItem.LDTS AS OrdersOnHandsDateTime, -- cross booking has to be at the same date with the new entry
CASE WHEN s_soi.RejectionReason <> '' THEN 2 -- still in, from the old logic
	 WHEN CASE WHEN SoDocItem.LDTS > '2026-02-01' THEN ISNULL(DelDocItem.CompletedDeliveryQuantity,0) ELSE ISNULL(DelDocItem.ActualDeliveryQuantity,0) END < s_sch.ConfirmedQty THEN 1  -- DelDocItem.ActualDeliveryQuantity incl. logic in BIZ for ActDelQty if ActualGMovementDate is availible (NOT NULL)
	 WHEN CASE WHEN SoDocItem.LDTS > '2026-02-01' THEN ISNULL(DelDocItem.CompletedDeliveryQuantity,0) ELSE ISNULL(DelDocItem.ActualDeliveryQuantity,0) END >= s_sch.ConfirmedQty THEN  3
	 ELSE 3 END	
AS IntSOStatusCode,
CASE WHEN s_soi.IsDeleted = 1 THEN 1
	 WHEN s_sch.IsDeleted = 1 THEN 1
	 WHEN stagMaterial.MaterialCategoryCode = '01' THEN 1
	 ELSE 0	END
AS IsDeleted,
SalesTypes.IntSalesType,
s_soi.NatSalesOrderNo,
s_soi.NatSalesOrderItemNo,

s_soi.ReferenceDocumentNumber,
s_soi.ReferenceDocumentItemNumber,
s_soi.CompanyCode,
CONVERT(NVARCHAR(20), CONCAT(LTRIM(RTRIM(s_soi.CustomerCode_SoldTo)), '|',s_soi.SalesOrganization )) AS NatCustomer_BK,
CONVERT(NVARCHAR(40), CONCAT(LTRIM(RTRIM(s_soi.MaterialNumber)), '|', CASE WHEN LTRIM(RTRIM(s_soi.CompanyCode)) = 'PT10' THEN 'ES10' ELSE LTRIM(RTRIM(s_soi.CompanyCode))END)) AS NatArticle_BK, -- bk at ref.NatArticle_BK
CONVERT(NVARCHAR(20), LTRIM(RTRIM(REPLACE(s_soi.MaterialNumber,'-',' ')))) AS ArticleSize_BK, -- bk at ref.ArticleSize			
CONVERT(INT,ISNULL(TRY_CONVERT(INT,stagMaterial.StyleNo),0)) AS StyleNumber_BK,
CONVERT(CHAR(9), CASE WHEN CHARINDEX('-',LTRIM(stagMaterial.MaterialNumber)) <> 7 
						THEN NULL 
						ELSE REPLACE(LEFT(stagMaterial.MaterialNumber,9),'-',' ') END) AS ArticleNumber_BK,
CONVERT(INT,FORMAT(CAST(s_sch.MaxSODeliveryDate AS DATE),'yyyyMMdd')) AS SODeliveryDate,
CONVERT(INT,FORMAT(CAST(s_sch.MinSODeliveryDate AS DATE),'yyyyMMdd')) AS SOPlannedDeliveryDate,
s_soi.CurrencyCode,
CONVERT(INT,ISNULL(TRY_CONVERT(INT,stagMaterial.RBUCode),0)) AS RBUCode, -- new
stagMaterial.BrandCode, -- new
CONVERT(INT,ISNULL(TRY_CONVERT(INT,stagMaterial.ProdDivCode),0)) AS ProdDivCode, -- new
s_soi.SOTypeCode,
SalesTypes.IntSalesType AS IntSalesTypeCode
,CASE WHEN s_soi.RejectionReason <> '' and s_soi.SOTypeCode in( 'ZPTO', 'ZPKP') 
		THEN  s_soi.OrderQuantity 
		ELSE s_sch.ConfirmedQty END 
AS OrderedQty

,s_sch.ConfirmedQty AS ConfirmedQty
,ISNULL(DelDocItem.ActualDeliveryQuantity,0) AS ActualDeliveryQuantity -- Added to seperate the CallOffs from the normal OOH Qty logic
,CASE WHEN s_soi.RejectionReason <> '' and s_soi.SOTypeCode in( 'ZPTO', 'ZPKP') 
			THEN  s_soi.OrderQuantity - ISNULL(CASE WHEN SoDocItem.LDTS > '2026-02-01' THEN ISNULL(DelDocItem.CompletedDeliveryQuantity,0) ELSE ISNULL(DelDocItem.ActualDeliveryQuantity,0) END,0) 
			ELSE s_sch.ConfirmedQty - ISNULL(CASE WHEN SoDocItem.LDTS > '2026-02-01' THEN ISNULL(DelDocItem.CompletedDeliveryQuantity,0) ELSE ISNULL(DelDocItem.ActualDeliveryQuantity,0) END,0) END 
AS OOHUnits
,CASE WHEN con.ZXFP IS NOT NULL OR con.ZXFP <> 0 THEN 
                ISNULL(con.ZXFP,0)
                + ISNULL(con.ZXRD,0)
                + ISNULL(con.ZXSM,0)
                + ISNULL(con.ZXSC,0)
                + ISNULL(con.ZXWC,0)
                + ISNULL(con.ZXHF,0)
                + ISNULL(con.ZXFV,0)
                + ISNULL(con.[ZXF%],0)
                + ISNULL(con.ZXIN,0)
                + ISNULL(con.ZXDU,0)
				+ ISNULL(con.ZIUP,0)
			ELSE s_soi.GrossSalesValueUnit	END AS GrossSalesValueLC_Single --OnPrem NatDomGrossSalesValue
,ISNULL(s_soi.NetAmountUnit,0) AS InvoicedSalesValueLC_Single --OnPrem NatDomNetSalesValue 

,(ISNULL(s_soi.NetAmountUnit,0)+
		+ISNULL(con.ZRAS,0)--Return Accruals
        +ISNULL(con.ZGS1,0)
		+ISNULL(con.ZLSM,0)--Off-Invoice Growth Bonus
        +ISNULL(con.ZST1,0)--Off-Invoice Sell Through Bonus
        +ISNULL(con.ZCO1,0)--Off-Invoice Mark Down Bonus CCM
        +ISNULL(con.ZDCL,0)--Delcredere provision
		+ISNULL(con.ZSW1,0)-- Mkt SS Bonus
		/*+ISNULL(con.ZSKT,0)--cash discount removed EBPRP-1141 & EBPRP-1112*/
		+ISNULL(con.ZCDI,0))--cash discount
  AS NetSalesValueLC_Single  -- OnPrem NatSalesAttribute6 / Net2
,(ISNULL(con.ZSFP,0)+
  ISNULL(con.ZSRD,0)+
  ISNULL(con.ZSSM,0)+
  ISNULL(con.ZSSC,0)+
  ISNULL(con.ZSWC,0)+
  isnull(con.ZICF,0)+
  ISNULL(con.ZIHF,0)+
  ISNULL(con.ZIFV,0)+
  ISNULL(con.[ZIF%],0)+
  ISNULL(con.ZIIN,0)+
  ISNULL(con.ZIDU,0))
AS TotalCogsSplitLC_Single -- OnPrem NatSalesAttribute7 
	
,(ISNULL(con.ZSFP,0)+
  ISNULL(con.ZIFV,0)+
  ISNULL(con.[ZIF%],0)+
  ISNULL(con.ZIIN,0)+
  ISNULL(con.ZIDU,0))
AS TotalCogsSplitExclIntCompLC_Single -- On Prem NatSalesAttribute8         

,(ISNULL(con.ZSRD,0)+
  ISNULL(con.ZSSM,0)+
  ISNULL(con.ZSSC,0)+
  ISNULL(con.ZSWC,0)+
  ISNULL(con.ZICF,0)+
  ISNULL(con.ZIHF,0))
AS TotalIntCompCostLC_Single -- OnPrem NatSalesAttribute9

,(CASE 
			WHEN con.ZOFP IS NOT NULL THEN 
					con.ZOFP
					+ISNULL(con.[ZOF%],0)
					+ISNULL(con.[ZOFV],0)
					+ISNULL(con.[ZOVA],0)
					+ISNULL(con.ZOIC,0)
			WHEN con.ZSFP IS NOT NULL THEN 
					con.ZSFP
					+ISNULL(con.[ZIF%],0)
					+ISNULL(con.[ZIFV],0)
					+ISNULL(con.ZIIN,0)
					+ISNULL(con.ZICF,0) --added according to EBPRP-258 COGS4.0
					+ISNULL(con.ZIDU,0)
			WHEN con.VPRS IS NOT NULL THEN
					con.VPRS 
					-(ISNULL(con.ZSRD,0)
					+ISNULL(con.ZSSM,0)
					+ISNULL(con.ZSSC,0)
					+ISNULL(con.ZSWC,0)
					--+ISNULL(con.ZICF,0) --removed according to EBPRP-258 COGS4.0
					+ISNULL(con.ZIHF,0))
			ELSE
				ISNULL(con.ZCOS,0)
			END) 
AS ManagementCostLC_Single -- OnPrem NatSalesAttribute11  

,(ISNULL(con.ZFRH,0)+
  ISNULL(con.ZRY1,0)+
  ISNULL(con.ZRY2,0)+
  ISNULL(con.ZRY3,0)+
  ISNULL(con.ZESC,0)+
  ISNULL(con.ZCOC,0))
AS TotalOVCLC_Single -- OnPrem NatSalesAttribute12 

,ISNULL(con.ZSFP ,0) AS FPriceLC_Single -- OnPrem NatSalesAttribute13
,ISNULL(con.ZRAC ,0) AS ReturnAccrualsLC_Single -- OnPrem NatSalesAttribute14

,(CASE WHEN ZSFP IS NOT NULL THEN ISNULL(con.ZSFP,0)+
								  ISNULL(con.ZSRD,0)+
								  ISNULL(con.ZSSM,0)+
								  ISNULL(con.ZSSC,0)+
								  ISNULL(con.ZSWC,0)+
								  ISNULL(con.ZICF,0)+
								  ISNULL(con.ZIHF,0)+
								  ISNULL(con.ZIFV,0)+
								  ISNULL(con.[ZIF%],0)+
								  ISNULL(con.ZIIN,0)+
								  ISNULL(con.ZIDU,0)
		WHEN VPRS IS NOT NULL THEN VPRS 						
		ELSE ISNULL(con.ZCOS,0)	END) 
AS LandedCostValueLC_Single 

,CONVERT(TINYINT,
		 CASE WHEN s_soi.PrecedingDocumentCategory = 'G' THEN 1 
			ELSE 0 END)
AS NatSalesCustomFlag
,s_soi.SalesOrganization
FROM #DistLdtsSoItems AS SoDocItem
INNER JOIN biz.S4Hana_SoDocumentItemsHistory AS s_soi
	ON SoDocItem.NatSalesOrderNo = s_soi.NatSalesOrderNo
	AND SoDocItem.NatSalesOrderItemNo = s_soi.NatSalesOrderItemNo
	AND SoDocItem.LDTS BETWEEN s_soi.LDTS AND s_soi.LEDTS
LEFT JOIN biz.S4Hana_SoDocItemPriceConditionsHistory AS con 
	ON SoDocItem.NatSalesOrderNo = con.NatSalesOrderNo
	AND SoDocItem.NatSalesOrderItemNo = con.NatSalesOrderItemNo
	AND SoDocItem.LDTS BETWEEN con.LDTS AND con.LEDTS
INNER JOIN biz.S4Hana_SOScheduleLineItemsAggHistory AS s_sch
	ON SoDocItem.NatSalesOrderNo = s_sch.NatSalesOrderNo
	AND SoDocItem.NatSalesOrderItemNo = s_sch.NatSalesOrderItemNo
	AND SoDocItem.LDTS BETWEEN s_sch.LDTS AND s_sch.LEDTS
INNER JOIN stag.S4Hana_vMaterials AS stagMaterial
	ON s_soi.MaterialNumber = stagMaterial.MaterialNumber
INNER JOIN pdwref.S4Hana_SalesTypes AS SalesTypes 
	ON s_soi.SOTypeCode = SalesTypes.SOTypeCode		  
LEFT JOIN biz.S4Hana_DeliveryDocumentAggSoItemsHistory AS DelDocItem
	ON SoDocItem.NatSalesOrderNo = DelDocItem.NatSalesOrderNo
	AND SoDocItem.NatSalesOrderItemNo = DelDocItem.NatSalesOrderItemNo
	AND SoDocItem.LDTS BETWEEN DelDocItem.LDTS AND DelDocItem.LEDTS
WHERE SalesTypes.IntSalesType <> 3
)
SELECT OrdersOnHandsDateTime
	  ,CONVERT(TINYINT,IntSOStatusCode) AS IntSOStatusCode
	  ,1 as RecordStatus -- 1 - open bookings and calloffs
	  ,CONVERT(TINYINT,IsDeleted) AS IsDeleted
	  ,CONVERT(TINYINT,1) AS BookingDataSourceInfo
      ,NatSalesOrderNo
      ,CONVERT(VARCHAR(40),NatSalesOrderItemNo) AS NatSalesOrderItemNo
        ,CompanyCode
		,SalesOrganization
        ,NatCustomer_BK
        ,NatArticle_BK
		,ArticleSize_BK
		,StyleNumber_BK
		,ArticleNumber_BK
		,SODeliveryDate
		,SOPlannedDeliveryDate
        ,CurrencyCode
        ,RBUCode
        ,BrandCode
        ,ProdDivCode
		,SOTypeCode
		,IntSalesTypeCode
        ,OrderedQty
        ,ConfirmedQty
		,OOHUnits
        ,CONVERT(DECIMAL(38,25),GrossSalesValueLC_Single * ABS(OOHUnits)) AS GrossSalesValueLC
        ,CONVERT(DECIMAL(38,25),InvoicedSalesValueLC_Single * ABS(OOHUnits)) AS InvoicedSalesValueLC
        ,CONVERT(DECIMAL(38,25),NetSalesValueLC_Single * ABS(OOHUnits)) AS NetSalesValueLC
        ,CONVERT(DECIMAL(38,25),TotalCogsSplitLC_Single * ABS(OOHUnits)) AS TotalCogsSplitLC
        ,CONVERT(DECIMAL(38,25),TotalCogsSplitExclIntCompLC_Single * ABS(OOHUnits)) AS TotalCogsSplitExclIntCompLC
        ,CONVERT(DECIMAL(38,25),TotalIntCompCostLC_Single * ABS(OOHUnits)) AS TotalIntCompCostLC
        ,CONVERT(DECIMAL(38,25),ManagementCostLC_Single * ABS(OOHUnits)) AS ManagementCostLC
        ,CONVERT(DECIMAL(38,25),TotalOVCLC_Single * ABS(OOHUnits)) AS TotalOVCLC
        ,CONVERT(DECIMAL(38,25),FPriceLC_Single * ABS(OOHUnits)) AS FPriceLC
        ,CONVERT(DECIMAL(38,25),ReturnAccrualsLC_Single * ABS(OOHUnits)) AS ReturnAccrualsLC
		,CONVERT(DECIMAL(38,25),LandedCostValueLC_Single * ABS(OOHUnits)) AS LandedCostValueLC
		,CONVERT(BINARY(16), HASHBYTES('MD5', CONCAT (
			UPPER(LTRIM(RTRIM(NatSalesOrderNo))),'_',
			UPPER(LTRIM(RTRIM(NatSalesOrderItemNo))),'_',
			UPPER(LTRIM(RTRIM(CompanyCode))),'_',
			UPPER(LTRIM(RTRIM(NatCustomer_BK))),'_',
			UPPER(LTRIM(RTRIM(NatArticle_BK))),'_', -- ArticleSize & Article_BK is incl.
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), StyleNumber_BK)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), SODeliveryDate)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), SOPlannedDeliveryDate)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), CurrencyCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), RBUCode)))),'_', 
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), BrandCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), ProdDivCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), SOTypeCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), IntSalesTypeCode)))),'_',					
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), OrderedQty)))),'_', 
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), ConfirmedQty)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), OOHUnits)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), GrossSalesValueLC_Single * ABS(OOHUnits))))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), InvoicedSalesValueLC_Single * ABS(OOHUnits))))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), NetSalesValueLC_Single * ABS(OOHUnits))))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), TotalCogsSplitLC_Single * ABS(OOHUnits))))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), TotalCogsSplitExclIntCompLC_Single * ABS(OOHUnits))))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), TotalIntCompCostLC_Single * ABS(OOHUnits))))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), ManagementCostLC_Single * ABS(OOHUnits))))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), TotalOVCLC_Single * ABS(OOHUnits))))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), FPriceLC_Single * ABS(OOHUnits))))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), ReturnAccrualsLC_Single * ABS(OOHUnits))))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), LandedCostValueLC_Single * ABS(OOHUnits))))),'_',			
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), IntSOStatusCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), IsDeleted))))
		))) AS HashDiff 
FROM PreLogicOhhLogic
UNION ALL
--calloffs for the contract
SELECT CASE WHEN Contr.IntCallOffSOStatusCode = 2 THEN Contr.CalloffContractLDTS ELSE CallOff.OrdersOnHandsDateTime END OrdersOnHandsDateTime
	  ,CASE WHEN CallOff.IntSOStatusCode = 2 OR Contr.IntCallOffSOStatusCode = 2 THEN CONVERT(TINYINT,2) ELSE CONVERT(TINYINT,1) END AS IntSOStatusCode-- has to be always going through at call off, independent of the real status from the Delivery Note Information
	  ,IntCallOffSOStatusCode as RecordStatus -- 2 is calloffs for cancelled contracts
	  ,CONVERT(TINYINT,CallOff.IsDeleted) AS IsDeleted
	  ,CONVERT(TINYINT,2) AS BookingDataSourceInfo -- CallOffs of the Contract to reduce the contract total quantity
      ,Contr.ContractNatSalesOrderNo AS NatSalesOrderNo
      ,CONVERT(VARCHAR(40),CONCAT(Contr.ContractNatSalesOrderItemNo, '-', CallOff.NatSalesOrderNo, '-', CallOff.NatSalesOrderItemNo, '_OoH')) AS NatSalesOrderItemNo 
	  ,Contr.CompanyCode
	  ,Contr.SalesOrganization					
      ,CallOff.NatCustomer_BK
      ,CallOff.NatArticle_BK
	  ,CallOff.ArticleSize_BK
	  ,CallOff.StyleNumber_BK
	  ,CallOff.ArticleNumber_BK
	  ,Contr.MaxSODeliveryDate AS SODeliveryDate
	  ,Contr.MinSODeliveryDate AS SOPlannedDeliveryDate
      ,Contr.CurrencyCode
      ,CallOff.RBUCode
      ,CallOff.BrandCode
      ,CallOff.ProdDivCode
	  ,Contr.SOTypeCode
	  ,Contr.IntSalesTypeCode
	  ,CallOff.OrderedQty * -1 AS  OrderedQty
	  ,CallOff.ConfirmedQty * -1 AS ConfirmedQty
	  ,CallOff.ConfirmedQty * -1  AS OOHUnits -- at the CallOff take always the ConfirmedQty
	  ,CONVERT(DECIMAL(38,25),Contr.GrossSalesValueLC_Single * ABS(CallOff.ConfirmedQty) * -1) AS GrossSalesValueLC
	  ,CONVERT(DECIMAL(38,25),Contr.InvoicedSalesValueLC_Single * ABS(CallOff.ConfirmedQty) * -1) AS InvoicedSalesValueLC
	  ,CONVERT(DECIMAL(38,25),Contr.NetSalesValueLC_Single * ABS(CallOff.ConfirmedQty) * -1) AS NetSalesValueLC
	  ,CONVERT(DECIMAL(38,25),Contr.TotalCogsSplitLC_Single * ABS(CallOff.ConfirmedQty) * -1) AS TotalCogsSplitLC
	  ,CONVERT(DECIMAL(38,25),Contr.TotalCogsSplitExclIntCompLC_Single * ABS(CallOff.ConfirmedQty) * -1) AS TotalCogsSplitExclIntCompLC
	  ,CONVERT(DECIMAL(38,25),Contr.TotalIntCompCostLC_Single * ABS(CallOff.ConfirmedQty) * -1) AS TotalIntCompCostLC
	  ,CONVERT(DECIMAL(38,25),Contr.ManagementCostLC_Single * ABS(CallOff.ConfirmedQty) * -1) AS ManagementCostLC
	  ,CONVERT(DECIMAL(38,25),Contr.TotalOVCLC_Single * ABS(CallOff.ConfirmedQty) * -1) AS TotalOVCLC
	  ,CONVERT(DECIMAL(38,25),Contr.FPriceLC_Single * ABS(CallOff.ConfirmedQty) * -1) AS FPriceLC
	  ,CONVERT(DECIMAL(38,25),Contr.ReturnAccrualsLC_Single * ABS(CallOff.ConfirmedQty) * -1) AS ReturnAccrualsLC
	  ,CONVERT(DECIMAL(38,25),Contr.LandedCostValueLC_Single * ABS(CallOff.ConfirmedQty) * -1) AS LandedCostValueLC
	  ,CONVERT(BINARY(16), HASHBYTES('MD5',
	      CONCAT(
	          UPPER(LTRIM(RTRIM(ISNULL(Contr.ContractNatSalesOrderNo,'')))), '_',
	          UPPER(LTRIM(RTRIM(ISNULL(CONVERT(NVARCHAR(200),
	              CONCAT(Contr.ContractNatSalesOrderItemNo, '-', CallOff.NatSalesOrderNo, '-', CallOff.NatSalesOrderItemNo, '_OoH')
	          ),'')))), '_',
	          UPPER(LTRIM(RTRIM(ISNULL(Contr.CompanyCode,'')))), '_',
	          UPPER(LTRIM(RTRIM(ISNULL(Contr.SalesOrganization,'')))), '_',
	          UPPER(LTRIM(RTRIM(ISNULL(CallOff.NatCustomer_BK,'')))), '_',
	          UPPER(LTRIM(RTRIM(ISNULL(CallOff.NatArticle_BK,'')))), '_',
	          UPPER(LTRIM(RTRIM(ISNULL(CallOff.ArticleSize_BK,'')))), '_',
	          UPPER(LTRIM(RTRIM(ISNULL(CONVERT(NVARCHAR(200), CallOff.StyleNumber_BK),'')))), '_',
	          UPPER(LTRIM(RTRIM(ISNULL(CONVERT(NVARCHAR(200), Contr.MaxSODeliveryDate),'')))),'_',
	          UPPER(LTRIM(RTRIM(ISNULL(CONVERT(NVARCHAR(200), Contr.MinSODeliveryDate),'')))),'_',
	          UPPER(LTRIM(RTRIM(ISNULL(CONVERT(NVARCHAR(200), Contr.CurrencyCode),'')))), '_',
	          UPPER(LTRIM(RTRIM(ISNULL(CONVERT(NVARCHAR(200), CallOff.RBUCode),'')))), '_',
	          UPPER(LTRIM(RTRIM(ISNULL(CONVERT(NVARCHAR(200), CallOff.BrandCode),'')))), '_',
	          UPPER(LTRIM(RTRIM(ISNULL(CONVERT(NVARCHAR(200), CallOff.ProdDivCode),'')))), '_',
	          UPPER(LTRIM(RTRIM(ISNULL(CONVERT(NVARCHAR(200), Contr.SOTypeCode),'')))), '_',
	          UPPER(LTRIM(RTRIM(ISNULL(CONVERT(NVARCHAR(200), Contr.IntSalesTypeCode),'')))), '_',
	          ISNULL(CONVERT(NVARCHAR(200), CONVERT(DECIMAL(38,25), CallOff.OrderedQty * -1)),''), '_',
	          ISNULL(CONVERT(NVARCHAR(200), CONVERT(DECIMAL(38,25), CallOff.ConfirmedQty * -1)),''), '_',
	          ISNULL(CONVERT(NVARCHAR(200), CONVERT(DECIMAL(38,25), CallOff.ConfirmedQty * -1)),''), '_', -- OOHUnits
	          ISNULL(CONVERT(NVARCHAR(200), CONVERT(DECIMAL(38,25), Contr.GrossSalesValueLC_Single              * ABS(CallOff.ConfirmedQty) * -1)),''), '_',
	          ISNULL(CONVERT(NVARCHAR(200), CONVERT(DECIMAL(38,25), Contr.InvoicedSalesValueLC_Single            * ABS(CallOff.ConfirmedQty) * -1)),''), '_',
	          ISNULL(CONVERT(NVARCHAR(200), CONVERT(DECIMAL(38,25), Contr.NetSalesValueLC_Single                 * ABS(CallOff.ConfirmedQty) * -1)),''), '_',
	          ISNULL(CONVERT(NVARCHAR(200), CONVERT(DECIMAL(38,25), Contr.TotalCogsSplitLC_Single                * ABS(CallOff.ConfirmedQty) * -1)),''), '_',
	          ISNULL(CONVERT(NVARCHAR(200), CONVERT(DECIMAL(38,25), Contr.TotalCogsSplitExclIntCompLC_Single     * ABS(CallOff.ConfirmedQty) * -1)),''), '_',
	          ISNULL(CONVERT(NVARCHAR(200), CONVERT(DECIMAL(38,25), Contr.TotalIntCompCostLC_Single              * ABS(CallOff.ConfirmedQty) * -1)),''), '_',
	          ISNULL(CONVERT(NVARCHAR(200), CONVERT(DECIMAL(38,25), Contr.ManagementCostLC_Single                * ABS(CallOff.ConfirmedQty) * -1)),''), '_',
	          ISNULL(CONVERT(NVARCHAR(200), CONVERT(DECIMAL(38,25), Contr.TotalOVCLC_Single                      * ABS(CallOff.ConfirmedQty) * -1)),''), '_',
	          ISNULL(CONVERT(NVARCHAR(200), CONVERT(DECIMAL(38,25), Contr.FPriceLC_Single                         * ABS(CallOff.ConfirmedQty) * -1)),''), '_',
	          ISNULL(CONVERT(NVARCHAR(200), CONVERT(DECIMAL(38,25), Contr.ReturnAccrualsLC_Single                 * ABS(CallOff.ConfirmedQty) * -1)),''), '_',
	          ISNULL(CONVERT(NVARCHAR(200), CONVERT(DECIMAL(38,25), Contr.LandedCostValueLC_Single                * ABS(CallOff.ConfirmedQty) * -1)),''), '_',
	          CONVERT(NVARCHAR(10),
	              CASE
	                  WHEN CallOff.IntSOStatusCode = 2 OR Contr.IntCallOffSOStatusCode = 2 THEN CONVERT(TINYINT,2)
	                  ELSE CONVERT(TINYINT,1)
	              END
	          ), '_',
	          ISNULL(CONVERT(NVARCHAR(10), CONVERT(TINYINT, Contr.IntCallOffSOStatusCode)),''), '_',
	          ISNULL(CONVERT(NVARCHAR(10), CONVERT(TINYINT, CallOff.IsDeleted)), '')
	      )
	  )) AS HashDiff

FROM PreLogicOhhLogic AS CallOff
INNER JOIN #SoDocumentCallOffContractInfo AS Contr 
		ON CallOff.NatSalesOrderNo = Contr.CalloffNatSalesOrderNo
		AND CallOff.NatSalesOrderItemNo = Contr.CalloffNatSalesOrderItemNo
		AND Calloff.OrdersOnHandsDateTime = Contr.CalloffContractLDTS
WHERE CallOff.NatSalesCustomFlag = 1 -- only Calloff Records
	-- AND IntSOStatusCode = 1 --> moved to insert into final table
-- Extend list of Distinct new entries with the Contract SalesOrder

--Check for new bookings for artificial calloffs of cancelled contracts and delete those from AllSOs

IF OBJECT_ID('tempdb..#ChangedCancelledCalloffs') IS NOT NULL
BEGIN
    DROP TABLE #ChangedCancelledCalloffs
END

select SO.OrdersOnHandsDateTime
,SO.IntSOStatusCode
,SO.NatSalesOrderNo
,SO.NatSalesOrderItemNo 
into #ChangedCancelledCalloffs
from #AllSalesOrderOoHHist So 
inner join biz.S4Hana_SoDocumentItemsHistory as Contr on Contr.NatSalesOrderNo=So.NatSalesOrderNo and Contr.NatSalesOrderItemNo = left(SO.NatSalesOrderItemNo,6)
where SO.IntSOStatusCode = 1 and Contr.RejectionReason <> '' and SO.OrdersOnHandsDateTime between Contr.LDTS and Contr.LEDTS


DELETE AllSos FROM #AllSalesOrderOoHHist AllSos
INNER JOIN #ChangedCancelledCalloffs CCC ON
AllSos.OrdersOnHandsDateTime   = CCC.OrdersOnHandsDateTime
and AllSos.IntSOStatusCode     = CCC.IntSOStatusCode
and AllSos.NatSalesOrderNo	   = CCC.NatSalesOrderNo
and AllSos.NatSalesOrderItemNo = CCC.NatSalesOrderItemNo 


;WITH NewDistinctIncrement AS (
SELECT DISTINCT  
       NatSalesOrderNo
      ,NatSalesOrderItemNo
	  FROM #AllSalesOrderOoHHist)
,LastReleatedBookingEntrieFromHist AS (
SELECT CONVERT(DATETIME2(0),(CONVERT(DATETIME, CONVERT(VARCHAR(255), salesHist.OrdersOnHandDate)) +
							 CONVERT(DATETIME, TIMEFROMPARTS(salesHist.OrdersOnHandTime / 10000, (salesHist.OrdersOnHandTime / 100) % 100, salesHist.OrdersOnHandTime % 100, 0, 0)))) 	 
      AS OrdersOnHandsDateTime
      ,CONVERT(TINYINT,1) AS IntSOStatusCode -- Fix value
	  ,CONVERT(TINYINT,0) AS IsDeleted
      ,CONVERT(TINYINT,3) AS BookingDataSourceInfo -- Source from sales.NatSalesOrdersOohHistory_SE
      ,salesHist.NatSalesOrderNo
      ,salesHist.NatSalesOrderItemNo
      ,salesHist.HashDiff
      ,salesHist.CompanyCode
	  ,salesHist.SalesOrganization
      ,salesHist.NatCustomer_BK
      ,salesHist.NatArticle_BK
	  ,salesHist.ArticleSize_BK
	  ,salesHist.StyleNumber_BK
	  ,salesHist.ArticleNumber_BK
      ,salesHist.SODeliveryDate
      ,salesHist.SOPlannedDeliveryDate
      ,salesHist.CurrencyCode
      ,salesHist.RBUCode
      ,salesHist.BrandCode
      ,salesHist.ProdDivCode
      ,salesHist.SOTypeCode
      ,salesHist.IntSalesTypeCode
      ,salesHist.OrderedQty
      ,salesHist.ConfirmedQty
	  ,salesHist.OOHUnits
      ,salesHist.GrossSalesValueLC
      ,salesHist.InvoicedSalesValueLC
      ,salesHist.NetSalesValueLC
      ,salesHist.TotalCogsSplitLC
      ,salesHist.TotalCogsSplitExclIntCompLC
      ,salesHist.TotalIntCompCostLC
      ,salesHist.ManagementCostLC
      ,salesHist.TotalOVCLC
      ,salesHist.FPriceLC
      ,salesHist.ReturnAccrualsLC
	  ,salesHist.LandedCostValueLC
	  ,salesHist.BookingTypeCode
	  ,ROW_NUMBER() OVER (PARTITION BY salesHist.NatSalesOrderNo, salesHist.NatSalesOrderItemNo ORDER BY salesHist.OrdersOnHandDate DESC, salesHist.OrdersOnHandTime DESC, salesHist.BookingTypeCode ASC) AS LastEntryInHist
FROM sales.NatSalesOrdersOohHistory_SE AS salesHist
INNER JOIN NewDistinctIncrement AS new 
		ON salesHist.NatSalesOrderNo = new.NatSalesOrderNo
		AND salesHist.NatSalesOrderItemNo = new.NatSalesOrderItemNo
  )
INSERT INTO #AllSalesOrderOoHHist
	 (OrdersOnHandsDateTime
      ,IntSOStatusCode
      ,IsDeleted
      ,BookingDataSourceInfo
      ,NatSalesOrderNo
      ,NatSalesOrderItemNo
      ,HashDiff
      ,CompanyCode
	  ,SalesOrganization
      ,NatCustomer_BK
      ,NatArticle_BK
	  ,ArticleSize_BK
	  ,StyleNumber_BK
	  ,ArticleNumber_BK
      ,SODeliveryDate
      ,SOPlannedDeliveryDate
      ,CurrencyCode
      ,RBUCode
      ,BrandCode
      ,ProdDivCode
      ,SOTypeCode
      ,IntSalesTypeCode
      ,OrderedQty
      ,ConfirmedQty
	  ,OOHUnits
      ,GrossSalesValueLC
      ,InvoicedSalesValueLC
      ,NetSalesValueLC
      ,TotalCogsSplitLC
      ,TotalCogsSplitExclIntCompLC
      ,TotalIntCompCostLC
      ,ManagementCostLC
      ,TotalOVCLC
      ,FPriceLC
      ,ReturnAccrualsLC
	  ,LandedCostValueLC)
SELECT OrdersOnHandsDateTime
      ,IntSOStatusCode
      ,IsDeleted
      ,BookingDataSourceInfo
      ,NatSalesOrderNo
      ,NatSalesOrderItemNo
      ,HashDiff
      ,CompanyCode
	  ,SalesOrganization
      ,NatCustomer_BK
      ,NatArticle_BK
	  ,ArticleSize_BK
	  ,StyleNumber_BK
	  ,ArticleNumber_BK
      ,SODeliveryDate
      ,SOPlannedDeliveryDate
      ,CurrencyCode
      ,RBUCode
      ,BrandCode
      ,ProdDivCode
      ,SOTypeCode
      ,IntSalesTypeCode
      ,OrderedQty
      ,ConfirmedQty
	  ,OOHUnits
      ,GrossSalesValueLC
      ,InvoicedSalesValueLC
      ,NetSalesValueLC
      ,TotalCogsSplitLC
      ,TotalCogsSplitExclIntCompLC
      ,TotalIntCompCostLC
      ,ManagementCostLC
      ,TotalOVCLC
      ,FPriceLC
      ,ReturnAccrualsLC
	  ,LandedCostValueLC
FROM LastReleatedBookingEntrieFromHist
WHERE LastEntryInHist = 1 
  AND BookingTypeCode = 1 -- Just open booking to get the info for the Cross booking

--- Load exisinting DATA from final Table

IF OBJECT_ID('tempdb..#FinalSalesOrderOoHHist') IS NOT NULL
	BEGIN DROP TABLE #FinalSalesOrderOoHHist END

CREATE TABLE #FinalSalesOrderOoHHist
WITH(DISTRIBUTION = HASH(NatSalesOrderNo),HEAP) AS
WITH DiffSorting AS(
SELECT OrdersOnHandsDateTime
      ,IntSOStatusCode
	  ,RecordStatus
	  ,IsDeleted
      ,BookingDataSourceInfo
      ,NatSalesOrderNo
      ,NatSalesOrderItemNo
      ,HashDiff
      ,CompanyCode
	  ,SalesOrganization
      ,NatCustomer_BK
      ,NatArticle_BK
	  ,ArticleSize_BK
	  ,StyleNumber_BK
	  ,ArticleNumber_BK	  
      ,SODeliveryDate
      ,SOPlannedDeliveryDate
      ,CurrencyCode
      ,RBUCode
      ,BrandCode
      ,ProdDivCode
      ,SOTypeCode
      ,IntSalesTypeCode
      ,OrderedQty
      ,ConfirmedQty
	  ,OOHUnits
      ,GrossSalesValueLC
      ,InvoicedSalesValueLC
      ,NetSalesValueLC
      ,TotalCogsSplitLC
      ,TotalCogsSplitExclIntCompLC
      ,TotalIntCompCostLC
      ,ManagementCostLC
      ,TotalOVCLC
      ,FPriceLC
      ,ReturnAccrualsLC
	  ,LandedCostValueLC
	  ,LAG(HashDiff) OVER (PARTITION BY NatSalesOrderNo, NatSalesOrderItemNo,RecordStatus ORDER BY OrdersOnHandsDateTime) AS pre_HashDiff
	  ,LAG(RecordStatus) OVER (PARTITION BY NatSalesOrderNo, NatSalesOrderItemNo ORDER BY OrdersOnHandsDateTime) AS pre_RecordStatus
	  ,ROW_NUMBER() OVER (PARTITION BY NatSalesOrderNo, NatSalesOrderItemNo,RecordStatus ORDER BY OrdersOnHandsDateTime) AS RankOverAll
FROM #AllSalesOrderOoHHist
)
SELECT OrdersOnHandsDateTime
      ,LEAD(OrdersOnHandsDateTime) OVER (PARTITION BY NatSalesOrderNo ,NatSalesOrderItemNo ORDER BY OrdersOnHandsDateTime) AS CrossBookingOrdersOnHandsDateTime
	  ,IntSOStatusCode
	  ,IsDeleted
      ,BookingDataSourceInfo
      ,NatSalesOrderNo
      ,NatSalesOrderItemNo
      ,HashDiff 
      ,CompanyCode
	  ,SalesOrganization
      ,NatCustomer_BK
      ,NatArticle_BK
	  ,ArticleSize_BK
	  ,StyleNumber_BK
	  ,ArticleNumber_BK	  
      ,SODeliveryDate
      ,SOPlannedDeliveryDate
      ,CurrencyCode
      ,RBUCode
      ,BrandCode
      ,ProdDivCode
      ,SOTypeCode
      ,IntSalesTypeCode
      ,OrderedQty
      ,ConfirmedQty
	  ,OOHUnits
      ,GrossSalesValueLC
      ,InvoicedSalesValueLC
      ,NetSalesValueLC
      ,TotalCogsSplitLC
      ,TotalCogsSplitExclIntCompLC
      ,TotalIntCompCostLC
      ,ManagementCostLC
      ,TotalOVCLC
      ,FPriceLC
      ,ReturnAccrualsLC
	  ,LandedCostValueLC
FROM DiffSorting
WHERE HashDiff <> pre_HashDiff
   OR RankOverAll = 1 -- to get the first entry
   OR (RecordStatus = 1 and pre_RecordStatus = 2) --add calloffs for contracts that were reopened (open and previous status cancelled)

-- Build booking / Cross booking
SELECT @CreatedOn = GetDate() 
BEGIN TRAN -- Make sure Insert and Update are done in the same transaction
	---- Insert Bookings
	INSERT INTO sales.NatSalesOrdersOohHistory_SE
				(OrdersOnHandHistory_BK
				,HashValueBK
				,HashDiff
				,CreatedOn
				,OrdersOnHandDate
				,OrdersOnHandTime
				,BookingTypeCode
				,BookingTypeDesc
				,NatSalesOrderNo
				,NatSalesOrderItemNo
				,CompanyCode
				,SalesOrganization
				,IntPupMasterId
				,PDUCode
				,NatCustomer_BK
				,NatArticle_BK
				,StyleNumber_BK
				,ArticleNumber_BK
				,ArticleSize_BK
				,SODeliveryDate
				,SOPlannedDeliveryDate
				,CurrencyCode
				,SOTypeCode
				,IntSalesTypeCode
				,RBUCode
				,BrandCode
				,ProdDivCode
				,OrderedQty
				,ConfirmedQty
				,OOHUnits
				,GrossSalesValueLC
				,InvoicedSalesValueLC
				,NetSalesValueLC
				,TotalCogsSplitLC
				,TotalCogsSplitExclIntCompLC
				,TotalIntCompCostLC
				,ManagementCostLC
				,TotalOVCLC
				,FPriceLC
				,ReturnAccrualsLC
				,LandedCostValueLC				
	)
	SELECT CONVERT(VARCHAR(100),CONCAT( ooh.NatSalesOrderNo, '|'
				  ,ooh.NatSalesOrderItemNo,'|'
				  ,CONVERT(CHAR(8),CONVERT(INT,FORMAT(ooh.OrdersOnHandsDateTime,'yyyyMMdd'))),'|'
				  ,CONVERT(CHAR(6),CONVERT(INT,FORMAT(ooh.OrdersOnHandsDateTime,'HHmmss'))),'|'
				  ,CONVERT(CHAR(1),'1')))
			 AS OrdersOnHandHistory_BK
 		  ,CONVERT(BINARY(16), 
				HASHBYTES('MD5',CONCAT( 
				UPPER(LTRIM(RTRIM( ooh.NatSalesOrderNo))),'_', 
				UPPER(LTRIM(RTRIM( ooh.NatSalesOrderItemNo))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), CONVERT(INT,FORMAT(Ooh.OrdersOnHandsDateTime,'yyyyMMdd')))))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), CONVERT(INT,FORMAT(Ooh.OrdersOnHandsDateTime,'HHmmss')))))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), 1)))))) 
			) AS HashValueBK
		  ,Ooh.HashDiff
		  ,@CreatedOn AS CreatedOn
		  ,CONVERT(INT,FORMAT(Ooh.OrdersOnHandsDateTime,'yyyyMMdd')) AS OrdersOnHandDate
		  ,CONVERT(INT,FORMAT(Ooh.OrdersOnHandsDateTime,'HHmmss')) AS OrdersOnHandTime
		  ,1 AS BookingTypeCode
		  ,CONVERT (NVARCHAR(15),'booking') AS BookingTypeDesc
		  ,CONVERT(char(10),Ooh.NatSalesOrderNo) AS NatSalesOrderNo
		  ,CONVERT(VARCHAR(40),Ooh.NatSalesOrderItemNo) AS NatSalesOrderItemNo
		  ,CONVERT(char(4),Ooh.CompanyCode) AS CompanyCode
		  ,Ooh.SalesOrganization
		  ,s4If.IntPupMasterId
		  ,CONVERT (VARCHAR(10),s4If.PDUCode) AS PDUCode
		  ,Ooh.NatCustomer_BK
		  ,Ooh.NatArticle_BK
		  ,Ooh.StyleNumber_BK
		  ,Ooh.ArticleNumber_BK
		  ,CONVERT(char(20),Ooh.ArticleSize_BK) AS ArticleSize_BK
		  ,Ooh.SODeliveryDate
		  ,Ooh.SOPlannedDeliveryDate  
		  ,CONVERT(NVARCHAR(3),Ooh.CurrencyCode) AS CurrencyCode
		  ,Ooh.SOTypeCode
		  ,Ooh.IntSalesTypeCode
		  ,Ooh.RBUCode
		  ,Ooh.BrandCode
		  ,Ooh.ProdDivCode
		  ,Ooh.OrderedQty
		  ,Ooh.ConfirmedQty
		  ,Ooh.OOHUnits
		  ,Ooh.GrossSalesValueLC
		  ,Ooh.InvoicedSalesValueLC
		  ,Ooh.NetSalesValueLC
		  ,Ooh.TotalCogsSplitLC
		  ,Ooh.TotalCogsSplitExclIntCompLC
		  ,Ooh.TotalIntCompCostLC
		  ,Ooh.ManagementCostLC
		  ,Ooh.TotalOVCLC
		  ,Ooh.FPriceLC
		  ,Ooh.ReturnAccrualsLC
		  ,Ooh.LandedCostValueLC			  
	  FROM #FinalSalesOrderOoHHist AS Ooh
	  INNER JOIN pdwref.S4Hana_Interfaces AS s4If
		ON ooh.SalesOrganization = s4If.SalesOrg
		AND s4If.Interface='EBP'
	  WHERE Ooh.IntSOStatusCode = 1   
			AND IsDeleted  = 0
			AND BookingDataSourceInfo IN (1,2)  -- only Bookings & Call offs -- no "new bookings" from the sales.NatSalesOrdersOohHistory_SE

	-- New inserted entries 
	SELECT @AffectedRows = COUNT(*)
	 FROM #FinalSalesOrderOoHHist AS Ooh
	  INNER JOIN pdwref.S4Hana_Interfaces AS s4If
		ON ooh.CompanyCode = s4If.CompanyCode
		AND s4If.Interface='EBP'
	  WHERE Ooh.IntSOStatusCode = 1   
			AND IsDeleted  = 0
			AND BookingDataSourceInfo IN (1,2) 

	-- Update Inserted of the load
	UPDATE DTlogs
	SET Inserted = @AffectedRows
	FROM etl.DataTransferLogs DTlogs
	WHERE DataTransferLogId = @DataTransferLogId

	--- Insert cross bookings
	INSERT INTO sales.NatSalesOrdersOohHistory_SE
				(OrdersOnHandHistory_BK
				,HashValueBK
				,HashDiff
				,CreatedOn
				,OrdersOnHandDate
				,OrdersOnHandTime
				,BookingTypeCode
				,BookingTypeDesc
				,NatSalesOrderNo
				,NatSalesOrderItemNo
				,CompanyCode
				,SalesOrganization
				,IntPupMasterId
				,PDUCode
				,NatCustomer_BK
				,NatArticle_BK
				,StyleNumber_BK
				,ArticleNumber_BK
				,ArticleSize_BK
				,SODeliveryDate
				,SOPlannedDeliveryDate
				,CurrencyCode
				,SOTypeCode
				,IntSalesTypeCode
				,RBUCode
				,BrandCode
				,ProdDivCode
				,OrderedQty
				,ConfirmedQty
				,OOHUnits
				,GrossSalesValueLC
				,InvoicedSalesValueLC
				,NetSalesValueLC
				,TotalCogsSplitLC
				,TotalCogsSplitExclIntCompLC
				,TotalIntCompCostLC
				,ManagementCostLC
				,TotalOVCLC
				,FPriceLC
				,ReturnAccrualsLC
				,LandedCostValueLC

	)
		SELECT CONVERT(NVARCHAR(100),CONCAT( ooh.NatSalesOrderNo, '|'
				  ,ooh.NatSalesOrderItemNo,'|'
				  ,CONVERT(CHAR(8),CONVERT(INT,FORMAT(Ooh.CrossBookingOrdersOnHandsDateTime ,'yyyyMMdd'))),'|'											
				  ,CONVERT(CHAR(6),CONVERT(INT,FORMAT(Ooh.CrossBookingOrdersOnHandsDateTime,'HHmmss'))),'|'
				  ,CONVERT(CHAR(1),'2')))
			 AS OrdersOnHandHistory_BK
 		  ,CONVERT(BINARY(16), 
				HASHBYTES('MD5',CONCAT( 
				UPPER(LTRIM(RTRIM( ooh.NatSalesOrderNo))),'_', 
				UPPER(LTRIM(RTRIM( ooh.NatSalesOrderItemNo))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), CONVERT(INT,FORMAT(Ooh.CrossBookingOrdersOnHandsDateTime,'yyyyMMdd')))))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), CONVERT(INT,FORMAT( Ooh.CrossBookingOrdersOnHandsDateTime,'HHmmss')))))),'_', 
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), 2)))))) 
			) AS HashValueBK
		  ,Ooh.HashDiff
		  ,@CreatedOn AS CreatedOn
		  ,CONVERT(INT,FORMAT(Ooh.CrossBookingOrdersOnHandsDateTime,'yyyyMMdd')) AS OrdersOnHandDate
		  ,CONVERT(INT,FORMAT(Ooh.CrossBookingOrdersOnHandsDateTime,'HHmmss')) AS OrdersOnHandTime
		  ,2 AS BookingTypeCode
		  ,CONVERT (NVARCHAR(15),'cross-entry') AS BookingTypeDesc
		  ,CONVERT(char(10),Ooh.NatSalesOrderNo) AS NatSalesOrderNo
		  ,CONVERT(VARCHAR(40),Ooh.NatSalesOrderItemNo) AS NatSalesOrderItemNo
		  ,CONVERT(char(4),Ooh.CompanyCode) AS CompanyCode
		  ,SalesOrganization
		  ,s4If.IntPupMasterId
		  ,CONVERT (VARCHAR(10),s4If.PDUCode) AS PDUCode
		  ,Ooh.NatCustomer_BK
		  ,Ooh.NatArticle_BK
		  ,Ooh.StyleNumber_BK
		  ,Ooh.ArticleNumber_BK
		  ,CONVERT(char(20),Ooh.ArticleSize_BK) AS ArticleSize_BK
		  ,Ooh.SODeliveryDate
		  ,Ooh.SOPlannedDeliveryDate
		  ,CONVERT(NVARCHAR(3),Ooh.CurrencyCode) AS CurrencyCode
		  ,Ooh.SOTypeCode
		  ,Ooh.IntSalesTypeCode
		  ,Ooh.RBUCode
		  ,Ooh.BrandCode
		  ,Ooh.ProdDivCode
		  ,Ooh.OrderedQty * -1 AS OrderedQty
		  ,Ooh.ConfirmedQty * -1 AS ConfirmedQty
		  ,Ooh.OOHUnits * -1 AS OOHUnits
		  ,Ooh.GrossSalesValueLC * -1 AS GrossSalesValueLC
		  ,Ooh.InvoicedSalesValueLC * -1 AS InvoicedSalesValueLC
		  ,Ooh.NetSalesValueLC * -1 AS NetSalesValueLC
		  ,Ooh.TotalCogsSplitLC * -1 AS TotalCogsSplitLC
		  ,Ooh.TotalCogsSplitExclIntCompLC * -1 AS TotalCogsSplitExclIntCompLC
		  ,Ooh.TotalIntCompCostLC * -1 AS TotalIntCompCostLC
		  ,Ooh.ManagementCostLC * -1 AS ManagementCostLC
		  ,Ooh.TotalOVCLC * -1 AS TotalOVCLC
		  ,Ooh.FPriceLC * -1 AS FPriceLC
		  ,Ooh.ReturnAccrualsLC * -1 AS ReturnAccrualsLC
		  ,Ooh.LandedCostValueLC * -1 AS LandedCostValueLC		   
	  FROM #FinalSalesOrderOoHHist AS Ooh
	  INNER JOIN pdwref.S4Hana_Interfaces AS s4If
		on ooh.SalesOrganization = s4If.SalesOrg
	  WHERE BookingDataSourceInfo in (1,2,3) -- crossbookings for all new bookings and only crosbookings for the orders that are not open anymore and crossbooking for the last entry in NatSalesOrdersOohHistory_SE
		AND CrossBookingOrdersOnHandsDateTime IS NOT NULL AND Ooh.IntSOStatusCode = 1 -- last booking is open and  next booking does not close the SO via StatusCode <>1
		AND IsDeleted  = 0
COMMIT TRAN; 
-- Count Cross booking and use the updated column
SELECT @AffectedRows = NULL -- reset Var

SELECT @AffectedRows = COUNT(*)
 FROM #FinalSalesOrderOoHHist AS Ooh
  INNER JOIN pdwref.S4Hana_Interfaces AS s4If
	on ooh.SalesOrganization = s4If.SalesOrg
  WHERE BookingDataSourceInfo in(1,2,3) -- just crossbookings for bookings (source from increment or Hist table)
	AND CrossBookingOrdersOnHandsDateTime IS NOT NULL AND Ooh.IntSOStatusCode = 1 -- last booking is open and  next booking does not close the SO via StatusCode <>1
    AND IsDeleted  = 0

-- Update End of the load
UPDATE DTlogs
SET ExecEnd = GETDATE()
	,Updated = @AffectedRows
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

--exec [dbo].[S4Hana_spProvOrdersOnHandHistoryAll_SE] '19000101'
END --SP


