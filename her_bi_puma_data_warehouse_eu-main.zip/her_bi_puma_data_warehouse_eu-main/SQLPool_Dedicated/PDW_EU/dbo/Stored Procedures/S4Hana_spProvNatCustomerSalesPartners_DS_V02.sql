﻿CREATE PROC [dbo].[S4Hana_spProvNatCustomerSalesPartners_DS_V02] @LDTS [DATETIME2](7) AS

DECLARE @LoadDate DATETIME2(7) = GETDATE();

IF OBJECT_ID('tempdb..#NatCustomerSalesPartners') IS NOT NULL DROP TABLE #NatCustomerSalesPartners;

-- logging informations - BEGIN
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(0) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(0)
DECLARE @DestinationLastLoadDate DATETIME2(0)
DECLARE @BatchLdts DATETIME2(0) = @LDTS
DECLARE @AffectedRows BIGINT = NULL
-- logging Informations - END

-- get last LDTS Informations for Logging
IF(EXISTS(SELECT 1 FROM ref.NatCustomerSalesPartners_DS_V02))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(ModifiedOn))
		FROM ref.NatCustomerSalesPartners_DS_V02
	END
ELSE 
	BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

IF(EXISTS(SELECT 1 FROM biz.[S4Hana_CustomerSalesPartners]))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(LDTS))
		FROM biz.[S4Hana_CustomerSalesPartners]
	END
ELSE 
	BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END
-- Logging Informations END


-- Log first DATA Informations

INSERT INTO etl.DataTransferLogs
(
  DataTransferLogId
, TransferName
, TransferGroupName
, TargetTableName
, TargetSchemaName
, ExecStart
, SourceLastLoadDate
, DestinationLastLoadDate
, BatchLdts
)
SELECT 
  @DataTransferLogId 
, 'S4Hana_spProvNatCustomerSalesPartners_DS_V02'
, 'NatCustomerSalesPartners_DS_V02'
, 'NatCustomerSalesPartners_DS_V02'
, 'ref'
, @ExecStart
, @SourceLastLoadDate
, @DestinationLastLoadDate
, @BatchLdts;

-- Log first DATA Informations END
WITH CTE AS
(
	SELECT CONCAT(A.CustomerNumber, '|', A.SalesOrganization, '|', A.DistributionChannel, '|', A.PartnerFunction, '|', A.PartnerCounter, '|',b.CustomerAccountGroup) AS NatCustomerSalesPartner_BK
	  ,@LoadDate	AS CreatedOn
	  ,@LoadDate	AS ModifiedOn
	  ,a.[CustomerNumber]
      ,a.[SalesOrganization]
	  ,b.CustomerAccountGroup
      ,a.[DistributionChannel]
      ,a.[Division]
      ,a.[PartnerFunction]
      ,a.[PartnerCounter]
      ,a.[Partner]
      ,a.[Vendor]
      ,a.[PersonalNumber]
      ,a.[ContactPerson]
      ,a.[Description]
      ,a.[DefaultPartner]
      ,a.[FunctionDescription]
      ,a.[Desccustpartm]
      ,a.[Partnername]
	  ,a.IsDeleted

FROM biz.[S4Hana_CustomerSalesPartners] a
inner join biz.[S4Hana_Customers] b on a.[CustomerNumber]=b.Customer
--inner join [pdwref].[AreaCodeMapping] acm on a.[SalesOrganization]= acm.SalesOrganization
	WHERE
	A.LDTS >= @LDTS 
	OR B.LDTS >= @LDTS
	
)

--Insert to temp table
SELECT 
	   NatCustomerSalesPartner_BK
	  ,IsDeleted
	  ,CreatedOn
	  ,ModifiedOn
	  ,[CustomerNumber]
	  ,[SalesOrganization]
	  ,CustomerAccountGroup
	  ,[DistributionChannel]
	  ,[Division]
      ,[PartnerFunction]
      ,[PartnerCounter]
      ,[Partner]
      ,[Vendor]
      ,[PersonalNumber]
      ,[ContactPerson]
      ,[Description]
      ,[DefaultPartner]
      ,[FunctionDescription]
      ,[Desccustpartm]
      ,[Partnername]      
	  ,CONVERT([BINARY](16), HASHBYTES('MD5',CONCAT(
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), NatCustomerSalesPartner_BK)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [CustomerNumber])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [SalesOrganization])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CustomerAccountGroup)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DistributionChannel])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [Division])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [PartnerFunction])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [PartnerCounter])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [Partner])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [Vendor])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [PersonalNumber])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [ContactPerson])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [Description])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DefaultPartner])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [FunctionDescription])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [Desccustpartm])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [Partnername])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [IsDeleted]))))    
	))) AS HashDiff

INTO #NatCustomerSalesPartners
FROM CTE

--Count Records to be updated
SELECT @AffectedRows = COUNT(*)
FROM [ref].[NatCustomerSalesPartners_DS_V02] A
INNER JOIN #NatCustomerSalesPartners B ON A.NatCustomerSalesPartner_BK = B.NatCustomerSalesPartner_BK
WHERE A.HashDiff <> B.HashDiff

--Update Final Table
UPDATE A SET
  A.ModifiedOn = @LoadDate
, A.NatCustomerSalesPartner_BK = B.NatCustomerSalesPartner_BK
, A.IsDeleted				   = B.IsDeleted
, A.[CustomerNumber]		   = B.[CustomerNumber]
, A.[SalesOrganization]		   = B.[SalesOrganization]
, A.CustomerAccountGroup	   = B.CustomerAccountGroup
, A.[DistributionChannel]	   = B.[DistributionChannel]
, A.[Division]				   = B.[Division]
, A.[PartnerFunction]		   = B.[PartnerFunction]
, A.[PartnerCounter]		   = B.[PartnerCounter]
, A.[Partner]				   = B.[Partner]
, A.[Vendor]				   = B.[Vendor]
, A.[PersonalNumber]		   = B.[PersonalNumber]
, A.[ContactPerson]			   = B.[ContactPerson]
, A.[Description]			   = B.[Description]
, A.[DefaultPartner]		   = B.[DefaultPartner]
, A.[FunctionDescription]	   = B.[FunctionDescription]
, A.[Desccustpartm]			   = B.[Desccustpartm]
, A.[Partnername]			   = B.[Partnername]
, A.HashDiff  = B.HashDiff
FROM [ref].[NatCustomerSalesPartners_DS_V02] A
INNER JOIN #NatCustomerSalesPartners B ON A.NatCustomerSalesPartner_BK = B.NatCustomerSalesPartner_BK
WHERE A.HashDiff <> B.HashDiff and B.IsDeleted = 0

--update deletion status
UPDATE A SET
	   A.ModifiedOn = @LoadDate
	  ,A.IsDeleted = 1
	  ,A.HashDiff  = B.HashDiff

FROM [ref].[NatCustomerSalesPartners_DS_V02] A
INNER JOIN #NatCustomerSalesPartners B ON A.NatCustomerSalesPartner_BK = B.NatCustomerSalesPartner_BK
WHERE A.HashDiff <> B.HashDiff and B.IsDeleted = 1

--Log count of updated records
UPDATE DTlogs SET
  Updated = @AffectedRows
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

--Count Records to be inserted
SELECT @AffectedRows = COUNT(*)
FROM #NatCustomerSalesPartners A
LEFT JOIN [ref].[NatCustomerSalesPartners_DS_V02] B ON A.NatCustomerSalesPartner_BK = B.NatCustomerSalesPartner_BK
WHERE B.NatCustomerSalesPartner_BK IS NULL

--Insert to Final Table
INSERT INTO [ref].[NatCustomerSalesPartners_DS_V02]
(
      NatCustomerSalesPartner_BK
     ,IsDeleted
     ,CreatedOn
     ,ModifiedOn
     ,[CustomerNumber]
     ,[SalesOrganization]
     ,CustomerAccountGroup
     ,[DistributionChannel]
     ,[Division]
     ,[PartnerFunction]
     ,[PartnerCounter]
     ,[Partner]
     ,[Vendor]
     ,[PersonalNumber]
     ,[ContactPerson]
     ,[Description]
     ,[DefaultPartner]
     ,[FunctionDescription]
     ,[Desccustpartm]
     ,[Partnername]
     ,HashDiff
)
SELECT
	   A.NatCustomerSalesPartner_BK
      ,A.IsDeleted
      ,A.CreatedOn
      ,A.ModifiedOn
	  ,A.[CustomerNumber]
      ,A.[SalesOrganization]
      ,A.CustomerAccountGroup
      ,A.[DistributionChannel]
      ,A.[Division]
      ,A.[PartnerFunction]
      ,A.[PartnerCounter]
      ,A.[Partner]
      ,A.[Vendor]
      ,A.[PersonalNumber]
      ,A.[ContactPerson]
      ,A.[Description]
      ,A.[DefaultPartner]
      ,A.[FunctionDescription]
      ,A.[Desccustpartm]
      ,A.[Partnername]
      ,A.HashDiff
FROM #NatCustomerSalesPartners A
LEFT JOIN [ref].[NatCustomerSalesPartners_DS_V02] B ON A.NatCustomerSalesPartner_BK = B.NatCustomerSalesPartner_BK
WHERE B.NatCustomerSalesPartner_BK IS NULL

--Log count of inserted records
UPDATE DTlogs SET 
  Inserted = @AffectedRows
, ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId