﻿CREATE PROC [dbo].[S4Hana_spProvNatBPAddressEmail_DS_V02] @LDTS [DATETIME2](7) AS

DECLARE @LoadDate DATETIME2(7) = GETDATE();

IF OBJECT_ID('tempdb..#NatBPAddressEmail') IS NOT NULL DROP TABLE #NatBPAddressEmail;

-- logging informations - BEGIN
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(0) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(0)
DECLARE @DestinationLastLoadDate DATETIME2(0)
DECLARE @BatchLdts DATETIME2(0) = @LDTS
DECLARE @AffectedRows BIGINT = NULL
-- logging Informations - END

-- get last LDTS Informations for Logging
IF(EXISTS(SELECT 1 FROM [ref].[NatBPAddressEmail_DS_V02]))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(ModifiedOn))
		FROM [ref].[NatBPAddressEmail_DS_V02]
	END
ELSE 
	BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

IF(EXISTS(SELECT 1 FROM biz.[S4Hana_BPAddressEmail]))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(LDTS))
		FROM biz.[S4Hana_BPAddressEmail]
	END
ELSE 
	BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END
-- Logging Informations END


-- Log first DATA Informations

INSERT INTO etl.DataTransferLogs
(
  DataTransferLogId
, TransferName
, TransferGroupName
, TargetTableName
, TargetSchemaName
, ExecStart
, SourceLastLoadDate
, DestinationLastLoadDate
, BatchLdts
)
SELECT 
  @DataTransferLogId 
, 'S4Hana_spProvNatBPAddressEmail_DS_V02'
, 'NatBPAddressEmail_DS_V02'
, 'NatBPAddressEmail_DS_V02'
, 'ref'
, @ExecStart
, @SourceLastLoadDate
, @DestinationLastLoadDate
, @BatchLdts;

-- Log first DATA Informations END
WITH CTE AS
(
	SELECT distinct
	CONCAT(A.BusinessPartner, '|', A.addrnumber, '|', A.persnumber, '|', A.ValidFromDflt, '|', A.SequenceNumber, '|',d.CustomerAccountGroup, '|',d.ContactFunction) AS NatBPAddressEmail_BK
	  ,@LoadDate	AS CreatedOn
	  ,@LoadDate	AS ModifiedOn
	  ,a.[BusinessPartner]
	  ,d.[SalesOrganization]
	  ,d.CustomerAccountGroup
	  ,d.ContactFunction
	  ,c.BPCategory
	  ,a.[AddressNumber]
	  ,a.[StrdAddress]
	  ,a.[addrnumber]
	  ,a.[persnumber]
	  ,a.[ValidFromDflt]
	  ,a.[SequenceNumber]
	  ,a.[StdSender]
	  ,a.[NotUsed]
	  ,a.[HomeFlag]
	  ,a.[EmailAddress]
	  ,a.[FlagStdRecipient]
	  ,a.[COnSapSys]
	  ,a.[RequiredEncoding]
	  ,a.[TNEFEncode]
	  ,a.[ValidFrom]
	  ,a.[ValidTo]
	  ,a.IsDeleted
	  ,d.IsDeleted as isDeleted2	       

FROM biz.[S4Hana_BPAddressEmail] a
left join biz.[S4Hana_CustomerBusinessPartner] b on a.[BusinessPartner] = b.But051partner
left join biz.[S4Hana_BPGeneralData1] c on a.[BusinessPartner] = c.[BusinessPartner]
left join [stag].[vCustomerAccountGroup_DS] d on a.[BusinessPartner] = d.[BusinessPartner]
--inner join [pdwref].[AreaCodeMapping] acm on d.[SalesOrganization] = acm.SalesOrganization
	  
	WHERE
	d.[SalesOrganization] is not null
	AND (A.LDTS >= @LDTS 
	OR B.LDTS >= @LDTS
	OR C.LDTS >= @LDTS
	OR D.CBP_LDTS >= @LDTS
	OR D.C_LDTS >= @LDTS	
	OR D.CSA_LDTS >= @LDTS)
)

--Insert to temp table
SELECT 
	   NatBPAddressEmail_BK
	  ,IsDeleted
	  ,CreatedOn
	  ,ModifiedOn
	  ,[BusinessPartner]
	  ,[SalesOrganization]
      ,CustomerAccountGroup
	  ,ContactFunction
	  ,BPCategory
      ,[AddressNumber]
      ,[StrdAddress]
      ,[addrnumber]
      ,[persnumber]
      ,[ValidFromDflt]
      ,[SequenceNumber]
      ,[StdSender]
      ,[NotUsed]
      ,[HomeFlag]
      ,[EmailAddress]
      ,[FlagStdRecipient]
	  ,[COnSapSys]
	  ,[RequiredEncoding]
	  ,[TNEFEncode]
	  ,[ValidFrom]
	  ,[ValidTo]       
	  ,CONVERT([BINARY](16), HASHBYTES('MD5',CONCAT(
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),NatBPAddressEmail_BK)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),IsDeleted)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[BusinessPartner])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SalesOrganization])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),CustomerAccountGroup)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),ContactFunction)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),BPCategory)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[AddressNumber])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[StrdAddress])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[addrnumber])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[persnumber])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ValidFromDflt])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SequenceNumber])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[StdSender])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[NotUsed])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[HomeFlag])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[EmailAddress])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FlagStdRecipient])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[COnSapSys])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[RequiredEncoding])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TNEFEncode])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ValidFrom])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ValidTo]))))
	))) AS HashDiff
	
INTO #NatBPAddressEmail
FROM CTE

--Count Records to be updated
SELECT @AffectedRows = COUNT(*)
FROM [ref].[NatBPAddressEmail_DS_V02] A
INNER JOIN #NatBPAddressEmail B ON A.NatBPAddressEmail_BK = B.NatBPAddressEmail_BK
WHERE A.HashDiff <> B.HashDiff

--Update Final Table
UPDATE A SET
  A.ModifiedOn = @LoadDate
, A.IsDeleted			 = B.IsDeleted
, A.[BusinessPartner]	 = B.[BusinessPartner]
, A.[SalesOrganization]	 = B.[SalesOrganization]
, A.CustomerAccountGroup = B.CustomerAccountGroup
, A.ContactFunction		 = B.ContactFunction
, A.BPCategory			 = B.BPCategory
, A.[AddressNumber]		 = B.[AddressNumber]
, A.[StrdAddress]		 = B.[StrdAddress]
, A.[addrnumber]		 = B.[addrnumber]
, A.[persnumber]		 = B.[persnumber]
, A.[ValidFromDflt]		 = B.[ValidFromDflt]
, A.[SequenceNumber]	 = B.[SequenceNumber]
, A.[StdSender]			 = B.[StdSender]
, A.[NotUsed]			 = B.[NotUsed]
, A.[HomeFlag]			 = B.[HomeFlag]
, A.[EmailAddress]		 = B.[EmailAddress]
, A.[FlagStdRecipient]	 = B.[FlagStdRecipient]
, A.[COnSapSys]			 = B.[COnSapSys]
, A.[RequiredEncoding]	 = B.[RequiredEncoding]
, A.[TNEFEncode]		 = B.[TNEFEncode]
, A.[ValidFrom]			 = B.[ValidFrom]
, A.[ValidTo]       	 = B.[ValidTo]       
, A.HashDiff         	 = B.HashDiff  

FROM [ref].[NatBPAddressEmail_DS_V02] A
INNER JOIN #NatBPAddressEmail B ON A.NatBPAddressEmail_BK = B.NatBPAddressEmail_BK
WHERE A.HashDiff <> B.HashDiff and B.IsDeleted = 0

--update deletion status
UPDATE A SET
	   A.ModifiedOn = @LoadDate
	  ,A.IsDeleted = 1
	  ,A.HashDiff  = B.HashDiff

FROM [ref].[NatBPAddressEmail_DS_V02] A
INNER JOIN #NatBPAddressEmail B ON A.NatBPAddressEmail_BK = B.NatBPAddressEmail_BK
WHERE A.HashDiff <> B.HashDiff and B.IsDeleted = 1

--Log count of updated records
UPDATE DTlogs SET
  Updated = @AffectedRows
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

--Count Records to be inserted
SELECT @AffectedRows = COUNT(*)
FROM #NatBPAddressEmail A
LEFT JOIN [ref].[NatBPAddressEmail_DS_V02] B ON A.NatBPAddressEmail_BK = B.NatBPAddressEmail_BK
WHERE B.NatBPAddressEmail_BK IS NULL

--Insert to Final Table
INSERT INTO [ref].[NatBPAddressEmail_DS_V02]
(
      NatBPAddressEmail_BK
     ,IsDeleted
     ,CreatedOn
     ,ModifiedOn
     ,[BusinessPartner]
     ,[SalesOrganization]
     ,CustomerAccountGroup
     ,ContactFunction
     ,BPCategory
     ,[AddressNumber]
     ,[StrdAddress]
     ,[addrnumber]
     ,[persnumber]
     ,[ValidFromDflt]
     ,[SequenceNumber]
     ,[StdSender]
     ,[NotUsed]
     ,[HomeFlag]
     ,[EmailAddress]
     ,[FlagStdRecipient]
     ,[COnSapSys]
	 ,[RequiredEncoding]
	 ,[TNEFEncode]
	 ,[ValidFrom]
	 ,[ValidTo]       
	 ,Hashdiff
	  )
SELECT
	   A.NatBPAddressEmail_BK
      ,A.IsDeleted
      ,A.CreatedOn
      ,A.ModifiedOn
	  ,A.[BusinessPartner]
      ,A.[SalesOrganization]
      ,A.CustomerAccountGroup
      ,A.ContactFunction
      ,A.BPCategory
      ,A.[AddressNumber]
      ,A.[StrdAddress]
      ,A.[addrnumber]
      ,A.[persnumber]
      ,A.[ValidFromDflt]
      ,A.[SequenceNumber]
      ,A.[StdSender]
      ,A.[NotUsed]
      ,A.[HomeFlag]
      ,A.[EmailAddress]
      ,A.[FlagStdRecipient]
      ,A.[COnSapSys]
	  ,A.[RequiredEncoding]
	  ,A.[TNEFEncode]
	  ,A.[ValidFrom]
	  ,A.[ValidTo]       
	  ,A.Hashdiff

FROM #NatBPAddressEmail A
LEFT JOIN [ref].[NatBPAddressEmail_DS_V02] B ON A.NatBPAddressEmail_BK = B.NatBPAddressEmail_BK
WHERE B.NatBPAddressEmail_BK IS NULL

--Log count of inserted records
UPDATE DTlogs SET 
  Inserted = @AffectedRows
, ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId