﻿CREATE PROC [dbo].[S4Hana_spSOCurrentAccumulated_Iflag_Update] @ldts_param [VARCHAR](255) AS
BEGIN 
DECLARE @LDTS DATETIME = CAST(CAST(@ldts_param AS DATETIME2) AS SMALLDATETIME);


DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(7) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(7)
DECLARE @DestinationLastLoadDate DATETIME2(7)
DECLARE @BatchLdts DATETIME2(7) = @ldts_param
DECLARE @AffectedRows BIGINT = NULL

IF(EXISTS(SELECT 1 FROM sales.[NatSalesOrderCurrentAccumulated]))
BEGIN
	SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(ModifiedOn))
FROM sales.[NatSalesOrderCurrentAccumulated]
END
ELSE BEGIN
	SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
END 

IF(EXISTS(SELECT 1 FROM sales.[NatSalesOrderCurrentAccumulated]))
BEGIN
	SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(ModifiedOn))
	FROM sales.[NatSalesOrderCurrentAccumulated]
END
ELSE BEGIN
	SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
END 

--Log Data load
INSERT INTO etl.DataTransferLogs
  (DataTransferLogId
  ,TransferName
  ,TransferGroupName
  ,TargetTableName
  ,TargetSchemaName
  ,ExecStart
  ,SourceLastLoadDate
  ,DestinationLastLoadDate
  ,BatchLdts)
  SELECT @DataTransferLogId 
		,'S4Hana_spSOCurrentAccumulated_Iflag_Update'
		,'Iflag_Update'
		,'Iflag_Update'
		,'sales'
		,@ExecStart
		,@SourceLastLoadDate
		,@DestinationLastLoadDate
		,@BatchLdts

--DECLARE @LDTS DATETIME2(7) = '19000101'
IF OBJECT_ID('tempdb..#ChangedCombos') IS NOT NULL DROP TABLE #ChangedCombos;
CREATE TABLE #ChangedCombos
WITH
(
	DISTRIBUTION = ROUND_ROBIN
)
AS
(
Select distinct SalesSeason,NatCustomer_BK,NatArticle_BK
FROM [sales].[NatSalesOrderCurrentAccumulated] a
where a.ModifiedOn > @LDTS and a.CompanyCode = 'FR10'

UNION

Select distinct a.SalesSeason,a.NatCustomer_BK,a.NatArticle_BK
FROM [sales].[NatSalesOrderCurrentAccumulated] a
INNER JOIN sales.NatCopaDetails b on a.NatSalesOrderNo = b.NatSalesOrderNo and a.NatSalesOrderItemNo = b.NatSalesOrderItemNo
where b.NatSalesOrderNo <> '' and b.ModifiedOn > @LDTS and a.CompanyCode = 'FR10')

IF OBJECT_ID('tempdb..#SOAccu') IS NOT NULL DROP TABLE #SOAccu;
SELECT
 a.SalesSeason
,a.NatCustomer_BK
,a.NatArticle_BK
,a.NatSalesOrderNo
,a.SOStatusDesc
,a.InvoicePostingDate
,a.LatestRDD
INTO #SOAccu
FROM [sales].[NatSalesOrderCurrentAccumulated] a
INNER JOIN #ChangedCombos b on a.SalesSeason=b.SalesSeason and a.NatCustomer_BK=b.NatCustomer_BK and a.NatArticle_BK=b.NatArticle_BK
where a.SalesSeason <> '' and a.NatCustomer_BK <> '' and a.NatArticle_BK <> '' and a.SOStatusDesc <> 'Cancelled'

--First dates per Season, Article, Customer level
IF OBJECT_ID('tempdb..#SeasonArticleCustomer') IS NOT NULL DROP TABLE #SeasonArticleCustomer;
select distinct
 SalesSeason
,NatCustomer_BK
,LEFT(NatArticle_BK,len(NatArticle_BK)-9) as NatArticleNo 
,min(InvoicePostingDate) as FirstIPD
,min(LatestRDD) as FirstRDD
into #SeasonArticleCustomer
from #SOAccu
group by NatCustomer_BK
,LEFT(NatArticle_BK,len(NatArticle_BK)-9)
,SalesSeason

--Find min dates for SOs
IF OBJECT_ID('tempdb..#SO_agg') IS NOT NULL DROP TABLE #SO_agg;
select 
NatSalesOrderNo
,SalesSeason
,NatCustomer_BK
,LEFT(NatArticle_BK,len(NatArticle_BK)-9) as NatArticleNo
,MIN(InvoicePostingDate) as InvoicePostingDate
,MIN(LatestRDD) as LatestRDD
into #SO_agg
from #SOAccu a
group by 
NatSalesOrderNo
,SalesSeason
,NatCustomer_BK
,LEFT(NatArticle_BK,len(NatArticle_BK)-9)

-- Find SO matches on min Invoice Posting Date or LatestRDD
IF OBJECT_ID('tempdb..#flag') IS NOT NULL DROP TABLE #flag;
select a.SalesSeason,a.NatCustomer_BK,a.NatArticleNo,coalesce (b.NatSalesOrderNo,c.NatSalesOrderNo) as I_NatSalesOrderNo, 'I' as I_flag
into #flag
from #SeasonArticleCustomer a
left join #SO_agg b on a.SalesSeason=b.SalesSeason and a.NatCustomer_BK=b.NatCustomer_BK and a.NatArticleNo=b.NatArticleNo and InvoicePostingDate=FirstIPD
left join #SO_agg c on a.SalesSeason=c.SalesSeason and a.NatCustomer_BK=c.NatCustomer_BK and a.NatArticleNo=c.NatArticleNo and FirstRDD=c.LatestRDD

--clear Iflags
UPDATE prd SET
	   prd.I_flag          = NULL
	 , prd.I_flag2         = NULL
	from [sales].[NatSalesOrderCurrentAccumulated] as prd
	INNER JOIN #ChangedCombos stg on 
		prd.SalesSeason    = stg.SalesSeason    
	and prd.NatCustomer_BK = stg.NatCustomer_BK 
	and prd.NatArticle_BK  = stg.NatArticle_BK  

--assign I_flag values
UPDATE prd SET
	   prd.I_flag    = stg.I_flag  
	from [sales].[NatSalesOrderCurrentAccumulated] as prd
	INNER JOIN  #flag as stg 
		on 	prd.natsalesorderno = stg.I_NatSalesOrderNo
		and prd.SalesSeason    = stg.SalesSeason    
		and prd.NatCustomer_BK = stg.NatCustomer_BK 
		and LEFT(prd.NatArticle_BK,len(prd.NatArticle_BK)-9)  = stg.NatArticleNo

--Calculate I_flag2

--First dates per Article, Customer level
IF OBJECT_ID('tempdb..#ArticleCustomer') IS NOT NULL DROP TABLE #ArticleCustomer;
SELECT DISTINCT
 NatCustomer_BK
,LEFT(NatArticle_BK,len(NatArticle_BK)-9) NatArticleNo
,min(InvoicePostingDate) as FirstIPD
,min(LatestRDD) as FirstRDD
INTO #ArticleCustomer
from #SOAccu
group by NatCustomer_BK
,LEFT(NatArticle_BK,len(NatArticle_BK)-9)

--Find min dates for SOs
IF OBJECT_ID('tempdb..#SO_agg2') IS NOT NULL DROP TABLE #SO_agg2;
select 
NatSalesOrderNo
,NatCustomer_BK
,LEFT(NatArticle_BK,len(NatArticle_BK)-9) as NatArticleNo
,MIN(InvoicePostingDate) as InvoicePostingDate
,MIN(LatestRDD) as LatestRDD
into #SO_agg2
from #SOAccu a
group by 
NatSalesOrderNo
,NatCustomer_BK
,LEFT(NatArticle_BK,len(NatArticle_BK)-9)

-- Find SO matches on min Invoice Posting Date or LatestRDD
IF OBJECT_ID('tempdb..#flag2') IS NOT NULL DROP TABLE #flag2;
select a.NatCustomer_BK,a.NatArticleNo,coalesce (b.NatSalesOrderNo,c.NatSalesOrderNo) as I_NatSalesOrderNo, 'I' as I_flag2
into #flag2
from #SeasonArticleCustomer a
left join #SO_agg2 b on a.NatCustomer_BK=b.NatCustomer_BK and a.NatArticleNo=b.NatArticleNo and InvoicePostingDate=FirstIPD
left join #SO_agg2 c on a.NatCustomer_BK=c.NatCustomer_BK and a.NatArticleNo=c.NatArticleNo and FirstRDD=c.LatestRDD

--assign I_flag2 values
UPDATE prd SET
	   prd.I_flag2 = stg.I_flag2
	from [sales].[NatSalesOrderCurrentAccumulated] as prd
	INNER JOIN  #flag2 as stg 
		on 	prd.natsalesorderno = stg.I_NatSalesOrderNo
		and prd.NatCustomer_BK = stg.NatCustomer_BK 
		and LEFT(prd.NatArticle_BK,len(prd.NatArticle_BK)-9)  = stg.NatArticleNo

--exec [dbo].[S4Hana_spSOCurrentAccumulated_Iflag_Update] '19000101'

END