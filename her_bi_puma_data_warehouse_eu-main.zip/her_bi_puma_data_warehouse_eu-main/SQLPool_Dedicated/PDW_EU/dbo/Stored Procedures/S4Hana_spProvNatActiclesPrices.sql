﻿CREATE PROC [dbo].[S4Hana_spProvNatActiclesPrices] @LDTS [DATETIME2](7) AS

DECLARE @LoadDate DATETIME2(7) = GETDATE();
--DECLARE @LDTS DATETIME2(7) = '1900-01-01';

-- logging informations - BEGIN
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(0) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(0)
DECLARE @DestinationLastLoadDate DATETIME2(0)
DECLARE @BatchLdts DATETIME2(0) = @LDTS
DECLARE @AffectedRows BIGINT = NULL
-- logging Informations - END

-- get last LDTS Informations for Logging
IF(EXISTS(SELECT 1 FROM ref.NatArticlesPrices))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(modifiedOn))
		FROM ref.NatArticlesPrices
	END
ELSE 
	BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

IF(EXISTS(SELECT 1 FROM [biz].[S4Hana_MaterialPrices]))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(_LDTS))
		FROM [biz].[S4Hana_MaterialPrices]
	END
ELSE 
	BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END
-- Logging Informations END

-- Log first DATA Informations
INSERT INTO etl.DataTransferLogs
(
  DataTransferLogId
, TransferName
, TransferGroupName
, TargetTableName
, TargetSchemaName
, ExecStart
, SourceLastLoadDate
, DestinationLastLoadDate
, BatchLdts
)
SELECT 
  @DataTransferLogId 
, 'S4Hana_spProvNatActiclesPrices'
, 'NatArticlesPrices'
, 'NatArticlesPrices'
, 'ref'
, @ExecStart
, @SourceLastLoadDate
, @DestinationLastLoadDate
, @BatchLdts;


-- TempTable with all changed Materials
IF OBJECT_ID('tempdb..#AllChangedMaterials') IS NOT NULL DROP TABLE #AllChangedMaterials;

SELECT 
	MaterialNumber
	,MAX(_LDTS) LDTS
INTO #AllChangedMaterials
FROM [biz].[S4Hana_MaterialPrices]
WHERE _LDTS > @DestinationLastLoadDate
GROUP BY MaterialNumber

-- TempTable with all changed Materials pivoted
IF OBJECT_ID('tempdb..#AllChangedMaterialsPivoted') IS NOT NULL DROP TABLE #AllChangedMaterialsPivoted;

SELECT
	MaterialNumber
	,ModifiedOn
	,IsDeleted
	,RRP_CH19_CHF
	,RRP_NL19_CHF
	,RRP_DE19_CHF
	,RRP_AT19_CHF
	,RRP_BE19_CHF
	,RRP_CH19_EUR
	,RRP_NL19_EUR
	,RRP_DE19_EUR
	,RRP_AT19_EUR
	,RRP_BE19_EUR
	,WSP_CH19_CHF
	,WSP_NL19_CHF
	,WSP_DE19_CHF
	,WSP_AT19_CHF
	,WSP_BE19_CHF
	,WSP_CH19_EUR
	,WSP_NL19_EUR
	,WSP_DE19_EUR
	,WSP_AT19_EUR
	,WSP_BE19_EUR
	,CONVERT(BINARY(16), HASHBYTES('MD5',CONCAT(
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), MaterialNumber)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ModifiedOn)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), IsDeleted )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), RRP_CH19_CHF )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), RRP_NL19_CHF )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), RRP_DE19_CHF )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), RRP_AT19_CHF )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), RRP_BE19_CHF )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), RRP_CH19_EUR )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), RRP_NL19_EUR )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), RRP_DE19_EUR )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), RRP_AT19_EUR )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), RRP_BE19_EUR )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), WSP_CH19_CHF )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), WSP_NL19_CHF )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), WSP_DE19_CHF )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), WSP_AT19_CHF )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), WSP_BE19_CHF )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), WSP_CH19_EUR )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), WSP_NL19_EUR )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), WSP_DE19_EUR )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), WSP_AT19_EUR )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), WSP_BE19_EUR ))))
		))) AS HashDiff
INTO #AllChangedMaterialsPivoted
FROM 
(SELECT 
	MP.MaterialNumber
	,PivotKey
	,WHPrice
	,C.LDTS AS [ModifiedOn]
	,IsDeleted
FROM [biz].[S4Hana_MaterialPrices] MP
	INNER JOIN #AllChangedMaterials C ON MP.MaterialNumber = C.MaterialNumber
) aa
PIVOT (MAX(aa.WHPrice) FOR PivotKey IN ( RRP_CH19_CHF
										,RRP_NL19_CHF
										,RRP_DE19_CHF
										,RRP_AT19_CHF
										,RRP_BE19_CHF
										,RRP_CH19_EUR
										,RRP_NL19_EUR
										,RRP_DE19_EUR
										,RRP_AT19_EUR
										,RRP_BE19_EUR
										,WSP_CH19_CHF
										,WSP_NL19_CHF
										,WSP_DE19_CHF
										,WSP_AT19_CHF
										,WSP_BE19_CHF
										,WSP_CH19_EUR
										,WSP_NL19_EUR
										,WSP_DE19_EUR
										,WSP_AT19_EUR
										,WSP_BE19_EUR)
	) pvt
WHERE IsDeleted = 0

--Count Records to be updated
SELECT @AffectedRows = COUNT(*)
FROM ref.NatArticlesPrices A
INNER JOIN #AllChangedMaterialsPivoted B ON A.MaterialNumber = B.MaterialNumber
WHERE A.HashDiff <> B.HashDiff

--Update Final Table
UPDATE A SET
 A.MaterialNumber	= B.MaterialNumber
,A.ModifiedOn		= B.ModifiedOn
,A.IsDeleted		= B.IsDeleted
,A.RRP_CH19_CHF		= B.RRP_CH19_CHF
,A.RRP_NL19_CHF		= B.RRP_NL19_CHF
,A.RRP_DE19_CHF		= B.RRP_DE19_CHF
,A.RRP_AT19_CHF		= B.RRP_AT19_CHF
,A.RRP_BE19_CHF		= B.RRP_BE19_CHF
,A.RRP_CH19_EUR		= B.RRP_CH19_EUR
,A.RRP_NL19_EUR		= B.RRP_NL19_EUR
,A.RRP_DE19_EUR		= B.RRP_DE19_EUR
,A.RRP_AT19_EUR		= B.RRP_AT19_EUR
,A.RRP_BE19_EUR		= B.RRP_BE19_EUR
,A.WSP_CH19_CHF		= B.WSP_CH19_CHF
,A.WSP_NL19_CHF		= B.WSP_NL19_CHF
,A.WSP_DE19_CHF		= B.WSP_DE19_CHF
,A.WSP_AT19_CHF		= B.WSP_AT19_CHF
,A.WSP_BE19_CHF		= B.WSP_BE19_CHF
,A.WSP_CH19_EUR		= B.WSP_CH19_EUR
,A.WSP_NL19_EUR		= B.WSP_NL19_EUR
,A.WSP_DE19_EUR		= B.WSP_DE19_EUR
,A.WSP_AT19_EUR		= B.WSP_AT19_EUR
,A.WSP_BE19_EUR		= B.WSP_BE19_EUR
,A.HashDiff			= B.HashDiff
FROM ref.NatArticlesPrices A
INNER JOIN #AllChangedMaterialsPivoted B ON A.MaterialNumber = B.MaterialNumber
WHERE A.HashDiff <> B.HashDiff
	
--Log count of updated records
UPDATE DTlogs SET
  Updated = @AffectedRows
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId


--Count Records to be inserted
SELECT @AffectedRows = COUNT(*)
FROM #AllChangedMaterialsPivoted A
LEFT JOIN ref.NatArticlesPrices B ON A.MaterialNumber = B.MaterialNumber
WHERE B.MaterialNumber IS NULL

--Insert to Final Table
INSERT INTO ref.NatArticlesPrices
(
 MaterialNumber
,CreatedOn
,ModifiedOn
,IsDeleted
,RRP_CH19_CHF
,RRP_NL19_CHF
,RRP_DE19_CHF
,RRP_AT19_CHF
,RRP_BE19_CHF
,RRP_CH19_EUR
,RRP_NL19_EUR
,RRP_DE19_EUR
,RRP_AT19_EUR
,RRP_BE19_EUR
,WSP_CH19_CHF
,WSP_NL19_CHF
,WSP_DE19_CHF
,WSP_AT19_CHF
,WSP_BE19_CHF
,WSP_CH19_EUR
,WSP_NL19_EUR
,WSP_DE19_EUR
,WSP_AT19_EUR
,WSP_BE19_EUR
,HashDiff
)
SELECT
	 A.MaterialNumber
	,A.ModifiedOn
	,A.ModifiedOn
	,A.IsDeleted
	,A.RRP_CH19_CHF
	,A.RRP_NL19_CHF
	,A.RRP_DE19_CHF
	,A.RRP_AT19_CHF
	,A.RRP_BE19_CHF
	,A.RRP_CH19_EUR
	,A.RRP_NL19_EUR
	,A.RRP_DE19_EUR
	,A.RRP_AT19_EUR
	,A.RRP_BE19_EUR
	,A.WSP_CH19_CHF
	,A.WSP_NL19_CHF
	,A.WSP_DE19_CHF
	,A.WSP_AT19_CHF
	,A.WSP_BE19_CHF
	,A.WSP_CH19_EUR
	,A.WSP_NL19_EUR
	,A.WSP_DE19_EUR
	,A.WSP_AT19_EUR
	,A.WSP_BE19_EUR
	,A.HashDiff

FROM #AllChangedMaterialsPivoted A
LEFT JOIN ref.NatArticlesPrices B ON A.MaterialNumber = B.MaterialNumber
WHERE B.MaterialNumber IS NULL

--Log count of inserted records
UPDATE DTlogs SET 
  Inserted = @AffectedRows
, ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId


--Count Records to be inserted
SELECT @AffectedRows = COUNT(*)
FROM ref.NatArticlesPrices A
	INNER JOIN #AllChangedMaterials C ON A.MaterialNumber = C.MaterialNumber
	LEFT JOIN #AllChangedMaterialsPivoted B ON A.MaterialNumber = B.MaterialNumber
WHERE B.MaterialNumber IS NULL

--update deletions (only deleted status and LDTS)
UPDATE A 
SET
	 A.ModifiedOn			= @LoadDate
	,A.IsDeleted			= 1
	,A.[HashDiff]			= CONVERT(BINARY(16), HASHBYTES('MD5',CONCAT(
									UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), A.MaterialNumber)))),'_',
									UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), @LoadDate)))),'_',
									UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), 1 )))),'_',
									UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), A.RRP_CH19_CHF )))),'_',
									UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), A.RRP_NL19_CHF )))),'_',
									UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), A.RRP_DE19_CHF )))),'_',
									UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), A.RRP_AT19_CHF )))),'_',
									UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), A.RRP_BE19_CHF )))),'_',
									UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), A.RRP_CH19_EUR )))),'_',
									UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), A.RRP_NL19_EUR )))),'_',
									UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), A.RRP_DE19_EUR )))),'_',
									UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), A.RRP_AT19_EUR )))),'_',
									UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), A.RRP_BE19_EUR )))),'_',
									UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), A.WSP_CH19_CHF )))),'_',
									UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), A.WSP_NL19_CHF )))),'_',
									UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), A.WSP_DE19_CHF )))),'_',
									UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), A.WSP_AT19_CHF )))),'_',
									UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), A.WSP_BE19_CHF )))),'_',
									UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), A.WSP_CH19_EUR )))),'_',
									UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), A.WSP_NL19_EUR )))),'_',
									UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), A.WSP_DE19_EUR )))),'_',
									UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), A.WSP_AT19_EUR )))),'_',
									UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), A.WSP_BE19_EUR ))))
									)))
FROM ref.NatArticlesPrices A
	INNER JOIN #AllChangedMaterials C ON A.MaterialNumber = C.MaterialNumber
	LEFT JOIN #AllChangedMaterialsPivoted B ON A.MaterialNumber = B.MaterialNumber
WHERE B.MaterialNumber IS NULL

--Log count of deleted records
UPDATE DTlogs SET 
  Deleted = @AffectedRows
, ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

-- EXEC [dbo].[S4Hana_spProvNatActiclesPrices] '1900-01-01'
-- SELECT TOP 100 * FROM ref.NatArticlesPrices
