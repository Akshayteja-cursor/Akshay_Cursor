﻿CREATE PROC [dbo].[S4Hana_spPlantMaterialPricesHistory] @isFullMode [bit] AS 
Begin 
IF @isFullMode = 1

		BEGIN

			IF OBJECT_ID(N'tempdb..#PartitionedGroups') IS NOT NULL
				DROP TABLE #PartitionedGroups;

			IF OBJECT_ID(N'tempdb..#AggMaterialLandedCost') IS NOT NULL
				DROP TABLE #AggMaterialLandedCost;

			SELECT
				Material,
				Plant,
				MovingAveragePrice,
				PriceCurrency,
				VALIDFROMDAT,
				VALIDTODAT
			INTO #AggMaterialLandedCost
			FROM [biz].[S4Hana_AggMaterialStockPrices]
			WHERE MovingAveragePrice <> 0

			UNION ALL

			SELECT
				Material,
				Plant,
				MovingAveragePrice,
				PriceCurrency,
				VALIDFROMDAT,
				VALIDTODAT
			FROM [biz].[S4Hana_AggMaterialStockPricesHistory]
			WHERE MovingAveragePrice <> 0;

			WITH CTE
			AS
			(
			SELECT 
				REPLACE(price.Material, '-', ' ') AS ArticleSize_BK,
				plant.GSMCode AS GSMStoreCode,
				plant.SalesOrganization,
				price.PriceCurrency AS ArticleCurrencyCode,
				TRY_CAST(price.MovingAveragePrice AS decimal(18, 2)) AS UnitLandedCost,
				TRY_CAST(price.VALIDFROMDAT AS date) AS ValidFrom,
				ISNULL(LEAD(DATEADD(DAY, -1, TRY_CAST(price.VALIDFROMDAT AS date)), 1) OVER(PARTITION BY plant.GSMCode, price.Material ORDER BY TRY_CAST(price.VALIDFROMDAT AS date)), '9999-12-31') AS ValidTo,
				ISNULL(LAG(TRY_CAST(price.MovingAveragePrice AS decimal(18, 2)), 1) OVER(PARTITION BY plant.GSMCode, price.Material ORDER BY TRY_CAST(price.VALIDFROMDAT AS date)), 0) AS PrevPrice,
				ROW_NUMBER() OVER(PARTITION BY plant.GSMCode, price.Material ORDER BY TRY_CAST(price.VALIDFROMDAT AS date)) AS rN
			FROM #AggMaterialLandedCost AS price
			JOIN [stag].[S4Hana_Plants] AS plant
			ON price.Plant = plant.Plant
			)

			SELECT
				ArticleSize_BK,
				GSMStoreCode,
				SalesOrganization,
				ArticleCurrencyCode,
				UnitLandedCost,
				CASE WHEN rN = 1 THEN '2000-01-01' ELSE ValidFrom END AS ValidFrom,
				ValidTo,
				SUM(ABS(UnitLandedCost - PrevPrice)) OVER(PARTITION BY ArticleSize_BK, GSMStoreCode ORDER BY ValidFrom) AS PartitionGroup
			INTO #PartitionedGroups
			FROM CTE;

			INSERT INTO ref.PlantMaterialPricesHistory
			SELECT
				 CONVERT([BINARY](16), HASHBYTES('MD5', UPPER(LTRIM(RTRIM(ISNULL(CONVERT([NVARCHAR](200),  ArticleSize_BK), '')))) + '_' +
								UPPER(LTRIM(RTRIM(ISNULL(CONVERT([NVARCHAR](200),  GSMStoreCode), '')))) + '_' +
								UPPER(LTRIM(RTRIM(ISNULL(CONVERT([NVARCHAR](200),  MIN(ValidFrom)), '')))) + '_' +
								UPPER(LTRIM(RTRIM(ISNULL(CONVERT([NVARCHAR](200), SalesOrganization), ''))))

								)) AS HashValueBK,
				ArticleSize_BK,
				GSMStoreCode,
				ArticleCurrencyCode,
				UnitLandedCost,
				MIN(ValidFrom) AS ValidFrom,
				MAX(ValidTo) AS ValidTo,
				CONVERT([BINARY](16), HASHBYTES('MD5', UPPER(LTRIM(RTRIM(ISNULL(CONVERT([NVARCHAR](200),  UnitLandedCost), '')))) + '_' +
								UPPER(LTRIM(RTRIM(ISNULL(CONVERT([NVARCHAR](200),  ArticleCurrencyCode), '')))) + '_' +
								UPPER(LTRIM(RTRIM(ISNULL(CONVERT([NVARCHAR](200),  MAX(ValidTo)), ''))))
								)) AS HashDiff,
				GETDATE() AS CreationDate,
				GETDATE() AS ModificationDate,
				SalesOrganization
			FROM #PartitionedGroups
			GROUP BY
				ArticleSize_BK,
				GSMStoreCode,
				SalesOrganization,
				ArticleCurrencyCode,
				UnitLandedCost,
				PartitionGroup;

		END

	ELSE

		BEGIN
			
			IF OBJECT_ID(N'tempdb..#PartitionedGroups') IS NOT NULL
				DROP TABLE #TempCost;

			IF OBJECT_ID(N'tempdb..#TempGroups') IS NOT NULL
				DROP TABLE #TempGroups;

			IF OBJECT_ID(N'tempdb..#LandedCost') IS NOT NULL
				DROP TABLE #LandedCost;

			IF OBJECT_ID(N'tempdb..#AggMaterialLandedCostIncremental') IS NOT NULL
				DROP TABLE #AggMaterialLandedCostIncremental;

			DECLARE @lastUpdated DATETIME = (SELECT MAX(ModificationDate) AS ModificationDate FROM ref.PlantMaterialPricesHistory);
			
			SELECT
				Material,
				Plant,
				MovingAveragePrice,
				PriceCurrency,
				VALIDFROMDAT,
				VALIDTODAT,
				ModifiedOn
			INTO #AggMaterialLandedCostIncremental
			FROM [biz].[S4Hana_AggMaterialStockPrices]
			WHERE MovingAveragePrice <> 0 AND ModifiedOn > @lastUpdated;

			WITH CTE
			AS
			(
			SELECT 
				REPLACE(price.Material, '-', ' ') AS ArticleSize_BK,
				plant.GSMCode AS GSMStoreCode,
				price.PriceCurrency AS ArticleCurrencyCode,
				TRY_CAST(price.MovingAveragePrice AS decimal(18, 2)) AS UnitLandedCost,
				TRY_CAST(price.VALIDFROMDAT AS date) AS ValidFrom,
				TRY_CAST(price.VALIDTODAT AS date) AS ValidTo,
				ModifiedOn AS ModificationDate,
				SalesOrganization
			FROM #AggMaterialLandedCostIncremental AS price
			JOIN [stag].[S4Hana_Plants] AS plant
			ON price.Plant = plant.Plant)

			SELECT
				ArticleSize_BK,
				GSMStoreCode,
				ArticleCurrencyCode,
				UnitLandedCost,
				ValidFrom,
				ValidTo,
				ModificationDate,
				SalesOrganization
			INTO #TempCost
			FROM CTE
			UNION ALL
			SELECT
				lc.ArticleSize_BK,
				lc.GSMStoreCode,
				lc.ArticleCurrencyCode,
				lc.UnitLandedCost,
				lc.ValidFrom,
				lc.ValidTo,
				lc.ModificationDate,
				lc.SalesOrganization
			FROM ref.PlantMaterialPricesHistory AS lc
			JOIN CTE AS t
			ON lc.ArticleSize_BK = t.ArticleSize_BK AND lc.GSMStoreCode = t.GSMStoreCode
				AND (lc.ValidFrom > t.ValidFrom AND lc.ValidFrom <= t.ValidTo
					OR lc.ValidFrom < t.ValidFrom);

			WITH CTE
			AS
			(
			SELECT	
				ArticleSize_BK,
				GSMStoreCode,
				ArticleCurrencyCode,
				UnitLandedCost,
				ValidFrom,
				ISNULL(LEAD(DATEADD(DAY, -1, ValidFrom), 1) OVER(PARTITION BY GSMStoreCode, ArticleSize_BK ORDER BY ValidFrom), '9999-12-31') AS ValidTo,
				ISNULL(LAG(UnitLandedCost, 1) OVER(PARTITION BY GSMStoreCode, ArticleSize_BK ORDER BY ValidFrom), 0) AS PrevPrice,
				ROW_NUMBER() OVER(PARTITION BY GSMStoreCode, ArticleSize_BK ORDER BY ValidFrom) AS rN,
				ModificationDate,
				SalesOrganization
			FROM #TempCost)

			SELECT
				ArticleSize_BK,
				GSMStoreCode,
				ArticleCurrencyCode,
				UnitLandedCost,
				CASE WHEN rN = 1 AND ModificationDate > @lastUpdated THEN '2000-01-01' ELSE ValidFrom END AS ValidFrom,
				ValidTo,
				SalesOrganization,
				SUM(ABS(UnitLandedCost - PrevPrice)) OVER(PARTITION BY ArticleSize_BK, GSMStoreCode ORDER BY ValidFrom) AS PartitionGroup
			INTO #TempGroups
			FROM CTE;

			SELECT
				 CONVERT([BINARY](16), HASHBYTES('MD5', UPPER(LTRIM(RTRIM(ISNULL(CONVERT([NVARCHAR](200),  ArticleSize_BK), '')))) + '_' +
								UPPER(LTRIM(RTRIM(ISNULL(CONVERT([NVARCHAR](200),  GSMStoreCode), '')))) + '_' +
								UPPER(LTRIM(RTRIM(ISNULL(CONVERT([NVARCHAR](200),  MIN(ValidFrom)), ''))))
								)) AS HashValueBK,
				ArticleSize_BK,
				GSMStoreCode,
				ArticleCurrencyCode,
				UnitLandedCost,
				MIN(ValidFrom) AS ValidFrom,
				MAX(ValidTo) AS ValidTo,
				CONVERT([BINARY](16), HASHBYTES('MD5', UPPER(LTRIM(RTRIM(ISNULL(CONVERT([NVARCHAR](200),  UnitLandedCost), '')))) + '_' +
								UPPER(LTRIM(RTRIM(ISNULL(CONVERT([NVARCHAR](200),  ArticleCurrencyCode), '')))) + '_' +
								UPPER(LTRIM(RTRIM(ISNULL(CONVERT([NVARCHAR](200),  MAX(ValidTo)), ''))))
								)) AS HashDiff,
				GETDATE() AS CreationDate,
				GETDATE() AS ModificationDate,
				SalesOrganization
			INTO #LandedCost
			FROM #TempGroups
			GROUP BY
				ArticleSize_BK,
				GSMStoreCode,
				ArticleCurrencyCode,
				UnitLandedCost,
				PartitionGroup,
				SalesOrganization;

			INSERT INTO ref.PlantMaterialPricesHistory
			SELECT * FROM #LandedCost
			WHERE NOT EXISTS (
				SELECT 1 FROM ref.PlantMaterialPricesHistory AS slc
				WHERE slc.HashValueBK = #LandedCost.HashValueBK);

			UPDATE slc
			SET
				ArticleCurrencyCode = lc.ArticleCurrencyCode,
				UnitLandedCost = lc.UnitLandedCost,
				ValidTo = lc.ValidTo,
				HashDiff = lc.HashDiff,
				ModificationDate = lc.ModificationDate,
				SalesOrganization = lc.SalesOrganization
			FROM ref.PlantMaterialPricesHistory AS slc
			JOIN #LandedCost AS lc
			ON slc.HashValueBK = lc.HashValueBK
				AND slc.HashDiff <> lc.HashDiff;
END 
END