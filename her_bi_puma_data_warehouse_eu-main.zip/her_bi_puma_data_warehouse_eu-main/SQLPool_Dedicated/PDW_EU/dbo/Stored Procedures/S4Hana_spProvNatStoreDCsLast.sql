﻿CREATE PROC [dbo].[S4Hana_spProvNatStoreDCsLast] @LDTS [DATETIME2](7) AS

DECLARE @LoadDate DATETIME2(7) = GETDATE();

IF OBJECT_ID('tempdb..#NatStoreDCs') IS NOT NULL DROP TABLE #NatStoreDCs;

-- logging informations - BEGIN
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(0) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(0)
DECLARE @DestinationLastLoadDate DATETIME2(0)
DECLARE @BatchLdts DATETIME2(0) = @LDTS
DECLARE @AffectedRows BIGINT = NULL
-- logging Informations - END

-- get last LDTS Informations for Logging
IF(EXISTS(SELECT 1 FROM ref.NatStoreDCs))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(modifiedOn))
		FROM ref.NatStoreDCs
	END
ELSE 
	BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

IF(EXISTS(SELECT 1 FROM ref.NatStoreDCs))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(modifiedOn))
		FROM ref.NatStoreDCs
	END
ELSE 
	BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END
-- Logging Informations END


-- Log first DATA Informations

INSERT INTO etl.DataTransferLogs
(
  DataTransferLogId
, TransferName
, TransferGroupName
, TargetTableName
, TargetSchemaName
, ExecStart
, SourceLastLoadDate
, DestinationLastLoadDate
, BatchLdts
)
SELECT 
  @DataTransferLogId 
, 'S4Hana_spProvNatStoreDCsLast'
, 'NatStoreDCs'
, 'NatStoreDCs'
, 'ref'
, @ExecStart
, @SourceLastLoadDate
, @DestinationLastLoadDate
, @BatchLdts;

-- Log first DATA Informations END

WITH CTE_ArtificialDCs AS
(
	/*add artificial DCs*/
	SELECT 'ECM' AS Channel	UNION
	SELECT 'FOC' AS Channel	UNION
	SELECT 'FPS' AS Channel	UNION
	SELECT 'N/A' AS Channel	UNION
	SELECT 'CON' AS Channel	UNION
	SELECT 'WHS' AS Channel	UNION
	SELECT 'WHC' AS Channel	UNION
	SELECT 'FRA' AS Channel UNION /* added for France Franchise by Stelli 20240119 */
	SELECT 'FPC' AS Channel UNION /* added by Wojtek 20241219*/
	SELECT NULL  AS Channel
)
, CTE_NatStoreDCs AS
(
	SELECT
	  CONCAT(A.StoreCode, '|', C.CompanyCode)															AS NatStoreDC_BK
	, @LoadDate																							AS CreatedOn
	, @LoadDate																							AS ModifiedOn
	, A.StoreCode																						AS NatStoreDCCode
	, C.CompanyCode																						AS CompanyCode
	, C.IntPupMasterId																					AS IntPupMasterId
	, C.PDUCode																							AS PDUCode
	, A.StoreName																						AS NatStoreDCName
	, A.City																							AS City
	, A.Street																							AS Street
	, A.PostalCode																						AS PostalCode
	, CASE WHEN A.SalesOrganizationCode = '2100' THEN NULL 
		ELSE 'CON'
		END																								AS Channel
	, A.CountryCode																						AS CountryCode
	, D.ISOCountryDesc																					AS CountryDesc
	, A.DistributionChannelCode																			AS DistChannelCode
	, E.[Description]																					AS DistChannelDesc
	, A.GSMCode																							AS GSMCode
	, CASE WHEN LEFT(A.StoreCode, 1) = 'A' THEN 10 
		   ELSE 60
	  END																								AS IntDCTypeCode
	FROM stag.S4Hana_vPlants A
	INNER JOIN pdwref.S4Hana_Interfaces C ON A.SalesOrganizationCode = C.SalesOrg
	INNER JOIN pdwref.ISOCountries D ON A.CountryCode = D.ISOCountryCode
	LEFT JOIN stag.S4Hana_vPUMADistributionChannelTexts E ON A.DistributionChannelCode = E.Code
	WHERE A.PlantCategoryCode = 'A'
	AND (
		 A.LDTS >= @LDTS
		)
	--===================
	UNION ALL
	SELECT
	  CONCAT(CASE WHEN B.Channel IS NOT NULL THEN CONCAT(A.StoreCode, '_', B.Channel)
				  ELSE A.StoreCode
			 END, '|', D.CompanyCode)																	AS NatStoreDC_BK
	, @LoadDate																							AS CreatedOn
	, @LoadDate																							AS ModifiedOn
	, CASE WHEN B.Channel IS NOT NULL THEN CONCAT(A.StoreCode, '_', B.Channel)
		   ELSE A.StoreCode
	  END																								AS NatStoreDCCode
	, C.CompanyCode																						AS CompanyCode
	, D.IntPupMasterId																					AS IntPupMasterId
	, D.PDUCode																							AS PDUCode
	, A.StoreName																						AS NatStoreDCName
	, A.City																							AS City
	, A.Street																							AS Street
	, A.PostalCode																						AS PostalCode
	, B.Channel																							AS Channel
	, A.CountryCode																						AS CountryCode
	, E.ISOCountryDesc																					AS CountryDesc
	, A.DistributionChannelCode																			AS DistChannelCode
	, F.[Description]																					AS DistChannelDesc
	, A.GSMCode																							AS GSMCode
	, CASE WHEN A.StoreName LIKE '%virtual%' THEN 20 
		   ELSE 50 
	  END																								AS IntDCTypeCode
	FROM stag.S4Hana_vPlants A
	CROSS JOIN CTE_ArtificialDCs B
	INNER JOIN stag.S4Hana_vSalesOrgToCompanyCode C ON A.SalesOrganizationCode = C.Code
	INNER JOIN pdwref.S4Hana_Interfaces D ON C.CompanyCode = D.CompanyCode
	INNER JOIN pdwref.ISOCountries E ON A.CountryCode = E.ISOCountryCode
	LEFT JOIN stag.S4Hana_vPUMADistributionChannelTexts F ON A.DistributionChannelCode = F.Code
	WHERE A.PlantCategoryCode = 'B'
	AND (
		 A.LDTS >= @LDTS 
		 OR C.LDTS >= @LDTS
		)
)

--Insert to temp table
SELECT
  NatStoreDC_BK
, CreatedOn
, ModifiedOn
, NatStoreDCCode
, CompanyCode
, IntPupMasterId
, PDUCode
, CONVERT([BINARY](16), HASHBYTES('MD5',CONCAT(
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), NatStoreDC_BK)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), NatStoreDCCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CompanyCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), IntPupMasterId)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PDUCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), NatStoreDCName)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), City)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), Street)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PostalCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), Channel)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CountryCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CountryDesc)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), DistChannelCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), DistChannelDesc)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), GSMCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), IntDCTypeCode))))
	))) AS HashDiff
, NatStoreDCName
, City
, Street
, PostalCode
, Channel
, CountryCode
, CountryDesc
, DistChannelCode
, DistChannelDesc
, GSMCode
, IntDCTypeCode
INTO #NatStoreDCs
FROM CTE_NatStoreDCs

--Count Records to be updated
SELECT @AffectedRows = COUNT(*)
FROM ref.NatStoreDCs A
INNER JOIN #NatStoreDCs B ON A.NatStoreDC_BK = B.NatStoreDC_BK
WHERE A.HashDiff <> B.HashDiff

--Update Final Table
UPDATE A SET
  A.ModifiedOn = @LoadDate
, A.NatStoreDCCode = B.NatStoreDCCode
, A.CompanyCode = B.CompanyCode
, A.IntPupMasterId = B.IntPupMasterId
, A.PDUCode = B.PDUCode
, A.HashDiff = B.HashDiff
, A.NatStoreDCName = B.NatStoreDCName
, A.City = B.City
, A.Street = B.Street
, A.PostalCode = B.PostalCode
, A.Channel = B.Channel
, A.CountryCode = B.CountryCode
, A.CountryDesc = B.CountryDesc
, A.DistChannelCode = B.DistChannelCode
, A.DistChannelDesc = B.DistChannelDesc
, A.GSMCode = B.GSMCode
, A.IntDCTypeCode = B.IntDCTypeCode
FROM ref.NatStoreDCs A
INNER JOIN #NatStoreDCs B ON A.NatStoreDC_BK = B.NatStoreDC_BK
WHERE A.HashDiff <> B.HashDiff

--Log count of updated records
UPDATE DTlogs SET
  Updated = @AffectedRows
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

--Count Records to be inserted
SELECT @AffectedRows = COUNT(*)
FROM #NatStoreDCs A
LEFT JOIN ref.NatStoreDCs B ON A.NatStoreDC_BK = B.NatStoreDC_BK
WHERE B.NatStoreDC_BK IS NULL

--Insert to Final Table
INSERT INTO ref.NatStoreDCs
(
  NatStoreDC_BK
, CreatedOn
, ModifiedOn
, NatStoreDCCode
, CompanyCode
, IntPupMasterId
, PDUCode
, HashDiff
, NatStoreDCName
, City
, Street
, PostalCode
, Channel
, CountryCode
, CountryDesc
, DistChannelCode
, DistChannelDesc
, GSMCode
, IntDCTypeCode
)
SELECT
  A.NatStoreDC_BK
, A.CreatedOn
, A.ModifiedOn
, A.NatStoreDCCode
, A.CompanyCode
, A.IntPupMasterId
, A.PDUCode
, A.HashDiff
, A.NatStoreDCName
, A.City
, A.Street
, A.PostalCode
, A.Channel
, A.CountryCode
, A.CountryDesc
, A.DistChannelCode
, A.DistChannelDesc
, A.GSMCode
, A.IntDCTypeCode
FROM #NatStoreDCs A
LEFT JOIN ref.NatStoreDCs B ON A.NatStoreDC_BK = B.NatStoreDC_BK
WHERE B.NatStoreDC_BK IS NULL

--Log count of inserted records
UPDATE DTlogs SET 
  Inserted = @AffectedRows
, ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId