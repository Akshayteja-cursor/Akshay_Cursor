﻿CREATE PROC [dbo].[S4Hana_spProvNatCustomersLast_DS_V02] @LDTS [DATETIME2](7) AS

DECLARE @LoadDate DATETIME2(7) = GETDATE();

IF OBJECT_ID('tempdb..#NatCustomers') IS NOT NULL DROP TABLE #NatCustomers;

-- logging informations - BEGIN
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(0) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(0)
DECLARE @DestinationLastLoadDate DATETIME2(0)
DECLARE @BatchLdts DATETIME2(0) = @LDTS
DECLARE @AffectedRows BIGINT = NULL
-- logging Informations - END

-- get last LDTS Informations for Logging
IF(EXISTS(SELECT 1 FROM ref.NatCustomers_DS_V02))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(ModifiedOn))
		FROM ref.NatCustomers_DS_V02
	END
ELSE 
	BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

IF(EXISTS(SELECT 1 FROM [biz].[S4Hana_Customers]))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(LDTS))
		FROM [biz].[S4Hana_Customers]
	END
ELSE 
	BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END
-- Logging Informations END


-- Log first DATA Informations

INSERT INTO etl.DataTransferLogs
(
  DataTransferLogId
, TransferName
, TransferGroupName
, TargetTableName
, TargetSchemaName
, ExecStart
, SourceLastLoadDate
, DestinationLastLoadDate
, BatchLdts
)
SELECT 
  @DataTransferLogId 
, 'S4Hana_spProvNatCustomersLast_DS_V02'
, 'NatCustomers_DS_V02'
, 'NatCustomers_DS_V02'
, 'ref'
, @ExecStart
, @SourceLastLoadDate
, @DestinationLastLoadDate
, @BatchLdts;

-- Log first DATA Informations END
WITH CTE AS
(
	SELECT
	   a.[Customer]
	  ,@LoadDate	AS CreatedOn
	  ,@LoadDate	AS ModifiedOn
      ,a.[CustomerName]
      ,a.[CustomerFullName]
      ,a.[CreatedByUser]
      ,a.[CreationDate]
	  ,left(STRING_AGG(b.SalesOrganization, ',') WITHIN GROUP (ORDER BY SalesOrganization), 40) as SalesOrganizations
	  ,a.[CustomerAccountGroup]
      ,a.[AddressID]
      ,a.[CustomerClassification]
      ,a.[VATRegistration]     
      ,a.[AuthorizationGroup]
      ,a.[DeliveryIsBlocked]
      ,a.[PostingIsBlocked]
      ,a.[BillingIsBlockedForCustomer]
      ,a.[OrderIsBlockedForCustomer]
      ,a.[InternationalLocationNumber1]
      ,a.[IsOneTimeAccount]
      ,a.[TaxJurisdiction]
      ,a.[Industry]
      ,a.[TaxNumberType]
      ,a.[TaxNumber1]
      ,a.[TaxNumber2]
      ,a.[TaxNumber3]
      ,a.[TaxNumber4]
      ,a.[TaxNumber5]
      ,a.[CustomerCorporateGroup]
      ,a.[Supplier]
      ,a.[NielsenRegion]
      ,a.[IndustryCode1]
      ,a.[IndustryCode2]
      ,a.[IndustryCode3]
      ,a.[IndustryCode4]
      ,a.[IndustryCode5]
      ,a.[Country]
      ,a.[OrganizationBPName1]
      ,a.[OrganizationBPName2]
      ,a.[CityName]
      ,a.[PostalCode]
      ,a.[StreetName]
      ,a.[SortField]
      ,a.[FaxNumber]
      ,a.[BR_SUFRAMACode]
      ,a.[Region]
      ,a.[AlternativePayerAccount]
      ,a.[DataMediumExchangeIndicator]
      ,a.[VATLiability]
      ,a.[IsBusinessPurposeCompleted]
      ,a.[ResponsibleType]
      ,a.[FiscalAddress]
      ,a.[NFPartnerIsNaturalPerson]
      ,a.[DeletionIndicator]
      ,a.[Language]
      ,a.[TaxInvoiceRepresentativeName]
      ,a.[BusinessType]
      ,a.[IndustryType]
      ,a.[IsDeleted]
	  ,a.ConditionGroup1
	  ,a.ConditionGroup2
  FROM [biz].[S4Hana_Customers] a
  INNER JOIN (SELECT DISTINCT CUSTOMER, SalesOrganization, LDTS FROM [biz].[S4Hana_CustomerSalesAttributes]) b on a.customer=b.customer
  WHERE
	   A.LDTS >= @LDTS 
	   or B.LDTS >= @LDTS
  GROUP BY
	   a.[Customer]
      ,a.[CustomerName]
      ,a.[CustomerFullName]
      ,a.[CreatedByUser]
      ,a.[CreationDate],a.[CustomerAccountGroup]
      ,a.[AddressID]
      ,a.[CustomerClassification]
      ,a.[VATRegistration]     
      ,a.[AuthorizationGroup]
      ,a.[DeliveryIsBlocked]
      ,a.[PostingIsBlocked]
      ,a.[BillingIsBlockedForCustomer]
      ,a.[OrderIsBlockedForCustomer]
      ,a.[InternationalLocationNumber1]
      ,a.[IsOneTimeAccount]
      ,a.[TaxJurisdiction]
      ,a.[Industry]
      ,a.[TaxNumberType]
      ,a.[TaxNumber1]
      ,a.[TaxNumber2]
      ,a.[TaxNumber3]
      ,a.[TaxNumber4]
      ,a.[TaxNumber5]
      ,a.[CustomerCorporateGroup]
      ,a.[Supplier]
      ,a.[NielsenRegion]
      ,a.[IndustryCode1]
      ,a.[IndustryCode2]
      ,a.[IndustryCode3]
      ,a.[IndustryCode4]
      ,a.[IndustryCode5]
      ,a.[Country]
      ,a.[OrganizationBPName1]
      ,a.[OrganizationBPName2]
      ,a.[CityName]
      ,a.[PostalCode]
      ,a.[StreetName]
      ,a.[SortField]
      ,a.[FaxNumber]
      ,a.[BR_SUFRAMACode]
      ,a.[Region]
      ,a.[AlternativePayerAccount]
      ,a.[DataMediumExchangeIndicator]
      ,a.[VATLiability]
      ,a.[IsBusinessPurposeCompleted]
      ,a.[ResponsibleType]
      ,a.[FiscalAddress]
      ,a.[NFPartnerIsNaturalPerson]
      ,a.[DeletionIndicator]
      ,a.[Language]
      ,a.[TaxInvoiceRepresentativeName]
      ,a.[BusinessType]
      ,a.[IndustryType]
      ,a.[IsDeleted]
	  ,a.ConditionGroup1
	  ,a.ConditionGroup2
	
)

--Insert to temp table
SELECT 
	   Customer
	  ,CreatedOn                    
	  ,ModifiedOn
	  ,[CustomerName]
	  ,[CustomerFullName]
      ,[CreatedByUser]
	  ,[CreationDate]
	  ,SalesOrganizations
      ,[CustomerAccountGroup]
      ,[AddressID]
      ,[CustomerClassification]
      ,[VATRegistration]     
      ,[AuthorizationGroup]
      ,[DeliveryIsBlocked]
      ,[PostingIsBlocked]
      ,[BillingIsBlockedForCustomer]
      ,[OrderIsBlockedForCustomer]
      ,[InternationalLocationNumber1]
      ,[IsOneTimeAccount]
      ,[TaxJurisdiction]
      ,[Industry]
      ,[TaxNumberType]
      ,[TaxNumber1]
      ,[TaxNumber2]
      ,[TaxNumber3]
      ,[TaxNumber4]
      ,[TaxNumber5]
      ,[CustomerCorporateGroup]
      ,[Supplier]
      ,[NielsenRegion]
      ,[IndustryCode1]
      ,[IndustryCode2]
      ,[IndustryCode3]
      ,[IndustryCode4]
      ,[IndustryCode5]
      ,[Country]
      ,[OrganizationBPName1]
      ,[OrganizationBPName2]
      ,[CityName]
      ,[PostalCode]
      ,[StreetName]
      ,[SortField]
      ,[FaxNumber]
      ,[BR_SUFRAMACode]
      ,[Region]
      ,[AlternativePayerAccount]
      ,[DataMediumExchangeIndicator]
      ,[VATLiability]
      ,[IsBusinessPurposeCompleted]
      ,[ResponsibleType]
      ,[FiscalAddress]
      ,[NFPartnerIsNaturalPerson]
      ,[DeletionIndicator]
      ,[Language]
      ,[TaxInvoiceRepresentativeName]
      ,[BusinessType]
      ,[IndustryType]
      ,[IsDeleted]
	  ,ConditionGroup1
	  ,ConditionGroup2
,CONVERT([BINARY](16), HASHBYTES('MD5',CONCAT(
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), Customer                        )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [CustomerName]				   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [CustomerFullName]			   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [CreatedByUser]				   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [CreationDate]				   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), SalesOrganizations			   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [CustomerAccountGroup]		   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [AddressID]					   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [CustomerClassification]		   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [VATRegistration]     		   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [AuthorizationGroup]			   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DeliveryIsBlocked]			   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [PostingIsBlocked]			   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [BillingIsBlockedForCustomer]   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [OrderIsBlockedForCustomer]	   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [InternationalLocationNumber1]  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [IsOneTimeAccount]			   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [TaxJurisdiction]			   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [Industry]					   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [TaxNumberType]				   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [TaxNumber1]					   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [TaxNumber2]					   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [TaxNumber3]					   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [TaxNumber4]					   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [TaxNumber5]					   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [CustomerCorporateGroup]		   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [Supplier]					   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [NielsenRegion]				   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [IndustryCode1]				   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [IndustryCode2]				   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [IndustryCode3]				   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [IndustryCode4]				   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [IndustryCode5]				   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [Country]					   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [OrganizationBPName1]		   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [OrganizationBPName2]		   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [CityName]					   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [PostalCode]					   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [StreetName]					   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [SortField]					   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [FaxNumber]					   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [BR_SUFRAMACode]				   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [Region]						   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [AlternativePayerAccount]	   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DataMediumExchangeIndicator]   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [VATLiability]				   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [IsBusinessPurposeCompleted]	   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [ResponsibleType]			   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [FiscalAddress]				   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [NFPartnerIsNaturalPerson]	   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DeletionIndicator]			   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [Language]					   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [TaxInvoiceRepresentativeName]  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [BusinessType]				   )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [IndustryType]                  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ConditionGroup1                  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ConditionGroup2                  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [IsDeleted]))))    
	))) AS HashDiff

INTO #NatCustomers
FROM CTE

--Count Records to be updated
SELECT @AffectedRows = COUNT(*)
FROM ref.NatCustomers_DS_V02 A
INNER JOIN #NatCustomers B ON A.Customer = B.Customer
WHERE A.HashDiff <> B.HashDiff

--Update Final Table
UPDATE A SET
  A.ModifiedOn = @LoadDate
, A.[CustomerName]                  = B.[CustomerName]
, A.[CustomerFullName]				= B.[CustomerFullName]
, A.[CreatedByUser]					= B.[CreatedByUser]
, A.[CreationDate]					= B.[CreationDate]
, A.SalesOrganizations				= B.SalesOrganizations
, A.[CustomerAccountGroup]			= B.[CustomerAccountGroup]
, A.[AddressID]						= B.[AddressID]
, A.[CustomerClassification]		= B.[CustomerClassification]
, A.[VATRegistration]     			= B.[VATRegistration]     
, A.[AuthorizationGroup]			= B.[AuthorizationGroup]
, A.[DeliveryIsBlocked]				= B.[DeliveryIsBlocked]
, A.[PostingIsBlocked]				= B.[PostingIsBlocked]
, A.[BillingIsBlockedForCustomer]	= B.[BillingIsBlockedForCustomer]
, A.[OrderIsBlockedForCustomer]		= B.[OrderIsBlockedForCustomer]
, A.[InternationalLocationNumber1]  = B.[InternationalLocationNumber1] 
, A.[IsOneTimeAccount]				= B.[IsOneTimeAccount]
, A.[TaxJurisdiction]				= B.[TaxJurisdiction]
, A.[Industry]						= B.[Industry]
, A.[TaxNumberType]					= B.[TaxNumberType]
, A.[TaxNumber1]					= B.[TaxNumber1]
, A.[TaxNumber2]					= B.[TaxNumber2]
, A.[TaxNumber3]					= B.[TaxNumber3]
, A.[TaxNumber4]					= B.[TaxNumber4]
, A.[TaxNumber5]					= B.[TaxNumber5]
, A.[CustomerCorporateGroup]		= B.[CustomerCorporateGroup]
, A.[Supplier]						= B.[Supplier]
, A.[NielsenRegion]					= B.[NielsenRegion]
, A.[IndustryCode1]					= B.[IndustryCode1]
, A.[IndustryCode2]					= B.[IndustryCode2]
, A.[IndustryCode3]					= B.[IndustryCode3]
, A.[IndustryCode4]					= B.[IndustryCode4]
, A.[IndustryCode5]					= B.[IndustryCode5]
, A.[Country]						= B.[Country]
, A.[OrganizationBPName1]			= B.[OrganizationBPName1]
, A.[OrganizationBPName2]			= B.[OrganizationBPName2]
, A.[CityName]						= B.[CityName]
, A.[PostalCode]					= B.[PostalCode]
, A.[StreetName]					= B.[StreetName]
, A.[SortField]						= B.[SortField]
, A.[FaxNumber]						= B.[FaxNumber]
, A.[BR_SUFRAMACode]				= B.[BR_SUFRAMACode]
, A.[Region]						= B.[Region]
, A.[AlternativePayerAccount]		= B.[AlternativePayerAccount]
, A.[DataMediumExchangeIndicator]	= B.[DataMediumExchangeIndicator]
, A.[VATLiability]					= B.[VATLiability]
, A.[IsBusinessPurposeCompleted]	= B.[IsBusinessPurposeCompleted]
, A.[ResponsibleType]				= B.[ResponsibleType]
, A.[FiscalAddress]					= B.[FiscalAddress]
, A.[NFPartnerIsNaturalPerson]		= B.[NFPartnerIsNaturalPerson]
, A.[DeletionIndicator]				= B.[DeletionIndicator]
, A.[Language]						= B.[Language]
, A.[TaxInvoiceRepresentativeName]	= B.[TaxInvoiceRepresentativeName]
, A.[BusinessType]					= B.[BusinessType]
, A.[IndustryType]					= B.[IndustryType]
, A.[IsDeleted]						= B.[IsDeleted]
, A.ConditionGroup1					= B.ConditionGroup1
, A.ConditionGroup2					= B.ConditionGroup2
, A.HashDiff  = B.HashDiff
FROM ref.NatCustomers_DS_V02 A
INNER JOIN #NatCustomers B ON A.Customer = B.Customer
WHERE A.HashDiff <> B.HashDiff and B.IsDeleted = 0

--update deletion status
UPDATE A SET
	   A.ModifiedOn = @LoadDate
	  ,A.IsDeleted = 1
	  ,A.HashDiff  = B.HashDiff
FROM ref.NatCustomers_DS_V02 A
INNER JOIN #NatCustomers B ON A.Customer = B.Customer
WHERE A.HashDiff <> B.HashDiff and B.IsDeleted = 1

--Log count of updated records
UPDATE DTlogs SET
  Updated = @AffectedRows
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

--Count Records to be inserted
SELECT @AffectedRows = COUNT(*)
FROM #NatCustomers A
LEFT JOIN ref.NatCustomers_DS_V02 B ON A.Customer = B.Customer
WHERE B.Customer IS NULL

--Insert to Final Table
INSERT INTO ref.NatCustomers_DS_V02
(
      Customer
     ,CreatedOn                    
     ,ModifiedOn
     ,[CustomerName]
     ,[CustomerFullName]
     ,[CreatedByUser]
     ,[CreationDate]
     ,SalesOrganizations
     ,[CustomerAccountGroup]
     ,[AddressID]
     ,[CustomerClassification]
     ,[VATRegistration]     
     ,[AuthorizationGroup]
     ,[DeliveryIsBlocked]
     ,[PostingIsBlocked]
     ,[BillingIsBlockedForCustomer]
     ,[OrderIsBlockedForCustomer]
     ,[InternationalLocationNumber1]
     ,[IsOneTimeAccount]
     ,[TaxJurisdiction]
     ,[Industry]
     ,[TaxNumberType]
     ,[TaxNumber1]
     ,[TaxNumber2]
     ,[TaxNumber3]
     ,[TaxNumber4]
     ,[TaxNumber5]
     ,[CustomerCorporateGroup]
     ,[Supplier]
     ,[NielsenRegion]
     ,[IndustryCode1]
     ,[IndustryCode2]
     ,[IndustryCode3]
     ,[IndustryCode4]
     ,[IndustryCode5]
     ,[Country]
     ,[OrganizationBPName1]
     ,[OrganizationBPName2]
     ,[CityName]
     ,[PostalCode]
     ,[StreetName]
     ,[SortField]
     ,[FaxNumber]
     ,[BR_SUFRAMACode]
     ,[Region]
     ,[AlternativePayerAccount]
     ,[DataMediumExchangeIndicator]
     ,[VATLiability]
     ,[IsBusinessPurposeCompleted]
     ,[ResponsibleType]
     ,[FiscalAddress]
     ,[NFPartnerIsNaturalPerson]
     ,[DeletionIndicator]
     ,[Language]
     ,[TaxInvoiceRepresentativeName]
     ,[BusinessType]
     ,[IndustryType]
     ,[IsDeleted]
	 ,ConditionGroup1
	 ,ConditionGroup2
     ,HashDiff
)
SELECT
	   A.Customer
      ,A.CreatedOn                    
      ,A.ModifiedOn
      ,A.[CustomerName]
	  ,A.[CustomerFullName]
      ,A.[CreatedByUser]
      ,A.[CreationDate]
      ,A.SalesOrganizations
      ,A.[CustomerAccountGroup]
      ,A.[AddressID]
      ,A.[CustomerClassification]
      ,A.[VATRegistration]     
      ,A.[AuthorizationGroup]
      ,A.[DeliveryIsBlocked]
      ,A.[PostingIsBlocked]
      ,A.[BillingIsBlockedForCustomer]
      ,A.[OrderIsBlockedForCustomer]
      ,A.[InternationalLocationNumber1]
      ,A.[IsOneTimeAccount]
      ,A.[TaxJurisdiction]
      ,A.[Industry]
      ,A.[TaxNumberType]
      ,A.[TaxNumber1]
      ,A.[TaxNumber2]
      ,A.[TaxNumber3]
      ,A.[TaxNumber4]
      ,A.[TaxNumber5]
      ,A.[CustomerCorporateGroup]
      ,A.[Supplier]
      ,A.[NielsenRegion]
      ,A.[IndustryCode1]
      ,A.[IndustryCode2]
      ,A.[IndustryCode3]
      ,A.[IndustryCode4]
      ,A.[IndustryCode5]
      ,A.[Country]
      ,A.[OrganizationBPName1]
      ,A.[OrganizationBPName2]
      ,A.[CityName]
      ,A.[PostalCode]
      ,A.[StreetName]
      ,A.[SortField]
      ,A.[FaxNumber]
      ,A.[BR_SUFRAMACode]
      ,A.[Region]
      ,A.[AlternativePayerAccount]
      ,A.[DataMediumExchangeIndicator]
      ,A.[VATLiability]
      ,A.[IsBusinessPurposeCompleted]
      ,A.[ResponsibleType]
      ,A.[FiscalAddress]
      ,A.[NFPartnerIsNaturalPerson]
      ,A.[DeletionIndicator]
      ,A.[Language]
      ,A.[TaxInvoiceRepresentativeName]
      ,A.[BusinessType]
      ,A.[IndustryType]
      ,A.[IsDeleted]
	  ,A.ConditionGroup1
	  ,A.ConditionGroup2
      ,A.HashDiff
FROM #NatCustomers A
LEFT JOIN ref.NatCustomers_DS_V02 B ON A.Customer = B.Customer
WHERE B.Customer IS NULL

--Log count of inserted records
UPDATE DTlogs SET 
  Inserted = @AffectedRows
, ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId