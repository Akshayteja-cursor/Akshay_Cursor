﻿CREATE PROC [dbo].[S4Hana_spProvAvailableToPromiseCurrent] @LDTS [DATETIME2](7) AS
BEGIN
SET NOCOUNT ON

--DECLARE @LDTS DATETIME2(7) = '20241001'
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(7) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(7)
DECLARE @DestinationLastLoadDate DATETIME2(7)
DECLARE @BatchLdts DATETIME2(7) = @LDTS


-- do not use the input parameter, in case of an failure or reload situartion take the last tranfered LDTS from the Hist table
IF(EXISTS(SELECT 1 FROM [sourcing].[AvailableToPromiseCurrent]))
BEGIN
	SELECT @DestinationLastLoadDate = 
	MAX(LDTS)
	FROM [sourcing].[AvailableToPromiseCurrent]
END
ELSE BEGIN
	SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
END 

IF(EXISTS(SELECT 1 FROM stag.S4Hana_FreeAvailableStock))
BEGIN
	SELECT @SourceLastLoadDate = MAX(_LDTS)
	FROM  stag.S4Hana_FreeAvailableStock
END
ELSE BEGIN
	SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
END



IF OBJECT_ID('tempdb..#AvailableToPromiseLast') IS NOT NULL
BEGIN
    DROP TABLE #AvailableToPromiseLast
END


CREATE TABLE #AvailableToPromiseLast
(
	[HASH_BK] [binary](16) NULL,
	[AggInventoryMovements_HASH] [binary](16) NULL,
	[AggInventoryValuations_HASH] [binary](16) NULL,
	[AggInventoryTypes_HASH] [binary](16) NULL,
	[HASH_Diff] [binary](16) NULL,
	[NatStoreDC_BK] [nvarchar](20) NULL,
	[COMPANYCODE] [nvarchar](4) NULL,
	[PLANT] [nvarchar](4) NULL,
	[MATERIAL] [nvarchar](40) NULL,
	[STORAGELOCATION] [nvarchar](4) NULL,
	[STOCKSEGMENT] [nvarchar](40) NULL,
	[POSTINGDATE] [date] NULL,
	[ConfirmedDateATP] [date] null,
	[BatchID] [nvarchar](10) NOT NULL,
	[QTYTYPE] [nvarchar](128) NULL,
	[MATERIALBASEUNIT] [nvarchar](3) NULL,
	[QTY] [decimal](17, 2) NULL,
	[PRICE] [decimal](17, 2) NULL,
	[GROSS] [decimal](17, 2) NULL,
	[PRICECURRENCY] [nvarchar](5) NULL,
	[VALIDFROMDAT] [date] NULL,
	[VALIDTODAT] [date] NULL,
	[BusinessTypeCode] [int] NULL,
	[INSERTTYPE] [int] NULL,
	[ModifiedOn] [datetime2](7) NULL,
	[NatArticle_BK] [nvarchar](50) NULL,
	[PDUCode] [varchar](15) NULL,
	[IntPupMasterId] [varchar](15) NULL,
	[ArticleNumber_BK] [nvarchar](15) NULL,
	[ArticleSize_BK] [nvarchar](50) NULL,
	[BrandCode] [nvarchar](4) NULL,
	[RBUCode] [int] NULL,
	[ProdDivCode] [int] NULL,
	[StyleNumber_BK] [int] NULL,
	[IntAgeingCode] [int] NULL,
	[IntInventoryStatusCode] [int] NULL,
	[IntInventoryTypeCode] [int] NULL,
	[SPECIALSTOCKINDICATOR] [nvarchar](1) NULL,
	[LDTS] [datetime2](7) NULL,
	isdeleted bit
)
WITH
(
	DISTRIBUTION = HASH(AggInventoryTypes_HASH),
	CLUSTERED COLUMNSTORE INDEX
)

;WITH CTE AS (
SELECT	CONVERT([BINARY](16),
			HASHBYTES('MD5',
				CONCAT(		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.Plant)))), '_',
							UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.Material)))), '_',
							UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.InventoryStatusType))))
							))) AS HASH_BK
		,CONVERT([BINARY](16),
			HASHBYTES('MD5',
				CONCAT(	UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.Plant)))), '_',
							UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.Material)))), '_',
							UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.StockSegment)))), '_',
							UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.InventoryStatusType)))), '_',
							UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.PostingDate))))
							))) AS AggInventoryMovements_HASH
		,NULL AS AggInventoryValuations_HASH
		,CONVERT([BINARY](16),
			HASHBYTES('MD5',
				CONCAT(	UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.Plant)))), '_',
							UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.Material)))), '_',
							UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.StockSegment)))), '_', 
							UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.InventoryStatusType))))
							))) AS AggInventoryTypes_HASH
		,NULL AS HASH_Diff
		,CONVERT(NVARCHAR(20),	CASE	WHEN SHVP.PlantCategoryCode='A' THEN CONCAT(FASH.Plant, '|', SHI.RegionCode)
												WHEN FASH.StockSegment='' THEN CONCAT(FASH.Plant, '|', SHI.RegionCode)
												ELSE CONCAT(FASH.Plant, '_', FASH.StockSegment,'|', SHI.RegionCode)
										END) AS NatStoreDC_BK
		,SHI.CompanyCode AS COMPANYCODE
		,FASH.Plant AS PLANT
		,FASH.Material AS MATERIAL
		,'0001' AS STORAGELOCATION
		,FASH.StockSegment AS STOCKSEGMENT
		,'UNRESTRICTEDSTOCK' AS QTYTYPE
		,FASH.BaseUnitOfMeasure AS MATERIALBASEUNIT
		,FASH.QTY
		,CASE	WHEN ISNULL(SHAMSP.PriceControlIndicator, SHAMSPH.PriceControlIndicator)='V'
				THEN ISNULL(SHAMSP.MovingAveragePrice, SHAMSPH.MovingAveragePrice)
				ELSE ISNULL(SHAMSP.StandardPrice, SHAMSPH.StandardPrice)
		END AS PRICE
		,CASE	WHEN ISNULL(SHAMSP.PriceControlIndicator, SHAMSPH.PriceControlIndicator)='V'
				THEN ISNULL(SHAMSP.MovingAveragePrice, SHAMSPH.MovingAveragePrice)
				ELSE ISNULL(SHAMSP.StandardPrice, SHAMSPH.StandardPrice)
		END * FASH.QTY AS GROSS
		,ISNULL(SHAMSP.PriceCurrency, SHAMSPH.PriceCurrency) AS PRICECURRENCY
		,ISNULL(SHAMSP.VALIDFROMDAT, SHAMSPH.ValidFromDat) AS VALIDFROMDAT
		,ISNULL(SHAMSP.VALIDTODAT, SHAMSPH.ValidToDat) AS VALIDTODAT
		,FASH.PostingDate AS POSTINGDATE
		,FASH.ConfirmedDateATP AS ConfirmedDateATP
		,FASH.SequentialNumber as BatchID
		,1 AS BusinessTypeCode
		,-1 AS INSERTTYPE
		,GETDATE() AS ModifiedOn
		,CONCAT(FASH.Material,'|', CASE WHEN SHI.CompanyCode='PT10' THEN 'ES10' ELSE SHI.CompanyCode END) AS NatArticle_BK
		,SHI.PDUCode
		,SHI.IntPupMasterId
		,CONCAT(LTRIM(RTRIM(SHVM.StyleNo)), ' ', LTRIM(RTRIM(SHVM.ColorNo))) AS ArticleNumber_BK
		,CONCAT(LTRIM(RTRIM(SHVM.StyleNo)), ' ', LTRIM(RTRIM(SHVM.ColorNo)), ' ', LTRIM(RTRIM(ISNULL(SHVM.SizeNumber, '0')))) AS ArticleSize_BK
		,SHVM.BrandCode
		,ISNULL(TRY_CONVERT(INT, SHVM.RBUCode), 0) AS RBUCode
		,CONVERT(INT, CASE WHEN SHVM.RetailDCSDepCode IN ('31', '32', '33', '34') AND SHVM.ProdDivCode = '2' THEN '3' ELSE SHVM.ProdDivCode END) AS ProdDivCode
		,CONVERT(INT, ISNULL(TRY_CONVERT(INT, SHVM.StyleNo), 0)) AS StyleNumber_BK
		,50 AS IntAgeingCode
		,FASH.InventoryStatusType AS IntInventoryStatusCode
		,CASE WHEN SHVP.PlantCategoryCode='B' THEN 30 ELSE 40 END AS IntInventoryTypeCode
		,'' AS SPECIALSTOCKINDICATOR
		,FASH.LDTS
FROM (
            SELECT		 
						SHFAS.Plant
						,SHFAS.Material
						,CASE WHEN SHFAS.StockSegment='' THEN SHFAS.RequirementSegment ELSE SHFAS.StockSegment END StockSegment
						,SHFAS.MRPElement
						,SHFAS.ConfirmedDateATP
						,SHFAS.SequentialNumber
						,CONVERT(DECIMAL(15,3), SHFAS.quantity) AS QTY
						,SHFAS.BaseUnitOfMeasure
						,DATEADD(DAY, -1, CONVERT(DATE, DATEADD(s, __timestamp / 1000000, CONVERT(DATETIME, '1-1-1970 00:00:00')))) AS PostingDate
						,CASE WHEN MRPElement = 'LA' THEN '-10' ELSE '-20' END InventoryStatusType
						,_LDTS as LDTS
			FROM stag.S4Hana_vFreeAvailableStock AS SHFAS
			WHERE isDeleted = 0 AND MRPElement in ('BE','LA')
	) AS FASH
	LEFT JOIN biz.S4Hana_AggMaterialStockPricesHistory AS SHAMSPH ON	SHAMSPH.Material = FASH.Material
																	   AND SHAMSPH.Plant = FASH.Plant
																	   AND SHAMSPH.ValidToDat = '9999-12-31'
	LEFT JOIN biz.S4Hana_AggMaterialStockPrices AS SHAMSP ON        	SHAMSP.Material = FASH.Material
															           AND SHAMSP.Plant = FASH.Plant
															           AND SHAMSP.ValidToDat = '9999-12-31'

	LEFT JOIN stag.S4Hana_vMaterials AS SHVM ON SHVM.MaterialNumber=FASH.Material
	JOIN stag.S4Hana_vPlants AS SHVP ON SHVP.StoreCode=FASH.Plant
	JOIN pdwref.S4Hana_Interfaces AS SHI ON SHI.SalesOrg=SHVP.SalesOrganizationCode AND SHI.Interface='EBP'
	where 1=1
)
INSERT INTO #AvailableToPromiseLast
(HASH_BK,
 AggInventoryMovements_HASH,
 AggInventoryValuations_HASH,
 AggInventoryTypes_HASH,
 HASH_Diff,
 POSTINGDATE,
 ConfirmedDateATP,
 BatchID,
 NatStoreDC_BK,
 COMPANYCODE,
 PLANT,
 MATERIAL,
 STORAGELOCATION,
 STOCKSEGMENT,
 QTYTYPE,
 MATERIALBASEUNIT,
 QTY,
 PRICE,
 GROSS,
 PRICECURRENCY,
 VALIDFROMDAT,
 VALIDTODAT,
 BusinessTypeCode,
 INSERTTYPE,
 ModifiedOn,
 NatArticle_BK,
 PDUCode,
 IntPupMasterId,
 ArticleNumber_BK,
 ArticleSize_BK,
 BrandCode,
 RBUCode,
 ProdDivCode,
 StyleNumber_BK,
 IntAgeingCode,
 IntInventoryStatusCode,
 IntInventoryTypeCode,
 SPECIALSTOCKINDICATOR,
 LDTS,
 IsDeleted)
	SELECT 
	HASH_BK,
	AggInventoryMovements_HASH,
	AggInventoryValuations_HASH,
	AggInventoryTypes_HASH,
	NULL as HASH_Diff,
	POSTINGDATE,
	ConfirmedDateATP,
	BatchID,
	NatStoreDC_BK,
	COMPANYCODE,
	PLANT,
	MATERIAL,
	STORAGELOCATION,
	STOCKSEGMENT,
	QTYTYPE,
	MATERIALBASEUNIT,
	QTY,
	PRICE,
	GROSS,
	PRICECURRENCY,
	VALIDFROMDAT,
	VALIDTODAT,
	BusinessTypeCode,
	INSERTTYPE,
	ModifiedOn,
	NatArticle_BK,
	PDUCode,
	IntPupMasterId,
	ArticleNumber_BK,
	ArticleSize_BK,
	BrandCode,
	RBUCode,
	ProdDivCode,
	StyleNumber_BK,
	IntAgeingCode,
	IntInventoryStatusCode,
	IntInventoryTypeCode,
	SPECIALSTOCKINDICATOR,
	LDTS,
	0 as IsDeleted
	FROM CTE

	--truncate table
	truncate table [sourcing].[AvailableToPromiseCurrent]

	--insert into table
	INSERT INTO [sourcing].[AvailableToPromiseCurrent]
	   (	HASH_BK
		   ,AggInventoryMovements_HASH
		   ,AggInventoryValuations_HASH
		   ,AggInventoryTypes_HASH
		   ,HASH_Diff
		   ,POSTINGDATE
		   ,ConfirmedDateATP
		   ,BatchID
		   ,NatStoreDC_BK
		   ,COMPANYCODE
		   ,PLANT
		   ,MATERIAL
		   ,STORAGELOCATION
		   ,STOCKSEGMENT
		   ,QTYTYPE
		   ,MATERIALBASEUNIT
		   ,QTY
		   ,PRICE
		   ,GROSS
		   ,PRICECURRENCY
		   ,VALIDFROMDAT
		   ,VALIDTODAT
		   ,BusinessTypeCode
		   ,INSERTTYPE
		   ,ModifiedOn
		   ,NatArticle_BK
		   ,PDUCode
		   ,IntPupMasterId
		   ,ArticleNumber_BK
		   ,ArticleSize_BK
		   ,BrandCode
		   ,RBUCode
		   ,ProdDivCode
		   ,StyleNumber_BK
		   ,IntAgeingCode
		   ,IntInventoryStatusCode
		   ,IntInventoryTypeCode
		   ,SPECIALSTOCKINDICATOR
		   ,LDTS
		   ,IsDeleted)
SELECT      a.HASH_BK
		   ,a.AggInventoryMovements_HASH
		   ,a.AggInventoryValuations_HASH
		   ,a.AggInventoryTypes_HASH
		   ,a.HASH_Diff
		   ,a.POSTINGDATE
		   ,a.ConfirmedDateATP
		   ,a.BatchID
		   ,a.NatStoreDC_BK
		   ,a.COMPANYCODE
		   ,a.PLANT
		   ,a.MATERIAL
		   ,a.STORAGELOCATION
		   ,a.STOCKSEGMENT
		   ,a.QTYTYPE
		   ,a.MATERIALBASEUNIT
		   ,a.QTY
		   ,a.PRICE
		   ,a.GROSS
		   ,a.PRICECURRENCY
		   ,a.VALIDFROMDAT
		   ,a.VALIDTODAT
		   ,a.BusinessTypeCode
		   ,a.INSERTTYPE
		   ,a.ModifiedOn
		   ,a.NatArticle_BK
		   ,a.PDUCode
		   ,a.IntPupMasterId
		   ,a.ArticleNumber_BK
		   ,a.ArticleSize_BK
		   ,a.BrandCode
		   ,a.RBUCode
		   ,a.ProdDivCode
		   ,a.StyleNumber_BK
		   ,a.IntAgeingCode
		   ,a.IntInventoryStatusCode
		   ,a.IntInventoryTypeCode
		   ,a.SPECIALSTOCKINDICATOR
		   ,a.LDTS
		   ,a.IsDeleted
	from #AvailableToPromiseLast a	

	--exec [dbo].[S4Hana_spProvAvailableToPromiseCurrent] '19000101'
	
	END