﻿CREATE PROC [dbo].[S4Hana_spProvNatPurchaseOrdersCurrentAccumulated] @LDTS [DATETIME2](7) AS
BEGIN
    DECLARE   @CurrentTimestamp DATETIME = GETDATE()
            , @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
            , @InsertedRows BIGINT = 0
            , @UpdatedRows BIGINT = 0

    --Log data load begin 
    INSERT INTO etl.DataTransferLogs
    (
        DataTransferLogId
      , TransferName
      , TransferGroupName
      , TargetTableName
      , TargetSchemaName
      , ExecStart
      , BatchLdts
    )
    SELECT
        @DataTransferLogId
      , 'spProvNatPurchaseOrdersCurrentAccumulated'
      , 'NatPurchaseOrders'
      , 'NatPurchaseOrdersCurrentAccumulated'
      , 'sourcing'
      , @CurrentTimestamp
      , @LDTS


    IF OBJECT_ID('tempdb..#ChangedPOs') IS NOT NULL DROP TABLE #ChangedPOs

    CREATE TABLE #ChangedPOs
    WITH
    (
      DISTRIBUTION = HASH(PONo)
    , CLUSTERED INDEX (PONo ASC)
    )
	AS
    SELECT
        chpos.PONo
    FROM
        (
            SELECT DISTINCT
                   pod.PONo
            FROM   stag.S4Hana_vPODocuments pod
            WHERE  pod.LDTS >= @LDTS
            UNION
            SELECT DISTINCT
                   podi.PONo
            FROM   biz.S4Hana_PODocumentItems podi
            WHERE  podi.LDTS >= @LDTS
            UNION
            SELECT DISTINCT
                   posl.PONo
            FROM   biz.S4Hana_POScheduleLines posl
            WHERE  posl.LDTS >= @LDTS
            UNION
            SELECT DISTINCT
                   aggpopc.PONo
            FROM   biz.S4Hana_AggPOPricingConditions aggpopc
            WHERE  aggpopc.LDTS >= @LDTS
            UNION
            SELECT DISTINCT
                   poa.PONo
            FROM   stag.S4Hana_vPOAssignments poa
            WHERE  poa.LDTS >= @LDTS
            UNION
            SELECT DISTINCT
                   poc.PONo
            FROM   stag.S4Hana_vPOConfirmations poc
            WHERE  poc.LDTS >= @LDTS
			UNION
			SELECT DISTINCT
                   podi.PONo
            FROM   biz.S4Hana_PODocumentItems       podi
			JOIN   biz.S4Hana_DeliveryDocumentItems deli ON podi.PONo = deli.ReferenceDocumentNo AND podi.POItemNo = right(deli.ReferenceDocumentItemNo,5)
			JOIN   biz.S4Hana_DeliveryDocuments	  delh ON delh.DeliveryNoteNumber = deli.DeliveryNoteNumber 
            WHERE  deli.LDTS >= @LDTS
					or delh.LDTS >= @LDTS

        ) chpos
    OPTION (LABEL = 'dbo.S4Hana_spProvNatPurchaseOrdersCurrentAccumulated: DeltaTempTableChangedPOsStatement')

    IF OBJECT_ID('tempdb..#SLDN') IS NOT NULL DROP TABLE #SLDN

	CREATE TABLE #SLDN
	WITH
    (
      DISTRIBUTION = HASH(PONo)
    , CLUSTERED INDEX (PONo ASC, POItemNo ASC)
    )
	AS
	SELECT
                 chpos.PONo
               , podi.POItemNo
               , MAX(CASE WHEN posl.IsDeleted = 1 THEN NULL ELSE posl.DeliveryDate END) AS PO_DeliveryDate
               , SUM(CASE WHEN posl.IsDeleted = 1 THEN 0 ELSE posl.RoughGoodsReceiptQuantity END) AS RoughGoodsReceiptQuantity
			   , MAX(delh.ActualGoodsMovementDate) AS ActualGoodsMovementDate
               , MAX(delh.DeliveryDate) as IBD_DeliveryDate

            FROM     #ChangedPOs                chpos
            JOIN     biz.S4Hana_PODocumentItems podi ON chpos.PONo = podi.PONo
            LEFT JOIN     biz.S4Hana_POScheduleLines posl ON podi.PONo = posl.PONo AND podi.POItemNo = posl.POItemNo
			LEFT JOIN     biz.S4Hana_DeliveryDocumentItems deli ON podi.PONo = deli.ReferenceDocumentNo AND podi.POItemNo = right(deli.ReferenceDocumentItemNo,5) AND deli.StockSegment <> ''
		    LEFT JOIN     biz.S4Hana_DeliveryDocuments	  delh ON delh.DeliveryNoteNumber = deli.DeliveryNoteNumber 
            GROUP BY chpos.PONo, podi.POItemNo



    IF OBJECT_ID('tempdb..#DeliveryDocuments') IS NOT NULL DROP TABLE #DeliveryDocuments 

    CREATE TABLE #DeliveryDocuments
    WITH
    (
      DISTRIBUTION = HASH(PONo)
    , CLUSTERED INDEX (PONo ASC, POItemNo ASC)
    )
	AS
	SELECT     podi.PONo
			  ,podi.POItemNo
			  ,(SELECT STRING_AGG(DeliveryDocument,',') WITHIN GROUP (ORDER BY DeliveryDocument)
              FROM 
                          (SELECT DISTINCT value AS DeliveryDocument
					FROM STRING_SPLIT(STRING_AGG(DeliveryDocument, ',') ,',')
					) t  )   AS IBD_DeliveryDocuments
						from [stag].[S4Hana_vPOConfirmations] poc 
							inner join  #ChangedPOs cpo on cpo.PONo = poc.PONo
							inner join biz.S4Hana_PODocumentItems podi  on podi.PONo = poc.PONo and podi.POItemNo = poc.POItemNo and podi.[StockSegment] = poc.[StockSegment]
						group by  podi.PONo,podi.POItemNo


    IF OBJECT_ID('tempdb..#ChangedPOsFiltered') IS NOT NULL
    DROP TABLE #ChangedPOsFiltered

    CREATE TABLE #ChangedPOsFiltered
    WITH
    (
      DISTRIBUTION = HASH(PONo)
    , CLUSTERED INDEX (PONo ASC, POItemNo ASC, IntPupMasterId ASC)
    )
	AS
	SELECT
         pod.PONo
       , podi.POItemNo
       , pod.DeletionCode  AS pod_DeletionCode
       , pod.CurrencyCode
       , pod.CreationDate
       , pod.SiteCode_SupplyingSupplier
       , pod.RetailSellingSeason
       , pod.CompanyCode
       , SHVP.SalesOrganizationCode as SalesOrganization
       , pod.IsDeleted     AS pod_IsDeleted
       , podi.DeletionCode AS podi_DeletionCode
       , podi.IsCompletelyDelivered
       , podi.MaterialNumber
       , podi.FactoryCode
       , podi.SiteCode
       , podi.RequestedDeliveryDate
       , podi.OrderQuantity
       , podi.NetAmount
       , podi.PlannedDeliveryDate
       , podi.LastConfirmedDeliveryDate
       , podi.ExpectedHandoverDate
       , podi.ActualHandoverDate
       , podi.CountryOfOrigin
       , podi.ShippingInstructionCode
	   , podi.StorageLocation
	   , podi.StockSegment
	   , podi.ISSSTORLOCSTO as IssuingStorageLocation
	   , podi.LegacyPONumber
	   , podi.LegacyPOItemNumber
	   , pod.CreatedByUser	AS RequisitionerName
       , podi.IsDeleted    AS podi_IsDeleted   
       , pot.IntPOTypeCode AS IntPOTypeCode	   
	   , pot.MappingDesc AS	  IntPOTypeDesc	   
	   , pot.EBPIndicator AS  NatPOTypeCode	   
	   , pot.EBPDesc AS       NatPOTypeDesc
	   , pod.SupplierCode
	   , pod.POSubType
       , i.IntPupMasterId
       , i.PDUCode
       , i.SourcingCustomerCode
       , i.RegionCode
	   , sldn.IBD_DeliveryDate 
	   , sldn.ActualGoodsMovementDate
	   , sldn.PO_DeliveryDate
	   , sldn.RoughGoodsReceiptQuantity
	   , poc.IBD_DeliveryDocuments as IBD_DeliveryDocument
    FROM #ChangedPOs                      chpos
    JOIN stag.S4Hana_vPODocuments         pod  ON chpos.PONo = pod.PONo
    JOIN biz.S4Hana_PODocumentItems       podi ON pod.PONo = podi.PONo
	LEFT JOIN #DeliveryDocuments poc on chpos.PONo = poc.PONo and podi.POItemNo = poc.POItemNo 
	LEFT JOIN #SLDN sldn on chpos.PONo = sldn.PONo and podi.POItemNo = sldn.POItemNo 
    JOIN pdwref.S4Hana_PurchaseOrderTypes pot  ON pod.POTypeCode = pot.EBPIndicator
	JOIN stag.S4Hana_vPlants		      SHVP ON SHVP.StoreCode = podi.SiteCode
	JOIN pdwref.S4Hana_Interfaces         i    ON i.SalesOrg = SHVP.SalesOrganizationCode AND i.Interface='EBP'
	--LEFT JOIN biz.S4Hana_DeliveryDocumentItems deli ON podi.PONo = deli.ReferenceDocumentNo AND podi.POItemNo = right(deli.ReferenceDocumentItemNo,5)
	--LEFT JOIN biz.S4Hana_DeliveryDocuments	  delh ON delh.DeliveryNoteNumber = deli.DeliveryNoteNumber 
	--LEFT JOIN [stag].[S4Hana_vPOConfirmations] poc on chpos.PONo = poc.PONo

    OPTION (LABEL = 'dbo.S4Hana_spProvNatPurchaseOrdersCurrentAccumulated: DeltaTempTableChangedPOsFilteredStatement')


    IF OBJECT_ID('tempdb..#preResult') IS NOT NULL DROP TABLE #preResult
	
    CREATE TABLE #preResult
    WITH
    (
      DISTRIBUTION = HASH(NatPurchaseOrderNo)
    , CLUSTERED INDEX (NatPurchaseOrderNo ASC, NatPurchaseOrderItemNo ASC, IntPupMasterId)
    )
	AS
	SELECT
                      CAST(CONCAT(TRIM(chposf.PONo), TRIM(chposf.POItemNo)) AS BIGINT)                              AS NatPurchaseOrder_BK
                    , chposf.PONo                                                                                   AS NatPurchaseOrderNo
                    , chposf.POItemNo                                                                               AS NatPurchaseOrderItemNo
                    , chposf.CompanyCode                                                                            AS CompanyCode
                    , chposf.IntPupMasterId                                                                         AS IntPupMasterId
                    , chposf.PDUCode                                                                                AS PDUCode
                    , CAST(CASE
                               WHEN chposf.pod_DeletionCode <> '' OR chposf.podi_DeletionCode <> ''
                                   THEN 3 /*Cancelled*/
                               ELSE CASE
                                        WHEN chposf.IsCompletelyDelivered = 'X'
                                            THEN 1 /*Finished Status*/
                                        WHEN chposf.IsCompletelyDelivered = '' AND chposf.RoughGoodsReceiptQuantity = 0
                                            THEN 2 /*Open Status*/
										WHEN chposf.IsCompletelyDelivered = '' AND chposf.RoughGoodsReceiptQuantity > 0	
											THEN 4 /*Partially Received*/
                                    END
                           END AS INT)                                                                              AS POStatusCode
                    , CONCAT(TRIM(mat.StyleNo), ' ', TRIM(mat.ColorNo))                                             AS ArticleNumber_BK
                    , ISNULL(chposf.IntPOTypeCode, 0)                                                               AS IntPOTypeCode
					, ISNULL(IntPOTypeDesc, '')																		AS IntPOTypeDesc
					, ISNULL(NatPOTypeCode, '')																		AS NatPOTypeCode
					, ISNULL(NatPOTypeDesc, '')																		AS NatPOTypeDesc
					, ISNULL(SupplierCode ,'')																		AS SupplierCode
                    , ISNULL(POSubType , '')																		AS POSubType
					, CAST(CONVERT(VARCHAR, chposf.CreationDate, 112) AS INT)                                       AS POCreationDate
                    , CAST(CONVERT(VARCHAR, chposf.RequestedDeliveryDate, 112) AS INT)                              AS RequestedDeliveryDate
                    , CAST(CONVERT(VARCHAR, chposf.LastConfirmedDeliveryDate, 112) AS INT)                          AS LastConfirmedDeliveryDate
                    , chposf.CurrencyCode                                                                           AS CurrencyCode
                    , CONCAT(TRIM(mat.StyleNo), ' ', TRIM(mat.ColorNo), ' ', 
                                TRIM(ISNULL(mat.SizeNumber, '0')))                                                  AS ArticleSize_BK
                    , CONCAT(TRIM(chposf.SiteCode), '|', TRIM(chposf.CompanyCode))                                   AS NatDC_BK
                    , chposf.OrderQuantity                                                                          AS Qty
					, chposf.StorageLocation                                                                        AS StorageLocation
                    , ISNULL(apopc.ZSFP, 0) + ISNULL(apopc.ZSRD, 0) + ISNULL(apopc.ZSSM, 0) + ISNULL(apopc.ZSSC, 0)
                      + ISNULL(apopc.ZSWC, 0)                                                                       AS NetValueLC           /*ZSFP (F-Price) + ZSRD (R+D Surcharge) + ZSSM (Sales Mark-up) + ZSSC (SourceCo Fee %) + ZSWC (WorldCat Fee%)*/
                    , ISNULL(   CASE
                                    WHEN chposf.FactoryCode = ''
                                        THEN NULL
                                    ELSE chposf.FactoryCode
                                END
                              , '0'
                            )                                                                                       AS FactoryCode
                    , CASE
                          WHEN chposf.CompanyCode = 'DE11'
                              THEN '2'
                          ELSE '1'
                      END                                                                                           AS BusTypeCode          /*check if StockSegment would work*/ /*Contains IntBusTypeCode: 1 = Wholessales, 2 = Retail*/ /*Works only until Area with WS and RET business integrated*/
                    , chposf.SourcingCustomerCode                                                                   AS SourcingCustomerCode /*SourceCo CustomerCode*/
                    , poa.SalesOrderNo                                                                              AS NatSalesOrderNo
                    , CASE
                          WHEN chposf.SiteCode_SupplyingSupplier = 'DE16000'
                              THEN 1
                          ELSE 2
                      END                                                                                           AS PurchasingSystem     /*1 = SourceCo, 2 = local sourcing, 3 = Intercompany sourcing*/ /*Intercompany: Non-S4-Sub orders from S4-Sub: No STO*/
                    , poa.SalesOrderItemNo                                                                          AS NatSalesOrderItemNo
                    , poa.SalesOrderScheduleLine                                                                    AS NatSalesOrderItemScheduleLineNo
                    , chposf.NetAmount                                                                              AS NatLandedCostLC
                    , CAST(CASE
                               WHEN chposf.pod_IsDeleted = 1
                                   THEN 0
                               WHEN chposf.podi_IsDeleted = 1
                                   THEN 0
                               ELSE 1
                           END AS BIT)                                                                              AS Active
                    , CONCAT(TRIM(chposf.MaterialNumber), '|', 
                            CASE
                                WHEN TRIM(chposf.CompanyCode) = 'PT10'
                                    THEN 'ES10'
                                ELSE TRIM(chposf.CompanyCode)
                            END)                                                                                    AS NatArticle_BK
                    , ISNULL(TRY_CAST(mat.ProdDivCode AS INT), 0)                                                   AS ProdDivCode
                    , ISNULL(TRY_CAST(mat.RBUCode AS INT), 0)                                                       AS RBUCode
                    , ISNULL(mat.BrandCode, '0')                                                                    AS BrandCode
                    , CONCAT(TRIM(chposf.SiteCode), '|', TRIM(chposf.CompanyCode))                                   AS NatStoreDC_BK
                    , ISNULL(TRY_CAST(mat.StyleNo AS INT), 0)                                                       AS StyleNumber_BK
                    , CAST(CONVERT(VARCHAR, chposf.PlannedDeliveryDate, 112) AS INT)                                AS PlannedDeliveryDate
                    , CAST(CONVERT(VARCHAR, chposf.ExpectedHandoverDate, 112) AS INT)                               AS ExpectedHandoverDate
                    , CAST(CONVERT(VARCHAR, chposf.ActualHandoverDate, 112) AS INT)                                 AS ActualHandoverDate
                    , CAST(CONVERT(VARCHAR, chposf.LastConfirmedDeliveryDate, 112) AS INT)                          AS LastConfirmedHandoverDate
                    , ISNULL(chposf.CountryOfOrigin, '0')                                                           AS CountryOriginCode
                    , chposf.ShippingInstructionCode                                                                AS ShippingInstruction
                    , CASE
                          WHEN chposf.RetailSellingSeason = ''
                              THEN 190011
                          ELSE ISNULL(TRY_CAST(chposf.RetailSellingSeason AS INT), 190011)
                      END                                                                                           AS PlannedRetailSellingSeason
                    , chposf.StockSegment                                                                           AS StockSegment
					, chposf.IssuingStorageLocation																	AS IssuingStorageLocation
                    , chposf.RoughGoodsReceiptQuantity                                                              AS RoughGoodsReceiptQty
					, chposf.LegacyPONumber																			AS LegacyPONumber
					, chposf.LegacyPOItemNumber																		AS LegacyPOItemNumber
					, chposf.RequisitionerName																		AS RequisitionerName
                    , ISNULL(apopc.ZSRD, 0) + ISNULL(apopc.ZSSM, 0) + ISNULL(apopc.ZSSC, 0) + ISNULL(apopc.ZSWC, 0) AS InterCompanyCosts    /*ZSRD (R+D Surcharge) + ZSSM (Sales Mark-up) + ZSSC (SourceCo Fee %) + ZSWC (WorldCat Fee%)*/
                    , CAST(NULL AS DECIMAL(14, 2))                                                                  AS RRP                  /*integrated for PEG from ArticleMaster, needs to be added when new Pricing tables are available in CDW*/
                    , apopc.[GRWR]
                    , apopc.[NAVS]
                    , apopc.[P101]
                    , apopc.[PB00]
                    , apopc.[PBXX]
                    , apopc.[SKTO]
                    , apopc.[WOTB]
                    , apopc.[ZDIS]
                    , apopc.[ZDVG]
                    , apopc.[ZFR1]
                    , apopc.[ZIDU]
                    , apopc.[ZIF%]
                    , apopc.[ZIFV]
                    , apopc.[ZIHF]
                    , apopc.[ZIIN]
                    , apopc.[ZINC]
                    , apopc.[ZINM]
                    , apopc.[ZIUP]
                    , apopc.[ZMAN]
                    , apopc.[ZNF%]
                    , apopc.[ZPB0]
                    , apopc.[ZPBX]
                    , apopc.[ZSD1]
                    , apopc.[ZSD2]
                    , apopc.[ZSFP]
                    , apopc.[ZSH1]
                    , apopc.[ZSL1]
                    , apopc.[ZSL2]
                    , apopc.[ZSL3]
                    , apopc.[ZSM1]
                    , apopc.[ZSMS]
                    , apopc.[ZSO1]
                    , apopc.[ZSO2]
                    , apopc.[ZSOC]
                    , apopc.[ZSP1]
                    , apopc.[ZSP4]
                    , apopc.[ZSQ1]
                    , apopc.[ZSQ2]
                    , apopc.[ZSR1]
                    , apopc.[ZSRD]
                    , apopc.[ZSSC]
                    , apopc.[ZSSM]
                    , apopc.[ZSV1]
                    , apopc.[ZSV2]
                    , apopc.[ZSWC]
                    , apopc.[ZVAT]
					, CAST(CONVERT(VARCHAR, chposf.IBD_DeliveryDate, 112) AS INT)  AS IBD_DeliveryDate
					, CASE WHEN chposf.IsCompletelyDelivered = 'X' THEN CAST(CONVERT(VARCHAR, chposf.ActualGoodsMovementDate, 112) AS INT) END AS ActualGoodsMovementDate
                    , CAST(CONVERT(VARCHAR, chposf.PO_DeliveryDate, 112) AS INT) AS PO_DeliveryDate
					, chposf.IBD_DeliveryDocument
					, CASE WHEN chposf.IsCompletelyDelivered = 'X' --Delivered part
						   THEN CASE WHEN chposf.ActualGoodsMovementDate is not null THEN CAST(CONVERT(VARCHAR, chposf.ActualGoodsMovementDate, 112) AS INT)
									 WHEN chposf.IBD_DeliveryDate is not null THEN CAST(CONVERT(VARCHAR, chposf.IBD_DeliveryDate, 112) AS INT)
									 ELSE CAST(CONVERT(VARCHAR, chposf.PO_DeliveryDate, 112) AS INT) END
						   WHEN chposf.IsCompletelyDelivered = '' --Open Part
						   THEN	CASE WHEN chposf.IBD_DeliveryDate is not null THEN CAST(CONVERT(VARCHAR, chposf.IBD_DeliveryDate, 112) AS INT)
									 ELSE CAST(CONVERT(VARCHAR, chposf.PO_DeliveryDate, 112) AS INT) END
						   END AS DeliveryDate

            FROM      #ChangedPOsFiltered               chposf
            JOIN      stag.S4Hana_vMaterials            mat ON chposf.MaterialNumber = mat.MaterialNumber
            LEFT JOIN biz.S4Hana_AggPOPricingConditions apopc ON chposf.PONo = apopc.PONo
                                                                 AND chposf.POItemNo = apopc.POItemNo
                                                                 AND chposf.IntPupMasterId = apopc.IntPupMasterId
            LEFT JOIN stag.S4Hana_vPOAssignments        poa ON chposf.PONo = poa.PONo AND chposf.POItemNo = poa.POItemNo
                                                               AND poa.AccountAssignmentNumber = '01'
                                                               AND poa.SalesOrderItemNo <> ''
            WHERE     mat.MaterialCategoryCode <> '01'


    IF OBJECT_ID('tempdb..#Result') IS NOT NULL DROP TABLE #Result;
	
    CREATE TABLE #Result
    WITH
    (
      DISTRIBUTION = HASH(NatPurchaseOrderNo)
    , CLUSTERED INDEX (NatPurchaseOrderNo ASC, NatPurchaseOrderItemNo ASC, IntPupMasterId)
    )
	AS
    
    SELECT
        X.NatPurchaseOrder_BK
      , X.NatPurchaseOrderNo
      , X.NatPurchaseOrderItemNo
      , X.CompanyCode
      , X.IntPupMasterId
      , X.PDUCode
      , X.POStatusCode
      , X.ArticleNumber_BK
      , X.IntPOTypeCode
	  , X.IntPOTypeDesc
	  , X.NatPOTypeCode
	  , X.NatPOTypeDesc
	  , X.SupplierCode
	  , X.StorageLocation
	  , X.POSubType
      , X.POCreationDate
      , X.RequestedDeliveryDate
      , X.LastConfirmedDeliveryDate
      , X.CurrencyCode
      , X.ArticleSize_BK
      , X.NatDC_BK
      , X.Qty
      , X.NetValueLC
      , X.FactoryCode
      , X.BusTypeCode
      , X.SourcingCustomerCode
      , X.NatSalesOrderNo
      , X.PurchasingSystem
      , X.NatSalesOrderItemNo
      , X.NatSalesOrderItemScheduleLineNo
      , X.NatLandedCostLC
      , X.Active
      , X.NatArticle_BK
      , X.ProdDivCode
      , X.RBUCode
      , X.BrandCode
      , X.NatStoreDC_BK
      , X.StyleNumber_BK
      , X.PlannedDeliveryDate
      , X.ExpectedHandoverDate
      , X.ActualHandoverDate
      , X.LastConfirmedHandoverDate
      , X.CountryOriginCode
      , X.ShippingInstruction
      , X.PlannedRetailSellingSeason
      , X.StockSegment
	  , x.IssuingStorageLocation
      , X.RoughGoodsReceiptQty
      , X.LegacyPONumber
      , X.LegacyPOItemNumber
      , X.RequisitionerName
      , X.InterCompanyCosts
      , X.RRP
      , X.[GRWR]
      , X.[NAVS]
      , X.[P101]
      , X.[PB00]
      , X.[PBXX]
      , X.[SKTO]
      , X.[WOTB]
      , X.[ZDIS]
      , X.[ZDVG]
      , X.[ZFR1]
      , X.[ZIDU]
      , X.[ZIF%]
      , X.[ZIFV]
      , X.[ZIHF]
      , X.[ZIIN]
      , X.[ZINC]
      , X.[ZINM]
      , X.[ZIUP]
      , X.[ZMAN]
      , X.[ZNF%]
      , X.[ZPB0]
      , X.[ZPBX]
      , X.[ZSD1]
      , X.[ZSD2]
      , X.[ZSFP]
      , X.[ZSH1]
      , X.[ZSL1]
      , X.[ZSL2]
      , X.[ZSL3]
      , X.[ZSM1]
      , X.[ZSMS]
      , X.[ZSO1]
      , X.[ZSO2]
      , X.[ZSOC]
      , X.[ZSP1]
      , X.[ZSP4]
      , X.[ZSQ1]
      , X.[ZSQ2]
      , X.[ZSR1]
      , X.[ZSRD]
      , X.[ZSSC]
      , X.[ZSSM]
      , X.[ZSV1]
      , X.[ZSV2]
      , X.[ZSWC]
      , X.[ZVAT]
	  , X.IBD_DeliveryDate
	  , X.PO_DeliveryDate
	  , X.ActualGoodsMovementDate
	  , X.IBD_DeliveryDocument
	  , X.DeliveryDate
	  , CONVERT([BINARY](16),
			HASHBYTES('MD5',CONCAT(
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.NatPurchaseOrder_BK)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.NatPurchaseOrderNo)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.NatPurchaseOrderItemNo)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.CompanyCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.IntPupMasterId)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.PDUCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.POStatusCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.ArticleNumber_BK)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.IntPOTypeCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.IntPOTypeDesc)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.NatPOTypeCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.NatPOTypeDesc)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.SupplierCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.POSubType)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.POCreationDate)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.RequestedDeliveryDate)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.LastConfirmedDeliveryDate)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.CurrencyCode)))),'_',		
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.ArticleSize_BK)))),'_',			
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.NatDC_BK)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.Qty)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.NetValueLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.FactoryCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.BusTypeCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.SourcingCustomerCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.NatSalesOrderNo)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.PurchasingSystem)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.NatSalesOrderItemNo)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.NatSalesOrderItemScheduleLineNo)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.NatLandedCostLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.Active)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.NatArticle_BK)))),'_',		
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.ProdDivCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.RBUCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.BrandCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.NatStoreDC_BK)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.StyleNumber_BK)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.PlannedDeliveryDate)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.ExpectedHandoverDate)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.StorageLocation)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.ActualHandoverDate)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.LastConfirmedHandoverDate)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.CountryOriginCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.ShippingInstruction)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.PlannedRetailSellingSeason)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.StockSegment)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.IssuingStorageLocation)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.RoughGoodsReceiptQty)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.LegacyPONumber)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.LegacyPOItemNumber)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.RequisitionerName)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.InterCompanyCosts)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.RRP)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[GRWR])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[NAVS])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[P101])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[PB00])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[PBXX])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[SKTO])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[WOTB])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZDIS])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZDVG])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZFR1])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZIDU])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZIF%])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZIFV])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZIHF])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZIIN])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZINC])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZINM])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZIUP])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZMAN])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZNF%])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZPB0])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZPBX])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZSD1])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZSD2])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZSFP])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZSH1])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZSL1])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZSL2])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZSL3])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZSM1])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZSMS])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZSO1])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZSO2])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZSOC])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZSP1])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZSP4])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZSQ1])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZSQ2])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZSR1])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZSRD])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZSSC])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZSSM])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZSV1])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZSV2])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZSWC])))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.IBD_DeliveryDate)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.PO_DeliveryDate)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.ActualGoodsMovementDate)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.IBD_DeliveryDocument)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.DeliveryDate)))),'_',
            UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), X.[ZVAT]))))
	    ))) AS HashDiff

    FROM #preresult X
    OPTION (LABEL = 'dbo.S4Hana_spProvNatPurchaseOrdersCurrentAccumulated: DeltaTempTableFinalResultStatement')

    /*--------------------------------------------------------------------------------------------*/
    -- Update-Insert sourcing.NatPurchasesCurrentAccumulated
    /*--------------------------------------------------------------------------------------------*/

    UPDATE
          dest
    SET
          dest.ModifiedOn = CAST(@CurrentTimestamp AS SMALLDATETIME)
		, dest.CompanyCode = src.CompanyCode
		, dest.PDUCode = src.PDUCode
		, dest.HashDiff = src.HashDiff
        , dest.POStatusCode = src.POStatusCode
		, dest.ArticleNumber_BK = src.ArticleNumber_BK
        , dest.IntPOTypeCode = src.IntPOTypeCode
		, dest.IntPOTypeDesc = src.IntPOTypeDesc
		, dest.NatPOTypeCode = src.NatPOTypeCode
		, dest.NatPOTypeDesc = src.NatPOTypeDesc
        , dest.SupplierCode = src.SupplierCode
		, dest.POSubType = src.POSubType
		, dest.POCreationDate = src.POCreationDate
        , dest.RequestedDeliveryDate = src.RequestedDeliveryDate
        , dest.LastConfirmedDeliveryDate = src.LastConfirmedDeliveryDate
        , dest.CurrencyCode = src.CurrencyCode
		, dest.ArticleSize_BK = src.ArticleSize_BK
		, dest.NatDC_BK = src.NatDC_BK
        , dest.Qty = src.Qty
        , dest.NetValueLC = src.NetValueLC
        , dest.FactoryCode = src.FactoryCode
        , dest.BusTypeCode = src.BusTypeCode
        , dest.SourcingCustomerCode = src.SourcingCustomerCode
        , dest.NatSalesOrderNo = src.NatSalesOrderNo
        , dest.PurchasingSystem = src.PurchasingSystem
        , dest.NatSalesOrderItemNo = src.NatSalesOrderItemNo
        , dest.NatSalesOrderItemScheduleLineNo = src.NatSalesOrderItemScheduleLineNo
        , dest.NatLandedCostLC = src.NatLandedCostLC
        , dest.Active = src.Active
		, dest.NatArticle_BK = src.NatArticle_BK
        , dest.ProdDivCode = src.ProdDivCode
        , dest.RBUCode = src.RBUCode
        , dest.BrandCode = src.BrandCode
		, dest.NatStoreDC_BK = src.NatStoreDC_BK
		, dest.StyleNumber_BK = src.StyleNumber_BK
        , dest.PlannedDeliveryDate = src.PlannedDeliveryDate
        , dest.ExpectedHandoverDate = src.ExpectedHandoverDate
        , dest.ActualHandoverDate = src.ActualHandoverDate
        , dest.LastConfirmedHandoverDate = src.LastConfirmedHandoverDate
        , dest.CountryOriginCode = src.CountryOriginCode
        , dest.ShippingInstruction = src.ShippingInstruction
        , dest.PlannedRetailSellingSeason = src.PlannedRetailSellingSeason
        , dest.StockSegment = src.StockSegment
        , dest.RoughGoodsReceiptQty = src.RoughGoodsReceiptQty
        , dest.LegacyPONumber = src.LegacyPONumber
        , dest.LegacyPOItemNumber = src.LegacyPOItemNumber
        , dest.RequisitionerName = src.RequisitionerName
        , dest.InterCompanyCosts = src.InterCompanyCosts
        , dest.RRP = src.RRP
		, dest.StorageLocation = src.StorageLocation
		, dest.IssuingStorageLocation = src.IssuingStorageLocation
        , dest.[GRWR] = src.[GRWR]
        , dest.[NAVS] = src.[NAVS]
        , dest.[P101] = src.[P101]
        , dest.[PB00] = src.[PB00]
        , dest.[PBXX] = src.[PBXX]
        , dest.[SKTO] = src.[SKTO]
        , dest.[WOTB] = src.[WOTB]
        , dest.[ZDIS] = src.[ZDIS]
        , dest.[ZDVG] = src.[ZDVG]
        , dest.[ZFR1] = src.[ZFR1]
        , dest.[ZIDU] = src.[ZIDU]
        , dest.[ZIF%] = src.[ZIF%]
        , dest.[ZIFV] = src.[ZIFV]
        , dest.[ZIHF] = src.[ZIHF]
        , dest.[ZIIN] = src.[ZIIN]
        , dest.[ZINC] = src.[ZINC]
        , dest.[ZINM] = src.[ZINM]
        , dest.[ZIUP] = src.[ZIUP]
        , dest.[ZMAN] = src.[ZMAN]
        , dest.[ZNF%] = src.[ZNF%]
        , dest.[ZPB0] = src.[ZPB0]
        , dest.[ZPBX] = src.[ZPBX]
        , dest.[ZSD1] = src.[ZSD1]
        , dest.[ZSD2] = src.[ZSD2]
        , dest.[ZSFP] = src.[ZSFP]
        , dest.[ZSH1] = src.[ZSH1]
        , dest.[ZSL1] = src.[ZSL1]
        , dest.[ZSL2] = src.[ZSL2]
        , dest.[ZSL3] = src.[ZSL3]
        , dest.[ZSM1] = src.[ZSM1]
        , dest.[ZSMS] = src.[ZSMS]
        , dest.[ZSO1] = src.[ZSO1]
        , dest.[ZSO2] = src.[ZSO2]
        , dest.[ZSOC] = src.[ZSOC]
        , dest.[ZSP1] = src.[ZSP1]
        , dest.[ZSP4] = src.[ZSP4]
        , dest.[ZSQ1] = src.[ZSQ1]
        , dest.[ZSQ2] = src.[ZSQ2]
        , dest.[ZSR1] = src.[ZSR1]
        , dest.[ZSRD] = src.[ZSRD]
        , dest.[ZSSC] = src.[ZSSC]
        , dest.[ZSSM] = src.[ZSSM]
        , dest.[ZSV1] = src.[ZSV1]
        , dest.[ZSV2] = src.[ZSV2]
        , dest.[ZSWC] = src.[ZSWC]
        , dest.[ZVAT] = src.[ZVAT]
		, dest.IBD_DeliveryDate = src.IBD_DeliveryDate
		, dest.PO_DeliveryDate = src.PO_DeliveryDate
		, dest.DeliveryDate = src.DeliveryDate
		, dest.ActualGoodsMovementDate = src.ActualGoodsMovementDate
		, dest.IBD_DeliveryDocument = src.IBD_DeliveryDocument
    FROM  sourcing.NatPurchaseOrdersCurrentAccumulated AS dest
    JOIN  #result                                      AS src ON dest.NatPurchaseOrder_BK = src.NatPurchaseOrder_BK AND dest.IntPupMasterId = src.IntPupMasterId AND dest.NatPurchaseOrderNo = src.NatPurchaseOrderNo
    WHERE dest.HashDiff <> src.HashDiff
    OPTION (LABEL = 'dbo.S4Hana_spProvNatPurchaseOrdersCurrentAccumulated: UpdateStatement')

    SELECT   TOP 1
             @UpdatedRows = es.row_count
    FROM     sys.dm_pdw_exec_requests er
    JOIN     sys.dm_pdw_request_steps es ON er.request_id = es.request_id
    WHERE    es.row_count > -1 AND er.[label] = 'dbo.S4Hana_spProvNatPurchaseOrdersCurrentAccumulated: UpdateStatement'
    ORDER BY er.end_time DESC;

    INSERT INTO sourcing.NatPurchaseOrdersCurrentAccumulated
    (
        NatPurchaseOrder_BK
      , CreatedOn
      , ModifiedOn
      , NatPurchaseOrderNo
      , NatPurchaseOrderItemNo
      , CompanyCode
      , IntPupMasterId
      , PDUCode
      , HashDiff
      , POStatusCode
      , ArticleNumber_BK
      , IntPOTypeCode
	  , IntPOTypeDesc
	  , NatPOTypeCode
	  ,	NatPOTypeDesc
	  , SupplierCode
	  , POSubType
      , POCreationDate
      , RequestedDeliveryDate
      , LastConfirmedDeliveryDate
      , CurrencyCode
      , ArticleSize_BK
      , NatDC_BK
      , Qty
      , NetValueLC
      , FactoryCode
      , BusTypeCode
      , SourcingCustomerCode
      , NatSalesOrderNo
      , PurchasingSystem
      , NatSalesOrderItemNo
      , NatSalesOrderItemScheduleLineNo
      , NatLandedCostLC
      , Active
      , NatArticle_BK
      , ProdDivCode
      , RBUCode
      , BrandCode
      , NatStoreDC_BK
      , StyleNumber_BK
      , PlannedDeliveryDate
      , ExpectedHandoverDate
      , ActualHandoverDate
      , LastConfirmedHandoverDate
      , CountryOriginCode
      , ShippingInstruction
      , PlannedRetailSellingSeason
      , StockSegment
	  , IssuingStorageLocation
      , RoughGoodsReceiptQty
      , LegacyPONumber
      , LegacyPOItemNumber
      , RequisitionerName
      , InterCompanyCosts
      , RRP
      , [GRWR]
      , [NAVS]
      , [P101]
      , [PB00]
      , [PBXX]
      , [SKTO]
      , [WOTB]
      , [ZDIS]
      , [ZDVG]
      , [ZFR1]
      , [ZIDU]
      , [ZIF%]
      , [ZIFV]
      , [ZIHF]
      , [ZIIN]
      , [ZINC]
      , [ZINM]
      , [ZIUP]
      , [ZMAN]
      , [ZNF%]
      , [ZPB0]
      , [ZPBX]
      , [ZSD1]
      , [ZSD2]
      , [ZSFP]
      , [ZSH1]
      , [ZSL1]
      , [ZSL2]
      , [ZSL3]
      , [ZSM1]
      , [ZSMS]
      , [ZSO1]
      , [ZSO2]
      , [ZSOC]
      , [ZSP1]
      , [ZSP4]
      , [ZSQ1]
      , [ZSQ2]
      , [ZSR1]
      , [ZSRD]
      , [ZSSC]
      , [ZSSM]
      , [ZSV1]
      , [ZSV2]
      , [ZSWC]
      , [ZVAT]
	  , [StorageLocation]
	  , IBD_DeliveryDate
      , PO_DeliveryDate
      , DeliveryDate
  	  , ActualGoodsMovementDate
	  , IBD_DeliveryDocument
    )
    SELECT
              src.NatPurchaseOrder_BK
            , CAST(@CurrentTimestamp AS SMALLDATETIME) AS CreatedOn
            , CAST(@CurrentTimestamp AS SMALLDATETIME) AS ModifiedOn
            , src.NatPurchaseOrderNo
            , src.NatPurchaseOrderItemNo
            , src.CompanyCode
            , src.IntPupMasterId
            , src.PDUCode
            , src.HashDiff
            , src.POStatusCode
            , src.ArticleNumber_BK
            , src.IntPOTypeCode
			, src.IntPOTypeDesc
			, src.NatPOTypeCode
			, src.NatPOTypeDesc
			, src.SupplierCode
			, src.POSubType
            , src.POCreationDate
            , src.RequestedDeliveryDate
            , src.LastConfirmedDeliveryDate
            , src.CurrencyCode
            , src.ArticleSize_BK
            , src.NatDC_BK
            , src.Qty
            , src.NetValueLC
            , src.FactoryCode
            , src.BusTypeCode
            , src.SourcingCustomerCode
            , src.NatSalesOrderNo
            , src.PurchasingSystem
            , src.NatSalesOrderItemNo
            , src.NatSalesOrderItemScheduleLineNo
            , src.NatLandedCostLC
            , src.Active
            , src.NatArticle_BK
            , src.ProdDivCode
            , src.RBUCode
            , src.BrandCode
            , src.NatStoreDC_BK
            , src.StyleNumber_BK
            , src.PlannedDeliveryDate
            , src.ExpectedHandoverDate
            , src.ActualHandoverDate
            , src.LastConfirmedHandoverDate
            , src.CountryOriginCode
            , src.ShippingInstruction
            , src.PlannedRetailSellingSeason
            , src.StockSegment
            , src.IssuingStorageLocation
            , src.RoughGoodsReceiptQty
            , src.LegacyPONumber
            , src.LegacyPOItemNumber
            , src.RequisitionerName
            , src.InterCompanyCosts
            , src.RRP
            , src.[GRWR]
            , src.[NAVS]
            , src.[P101]
            , src.[PB00]
            , src.[PBXX]
            , src.[SKTO]
            , src.[WOTB]
            , src.[ZDIS]
            , src.[ZDVG]
            , src.[ZFR1]
            , src.[ZIDU]
            , src.[ZIF%]
            , src.[ZIFV]
            , src.[ZIHF]
            , src.[ZIIN]
            , src.[ZINC]
            , src.[ZINM]
            , src.[ZIUP]
            , src.[ZMAN]
            , src.[ZNF%]
            , src.[ZPB0]
            , src.[ZPBX]
            , src.[ZSD1]
            , src.[ZSD2]
            , src.[ZSFP]
            , src.[ZSH1]
            , src.[ZSL1]
            , src.[ZSL2]
            , src.[ZSL3]
            , src.[ZSM1]
            , src.[ZSMS]
            , src.[ZSO1]
            , src.[ZSO2]
            , src.[ZSOC]
            , src.[ZSP1]
            , src.[ZSP4]
            , src.[ZSQ1]
            , src.[ZSQ2]
            , src.[ZSR1]
            , src.[ZSRD]
            , src.[ZSSC]
            , src.[ZSSM]
            , src.[ZSV1]
            , src.[ZSV2]
            , src.[ZSWC]
            , src.[ZVAT]
			, src.[StorageLocation]
			, src.IBD_DeliveryDate
            , src.PO_DeliveryDate
            , src.DeliveryDate
			, src.ActualGoodsMovementDate
			, src.IBD_DeliveryDocument


    FROM      #result                                      AS src
    LEFT JOIN sourcing.NatPurchaseOrdersCurrentAccumulated AS dest ON src.NatPurchaseOrder_BK = dest.NatPurchaseOrder_BK AND src.IntPupMasterId = dest.IntPupMasterId AND src.NatPurchaseOrderNo = dest.NatPurchaseOrderNo
    WHERE     dest.NatPurchaseOrder_BK IS NULL
    OPTION (LABEL = 'dbo.S4Hana_spProvNatPurchaseOrdersCurrentAccumulated: InsertStatement')
    
    SELECT   TOP 1
             @InsertedRows = es.row_count
    FROM     sys.dm_pdw_exec_requests er
    JOIN     sys.dm_pdw_request_steps es ON er.request_id = es.request_id
    WHERE    es.row_count > -1 AND er.[label] = 'dbo.S4Hana_spProvNatPurchaseOrdersCurrentAccumulated: InsertStatement'
    ORDER BY er.end_time DESC;

    --Log data load end
    UPDATE
          etl.DataTransferLogs
    SET
          ExecEnd = GETDATE()
        , Inserted = @InsertedRows
        , Updated = @UpdatedRows
    WHERE DataTransferLogId = @DataTransferLogId

-- exec [dbo].[S4Hana_spProvNatPurchaseOrdersCurrentAccumulated] '19000101'

END
