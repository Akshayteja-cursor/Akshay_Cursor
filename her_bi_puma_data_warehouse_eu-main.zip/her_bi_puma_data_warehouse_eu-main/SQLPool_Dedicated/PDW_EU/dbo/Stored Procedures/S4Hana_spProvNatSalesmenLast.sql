﻿CREATE PROC [dbo].[S4Hana_spProvNatSalesmenLast] @LDTS [DATETIME2](7) AS

DECLARE @LoadDate DATETIME2(7) = GETDATE();

IF OBJECT_ID('tempdb..#NatSalesMen') IS NOT NULL DROP TABLE #NatSalesMen;

-- logging informations - BEGIN
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(0) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(0)
DECLARE @DestinationLastLoadDate DATETIME2(0)
DECLARE @BatchLdts DATETIME2(0) = @LDTS
DECLARE @AffectedRows BIGINT = NULL
-- logging Informations - END

-- get last LDTS Informations for Logging
IF(EXISTS(SELECT 1 FROM ref.NatSalesMen))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(modifiedOn))
		FROM ref.NatSalesMen
	END
ELSE 
	BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

IF(EXISTS(SELECT 1 FROM ref.NatSalesMen))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(modifiedOn))
		FROM ref.NatSalesMen
	END
ELSE 
	BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END
-- Logging Informations END


-- Log first DATA Informations

INSERT INTO etl.DataTransferLogs
(
  DataTransferLogId
, TransferName
, TransferGroupName
, TargetTableName
, TargetSchemaName
, ExecStart
, SourceLastLoadDate
, DestinationLastLoadDate
, BatchLdts
)
SELECT 
  @DataTransferLogId 
, 'S4Hana_spProvNatSalesmenLast'
, 'NatSalesMen'
, 'NatSalesMen'
, 'ref'
, @ExecStart
, @SourceLastLoadDate
, @DestinationLastLoadDate
, @BatchLdts;

-- Log first DATA Informations END

WITH CTE_Customer_Company_Hierarchy AS
(
	SELECT
	  A.CustomerNumber
	, A.LDTS
	, A.SalesOrgCode
	, ROW_NUMBER() OVER (PARTITION BY A.CustomerNumber ,A.SalesOrgCode
						 ORDER BY A.SalesOrgCode
								, A.DistributionChannelCode) AS RN
	FROM stag.S4Hana_vCustomerSalesAttributes A
	WHERE A.IsDeleted = 0 
		AND (A.DeletionIndicator = '' OR A.DeletionIndicator IS NULL)
)
, CTE_NatSalesMen AS
(
	SELECT
	  CONCAT(A.CustomerCode, '|', C.CompanyCode)				AS NatSalesman_BK
	, @LoadDate													AS CreatedOn
	, @LoadDate													AS ModifiedOn
	, A.CustomerCode											AS NatSalesmanCode
	, C.CompanyCode												AS CompanyCode
	, C.IntPupMasterId											AS IntPupMasterId
	, C.PDUCode													AS PDUCode
	, A.CustomerName											AS NatSalesmanName
	, A.City													AS City
	, A.Street													AS Street
	, A.PostalCode												AS PostalCode
	, CAST(CASE WHEN A.IsDeleted = 1 
					  OR A.DeletionIndicator != '' THEN 1 
				 ELSE 0 
			END AS BIT)											AS LockFlag
	FROM stag.S4Hana_vCustomers A
	LEFT JOIN CTE_Customer_Company_Hierarchy B ON A.CustomerCode = B.CustomerNumber 
		AND B.RN = 1
	INNER JOIN pdwref.S4Hana_Interfaces C ON B.SalesOrgCode = C.SalesOrg
	WHERE A.IsDeleted = 0 
		AND (A.DeletionIndicator = '' OR A.DeletionIndicator IS NULL)
		AND A.CustomerAccountGroup = 'Z009' --Sales Representative
		
)

, cte_salesmanager AS --Add Sales manager name By Reza
(
       SELECT distinct SalesManagerName ,
              customerno
       FROM   etl.s4hana_customerbusinesspartner)

SELECT
  c.NatSalesman_BK
, c.CreatedOn
, c.ModifiedOn
, c.NatSalesmanCode
, c.CompanyCode
, c.IntPupMasterId
, c.PDUCode
, CONVERT(BINARY(16), HASHBYTES('MD5',CONCAT(
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), c.NatSalesman_BK	)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), c.NatSalesmanCode 	)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), c.CompanyCode 		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), c.IntPupMasterId 	)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), c.PDUCode 			)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), c.NatSalesmanName 	)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), c.City 			)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), c.Street 			)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), c.PostalCode 		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), c.LockFlag 		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), s.SalesManagerName ))))
  ))) AS HashDiff
, c.NatSalesmanName
, c.City
, c.Street
, c.PostalCode
, c.LockFlag
, s.SalesManagerName
INTO #NatSalesMen
FROM CTE_NatSalesMen c left join cte_salesmanager s
					on c.natsalesmancode = s.customerno


--Count Records to be updated
SELECT @AffectedRows = COUNT(*)
FROM ref.NatSalesMen A
INNER JOIN #NatSalesMen B ON A.NatSalesman_BK = B.NatSalesman_BK
WHERE A.HashDiff <> B.HashDiff

--Update Final Table
UPDATE A SET
  A.ModifiedOn = @LoadDate
, A.NatSalesmanCode = B.NatSalesmanCode
, A.CompanyCode = B.CompanyCode
, A.IntPupMasterId = B.IntPupMasterId
, A.PDUCode = B.PDUCode
, A.HashDiff = B.HashDiff
, A.NatSalesmanName = B.NatSalesmanName
, A.City = B.City
, A.Street = B.Street
, A.PostalCode = B.PostalCode
, A.LockFlag = B.LockFlag
, A.SalesManagerName = B.SalesManagerName
FROM ref.NatSalesMen A
INNER JOIN #NatSalesMen B ON A.NatSalesman_BK = B.NatSalesman_BK
WHERE A.HashDiff <> B.HashDiff

--Log count of updated records
UPDATE DTlogs SET
  Updated = @AffectedRows
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

--Count Records to be inserted
SELECT @AffectedRows = COUNT(*)
FROM #NatSalesMen A
LEFT JOIN ref.NatSalesMen B ON A.NatSalesman_BK = B.NatSalesman_BK
WHERE B.NatSalesman_BK IS NULL

--Insert to Final Table
INSERT INTO ref.NatSalesMen
(
  NatSalesman_BK
, CreatedOn
, ModifiedOn
, NatSalesmanCode
, CompanyCode
, IntPupMasterId
, PDUCode
, HashDiff
, NatSalesmanName
, City
, Street
, PostalCode
, LockFlag
, SalesManagerName
)
SELECT
  A.NatSalesman_BK
, A.CreatedOn
, A.ModifiedOn
, A.NatSalesmanCode
, A.CompanyCode
, A.IntPupMasterId
, A.PDUCode
, A.HashDiff
, A.NatSalesmanName
, A.City
, A.Street
, A.PostalCode
, A.LockFlag
, A.SalesManagerName
FROM #NatSalesMen A
LEFT JOIN ref.NatSalesMen B ON A.NatSalesman_BK = B.NatSalesman_BK
WHERE B.NatSalesman_BK IS NULL

--Log count of inserted records
UPDATE DTlogs SET 
  Inserted = @AffectedRows
, ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId
