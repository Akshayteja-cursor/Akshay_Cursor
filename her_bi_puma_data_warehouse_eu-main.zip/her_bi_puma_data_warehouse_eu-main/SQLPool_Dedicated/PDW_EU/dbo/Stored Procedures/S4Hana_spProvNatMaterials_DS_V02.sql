﻿CREATE PROC [dbo].[S4Hana_spProvNatMaterials_DS_V02] @LDTS [DATETIME2](7) AS
BEGIN
DECLARE @LoadDate DATETIME2(7) = GETDATE();

IF OBJECT_ID('tempdb..#NatMaterials') IS NOT NULL DROP TABLE #NatMaterials;

-- logging informations - BEGIN
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(0) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(0)
DECLARE @DestinationLastLoadDate DATETIME2(0)
DECLARE @BatchLdts DATETIME2(0) = @LDTS
DECLARE @AffectedRows BIGINT = NULL
-- logging Informations - END

-- get last LDTS Informations for Logging
IF(EXISTS(SELECT 1 FROM [ref].[NatMaterials_DS_v02]))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(ModifiedOn))
		FROM [ref].[NatMaterials_DS_v02]
	END
ELSE 
	BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

IF(EXISTS(SELECT 1 FROM biz.[S4Hana_Materials]))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(LDTS))
		FROM biz.[S4Hana_Materials]
	END
ELSE 
	BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END
-- Logging Informations END


-- Log first DATA Informations

INSERT INTO etl.DataTransferLogs
(
  DataTransferLogId
, TransferName
, TransferGroupName
, TargetTableName
, TargetSchemaName
, ExecStart
, SourceLastLoadDate
, DestinationLastLoadDate
, BatchLdts
)
SELECT 
  @DataTransferLogId 
, 'S4Hana_spProvNatMaterials_DS_v02'
, 'NatMaterials_DS_v02'
, 'NatMaterials_DS_v02'
, 'ref'
, @ExecStart
, @SourceLastLoadDate
, @DestinationLastLoadDate
, @BatchLdts;

-- Log first DATA Informations END
WITH CTE AS
(
  SELECT 
   M.[Material]
  ,@LoadDate	AS CreatedOn
  ,@LoadDate	AS ModifiedOn
  ,M.MaterialType
  ,M.MaterialGroup
  ,M.MaterialBaseUnit
  ,M.MaterialGrossWeight
  ,M.MaterialNetWeight
  ,M.MaterialWeightUnit
  ,M.MaterialManufacturerNumber
  ,M.MaterialManufacturerPartNumber
  ,M.AuthorizationGroup
  ,M.IsBatchManagementRequired
  ,M.WeightUnit
  ,M.ntgew
  ,M.brgew
  ,M.meins
  ,M.matkl
  ,M.mtart
  ,M.brand_id
  ,M.fsh_mg_at1
  ,M.zcoldesc
  ,M.zcolor
  ,M.size1
  ,M.ean11
  ,M.zage_group_code
  ,M.zline_name_code
  ,M.zbus_unit
  ,M.zcategory
  ,M.zactgrp
  ,M.zart_grp_code
  ,M.zart_typ_code
  ,M.zgender_code
  ,M.zdcs_class
  ,M.zmkt_st_code
  ,M.zrepcat
  ,M.zrep_line
  ,M.zrepcon
  ,M.pod_code
  ,M.zprodiv
  ,M.mstae
  ,M.mstav
  ,M.zprd_chr_code
  ,M.zrbu
  ,M.zbusseg
  ,M.zbussub
  ,M.zret_gender
  ,M.zbfo_season
  ,M.zqinfo
  ,M.zfp_promo
  ,M.GenericMaterial
  ,M.zdcs_sclass
  ,M.fsh_mg_at2
  ,M.fsh_mg_at3
  ,M.MaterialCategory
  ,M.maindc
  ,M.free_char
  ,M.zlaunch
  ,M.DateOfLastChange
  ,M.DateChanged
  ,M.PIDFlag
  ,M.Master_Staging_werks
  ,M.Master_Staging_vtweg
  ,M.FirstPIDSeason
  ,M.LastPIDSeason
  ,M.RetailDCSDepCode
  ,M.OutletTheme
  ,M.FPeComTheme
  ,STRING_AGG(MSA.ProductSalesOrg, ',') WITHIN GROUP (ORDER BY MSA.ProductSalesOrg) as SalesOrganizations
  ,ST.StyleDesc
  ,ArtSize.SizeConversionCodeFR as SizeFR
  ,M.IsDeleted 
  ,(CONVERT(BIGINT, DATEDIFF(sECOND,'1970-01-01', @LoadDate)) * 1000000)  +  DATEPART(MCS,@LoadDate) as modifiedOn_UTC_epoch
FROM
  biz.[S4Hana_Materials] M
  inner join [biz].[S4Hana_MaterialSalesAttributes] MSA on M.Material = MSA.Product and MSA.RN_2 = 1
  --inner join [pdwref].[AreaCodeMapping] ACM on MSA.ProductSalesOrg=ACM.[SalesOrganization]
  left join [stag].[S4Hana_vStyleTexts] ST ON M.fsh_mg_at1 = ST.Style and ST.Language = 'EN'
  left join [ref].[ArticleSizes_DL] ArtSize ON concat(REPLACE(ArtSize.ArticleNumber_BK,' ','-'),'-',ArtSize.SizeNumber) = M.Material
	WHERE
	M.LDTS >= @LDTS 
	OR MSA.LDTS >= @LDTS
	OR ST.LDTS >= @LDTS
	OR ArtSize.[CreatedOn] >= @LDTS
	OR ArtSize.[ModifiedOn] >= @LDTS

GROUP BY 
 Material
,MaterialType
,MaterialGroup
,MaterialBaseUnit
,MaterialGrossWeight
,MaterialNetWeight
,MaterialWeightUnit
,MaterialManufacturerNumber
,MaterialManufacturerPartNumber
,AuthorizationGroup
,IsBatchManagementRequired
,WeightUnit
,ntgew
,brgew
,meins
,matkl
,mtart
,brand_id
,fsh_mg_at1
,zcoldesc
,zcolor
,size1
,ean11
,zage_group_code
,zline_name_code
,zbus_unit
,zcategory
,zactgrp
,zart_grp_code
,zart_typ_code
,zgender_code
,zdcs_class
,zmkt_st_code
,zrepcat
,zrep_line
,zrepcon
,pod_code
,zprodiv
,mstae
,mstav
,zprd_chr_code
,zrbu
,zbusseg
,zbussub
,zret_gender
,zbfo_season
,zqinfo
,zfp_promo
,GenericMaterial
,zdcs_sclass
,fsh_mg_at2
,fsh_mg_at3
,MaterialCategory
,maindc
,free_char
,zlaunch
,DateOfLastChange
,DateChanged
,PIDFlag
,Master_Staging_werks
,Master_Staging_vtweg
,FirstPIDSeason
,LastPIDSeason
,RetailDCSDepCode
,OutletTheme
,FPeComTheme
,StyleDesc
,SizeConversionCodeFR
,M.IsDeleted 
)

--Insert to temp table
SELECT 
	    Material
	   ,CreatedOn
	   ,ModifiedOn
	   ,MaterialType
	   ,MaterialGroup
	   ,MaterialBaseUnit
	   ,MaterialGrossWeight
	   ,MaterialNetWeight
	   ,MaterialWeightUnit
	   ,MaterialManufacturerNumber
       ,MaterialManufacturerPartNumber
	   ,AuthorizationGroup
	   ,IsBatchManagementRequired
	   ,WeightUnit
	   ,ntgew
	   ,brgew
	   ,meins
	   ,matkl
	   ,mtart
	   ,brand_id
	   ,fsh_mg_at1
	   ,zcoldesc
	   ,zcolor
	   ,size1
	   ,ean11
	   ,zage_group_code
	   ,zline_name_code
	   ,zbus_unit
	   ,zcategory
	   ,zactgrp
	   ,zart_grp_code
	   ,zart_typ_code
	   ,zgender_code
	   ,zdcs_class
	   ,zmkt_st_code
	   ,zrepcat
	   ,zrep_line
	   ,zrepcon
	   ,pod_code
	   ,zprodiv
	   ,mstae
	   ,mstav
	   ,zprd_chr_code
	   ,zrbu
	   ,zbusseg
	   ,zbussub
	   ,zret_gender
	   ,zbfo_season
	   ,zqinfo
	   ,zfp_promo
	   ,GenericMaterial
	   ,zdcs_sclass
	   ,fsh_mg_at2
	   ,fsh_mg_at3
	   ,MaterialCategory
	   ,maindc
	   ,free_char
	   ,zlaunch
	   ,DateOfLastChange
	   ,DateChanged
	   ,PIDFlag
	   ,Master_Staging_werks
	   ,Master_Staging_vtweg
	   ,FirstPIDSeason
	   ,LastPIDSeason
	   ,RetailDCSDepCode
	   ,OutletTheme
	   ,FPeComTheme
	   ,SalesOrganizations
	   ,StyleDesc
	   ,SizeFR
	   ,IsDeleted
	   ,modifiedOn_UTC_epoch
	   ,CONVERT([BINARY](16), HASHBYTES('MD5',CONCAT(
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),Material)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),MaterialType)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),MaterialGroup)))),'_',
        UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),MaterialBaseUnit)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),MaterialGrossWeight)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),MaterialNetWeight)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),MaterialWeightUnit)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),MaterialManufacturerNumber)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),MaterialManufacturerPartNumber)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),AuthorizationGroup)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),IsBatchManagementRequired)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),WeightUnit)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),ntgew)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),brgew)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),meins)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),matkl)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),mtart)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),brand_id)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),fsh_mg_at1)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),zcoldesc)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),zcolor)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),size1)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),ean11)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),zage_group_code)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),zline_name_code)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),zbus_unit)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),zcategory)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),zactgrp)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),zart_grp_code)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),zart_typ_code)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),zgender_code)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),zdcs_class)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),zmkt_st_code)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),zrepcat)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),zrep_line)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),zrepcon)))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),pod_code)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),zprodiv)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),mstae)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),mstav)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),zprd_chr_code)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),zrbu)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),zbusseg)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),zbussub)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),zret_gender)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),zbfo_season)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),zqinfo)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),zfp_promo)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),GenericMaterial)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),zdcs_sclass)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),fsh_mg_at2)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),fsh_mg_at3)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),MaterialCategory)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),maindc)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),free_char)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),zlaunch)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),DateOfLastChange)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),DateChanged)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),PIDFlag)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),Master_Staging_werks)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),Master_Staging_vtweg)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),FirstPIDSeason)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),LastPIDSeason)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),RetailDCSDepCode)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),OutletTheme)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),FPeComTheme)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),SalesOrganizations)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),StyleDesc)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),SizeFR)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),IsDeleted))))


	))) AS HashDiff
	
INTO #NatMaterials
FROM CTE

--Count Records to be updated
SELECT @AffectedRows = COUNT(*)
FROM [ref].[NatMaterials_DS_v02] A
INNER JOIN #NatMaterials B ON A.[Material] = B.[Material]
WHERE A.HashDiff <> B.HashDiff

--Update Final Table 
UPDATE A SET
	   A.ModifiedOn = @LoadDate
	  ,A.modifiedOn_UTC_epoch = ( CONVERT(BIGINT, DATEDIFF(sECOND,'1970-01-01', @LoadDate)) * 1000000)  +  DATEPART(MCS,@LoadDate)
	  ,A.IsDeleted = 0
	  ,A.MaterialType                   =B.MaterialType
	  ,A.MaterialGroup					=B.MaterialGroup
	  ,A.MaterialBaseUnit				=B.MaterialBaseUnit
      ,A.MaterialGrossWeight			=B.MaterialGrossWeight
	  ,A.MaterialNetWeight				=B.MaterialNetWeight
	  ,A.MaterialWeightUnit				=B.MaterialWeightUnit
	  ,A.MaterialManufacturerNumber		=B.MaterialManufacturerNumber
	  ,A.MaterialManufacturerPartNumber	=B.MaterialManufacturerPartNumber
	  ,A.AuthorizationGroup				=B.AuthorizationGroup
	  ,A.IsBatchManagementRequired		=B.IsBatchManagementRequired
	  ,A.WeightUnit						=B.WeightUnit
	  ,A.ntgew							=B.ntgew
	  ,A.brgew							=B.brgew
	  ,A.meins							=B.meins
	  ,A.matkl							=B.matkl
	  ,A.mtart							=B.mtart
	  ,A.brand_id						=B.brand_id
	  ,A.fsh_mg_at1						=B.fsh_mg_at1
	  ,A.zcoldesc						=B.zcoldesc
	  ,A.zcolor							=B.zcolor
	  ,A.size1							=B.size1
	  ,A.ean11							=B.ean11
	  ,A.zage_group_code				=B.zage_group_code
	  ,A.zline_name_code				=B.zline_name_code
	  ,A.zbus_unit						=B.zbus_unit
	  ,A.zcategory						=B.zcategory
	  ,A.zactgrp						=B.zactgrp
	  ,A.zart_grp_code					=B.zart_grp_code
	  ,A.zart_typ_code					=B.zart_typ_code
	  ,A.zgender_code					=B.zgender_code
	  ,A.zdcs_class						=B.zdcs_class
	  ,A.zmkt_st_code					=B.zmkt_st_code
	  ,A.zrepcat						=B.zrepcat
	  ,A.zrep_line						=B.zrep_line
	  ,A.zrepcon						=B.zrepcon
	  ,A.pod_code						=B.pod_code
	  ,A.zprodiv						=B.zprodiv
	  ,A.mstae							=B.mstae
	  ,A.mstav							=B.mstav
	  ,A.zprd_chr_code					=B.zprd_chr_code
	  ,A.zrbu							=B.zrbu
	  ,A.zbusseg						=B.zbusseg
	  ,A.zbussub						=B.zbussub
	  ,A.zret_gender					=B.zret_gender
	  ,A.zbfo_season					=B.zbfo_season
	  ,A.zqinfo							=B.zqinfo
	  ,A.zfp_promo						=B.zfp_promo
	  ,A.GenericMaterial				=B.GenericMaterial
	  ,A.zdcs_sclass					=B.zdcs_sclass
	  ,A.fsh_mg_at2						=B.fsh_mg_at2
	  ,A.fsh_mg_at3						=B.fsh_mg_at3
	  ,A.MaterialCategory				=B.MaterialCategory
	  ,A.maindc							=B.maindc
	  ,A.free_char						=B.free_char
	  ,A.zlaunch						=B.zlaunch
	  ,A.DateOfLastChange				=B.DateOfLastChange
	  ,A.DateChanged					=B.DateChanged
	  ,A.PIDFlag						=B.PIDFlag
	  ,A.Master_Staging_werks			=B.Master_Staging_werks
	  ,A.Master_Staging_vtweg			=B.Master_Staging_vtweg
	  ,A.FirstPIDSeason					=B.FirstPIDSeason
	  ,A.LastPIDSeason					=B.LastPIDSeason
	  ,A.RetailDCSDepCode				=B.RetailDCSDepCode
	  ,A.OutletTheme					=B.OutletTheme
	  ,A.FPeComTheme					=B.FPeComTheme
	  ,A.SalesOrganizations			    =B.SalesOrganizations
	  ,A.StyleDesc						=B.StyleDesc
	  ,A.SizeFR							=B.SizeFR
	  ,A.HashDiff			 		    = B.HashDiff


FROM [ref].[NatMaterials_DS_v02] A
INNER JOIN #NatMaterials B ON A.[Material] = B.[Material]
WHERE A.HashDiff <> B.HashDiff and B.IsDeleted = 0

--update deletion status
UPDATE A SET
	   A.ModifiedOn = @LoadDate
	  ,A.modifiedOn_UTC_epoch = ( CONVERT(BIGINT, DATEDIFF(sECOND,'1970-01-01', @LoadDate)) * 1000000)  +  DATEPART(MCS,@LoadDate)
	  ,A.IsDeleted = 1
	  ,A.HashDiff  = B.HashDiff

FROM [ref].[NatMaterials_DS_v02] A
INNER JOIN #NatMaterials B ON A.[Material] = B.[Material]
WHERE A.HashDiff <> B.HashDiff and B.IsDeleted = 1

--Log count of updated records
UPDATE DTlogs SET
  Updated = @AffectedRows
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

--Count Records to be inserted
SELECT @AffectedRows = COUNT(*)
FROM #NatMaterials A
LEFT JOIN [ref].[NatMaterials_DS_v02] B ON A.[Material] = B.[Material]
WHERE B.[Material] IS NULL

--Insert to Final Table
INSERT INTO [ref].[NatMaterials_DS_v02]
(
       Material
	  ,CreatedOn
	  ,ModifiedOn
	  ,MaterialType
	  ,MaterialGroup
	  ,MaterialBaseUnit
	  ,MaterialGrossWeight
      ,MaterialNetWeight
	  ,MaterialWeightUnit
	  ,MaterialManufacturerNumber
	  ,MaterialManufacturerPartNumber
	  ,AuthorizationGroup
	  ,IsBatchManagementRequired
	  ,WeightUnit
	  ,ntgew
	  ,brgew
	  ,meins
	  ,matkl
	  ,mtart
	  ,brand_id
	  ,fsh_mg_at1
	  ,zcoldesc
	  ,zcolor
	  ,size1
	  ,ean11
	  ,zage_group_code
	  ,zline_name_code
	  ,zbus_unit
	  ,zcategory
	  ,zactgrp
	  ,zart_grp_code
	  ,zart_typ_code
	  ,zgender_code
	  ,zdcs_class
	  ,zmkt_st_code
	  ,zrepcat
	  ,zrep_line
	  ,zrepcon
	  ,pod_code
	  ,zprodiv
	  ,mstae
	  ,mstav
	  ,zprd_chr_code
	  ,zrbu
	  ,zbusseg
	  ,zbussub
	  ,zret_gender
	  ,zbfo_season
	  ,zqinfo
	  ,zfp_promo
	  ,GenericMaterial
	  ,zdcs_sclass
	  ,fsh_mg_at2
	  ,fsh_mg_at3
	  ,MaterialCategory
	  ,maindc
	  ,free_char
	  ,zlaunch
	  ,DateOfLastChange
	  ,DateChanged
	  ,PIDFlag
	  ,Master_Staging_werks
	  ,Master_Staging_vtweg
	  ,FirstPIDSeason
	  ,LastPIDSeason
	  ,RetailDCSDepCode
	  ,OutletTheme
	  ,FPeComTheme
	  ,SalesOrganizations
	  ,StyleDesc
	  ,SizeFR
	  ,IsDeleted
	  ,Hashdiff
	  ,modifiedOn_UTC_epoch
	  )
SELECT
	   A.Material
	  ,A.CreatedOn
	  ,A.ModifiedOn
	  ,A.MaterialType
	  ,A.MaterialGroup
	  ,A.MaterialBaseUnit
	  ,A.MaterialGrossWeight
      ,A.MaterialNetWeight
	  ,A.MaterialWeightUnit
	  ,A.MaterialManufacturerNumber
	  ,A.MaterialManufacturerPartNumber
	  ,A.AuthorizationGroup
	  ,A.IsBatchManagementRequired
	  ,A.WeightUnit
	  ,A.ntgew
	  ,A.brgew
	  ,A.meins
	  ,A.matkl
	  ,A.mtart
	  ,A.brand_id
	  ,A.fsh_mg_at1
	  ,A.zcoldesc
	  ,A.zcolor
	  ,A.size1
	  ,A.ean11
	  ,A.zage_group_code
	  ,A.zline_name_code
	  ,A.zbus_unit
	  ,A.zcategory
	  ,A.zactgrp
	  ,A.zart_grp_code
	  ,A.zart_typ_code
	  ,A.zgender_code
	  ,A.zdcs_class
	  ,A.zmkt_st_code
	  ,A.zrepcat
	  ,A.zrep_line
	  ,A.zrepcon
	  ,A.pod_code
	  ,A.zprodiv
	  ,A.mstae
	  ,A.mstav
	  ,A.zprd_chr_code
	  ,A.zrbu
	  ,A.zbusseg
	  ,A.zbussub
	  ,A.zret_gender
	  ,A.zbfo_season
	  ,A.zqinfo
	  ,A.zfp_promo
	  ,A.GenericMaterial
	  ,A.zdcs_sclass
	  ,A.fsh_mg_at2
	  ,A.fsh_mg_at3
	  ,A.MaterialCategory
	  ,A.maindc
	  ,A.free_char
	  ,A.zlaunch
	  ,A.DateOfLastChange
	  ,A.DateChanged
	  ,A.PIDFlag
	  ,A.Master_Staging_werks
	  ,A.Master_Staging_vtweg
	  ,A.FirstPIDSeason
	  ,A.LastPIDSeason
	  ,A.RetailDCSDepCode
	  ,A.OutletTheme
	  ,A.FPeComTheme
	  ,A.[SalesOrganizations]
	  ,A.StyleDesc
	  ,A.SizeFR
	  ,A.IsDeleted  
	  ,A.HashDiff
	  ,A.modifiedOn_UTC_epoch


FROM #NatMaterials A
LEFT JOIN [ref].[NatMaterials_DS_v02] B ON A.[Material] = B.[Material]
WHERE B.[Material] IS NULL

--Log count of inserted records
UPDATE DTlogs SET 
  Inserted = @AffectedRows
, ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

--exec [dbo].[S4Hana_spProvNatMaterials_DS_v02] '19000101'

END