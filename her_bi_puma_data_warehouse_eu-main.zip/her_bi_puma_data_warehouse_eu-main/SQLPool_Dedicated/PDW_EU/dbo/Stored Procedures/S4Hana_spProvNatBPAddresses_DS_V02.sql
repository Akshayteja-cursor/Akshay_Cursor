﻿CREATE PROC [dbo].[S4Hana_spProvNatBPAddresses_DS_V02] @LDTS [DATETIME2](7) AS

DECLARE @LoadDate DATETIME2(7) = GETDATE();
DECLARE @LoadDate_UTC_epoh BIGINT = ( CONVERT(BIGINT, DATEDIFF(sECOND,'1970-01-01', SYSUTCDATETIME())) * 1000000)  +  DATEPART(MCS,SYSUTCDATETIME());

IF OBJECT_ID('tempdb..#NatBPAddresses') IS NOT NULL DROP TABLE #NatBPAddresses;

-- logging informations - BEGIN
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(0) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(0)
DECLARE @DestinationLastLoadDate DATETIME2(0)
DECLARE @BatchLdts DATETIME2(0) = @LDTS
DECLARE @AffectedRows BIGINT = NULL
-- logging Informations - END

-- get last LDTS Informations for Logging
IF(EXISTS(SELECT 1 FROM [ref].[NatBPAddresses_DS_v02]))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(ModifiedOn))
		FROM [ref].[NatBPAddresses_DS_v02]
	END
ELSE
	BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

IF(EXISTS(SELECT 1 FROM biz.[S4Hana_BPAddresses]))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(LDTS))
		FROM biz.[S4Hana_BPAddresses]
	END
ELSE 
	BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END
-- Logging Informations END


-- Log first DATA Informations

INSERT INTO etl.DataTransferLogs
(
  DataTransferLogId
, TransferName
, TransferGroupName
, TargetTableName
, TargetSchemaName
, ExecStart
, SourceLastLoadDate
, DestinationLastLoadDate
, BatchLdts
)
SELECT 
  @DataTransferLogId 
, 'S4Hana_spProvNatBPAddresses_DS_v02'
, 'NatBPAddresses_DS_v02'
, 'NatBPAddresses_DS_v02'
, 'ref'
, @ExecStart
, @SourceLastLoadDate
, @DestinationLastLoadDate
, @BatchLdts;

-- Log first DATA Informations END
WITH CTE AS
(
	SELECT distinct  /*distinct neccesary due to join [stag].[S4Hana_vCustomers_all] c2 on b.But051customer = c2.[Customer],
	but051customer needed for CustAccGroup,SalesOrg retrieval. One bp has multiple customers /WL 24012024*/
	 a.[BusinessPartner]
	,CONCAT(A.[BusinessPartner],'|',A.AdrcAddressNumber,'|',A.ValidFrom,'|',A.IntAddress, '|',d.CustomerAccountGroup, '|',d.ContactFunction) AS NatBPAddresses_BK
	,@LoadDate	AS CreatedOn
	,@LoadDate	AS ModifiedOn
	,@LoadDate_UTC_epoh as ModifiedOn_UTC_epoch
	,d.[SalesOrganization]
	,d.CustomerAccountGroup
	,d.ContactFunction
	,c.BPCategory
	,a.[AddressNumber]
	,a.[StrdAddress]
	,a.[AdrcAddressNumber]
	,a.[ValidFrom]
	,a.[IntAddress]
	,a.[ValidToDflt]
	,a.[title]
	,a.[Name1]
	,a.[name2]
	,a.[name3]
	,a.[name4]
	,a.[convertedName]
	,a.[COName]
	,a.[City]
	,a.[District]
	,a.[CityCode]
	,a.[CityCode2]
	,a.[City2]
	,a.[CityFTest]
	,a.[TestStatus]
	,a.[RegionalGroup]
	,a.[PostalCode1]
	,a.[PostalCode2]
	,a.[PostalCode3]
	,a.[PostalCode1ex]
	,a.[PostalCode2ex]
	,a.[PostalCode3ex]
	,a.[POBox]
	,a.[BoxWoutNo]
	,a.[POBoxcity]
	,a.[CITY_CODE2]
	,a.[RegionPOBox]
	,a.[POboxcountry]
	,a.[PostDeliveryDistrict]
	,a.[TranspZone]
	,a.[Street]
	,a.[StreetCity]
	,a.[AbbrStreet]
	,a.[HouseNumber]
	,a.[HouseSuppl]
	,a.[HouseRange]
	,a.[Street2]
	,a.[Street3]
	,a.[Street4]
	,a.[Street5]
	,a.[Building]
	,a.[Floor]
	,a.[Room]
	,a.[COUNTRY]
	,a.[Language]
	,a.[Region]
	,a.[AddressGroup]
	,a.[FlagGroup]
	,a.[flagPersADDR]
	,a.[SearchTerm1]
	,a.[SearchTerm2]
	,a.[PhoneticSearch]
	,a.[DfltCommMtd]
	,a.[FirstTel]
	,a.[TelExtension]
	,a.[FAX_NUMBER]
	,a.[FaxExtension]
	,a.[FlagTeldef]
	,a.[FlagFax]
	,a.[Flagteletex]
	,a.[Flagtelex]
	,a.[FlagEmail]
	,a.[FlagRML]
	,a.[FlagX400]
	,a.[FlagRFC]
	,a.[FlagPrinter]
	,a.[FlagSSF]
	,a.[FlagURI]
	,a.[Pager]
	,a.[AddressDataSource]
	,a.[NameUpper]
	,a.[CityUpper]
	,a.[StreetUpper]
	,a.[EXTENSIONDataLine]
	,a.[EXTENSIONTelebox]
	,a.[TIME_ZONE]
	,a.[TAXJURCODE]
	,a.[ADDRESS_ID]
	,a.[OrigLanguage]
	,a.[UUIDAddress]
	,a.[IndUUIDAddress]
	,a.[CategoryAddress]
	,a.[ErrorStatusAddress]
	,a.[POBoxLobby]
	,a.[TypeDeliveryService]
	,a.[NumberDeliveryService]
	,a.[Countycode]
	,a.[County]
	,a.[Townshipcode]
	,a.[Township]
	,a.[CuontyUpper]
	,a.[TownshipUpper]
	,a.[BusinessPurpose]
	,a.[DunsBradstreet]
	,a.[DUNSplus4]
	,a.[IsDeleted]

FROM biz.[S4Hana_BPAddresses] a 
left join biz.[S4Hana_CustomerBusinessPartner] b on a.[BusinessPartner] = b.But051partner
left join biz.[S4Hana_BPGeneralData1] c on a.[BusinessPartner] = c.[BusinessPartner]
left join [stag].[vCustomerAccountGroup_DS] d on a.[BusinessPartner] = d.[BusinessPartner]
--inner join [pdwref].[AreaCodeMapping] acm on d.[SalesOrganization] = acm.SalesOrganization

	WHERE
	d.[SalesOrganization] is not null
	AND(A.LDTS >= @LDTS 
	OR B.LDTS >= @LDTS
	OR C.LDTS >= @LDTS
	OR D.CBP_LDTS >= @LDTS
	OR D.C_LDTS >= @LDTS	
	OR D.CSA_LDTS >= @LDTS)
)

--Insert to temp table
SELECT distinct
	   [BusinessPartner]
	  ,NatBPAddresses_BK
	  ,IsDeleted
	  ,CreatedOn
	  ,ModifiedOn
	  ,ModifiedOn_UTC_epoch
	  ,[SalesOrganization]
      ,CustomerAccountGroup
	  ,ContactFunction
	  ,BPCategory
	  ,[AddressNumber]
	  ,[StrdAddress]
	  ,[AdrcAddressNumber]
	  ,[ValidFrom]
	  ,[IntAddress]
	  ,[ValidToDflt]
	  ,[title]
	  ,[Name1]
	  ,[name2]
	  ,[name3]
	  ,[name4]
	  ,[convertedName]
	  ,[COName]
	  ,[City]
	  ,[District]
	  ,[CityCode]
	  ,[CityCode2]
	  ,[City2]
	  ,[CityFTest]
	  ,[TestStatus]
	  ,[RegionalGroup]
	  ,[PostalCode1]
	  ,[PostalCode2]
	  ,[PostalCode3]
	  ,[PostalCode1ex]
	  ,[PostalCode2ex]
	  ,[PostalCode3ex]
	  ,[POBox]
	  ,[BoxWoutNo]
	  ,[POBoxcity]
	  ,[CITY_CODE2]
	  ,[RegionPOBox]
	  ,[POboxcountry]
	  ,[PostDeliveryDistrict]
	  ,[TranspZone]
	  ,[Street]
	  ,[StreetCity]
	  ,[AbbrStreet]
	  ,[HouseNumber]
	  ,[HouseSuppl]
	  ,[HouseRange]
	  ,[Street2]
	  ,[Street3]
	  ,[Street4]
	  ,[Street5]
	  ,[Building]
	  ,[Floor]
	  ,[Room]
	  ,[COUNTRY]
	  ,[Language]
	  ,[Region]
	  ,[AddressGroup]
	  ,[FlagGroup]
	  ,[flagPersADDR]
	  ,[SearchTerm1]
	  ,[SearchTerm2]
	  ,[PhoneticSearch]
	  ,[DfltCommMtd]
	  ,[FirstTel]
	  ,[TelExtension]
	  ,[FAX_NUMBER]
	  ,[FaxExtension]
	  ,[FlagTeldef]
	  ,[FlagFax]
	  ,[Flagteletex]
	  ,[Flagtelex]
	  ,[FlagEmail]
	  ,[FlagRML]
	  ,[FlagX400]
	  ,[FlagRFC]
	  ,[FlagPrinter]
	  ,[FlagSSF]
	  ,[FlagURI]
	  ,[Pager]
	  ,[AddressDataSource]
	  ,[NameUpper]
	  ,[CityUpper]
	  ,[StreetUpper]
	  ,[EXTENSIONDataLine]
	  ,[EXTENSIONTelebox]
	  ,[TIME_ZONE]
	  ,[TAXJURCODE]
	  ,[ADDRESS_ID]
	  ,[OrigLanguage]
	  ,[UUIDAddress]
	  ,[IndUUIDAddress]
	  ,[CategoryAddress]
	  ,[ErrorStatusAddress]
	  ,[POBoxLobby]
	  ,[TypeDeliveryService]
	  ,[NumberDeliveryService]
	  ,[Countycode]
	  ,[County]
	  ,[Townshipcode]
	  ,[Township]
	  ,[CuontyUpper]
	  ,[TownshipUpper]
	  ,[BusinessPurpose]
	  ,[DunsBradstreet]
	  ,[DUNSplus4]
	  ,CONVERT([BINARY](16), HASHBYTES('MD5',CONCAT(
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[BusinessPartner]               )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),NatBPAddresses_BK               )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),IsDeleted						  )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SalesOrganization]			  )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),CustomerAccountGroup			  )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),ContactFunction				  )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),BPCategory					  )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[AddressNumber]				  )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[StrdAddress]					  )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[AdrcAddressNumber]			  )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ValidFrom]					  )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[IntAddress]					  )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ValidToDflt]					  )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[title]						  )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Name1]						  )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[name2]						  )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[name3]						  )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[name4]						  )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[convertedName]				  )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[COName]						  )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[City]						  )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[District]					  )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CityCode]					  )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CityCode2]					  )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[City2]						  )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CityFTest]					  )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TestStatus]					  )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[RegionalGroup]				  )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PostalCode1]					  )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PostalCode2]					  )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PostalCode3]					  )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PostalCode1ex]				  )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PostalCode2ex]				  )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PostalCode3ex]				  )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[POBox]						  )))),'_',
	    UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[BoxWoutNo]					  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[POBoxcity]					  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CITY_CODE2]					  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[RegionPOBox]					  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[POboxcountry]				  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PostDeliveryDistrict]		  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TranspZone]					  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Street]						  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[StreetCity]					  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[AbbrStreet]					  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[HouseNumber]					  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[HouseSuppl]					  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[HouseRange]					  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Street2]						  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Street3]						  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Street4]						  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Street5]						  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Building]					  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Floor]						  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Room]						  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[COUNTRY]						  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Language]					  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Region]						  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[AddressGroup]				  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FlagGroup]					  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[flagPersADDR]				  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SearchTerm1]					  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[SearchTerm2]					  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[PhoneticSearch]				  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DfltCommMtd]					  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FirstTel]					  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TelExtension]				  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FAX_NUMBER]					  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FaxExtension]				  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FlagTeldef]					  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FlagFax]						  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Flagteletex]					  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Flagtelex]					  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FlagEmail]					  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FlagRML]						  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FlagX400]					  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FlagRFC]						  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FlagPrinter]					  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FlagSSF]						  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[FlagURI]						  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Pager]						  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[AddressDataSource]			  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[NameUpper]					  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CityUpper]					  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[StreetUpper]					  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[EXTENSIONDataLine]			  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[EXTENSIONTelebox]			  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TIME_ZONE]					  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TAXJURCODE]					  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ADDRESS_ID]					  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[OrigLanguage]				  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[UUIDAddress]					  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[IndUUIDAddress]				  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CategoryAddress]				  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[ErrorStatusAddress]			  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[POBoxLobby]					  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TypeDeliveryService]			  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[NumberDeliveryService]		  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Countycode]					  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[County]						  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Townshipcode]				  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[Township]					  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[CuontyUpper]					  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[TownshipUpper]				  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[BusinessPurpose]				  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DunsBradstreet]				  )))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),[DUNSplus4]))))
	    
	))) AS HashDiff
	
INTO #NatBPAddresses
FROM CTE

--Count Records to be updated
SELECT @AffectedRows = COUNT(*)
FROM [ref].[NatBPAddresses_DS_v02] A
INNER JOIN #NatBPAddresses B ON A.NatBPAddresses_BK = B.NatBPAddresses_BK
WHERE A.HashDiff <> B.HashDiff

--Update Final Table 
UPDATE A SET
	   A.ModifiedOn = @LoadDate
	  ,A.ModifiedOn_UTC_epoch = @LoadDate_UTC_epoh
	  ,A.[SalesOrganization]      =B.[SalesOrganization]    		
      ,A.CustomerAccountGroup	  =B.CustomerAccountGroup	
	  ,A.ContactFunction		  =B.ContactFunction		
	  ,A.BPCategory				  =B.BPCategory				
	  ,A.[AddressNumber]		  =B.[AddressNumber]		
	  ,A.[StrdAddress]			  =B.[StrdAddress]			
	  ,A.[AdrcAddressNumber]	  =B.[AdrcAddressNumber]	
	  ,A.[ValidFrom]			  =B.[ValidFrom]			
	  ,A.[IntAddress]			  =B.[IntAddress]			
	  ,A.[ValidToDflt]			  =B.[ValidToDflt]			
	  ,A.[title]				  =B.[title]				
	  ,A.[Name1]				  =B.[Name1]				
	  ,A.[name2]				  =B.[name2]				
	  ,A.[name3]				  =B.[name3]				
	  ,A.[name4]				  =B.[name4]				
	  ,A.[convertedName]		  =B.[convertedName]		
	  ,A.[COName]				  =B.[COName]				
	  ,A.[City]					  =B.[City]					
	  ,A.[District]				  =B.[District]				
	  ,A.[CityCode]				  =B.[CityCode]				
	  ,A.[CityCode2]			  =B.[CityCode2]			
	  ,A.[City2]				  =B.[City2]				
	  ,A.[CityFTest]			  =B.[CityFTest]			
	  ,A.[TestStatus]			  =B.[TestStatus]			
	  ,A.[RegionalGroup]		  =B.[RegionalGroup]		
	  ,A.[PostalCode1]			  =B.[PostalCode1]			
	  ,A.[PostalCode2]			  =B.[PostalCode2]			
	  ,A.[PostalCode3]			  =B.[PostalCode3]			
	  ,A.[PostalCode1ex]		  =B.[PostalCode1ex]		
	  ,A.[PostalCode2ex]		  =B.[PostalCode2ex]		
	  ,A.[PostalCode3ex]		  =B.[PostalCode3ex]		
	  ,A.[POBox]				  =B.[POBox]				
	  ,A.[BoxWoutNo]			  =B.[BoxWoutNo]			
	  ,A.[POBoxcity]			  =B.[POBoxcity]			
	  ,A.[CITY_CODE2]			  =B.[CITY_CODE2]			
	  ,A.[RegionPOBox]			  =B.[RegionPOBox]			
	  ,A.[POboxcountry]			  =B.[POboxcountry]			
	  ,A.[PostDeliveryDistrict]	  =B.[PostDeliveryDistrict]	
	  ,A.[TranspZone]			  =B.[TranspZone]			
	  ,A.[Street]				  =B.[Street]				
	  ,A.[StreetCity]			  =B.[StreetCity]			
	  ,A.[AbbrStreet]			  =B.[AbbrStreet]			
	  ,A.[HouseNumber]			  =B.[HouseNumber]			
	  ,A.[HouseSuppl]			  =B.[HouseSuppl]			
	  ,A.[HouseRange]			  =B.[HouseRange]			
	  ,A.[Street2]				  =B.[Street2]				
	  ,A.[Street3]				  =B.[Street3]				
	  ,A.[Street4]				  =B.[Street4]				
	  ,A.[Street5]				  =B.[Street5]				
	  ,A.[Building]				  =B.[Building]				
	  ,A.[Floor]				  =B.[Floor]				
	  ,A.[Room]					  =B.[Room]					
	  ,A.[COUNTRY]				  =B.[COUNTRY]				
	  ,A.[Language]				  =B.[Language]				
	  ,A.[Region]				  =B.[Region]				
	  ,A.[AddressGroup]			  =B.[AddressGroup]			
	  ,A.[FlagGroup]			  =B.[FlagGroup]			
	  ,A.[flagPersADDR]			  =B.[flagPersADDR]			
	  ,A.[SearchTerm1]			  =B.[SearchTerm1]			
	  ,A.[SearchTerm2]			  =B.[SearchTerm2]			
	  ,A.[PhoneticSearch]		  =B.[PhoneticSearch]		
	  ,A.[DfltCommMtd]			  =B.[DfltCommMtd]			
	  ,A.[FirstTel]				  =B.[FirstTel]				
	  ,A.[TelExtension]			  =B.[TelExtension]			
	  ,A.[FAX_NUMBER]			  =B.[FAX_NUMBER]			
	  ,A.[FaxExtension]			  =B.[FaxExtension]			
	  ,A.[FlagTeldef]			  =B.[FlagTeldef]			
	  ,A.[FlagFax]				  =B.[FlagFax]				
	  ,A.[Flagteletex]			  =B.[Flagteletex]			
	  ,A.[Flagtelex]			  =B.[Flagtelex]			
	  ,A.[FlagEmail]			  =B.[FlagEmail]			
	  ,A.[FlagRML]				  =B.[FlagRML]				
	  ,A.[FlagX400]				  =B.[FlagX400]				
	  ,A.[FlagRFC]				  =B.[FlagRFC]				
	  ,A.[FlagPrinter]			  =B.[FlagPrinter]			
	  ,A.[FlagSSF]				  =B.[FlagSSF]				
	  ,A.[FlagURI]				  =B.[FlagURI]				
	  ,A.[Pager]				  =B.[Pager]				
	  ,A.[AddressDataSource]	  =B.[AddressDataSource]	
	  ,A.[NameUpper]			  =B.[NameUpper]			
	  ,A.[CityUpper]			  =B.[CityUpper]			
	  ,A.[StreetUpper]			  =B.[StreetUpper]			
	  ,A.[EXTENSIONDataLine]	  =B.[EXTENSIONDataLine]	
	  ,A.[EXTENSIONTelebox]		  =B.[EXTENSIONTelebox]		
	  ,A.[TIME_ZONE]			  =B.[TIME_ZONE]			
	  ,A.[TAXJURCODE]			  =B.[TAXJURCODE]			
	  ,A.[ADDRESS_ID]			  =B.[ADDRESS_ID]			
	  ,A.[OrigLanguage]			  =B.[OrigLanguage]			
	  ,A.[UUIDAddress]			  =B.[UUIDAddress]			
	  ,A.[IndUUIDAddress]		  =B.[IndUUIDAddress]		
	  ,A.[CategoryAddress]		  =B.[CategoryAddress]		
	  ,A.[ErrorStatusAddress]	  =B.[ErrorStatusAddress]	
	  ,A.[POBoxLobby]			  =B.[POBoxLobby]			
	  ,A.[TypeDeliveryService]	  =B.[TypeDeliveryService]	
	  ,A.[NumberDeliveryService]  =B.[NumberDeliveryService]
	  ,A.[Countycode]			  =B.[Countycode]			
	  ,A.[County]				  =B.[County]				
	  ,A.[Townshipcode]			  =B.[Townshipcode]			
	  ,A.[Township]				  =B.[Township]				
	  ,A.[CuontyUpper]			  =B.[CuontyUpper]			
	  ,A.[TownshipUpper]		  =B.[TownshipUpper]		
	  ,A.[BusinessPurpose]		  =B.[BusinessPurpose]		
	  ,A.[DunsBradstreet]		  =B.[DunsBradstreet]		
	  ,A.[DUNSplus4]			  =B.[DUNSplus4]		
	  ,A.HashDiff				  = B.HashDiff
	  ,A.IsDeleted = B.IsDeleted


FROM [ref].[NatBPAddresses_DS_v02] A
INNER JOIN #NatBPAddresses B ON A.NatBPAddresses_BK = B.NatBPAddresses_BK
WHERE A.HashDiff <> B.HashDiff and B.IsDeleted = 0

--update deletion status
UPDATE A SET
	   A.ModifiedOn = @LoadDate
	  ,A.ModifiedOn_UTC_epoch = @LoadDate_UTC_epoh
	  ,A.IsDeleted = 1
	  ,A.HashDiff	= B.HashDiff

FROM [ref].[NatBPAddresses_DS_v02] A
INNER JOIN #NatBPAddresses B ON A.NatBPAddresses_BK = B.NatBPAddresses_BK
WHERE A.HashDiff <> B.HashDiff and B.IsDeleted = 1

--Log count of updated records
UPDATE DTlogs SET
  Updated = @AffectedRows
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

--Count Records to be inserted
SELECT @AffectedRows = COUNT(*)
FROM #NatBPAddresses A
LEFT JOIN [ref].[NatBPAddresses_DS_v02] B ON A.NatBPAddresses_BK = B.NatBPAddresses_BK
WHERE B.NatBPAddresses_BK IS NULL

--Insert to Final Table
INSERT INTO [ref].[NatBPAddresses_DS_v02]
(
      [BusinessPartner]
	  ,NatBPAddresses_BK
	  ,IsDeleted
	  ,CreatedOn
	  ,ModifiedOn
	  ,ModifiedOn_UTC_epoch
	  ,[SalesOrganization]
      ,CustomerAccountGroup
	  ,ContactFunction
	  ,BPCategory
	  ,[AddressNumber]
	  ,[StrdAddress]
	  ,[AdrcAddressNumber]
	  ,[ValidFrom]
	  ,[IntAddress]
	  ,[ValidToDflt]
	  ,[title]
	  ,[Name1]
	  ,[name2]
	  ,[name3]
	  ,[name4]
	  ,[convertedName]
	  ,[COName]
	  ,[City]
	  ,[District]
	  ,[CityCode]
	  ,[CityCode2]
	  ,[City2]
	  ,[CityFTest]
	  ,[TestStatus]
	  ,[RegionalGroup]
	  ,[PostalCode1]
	  ,[PostalCode2]
	  ,[PostalCode3]
	  ,[PostalCode1ex]
	  ,[PostalCode2ex]
	  ,[PostalCode3ex]
	  ,[POBox]
	  ,[BoxWoutNo]
	  ,[POBoxcity]
	  ,[CITY_CODE2]
	  ,[RegionPOBox]
	  ,[POboxcountry]
	  ,[PostDeliveryDistrict]
	  ,[TranspZone]
	  ,[Street]
	  ,[StreetCity]
	  ,[AbbrStreet]
	  ,[HouseNumber]
	  ,[HouseSuppl]
	  ,[HouseRange]
	  ,[Street2]
	  ,[Street3]
	  ,[Street4]
	  ,[Street5]
	  ,[Building]
	  ,[Floor]
	  ,[Room]
	  ,[COUNTRY]
	  ,[Language]
	  ,[Region]
	  ,[AddressGroup]
	  ,[FlagGroup]
	  ,[flagPersADDR]
	  ,[SearchTerm1]
	  ,[SearchTerm2]
	  ,[PhoneticSearch]
	  ,[DfltCommMtd]
	  ,[FirstTel]
	  ,[TelExtension]
	  ,[FAX_NUMBER]
	  ,[FaxExtension]
	  ,[FlagTeldef]
	  ,[FlagFax]
	  ,[Flagteletex]
	  ,[Flagtelex]
	  ,[FlagEmail]
	  ,[FlagRML]
	  ,[FlagX400]
	  ,[FlagRFC]
	  ,[FlagPrinter]
	  ,[FlagSSF]
	  ,[FlagURI]
	  ,[Pager]
	  ,[AddressDataSource]
	  ,[NameUpper]
	  ,[CityUpper]
	  ,[StreetUpper]
	  ,[EXTENSIONDataLine]
	  ,[EXTENSIONTelebox]
	  ,[TIME_ZONE]
	  ,[TAXJURCODE]
	  ,[ADDRESS_ID]
	  ,[OrigLanguage]
	  ,[UUIDAddress]
	  ,[IndUUIDAddress]
	  ,[CategoryAddress]
	  ,[ErrorStatusAddress]
	  ,[POBoxLobby]
	  ,[TypeDeliveryService]
	  ,[NumberDeliveryService]
	  ,[Countycode]
	  ,[County]
	  ,[Townshipcode]
	  ,[Township]
	  ,[CuontyUpper]
	  ,[TownshipUpper]
	  ,[BusinessPurpose]
	  ,[DunsBradstreet]
	  ,[DUNSplus4]
	  ,Hashdiff
	  )
SELECT
	   A.[BusinessPartner]
	  ,A.NatBPAddresses_BK
	  ,A.IsDeleted
	  ,A.CreatedOn
	  ,A.ModifiedOn
	  ,A.ModifiedOn_UTC_epoch
	  ,A.[SalesOrganization]
      ,A.CustomerAccountGroup
	  ,A.ContactFunction
	  ,A.BPCategory
	  ,A.[AddressNumber]
	  ,A.[StrdAddress]
	  ,A.[AdrcAddressNumber]
	  ,A.[ValidFrom]
	  ,A.[IntAddress]
	  ,A.[ValidToDflt]
	  ,A.[title]
	  ,A.[Name1]
	  ,A.[name2]
	  ,A.[name3]
	  ,A.[name4]
	  ,A.[convertedName]
	  ,A.[COName]
	  ,A.[City]
	  ,A.[District]
	  ,A.[CityCode]
	  ,A.[CityCode2]
	  ,A.[City2]
	  ,A.[CityFTest]
	  ,A.[TestStatus]
	  ,A.[RegionalGroup]
	  ,A.[PostalCode1]
	  ,A.[PostalCode2]
	  ,A.[PostalCode3]
	  ,A.[PostalCode1ex]
	  ,A.[PostalCode2ex]
	  ,A.[PostalCode3ex]
	  ,A.[POBox]
	  ,A.[BoxWoutNo]
	  ,A.[POBoxcity]
	  ,A.[CITY_CODE2]
	  ,A.[RegionPOBox]
	  ,A.[POboxcountry]
	  ,A.[PostDeliveryDistrict]
	  ,A.[TranspZone]
	  ,A.[Street]
	  ,A.[StreetCity]
	  ,A.[AbbrStreet]
	  ,A.[HouseNumber]
	  ,A.[HouseSuppl]
	  ,A.[HouseRange]
	  ,A.[Street2]
	  ,A.[Street3]
	  ,A.[Street4]
	  ,A.[Street5]
	  ,A.[Building]
	  ,A.[Floor]
	  ,A.[Room]
	  ,A.[COUNTRY]
	  ,A.[Language]
	  ,A.[Region]
	  ,A.[AddressGroup]
	  ,A.[FlagGroup]
	  ,A.[flagPersADDR]
	  ,A.[SearchTerm1]
	  ,A.[SearchTerm2]
	  ,A.[PhoneticSearch]
	  ,A.[DfltCommMtd]
	  ,A.[FirstTel]
	  ,A.[TelExtension]
	  ,A.[FAX_NUMBER]
	  ,A.[FaxExtension]
	  ,A.[FlagTeldef]
	  ,A.[FlagFax]
	  ,A.[Flagteletex]
	  ,A.[Flagtelex]
	  ,A.[FlagEmail]
	  ,A.[FlagRML]
	  ,A.[FlagX400]
	  ,A.[FlagRFC]
	  ,A.[FlagPrinter]
	  ,A.[FlagSSF]
	  ,A.[FlagURI]
	  ,A.[Pager]
	  ,A.[AddressDataSource]
	  ,A.[NameUpper]
	  ,A.[CityUpper]
	  ,A.[StreetUpper]
	  ,A.[EXTENSIONDataLine]
	  ,A.[EXTENSIONTelebox]
	  ,A.[TIME_ZONE]
	  ,A.[TAXJURCODE]
	  ,A.[ADDRESS_ID]
	  ,A.[OrigLanguage]
	  ,A.[UUIDAddress]
	  ,A.[IndUUIDAddress]
	  ,A.[CategoryAddress]
	  ,A.[ErrorStatusAddress]
	  ,A.[POBoxLobby]
	  ,A.[TypeDeliveryService]
	  ,A.[NumberDeliveryService]
	  ,A.[Countycode]
	  ,A.[County]
	  ,A.[Townshipcode]
	  ,A.[Township]
	  ,A.[CuontyUpper]
	  ,A.[TownshipUpper]
	  ,A.[BusinessPurpose]
	  ,A.[DunsBradstreet]
	  ,A.[DUNSplus4]
	  ,A.Hashdiff

FROM #NatBPAddresses A
LEFT JOIN [ref].[NatBPAddresses_DS_v02] B ON A.NatBPAddresses_BK = B.NatBPAddresses_BK
WHERE B.NatBPAddresses_BK IS NULL

--Log count of inserted records
UPDATE DTlogs SET 
  Inserted = @AffectedRows
, ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId