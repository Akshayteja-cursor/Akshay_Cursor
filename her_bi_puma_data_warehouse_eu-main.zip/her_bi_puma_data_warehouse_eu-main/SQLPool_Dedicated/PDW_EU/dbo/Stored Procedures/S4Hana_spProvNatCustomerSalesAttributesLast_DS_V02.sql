﻿CREATE PROC [dbo].[S4Hana_spProvNatCustomerSalesAttributesLast_DS_V02] @LDTS [DATETIME2](7) AS

DECLARE @LoadDate DATETIME2(7) = GETDATE();

IF OBJECT_ID('tempdb..#NatCustomerSalesAttributes') IS NOT NULL DROP TABLE #NatCustomerSalesAttributes;

-- logging informations - BEGIN
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(0) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(0)
DECLARE @DestinationLastLoadDate DATETIME2(0)
DECLARE @BatchLdts DATETIME2(0) = @LDTS
DECLARE @AffectedRows BIGINT = NULL
-- logging Informations - END

-- get last LDTS Informations for Logging
IF(EXISTS(SELECT 1 FROM ref.NatCustomerSalesAttributes_DS_V02))
	BEGIN
		SELECT @DestinationLastLoadDate = CONVERT(DateTime, MAX(modifiedOn))
		FROM ref.NatCustomerSalesAttributes_DS_V02
	END
ELSE 
	BEGIN
		SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
	END 

IF(EXISTS(SELECT 1 FROM biz.[S4Hana_CustomerSalesAttributes]))
	BEGIN
		SELECT @SourceLastLoadDate = CONVERT(DateTime, MAX(LDTS))
		FROM biz.[S4Hana_CustomerSalesAttributes]
	END
ELSE 
	BEGIN
		SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
	END
-- Logging Informations END


-- Log first DATA Informations

INSERT INTO etl.DataTransferLogs
(
  DataTransferLogId
, TransferName
, TransferGroupName
, TargetTableName
, TargetSchemaName
, ExecStart
, SourceLastLoadDate
, DestinationLastLoadDate
, BatchLdts
)
SELECT 
  @DataTransferLogId 
, 'S4Hana_spProvNatCustomerSalesAttributesLast_DS_V02'
, 'NatCustomerSalesAttributes_DS_V02'
, 'NatCustomerSalesAttributes_DS_V02'
, 'ref'
, @ExecStart
, @SourceLastLoadDate
, @DestinationLastLoadDate
, @BatchLdts;

-- Log first DATA Informations END
WITH CTE AS
(
	SELECT
	CONCAT(A.Customer, '|', A.SalesOrganization, '|', A.DistributionChannel, '|', A.Division, '|',b.[CustomerAccountGroup]) AS NatCustomerSalesAttribute_BK
	  ,@LoadDate	AS CreatedOn
	  ,@LoadDate	AS ModifiedOn
	  ,a.[Customer]
	  ,b.[CustomerAccountGroup]
      ,a.[SalesOrganization]
	  ,a.CompanyCode
      ,a.[DistributionChannel]
      ,a.[Division]
      ,a.[CustomerABCClassification]
      ,a.[SalesOffice]
      ,a.[SalesGroup]
      ,a.[OrderIsBlockedForCustomer]
      ,a.[Currency]
      ,a.[CustomerPriceGroup]
      ,a.[PriceListType]
      ,a.[DeliveryPriority]
      ,a.[ShippingCondition]
      ,a.[IncotermsClassification]
      ,a.[SupplyingPlant]
      ,a.[CompleteDeliveryIsDefined]
      ,a.[DeliveryIsBlockedForCustomer]
      ,a.[BillingIsBlockedForCustomer]
      ,a.[CustomerPaymentTerms]
      ,a.[CustomerAccountAssignmentGroup]
      ,a.[AccountByCustomer]
      ,a.[CustomerGroup]
      ,a.[CustomerGroupName]
      ,a.[CustomerPricingProcedure]
      ,a.[OrderCombinationIsAllowed]
      ,a.[PartialDeliveryIsAllowed]
      ,a.[InvoiceDate]
      ,a.[PaymentTerms]
      ,a.[IncotermsTransferLocation]
      ,a.[ItemOrderProbabilityInPercent]
      ,a.[IncotermsLocation2]
      ,a.[AuthorizationGroup]
      ,a.[SalesDistrict]
      ,a.[IncotermsVersion]
      ,a.[IncotermsLocation1]
      ,a.[DeletionIndicator]
      ,a.[IsBusinessPurposeCompleted]
      ,a.[SalesItemProposal]
      ,a.[CustProdProposalProcedure]
      ,a.[MaxNmbrOfPartialDelivery]
      ,a.[UnderdelivTolrtdLmtRatioInPct]
      ,a.[OverdelivTolrtdLmtRatioInPct]
      ,a.[IsActiveEntity]
      ,a.[AdditionalCustomerGroup1]
      ,a.[AdditionalCustomerGroup2]
      ,a.[AdditionalCustomerGroup3]
      ,a.[AdditionalCustomerGroup4]
      ,a.[AdditionalCustomerGroup5]
      ,a.[InvoiceListSchedule]
      ,a.[ExchangeRateType]
      ,a.[PaymentGuaranteeProcedure]
      ,a.[DeliverySplitStrategy]
      ,a.[InvoiceSplitStrategy]
      ,a.[TermsOfPayment]
      ,a.[SalesRepType]
      ,a.[B2BOrderHistory]
      ,a.[OrderNumber]
      ,a.[CostCenter]
      ,a.[RetCreditNoteSStrategy]
      ,a.[DC10SportsSpecial]
      ,a.[DC20Sports]
      ,a.[DC30SportStyle]
      ,a.[DC40SportLifest]
      ,a.[DC50Lifestyle]
      ,a.[DC60Fashion]
      ,a.[DC35SportStylePlus]
      ,a.[DC45LifestylePlus]
      ,a.[DC90Distributer]
      ,a.[DC90B2B]
      ,a.[DC92InternalSales]
      ,a.[DC93MonobrandFranchiseStore]
      ,a.[DC94MassMerchant]
      ,a.[DC95Clearance]
      ,a.[DC99Others]
      ,a.[DC31Performance]
      ,a.[PumaDistributionChannel]
      ,a.[LocalCustomerGroup]
      ,a.[AreaAccount]
      ,a.[AccountRole]
      ,a.[CustomerStructure]
      ,a.[MainCustomer]
      ,a.[MasterCustomer]
      ,a.[ReportingGroup10]
      ,a.[LaunchDateBuffer]
      ,a.[Specialist]
      ,a.[NeveroutofStock]
      ,a.[LocalOwnerGroup]
      ,a.[TeamBusinessSpecIdentification]
      ,a.[ShopName]
      ,a.[AccountType]
      ,a.[EDI]
      ,a.[CallCenterCampaign]
      ,a.[CommercialOperations]
      ,a.[EarlyShipment]
      ,a.[RestrictProdAccess]
      ,a.[RetailAdditionalCustomerGrp6]
      ,a.[RetailAdditionalCustomerGrp7]
      ,a.[RetailAdditionalCustomerGrp8]
      ,a.[RetailAdditionalCustomerGrp9]
      ,a.[RetailAdditionalCustomerGrp10]
      ,a.[credit_limit]
      ,a.[xblocked]
      ,a.[block_reason]
      ,a.[CreditControlArea]
      ,a.[Postingblockforcompanycode]
      ,a.[DeletionFlagCompanyCodeLevel]
      ,a.[BlockKeyforPayment]
      ,a.[DunningArea]
      ,a.[DunningBlock]
      ,a.[IsDeleted]
	FROM biz.[S4Hana_CustomerSalesAttributes] a
  LEFT JOIN biz.[S4Hana_Customers] b on a.customer=b.customer
  --INNER JOIN [pdwref].[AreaCodeMapping] acm on a.[SalesOrganization]= acm.SalesOrganization
	WHERE
	A.LDTS >= @LDTS 
	OR B.LDTS >= @LDTS
	
)

--Insert to temp table
SELECT
  NatCustomerSalesAttribute_BK
	  ,CreatedOn
	  ,ModifiedOn
	  ,[Customer]
	  ,[CustomerAccountGroup]
      ,[SalesOrganization]
	  ,CompanyCode
      ,[DistributionChannel]
      ,[Division]
      ,[CustomerABCClassification]
      ,[SalesOffice]
      ,[SalesGroup]
      ,[OrderIsBlockedForCustomer]
      ,[Currency]
      ,[CustomerPriceGroup]
      ,[PriceListType]
      ,[DeliveryPriority]
      ,[ShippingCondition]
      ,[IncotermsClassification]
      ,[SupplyingPlant]
      ,[CompleteDeliveryIsDefined]
      ,[DeliveryIsBlockedForCustomer]
      ,[BillingIsBlockedForCustomer]
      ,[CustomerPaymentTerms]
      ,[CustomerAccountAssignmentGroup]
      ,[AccountByCustomer]
      ,[CustomerGroup]
      ,[CustomerGroupName]
      ,[CustomerPricingProcedure]
      ,[OrderCombinationIsAllowed]
      ,[PartialDeliveryIsAllowed]
      ,[InvoiceDate]
      ,[PaymentTerms]
      ,[IncotermsTransferLocation]
      ,[ItemOrderProbabilityInPercent]
      ,[IncotermsLocation2]
      ,[AuthorizationGroup]
      ,[SalesDistrict]
      ,[IncotermsVersion]
      ,[IncotermsLocation1]
      ,[DeletionIndicator]
      ,[IsBusinessPurposeCompleted]
      ,[SalesItemProposal]
      ,[CustProdProposalProcedure]
      ,[MaxNmbrOfPartialDelivery]
      ,[UnderdelivTolrtdLmtRatioInPct]
      ,[OverdelivTolrtdLmtRatioInPct]
      ,[IsActiveEntity]
      ,[AdditionalCustomerGroup1]
      ,[AdditionalCustomerGroup2]
      ,[AdditionalCustomerGroup3]
      ,[AdditionalCustomerGroup4]
      ,[AdditionalCustomerGroup5]
      ,[InvoiceListSchedule]
      ,[ExchangeRateType]
      ,[PaymentGuaranteeProcedure]
      ,[DeliverySplitStrategy]
      ,[InvoiceSplitStrategy]
      ,[TermsOfPayment]
      ,[SalesRepType]
      ,[B2BOrderHistory]
      ,[OrderNumber]
      ,[CostCenter]
      ,[RetCreditNoteSStrategy]
      ,[DC10SportsSpecial]
      ,[DC20Sports]
      ,[DC30SportStyle]
      ,[DC40SportLifest]
      ,[DC50Lifestyle]
      ,[DC60Fashion]
      ,[DC35SportStylePlus]
      ,[DC45LifestylePlus]
      ,[DC90Distributer]
      ,[DC90B2B]
      ,[DC92InternalSales]
      ,[DC93MonobrandFranchiseStore]
      ,[DC94MassMerchant]
      ,[DC95Clearance]
      ,[DC99Others]
      ,[DC31Performance]
      ,[PumaDistributionChannel]
      ,[LocalCustomerGroup]
      ,[AreaAccount]
      ,[AccountRole]
      ,[CustomerStructure]
      ,[MainCustomer]
      ,[MasterCustomer]
      ,[ReportingGroup10]
      ,[LaunchDateBuffer]
      ,[Specialist]
      ,[NeveroutofStock]
      ,[LocalOwnerGroup]
      ,[TeamBusinessSpecIdentification]
      ,[ShopName]
      ,[AccountType]
      ,[EDI]
      ,[CallCenterCampaign]
      ,[CommercialOperations]
      ,[EarlyShipment]
      ,[RestrictProdAccess]
      ,[RetailAdditionalCustomerGrp6]
      ,[RetailAdditionalCustomerGrp7]
      ,[RetailAdditionalCustomerGrp8]
      ,[RetailAdditionalCustomerGrp9]
      ,[RetailAdditionalCustomerGrp10]
      ,[credit_limit]
      ,[xblocked]
      ,[block_reason]
      ,[CreditControlArea]
      ,[Postingblockforcompanycode]
      ,[DeletionFlagCompanyCodeLevel]
      ,[BlockKeyforPayment]
      ,[DunningArea]
      ,[DunningBlock]
      ,[IsDeleted]
, CONVERT([BINARY](16), HASHBYTES('MD5',CONCAT(
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), NatCustomerSalesAttribute_BK)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [Customer]	)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [CustomerAccountGroup]	)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [SalesOrganization]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CompanyCode	)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DistributionChannel]	)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [Division]	)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [CustomerABCClassification])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [SalesOffice])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [SalesGroup]	)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [OrderIsBlockedForCustomer])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [Currency]	)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [CustomerPriceGroup]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [PriceListType])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DeliveryPriority]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [ShippingCondition]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [IncotermsClassification])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [SupplyingPlant])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [CompleteDeliveryIsDefined])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DeliveryIsBlockedForCustomer]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [BillingIsBlockedForCustomer]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [CustomerPaymentTerms]	)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [CustomerAccountAssignmentGroup]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [AccountByCustomer]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [CustomerGroup])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [CustomerGroupName]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [CustomerPricingProcedure])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [OrderCombinationIsAllowed])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [PartialDeliveryIsAllowed])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [InvoiceDate])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [PaymentTerms])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [IncotermsTransferLocation])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [ItemOrderProbabilityInPercent]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [IncotermsLocation2]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [AuthorizationGroup]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [SalesDistrict])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [IncotermsVersion]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [IncotermsLocation1]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DeletionIndicator]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [IsBusinessPurposeCompleted])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [SalesItemProposal]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [CustProdProposalProcedure])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [MaxNmbrOfPartialDelivery])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [UnderdelivTolrtdLmtRatioInPct]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [OverdelivTolrtdLmtRatioInPct]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [IsActiveEntity])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [AdditionalCustomerGroup1])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [AdditionalCustomerGroup2])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [AdditionalCustomerGroup3])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [AdditionalCustomerGroup4])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [AdditionalCustomerGroup5])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [InvoiceListSchedule]	)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [ExchangeRateType]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [PaymentGuaranteeProcedure])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DeliverySplitStrategy]	)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [InvoiceSplitStrategy]	)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [TermsOfPayment])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [SalesRepType])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [B2BOrderHistory]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [OrderNumber])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [CostCenter]	)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [RetCreditNoteSStrategy]	)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DC10SportsSpecial]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DC20Sports]	)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DC30SportStyle])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DC40SportLifest]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DC50Lifestyle])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DC60Fashion])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DC35SportStylePlus]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DC45LifestylePlus]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DC90Distributer]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DC90B2B]	)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DC92InternalSales]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DC93MonobrandFranchiseStore]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DC94MassMerchant]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DC95Clearance])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DC99Others]	)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DC31Performance]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [PumaDistributionChannel])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [LocalCustomerGroup]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [AreaAccount])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [AccountRole])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [CustomerStructure]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [MainCustomer])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [MasterCustomer])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [ReportingGroup10]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [LaunchDateBuffer]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [Specialist]	)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [NeveroutofStock]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [LocalOwnerGroup]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [TeamBusinessSpecIdentification]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [ShopName]	)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [AccountType])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [EDI]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [CallCenterCampaign]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [CommercialOperations]	)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [EarlyShipment])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [RestrictProdAccess]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [RetailAdditionalCustomerGrp6]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [RetailAdditionalCustomerGrp7]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [RetailAdditionalCustomerGrp8]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [RetailAdditionalCustomerGrp9]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [RetailAdditionalCustomerGrp10]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [credit_limit])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [xblocked]	)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [block_reason])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [CreditControlArea]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [Postingblockforcompanycode])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DeletionFlagCompanyCodeLevel]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [BlockKeyforPayment]		)))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DunningArea])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [DunningBlock])))),'_',
		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), [IsDeleted]))))
	))) AS HashDiff

INTO #NatCustomerSalesAttributes
FROM CTE

--Count Records to be updated
SELECT @AffectedRows = COUNT(*)
FROM ref.NatCustomerSalesAttributes_DS_V02 A
INNER JOIN #NatCustomerSalesAttributes B ON A.NatCustomerSalesAttribute_BK = B.NatCustomerSalesAttribute_BK
WHERE A.HashDiff <> B.HashDiff

--Update Final Table
UPDATE A SET
  A.ModifiedOn = @LoadDate
, A.CustomerAccountGroup = B.CustomerAccountGroup
, A.CustomerABCClassification = B.CustomerABCClassification
, A.SalesOffice						= B.SalesOffice
, A.SalesGroup						= B.SalesGroup
, A.OrderIsBlockedForCustomer			= B.OrderIsBlockedForCustomer
, A.Currency							= B.Currency
, A.CustomerPriceGroup				= B.CustomerPriceGroup
, A.PriceListType						= B.PriceListType
, A.DeliveryPriority					= B.DeliveryPriority
, A.ShippingCondition					= B.ShippingCondition
, A.IncotermsClassification			= B.IncotermsClassification
, A.SupplyingPlant					= B.SupplyingPlant
, A.CompleteDeliveryIsDefined			= B.CompleteDeliveryIsDefined
, A.DeliveryIsBlockedForCustomer		= B.DeliveryIsBlockedForCustomer
, A.BillingIsBlockedForCustomer		= B.BillingIsBlockedForCustomer
, A.CustomerPaymentTerms				= B.CustomerPaymentTerms
, A.CustomerAccountAssignmentGroup	= B.CustomerAccountAssignmentGroup
, A.AccountByCustomer					= B.AccountByCustomer
, A.CustomerGroup						= B.CustomerGroup
, A.CustomerGroupName					= B.CustomerGroupName
, A.CustomerPricingProcedure			= B.CustomerPricingProcedure
, A.OrderCombinationIsAllowed			= B.OrderCombinationIsAllowed
, A.PartialDeliveryIsAllowed			= B.PartialDeliveryIsAllowed
, A.InvoiceDate						= B.InvoiceDate
, A.PaymentTerms						= B.PaymentTerms
, A.IncotermsTransferLocation			= B.IncotermsTransferLocation
, A.ItemOrderProbabilityInPercent		= B.ItemOrderProbabilityInPercent
, A.IncotermsLocation2				= B.IncotermsLocation2
, A.AuthorizationGroup				= B.AuthorizationGroup
, A.SalesDistrict						= B.SalesDistrict
, A.IncotermsVersion					= B.IncotermsVersion
, A.IncotermsLocation1				= B.IncotermsLocation1
, A.DeletionIndicator					= B.DeletionIndicator
, A.IsBusinessPurposeCompleted		= B.IsBusinessPurposeCompleted
, A.SalesItemProposal					= B.SalesItemProposal
, A.CustProdProposalProcedure			= B.CustProdProposalProcedure
, A.MaxNmbrOfPartialDelivery			= B.MaxNmbrOfPartialDelivery
, A.UnderdelivTolrtdLmtRatioInPct		= B.UnderdelivTolrtdLmtRatioInPct
, A.OverdelivTolrtdLmtRatioInPct		= B.OverdelivTolrtdLmtRatioInPct
, A.IsActiveEntity					= B.IsActiveEntity
, A.AdditionalCustomerGroup1			= B.AdditionalCustomerGroup1
, A.AdditionalCustomerGroup2			= B.AdditionalCustomerGroup2
, A.AdditionalCustomerGroup3			= B.AdditionalCustomerGroup3
, A.AdditionalCustomerGroup4			= B.AdditionalCustomerGroup4
, A.AdditionalCustomerGroup5			= B.AdditionalCustomerGroup5
, A.InvoiceListSchedule				= B.InvoiceListSchedule
, A.ExchangeRateType					= B.ExchangeRateType
, A.PaymentGuaranteeProcedure			= B.PaymentGuaranteeProcedure
, A.DeliverySplitStrategy				= B.DeliverySplitStrategy
, A.InvoiceSplitStrategy				= B.InvoiceSplitStrategy
, A.TermsOfPayment					= B.TermsOfPayment
, A.SalesRepType						= B.SalesRepType
, A.B2BOrderHistory					= B.B2BOrderHistory
, A.OrderNumber						= B.OrderNumber
, A.CostCenter						= B.CostCenter
, A.RetCreditNoteSStrategy			= B.RetCreditNoteSStrategy
, A.DC10SportsSpecial					= B.DC10SportsSpecial
, A.DC20Sports						= B.DC20Sports
, A.DC30SportStyle					= B.DC30SportStyle
, A.DC40SportLifest					= B.DC40SportLifest
, A.DC50Lifestyle						= B.DC50Lifestyle
, A.DC60Fashion						= B.DC60Fashion
, A.DC35SportStylePlus				= B.DC35SportStylePlus
, A.DC45LifestylePlus					= B.DC45LifestylePlus
, A.DC90Distributer					= B.DC90Distributer
, A.DC90B2B							= B.DC90B2B
, A.DC92InternalSales					= B.DC92InternalSales
, A.DC93MonobrandFranchiseStore		= B.DC93MonobrandFranchiseStore
, A.DC94MassMerchant					= B.DC94MassMerchant
, A.DC95Clearance						= B.DC95Clearance
, A.DC99Others						= B.DC99Others
, A.DC31Performance					= B.DC31Performance
, A.PumaDistributionChannel			= B.PumaDistributionChannel
, A.LocalCustomerGroup				= B.LocalCustomerGroup
, A.AreaAccount						= B.AreaAccount
, A.AccountRole						= B.AccountRole
, A.CustomerStructure					= B.CustomerStructure
, A.MainCustomer						= B.MainCustomer
, A.MasterCustomer					= B.MasterCustomer
, A.ReportingGroup10					= B.ReportingGroup10
, A.LaunchDateBuffer					= B.LaunchDateBuffer
, A.Specialist						= B.Specialist
, A.NeveroutofStock					= B.NeveroutofStock
, A.LocalOwnerGroup					= B.LocalOwnerGroup
, A.TeamBusinessSpecIdentification	= B.TeamBusinessSpecIdentification
, A.ShopName							= B.ShopName
, A.AccountType						= B.AccountType
, A.EDI								= B.EDI
, A.CallCenterCampaign				= B.CallCenterCampaign
, A.CommercialOperations				= B.CommercialOperations
, A.EarlyShipment						= B.EarlyShipment
, A.RestrictProdAccess				= B.RestrictProdAccess
, A.RetailAdditionalCustomerGrp6		= B.RetailAdditionalCustomerGrp6
, A.RetailAdditionalCustomerGrp7		= B.RetailAdditionalCustomerGrp7
, A.RetailAdditionalCustomerGrp8		= B.RetailAdditionalCustomerGrp8
, A.RetailAdditionalCustomerGrp9		= B.RetailAdditionalCustomerGrp9
, A.RetailAdditionalCustomerGrp10		= B.RetailAdditionalCustomerGrp10
, A.credit_limit						= B.credit_limit
, A.xblocked							= B.xblocked
, A.block_reason						= B.block_reason
, A.CreditControlArea					= B.CreditControlArea
, A.Postingblockforcompanycode		= B.Postingblockforcompanycode
, A.DeletionFlagCompanyCodeLevel		= B.DeletionFlagCompanyCodeLevel
, A.BlockKeyforPayment				= B.BlockKeyforPayment
, A.DunningArea						= B.DunningArea
, A.DunningBlock						= B.DunningBlock
, A.IsDeleted							= B.IsDeleted
,A.HashDiff  = B.HashDiff

FROM ref.NatCustomerSalesAttributes_DS_V02 A
INNER JOIN #NatCustomerSalesAttributes B ON A.NatCustomerSalesAttribute_BK = B.NatCustomerSalesAttribute_BK
WHERE A.HashDiff <> B.HashDiff and B.IsDeleted = 0

--update deletion status
UPDATE A SET
	   A.ModifiedOn = @LoadDate
	  ,A.IsDeleted = 1
	  ,A.HashDiff  = B.HashDiff

FROM ref.NatCustomerSalesAttributes_DS_V02 A
INNER JOIN #NatCustomerSalesAttributes B ON A.NatCustomerSalesAttribute_BK = B.NatCustomerSalesAttribute_BK
WHERE A.HashDiff <> B.HashDiff and B.IsDeleted = 1

--Log count of updated records
UPDATE DTlogs SET
  Updated = @AffectedRows
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId

--Count Records to be inserted
SELECT @AffectedRows = COUNT(*)
FROM #NatCustomerSalesAttributes A
LEFT JOIN ref.NatCustomerSalesAttributes_DS_V02 B ON A.NatCustomerSalesAttribute_BK = B.NatCustomerSalesAttribute_BK
WHERE B.NatCustomerSalesAttribute_BK IS NULL

--Insert to Final Table
INSERT INTO ref.NatCustomerSalesAttributes_DS_V02
(
   NatCustomerSalesAttribute_BK
      ,IsDeleted
      ,ModifiedOn
      ,CreatedOn
	  ,Customer
      ,CustomerAccountGroup
      ,SalesOrganization
      ,CompanyCode
      ,DistributionChannel
      ,Division
      ,CustomerABCClassification
      ,SalesOffice
      ,SalesGroup
      ,OrderIsBlockedForCustomer
      ,Currency
      ,CustomerPriceGroup
      ,PriceListType
      ,DeliveryPriority
      ,ShippingCondition
      ,IncotermsClassification
      ,SupplyingPlant
      ,CompleteDeliveryIsDefined
      ,DeliveryIsBlockedForCustomer
      ,BillingIsBlockedForCustomer
      ,CustomerPaymentTerms
      ,CustomerAccountAssignmentGroup
      ,AccountByCustomer
      ,CustomerGroup
      ,CustomerGroupName
      ,CustomerPricingProcedure
      ,OrderCombinationIsAllowed
      ,PartialDeliveryIsAllowed
      ,InvoiceDate
      ,PaymentTerms
      ,IncotermsTransferLocation
      ,ItemOrderProbabilityInPercent
      ,IncotermsLocation2
      ,AuthorizationGroup
      ,SalesDistrict
      ,IncotermsVersion
      ,IncotermsLocation1
      ,DeletionIndicator
      ,IsBusinessPurposeCompleted
      ,SalesItemProposal
      ,CustProdProposalProcedure
      ,MaxNmbrOfPartialDelivery
      ,UnderdelivTolrtdLmtRatioInPct
      ,OverdelivTolrtdLmtRatioInPct
      ,IsActiveEntity
      ,AdditionalCustomerGroup1
      ,AdditionalCustomerGroup2
      ,AdditionalCustomerGroup3
      ,AdditionalCustomerGroup4
      ,AdditionalCustomerGroup5
      ,InvoiceListSchedule
      ,ExchangeRateType
      ,PaymentGuaranteeProcedure
      ,DeliverySplitStrategy
      ,InvoiceSplitStrategy
      ,TermsOfPayment
      ,SalesRepType
      ,B2BOrderHistory
      ,OrderNumber
      ,CostCenter
      ,RetCreditNoteSStrategy
      ,DC10SportsSpecial
      ,DC20Sports
      ,DC30SportStyle
      ,DC40SportLifest
      ,DC50Lifestyle
      ,DC60Fashion
      ,DC35SportStylePlus
      ,DC45LifestylePlus
      ,DC90Distributer
      ,DC90B2B
      ,DC92InternalSales
      ,DC93MonobrandFranchiseStore
      ,DC94MassMerchant
      ,DC95Clearance
      ,DC99Others
      ,DC31Performance
      ,PumaDistributionChannel
      ,LocalCustomerGroup
      ,AreaAccount
      ,AccountRole
      ,CustomerStructure
      ,MainCustomer
      ,MasterCustomer
      ,ReportingGroup10
      ,LaunchDateBuffer
      ,Specialist
      ,NeveroutofStock
      ,LocalOwnerGroup
      ,TeamBusinessSpecIdentification
      ,ShopName
      ,AccountType
      ,EDI
      ,CallCenterCampaign
      ,CommercialOperations
      ,EarlyShipment
      ,RestrictProdAccess
      ,RetailAdditionalCustomerGrp6
      ,RetailAdditionalCustomerGrp7
      ,RetailAdditionalCustomerGrp8
      ,RetailAdditionalCustomerGrp9
      ,RetailAdditionalCustomerGrp10
      ,credit_limit
      ,xblocked
      ,block_reason
      ,CreditControlArea
      ,Postingblockforcompanycode
      ,DeletionFlagCompanyCodeLevel
      ,BlockKeyforPayment
      ,DunningArea
      ,DunningBlock
      ,HashDiff
)
SELECT
  A.NatCustomerSalesAttribute_BK
      ,A.IsDeleted
      ,A.ModifiedOn
      ,A.CreatedOn
	  ,A.Customer
      ,A.CustomerAccountGroup
      ,A.SalesOrganization
      ,A.CompanyCode
      ,A.DistributionChannel
      ,A.Division
      ,A.CustomerABCClassification
      ,A.SalesOffice
      ,A.SalesGroup
      ,A.OrderIsBlockedForCustomer
      ,A.Currency
      ,A.CustomerPriceGroup
      ,A.PriceListType
      ,A.DeliveryPriority
      ,A.ShippingCondition
      ,A.IncotermsClassification
      ,A.SupplyingPlant
      ,A.CompleteDeliveryIsDefined
      ,A.DeliveryIsBlockedForCustomer
      ,A.BillingIsBlockedForCustomer
      ,A.CustomerPaymentTerms
      ,A.CustomerAccountAssignmentGroup
      ,A.AccountByCustomer
      ,A.CustomerGroup
      ,A.CustomerGroupName
      ,A.CustomerPricingProcedure
      ,A.OrderCombinationIsAllowed
      ,A.PartialDeliveryIsAllowed
      ,A.InvoiceDate
      ,A.PaymentTerms
      ,A.IncotermsTransferLocation
      ,A.ItemOrderProbabilityInPercent
      ,A.IncotermsLocation2
      ,A.AuthorizationGroup
      ,A.SalesDistrict
      ,A.IncotermsVersion
      ,A.IncotermsLocation1
      ,A.DeletionIndicator
      ,A.IsBusinessPurposeCompleted
      ,A.SalesItemProposal
      ,A.CustProdProposalProcedure
      ,A.MaxNmbrOfPartialDelivery
      ,A.UnderdelivTolrtdLmtRatioInPct
      ,A.OverdelivTolrtdLmtRatioInPct
      ,A.IsActiveEntity
      ,A.AdditionalCustomerGroup1
      ,A.AdditionalCustomerGroup2
      ,A.AdditionalCustomerGroup3
      ,A.AdditionalCustomerGroup4
      ,A.AdditionalCustomerGroup5
      ,A.InvoiceListSchedule
      ,A.ExchangeRateType
      ,A.PaymentGuaranteeProcedure
      ,A.DeliverySplitStrategy
      ,A.InvoiceSplitStrategy
      ,A.TermsOfPayment
      ,A.SalesRepType
      ,A.B2BOrderHistory
      ,A.OrderNumber
      ,A.CostCenter
      ,A.RetCreditNoteSStrategy
      ,A.DC10SportsSpecial
      ,A.DC20Sports
      ,A.DC30SportStyle
      ,A.DC40SportLifest
      ,A.DC50Lifestyle
      ,A.DC60Fashion
      ,A.DC35SportStylePlus
      ,A.DC45LifestylePlus
      ,A.DC90Distributer
      ,A.DC90B2B
      ,A.DC92InternalSales
      ,A.DC93MonobrandFranchiseStore
      ,A.DC94MassMerchant
      ,A.DC95Clearance
      ,A.DC99Others
      ,A.DC31Performance
      ,A.PumaDistributionChannel
      ,A.LocalCustomerGroup
      ,A.AreaAccount
      ,A.AccountRole
      ,A.CustomerStructure
      ,A.MainCustomer
      ,A.MasterCustomer
      ,A.ReportingGroup10
      ,A.LaunchDateBuffer
      ,A.Specialist
      ,A.NeveroutofStock
      ,A.LocalOwnerGroup
      ,A.TeamBusinessSpecIdentification
      ,A.ShopName
      ,A.AccountType
      ,A.EDI
      ,A.CallCenterCampaign
      ,A.CommercialOperations
      ,A.EarlyShipment
      ,A.RestrictProdAccess
      ,A.RetailAdditionalCustomerGrp6
      ,A.RetailAdditionalCustomerGrp7
      ,A.RetailAdditionalCustomerGrp8
      ,A.RetailAdditionalCustomerGrp9
      ,A.RetailAdditionalCustomerGrp10
      ,A.credit_limit
      ,A.xblocked
      ,A.block_reason
      ,A.CreditControlArea
      ,A.Postingblockforcompanycode
      ,A.DeletionFlagCompanyCodeLevel
      ,A.BlockKeyforPayment
      ,A.DunningArea
      ,A.DunningBlock
      ,A.HashDiff
FROM #NatCustomerSalesAttributes A
LEFT JOIN ref.NatCustomerSalesAttributes_DS_V02 B ON A.NatCustomerSalesAttribute_BK = B.NatCustomerSalesAttribute_BK
WHERE B.NatCustomerSalesAttribute_BK IS NULL

--Log count of inserted records
UPDATE DTlogs SET 
  Inserted = @AffectedRows
, ExecEnd = GETDATE()
FROM etl.DataTransferLogs DTlogs
WHERE DataTransferLogId = @DataTransferLogId