﻿CREATE PROC [dbo].[S4Hana_spProvNatCopaDetails] @ldts [VARCHAR](255) AS
BEGIN

	--SET NOCOUNT ON;
	SET ANSI_WARNINGS ON;

	DECLARE @LDTSDate DATETIME = CAST(CAST(@ldts AS DATETIME2) AS DATETIME);
	DECLARE @LoadDate SMALLDATETIME = GETDATE();

	IF OBJECT_ID('tempdb..#TMP_STAG_COPA') IS NOT NULL DROP TABLE #TMP_STAG_COPA;


	;WITH CTE0 AS (      
			SELECT 
			  co.CompanyCode
			  ,co.AccountingDocNo
			  ,co.ReferenceDocNo
			  ,co.ReferenceDocItemNo
			  ,co.ReferenceDocumentType
			  ,COALESCE(co.MaterialNumber,'') AS NatMaterialNo   
			  ,co.FiscalYear
			  ,co.ProfitCenterCode
			  ,co.NatSalesOrderNo  
			  ,co.NatSalesOrderItemNo   
			  ,d1.DateKey									AS CreationDate  
			  ,d2.DateKey									AS PostingDate
			  ,co.BrandCode
			  ,co.RBUCode
			  ,co.RefRBUCode   
			  ,co.BusSegmentCode
			  ,co.BusSubSegmentCode
			  ,co.DistributionChannelCode
			  ,CAST(COALESCE(TRY_CAST(co.ProdDivCode  AS INT), 0) AS INT)	AS ProdDivCode 
			  ,COALESCE(co.SalesRep,'')										AS SalesRep 	
			  ,COALESCE(co.CustomerCode_SoldTo,'')							AS CustomerCode_SoldTo
			  ,COALESCE(co.CustomerCode_ShipTo,'')							AS CustomerCode_ShipTo	
			  ,COALESCE(co.Payer,'')										AS Payer 
			  ,COALESCE(co.CustomerCode_OwnerGroup,'')						AS CustomerCode_OwnerGroup
			  ,COALESCE(co.CustomerCode_BillTo,'')							AS CustomerCode_BillTo
			  ,COALESCE(co.Plant,'')										AS Plant
			  ,COALESCE(co.DiscountReasonCode,'')							AS DiscountReasonCode   
			  ,co.CurrencyCode
			  ,co.GroupKey
			  ,co.SOTypeCode												AS NatSOTypeCode
			  ,co.BillingDocTypeCode										AS NatInvoiceTypeCode
			  ,ref.BusinessClassCode
			  ,COALESCE(CAST(co.AmountInCompanyCodeCurrency AS DECIMAL(24,12)),0) * (-1)AS AmountInCompanyCodeCurrency
			  ,COALESCE(CAST(co.Quantity AS DECIMAL(24,12)),0) * (-1)				    AS Quantity 
			  ,tg.SemanticTag
			  ,co.ProfitCenter      
			  ,co.OrderID			
			  ,co.CostCenter		
			  ,co.AccountingDocument
			  ,Concat(co.SeasonYear,co.Season)								AS CoPaSeason --new implementation  commented for now we found discrepancies in existing old invoices
			  ,co.SalesOrganization
			FROM stag.S4Hana_vCopaSemanticTags tg	JOIN stag.S4Hana_fnCopaRaw(@LDTSDate) co		ON tg.GLAccount = co.GLAccount AND tg.ChartOfAccounts = co.ChartOfAccounts
													JOIN pdwref.S4Hana_COPA_BillTypeBusClass ref	ON ref.BillingDocTypeCode	= co.BillingDocTypeCode
													JOIN pdwref.S4Hana_COPA_ActiveSemanticTags atg	ON atg.SemanticTag			= tg.SemanticTag AND atg.IsActive = 1	
											   LEFT JOIN ref.DimDate d1 ON d1.CalendarDate = co.CreationDate
											   LEFT JOIN ref.DimDate d2 ON d2.CalendarDate = co.PostingDate
			),
	 ---- create "basic/atomic" KPI fieds 
		CTEtag_to_fields AS (
		SELECT 	
		  cte.CompanyCode
		  ,cte.SalesOrganization
		  ,cte.AccountingDocNo
		  ,cte.ReferenceDocNo
		  ,cte.ReferenceDocItemNo
		  ,cte.ReferenceDocumentType
		  ,cte.NatMaterialNo
		  ,cte.FiscalYear
		  ,cte.ProfitCenterCode
		  ,cte.NatSalesOrderNo  
		  ,cte.NatSalesOrderItemNo  
		  ,cte.CreationDate  
		  ,cte.PostingDate
		  ,cte.BrandCode
		  ,cte.RBUCode
		  ,cte.RefRBUCode   
		  ,cte.BusSegmentCode
		  ,cte.BusSubSegmentCode
		  ,cte.DistributionChannelCode
		  ,cte.ProdDivCode  
		  ,cte.SalesRep
		  ,cte.CustomerCode_SoldTo
		  ,cte.CustomerCode_ShipTo 
		  ,cte.Payer
		  ,cte.CustomerCode_OwnerGroup 
		  ,cte.CustomerCode_BillTo
		  ,cte.Plant
		  ,cte.DiscountReasonCode    
		  ,cte.CurrencyCode
		  ,cte.GroupKey
		  ,cte.NatSOTypeCode  --SOTypeCode
		  ,cte.NatInvoiceTypeCode
		  ,cte.BusinessClassCode
		  ,cte.ProfitCenter      
		  ,cte.OrderID			
		  ,cte.CostCenter		
		  ,cte.AccountingDocument
		  ,cte.CoPaSeason
		  ,CASE WHEN cte.SemanticTag IN ('ZR3017GS3P','ZR3018GSIC','ZR3020GSBF')THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS GrossSalesLC
		  ,CASE WHEN cte.SemanticTag IN ('ZR3017GS3P','ZR3018GSIC','ZR3020GSBF')THEN cte.Quantity					 ELSE 0 END AS GrossSalesUnits 
		  ,CASE WHEN cte.SemanticTag IN ('ZR3024OIDS','ZR3026OIDI')				THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS OnInvoicePriceReductionsLC
		  ,CASE WHEN cte.SemanticTag IN ('ZR3024OIDS','ZR3026OIDI')				THEN cte.Quantity					 ELSE 0 END AS OnInvoicePriceReductionsUnits 
		  ,CASE WHEN cte.SemanticTag IN ('ZR3032SMSP','ZR3033GRSB'/*'ZR3034DELP'*/,'ZR3038OIDA')THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS OffInvoicePriceReductionsLC
		  ,CASE WHEN cte.SemanticTag IN ('ZR3035RETM')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS RetailMarkdownLC
		  ,CASE WHEN cte.SemanticTag IN ('ZR3035RETM')							THEN cte.Quantity					 ELSE 0 END AS RetailMarkdownUnits 
		  --,CASE WHEN cte.SemanticTag IN ('ZR3038OIDA')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS OffInvoiceDiscAdjustmentsLC
		  ,CASE WHEN cte.SemanticTag IN ('ZR3040RASL')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS SalesAdjustmentsReturnProvisionLC
		  ,CASE WHEN cte.SemanticTag IN ('ZR3152OSA')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS OtherSalesAdjustmentsLC
		  ,CASE WHEN cte.SemanticTag IN ('ZR3041NSTP','ZR3042NSIC','ZR3044NSIF')THEN cte.Quantity					 ELSE 0 END AS NetSalesUnits
		  ,CASE WHEN cte.SemanticTag IN ('ZR3041NSTP','ZR3042NSIC','ZR3044NSIF')THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS NetSalesLC
		  ,CASE WHEN cte.SemanticTag IN ('ZR3046CFTP','ZR3062CFIC','ZR3066CBMP')THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS CogsAtFPriceLC
		  ,CASE WHEN cte.SemanticTag IN ('ZR3059ICCM')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS IcCogsChargesAndMarkupLC  
		  ,CASE WHEN cte.SemanticTag IN ('ZR3069SHRT')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS ShortageLC
		  ,CASE WHEN cte.SemanticTag IN ('ZR3073CIIR')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS ChangeInInventoryReserveLC
		  ,CASE WHEN cte.SemanticTag IN ('ZR3153OCA')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS CogsOtherAdjustmentsLC
		  ,CASE WHEN cte.SemanticTag IN ('ZR3077RACG')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS CogsAdjustmentsReturnsLC
		  --For Calculated KPIs:
		  ,CASE WHEN cte.SemanticTag IN ('ZR3070COGF')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS COGS_Inventory_Revaluation_Transfer
		  ,CASE WHEN cte.SemanticTag IN ('ZR3071OCOG')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS Others_Cost_of_Goods_Warranties
		  ,CASE WHEN cte.SemanticTag IN ('ZR3074CGLD')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS Currency_gain_loss_from_derivates_COGS
		  ,CASE WHEN cte.SemanticTag IN ('ZR3066CBMP')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS COGS_BFT_MAP
		  ,CASE WHEN cte.SemanticTag IN ('ZR3068CBMU')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS COGS_BFT_Markup
		  ,CASE WHEN cte.SemanticTag IN ('ZR3052MCTP')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS Mgmt_COGS_3rd_F_Price_Duty_Freight_Insurance
		  ,CASE WHEN cte.SemanticTag IN ('ZR3064CGIC')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS COGS_IC_Sales
		  ,CASE WHEN cte.SemanticTag IN ('ZR3097CNCN')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS ECICommissionsLC
		  ,CASE WHEN cte.SemanticTag IN ('ZR3047DUTP')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS DutiesLC
		  ,CASE WHEN cte.SemanticTag IN ('ZR3048FRTP')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS FreightLC
		  ,CASE WHEN cte.SemanticTag IN ('ZR3049ISTP')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS InsuranceLC
		  ,CASE WHEN cte.SemanticTag IN ('ZR3050UDTP')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS VASLC
	      ,CASE WHEN cte.SemanticTag IN ('ZR3155OSUB')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS SubcontractingLC
		  ,CASE WHEN cte.SemanticTag IN ('ZR3201ISWV')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS InvoicedSalesWithVATLC
		  ,CASE WHEN cte.SemanticTag IN ('ZR3204FIBS')							THEN cte.AmountInCompanyCodeCurrency ELSE 0 END AS FranchiseIncomeBaseLC

		FROM cte0 cte 
		),
		---- ensemble "Atomic" KPIs into Formula-calculated KPis , SUM and GROUP the data
		CTEfields_agg AS (
		SELECT 	
		  CompanyCode
		  ,SalesOrganization
		  ,AccountingDocNo
		  ,ReferenceDocNo
		  ,ReferenceDocItemNo
		  ,ReferenceDocumentType
		  ,NatMaterialNo 
		  ,FiscalYear
		  ,ProfitCenterCode
		  ,NatSalesOrderNo  
		  ,NatSalesOrderItemNo   
		  ,CreationDate  
		  ,PostingDate
		  ,BrandCode
		  ,RBUCode
		  ,RefRBUCode   
		  ,BusSegmentCode
		  ,BusSubSegmentCode
		  ,DistributionChannelCode
		  ,ProdDivCode  
		  ,SalesRep
		  ,CustomerCode_SoldTo
		  ,CustomerCode_ShipTo 
		  ,Payer
		  ,CustomerCode_OwnerGroup 
		  ,CustomerCode_BillTo
		  ,Plant
		  ,DiscountReasonCode    
		  ,CurrencyCode
		  ,GroupKey
		  ,NatSOTypeCode
		  ,NatInvoiceTypeCode
		  ,BusinessClassCode
		  ,ProfitCenter      
		  ,OrderID			
		  ,CostCenter		
		  ,AccountingDocument
		  ,CoPaSeason
		  --------
		  ,SUM(NetSalesUnits)						AS NetSalesUnits
		  ,SUM(GrossSalesLC)						AS GrossSalesLC
		  ,SUM(OnInvoicePriceReductionsLC)			AS OnInvoicePriceReductionsLC
		  ,SUM(OffInvoicePriceReductionsLC)			AS OffInvoicePriceReductionsLC
		  ,SUM(RetailMarkdownLC)					AS RetailMarkdownLC
		  --,SUM(OffInvoiceDiscAdjustmentsLC)			AS OffInvoiceDiscAdjustmentsLC
		  ,SUM(SalesAdjustmentsReturnProvisionLC)	AS SalesAdjustmentsReturnProvisionLC
		  ,SUM(OtherSalesAdjustmentsLC)				AS OtherSalesAdjustmentsLC
		  ,SUM(NetSalesLC)							AS NetSalesLC
		  ,SUM(CogsAtFPriceLC)						AS CogsAtFPriceLC
		  ,SUM(ShortageLC)							AS ShortageLC
		  ,SUM(ChangeInInventoryReserveLC)			AS ChangeInInventoryReserveLC
		  ,SUM(CogsOtherAdjustmentsLC)				AS CogsOtherAdjustmentsLC
		  ,SUM(CogsAdjustmentsReturnsLC)			AS CogsAdjustmentsReturnsLC
		  --KPIs
		  --Cluster
		  ,SUM(GrossSalesLC) + SUM(OnInvoicePriceReductionsLC) + SUM(RetailMarkdownLC)												 AS InvoicedSalesLC
		  ,SUM(GrossSalesUnits) + SUM(OnInvoicePriceReductionsUnits) + SUM(RetailMarkdownUnits)										 AS InvoicedSalesUnits 
		  ,SUM(GrossSalesLC) + SUM(OnInvoicePriceReductionsLC) + SUM(RetailMarkdownLC) + SUM(OffInvoicePriceReductionsLC)			 AS OffInvoiceSales 
		  ,SUM(ECICommissionsLC)					AS ECICommissionsLC
		  ,SUM(DutiesLC)							AS DutiesLC
		  ,SUM(FreightLC)							AS FreightLC
		  ,SUM(InsuranceLC)							AS InsuranceLC
		  ,SUM(VASLC)								AS VASLC
		  ,SUM(SubcontractingLC)					AS SubcontractingLC --*EBPRP-257*
		  ,SUM(InvoicedSalesWithVATLC)				AS InvoicedSalesWithVATLC --*EBPRP-291*
		  ,SUM(FranchiseIncomeBaseLC)				AS FranchiseIncomeBaseLC --*EBPRP-291*

		  --COGS
		  ,SUM(COGS_Inventory_Revaluation_Transfer)+SUM(Others_Cost_of_Goods_Warranties) + SUM(Currency_gain_loss_from_derivates_COGS) AS OtherCOGSLS 
		  ,SUM(Mgmt_COGS_3rd_F_Price_Duty_Freight_Insurance)+
			   SUM(IcCogsChargesAndMarkupLC)+ /*3rd*/
			   SUM(COGS_IC_Sales)+
			   SUM(COGS_BFT_MAP)+
			   SUM(COGS_BFT_Markup)																AS CogsAtLandedCostLC
		  ,SUM(Mgmt_COGS_3rd_F_Price_Duty_Freight_Insurance) + 
				SUM(IcCogsChargesAndMarkupLC) + 
				SUM(ShortageLC) +
				SUM(CogsAdjustmentsReturnsLC) + 
				SUM(CogsOtherAdjustmentsLC) + 
				SUM(ChangeInInventoryReserveLC) +
				SUM(COGS_Inventory_Revaluation_Transfer) + 
				SUM(Others_Cost_of_Goods_Warranties)+
				SUM(Currency_gain_loss_from_derivates_COGS) +
				SUM(COGS_IC_Sales)+/*IC*/
				SUM(COGS_BFT_MAP)+SUM(COGS_BFT_Markup) /*BFT*/									AS TotalCogsLC
			,SUM(Mgmt_COGS_3rd_F_Price_Duty_Freight_Insurance) + 
				SUM(ShortageLC) +
				SUM(CogsAdjustmentsReturnsLC)+
				SUM(CogsOtherAdjustmentsLC)														AS MgmtCogsAtCostLC

			--Profit KPIs:
			,SUM(GrossSalesLC) + SUM(CogsAtFPriceLC)											AS ProductProfitOnFPriceLC
			,SUM(GrossSalesLC) + SUM(Mgmt_COGS_3rd_F_Price_Duty_Freight_Insurance)/*3rd*/ 
							+ SUM(COGS_IC_Sales) /*IC*/
							+ SUM(COGS_BFT_MAP) + SUM(COGS_BFT_Markup)/*BFT*/				AS ProductProfitOn3rdPartyLandedCostLC
			,SUM(NetSalesLC) + SUM(Mgmt_COGS_3rd_F_Price_Duty_Freight_Insurance)/*3rd*/
						   + SUM(COGS_IC_Sales) /*IC*/
						   + SUM(COGS_BFT_MAP) + SUM(COGS_BFT_Markup)/*BFT*/						AS MgmtGrossProfitOn3rdPartyLandedCostLC
			,CASE WHEN BusinessClassCode = 10 /*3rd*/ THEN
							SUM(NetSalesLC) + 
							SUM(Mgmt_COGS_3rd_F_Price_Duty_Freight_Insurance) + 
							SUM(ShortageLC) + 
							SUM(CogsAdjustmentsReturnsLC) + 
							SUM(CogsOtherAdjustmentsLC) + 
							SUM(ChangeInInventoryReserveLC) +
							SUM(COGS_Inventory_Revaluation_Transfer) + 
							SUM(Others_Cost_of_Goods_Warranties) +
							SUM(Currency_gain_loss_from_derivates_COGS) ELSE NULL END			AS MgmtGrossProfitLC --in this field is used CASE BusClass because [NetSalesLC] is used not only in 3rd class
			,SUM(NetSalesLC) + SUM(Mgmt_COGS_3rd_F_Price_Duty_Freight_Insurance) + SUM(IcCogsChargesAndMarkupLC)
						   + SUM(COGS_IC_Sales) /*IC specific*/
						   + SUM(COGS_BFT_MAP) + SUM(COGS_BFT_Markup)/*BFT specific*/			AS GrossProfitOnLandedCostLC
			,SUM(NetSalesLC) + 
				SUM(Mgmt_COGS_3rd_F_Price_Duty_Freight_Insurance) + 
				SUM(IcCogsChargesAndMarkupLC) + 
				SUM(ShortageLC) + 
				SUM(CogsAdjustmentsReturnsLC) + 
				SUM(CogsOtherAdjustmentsLC) + 
				SUM(ChangeInInventoryReserveLC) +
				SUM(COGS_Inventory_Revaluation_Transfer) + 
				SUM(Others_Cost_of_Goods_Warranties) +
				SUM(Currency_gain_loss_from_derivates_COGS) +
				SUM(COGS_IC_Sales) + /*IC specific*/
				SUM(COGS_BFT_MAP) + SUM(COGS_BFT_Markup)/*BFT specific*/						AS GrossProfitLC

			--Profit Margin
			,(SUM(GrossSalesLC) + SUM(CogsAtFPriceLC))/ NULLIF(SUM(GrossSalesLC),0)				AS ProductMarginOnFPriceLC
			,(SUM(GrossSalesLC) + SUM(Mgmt_COGS_3rd_F_Price_Duty_Freight_Insurance)/*3rd*/ 
								+ SUM(COGS_IC_Sales) /*IC*/
								+ SUM(COGS_BFT_MAP) + SUM(COGS_BFT_Markup)/*BFT*/) 
								/ NULLIF(SUM(GrossSalesLC),0)									AS ProductMarginOn3rdPartyLandedCostLC
			,(SUM(NetSalesLC) + SUM(Mgmt_COGS_3rd_F_Price_Duty_Freight_Insurance)/*3rd*/
								+ SUM(COGS_IC_Sales) /*IC*/
								+ SUM(COGS_BFT_MAP) + SUM(COGS_BFT_Markup)/*BFT*/)
								/ NULLIF(SUM(NetSalesLC),0)										AS MgmtGrossProfitMarginOn3rdPartyLandedCostLC
			,CASE WHEN BusinessClassCode <> 10 THEN NULL ELSE 
							   (SUM(NetSalesLC) + SUM(Mgmt_COGS_3rd_F_Price_Duty_Freight_Insurance) 
							  + SUM(ShortageLC) 
							  + SUM(CogsAdjustmentsReturnsLC) 
							  + SUM(CogsOtherAdjustmentsLC) 
							  + SUM(ChangeInInventoryReserveLC) 
							  + SUM(COGS_Inventory_Revaluation_Transfer) 
							  + SUM(Others_Cost_of_Goods_Warranties) 
							  + SUM(Currency_gain_loss_from_derivates_COGS))
								/ NULLIF(SUM(NetSalesLC),0)										END AS MgmtGrossProfitMarginLC
			,(SUM(NetSalesLC) + SUM(Mgmt_COGS_3rd_F_Price_Duty_Freight_Insurance) 
							  + SUM(IcCogsChargesAndMarkupLC)
							  + SUM(COGS_IC_Sales) + /*IC specific*/
							  + SUM(COGS_BFT_MAP) +  /*BFT specific*/
															SUM(COGS_BFT_Markup) /*BFT specific*/)
															/ NULLIF(SUM(NetSalesLC),0)				AS GrossProfitMarginOnLandedCostLC
			,(SUM(NetSalesLC) + SUM(Mgmt_COGS_3rd_F_Price_Duty_Freight_Insurance) + 
								SUM(ShortageLC) + 
								SUM(CogsAdjustmentsReturnsLC) + 
								SUM(CogsOtherAdjustmentsLC) + 
								SUM(ChangeInInventoryReserveLC) +
								SUM(COGS_Inventory_Revaluation_Transfer) + 
								SUM(Others_Cost_of_Goods_Warranties) +
								SUM(Currency_gain_loss_from_derivates_COGS) +
								SUM(COGS_IC_Sales) + /*IC specific*/
								SUM(COGS_BFT_MAP) + SUM(COGS_BFT_Markup)/*BFT specific*/
									)
								/ NULLIF(SUM(NetSalesLC),0)											AS GrossProfitMarginLC
			,SUM(Mgmt_COGS_3rd_F_Price_Duty_Freight_Insurance)					AS MgmtCOGS3rdFPriceDutyFreightInsuranceLC
			,SUM(IcCogsChargesAndMarkupLC) as ICCOGSMarkups
								
		FROM CTEtag_to_fields f
		GROUP BY CompanyCode
		  ,SalesOrganization
		  ,AccountingDocNo
		  ,ReferenceDocNo
		  ,ReferenceDocItemNo
		  ,ReferenceDocumentType
		  ,NatMaterialNo
		  ,FiscalYear
		  ,ProfitCenterCode
		  ,NatSalesOrderNo  
		  ,NatSalesOrderItemNo   
		  ,CreationDate  
		  ,PostingDate
		  ,BrandCode
		  ,RBUCode
		  ,RefRBUCode   
		  ,BusSegmentCode
		  ,BusSubSegmentCode
		  ,DistributionChannelCode
		  ,ProdDivCode  
		  ,SalesRep
		  ,CustomerCode_SoldTo
		  ,CustomerCode_ShipTo 
		  ,Payer
		  ,CustomerCode_OwnerGroup 
		  ,CustomerCode_BillTo
		  ,Plant
		  ,DiscountReasonCode    
		  ,CurrencyCode
		  ,GroupKey
		  ,NatSOTypeCode 
		  ,NatInvoiceTypeCode
		  ,BusinessClassCode
		  ,ProfitCenter      
		  ,OrderID			
		  ,CostCenter		
		  ,AccountingDocument
		  ,CoPaSeason
		  )
		  SELECT 
		  CONCAT(co.CompanyCode,'|',co.AccountingDocNo,'|',CAST(co.FiscalYear AS VARCHAR(4)),'|',co.ReferenceDocNo,'|',co.ReferenceDocItemNo,'|',co.NatMaterialNo,'|',co.BusinessClassCode,'|',co.DiscountReasonCode) AS NatCopaDetails_BK
		  ,co.CompanyCode
		  ,co.SalesOrganization
		  ,co.AccountingDocNo
		  ,co.ReferenceDocNo
		  ,co.ReferenceDocItemNo
		  ,co.ReferenceDocumentType
		  ,co.NatMaterialNo
		  ,co.FiscalYear
		  ,i.IntPupMasterId  
		  ,i.PDUCode         
		  ,CASE WHEN co.NatMaterialNo = '' THEN '' ELSE CONCAT(co.NatMaterialNo,'|',(CASE WHEN co.CompanyCode = 'PT10' THEN 'ES10' ELSE co.CompanyCode END)) END				AS NatArticle_BK
		  ,CONVERT(CHAR(9), CASE WHEN (CASE WHEN CHARINDEX('-',LTRIM(co.NatMaterialNo)) <> 7 THEN '' ELSE REPLACE(LEFT(co.NatMaterialNo,9),'-',' ') END) = '' THEN '000000 00'
								 ELSE (CASE WHEN CHARINDEX('-',LTRIM(co.NatMaterialNo)) <> 7 THEN '' ELSE REPLACE(LEFT(co.NatMaterialNo,9),'-',' ') END) END)					AS ArticleNumber_BK
		  ,REPLACE(co.NatMaterialNo,'-',' ')																																	AS ArticleSize_BK
		  ,CASE WHEN CHARINDEX('-',LTRIM(co.NatMaterialNo)) <> 7 THEN '' ELSE LEFT(co.NatMaterialNo,CHARINDEX('-',co.NatMaterialNo)-1) END										AS StyleNumber_BK
		  ,co.ProfitCenterCode
		  ,co.NatSalesOrderNo
		  ,co.NatSalesOrderItemNo
		  ,co.CreationDate
		  ,co.PostingDate
		  ,co.BrandCode
		  ,co.RBUCode
		  ,co.RefRBUCode
		  ,co.BusSegmentCode
		  ,co.BusSubSegmentCode
		  ,co.DistributionChannelCode
		  ,CASE WHEN co.DistributionChannelCode = '10' THEN 3 
				WHEN co.DistributionChannelCode = '20' THEN 2 
				WHEN co.DistributionChannelCode = '30' THEN 2 
				ELSE 1 END																									        AS BusinessTypeCode
		  ,co.ProdDivCode
		  ,CASE WHEN co.SalesRep = '' THEN '' ELSE CONCAT(co.SalesRep,'|',i.CompanyCode) END										AS NatSalesman_BK		  
		  ,CASE WHEN co.CustomerCode_SoldTo = '' THEN '' ELSE CONCAT(co.CustomerCode_SoldTo ,'|',co.SalesOrganization)	END	 		AS NatCustomer_BK 
		  ,CASE WHEN co.CustomerCode_ShipTo = '' THEN '' ELSE CONCAT(co.CustomerCode_ShipTo,'|',co.SalesOrganization)	END			AS NatCustomerShipTo_BK 
		  ,CASE WHEN co.Payer = ''				 THEN '' ELSE CONCAT(co.Payer,'|',co.SalesOrganization)	END							AS NatCustomerPayer_BK 
		  ,CASE WHEN co.CustomerCode_OwnerGroup = '' THEN '' ELSE CONCAT(co.CustomerCode_OwnerGroup,'|',co.SalesOrganization) END	AS NatCustomerOwnerGroup_BK
		  ,CASE WHEN co.CustomerCode_BillTo = '' THEN '' ELSE CONCAT(co.CustomerCode_BillTo,'|',co.SalesOrganization)	END			AS NatCustomerBillTo_BK
		  ,CASE WHEN co.Plant = ''				 THEN '' ELSE CONCAT(co.Plant,'|',i.CompanyCode)	END							    AS NatStoreDC_BK --Added company code to StoreCode
		  ,co.DiscountReasonCode
		  ,co.CurrencyCode
		  ,co.GroupKey
		  ,co.NatSOTypeCode
		  ,st.EBPDesc AS NatSOTypeDesc 
		  ,co.NatInvoiceTypeCode
		  ,co.BusinessClassCode
		  ,co.ProfitCenter      
		  ,co.OrderID			
		  ,co.CostCenter		
		  ,co.AccountingDocument
		  ,co.CoPaSeason
		  ,co.NetSalesUnits
		  ,co.GrossSalesLC
		  ,co.OnInvoicePriceReductionsLC
		  ,co.OffInvoicePriceReductionsLC
		  ,co.RetailMarkdownLC
		  ,co.SalesAdjustmentsReturnProvisionLC
		  ,co.OtherSalesAdjustmentsLC
		  ,co.NetSalesLC
		  ,co.CogsAtFPriceLC
		  ,co.ShortageLC
		  ,co.ChangeInInventoryReserveLC
		  ,co.CogsOtherAdjustmentsLC
		  ,co.CogsAdjustmentsReturnsLC
		  ,co.InvoicedSalesLC
		  ,co.InvoicedSalesUnits
		  ,co.OffInvoiceSales
		  ,co.ECICommissionsLC
		  ,co.DutiesLC
		  ,co.FreightLC
		  ,co.InsuranceLC
		  ,co.VASLC
		  ,co.SubcontractingLC
		  ,co.FranchiseIncomeBaseLC
		  ,co.InvoicedSalesWithVATLC
		  ,co.OtherCOGSLS
		  ,co.CogsAtLandedCostLC
		  ,co.TotalCogsLC
		  ,co.MgmtCogsAtCostLC
		  ,co.ProductProfitOnFPriceLC
		  ,co.ProductProfitOn3rdPartyLandedCostLC
		  ,co.MgmtGrossProfitOn3rdPartyLandedCostLC
		  ,co.MgmtGrossProfitLC
		  ,co.GrossProfitOnLandedCostLC
		  ,co.GrossProfitLC
		  ,co.ProductMarginOnFPriceLC
		  ,co.ProductMarginOn3rdPartyLandedCostLC
		  ,co.MgmtGrossProfitMarginOn3rdPartyLandedCostLC
		  ,co.MgmtGrossProfitMarginLC
		  ,co.GrossProfitMarginOnLandedCostLC
		  ,co.GrossProfitMarginLC
		  ,co.MgmtCOGS3rdFPriceDutyFreightInsuranceLC
		  ,co.ICCOGSMarkups
		  ,	CONVERT([BINARY](16),
			HASHBYTES('MD5',CONCAT(
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](100), co.CompanyCode)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](100), co.AccountingDocNo)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](100), co.FiscalYear)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](100), co.ReferenceDocNo)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](100), co.ReferenceDocItemNo)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](100), co.NatMaterialNo)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](100), co.BusinessClassCode)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](100), co.DiscountReasonCode))))
			))) AS HashValueBK 
		  ,CONVERT([BINARY](16), 
			HASHBYTES('MD5',CONCAT( 
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.CompanyCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.AccountingDocNo)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.ReferenceDocNo)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.ReferenceDocItemNo)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.ReferenceDocumentType)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.NatMaterialNo )))),'_', --AS NatMaterialNo
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.FiscalYear)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), i.IntPupMasterId)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), i.PDUCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CASE WHEN co.NatMaterialNo = '' THEN '' ELSE CONCAT(co.NatMaterialNo,'|',(CASE WHEN co.CompanyCode = 'PT10' THEN 'ES10' ELSE co.CompanyCode END)) END )))),'_',					--NatArticle_BK
			--	UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CASE WHEN len(co.NatMaterialNo) >0 THEN REPLACE(LEFT(co.NatMaterialNo,CHARINDEX('-',co.NatMaterialNo,(CHARINDEX('-',co.NatMaterialNo)+1))-1),'-',' ') ELSE '' END )))),'_',	--ArticleNumber_BK
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CONVERT(CHAR(9), CASE WHEN (CASE WHEN CHARINDEX('-',LTRIM(co.NatMaterialNo)) <> 7 THEN '' ELSE REPLACE(LEFT(co.NatMaterialNo,9),'-',' ') END) = '' THEN '000000 00'
								 ELSE (CASE WHEN CHARINDEX('-',LTRIM(co.NatMaterialNo)) <> 7 THEN '' ELSE REPLACE(LEFT(co.NatMaterialNo,9),'-',' ') END) END)  )))),'_',									--ArticleNumber_BK
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), REPLACE(co.NatMaterialNo,'-',' ') )))),'_',																																		--ArticleSize_BK
			--	UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CASE WHEN len(co.NatMaterialNo) >0 THEN LEFT(co.NatMaterialNo,CHARINDEX('-',co.NatMaterialNo)-1) ELSE '' END )))),'_',														--StyleNumber_BK
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CASE WHEN CHARINDEX('-',LTRIM(co.NatMaterialNo)) <> 7 THEN '' ELSE LEFT(co.NatMaterialNo,CHARINDEX('-',co.NatMaterialNo)-1) END  )))),'_',										--StyleNumber_BK
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.ProfitCenterCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.NatSalesOrderNo)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.NatSalesOrderItemNo)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.CreationDate)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.PostingDate)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.BrandCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.RBUCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.RefRBUCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.BusSegmentCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.BusSubSegmentCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.DistributionChannelCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CASE WHEN co.DistributionChannelCode = '20' THEN 2 ELSE 1 END)))),'_',													--AS BusinessTypeCode
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.ProdDivCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CASE WHEN co.SalesRep = '' THEN '' ELSE CONCAT(co.SalesRep,'|',i.CompanyCode) END)))),'_',								--AS NatSalesman_BK  
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CASE WHEN co.CustomerCode_SoldTo = '' THEN '' ELSE CONCAT(co.CustomerCode_SoldTo ,'|',i.CompanyCode) END)))),'_',			--AS NatCustomer_BK
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CASE WHEN co.CustomerCode_ShipTo = '' THEN '' ELSE CONCAT(co.CustomerCode_ShipTo,'|',i.CompanyCode)	END)))),'_',		--AS NatCustomerShipTo_BK
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CASE WHEN co.Payer = '' THEN '' ELSE CONCAT(co.Payer,'|',i.CompanyCode) END)))),'_',										--AS NatCustomerPayer_BK
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CASE WHEN co.CustomerCode_OwnerGroup = '' THEN '' ELSE CONCAT(co.CustomerCode_OwnerGroup,'|',i.CompanyCode) END)))),'_',	--AS NatCustomerOwnerGroup_BK
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CASE WHEN co.CustomerCode_BillTo = '' THEN '' ELSE CONCAT(co.CustomerCode_BillTo,'|',i.CompanyCode)	END)))),'_',		--AS NatCustomerBillTo_BK
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CASE WHEN co.Plant = '' THEN '' ELSE CONCAT(co.Plant,'|',i.CompanyCode)	END)))),'_',									--AS NatStoreDC_BK 
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.DiscountReasonCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.CurrencyCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.GroupKey)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.NatSOTypeCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), st.EBPDesc)))),'_',											--AS NatSOTypeDesc
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.NatInvoiceTypeCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.BusinessClassCode)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.ProfitCenter)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.OrderID)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.CostCenter)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.AccountingDocument)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.CoPaSeason)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.NetSalesUnits)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.GrossSalesLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.OnInvoicePriceReductionsLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.OffInvoicePriceReductionsLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.RetailMarkdownLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.SalesAdjustmentsReturnProvisionLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.OtherSalesAdjustmentsLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.NetSalesLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.CogsAtFPriceLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.ShortageLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.ChangeInInventoryReserveLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.CogsOtherAdjustmentsLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.CogsAdjustmentsReturnsLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.InvoicedSalesLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.InvoicedSalesUnits)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.OffInvoiceSales)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.ECICommissionsLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.DutiesLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.FreightLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.InsuranceLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.VASLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.SubcontractingLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.FranchiseIncomeBaseLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.InvoicedSalesWithVATLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.OtherCOGSLS)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.CogsAtLandedCostLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.TotalCogsLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.MgmtCogsAtCostLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.ProductProfitOnFPriceLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.ProductProfitOn3rdPartyLandedCostLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.MgmtGrossProfitOn3rdPartyLandedCostLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.MgmtGrossProfitLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.GrossProfitOnLandedCostLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.GrossProfitLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.ProductMarginOnFPriceLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.ProductMarginOn3rdPartyLandedCostLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.MgmtGrossProfitMarginOn3rdPartyLandedCostLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.MgmtGrossProfitMarginLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.GrossProfitMarginOnLandedCostLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.GrossProfitMarginLC)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.ICCOGSMarkups)))),'_',
			UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), co.MgmtCOGS3rdFPriceDutyFreightInsuranceLC))))
					))) AS HashDiff      
		  INTO #TMP_STAG_COPA
		FROM CTEfields_agg co JOIN pdwref.S4Hana_Interfaces i ON co.SalesOrganization = i.SalesOrg AND i.IntPupMasterId <> 1425
						 LEFT JOIN pdwref.S4Hana_SalesTypes  st ON st.SOTypeCode = co.NatSOTypeCode;

	--update destination 
		UPDATE dest SET
		--dest.CompanyCode					= stg.CompanyCode			--BK
		--,dest.AccountingDocNo				= stg.AccountingDocNo		--BK
		--,dest.ReferenceDocNo 				= stg.ReferenceDocNo		--BK
		--,dest.ReferenceDocItemNo 			= stg.ReferenceDocItemNo	--BK
		dest.ReferenceDocumentType			= stg.ReferenceDocumentType
		--,dest.NatMaterialNo				= stg.NatMaterialNo			--BK
		--,dest.FiscalYear					= stg.FiscalYear,			--BK
		,dest.IntPupMasterId				= stg.IntPupMasterId
		,dest.PDUCode						= stg.PDUCode
		,dest.NatArticle_BK					= stg.NatArticle_BK
		,dest.ArticleNumber_BK				= stg.ArticleNumber_BK
		,dest.ArticleSize_BK				= stg.ArticleSize_BK
		,dest.StyleNumber_BK				= stg.StyleNumber_BK
		,dest.ProfitCenterCode				= stg.ProfitCenterCode
		,dest.NatSalesOrderNo				= stg.NatSalesOrderNo
		,dest.NatSalesOrderItemNo			= stg.NatSalesOrderItemNo
		,dest.CreationDate					= stg.CreationDate
		,dest.PostingDate					= stg.PostingDate
		,dest.BrandCode						= stg.BrandCode
		,dest.RBUCode						= stg.RBUCode
		,dest.RefRBUCode					= stg.RefRBUCode
		,dest.BusSegmentCode				= stg.BusSegmentCode
		,dest.BusSubSegmentCode				= stg.BusSubSegmentCode
		,dest.DistributionChannelCode		= stg.DistributionChannelCode
		,dest.BusinessTypeCode				= stg.BusinessTypeCode
		,dest.ProdDivCode					= stg.ProdDivCode
		,dest.NatSalesman_BK				= stg.NatSalesman_BK
		,dest.NatCustomer_BK				= stg.NatCustomer_BK
		,dest.NatCustomerShipTo_BK			= stg.NatCustomerShipTo_BK
		,dest.NatCustomerPayer_BK			= stg.NatCustomerPayer_BK
		,dest.NatCustomerOwnerGroup_BK		= stg.NatCustomerOwnerGroup_BK
		,dest.NatCustomerBillTo_BK			= stg.NatCustomerBillTo_BK
		,dest.NatStoreDC_BK					= stg.NatStoreDC_BK
		--,dest.DiscountReasonCode			= stg.DiscountReasonCode		--BK
		,dest.CurrencyCode					= stg.CurrencyCode
		,dest.GroupKey						= stg.GroupKey
		,dest.NatSOTypeCode					= stg.NatSOTypeCode
		,dest.NatSOTypeDesc					= stg.NatSOTypeDesc
		,dest.NatInvoiceTypeCode			= stg.NatInvoiceTypeCode
		--,dest.BusinessClassCode			= stg.BusinessClassCode			--BK
		,dest.ProfitCenter                  = stg.ProfitCenter      
		,dest.OrderID			            = stg.OrderID			
		,dest.CostCenter		            = stg.CostCenter		
		,dest.AccountingDocument            = stg.AccountingDocument
		,dest.CoPaSeason					= stg.CoPaSeason  --new request by Thomas
		,dest.NetSalesUnits					= stg.NetSalesUnits
		,dest.GrossSalesLC					= stg.GrossSalesLC
		,dest.OnInvoicePriceReductionsLC	= stg.OnInvoicePriceReductionsLC
		,dest.OffInvoicePriceReductionsLC	= stg.OffInvoicePriceReductionsLC
		,dest.RetailMarkdownLC				= stg.RetailMarkdownLC
		,dest.SalesAdjustmentsReturnProvisionLC = stg.SalesAdjustmentsReturnProvisionLC
		,dest.OtherSalesAdjustmentsLC		= stg.OtherSalesAdjustmentsLC
		,dest.NetSalesLC					= stg.NetSalesLC
		,dest.CogsAtFPriceLC				= stg.CogsAtFPriceLC
		,dest.ShortageLC					= stg.ShortageLC
		,dest.ChangeInInventoryReserveLC	= stg.ChangeInInventoryReserveLC
		,dest.CogsOtherAdjustmentsLC		= stg.CogsOtherAdjustmentsLC
		,dest.CogsAdjustmentsReturnsLC		= stg.CogsAdjustmentsReturnsLC
		,dest.InvoicedSalesLC				= stg.InvoicedSalesLC
		,dest.InvoicedSalesUnits			= stg.InvoicedSalesUnits
		,dest.OffInvoiceSales				= stg.OffInvoiceSales
		,dest.ECICommissionsLC				= stg.ECICommissionsLC
		,dest.DutiesLC                      = stg.DutiesLC
		,dest.FreightLC						= stg.FreightLC
		,dest.InsuranceLC					= stg.InsuranceLC
		,dest.VASLC							= stg.VASLC
		,dest.SubcontractingLC				= stg.SubcontractingLC
		,dest.FranchiseIncomeBaseLC			= stg.FranchiseIncomeBaseLC
		,dest.InvoicedSalesWithVATLC		= stg.InvoicedSalesWithVATLC
		,dest.OtherCOGSLS					= stg.OtherCOGSLS
		,dest.CogsAtLandedCostLC			= stg.CogsAtLandedCostLC
		,dest.TotalCogsLC					= stg.TotalCogsLC
		,dest.MgmtCogsAtCostLC				= stg.MgmtCogsAtCostLC
		,dest.ProductProfitOnFPriceLC		= stg.ProductProfitOnFPriceLC
		,dest.ProductProfitOn3rdPartyLandedCostLC			= stg.ProductProfitOn3rdPartyLandedCostLC
		,dest.MgmtGrossProfitOn3rdPartyLandedCostLC			= stg.MgmtGrossProfitOn3rdPartyLandedCostLC
		,dest.MgmtGrossProfitLC								= stg.MgmtGrossProfitLC
		,dest.GrossProfitOnLandedCostLC						= stg.GrossProfitOnLandedCostLC
		,dest.GrossProfitLC									= stg.GrossProfitLC
		,dest.ProductMarginOnFPriceLC						= stg.ProductMarginOnFPriceLC
		,dest.ProductMarginOn3rdPartyLandedCostLC			= stg.ProductMarginOn3rdPartyLandedCostLC
		,dest.MgmtGrossProfitMarginOn3rdPartyLandedCostLC	= stg.MgmtGrossProfitMarginOn3rdPartyLandedCostLC
		,dest.MgmtGrossProfitMarginLC						= stg.MgmtGrossProfitMarginLC
		,dest.GrossProfitMarginOnLandedCostLC				= stg.GrossProfitMarginOnLandedCostLC
		,dest.GrossProfitMarginLC							= stg.GrossProfitMarginLC
		,dest.MgmtCOGS3rdFPriceDutyFreightInsuranceLC			= stg.MgmtCOGS3rdFPriceDutyFreightInsuranceLC
		,dest.ICCOGSMarkups									= stg.ICCOGSMarkups
		,dest.HashDiff										= stg.HashDiff
		,dest.ModifiedOn									= @LoadDate
		FROM #TMP_STAG_COPA AS stg JOIN sales.NatCopaDetails AS dest ON stg.HashValueBK = dest.HashValueBK
		WHERE dest.HashDiff <> stg.HashDiff;

	--insert into dest
		INSERT INTO sales.NatCopaDetails
		( NatCopaDetails_BK
			  ,CompanyCode
			  ,AccountingDocNo
			  ,ReferenceDocNo
			  ,ReferenceDocItemNo
			  ,ReferenceDocumentType
			  ,NatMaterialNo
			  ,FiscalYear
			  ,IntPupMasterId
			  ,PDUCode
			  ,NatArticle_BK
			  ,ArticleNumber_BK
			  ,ArticleSize_BK
			  ,StyleNumber_BK
			  ,ProfitCenterCode
			  ,NatSalesOrderNo
			  ,NatSalesOrderItemNo
			  ,CreationDate
			  ,PostingDate
			  ,BrandCode
			  ,RBUCode
			  ,RefRBUCode
			  ,BusSegmentCode
			  ,BusSubSegmentCode
			  ,DistributionChannelCode
			  ,BusinessTypeCode
			  ,ProdDivCode
			  ,NatSalesman_BK
			  ,NatCustomer_BK
			  ,NatCustomerShipTo_BK
			  ,NatCustomerPayer_BK
			  ,NatCustomerOwnerGroup_BK
			  ,NatCustomerBillTo_BK
			  ,NatStoreDC_BK
			  ,DiscountReasonCode
			  ,CurrencyCode
			  ,GroupKey
			  ,NatSOTypeCode
			  ,NatSOTypeDesc
			  ,NatInvoiceTypeCode
			  ,BusinessClassCode
			  ,ProfitCenter      
			  ,OrderID			
			  ,CostCenter		
			  ,AccountingDocument
			  ,CoPaSeason
			  ,NetSalesUnits
			  ,GrossSalesLC
			  ,OnInvoicePriceReductionsLC
			  ,OffInvoicePriceReductionsLC
			  ,RetailMarkdownLC
			  --,OffInvoiceDiscAdjustmentsLC
			  ,SalesAdjustmentsReturnProvisionLC
			  ,OtherSalesAdjustmentsLC
			  ,NetSalesLC
			  ,CogsAtFPriceLC
			  ,ShortageLC
			  ,ChangeInInventoryReserveLC
			  ,CogsOtherAdjustmentsLC
			  ,CogsAdjustmentsReturnsLC
			  ,InvoicedSalesLC
			  ,InvoicedSalesUnits
			  ,OffInvoiceSales
			  ,ECICommissionsLC
			  ,DutiesLC
			  ,FreightLC
			  ,InsuranceLC
			  ,VASLC
			  ,SubcontractingLC
			  ,InvoicedSalesWithVATLC
			  ,FranchiseIncomeBaseLC
			  ,OtherCOGSLS
			  ,CogsAtLandedCostLC
			  ,TotalCogsLC
			  ,MgmtCogsAtCostLC
			  ,ProductProfitOnFPriceLC
			  ,ProductProfitOn3rdPartyLandedCostLC
			  ,MgmtGrossProfitOn3rdPartyLandedCostLC
			  ,MgmtGrossProfitLC
			  ,GrossProfitOnLandedCostLC
			  ,GrossProfitLC
			  ,ProductMarginOnFPriceLC
			  ,ProductMarginOn3rdPartyLandedCostLC
			  ,MgmtGrossProfitMarginOn3rdPartyLandedCostLC
			  ,MgmtGrossProfitMarginLC
			  ,GrossProfitMarginOnLandedCostLC
			  ,GrossProfitMarginLC
			  ,MgmtCOGS3rdFPriceDutyFreightInsuranceLC
			  ,ICCOGSMarkups
			  ,HashValueBK
			  ,HashDiff
			  ,CreatedOn
			  ,ModifiedOn

		)
		SELECT stg.NatCopaDetails_BK
			  ,stg.CompanyCode
			  ,stg.AccountingDocNo
			  ,stg.ReferenceDocNo
			  ,stg.ReferenceDocItemNo
			  ,stg.ReferenceDocumentType
			  ,stg.NatMaterialNo
			  ,stg.FiscalYear
			  ,stg.IntPupMasterId
			  ,stg.PDUCode
			  ,stg.NatArticle_BK
			  ,stg.ArticleNumber_BK
			  ,stg.ArticleSize_BK
			  ,stg.StyleNumber_BK
			  ,stg.ProfitCenterCode
			  ,stg.NatSalesOrderNo
			  ,stg.NatSalesOrderItemNo
			  ,stg.CreationDate
			  ,stg.PostingDate
			  ,stg.BrandCode
			  ,stg.RBUCode
			  ,stg.RefRBUCode
			  ,stg.BusSegmentCode
			  ,stg.BusSubSegmentCode
			  ,stg.DistributionChannelCode
			  ,stg.BusinessTypeCode
			  ,stg.ProdDivCode
			  ,stg.NatSalesman_BK
			  ,stg.NatCustomer_BK
			  ,stg.NatCustomerShipTo_BK
			  ,stg.NatCustomerPayer_BK
			  ,stg.NatCustomerOwnerGroup_BK
			  ,stg.NatCustomerBillTo_BK
			  ,stg.NatStoreDC_BK
			  ,stg.DiscountReasonCode
			  ,stg.CurrencyCode
			  ,stg.GroupKey
			  ,stg.NatSOTypeCode
			  ,stg.NatSOTypeDesc
			  ,stg.NatInvoiceTypeCode
			  ,stg.BusinessClassCode
			  ,stg.ProfitCenter      
			  ,stg.OrderID			
			  ,stg.CostCenter		
			  ,stg.AccountingDocument
			  ,stg.CoPaSeason
			  ,stg.NetSalesUnits
			  ,stg.GrossSalesLC
			  ,stg.OnInvoicePriceReductionsLC
			  ,stg.OffInvoicePriceReductionsLC
			  ,stg.RetailMarkdownLC
			  --,stg.OffInvoiceDiscAdjustmentsLC
			  ,stg.SalesAdjustmentsReturnProvisionLC
			  ,stg.OtherSalesAdjustmentsLC
			  ,stg.NetSalesLC
			  ,stg.CogsAtFPriceLC
			  ,stg.ShortageLC
			  ,stg.ChangeInInventoryReserveLC
			  ,stg.CogsOtherAdjustmentsLC
			  ,stg.CogsAdjustmentsReturnsLC
			  ,stg.InvoicedSalesLC
			  ,stg.InvoicedSalesUnits
			  ,stg.OffInvoiceSales
			  ,stg.ECICommissionsLC
			  ,stg.DutiesLC
			  ,stg.FreightLC
			  ,stg.InsuranceLC
			  ,stg.VASLC
			  ,stg.SubcontractingLC
			  ,stg.InvoicedSalesWithVATLC
			  ,stg.FranchiseIncomeBaseLC
			  ,stg.OtherCOGSLS
			  ,stg.CogsAtLandedCostLC
			  ,stg.TotalCogsLC
			  ,stg.MgmtCogsAtCostLC
			  ,stg.ProductProfitOnFPriceLC
			  ,stg.ProductProfitOn3rdPartyLandedCostLC
			  ,stg.MgmtGrossProfitOn3rdPartyLandedCostLC
			  ,stg.MgmtGrossProfitLC
			  ,stg.GrossProfitOnLandedCostLC
			  ,stg.GrossProfitLC
			  ,stg.ProductMarginOnFPriceLC
			  ,stg.ProductMarginOn3rdPartyLandedCostLC
			  ,stg.MgmtGrossProfitMarginOn3rdPartyLandedCostLC
			  ,stg.MgmtGrossProfitMarginLC
			  ,stg.GrossProfitMarginOnLandedCostLC
			  ,stg.GrossProfitMarginLC
			  ,stg.MgmtCOGS3rdFPriceDutyFreightInsuranceLC
			  ,stg.ICCOGSMarkups
			  ,stg.HashValueBK
			  ,stg.HashDiff
			  ,@LoadDate AS CreatedOn
			  ,@LoadDate AS ModifiedOn
		FROM #TMP_STAG_COPA AS stg LEFT JOIN sales.NatCopaDetails AS dest ON stg.HashValueBK = dest.HashValueBK
		WHERE dest.HashValueBK IS NULL OPTION (MAXDOP 1);

	END