﻿CREATE PROC [dbo].[S4Hana_spProvFreeAvailableStocks] @LDTS [DATETIME2](7) AS
BEGIN
SET NOCOUNT ON

--DECLARE @LDTS DATETIME2(7) = '2000-01-01'
DECLARE @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
DECLARE @ExecStart DATETIME2(7) = GETDATE()
DECLARE @SourceLastLoadDate DATETIME2(7)
DECLARE @DestinationLastLoadDate DATETIME2(7)
DECLARE @BatchLdts DATETIME2(7) = @LDTS


-- do not use the input parameter, in case of an failure or reload situartion take the last tranfered LDTS from the Hist table
IF(EXISTS(SELECT 1 FROM [sourcing].[FreeAvailableStockHistory]))
BEGIN
	SELECT @DestinationLastLoadDate = MAX(LDTS)
	FROM [sourcing].[FreeAvailableStockHistory]
END
ELSE BEGIN
	SELECT @DestinationLastLoadDate = '1990-01-01' -- for intial load
END 

IF(EXISTS(SELECT 1 FROM [biz].[S4Hana_FreeAvailableStocksHistory]))
BEGIN
	SELECT @SourceLastLoadDate = MAX(LDTS)
	FROM  [biz].[S4Hana_FreeAvailableStocksHistory]
END
ELSE BEGIN
	SELECT @SourceLastLoadDate = '1990-01-01' -- for intial load
END


IF OBJECT_ID('tempdb..#FreeAvailableStocksFullLast') IS NOT NULL
BEGIN
    DROP TABLE #FreeAvailableStocksFullLast
END


CREATE TABLE #FreeAvailableStocksFullLast
(
	[HASH_BK] [binary](16) NULL,
	[AggInventoryMovements_HASH] [binary](16) NULL,
	[AggInventoryValuations_HASH] [binary](16) NULL,
	[AggInventoryTypes_HASH] [binary](16) NULL,
	[HASH_Diff] [binary](16) NULL,
	[NatStoreDC_BK] [nvarchar](20) NULL,
	[COMPANYCODE] [nvarchar](4) NULL,
	[PLANT] [nvarchar](4) NULL,
	[MATERIAL] [nvarchar](40) NULL,
	[STORAGELOCATION] [nvarchar](4) NULL,
	[STOCKSEGMENT] [nvarchar](40) NULL,
	[POSTINGDATE] [date] NULL,
	[QTYTYPE] [nvarchar](128) NULL,
	[MATERIALBASEUNIT] [nvarchar](3) NULL,
	[QTY] [decimal](31, 14) NULL,
	[RunningTotal] [int] NULL,
	[PRICE] [decimal](17, 2) NULL,
	[VALUE] [decimal](17, 2) NULL,
	[PRICECURRENCY] [nvarchar](5) NULL,
	[VALIDFROMDAT] [date] NULL,
	[VALIDTODAT] [date] NULL,
	[BusinessTypeCode] [int] NULL,
	[INSERTTYPE] [int] NULL,
	[ModifiedOn] [datetime2](7) NULL,
	[NatArticle_BK] [nvarchar](50) NULL,
	[PDUCode] [varchar](15) NULL,
	[IntPupMasterId] [varchar](15) NULL,
	[ArticleNumber_BK] [nvarchar](15) NULL,
	[ArticleSize_BK] [nvarchar](50) NULL,
	[BrandCode] [nvarchar](4) NULL,
	[RBUCode] [int] NULL,
	[ProdDivCode] [int] NULL,
	[StyleNumber_BK] [int] NULL,
	[IntAgeingCode] [int] NULL,
	[IntInventoryStatusCode] [int] NULL,
	[IntInventoryTypeCode] [int] NULL,
	[SPECIALSTOCKINDICATOR] [nvarchar](1) NULL,
	[GROSS] [decimal](17, 2) NULL,
	[LDTS] [datetime2](7) NULL,
	SourceIdentifier tinyint null
)
WITH
(
	DISTRIBUTION = HASH(AggInventoryTypes_HASH),
	CLUSTERED COLUMNSTORE INDEX
)

;WITH CTE AS (
SELECT	CONVERT([BINARY](16),
			HASHBYTES('MD5',
				CONCAT(		UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.Plant)))), '_',
							UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.Material)))), '_',
							UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.InventoryStatusType))))
							))) AS HASH_BK
		,CONVERT([BINARY](16),
			HASHBYTES('MD5',
				CONCAT(	UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.Plant)))), '_',
							UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.Material)))), '_',
							UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.StockSegment)))), '_',
							UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.InventoryStatusType)))), '_',
							UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.PostingDate))))
							))) AS AggInventoryMovements_HASH
		,NULL AS AggInventoryValuations_HASH
		,CONVERT([BINARY](16),
			HASHBYTES('MD5',
				CONCAT(	UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.Plant)))), '_',
							UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.Material)))), '_',
							UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.StockSegment)))), '_', 
							UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FASH.InventoryStatusType))))
							))) AS AggInventoryTypes_HASH
		,NULL AS HASH_Diff
		,CONVERT(NVARCHAR(20),	CASE	WHEN SHVP.PlantCategoryCode='A' THEN CONCAT(FASH.Plant, '|', SHI.RegionCode)
												WHEN FASH.StockSegment='' THEN CONCAT(FASH.Plant, '|', SHI.RegionCode)
												ELSE CONCAT(FASH.Plant, '_', FASH.StockSegment,'|', SHI.RegionCode)
										END) AS NatStoreDC_BK
		,SHI.CompanyCode AS COMPANYCODE
		,FASH.Plant AS PLANT
		,FASH.Material AS MATERIAL
		,'0001' AS STORAGELOCATION
		,FASH.StockSegment AS STOCKSEGMENT
		,'UNRESTRICTEDSTOCK' AS QTYTYPE
		,FASH.BaseUnitOfMeasure AS MATERIALBASEUNIT
		,NULL AS QTY
		,FASH.RunningTotal
		,CASE	WHEN ISNULL(SHAMSP.PriceControlIndicator, SHAMSPH.PriceControlIndicator)='V'
				THEN ISNULL(SHAMSP.MovingAveragePrice, SHAMSPH.MovingAveragePrice)
				ELSE ISNULL(SHAMSP.StandardPrice, SHAMSPH.StandardPrice)
		END AS PRICE
		,CASE	WHEN ISNULL(SHAMSP.PriceControlIndicator, SHAMSPH.PriceControlIndicator)='V'
				THEN ISNULL(SHAMSP.MovingAveragePrice, SHAMSPH.MovingAveragePrice)
				ELSE ISNULL(SHAMSP.StandardPrice, SHAMSPH.StandardPrice)
		END * FASH.RunningTotal AS VALUE
		,ISNULL(SHAMSP.PriceCurrency, SHAMSPH.PriceCurrency) AS PRICECURRENCY
		,ISNULL(SHAMSP.VALIDFROMDAT, SHAMSPH.ValidFromDat) AS VALIDFROMDAT
		,ISNULL(SHAMSP.VALIDTODAT, SHAMSPH.ValidToDat) AS VALIDTODAT
		,FASH.PostingDate AS POSTINGDATE
		,FASH.PostingDateValidTo AS POSTINGDATEVALIDTO 
		,1 AS BusinessTypeCode
		,-1 AS INSERTTYPE
		,GETDATE() AS ModifiedOn
		,CONCAT(FASH.Material,'|', CASE WHEN SHI.CompanyCode='PT10' THEN 'ES10' ELSE SHI.CompanyCode END) AS NatArticle_BK
		,SHI.PDUCode
		,SHI.IntPupMasterId
		,CONCAT(LTRIM(RTRIM(SHVM.StyleNo)), ' ', LTRIM(RTRIM(SHVM.ColorNo))) AS ArticleNumber_BK
		,CONCAT(LTRIM(RTRIM(SHVM.StyleNo)), ' ', LTRIM(RTRIM(SHVM.ColorNo)), ' ', LTRIM(RTRIM(ISNULL(SHVM.SizeNumber, '0')))) AS ArticleSize_BK
		,SHVM.BrandCode
		,ISNULL(TRY_CONVERT(INT, SHVM.RBUCode), 0) AS RBUCode
		,CONVERT(INT, CASE WHEN SHVM.RetailDCSDepCode IN ('31', '32', '33', '34') AND SHVM.ProdDivCode = '2' THEN '3' ELSE SHVM.ProdDivCode END) AS ProdDivCode
		,CONVERT(INT, ISNULL(TRY_CONVERT(INT, SHVM.StyleNo), 0)) AS StyleNumber_BK
		,50 AS IntAgeingCode
		,FASH.InventoryStatusType AS IntInventoryStatusCode
		,CASE WHEN SHVP.PlantCategoryCode='B' THEN 30 ELSE 40 END AS IntInventoryTypeCode
		,'' AS SPECIALSTOCKINDICATOR
		,0.00 AS GROSS
		,FASH.LDTS
FROM (
			SELECT [Plant]
			      ,[Material]
			      ,[StockSegment]
			      ,PostingDate
				  ,PostingDateValidTo
			      ,[MRPElement]
			      ,[RunningTotal]*X.Ratio as [RunningTotal]
			      ,[BaseUnitOfMeasure]
			      ,[HashDiff]
				  ,X.InventoryStatusType
				  ,LDTS

			FROM [biz].[S4Hana_FreeAvailableStocksHistory] FASH
			CROSS APPLY (SELECT -1 AS Ratio, 10 AS InventoryStatusType UNION SELECT 1, 20 AS InventoryStatusType) AS X
	) AS FASH
	LEFT JOIN biz.S4Hana_AggMaterialStockPricesHistory AS SHAMSPH ON	SHAMSPH.Material = FASH.Material
																	   AND SHAMSPH.Plant = FASH.Plant
																	   AND FASH.PostingDate BETWEEN SHAMSPH.ValidFromDat AND SHAMSPH.ValidToDat
	LEFT JOIN biz.S4Hana_AggMaterialStockPrices AS SHAMSP ON        	SHAMSP.Material = FASH.Material
															           AND SHAMSP.Plant = FASH.Plant
															           AND FASH.PostingDate BETWEEN SHAMSP.ValidFromDat AND SHAMSP.ValidToDat

	LEFT JOIN stag.S4Hana_vMaterials AS SHVM ON SHVM.MaterialNumber=FASH.Material
	JOIN stag.S4Hana_vPlants AS SHVP ON SHVP.StoreCode=FASH.Plant
	JOIN stag.S4Hana_vSalesOrgToCompanyCode AS SHVSOTCC ON SHVSOTCC.Code = SHVP.SalesOrganizationCode
	JOIN pdwref.S4Hana_Interfaces AS SHI ON SHI.SalesOrg=SHVP.SalesOrganizationCode AND SHI.Interface='EBP'
	where 1=1--FASH.Material ='076856-03-100' =
	and (FASH.LDTS > @DestinationLastLoadDate
	or SHAMSP._LDTS  > @DestinationLastLoadDate
	or SHAMSPH._LDTS   > @DestinationLastLoadDate)
)
INSERT INTO #FreeAvailableStocksFullLast
(HASH_BK,
	 AggInventoryMovements_HASH,
	 AggInventoryValuations_HASH,
	 AggInventoryTypes_HASH,
	 HASH_Diff,
	 POSTINGDATE,
	 NatStoreDC_BK,
	 COMPANYCODE,
	 PLANT,
	 MATERIAL,
	 STORAGELOCATION,
	 STOCKSEGMENT,
	 QTYTYPE,
	 MATERIALBASEUNIT,
	 QTY,
	 RunningTotal,
	 PRICE,
	 VALUE,
	 PRICECURRENCY,
	 VALIDFROMDAT,
	 VALIDTODAT,
	 BusinessTypeCode,
	 INSERTTYPE,
	 ModifiedOn,
	 NatArticle_BK,
	 PDUCode,
	 IntPupMasterId,
	 ArticleNumber_BK,
	 ArticleSize_BK,
	 BrandCode,
	 RBUCode,
	 ProdDivCode,
	 StyleNumber_BK,
	 IntAgeingCode,
	 IntInventoryStatusCode,
	 IntInventoryTypeCode,
	 SPECIALSTOCKINDICATOR,
	 GROSS,
	 LDTS,
     SourceIdentifier)
	SELECT 
	HASH_BK,
	AggInventoryMovements_HASH,
	AggInventoryValuations_HASH,
	AggInventoryTypes_HASH,
	CONVERT([BINARY](16),
			HASHBYTES('MD5',
				CONCAT(	UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), NatStoreDC_BK)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), COMPANYCODE			)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PLANT					)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), MATERIAL				)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), STORAGELOCATION		)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), STOCKSEGMENT			)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), QTYTYPE				)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), MATERIALBASEUNIT		)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), QTY					)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), RunningTotal			)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PRICE					)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), VALUE					)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PRICECURRENCY			)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), VALIDFROMDAT			)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), VALIDTODAT			)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), BusinessTypeCode		)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), INSERTTYPE			)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), NatArticle_BK			)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PDUCode				)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), IntPupMasterId		)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ArticleNumber_BK		)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ArticleSize_BK		)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), BrandCode				)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), RBUCode				)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ProdDivCode			)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), StyleNumber_BK		)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), IntAgeingCode			)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), IntInventoryStatusCode)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), IntInventoryTypeCode	)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), SPECIALSTOCKINDICATOR	)))), '_',
						UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), GROSS))))		
						))) as HASH_Diff,
	POSTINGDATE,
	NatStoreDC_BK,
	COMPANYCODE,
	PLANT,
	MATERIAL,
	STORAGELOCATION,
	STOCKSEGMENT,
	QTYTYPE,
	MATERIALBASEUNIT,
	QTY,
	RunningTotal,
	PRICE,
	VALUE,
	PRICECURRENCY,
	VALIDFROMDAT,
	VALIDTODAT,
	BusinessTypeCode,
	INSERTTYPE,
	ModifiedOn,
	NatArticle_BK,
	PDUCode,
	IntPupMasterId,
	ArticleNumber_BK,
	ArticleSize_BK,
	BrandCode,
	RBUCode,
	ProdDivCode,
	StyleNumber_BK,
	IntAgeingCode,
	IntInventoryStatusCode,
	IntInventoryTypeCode,
	SPECIALSTOCKINDICATOR,
	GROSS,
	LDTS,
	CONVERT(TINYINT,1) AS SourceIdentifier  --> 1 = new from biz ; 2 = last entry from sourcing
	FROM CTE

	-- Add last entires from sourcing History which are in the new batch
INSERT INTO #FreeAvailableStocksFullLast
	(HASH_BK,
	 AggInventoryMovements_HASH,
	 AggInventoryValuations_HASH,
	 AggInventoryTypes_HASH,
	 HASH_Diff,
	 POSTINGDATE,
	 NatStoreDC_BK,
	 COMPANYCODE,
	 PLANT,
	 MATERIAL,
	 STORAGELOCATION,
	 STOCKSEGMENT,
	 QTYTYPE,
	 MATERIALBASEUNIT,
	 QTY,
	 RunningTotal,
	 PRICE,
	 VALUE,
	 PRICECURRENCY,
	 VALIDFROMDAT,
	 VALIDTODAT,
	 BusinessTypeCode,
	 INSERTTYPE,
	 ModifiedOn,
	 NatArticle_BK,
	 PDUCode,
	 IntPupMasterId,
	 ArticleNumber_BK,
	 ArticleSize_BK,
	 BrandCode,
	 RBUCode,
	 ProdDivCode,
	 StyleNumber_BK,
	 IntAgeingCode,
	 IntInventoryStatusCode,
	 IntInventoryTypeCode,
	 SPECIALSTOCKINDICATOR,
	 GROSS,
	 LDTS,
     SourceIdentifier)
SELECT
    FASH.HASH_BK,
	FASH.AggInventoryMovements_HASH,
	FASH.AggInventoryValuations_HASH,
	FASH.AggInventoryTypes_HASH,
	FASH.HASH_Diff,
	FASH.POSTINGDATE,
	FASH.NatStoreDC_BK,
	FASH.COMPANYCODE,
	FASH.PLANT,
	FASH.MATERIAL,
	FASH.STORAGELOCATION,
	FASH.STOCKSEGMENT,
	FASH.QTYTYPE,
	FASH.MATERIALBASEUNIT,
	FASH.QTY,
	FASH.RunningTotal,
	FASH.PRICE,
	FASH.VALUE,
	FASH.PRICECURRENCY,
	FASH.VALIDFROMDAT,
	FASH.VALIDTODAT,
	FASH.BusinessTypeCode,
	FASH.INSERTTYPE,
	FASH.ModifiedOn,
	FASH.NatArticle_BK,
	FASH.PDUCode,
	FASH.IntPupMasterId,
	FASH.ArticleNumber_BK,
	FASH.ArticleSize_BK,
	FASH.BrandCode,
	FASH.RBUCode,
	FASH.ProdDivCode,
	FASH.StyleNumber_BK,
	FASH.IntAgeingCode,
	FASH.IntInventoryStatusCode,
	FASH.IntInventoryTypeCode,
	FASH.SPECIALSTOCKINDICATOR,
	FASH.GROSS,
	FASH.LDTS,
	CONVERT(TINYINT,2) AS SourceIdentifier  --> 1 = new from biz ; 2 = last entry from sourcing
	FROM [sourcing].[FreeAvailableStockHistory] AS FASH 
	INNER JOIN #FreeAvailableStocksFullLast AS stagNew
		ON 	stagNew.AggInventoryTypes_HASH=FASH.AggInventoryTypes_HASH

TRUNCATE TABLE etl.S4Hana_provFreeAvailableStocksHistory

;WITH preHash AS (
	 SELECT HASH_BK
		   ,AggInventoryMovements_HASH
		   ,AggInventoryValuations_HASH
		   ,AggInventoryTypes_HASH
		   ,HASH_Diff
		   ,POSTINGDATE
		   ,NatStoreDC_BK
		   ,COMPANYCODE
		   ,PLANT
		   ,MATERIAL
		   ,STORAGELOCATION
		   ,STOCKSEGMENT
		   ,QTYTYPE
		   ,MATERIALBASEUNIT
		   ,QTY
		   ,RunningTotal
		   ,PRICE
		   ,VALUE
		   ,PRICECURRENCY
		   ,VALIDFROMDAT
		   ,VALIDTODAT
		   ,BusinessTypeCode
		   ,INSERTTYPE
		   ,ModifiedOn
		   ,NatArticle_BK
		   ,PDUCode
		   ,IntPupMasterId
		   ,ArticleNumber_BK
		   ,ArticleSize_BK
		   ,BrandCode
		   ,RBUCode
		   ,ProdDivCode
		   ,StyleNumber_BK
		   ,IntAgeingCode
		   ,IntInventoryStatusCode
		   ,IntInventoryTypeCode
		   ,SPECIALSTOCKINDICATOR
		   ,GROSS
		   ,LDTS
		   ,SourceIdentifier
		   ,LAG(HASH_Diff) OVER (PARTITION BY AggInventoryTypes_HASH ORDER BY PostingDate, SourceIdentifier DESC) AS pre_HashDiff -- Add SourceIdentifier rank to take first the existing Data in case there are the same content in the source
		   ,ROW_NUMBER() OVER (PARTITION BY AggInventoryTypes_HASH ORDER BY PostingDate, SourceIdentifier DESC) AS RankOverAll
	FROM #FreeAvailableStocksFullLast
)
,DiffCheck AS (
	SELECT HASH_BK
		   ,AggInventoryMovements_HASH
		   ,AggInventoryValuations_HASH
		   ,AggInventoryTypes_HASH
		   ,HASH_Diff
		   ,POSTINGDATE
		   ,NatStoreDC_BK
		   ,COMPANYCODE
		   ,PLANT
		   ,MATERIAL
		   ,STORAGELOCATION
		   ,STOCKSEGMENT
		   ,QTYTYPE
		   ,MATERIALBASEUNIT
		   ,QTY
		   ,RunningTotal
		   ,PRICE
		   ,VALUE
		   ,PRICECURRENCY
		   ,VALIDFROMDAT
		   ,VALIDTODAT
		   ,BusinessTypeCode
		   ,INSERTTYPE
		   ,ModifiedOn
		   ,NatArticle_BK
		   ,PDUCode
		   ,IntPupMasterId
		   ,ArticleNumber_BK
		   ,ArticleSize_BK
		   ,BrandCode
		   ,RBUCode
		   ,ProdDivCode
		   ,StyleNumber_BK
		   ,IntAgeingCode
		   ,IntInventoryStatusCode
		   ,IntInventoryTypeCode
		   ,SPECIALSTOCKINDICATOR
		   ,GROSS
		   ,LDTS
		   ,SourceIdentifier
	FROM preHash
	WHERE HASH_Diff <> pre_HashDiff
	   OR RankOverAll = 1 -- to get the first entry
)
INSERT INTO etl.S4Hana_provFreeAvailableStocksHistory
 ( 	  
		   HASH_BK
		   ,AggInventoryMovements_HASH
		   ,AggInventoryValuations_HASH
		   ,AggInventoryTypes_HASH
		   ,HASH_Diff
		   ,POSTINGDATE
		   ,NatStoreDC_BK
		   ,COMPANYCODE
		   ,PLANT
		   ,MATERIAL
		   ,STORAGELOCATION
		   ,STOCKSEGMENT
		   ,QTYTYPE
		   ,MATERIALBASEUNIT
		   ,QTY
		   ,RunningTotal
		   ,PRICE
		   ,VALUE
		   ,PRICECURRENCY
		   ,VALIDFROMDAT
		   ,VALIDTODAT
		   ,BusinessTypeCode
		   ,INSERTTYPE
		   ,ModifiedOn
		   ,NatArticle_BK
		   ,PDUCode
		   ,IntPupMasterId
		   ,ArticleNumber_BK
		   ,ArticleSize_BK
		   ,BrandCode
		   ,RBUCode
		   ,ProdDivCode
		   ,StyleNumber_BK
		   ,IntAgeingCode
		   ,IntInventoryStatusCode
		   ,IntInventoryTypeCode
		   ,SPECIALSTOCKINDICATOR
		   ,GROSS
		   ,LDTS
		   ,SourceIdentifier)
	    SELECT HASH_BK
		   ,AggInventoryMovements_HASH
		   ,AggInventoryValuations_HASH
		   ,AggInventoryTypes_HASH
		   ,HASH_Diff
		   ,POSTINGDATE
		   ,NatStoreDC_BK
		   ,COMPANYCODE
		   ,PLANT
		   ,MATERIAL
		   ,STORAGELOCATION
		   ,STOCKSEGMENT
		   ,QTYTYPE
		   ,MATERIALBASEUNIT
		   ,ISNULL(RunningTotal-LEAD(RunningTotal) OVER(PARTITION BY AggInventoryTypes_HASH ORDER BY POSTINGDATE DESC), RunningTotal) AS QTY
		   ,RunningTotal
		   ,PRICE
		   ,VALUE
		   ,PRICECURRENCY
		   ,VALIDFROMDAT
		   ,VALIDTODAT
		   ,BusinessTypeCode
		   ,INSERTTYPE
		   ,ModifiedOn
		   ,NatArticle_BK
		   ,PDUCode
		   ,IntPupMasterId
		   ,ArticleNumber_BK
		   ,ArticleSize_BK
		   ,BrandCode
		   ,RBUCode
		   ,ProdDivCode
		   ,StyleNumber_BK
		   ,IntAgeingCode
		   ,IntInventoryStatusCode
		   ,IntInventoryTypeCode
		   ,SPECIALSTOCKINDICATOR
		   ,ISNULL([VALUE]-LEAD([VALUE]) OVER(PARTITION BY AggInventoryTypes_HASH ORDER BY POSTINGDATE DESC), [VALUE]) AS GROSS
		   ,LDTS
		   ,SourceIdentifier
		   
FROM DiffCheck

INSERT INTO [sourcing].[FreeAvailableStockHistory]
	   (	HASH_BK
		   ,AggInventoryMovements_HASH
		   ,AggInventoryValuations_HASH
		   ,AggInventoryTypes_HASH
		   ,HASH_Diff
		   ,POSTINGDATE
		   ,NatStoreDC_BK
		   ,COMPANYCODE
		   ,PLANT
		   ,MATERIAL
		   ,STORAGELOCATION
		   ,STOCKSEGMENT
		   ,QTYTYPE
		   ,MATERIALBASEUNIT
		   ,QTY
		   ,RunningTotal
		   ,PRICE
		   ,VALUE
		   ,PRICECURRENCY
		   ,VALIDFROMDAT
		   ,VALIDTODAT
		   ,BusinessTypeCode
		   ,INSERTTYPE
		   ,ModifiedOn
		   ,NatArticle_BK
		   ,PDUCode
		   ,IntPupMasterId
		   ,ArticleNumber_BK
		   ,ArticleSize_BK
		   ,BrandCode
		   ,RBUCode
		   ,ProdDivCode
		   ,StyleNumber_BK
		   ,IntAgeingCode
		   ,IntInventoryStatusCode
		   ,IntInventoryTypeCode
		   ,SPECIALSTOCKINDICATOR
		   ,GROSS
		   ,LDTS)
SELECT HASH_BK
		   ,AggInventoryMovements_HASH
		   ,AggInventoryValuations_HASH
		   ,AggInventoryTypes_HASH
		   ,HASH_Diff
		   ,POSTINGDATE
		   ,NatStoreDC_BK
		   ,COMPANYCODE
		   ,PLANT
		   ,MATERIAL
		   ,STORAGELOCATION
		   ,STOCKSEGMENT
		   ,QTYTYPE
		   ,MATERIALBASEUNIT
		   ,QTY
		   ,RunningTotal
		   ,PRICE
		   ,VALUE
		   ,PRICECURRENCY
		   ,VALIDFROMDAT
		   ,VALIDTODAT
		   ,BusinessTypeCode
		   ,INSERTTYPE
		   ,ModifiedOn
		   ,NatArticle_BK
		   ,PDUCode
		   ,IntPupMasterId
		   ,ArticleNumber_BK
		   ,ArticleSize_BK
		   ,BrandCode
		   ,RBUCode
		   ,ProdDivCode
		   ,StyleNumber_BK
		   ,IntAgeingCode
		   ,IntInventoryStatusCode
		   ,IntInventoryTypeCode
		   ,SPECIALSTOCKINDICATOR
		   ,GROSS
		   ,LDTS

	FROM etl.S4Hana_provFreeAvailableStocksHistory
	WHERE SourceIdentifier = 1 -- only new entiers 

--Update LEDTS for entires with fresh inserted entries for this BK
/*UPDATE histPre
	SET histPre.POSTINGDATEVALIDTO = new.POSTINGDATEVALIDTO
	FROM [sourcing].[FreeAvailableStockHistory] AS histPre
	INNER JOIN etl.S4Hana_FreeAvailableStocksHistory AS new
		ON 	histPre.Plant              =new.Plant             
		AND histPre.Material		   =new.Material		  
		AND histPre.StockSegment	   =new.StockSegment	
		AND histPre.POSTINGDATE = new.POSTINGDATE
	  AND new.SourceIdentifier = 2 -- only update Objects loaded from Hist table
COMMIT TRAN; */

END