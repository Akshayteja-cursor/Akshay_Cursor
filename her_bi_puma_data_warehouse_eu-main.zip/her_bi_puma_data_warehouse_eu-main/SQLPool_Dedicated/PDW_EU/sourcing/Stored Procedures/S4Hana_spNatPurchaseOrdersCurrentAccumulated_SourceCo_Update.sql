﻿CREATE PROC [sourcing].[S4Hana_spNatPurchaseOrdersCurrentAccumulated_SourceCo_Update] @LDTS [DATETIME2](7) AS
BEGIN
    DECLARE   @CurrentTimestamp DATETIME = GETDATE()
            , @DataTransferLogId UNIQUEIDENTIFIER = NEWID()
            , @UpdatedRows BIGINT = 0

    --Log data load begin 
    INSERT INTO etl.DataTransferLogs
    (
        DataTransferLogId
      , TransferName
      , TransferGroupName
      , TargetTableName
      , TargetSchemaName
      , ExecStart
      , BatchLdts
    )
    SELECT
        @DataTransferLogId
      , 'spNatPurchaseOrdersCurrentAccumulated_SourceCo_Update'
      , 'NatPurchaseOrders'
      , 'NatPurchaseOrdersCurrentAccumulated'
      , 'sourcing'
      , @CurrentTimestamp
      , @LDTS

    
    IF OBJECT_ID(N'etl.SourceCo_ProvPurchases', N'U') IS NOT NULL
        DROP TABLE etl.SourceCo_ProvPurchases;

	SELECT  [fact_purchase_orders_key]
			,[po_number] AS [PONo]
			,[po_item] AS [POItemNo]
			,[article_size_bk] AS ArticleSize_BK
			,[customer_po_number] AS [CustomerPONo]
			,[style_number_bk] AS [StyleNumber_BK]
			,[sold_to_number] AS [SourcingCustomerCode]
			,[ultimate_customer_number] AS [UltimateSourcingCustomerCode]
			,[ultimate_customer_po_number] AS [UltimateCustomerPONo]
			,[order_placement_date] AS [OPD]
			,[requested_handover_date] AS [RequestedHandoverDate]
			,[confirmed_handover_date] AS [ConfirmedHandoverDate]
			,[last_confirmed_handover_date] AS [LastConfirmedHandoverDate]
			,[po_supplier_code] AS [POSupplierCode]
			,[po_factory_code] AS [POFactoryCode]
			,[order_character_code] AS [OrderCharacterCode]
			,[order_character_desc] AS [OrderCharacterDesc]
			,[shipment_status] AS [ShipmentStatus]
			,[shipping_mode_code] AS [ShippingMode]
			,[r_ship_mode_desc] AS [ShippingModeDescription]
			,[etadp] AS Etadp
			,[etdop] AS Etdop
			,[modified_on] AS [ModifiedOn]
	INTO    [etl].[SourceCo_ProvPurchases]
	FROM    [sourcing].[fact_purchase_orders_DL]
	WHERE   [sold_to_number] IN ('ITPUI','ESPUE','FRPUF', 'DEPUD') 
    AND Active = 1

    IF OBJECT_ID('tempdb..#SourceCoPOsWithoutDuplicates') IS NOT NULL
        DROP TABLE #SourceCoPOsWithoutDuplicates
	;WITH SourceCoPOsDuplicatesRank AS
	(
		SELECT  [PONo]
				,[POItemNo]
				,[CustomerPONo]
				,[StyleNumber]
				,artsiz.[ColorNumber] as [ColorNumber]
				,artsiz.[SizeNumber] as [SizeNumber]
				,POs.[ArticleSize_BK] as [ArticleSize_BK]
				,[SourcingCustomerCode]
				,[UltimateSourcingCustomerCode]
				,cust.[customer_name] as [UltimateSourcingCustomerName]
				,artsiz.[EANNo] as [EANNo]
				,[UltimateCustomerPONo]
				,[OPD]
				,CAST([RequestedHandoverDate] AS DATE) AS [RequestedHandoverDate]
				,CAST([ConfirmedHandoverDate] AS DATE) AS [ConfirmedHandoverDate]
				,CAST([LastConfirmedHandoverDate] AS DATE) AS [LastConfirmedHandoverDate]
				,[POSupplierCode]
				,supplier.SupplierName as [POSupplierName]
				,[POFactoryCode]
				,factory.FactoryName as [POFactoryName]
				,NULL/*cust.[PDU_code]*/ as [UltimateCustomerPDUId]
				,[OrderCharacterCode]
				,[OrderCharacterDesc]
				,CAST(et.[FirstETADestinationPort] AS DATE) as [FirstETADestinationPort]
				,CAST(et.[LastETADestinationPort] AS DATE) as [LastETADestinationPort]
				,CAST(et.[FirstETDOriginPort] AS DATE) as [FirstETDOriginPort]
				,CAST(et.[LastETDOriginPort] AS DATE) as [LastETDOriginPort]
				,[ShipmentStatus]
				,[ShippingMode]
				,[ShippingModeDescription]
				,ROW_NUMBER() OVER(PARTITION BY [PONo], [POItemNo] ORDER BY [ModifiedOn] desc) as rnk
				,[ModifiedOn]		
			FROM [etl].[SourceCo_ProvPurchases] POs  
		join (select 
				[fact_purchase_orders_key], 
				min(Etadp) as [FirstETADestinationPort], 
				max(Etadp) as [LastETADestinationPort],
				min(Etdop) as [FirstETDOriginPort], 
				max(Etdop) as [LastETDOriginPort]
			from [etl].[SourceCo_ProvPurchases]
			group by [fact_purchase_orders_key]
			) et
				on POs.[fact_purchase_orders_key] = et.[fact_purchase_orders_key]
		left join [ref].[vArticlesSizesComposite_DL] artsiz on POs.[ArticleSize_BK] = artsiz.[ArticleSize_BK]
		left join [ref].[vdim_customers_DL] cust on POs.[UltimateSourcingCustomerCode] = cust.[customer_number]
		left join [ref].[vGlobalPDM_Vendors] factory on POs.[POFactoryCode] = factory.FactoryCode
		left join (select distinct SupplierCode, SupplierName from [ref].[vGlobalPDM_Vendors]) supplier on POs.[POSupplierCode] = supplier.SupplierCode
	 )
	 SELECT *
	 INTO #SourceCoPOsWithoutDuplicates
	 FROM SourceCoPOsDuplicatesRank
	 WHERE rnk = 1

	 IF OBJECT_ID('tempdb..#SourceCoPOsWithoutDuplicatesRank') IS NOT NULL
        DROP TABLE #SourceCoPOsWithoutDuplicatesRank

	 ;WITH SourceCoPOsWithoutDuplicatesRank AS
	 (
		SELECT *, ROW_NUMBER() OVER (PARTITION BY PONo, ArticleSize_BK
				--convoluted version of ORDER BY from on prem:
				ORDER BY POItemNo, ArticleSize_BK) AS PORowNum
		FROM #SourceCoPOsWithoutDuplicates
	 )

	 SELECT *
	 INTO #SourceCoPOsWithoutDuplicatesRank
	 FROM SourceCoPOsWithoutDuplicatesRank
    
    IF OBJECT_ID('tempdb..#TempNatPurchaseOrdersCurrentAccumulated_SourceCo') IS NOT NULL
        DROP TABLE #TempNatPurchaseOrdersCurrentAccumulated_SourceCo

    CREATE TABLE #TempNatPurchaseOrdersCurrentAccumulated_SourceCo
    WITH
    (
      DISTRIBUTION = HASH(CustomerPONo),
	  CLUSTERED INDEX (CustomerPONo ASC)
    )
    AS
    SELECT
         PONo
       , POItemNo
       , CustomerPONo
       , ISNULL(TRY_CAST(NULLIF(StyleNumber, '') AS INT), 0) AS StyleNumber
       , ISNULL(TRY_CAST(NULLIF(ColorNumber, '') AS SMALLINT), 0) AS ColorNumber
       , ISNULL(TRY_CAST(NULLIF(SizeNumber, '') AS INT), 0) AS SizeNumber
       , CONCAT(CAST(ISNULL(TRY_CAST(NULLIF(StyleNumber, '') AS INT), 0) AS NVARCHAR(10)), ' ', CAST(ISNULL(TRY_CAST(NULLIF(ColorNumber, '') AS SMALLINT), 0) AS NVARCHAR(2)), ' ', CAST(ISNULL(TRY_CAST(NULLIF(SizeNumber, '') AS INT), 0) AS NVARCHAR(18))) AS ArticleSize_BK
       , SourcingCustomerCode
       , UltimateSourcingCustomerCode
       , UltimateSourcingCustomerName
       , EANNo
       , UltimateCustomerPONo
       , NULLIF(OPD, '') AS OPD
       , CAST(REPLACE(NULLIF(RequestedHandoverDate, ''), '-', '') AS INT) AS RequestedHandoverDate
       , CAST(REPLACE(NULLIF(ConfirmedHandoverDate, ''), '-', '') AS INT) AS ConfirmedHandoverDate
       , CAST(REPLACE(NULLIF(LastConfirmedHandoverDate, '') , '-', '') AS INT) AS LastConfirmedHandoverDate
       , POSupplierCode
       , POSupplierName
       , POFactoryCode
       , POFactoryName
       , CAST(REPLACE(NULLIF(FirstETADestinationPort, ''), '-', '') AS INT) AS FirstETADestinationPort
       , CAST(REPLACE(NULLIF(LastETADestinationPort, ''), '-', '') AS INT) AS LastETADestinationPort
       , CAST(REPLACE(NULLIF(FirstETDOriginPort, ''), '-', '') AS INT) AS FirstETDOriginPort
       , CAST(REPLACE(NULLIF(LastETDOriginPort, ''), '-', '') AS INT) AS LastETDOriginPort
       , PORowNum
	   , CONVERT([BINARY](16),
				HASHBYTES('MD5',CONCAT(
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PONo)))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), POItemNo)))),'_',				
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), CustomerPONo)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), StyleNumber)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ColorNumber)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), SizeNumber)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), SourcingCustomerCode)))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), UltimateSourcingCustomerCode)))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), UltimateSourcingCustomerName)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), EANNo)))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), UltimateCustomerPONo)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), OPD)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), RequestedHandoverDate)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), ConfirmedHandoverDate)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), LastConfirmedHandoverDate)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), POSupplierCode)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), POSupplierName)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), POFactoryCode)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), POFactoryName)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FirstETADestinationPort)))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), LastETADestinationPort)))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), FirstETDOriginPort)))),'_',
                UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), LastETDOriginPort)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200), PORowNum))))))
			) AS HashDiff
    FROM #SourceCoPOsWithoutDuplicatesRank
    OPTION (LABEL='sourcing.S4Hana_spNatPurchaseOrdersCurrentAccumulated_SourceCo_Update: CreateTempSourceCoPOTableAsSelect')

    --update changed
    ;WITH NatPurchaseOrdersCurrentAccumulatedRowNum
    AS
    (
        SELECT
          NatPurchaseOrderNo
        , SourcingCustomerCode
        , CONCAT(CAST(ISNULL(TRY_CAST(PARSENAME(REPLACE(ArticleSize_BK, ' ', '.'), 3) AS INT), 0) AS NVARCHAR(10)), ' ', CAST(ISNULL(TRY_CAST(PARSENAME(REPLACE(ArticleSize_BK, ' ', '.'), 2) AS INT), 0) AS NVARCHAR(2)), ' ', CAST(ISNULL(TRY_CAST(PARSENAME(REPLACE(ArticleSize_BK, ' ', '.'), 1) AS INT), 0) AS NVARCHAR(18))) AS ArticleSize_BK
        , ROW_NUMBER() OVER (PARTITION BY NatPurchaseOrderNo, ArticleSize_BK ORDER BY CAST(NatPurchaseOrderItemNo AS INT)) AS NatPORowNum
        , ModifiedOn
        , scoHashDiff
        , scoPONo
        , scoCustomerCode
        , scoUltimateCustomerCode
        , scoUltimateCustomerName
        , scoUltimateCustomerPONo
        , scoOPD
        , scoRequestedHandoverDate
        , scoConfirmedHandoverDate
        , scoLastConfirmedHandoverDate
        , scoSupplierCode
        , scoSupplierName
        , scoFactoryCode
        , scoFactoryName
        , scoFirstETDOriginPort
        , scoLastETDOriginPort
        , scoFirstETADestinationPort
        , scoLastETADestinationPort
        FROM sourcing.NatPurchaseOrdersCurrentAccumulated npo
        WHERE EXISTS
        (
            SELECT 1
            FROM #TempNatPurchaseOrdersCurrentAccumulated_SourceCo etlsco
            WHERE etlsco.CustomerPONo = npo.NatPurchaseOrderNo
        )
    )
    UPDATE
          dest
    SET
          dest.scoHashDiff = src.HashDiff
        , dest.scoPONo = src.PONo
        , dest.scoCustomerCode = src.SourcingCustomerCode
        , dest.scoUltimateCustomerCode = src.UltimateSourcingCustomerCode
        , dest.scoUltimateCustomerName = src.UltimateSourcingCustomerName
        , dest.scoUltimateCustomerPONo = src.UltimateCustomerPONo
        , dest.scoOPD = src.OPD
        , dest.scoRequestedHandoverDate = src.RequestedHandoverDate
        , dest.scoConfirmedHandoverDate = src.ConfirmedHandoverDate
        , dest.scoLastConfirmedHandoverDate = src.LastConfirmedHandoverDate
        , dest.scoSupplierCode = src.POSupplierCode
        , dest.scoSupplierName = src.POSupplierName
        , dest.scoFactoryCode = src.POFactoryCode
        , dest.scoFactoryName = src.POFactoryName
        , dest.scoFirstETDOriginPort = src.FirstETDOriginPort
        , dest.scoLastETDOriginPort = src.LastETDOriginPort
        , dest.scoFirstETADestinationPort = src.FirstETADestinationPort
        , dest.scoLastETADestinationPort = src.LastETADestinationPort
        , dest.ModifiedOn = CAST(@CurrentTimestamp AS SMALLDATETIME)
    FROM  NatPurchaseOrdersCurrentAccumulatedRowNum         AS dest
    JOIN  #TempNatPurchaseOrdersCurrentAccumulated_SourceCo  AS src ON   dest.NatPurchaseOrderNo = src.CustomerPONo
                                                                    AND  dest.SourcingCustomerCode = src.SourcingCustomerCode
                                                                    AND  dest.ArticleSize_BK = src.ArticleSize_BK
                                                                    AND  dest.NatPORowNum = src.PORowNum
    WHERE ISNULL(dest.scoHashDiff, 0x00000000000000000000000000000000) <> src.HashDiff
    OPTION (LABEL = 'sourcing.S4Hana_spNatPurchaseOrdersCurrentAccumulated_SourceCo_Update: InheritUpdateStatement')

    SELECT   TOP 1
             @UpdatedRows = es.row_count
    FROM     sys.dm_pdw_exec_requests er
    JOIN     sys.dm_pdw_request_steps es ON er.request_id = es.request_id
    WHERE    es.row_count > -1 AND er.[label] = 'sourcing.S4Hana_spNatPurchaseOrdersCurrentAccumulated_SourceCo_Update: InheritUpdateStatement'
    ORDER BY er.end_time DESC;

    --Log data load end
    UPDATE
          etl.DataTransferLogs
    SET
          ExecEnd = GETDATE()
        , Updated = @UpdatedRows
    WHERE DataTransferLogId = @DataTransferLogId
END