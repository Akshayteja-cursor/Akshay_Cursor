﻿CREATE VIEW [sourcing].[vNatPurchaseOrdersCurrentAccumulated_CEU]
AS SELECT *
FROM sourcing.NatPurchaseOrdersCurrentAccumulated
WHERE COMPANYCODE in ('AT19' ,'BE19','DE19' ,'CH19', 'NL19');