﻿CREATE VIEW [sourcing].[vFreeAvailableStockHistory_FRA]
AS SELECT *
FROM sourcing.FreeAvailableStockHistory
WHERE COMPANYCODE = 'FR10';