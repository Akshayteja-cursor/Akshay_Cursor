﻿CREATE VIEW [sourcing].[vInventoriesHistory_FRA]
AS SELECT *
FROM sourcing.InventoriesHistory
WHERE COMPANYCODE = 'FR10';