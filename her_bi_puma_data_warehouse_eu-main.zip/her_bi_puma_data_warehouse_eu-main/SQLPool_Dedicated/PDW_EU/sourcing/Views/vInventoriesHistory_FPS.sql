﻿CREATE VIEW [sourcing].[vInventoriesHistory_FPS]
AS select 
HASH_BK
,AggInventoryMovements_HASH
,AggInventoryValuations_HASH
,AggInventoryTypes_HASH
,HASH_Diff
,NatStoreDC_BK
,COMPANYCODE
,PLANT
,MATERIAL
,STORAGELOCATION
,STOCKSEGMENT
,BATCHID
,QTYTYPE
,MATERIALBASEUNIT
,QTY as InventoryUnits
,RunningTotal
,PRICE
,[VALUE] as InventoryNetValue
,PRICECURRENCY
,VALIDFROMDAT
,VALIDTODAT
,CAST( trans.[PostingDate] AS DATE)  as BookingDate
,BusinessTypeCode
,INSERTTYPE
,ModifiedOn
,NatArticle_BK
,PDUCode
,IntPupMasterId
,ArticleNumber_BK
,ArticleSize_BK
,BrandCode
,RBUCode
,ProdDivCode
,StyleNumber_BK
,IntAgeingCode
,IntInventoryStatusCode
,IntInventoryTypeCode
,SPECIALSTOCKINDICATOR
,GROSS as InventoryGrossValue
,_LDTS
FROM [sourcing].[InventoriesHistory] trans 
where NatStoreDC_BK ='2601|ES10';