﻿CREATE VIEW [sourcing].[vFreeAvailableStockHistory_SE]
AS SELECT *
FROM sourcing.FreeAvailableStockHistory
WHERE COMPANYCODE IN ('ES10','PT10','IT10');