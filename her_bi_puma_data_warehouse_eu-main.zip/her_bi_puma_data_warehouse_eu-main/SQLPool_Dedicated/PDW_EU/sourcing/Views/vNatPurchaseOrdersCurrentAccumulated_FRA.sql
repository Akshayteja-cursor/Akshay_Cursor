﻿CREATE VIEW [sourcing].[vNatPurchaseOrdersCurrentAccumulated_FRA]
AS SELECT *
FROM sourcing.NatPurchaseOrdersCurrentAccumulated
WHERE COMPANYCODE = 'FR10';