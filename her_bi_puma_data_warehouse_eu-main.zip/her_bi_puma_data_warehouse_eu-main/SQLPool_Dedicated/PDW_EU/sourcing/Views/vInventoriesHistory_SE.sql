﻿CREATE VIEW [sourcing].[vInventoriesHistory_SE]
AS SELECT *
FROM sourcing.InventoriesHistory
WHERE COMPANYCODE IN ('ES10','PT10','IT10');