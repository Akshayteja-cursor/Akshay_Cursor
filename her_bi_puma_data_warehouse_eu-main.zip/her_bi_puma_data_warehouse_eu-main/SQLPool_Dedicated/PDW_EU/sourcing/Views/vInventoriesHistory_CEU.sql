﻿CREATE VIEW [sourcing].[vInventoriesHistory_CEU]
AS SELECT *
FROM sourcing.InventoriesHistory
WHERE COMPANYCODE in ('AT19' ,'BE19','DE19' ,'CH19', 'NL19');