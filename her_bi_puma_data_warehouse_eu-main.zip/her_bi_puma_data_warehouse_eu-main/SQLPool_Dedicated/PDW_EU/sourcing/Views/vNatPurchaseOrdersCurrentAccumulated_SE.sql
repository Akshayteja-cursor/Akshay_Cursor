﻿CREATE VIEW [sourcing].[vNatPurchaseOrdersCurrentAccumulated_SE]
AS SELECT *
FROM sourcing.NatPurchaseOrdersCurrentAccumulated
WHERE COMPANYCODE IN ('ES10','PT10','IT10');