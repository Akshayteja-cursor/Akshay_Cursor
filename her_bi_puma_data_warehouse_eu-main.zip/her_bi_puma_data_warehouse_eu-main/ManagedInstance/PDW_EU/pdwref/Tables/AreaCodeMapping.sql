﻿CREATE TABLE [pdwref].[AreaCodeMapping] (
    [Country]     VARCHAR (20) NULL,
    [PDUCode]     VARCHAR (10) NULL,
    [CompanyCode] VARCHAR (4)  NULL,
    [SalesOrg]    INT          NULL,
    [PDUAreaCode] VARCHAR (20) NULL
);

