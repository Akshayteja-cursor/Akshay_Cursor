﻿CREATE EXTERNAL TABLE [Ref].[vSizes_DL] (
    [SizeNumber] INT NULL,
    [SizeCode] NVARCHAR (MAX) NULL,
    [SizeTableCode] INT NULL,
    [ProductDivisionCode] INT NULL,
    [IntBrandCode] NVARCHAR (MAX) NULL,
    [SizeTableShortName] NVARCHAR (MAX) NULL,
    [SizeTableDesc] NVARCHAR (MAX) NULL,
    [LabelGender] NVARCHAR (MAX) NULL,
    [SizeRange] NVARCHAR (MAX) NULL,
    [AgeGroup] NVARCHAR (MAX) NULL,
    [TableGender] NVARCHAR (MAX) NULL,
    [LockingFlag] SMALLINT NULL,
    [LockingDate] DATE NULL,
    [Description] NVARCHAR (MAX) NULL,
    [Remark] NVARCHAR (MAX) NULL,
    [SizeConversionCodeUS] NVARCHAR (MAX) NULL,
    [SizeConversionScaleCodeUS] NVARCHAR (MAX) NULL,
    [CreatedOn] DATETIME NULL,
    [ModifiedOn] DATETIME NULL
)
    WITH (
    DATA_SOURCE = [ds_bigbd_encur_curated],
    LOCATION = N'/PDW_ArticleInformation/ref/vSizes/*',
    FILE_FORMAT = [ff_parquet],
    REJECT_TYPE = VALUE,
    REJECT_VALUE = 0
    );

