﻿CREATE EXTERNAL TABLE [Ref].[PlantMaterialPricesHistory_DL] (
    [HashValueBK] BINARY (16) NULL,
    [ArticleSize_BK] NVARCHAR (40) NULL,
    [GSMStoreCode] NVARCHAR (20) NULL,
    [ArticleCurrencyCode] NVARCHAR (5) NULL,
    [UnitLandedCost] DECIMAL (18, 2) NULL,
    [ValidFrom] DATE NULL,
    [ValidTo] DATE NULL,
    [HashDiff] BINARY (16) NULL,
    [CreationDate] DATETIME NOT NULL,
    [ModificationDate] DATETIME NOT NULL
)
    WITH (
    DATA_SOURCE = [ds_bieurope_encur_curated],
    LOCATION = N'/PDW_SE/ref/PlantMaterialPricesHistory/',
    FILE_FORMAT = [ff_parquet],
    REJECT_TYPE = VALUE,
    REJECT_VALUE = 0
    );

