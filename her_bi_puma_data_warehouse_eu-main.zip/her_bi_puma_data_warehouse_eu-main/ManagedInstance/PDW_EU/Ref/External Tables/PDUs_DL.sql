﻿CREATE EXTERNAL TABLE [Ref].[PDUs_DL] (
    [PDUCode] NVARCHAR (10) NULL,
    [PDUDesc] NVARCHAR (120) NULL,
    [FCUnitCountryCode] NVARCHAR (10) NULL,
    [FCUnitCountryDesc] NVARCHAR (120) NULL,
    [FCUnitAreaCode] NVARCHAR (10) NULL,
    [FCUnitAreaDesc] NVARCHAR (120) NULL,
    [FCUnitRegionCode] NVARCHAR (10) NULL,
    [FCUnitRegionDesc] NVARCHAR (120) NULL,
    [ISRCountryCode] NVARCHAR (10) NULL,
    [ISRCountryDesc] NVARCHAR (120) NULL,
    [ISRAreaCode] NVARCHAR (10) NULL,
    [ISRAreaDesc] NVARCHAR (120) NULL,
    [ISRRegionCode] NVARCHAR (10) NULL,
    [ISRRegionDesc] NVARCHAR (120) NULL,
    [FCUnitCountryISOCurrencyCode] NVARCHAR (3) NULL,
    [PDUHashBK] BINARY (16) NULL,
    [ModifiedOn] DATETIME NULL
)
    WITH (
    DATA_SOURCE = [ds_bigbd_encur_curated],
    LOCATION = N'/PDW_ArticleInformation/ref/vPDUs/*',
    FILE_FORMAT = [ff_parquet],
    REJECT_TYPE = VALUE,
    REJECT_VALUE = 0
    );

