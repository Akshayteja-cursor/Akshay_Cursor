﻿
CREATE PROC [Ref].[sp_SellthroughStores]
AS
BEGIN

select sps_location_id
,location_id
,store_number
,store_name
,address
,city
,state
,postal_code
,country
,open_date
,close_date
,store_rank
,store_classification
,location_type
,demographic
,region
,climate
,comp_store_indicator
,store_size
,retailer_division
,banner
,gln
,currency_code
,latitude
,longitude
,FileName
,SUBSTRING(FileName, CHARINDEX('-', FileName) + 1, CHARINDEX('-', FileName, CHARINDEX('-', FileName) + 1) - CHARINDEX('-', FileName) - 1) CustomerName
,_LDTS
, CONVERT([BINARY](16), HASHBYTES('MD5',CONCAT(
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),sps_location_id)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),location_id)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),store_number)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),store_name)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),address)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),city)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),state)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),postal_code)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),country)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),open_date)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),close_date)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),store_rank)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),store_classification)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),location_type)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),demographic)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),region)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),climate)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),comp_store_indicator)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),store_size)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),retailer_division)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),banner)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),gln)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),currency_code)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),latitude)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),longitude)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),FileName)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),_LDTS)))),'_'
	))) AS HashDiff
INTO #SPS_Location
from STAG.SPS_Location


--ALTER TABLE ref.SellthroughStores
--add HashDiff binary

update RSL SET
RSL.SPSLocationId=SSL.sps_location_id
,RSL.LocationId=SSL.location_id
,RSL.StoreNumber=SSL.store_number
,RSL.StoreName=SSL.store_name
,RSL.Address=SSL.address
,RSL.City=SSL.city
,RSL.State=SSL.state
,RSL.PostalCd=SSL.postal_code
,RSL.Country=SSL.country
,RSL.OpenDt=SSL.open_date
,RSL.CloseDt=SSL.close_date
,RSL.StoreRank=SSL.store_rank
,RSL.StoreClass=SSL.store_classification
,RSL.LocationType=SSL.location_type
,RSL.Demographic=SSL.demographic
,RSL.Region=SSL.region
,RSL.Climate=SSL.climate
,RSL.CompStoreInd=SSL.comp_store_indicator
,RSL.StoreSize=SSL.store_size
,RSL.RetailerDivision=SSL.retailer_division
,RSL.Banner=SSL.banner
,RSL.GLN=SSL.gln
,RSL.CurrencyCd=SSL.currency_code
,RSL.Latitude=SSL.latitude
,RSL.Longitude=SSL.longitude
,RSL.FileName=SSL.FileName
,RSL.CustomerName=SSL.CustomerName
,RSL.LDTS=SSL._LDTS
,RSL.ModifiedOn=CAST(GETDATE() as DATETIME)
,RSL.HashDiff=SSL.HashDiff
FROM Ref.SellthroughStores RSL 
 JOIN #SPS_Location SSL ON SSL.sps_location_id = RSL.SPSLocationId
WHERE RSL.HashDiff <> SSL.HashDiff

insert into ref.SellthroughStores(
SPSLocationId
,LocationId
,StoreNumber
,StoreName
,Address
,City
,State
,PostalCd
,Country
,OpenDt
,CloseDt
,StoreRank
,StoreClass
,LocationType
,Demographic
,Region
,Climate
,CompStoreInd
,StoreSize
,RetailerDivision
,Banner
,GLN
,CurrencyCd
,Latitude
,Longitude
,[FileName]
,CustomerName
,LDTS
,CreatedOn
,HashDiff


) 
select sps_location_id
,location_id
,store_number
,store_name
,SSL.address
,SSL.city
,SSL.state
,postal_code
,SSL.country
,open_date
,close_date
,store_rank
,store_classification
,location_type
,SSL.demographic
,SSL.region
,SSL.climate
,comp_store_indicator
,store_size
,retailer_division
,SSL.banner
,SSL.gln
,currency_code
,SSL.latitude
,SSL.longitude
,SSL.FileName
,SUBSTRING(SSL.FileName, CHARINDEX('-', SSL.FileName) + 1, CHARINDEX('-', SSL.FileName, CHARINDEX('-', SSL.FileName) + 1) - CHARINDEX('-', SSL.FileName) - 1)
,_LDTS
,CAST(GETDATE() as DATETIME)
,SSL.HashDiff
from #SPS_Location SSL
LEFT JOIN Ref.SellthroughStores RSL ON SSL.sps_location_id = RSL.SPSLocationId
where RSL.SPSLocationId is null
END
--select count(1) from ref.SellthroughStores

--select * into Stag.SPS_Location_Test from stag.SPS_Location
--where 1=0