﻿
CREATE PROC [Ref].[sp_SellThroughProducts]
AS
BEGIN


select 
sps_item_id
,product_id
,product_type_id
,vendor_code
,vendor_name
,brand_code
,brand_name
,duns_number
,division_code
,division_name
,major_department_code
,major_department_name
,department_code
,department_name
,sub_department_code
,sub_department_name
,major_class_code
,major_class_name
,class_code
,class_name
,sub_class_code
,sub_class_name
,category_code
,category_name
,product_group_code
,product_group_name
,SSI.gender
,style_number
,style_description
,color_code
,color_name
,size_code
,size_name
,SSI.upc
,SSI.sku
,product_description
,CAST(corporate_unit_acquired_cost AS numeric(10,4)) corporate_unit_acquired_cost
,CAST(corporate_unit_adjusted_cost AS numeric(10,4)) corporate_unit_adjusted_cost
,CAST(corporate_unit_owned_retail_price AS numeric(10,4)) corporate_unit_owned_retail_price
,replenishment_indicator
,markdown_indicator
,first_receipt_date
,last_receipt_date
,product_season
,SSI.age
,unit_of_measure
,fedas_code
,SSI.FileName
,SUBSTRING(SSI.FileName, CHARINDEX('-', SSI.FileName) + 1, CHARINDEX('-', SSI.FileName, CHARINDEX('-', SSI.FileName) + 1) - CHARINDEX('-', SSI.FileName) - 1) CustomerName
,_LDTS
, CONVERT([BINARY](16), HASHBYTES('MD5',CONCAT(UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),sps_item_id)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),product_id)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),product_type_id)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),vendor_code)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),vendor_name)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),brand_code)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),brand_name)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),duns_number)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),division_code)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),division_name)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),major_department_code)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),major_department_name)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),department_code)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),department_name)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),sub_department_code)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),sub_department_name)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),major_class_code)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),major_class_name)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),class_code)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),class_name)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),sub_class_code)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),sub_class_name)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),category_code)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),category_name)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),product_group_code)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),product_group_name)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),SSI.gender)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),style_number)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),style_description)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),color_code)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),color_name)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),size_code)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),size_name)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),SSI.upc)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),SSI.sku)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),product_description)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),corporate_unit_acquired_cost)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),corporate_unit_adjusted_cost)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),corporate_unit_owned_retail_price)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),replenishment_indicator)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),markdown_indicator)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),first_receipt_date)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),last_receipt_date)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),product_season)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),SSI.age)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),unit_of_measure)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),fedas_code)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),SUBSTRING(SSI.FileName, CHARINDEX('-', SSI.FileName) + 1, CHARINDEX('-', SSI.FileName, CHARINDEX('-', SSI.FileName) + 1) - CHARINDEX('-', SSI.FileName) - 1)
)))),'_',
UPPER(LTRIM(RTRIM(CONVERT([NVARCHAR](200),_LDTS)))),'_'
	))) AS HashDiff
INTO #SPS_ITEM
from STAG.SPS_Item SSI



UPDATE RSI SET
 RSI.SPSItemId=SSI.sps_item_id
,RSI.ProductId=SSI.product_id
,RSI.ProductTypeId=SSI.product_type_id
,RSI.VendorCd=SSI.vendor_code
,RSI.VendorName=SSI.vendor_name
,RSI.BrandCd=SSI.brand_code
,RSI.BrandName=SSI.brand_name
,RSI.DunsNumber=SSI.duns_number
,RSI.DivisionCd=SSI.division_code
,RSI.DivisionName=SSI.division_name
,RSI.MajorDeptCd=SSI.major_department_code
,RSI.MajorDeptName=SSI.major_department_name
,RSI.DeptCd=SSI.department_code
,RSI.DeptName=SSI.department_name
,RSI.SubDeptCd=SSI.sub_department_code
,RSI.SubDeptName=SSI.sub_department_name
,RSI.MajorClassCd=SSI.major_class_code
,RSI.MajorClassName=SSI.major_class_name
,RSI.ClassCd=SSI.class_code
,RSI.ClassName=SSI.class_name
,RSI.SubClassCd=SSI.sub_class_code
,RSI.SubClassName=SSI.sub_class_name
,RSI.CategoryCd=SSI.category_code
,RSI.CategoryNm=SSI.category_name
,RSI.ProductGroupCd=SSI.product_group_code
,RSI.ProductGroupName=SSI.product_group_name
,RSI.Gender=SSI.gender
,RSI.StyleNum=SSI.style_number
,RSI.StyleDesc=SSI.style_description
,RSI.ColorCd=SSI.color_code
,RSI.ColorName=SSI.color_name
,RSI.SizeCd=SSI.size_code
,RSI.SizeName=SSI.size_name
,RSI.UPC=SSI.upc
,RSI.SKU=SSI.sku
,RSI.ProductDesc=SSI.product_description
,RSI.CorpUnitAcqCost=SSI.corporate_unit_acquired_cost
,RSI.CorpUnitAdjCost=SSI.corporate_unit_adjusted_cost
,RSI.CorpUnitOwnRetPrc=SSI.corporate_unit_owned_retail_price
,RSI.ReplenishmentInd=SSI.replenishment_indicator
,RSI.MarkdownInd=SSI.markdown_indicator
,RSI.FirstReceiptDt=SSI.first_receipt_date
,RSI.LastReceiptDt=SSI.last_receipt_date
,RSI.ProductSeason=SSI.product_season
,RSI.Age=SSI.age
,RSI.UOM=SSI.unit_of_measure
,RSI.FedasCd=SSI.fedas_code
,RSI.FileName=SSI.FileName
,RSI.CustomerName=SSI.CustomerName
,RSI.LDTS=SSI._LDTS
,RSI.ModifiedOn=CAST(GETDATE() as datetime)
,RSI.HashDiff=SSI.HashDiff
FROM Ref.SellThroughProducts RSI 
JOIN #SPS_ITEM SSI ON SSI.sps_item_id = RSI.SPSItemId
WHERE RSI.HashDiff <> SSI.HashDiff


--select CAST(getdate() as datetime)

INSERT INTO ref.SellThroughProducts(
SPSItemId
,ProductId
,ProductTypeId
,VendorCd
,VendorName
,BrandCd
,BrandName
,DunsNumber
,DivisionCd
,DivisionName
,MajorDeptCd
,MajorDeptName
,DeptCd
,DeptName
,SubDeptCd
,SubDeptName
,MajorClassCd
,MajorClassName
,ClassCd
,ClassName
,SubClassCd
,SubClassName
,CategoryCd
,CategoryNm
,ProductGroupCd
,ProductGroupName
,Gender
,StyleNum
,StyleDesc
,ColorCd
,ColorName
,SizeCd
,SizeName
,UPC
,SKU
,ProductDesc
,CorpUnitAcqCost
,CorpUnitAdjCost
,CorpUnitOwnRetPrc
,ReplenishmentInd
,MarkdownInd
,FirstReceiptDt
,LastReceiptDt
,ProductSeason
,Age
,UOM
,FedasCd
,FileName
,CustomerName
,LDTS
,HashDiff
,CreatedOn
)
select 
sps_item_id
,product_id
,product_type_id
,vendor_code
,vendor_name
,brand_code
,brand_name
,duns_number
,division_code
,division_name
,major_department_code
,major_department_name
,department_code
,department_name
,sub_department_code
,sub_department_name
,major_class_code
,major_class_name
,class_code
,class_name
,sub_class_code
,sub_class_name
,category_code
,category_name
,product_group_code
,product_group_name
,SSI.gender
,style_number
,style_description
,color_code
,color_name
,size_code
,size_name
,SSI.upc
,SSI.sku
,product_description
,CAST(corporate_unit_acquired_cost AS numeric(10,4))
,CAST(corporate_unit_adjusted_cost AS numeric(10,4))
,CAST(corporate_unit_owned_retail_price AS numeric(10,4))
,replenishment_indicator
,markdown_indicator
,first_receipt_date
,last_receipt_date
,product_season
,SSI.age
,unit_of_measure
,fedas_code
,SSI.FileName
,SUBSTRING(SSI.FileName, CHARINDEX('-', SSI.FileName) + 1, CHARINDEX('-', SSI.FileName, CHARINDEX('-', SSI.FileName) + 1) - CHARINDEX('-', SSI.FileName) - 1)
,_LDTS
,SSI.HashDiff
,CAST(GETDATE() AS datetime)
from #SPS_ITEM SSI
LEFT JOIN Ref.SellThroughProducts RSI ON SSI.sps_item_id = RSI.SPSItemId
WHERE RSI.SPSItemId IS NULL
END