﻿CREATE TABLE [Ref].[Bii_ArticleSizes] (
    [ArticleSizesId]   INT           IDENTITY (1, 1) NOT NULL,
    [HashValueBK]      BINARY (16)   NOT NULL,
    [ArticleNumber_BK] NVARCHAR (40) NOT NULL,
    [StyleNumber_BK]   INT           NOT NULL,
    [ColorNumber]      SMALLINT      NULL,
    [SizeNumber]       INT           NULL,
    [CreatedOn]        DATETIME2 (7) NOT NULL,
    [ModifiedOn]       DATETIME2 (7) NOT NULL,
    [SourceCreatedOn]  DATETIME2 (7) NOT NULL,
    [SourceModifiedOn] DATETIME2 (7) NOT NULL,
    [LDTS]             DATETIME2 (7) NOT NULL,
    [EANNo]            VARCHAR (26)  NULL,
    [UPCNo]            VARCHAR (26)  NULL,
    CONSTRAINT [PK_ref_bii_ArticleSizes] PRIMARY KEY NONCLUSTERED ([HashValueBK] ASC) WITH (FILLFACTOR = 100)
);

