﻿
CREATE PROCEDURE [Sales].[sp_SPSSellThroughInvSum]
AS
BEGIN
IF OBJECT_ID('etl.SPS_SellThroughInvSum', 'U') IS NOT NULL
  DROP TABLE etl.SPS_SellThroughInvSum;

select  ADL.ArticleNumber_BK, 
       sta.SPSLocationId, 
       Dateadd(d, 4-((Datepart(dw,convert(varchar,PeriodEndingDt))+ 5) % 7 + 1),convert(varchar,PeriodEndingDt)) as  midweek,
       sum([InvQty]) SumInv
	  into etl.SPS_SellThroughInvSum
    FROM [sales].[SellthroughActivities]  sta
	join ref.ArticleSizes_DL ADL on sta.UPC = ADL.EANNo
            group by ADL.ArticleNumber_BK, sta.SPSLocationId,
       Dateadd(d, 4-((Datepart(dw,convert(varchar,PeriodEndingDt))+ 5) % 7 + 1),convert(varchar,PeriodEndingDt)) 
	   END