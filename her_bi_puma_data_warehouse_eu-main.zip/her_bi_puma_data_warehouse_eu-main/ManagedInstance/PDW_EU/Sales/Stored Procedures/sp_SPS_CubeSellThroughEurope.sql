﻿

CREATE PROCEDURE [sales].[sp_SPS_CubeSellThroughEurope] 
	@offset int 
as

declare @year int = YEAR(GETDATE())  - @offset

BEGIN


with cte_test
as
(
SELECT stac.CustomerName, A.ArticleNumber_BK, MIN(convert(date,convert(varchar, PeriodEndingDt))) MinDate
FROM [sales].[SellthroughActivities] stac
join ref.Bii_ArticleSizes A on stac.UPC = A.EANNo --and stac.CustomerName ='TwinSport'
WHERE NetSalesQty > 0 OR GrossSalesQty > 0 
GROUP BY stac.CustomerName , A.ArticleNumber_BK 
)
select  
'SellthroughActivityId'               = NULL
    ,'SellThroughStore_HashBk'          = S.SPSLocationId
    ,'SellThroughProduct_HashBk'        = SPSItemId
    ,'SalesDate'                        = format(cast(cast(PeriodEndingDt as nvarchar)as date), 'yyyy-MM-dd')
    ,'MidWeekDate'                      = Dateadd(d, 4-((Datepart(dw,format(cast(cast(PeriodEndingDt as nvarchar)as date), 'yyyy-MM-dd'))+ 5) % 7 + 1),format(cast(cast(PeriodEndingDt as nvarchar)as date), 'yyyy-MM-dd'))
    ,'ArticleNumber_BK'                 = a.ArticleNumber_BK
    ,'ArticleNumber'                    = a.ArticleNumber_BK
    ,'StyleNumber_BK'                   = a.StyleNumber_BK
    ,'ArticleSize_BK'                   = CONCAT(A.ArticleNumber_BK, ' ' , A.[SizeNumber])
    ,'EAN'                              = UPC
    ,'PDUCode'                          = [PDUCode] -- char
    ,'CustomerOrganisationId'           = c.CustomerOrganisation-- NULL -- char
    ,'CurrencyCode'                      = c.ISOCurrency --char
    ,'CustomerName'                     = S.CustomerName
    ,'FileDate'                         = S.FileDate
    --,'SoldToNumber'                     = [CustomerNumber] --char
    ,'NatCustomer_BK'                   = C.[CustomerNumber] +'|'+C.PDUCode +'|'+cast(C.IntPupMaster as nvarchar)--char
    ,'RBUCode'                          = NULL
    ,'ProductDivisionCode'              = NULL
    ,'BrandCode'                        = NULL
    ,'Country'                          = S.Country

    /* new BYOD */
    ,'Store'                            = S.StoreName
    ,'CustomerSKU'                      = NULL
    ,'CustomerCategory1'                = NULL
    ,'CustomerCategory2'                = NULL
    ,'CustomerCategory3'                = NULL
    ,'BuyingTeam'                       = NULL

    ,'GrossSalesQty'                    = NULLIF([GrossSalesQty],0)
    ,'GrossSalesCost'                   = NULLIF([GrossSalesCost],0)
    ,'GrossSalesRet'                    = NULLIF([GrossSalesRet],0)
    ,'GrossSalesMgn'                    = NULL
    ,'NetSalesQty'                      = NULLIF([NetSalesQty],0)
    ,'NetSalesCost'                     = NULL
    ,'NetSalesRet'                      = NULLIF([NetSalesRet],0)
    ,'NetSalesMgn'                      = NULL
    ,'CustRtnQty'                       = CASE WHEN GrossSalesQty is null or NetSalesQty is null THEN null ELSE GrossSalesQty - NetSalesQty END 
    ,'CustRtnCost'                      = NULL
    ,'CustRtnRet'                       = NULL
    ,'CustRtnMgn'                       = NULL
    ,'InvQty'                           = NULLIF([InvQty],0) 
    ,'InvCost'                          = NULLIF([InvCost],0) 
    ,'InvRet'                           = NULL
    ,'OrdQty'                           = NULL
    ,'OrdCost'                          = NULLIF(OrdCost,0)
    ,'OrdRet'                           = NULLIF(OrdRet,0)
    ,'ReceiptQty'                       = NULLIF([ReceiptQty],0)
    ,'ReceiptCost'                      = NULLIF(ReceiptCost,0) 
    ,'ReceiptRet'                       = NULL
    ,'ItrQty'                           = NULLIF([ItrQty],0)
    ,'ItrCost'                          = NULLIF(ItrCost,0)
    ,'ItrRet'                           = NULL
    ,'VendRtnQty'                       = NULL
    ,'VendRtnCost'                      = NULL
    ,'VendRtnRet'                       = NULL
    ,'InvAdjQty'                        = NULL
    ,'InvAdjCost'                       = NULL
    ,'InvAdjRet'                        = NULL
    ,'PermMarkdown'                     = NULL
    ,'POSMarkdown'                      = NULL
    ,'TotalMarkdown'                    = NULL
    ,'CorpUnitAdjCost'                  = NULL
    ,'CorpUnitAcqCost'                  = NULL
    ,'CorpUnitOwnRetPrc'                = NULLIF([CorpUnitOwnRetPrc],0) 
    ,'CustomerReservedField1'           = NULL
    ,'CustomerReservedField2'           = NULL
    ,'CustomerReservedField3'           = NULL
    ,'CustomerReservedField4'           = NULL
    ,'CustomerReservedField5'           = NULL
    ,'CustomerReservedField6'           = NULL
    ,'CustomerReservedField7'           = NULL
    ,'CustomerReservedField8'           = NULL
    ,'CustomerReservedField9'           = NULL
    ,'CustomerReservedField10'          = NULL
    ,'CustomerAttribute1'               = NULL
    ,'CustomerAttribute2'               = NULL
    ,'CustomerAttribute3'               = NULL
    ,'CustomerAttribute4'               = NULL
    ,'CustomerAttribute5'               = NULL
    ,'CustomerAttribute6'               = 0
    ,'CustomerAttribute7'               = 0
    ,'CustomerAttribute8'               = 0

    ,'ArticleID'                =0
    ,'ArticleSizeID'            =0

    ,'CurrencyID'               =0
    --,'CustomerOrganisationID'   =0
    ,'NatCustGSMStoresId'       =0
    --,'StyleId'                  =0
    ,'PDUId'                    =0
    ,'RetailerMargin'           =nullif(CASE WHEN ISNULL([NetSalesRet],0) <> 0 THEN [NetSalesRet] ELSE ISNULL([GrossSalesRet],0) - ISNULL([CustRtnRet],0) END -
                                  CASE WHEN ISNULL([NetSalesQty],0) <> 0 THEN [NetSalesQty] * [CorpUnitAcqCost] ELSE  (ISNULL([GrossSalesQty],0) - ISNULL([CustRtnQty],0)) * [CorpUnitAcqCost] END,0)
                                
    ,'InvSum'                   =nullif(I.SumInv,0)
,'SalesMinDate'         =cte.MinDate
,'WeeksInNeutral'       =case 
      WHEN cte.MinDate <= convert(date,convert(varchar, PeriodEndingDt)) then DATEDIFF(week, cte.MinDate, convert(date,convert(varchar, PeriodEndingDt)))
      end     

from sales.SellThroughActivities S
join Customer C on S.CustomerName = C.CustomerName and c.CustomerName not in ('ASOSPartnership') and c.CustomerName not like '%awlab%'
LEFT join ref.Bii_ArticleSizes A ON S.UPC = A.EANNo
  LEFT join [etl].[SellThroughInvSum] I on a.ArticleNumber_BK = I.ArticleNumber_BK and S.SPSLocationId = I.SPSLocationId 
and Dateadd(d, 4-((Datepart(dw,format(cast(cast(s.PeriodEndingDt as nvarchar)as date), 'yyyy-MM-dd'))+ 5) % 7 + 1),format(cast(cast(s.PeriodEndingDt as nvarchar)as date), 'yyyy-MM-dd'))=I.midweek
LEFT JOIN cte_test CTE on CTE.ArticleNumber_BK = A.ArticleNumber_BK and cte.CustomerName=s.CustomerName

WHERE  YEAR(convert(date,convert(varchar, PeriodEndingDt))) <= @year AND YEAR(convert(date,convert(varchar, PeriodEndingDt))) >= (@year -@offset) 
--where PeriodEndingDt='20240128' and s.CustomerName ='TwinSport'


END


--select * from etl.SellThroughEuropeMinDates where customername ='TwinSport' order by MinDate desc

--select * from etl.SPS_SellThroughInvSum


--select convert(date,convert(varchar, 20240128))