﻿
-- =============================================
-- Author:		<Vijay>
-- Create date: <2024-04-26>
-- Description:	<Loading SellThru for Seeburger>
-- =============================================
--exec [Sales].[spSeeburgerSellThroughActivities]
--truncate table [Sales].[SeeburgerSellThroughActivities]
CREATE PROCEDURE [Sales].[spSeeburgerSellThroughActivities]  @TypeOfProc TINYINT  = 0 
AS
BEGIN
--DECLARE @TypeOfProc TINYINT  = 0 
	--SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	SET ANSI_WARNINGS ON;
	SET XACT_ABORT ON;

	DROP TABLE IF EXISTS #SeeburgerSellthru;


	DECLARE @DelivTableName VARCHAR(255) = 'SeeburgerSellThru';
	DECLARE @LoadDate DATETIME2(7) = GETDATE();
	DECLARE @DataTransferLogId INT = NULL;
	DECLARE @RowNo BIGINT = 0;
	DECLARE @MaxLDTS DATETIME2(7) = '';
	DECLARE @TransferName		VARCHAR(225)	= 'spSeeburgerSellThroughActivities';
	DECLARE @LastRunLDTS		DATETIME2(7)
	DECLARE @LastLoadedLDTS		DATETIME2(7)
	DECLARE @MaxFullLoadLDTS  DATETIME2(7);
	DECLARE @ldts DATETIME2(7)
	select @ldts=max(_LDTS) from Stag.Seeburger_Sellout
	SET @ldts = CONVERT(DATETIME2(7), CONVERT(CHAR(19),@ldts , 126)); 

	SELECT TOP(1) @LastRunLDTS = BatchLdts 
				 ,@LastLoadedLDTS = SourceLastLoadDate  
	FROM etl.DataTransferLogs 
	WHERE ExecEnd IS NOT NULL
	   AND TransferName = @TransferName 	  
	ORDER BY ExecStart DESC;
	
	--SELECT @MaxLDTS = MAX(_LDTS)
	--FROM stag.Bii_TransferDataControl AS tdc
 --   WHERE  tdc.DelivTableName = @DelivTableName;


	--IF  @TypeOfProc = 0 AND @LastRunLDTS = @ldts AND @LastLoadedLDTS = @MaxLDTS 
	--RETURN;
--Log Start Data load
	INSERT INTO etl.DataTransferLogs
		  (TransferName
		  ,TransferGroupName
		  ,TargetTableName
		  ,TargetSchemaName
		  ,ExecStart
		  ,SourceLastLoadDate
		  ,BatchLdts
		  ,TypeOfProc)
		  SELECT 'spSeeburgerSellThroughActivities'
				,'SeeburgerSellThru'
				,'SeeburgerSellThroughActivities'
				,'sales'
				,@LoadDate
				,@MaxLDTS
				,@ldts
				,@TypeOfProc
	SET @DataTransferLogId = @@Identity 

--	--simulate TransferDataControl table
--	--DML option possible values are ‘D’ = Deletion, ‘U’ = Update , ‘I’ = Insert, ‘F’ = Full Load 
--	DROP TABLE IF EXISTS #TransferDataControl
 --   SELECT 'ImpNatCustomers' AS DelivTableName, 'F' AS DelivMethod , '1900.01.01' AS LDTS INTO  #TransferDataControl



	--#############################################################  0. build staging dataset 
;
	with cte_Stag_SalesDate
	as
	(
	select min(salesdate)salesdate, sendingdate from STAG.Seeburger_Sellout where flagsalesprocess ='S'
group by sendingdate 
	),
	
	cte_Stag_SeeburgerST
	as (
	
SELECT * FROM (
SELECT 
cast(t_1 AS int)	 AS t_1
,cast(t_2 AS int)	 AS t_2
,cast(customernumber AS nvarchar(25))	 AS customernumber
,cast(customerglnnumber AS nvarchar(25))	 AS customerglnnumber
,cast(vendorglnnumber AS nvarchar(25))	 AS vendorglnnumber
,cast(customerdepartment AS nvarchar(25))	 AS customerdepartment
,cast(salesorg AS nvarchar(25))	 AS salesorg
,cast(S.sendingdate AS date)	 AS sendingdate
,cast(currencyiso AS nvarchar(25))	 AS currencyiso
,cast(storepointofsales AS nvarchar(25))	 AS storepointofsales
,cast(case when S.salesdate ='' and s.flagsalesprocess='L' then MS.salesdate else S.salesdate end AS date)	 AS salesdate
,cast(flagsalesreturns AS int)	 AS flagsalesreturns
,cast(flagsalesprocess AS varchar(5))	 AS flagsalesprocess
,case when ean_upc='9999999999999' or ean_upc='' then 'n/a' else cast(ean_upc AS nvarchar(25)) end	 AS ean_upc
,NULLIF(case when (flagsalesprocess ='S' OR flagsalesprocess='C') and flagsalesreturns ='1' then cast(quantityofsales as int) END,0) as GrossSalesQty
,NULLIF(case when (flagsalesprocess ='S' OR flagsalesprocess='C') and flagsalesreturns ='1' then cast(iif(lineitemamountinclvat='','0',lineitemamountinclvat) as Numeric(14,4)) END,0) as GrossSalesRet
,NULLIF(case when (flagsalesprocess ='S' OR flagsalesprocess='C') and flagsalesreturns ='2' then cast(quantityofsales as int) END,0) as CustRtnQty
,NULLIF(case when (flagsalesprocess ='S' OR flagsalesprocess='C') and flagsalesreturns ='2' then cast(iif(lineitemamountinclvat='','0',lineitemamountinclvat) as  Numeric(14,4)) END,0) as CustRtnRet
,NULLIF(case when (flagsalesprocess ='S' OR flagsalesprocess='C') and flagsalesreturns ='1' then cast(iif(lineitemamountinclvat='','0',lineitemamountinclvat) as Numeric(14,4)) end,0) + 
 NULLIF(case when (flagsalesprocess ='S' OR flagsalesprocess='C') and flagsalesreturns ='2' then cast(iif(lineitemamountinclvat='','0',lineitemamountinclvat) as Numeric(14,4)) END,0) as NetSalesRet
,case when (flagsalesprocess ='S' OR flagsalesprocess='C') and flagsalesreturns ='1' then cast(quantityofsales as int) ELSE 0 end -
 case when (flagsalesprocess ='S' OR flagsalesprocess='C') and flagsalesreturns ='2' then cast(quantityofsales as int) ELSE 0 END as NetSalesQty
,case when flagsalesprocess ='L' OR flagsalesprocess='M' then cast(iif(quantityofstock='','0',quantityofstock) as int) END as InvQty
,cast(iif(salespriceinclvat='','0', salespriceinclvat) as numeric(14,4))	 AS salespriceinclvat
,cast(iif(lineitemamountinclvat='','0',lineitemamountinclvat) AS numeric(14,4))	 AS lineitemamountinclvat
,cast(iif(suggestedretailprice='','0',suggestedretailprice) AS numeric(14,4))	 AS suggestedretailprice
,cast(quantityofsales AS int)	 AS quantityofsales
,cast(quantityofstock AS int)	 AS quantityofstock
,cast(FileName AS nvarchar(MAX))	 AS FileName
,cast(s._LDTS AS datetime2(7))	 AS _LDTS
,cast(S.RowNo AS int)	 AS RowNo
,cast(S._BatchId AS int)	 AS _BatchId
,cast(A.ArticleNumber_BK AS nvarchar(80))	 AS ArticleNumber_BK
,cast(A.StyleNumber_BK AS nvarchar(30))	 AS StyleNumber_BK
,cast(BrandCode AS nvarchar(12))	 AS BrandCode
,cast(ProductDivisionCode AS nvarchar(30))	 AS ProductDivisionCode
,cast(RBUCode AS nvarchar(30))	 AS RBUCode
,cast(CONCAT(NC.FRLegacyCustomer,'|PLFRALD|32') AS nvarchar(40))	 AS NatCustomer_BK
,'PLFRALD' AS PDUCode
--******************* if not required remove
,ROW_NUMBER() over (partition by customernumber,salesorg,S.sendingdate,storepointofsales,flagsalesreturns,flagsalesprocess,ean_upc ,s.salesdate
order by S._LDTS) RN
--*******************
from STAG.Seeburger_Sellout S -- 1063245
LEFT join (select  [ArticleNumber_BK], StyleNumber_BK, EANNo from [ref].Bii_ArticleSizes) A 
on S.ean_upc = A.EANNo
left join (select [ArticleNumber_BK], StyleNumber_BK, rbu, RBUCode, ProductDivision, ProductDivisionCode, Brand, BrandCode from PDW_CEU.[ref].[ArticlesSeasonIndependent_DL]
)Art on A.ArticleNumber_BK = Art.ArticleNumber_BK
LEFT JOIN cte_Stag_SalesDate MS on S.sendingdate = MS.sendingdate
LEFT join (select ROW_NUMBER() over(partition by businesspartner order by _LDTS desc)Rno,* from PDW_FRA.stag.BPGeneralData1_DL --where BusinessPartner ='2100001234' 
   ) NC 
on NC.BusinessPartner = S.customernumber and NC.Rno =1 
)A 
--******************* if not required remove
where RN =1
--******************* 
	)
	SELECT 
	*
	,CONVERT(BINARY(16),
				HASHBYTES('MD5',CONCAT(
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),customernumber							)))),'|',	--IntPupMasterId
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),salesorg							)))),'|',	--PDUCode
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),sendingdate						)))),'|',
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),storepointofsales						)))),'|',
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),flagsalesreturns						)))),'|',
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),flagsalesprocess						)))),'|',
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),ean_upc						))))))

		) AS HashValueBK
		,CONVERT(BINARY(16),													
				HASHBYTES('MD5',CONCAT(									
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,t_1							)))),'|',
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,t_2							)))),'|',
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,customernumber							)))),'|',
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,customerglnnumber					)))),'|',		
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,vendorglnnumber						)))),'|',	
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,customerdepartment						)))),'|',	
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,salesorg					)))),'|',		
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,sendingdate						)))),'|',	
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,currencyiso				)))),'|',			
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,storepointofsales					)))),'|',		
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,salesdate					)))),'|',		
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,flagsalesreturns						)))),'|',	
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,flagsalesprocess					)))),'|',		
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,ean_upc					)))),'|',		
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,GrossSalesQty				)))),'|',		
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,GrossSalesRet				)))),'|',			
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,CustRtnQty						)))),'|',				
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,CustRtnRet						)))),'|',	
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,NetSalesRet				)))),'|',		
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,NetSalesQty				)))),'|',			
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,InvQty						)))),'|',	
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,salespriceinclvat						)))),'|',	
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,lineitemamountinclvat						)))),'|',	
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,suggestedretailprice					)))),'|',		
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,quantityofsales				)))),'|',		
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,quantityofstock				)))),'|',		
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,FileName				)))),'|',			
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,_LDTS				)))),'|',			
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,RowNo				)))),'|',			
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,_BatchId				)))),'|',			
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,c.ArticleNumber_BK				)))),'|',			
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,c.StyleNumber_BK				)))),'|',			
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,c.BrandCode				)))),'|',			
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,c.ProductDivisionCode				)))),'|',			
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,c.RBUCode				)))),'|',			
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,c.NatCustomer_BK				)))),'|',			
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200)		,c.PDUCode				))))))			
			) AS HashDiff										
	INTO  #SeeburgerSellthru 
	FROM cte_Stag_SeeburgerST  c 
	 -- 1063245

	


    --update changed              
    UPDATE
		 dest
    SET
		 dest.t_1	=	stg.t_1
		,dest.t_2	=	stg.t_2
		,dest.customernumber	=	stg.customernumber
		,dest.customerglnnumber	=	stg.customerglnnumber
		,dest.vendorglnnumber	=	stg.vendorglnnumber
		,dest.customerdepartment	=	stg.customerdepartment
		,dest.salesorg	=	stg.salesorg
		,dest.sendingdate	=	stg.sendingdate
		,dest.currencyiso	=	stg.currencyiso
		,dest.storepointofsales	=	stg.storepointofsales
		,dest.salesdate	=	stg.salesdate
		,dest.flagsalesreturns	=	stg.flagsalesreturns
		,dest.flagsalesprocess	=	stg.flagsalesprocess
		,dest.ean_upc	=	stg.ean_upc
		
		,dest.GrossSalesQty	=	stg.GrossSalesQty
		,dest.GrossSalesRet	=	stg.GrossSalesRet
		,dest.CustRtnQty	=	stg.CustRtnQty		
		,dest.CustRtnRet	=	stg.CustRtnRet
		,dest.NetSalesRet	=	stg.NetSalesRet
		,dest.NetSalesQty	=	stg.NetSalesQty
		
		,dest.InvQty	=	stg.InvQty
		,dest.salespriceinclvat	=	stg.salespriceinclvat
		,dest.lineitemamountinclvat	=	stg.lineitemamountinclvat
		,dest.suggestedretailprice	=	stg.suggestedretailprice
		,dest.quantityofsales	=	stg.quantityofsales
		,dest.quantityofstock	=	stg.quantityofstock

		,dest.FileName	=	stg.FileName
		,dest.ArticleNumber_BK	=	stg.ArticleNumber_BK
		,dest.StyleNumber_BK	=	stg.StyleNumber_BK
		,dest.BrandCode	=	stg.BrandCode
		,dest.ProductDivisionCode	=	stg.ProductDivisionCode
		,dest.RBUCode	=	stg.RBUCode
		,dest.NatCustomer_BK	=	stg.NatCustomer_BK
		,dest.PDUCode	=	stg.PDUCode
		,dest._LDTS	=	stg._LDTS
		,dest.HashValueBK	=	stg.HashValueBK
		,dest.HashDiff	=	stg.HashDiff

 
    FROM #SeeburgerSellthru AS stg
		JOIN Sales.SeeburgerSellThroughActivities AS dest
			ON stg.HashValueBK = dest.HashValueBK
	WHERE dest.HashDiff <> stg.HashDiff 
		
	SET @RowNo = @@RowCount;


	-- log rows number affected by UPDATE statement
		UPDATE DTlogs SET Updated = @RowNo
			FROM etl.DataTransferLogs DTlogs
			WHERE DataTransferLogId = @DataTransferLogId;

	


	--########################################################################  3. INSERT NEW DATA
	INSERT INTO sales.SeeburgerSellThroughActivities
		(
			 t_1
			,t_2
			,customernumber
			,customerglnnumber
			,vendorglnnumber
			,customerdepartment
			,salesorg
			,sendingdate
			,currencyiso
			,storepointofsales
			,salesdate
			,flagsalesreturns
			,flagsalesprocess
			,ean_upc

			,GrossSalesQty
			,GrossSalesRet
			,CustRtnQty
			,CustRtnRet
			,NetSalesRet
			,NetSalesQty

			,InvQty
			,salespriceinclvat
			,lineitemamountinclvat
			,suggestedretailprice
			,quantityofsales
			,quantityofstock

			,FileName
			,ArticleNumber_BK
			,StyleNumber_BK
			,BrandCode
			,ProductDivisionCode
			,RBUCode
			,NatCustomer_BK
			,PDUCode
			,_LDTS
			,HashValueBK
			,HashDiff
			,CreatedOn
			,ModifiedOn
		)
	SELECT
	 stg.t_1
	,stg.t_2
	,stg.customernumber
	,stg.customerglnnumber
	,stg.vendorglnnumber
	,stg.customerdepartment
	,stg.salesorg
	,stg.sendingdate
	,stg.currencyiso
	,stg.storepointofsales
	,stg.salesdate
	,stg.flagsalesreturns
	,stg.flagsalesprocess
	,stg.ean_upc

	,stg.GrossSalesQty
	,stg.GrossSalesRet	
	,stg.CustRtnQty	
	,stg.CustRtnRet	
	,stg.NetSalesRet
	,stg.NetSalesQty

	,stg.InvQty
	,stg.salespriceinclvat
	,stg.lineitemamountinclvat
	,stg.suggestedretailprice
	,stg.quantityofsales
	,stg.quantityofstock
	,stg.FileName
	,stg.ArticleNumber_BK
	,stg.StyleNumber_BK
	,stg.BrandCode
	,stg.ProductDivisionCode
	,stg.RBUCode
	,stg.NatCustomer_BK
	,stg.PDUCode
	,stg._LDTS
	,stg.HashValueBK
	,stg.HashDiff
	,GETDATE()
	,GETDATE()
	FROM #SeeburgerSellthru AS stg
		LEFT JOIN sales.SeeburgerSellThroughActivities  AS dest
			ON stg.HashValueBK = dest.HashValueBK
		WHERE dest.HashValueBK IS NULL;

	
	SET @RowNo = @@RowCount 

	

	-- log rows number affected by INSERT statement
		UPDATE DTlogs
		SET Inserted = @RowNo
		,Deleted =  (SELECT COUNT(1) FROM #SeeburgerSellthru )
		,ExecEnd = GETDATE()

		FROM etl.DataTransferLogs DTlogs
		WHERE DataTransferLogId = @DataTransferLogId;

END