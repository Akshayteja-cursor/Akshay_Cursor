﻿
CREATE PROC [Sales].[sp_SPS_SellThruActivities] (@LoadFrom DATETIME)
AS
BEGIN

DELETE SAL
FROM sales.SellThroughActivities SAL
	JOIN (select A.* from stag.SPS_Activity A 
	JOIN STAG.SPS_Item I ON A.sps_item_id = I.sps_item_id
	JOIN STAG.SPS_Location L ON A.sps_location_id = L.sps_location_id) A
	on SAL.PeriodEndingDt = A.period_ending_date 
	and sal.CustomerName = SUBSTRING(A.FileName, CHARINDEX('-', A.FileName) + 1, CHARINDEX('-', A.FileName, CHARINDEX('-', A.FileName) + 1) - CHARINDEX('-', A.FileName) - 1)

	INSERT INTO Sales.SellThroughActivities (
		SPSItemId
		,SPSLocationId
		,PeriodEndingDt
		,GrossSalesQty
		,GrossSalesCost
		,GrossSalesRet
		,GrossSalesMgn
		,NetSalesQty
		,NetSalesCost
		,NetSalesRet
		,NetSalesMgn
		,CustRtnQty
		,CustRtnCost
		,CustRtnRet
		,CustRtnMgn
		,InvQty
		,InvCost
		,InvRet
		,OrdQty
		,OrdCost
		,OrdRet
		,ReceiptQty
		,ReceiptCost
		,ReceiptRet
		,ItrQty
		,ItrCost
		,ItrRet
		,VendRtnQty
		,VendRtnCost
		,VendRtnRet
		,InvAdjQty
		,InvAdjCost
		,InvAdjRet
		,PermMarkdown
		,POSMarkdown
		,TotalMarkdown
		,CorpUnitAdjCost
		,CorpUnitAcqCost
		,CorpUnitOwnRetPrc
		,FileName
		,CustomerName
		,_LDTS
		,StyleNum
		,StyleDesc
		,ColorCd
		,ColorName
		,upc
		,sku
		,StoreName
		,country
		)
	SELECT A.sps_item_id
		,A.sps_location_id
		,CAST(A.period_ending_date AS INT)
		,CAST(ROUND(CAST(A.gross_sales_units AS DECIMAL), 0) AS INT)
		,CAST(A.gross_sales_cost AS NUMERIC(10, 4))
		,CAST(A.gross_sales_retail AS NUMERIC(10, 4))
		,CAST(A.gross_sales_margin_value AS NUMERIC(10, 4))
		,CAST(ROUND(CAST(A.net_sales_units AS DECIMAL), 0) AS INT)
		,CAST(A.net_sales_cost AS NUMERIC(10, 4))
		,CAST(A.net_sales_retail AS NUMERIC(10, 4))
		,CAST(A.net_sales_margin_value AS NUMERIC(10, 4))
		,CAST(ROUND(CAST(A.customer_return_units AS DECIMAL), 0) AS INT)
		,CAST(A.customer_return_cost AS NUMERIC(10, 4))
		,CAST(A.customer_return_retail AS NUMERIC(10, 4))
		,CAST(A.customer_return_margin_value AS NUMERIC(10, 4))
		--,CAST(A.inventory_units AS INT)
		,CAST(ROUND(CAST(A.inventory_units AS DECIMAL), 0) AS INT)
		,CAST(A.inventory_cost AS NUMERIC(10, 4))
		,CAST(A.inventory_retail AS NUMERIC(10, 4))
		--,CAST(A.on_order_units AS INT)
		,CAST(ROUND(CAST(A.on_order_units AS DECIMAL), 0) AS INT)
		,CAST(A.on_order_cost AS NUMERIC(10, 4))
		,CAST(A.on_order_retail AS NUMERIC(10, 4))
		--,CAST(A.receipt_units AS INT)
		,CAST(ROUND(CAST(A.receipt_units AS DECIMAL), 0) AS INT)
		,CAST(A.receipt_cost AS NUMERIC(10, 4))
		,CAST(A.receipt_retail AS NUMERIC(10, 4))
		--,CAST(A.in_transit_units AS INT)
		,CAST(ROUND(CAST(A.in_transit_units AS DECIMAL), 0) AS INT)
		,CAST(A.in_transit_cost AS NUMERIC(10, 4))
		,CAST(A.in_transit_retail AS NUMERIC(10, 4))
		--,CAST(A.return_to_vendor_units AS INT)
		,CAST(ROUND(CAST(A.return_to_vendor_units AS DECIMAL), 0) AS INT)
		,CAST(A.return_to_vendor_cost AS NUMERIC(10, 4))
		,CAST(A.return_to_vendor_retail AS NUMERIC(10, 4))
		,CAST(A.inventory_adjustment_units AS NUMERIC(10, 4))
		,CAST(A.inventory_adjustment_cost AS NUMERIC(10, 4))
		,CAST(A.inventory_adjustment_retail AS NUMERIC(10, 4))
		,CAST(A.permanent_markdown_values AS NUMERIC(10, 4))
		,CAST(A.point_of_sale_markdown_values AS NUMERIC(10, 4))
		,CAST(A.total_markdown_values AS NUMERIC(10, 4))

		--new logic for EBPRP-1490
		--,CAST(A.corporate_unit_adjusted_cost AS NUMERIC(10, 4))
		--,CAST(A.corporate_unit_acquired_cost AS NUMERIC(10, 4))
		--,CAST(A.corporate_unit_owned_retail_price AS NUMERIC(10, 4))
		,COALESCE(CAST(A.corporate_unit_adjusted_cost AS NUMERIC(10, 4)),CAST(I.corpUnitADJCost AS NUMERIC(10, 4)))
	    ,COALESCE(CAST(A.corporate_unit_acquired_cost AS NUMERIC(10, 4)),CAST(I.corpUnitACQCost AS NUMERIC(10, 4)))
	    ,COALESCE(CAST(A.corporate_unit_owned_retail_price AS NUMERIC(10, 4)),CAST(I.corpunitownretprc AS NUMERIC(10, 4)))
		,CAST(A.FileName AS NVARCHAR(255))
		,SUBSTRING(A.FileName, CHARINDEX('-', A.FileName) + 1, CHARINDEX('-', A.FileName, CHARINDEX('-', A.FileName) + 1) - CHARINDEX('-', A.FileName) - 1)
		,A._LDTS
		,replace(I.style_number, '-', ' ')
		,I.style_description
		,I.color_code
		,I.color_name
		,I.upc
		,I.sku
		,L.store_name
		,L.country
	FROM stag.SPS_Activity A
	JOIN STAG.SPS_Item I ON A.sps_item_id = I.sps_item_id
	JOIN STAG.SPS_Location L ON A.sps_location_id = L.sps_location_id
	WHERE A._LDTS >=@LoadFrom
END


--select * from stag.SPS_Location

--select count(1) from STAG.SPS_Activity
--select count(1) from STAG.SPS_Location
--select count(1) from STAG.SPS_Item
--select count(1)
--from stag.SPS_Activity A
--JOIN STAG.SPS_Item I on A.sps_item_id = I.sps_item_id
--JOIN STAG.SPS_Location L on A.sps_location_id = L.sps_location_id

--select distinct style_number, style_description, color_code, color_name, upc, sku from STAG.SPS_Item
--select distinct store_name, country from STAG.SPS_Location


--select * from sales.SellThroughActivities