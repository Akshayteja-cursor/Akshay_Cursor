﻿create view sales.vRetailSales
as
SELECT
[HashvalueBK], [HashDiff], trans.[ModifiedOn], trans.[CreatedOn], [NatInvoicePostingSalesDate], [TimeOfDayCode], trans.[GSMStoreCode], [WebTerminalGSMStoreCode], trans.[PDUCode], [CurrencyCode], [PromotionName], [EANNo], [ITEM_POS], [StyleNumber_BK], [ArticleNumber_BK], [ArticleSize_BK], [IntBusinessSegmentCode], [ProductDivisionCode], [RBUCode], 0[RepIntAgeGrpCode], [RepIntGenderCode], [IntBrandCode], [ProdCreationModelCode], [GrossValueLC], [CRPValueLC], [NetValueLC], [LineDiscount], [Qty], [NewDiscountAmount], [NewPrice], [PrevPrice], [TenderAmount], [DiscountReason], [TenderName], [Notes], [CashierName], [Employee1Name], [OrderStatus], [Comment1], [Comment2], [EmployeeCardNumber], [TransactionNumber], [Workstation_No], [DOC_SID], [DOC_REF_NO], [ReceiptType], [TrackingNumber], [Note1], [ReturnReason], [TransactionType], [DiscountSource], [GiftCardType], [Granularity], [ReFiveFlag], [TotalLandedCost], [LandedCostCurrencyCode], [ID]
FROM sales.RetailSales trans with(nolock)
inner join [Ref].[GSMStores_DL] gsm ON trans.[GSMStoreCode] = gsm.[GSMStoreCode] AND Active = 'True'
WHERE 1=1
AND trans.Granularity = 1