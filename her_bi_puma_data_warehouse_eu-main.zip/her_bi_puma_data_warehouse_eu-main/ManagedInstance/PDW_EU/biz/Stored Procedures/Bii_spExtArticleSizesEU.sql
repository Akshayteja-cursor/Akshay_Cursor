﻿
 --=============================================
 --Author:		<Author,,Name>
 --Create date: <2023.09.27>
 --Description:	<provisioning procedure for external table ArticleSizes_DL>
 --=============================================
CREATE PROCEDURE [biz].[Bii_spExtArticleSizesEU] @ldts DATETIME2(7) , @TypeOfProc TINYINT  = 0
AS
BEGIN
	--SET NOCOUNT ON;
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
	SET ANSI_WARNINGS ON;
	SET XACT_ABORT ON;
	
	DROP TABLE IF EXISTS #ArticleSizes;

	DECLARE @DelivTableName		VARCHAR(255)	= 'Bii_ArticleSizes';
	DECLARE @TargetSchemaName	VARCHAR(125)	= 'ref';
	DECLARE @TransferGroupName	VARCHAR(225)	= 'ArticleSizes_DL';
	DECLARE @TransferName		VARCHAR(225)	= 'Bii_spExtArticleSizes';
	DECLARE @LoadDate			DATETIME2		= GETDATE();
	DECLARE @DataTransferLogId	INT				= NULL;
	DECLARE @RowNo				BIGINT			= 0;
	DECLARE @MaxLDTS			DATETIME2(7)	= '1900.01.01';
	
	SET @ldts = CONVERT(DATETIME2(7), CONVERT(CHAR(19),@ldts , 126)); 


	SELECT @MaxLDTS = COALESCE(MAX(SourceLastLoadDate),'1900.01.01') FROM etl.DataTransferLogs WHERE ExecEnd IS NOT NULL AND TransferName = @TransferName  ---'Bii_spExtArticleSizes'--
					   
 -- avoid repeatable processing the same LDTS
	IF  @TypeOfProc = 0 AND @ldts <= @MaxLDTS   
	RETURN;
	IF @TypeOfProc = 1 SET @MaxLDTS = @ldts;

--Log Start Data load
	INSERT INTO etl.DataTransferLogs
		  (TransferName
		  ,TransferGroupName
		  ,TargetTableName
		  ,TargetSchemaName
		  ,ExecStart
		  ,BatchLdts
		  ,TypeOfProc)
		  SELECT @TransferName
				,@TransferGroupName
				,@DelivTableName
				,@TargetSchemaName
				,@LoadDate
				,@ldts
				,@TypeOfProc
	SET @DataTransferLogId = @@Identity 

	--################################################  0. build staging dataset 

	SELECT 	CONVERT(BINARY(16),  
			HASHBYTES('MD5',CONCAT(
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), ars.ArticleNumber_BK  	)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),CONCAT(' ',ars.SizeNumber)))))))
			) AS HashValueBK
			,ars.ArticleNumber_BK
			--,ars.hash
			,ars.StyleNumber_BK	--BK part
			,ars.ColorNumber	--BK part
			,ars.SizeNumber		--BK part
			,NULLIF(ars.EANNo,'')	AS EANNo
			,NULLIF(ars.UPCNo,'')	AS UPCNo
			,ars.ModifiedOn			AS SourceModifiedOn
			,ars.CreatedOn			AS SourceCreatedOn
	INTO #ArticleSizes
	FROM ref.ArticleSizes_DL ars
	WHERE CAST(ars.ModifiedOn AS DATETIME2(7)) > @MaxLDTS
	UNION
	SELECT CONVERT(BINARY(16),  
			HASHBYTES('MD5',CONCAT(
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200), ars.ArticleNumber_BK  	)))),'_',
				UPPER(LTRIM(RTRIM(CONVERT(NVARCHAR(200),CONCAT(' ',ars.SizeNumber)))))))
			) AS HashValueBK
			,ars.ArticleNumber_BK
			--,ars.hash
			,ars.StyleNumber_BK	--BK part
			,ars.ColorNumber	--BK part
			,ars.SizeNumber		--BK part
			,NULLIF(ars.EANNo,'')	AS EANNo
			,NULLIF(ars.UPCNo,'')	AS UPCNo
			,ars.ModifiedOn			AS SourceModifiedOn
			,ars.CreatedOn			AS SourceCreatedOn FROM ref.ArticleSizes_DL ars WHERE ArticleNumber_BK = '000000 00'
			

	--#########################################  1. UPDATE non - primary fields 
	UPDATE dest SET
		dest.ModifiedOn			= @LoadDate
		,dest.SourceModifiedOn	= stg.SourceModifiedOn
		,dest.LDTS				= @ldts
		,dest.EANNo				= stg.EANNo
		,dest.UPCNo				= stg.UPCNo
	FROM #ArticleSizes AS stg JOIN ref.Bii_ArticleSizes AS dest ON stg.HashValueBK = dest.HashValueBK
	WHERE dest.EANNo <> stg.EANNo ;
	
	SET @RowNo = @@RowCount;


		-- log rows number affected by UPDATE statement
		UPDATE DTlogs SET Updated = @RowNo
			FROM etl.DataTransferLogs DTlogs
			WHERE DataTransferLogId = @DataTransferLogId;


	--#########################################		2. INSERT NEW DATA
	INSERT INTO ref.Bii_ArticleSizes
			   (HashValueBK
				,CreatedOn
				,ModifiedOn
				,SourceCreatedOn
				,SourceModifiedOn
				,LDTS
				,ArticleNumber_BK
				,StyleNumber_Bk	--BK part
				,ColorNumber	--BK part
				,SizeNumber		--BK part
				,EANNo
				,UPCNo)
		SELECT stg.HashValueBK
				,@LoadDate   --ModifiedOn
				,@LoadDate   --CreatedOn
				,stg.SourceCreatedOn
				,stg.SourceModifiedOn
				,@ldts
				,stg.ArticleNumber_BK
				,CAST(stg.StyleNumber_BK AS INT)	
				,CAST(stg.ColorNumber AS SMALLINT)
				,CAST(stg.SizeNumber AS INT)	
				,stg.EANNo
				,stg.UPCNo
		FROM #ArticleSizes AS stg LEFT JOIN ref.Bii_ArticleSizes AS dest ON stg.HashValueBK = dest.HashValueBK
			WHERE dest.HashValueBK IS NULL;


	SET @RowNo = @@RowCount 

	-- log rows number affected by INSERT statement
		UPDATE DTlogs SET Inserted			= @RowNo,
						  Deleted			= 0,
						  SourceLastLoadDate= (SELECT COALESCE(MAX(SourceModifiedOn),@ldts) from #ArticleSizes),
						  ExecEnd			= GETDATE()
		FROM etl.DataTransferLogs DTlogs
		WHERE DataTransferLogId = @DataTransferLogId;


END

--truncate table ref.Bii_ArticleSizes
--SELECT * FROM etl.DataTransferLogs order by 1 desc
-- exec [biz].[Bii_spExtArticleSizes] '1900.01.01',1
--select * from ref.Bii_ArticleSizes