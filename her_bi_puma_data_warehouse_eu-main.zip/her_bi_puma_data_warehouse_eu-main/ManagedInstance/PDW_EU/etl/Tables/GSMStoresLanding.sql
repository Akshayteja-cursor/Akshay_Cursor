﻿CREATE TABLE [etl].[GSMStoresLanding] (
    [GSMStoreCode] NVARCHAR (300) NULL,
    [PDUCode]      NVARCHAR (10)  NULL
);

