﻿CREATE TABLE [etl].[ArticlesLanding] (
    [EANNo]                  NVARCHAR (13) NOT NULL,
    [StyleNumber_BK]         INT           NULL,
    [ArticleNumber_BK]       NVARCHAR (13) NULL,
    [ArticleSize_BK]         NVARCHAR (20) NULL,
    [ProdCreationModelCode]  INT           NULL,
    [IntBusinessSegmentCode] INT           NULL,
    [IntBrandCode]           NVARCHAR (6)  NULL,
    [ProductDivisionCode]    INT           NULL,
    [RBUCode]                INT           NULL,
    [RepIntGenderCode]       INT           NULL,
    [RepIntAgeGrpCode]       INT           NULL,
    [HashDiff]               BINARY (16)   NOT NULL
);

