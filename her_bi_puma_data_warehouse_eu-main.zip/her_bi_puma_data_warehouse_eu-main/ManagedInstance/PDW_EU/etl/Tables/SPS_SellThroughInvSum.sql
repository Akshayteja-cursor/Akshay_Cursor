﻿CREATE TABLE [etl].[SPS_SellThroughInvSum] (
    [ArticleNumber_BK] NVARCHAR (40) NOT NULL,
    [SPSLocationId]    VARCHAR (50)  NULL,
    [midweek]          DATETIME      NULL,
    [SumInv]           INT           NULL
);

