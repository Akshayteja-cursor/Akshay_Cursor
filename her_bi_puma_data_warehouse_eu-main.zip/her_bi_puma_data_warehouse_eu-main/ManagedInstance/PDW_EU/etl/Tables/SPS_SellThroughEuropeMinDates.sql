﻿CREATE TABLE [etl].[SPS_SellThroughEuropeMinDates] (
    [Customername]  NVARCHAR (255) NULL,
    [ArticleHashBK] NVARCHAR (255) NULL,
    [MinDate]       DATE           NULL,
    [ArticleNumber] NVARCHAR (255) NULL
);

