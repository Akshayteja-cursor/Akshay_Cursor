﻿CREATE TABLE [etl].[DataTransferLogs] (
    [DataTransferLogId]       INT            IDENTITY (1, 1) NOT NULL,
    [TransferName]            NVARCHAR (100) NULL,
    [TransferGroupName]       NVARCHAR (100) NULL,
    [TargetTableName]         NVARCHAR (100) NULL,
    [TargetSchemaName]        NVARCHAR (100) NULL,
    [ExecStart]               DATETIME2 (7)  NULL,
    [ExecEnd]                 DATETIME2 (7)  NULL,
    [SourceLastLoadDate]      DATETIME2 (7)  NULL,
    [DestinationLastLoadDate] DATETIME2 (7)  NULL,
    [BatchLdts]               DATETIME2 (7)  NULL,
    [Inserted]                BIGINT         NULL,
    [Updated]                 BIGINT         NULL,
    [Deleted]                 BIGINT         NULL,
    [TypeOfProc]              TINYINT        NULL
);

