﻿CREATE TABLE [etl].[PriceLanding] (
    [INVN_SBS_ITEM_SID] NVARCHAR (300) NULL,
    [PRICE]             FLOAT (53)     NULL
);

