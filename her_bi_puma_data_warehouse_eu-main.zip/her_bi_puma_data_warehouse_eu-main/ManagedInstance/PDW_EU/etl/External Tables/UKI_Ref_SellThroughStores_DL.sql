﻿CREATE EXTERNAL TABLE [etl].[UKI_Ref_SellThroughStores_DL] (
    [ID] NVARCHAR (2000) NULL,
    [MUID] NVARCHAR (2000) NULL,
    [VersionName] NVARCHAR (2000) NULL,
    [VersionNumber] NVARCHAR (2000) NULL,
    [Version_ID] NVARCHAR (2000) NULL,
    [VersionFlag] NVARCHAR (2000) NULL,
    [Name] NVARCHAR (2000) NULL,
    [Code] NVARCHAR (2000) NULL,
    [ChangeTrackingMask] NVARCHAR (2000) NULL,
    [Region] NVARCHAR (2000) NULL,
    [Country] NVARCHAR (2000) NULL,
    [Cluster] NVARCHAR (2000) NULL,
    [Fascia] NVARCHAR (2000) NULL,
    [Grade] NVARCHAR (2000) NULL,
    [Latitude] NVARCHAR (2000) NULL,
    [Longtitude] NVARCHAR (2000) NULL,
    [DoorCount] NVARCHAR (2000) NULL,
    [EnterDateTime] NVARCHAR (2000) NULL,
    [EnterUserName] NVARCHAR (2000) NULL,
    [EnterVersionNumber] NVARCHAR (2000) NULL,
    [LastChgDateTime] NVARCHAR (2000) NULL,
    [LastChgUserName] NVARCHAR (2000) NULL,
    [LastChgVersionNumber] NVARCHAR (2000) NULL,
    [ValidationStatus] NVARCHAR (2000) NULL
)
    WITH (
    DATA_SOURCE = [ds_bieurope_encur_curated],
    LOCATION = N'/PDW_EU/MDM_vUKI_Ref_SellThroughStores/*.parquet',
    FILE_FORMAT = [ff_parquet],
    REJECT_TYPE = VALUE,
    REJECT_VALUE = 0
    );

