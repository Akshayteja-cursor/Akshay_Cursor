﻿CREATE EXTERNAL TABLE [etl].[SellThroughEuropeMinDates] (
    [CustomerName] NVARCHAR (255) NULL,
    [ArticleHashBK] NVARCHAR (255) NULL,
    [MinDate] NVARCHAR (255) NULL,
    [ArticleNumber] NVARCHAR (255) NULL
)
    WITH (
    DATA_SOURCE = [ds_bieurope_encur_curated],
    LOCATION = N'/PDW_EU/SellThroughEuropeMinDates/*',
    FILE_FORMAT = [ff_parquet],
    REJECT_TYPE = VALUE,
    REJECT_VALUE = 0
    );

