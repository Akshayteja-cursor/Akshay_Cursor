﻿CREATE TABLE [Stag].[Prism_DOCUMENT_ITEM] (
    [SID]               NVARCHAR (300)  NULL,
    [DOC_SID]           NVARCHAR (300)  NULL,
    [SCAN_UPC]          NVARCHAR (300)  NULL,
    [DISCOUNT_REASON]   NVARCHAR (500)  NULL,
    [NOTE1]             NVARCHAR (1000) NULL,
    [ITEM_POS]          NVARCHAR (300)  NULL,
    [RETURN_REASON]     NVARCHAR (500)  NULL,
    [ITEM_TYPE]         NVARCHAR (300)  NULL,
    [ORIG_PRICE]        NVARCHAR (300)  NULL,
    [ORIG_TAX_AMT]      NVARCHAR (300)  NULL,
    [QTY]               NVARCHAR (300)  NULL,
    [PRICE]             NVARCHAR (300)  NULL,
    [TAX_AMT]           NVARCHAR (300)  NULL,
    [INVN_SBS_ITEM_SID] NVARCHAR (300)  NULL,
    [TAX_PERC]          NVARCHAR (300)  NULL
);

