﻿CREATE TABLE [Stag].[Prism_PRICE_LEVEL] (
    [SID]                   NVARCHAR (100) NULL,
    [CREATED_BY]            NVARCHAR (100) NULL,
    [CREATED_DATETIME]      NVARCHAR (100) NULL,
    [MODIFIED_BY]           NVARCHAR (100) NULL,
    [MODIFIED_DATETIME]     NVARCHAR (100) NULL,
    [CONTROLLER_SID]        NVARCHAR (100) NULL,
    [ORIGIN_APPLICATION]    NVARCHAR (100) NULL,
    [POST_DATE]             NVARCHAR (100) NULL,
    [ROW_VERSION]           NVARCHAR (100) NULL,
    [TENANT_SID]            NVARCHAR (100) NULL,
    [SBS_SID]               NVARCHAR (100) NULL,
    [PRICE_LVL]             NVARCHAR (100) NULL,
    [PRICE_LVL_NAME]        NVARCHAR (100) NULL,
    [SECURED]               NVARCHAR (100) NULL,
    [DISC_PERC]             NVARCHAR (100) NULL,
    [USE_DISC_PERC]         NVARCHAR (100) NULL,
    [ACTIVE]                NVARCHAR (100) NULL,
    [PRICE_LVL_DESCRIPTION] NVARCHAR (500) NULL,
    [RowNo]                 INT            NULL,
    [_BatchId]              INT            NULL
);

