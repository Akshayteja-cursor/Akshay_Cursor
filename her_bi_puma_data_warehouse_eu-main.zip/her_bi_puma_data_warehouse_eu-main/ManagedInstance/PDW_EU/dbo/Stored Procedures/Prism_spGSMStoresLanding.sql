﻿
CREATE   PROCEDURE [dbo].[Prism_spGSMStoresLanding]
AS
BEGIN

----------------------------------------------------------------------------------------------------

MERGE INTO ETL.GSMStoresLanding AS tgt
  USING (
      SELECT
          CAST(GSMStoreCode AS NVARCHAR(20)) AS GSMStoreCode
        , CAST(PDUCode AS NVARCHAR(10)) AS PDUCode
      FROM (
          SELECT
              GSMStoreCode
            , PDUCode
            , ROW_NUMBER() OVER(
                PARTITION BY GSMStoreCode
                ORDER BY
                    CASE
                      WHEN StoreStatus = 'Open' THEN 1
                      WHEN StoreStatus = 'Closed' THEN 2
                      ELSE 3
                    END
                  , CAST(OpeningDate AS DATE) DESC
          ) AS rn
          FROM ref.GSMStores_DL (NOLOCK)
          WHERE Active = 'True'
      ) AS gsm
      WHERE gsm.rn = 1
  ) AS src
    ON tgt.GSMStoreCode = src.GSMStoreCode

WHEN MATCHED THEN
  UPDATE SET
    tgt.PDUCode = src.PDUCode

WHEN NOT MATCHED THEN
  INSERT (
    GSMStoreCode,
    PDUCode
  )
  VALUES (
    src.GSMStoreCode,
    src.PDUCode
  );

----------------------------------------------------------------------------------------------------

END