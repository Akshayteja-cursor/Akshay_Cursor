﻿
CREATE   PROCEDURE [dbo].[Prism_spSalesLanding]
AS
BEGIN

----------------------------------------------------------------------------------------------------

TRUNCATE TABLE ETL.SalesLanding;

----------------------------------------------------------------------------------------------------

INSERT INTO ETL.SalesLanding (
  HashvalueBK, HashDiff, ModifiedOn, CreatedOn, NatInvoicePostingSalesDate, TimeOfDayCode,
  GSMStoreCode, WebTerminalGSMStoreCode, PDUCode, CurrencyCode, PromotionName, EANNo, ITEM_POS,
  StyleNumber_BK, ArticleNumber_BK, ArticleSize_BK, IntBusinessSegmentCode, ProductDivisionCode,
  RBUCode, RepIntAgeGrpCode, RepIntGenderCode, IntBrandCode, ProdCreationModelCode, GrossValueLC,
  CRPValueLC, NetValueLC, LineDiscount, Qty, NewDiscountAmount, NewPrice, PrevPrice, TenderAmount,
  DiscountReason, TenderName, Notes, CashierName, Employee1Name, OrderStatus, Comment1, Comment2,
  EmployeeCardNumber, TransactionNumber, Workstation_No, DOC_SID, DOC_REF_NO, ReceiptType,
  TrackingNumber, Note1, ReturnReason, TransactionType, DiscountSource, GiftCardType, Granularity
)
SELECT
    CONVERT(BINARY(16), HASHBYTES('MD5',
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(doc.CREATED_DATETIME AS DATE)), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(CAST(doc.CREATED_DATETIME AS TIME) AS VARCHAR(5))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(sto.GLOBAL_STORE_CODE AS NVARCHAR(20))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(right(CONCAT('0000000000000',cast(CAST(dit.SCAN_UPC AS decimal(14,0)) as bigint)), 13 )as nvarchar(13))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(CAST(dit.ITEM_POS AS FLOAT) AS INT)), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(doc.TENDER_NAME AS NVARCHAR(30))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(CAST(doc.DOC_NO AS FLOAT) AS INT)), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), dit.SID), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), 1), ''))))) AS HashvalueBK
  , CONVERT(BINARY(16), HASHBYTES('MD5',
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(doc.CREATED_DATETIME AS DATE)), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(CAST(doc.CREATED_DATETIME AS TIME) AS VARCHAR(5))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(sto.GLOBAL_STORE_CODE AS NVARCHAR(20))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(sto.GLOBAL_STORE_CODE AS NVARCHAR(20))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), gss.PDUCode), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(cur.ALPHABETIC_CODE AS NVARCHAR(3))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(right(CONCAT('0000000000000',cast(CAST(dit.SCAN_UPC AS decimal(14,0)) as bigint)), 13 )as nvarchar(13))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(CAST(dit.ITEM_POS AS FLOAT) AS INT)), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), art.StyleNumber_BK), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), art.ArticleNumber_BK), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), art.ArticleSize_BK), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), art.IntBusinessSegmentCode), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), art.ProductDivisionCode), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), art.RBUCode), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), art.RepIntAgeGrpCode), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), art.RepIntGenderCode), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), art.IntBrandCode), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), art.ProdCreationModelCode), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(ROUND(
        CASE
          WHEN CAST(CAST(dit.ITEM_TYPE AS FLOAT) AS INT) = 2
          THEN ((CAST(CAST(ISNULL(dit.QTY, 0) AS FLOAT) AS INT) * prl.PRICE * 100) / (100 + CAST(ISNULL(dit.TAX_PERC, 0) AS FLOAT))) * (-1)
          ELSE ((CAST(CAST(ISNULL(dit.QTY, 0) AS FLOAT) AS INT) * prl.PRICE * 100) / (100 + CAST(ISNULL(dit.TAX_PERC, 0) AS FLOAT)))
        END, 2) AS DECIMAL(19,2))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(ROUND(
        CASE
          WHEN CAST(CAST(dit.ITEM_TYPE AS FLOAT) AS INT) = 2
          THEN (CAST(ISNULL(dit.ORIG_PRICE, 0) AS FLOAT) - CAST(ISNULL(dit.ORIG_TAX_AMT, 0) AS FLOAT)) * CAST(CAST(ISNULL(dit.QTY, 0) AS FLOAT) AS INT) * (-1)
          ELSE (CAST(ISNULL(dit.ORIG_PRICE, 0) AS FLOAT) - CAST(ISNULL(dit.ORIG_TAX_AMT, 0) AS FLOAT)) * CAST(CAST(ISNULL(dit.QTY, 0) AS FLOAT) AS INT)
        END, 2) AS DECIMAL(19,2))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(ROUND(
        CASE
          WHEN CAST(CAST(dit.ITEM_TYPE AS FLOAT) AS INT) = 2
          THEN (CAST(ISNULL(dit.PRICE, 0) AS FLOAT) - CAST(ISNULL(dit.TAX_AMT, 0) AS FLOAT)) * CAST(CAST(ISNULL(dit.QTY, 0) AS FLOAT) AS INT) * (-1)
          ELSE (CAST(ISNULL(dit.PRICE, 0) AS FLOAT) - CAST(ISNULL(dit.TAX_AMT, 0) AS FLOAT)) * CAST(CAST(ISNULL(dit.QTY, 0) AS FLOAT) AS INT)
        END, 2) AS DECIMAL(19,2))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(ROUND(
        CASE
          WHEN CAST(CAST(dit.ITEM_TYPE AS FLOAT) AS INT) = 2
          THEN (CAST(ISNULL(dit.ORIG_PRICE, 0) AS FLOAT) - CAST(ISNULL(dit.ORIG_TAX_AMT, 0) AS FLOAT)) * CAST(CAST(ISNULL(dit.QTY, 0) AS FLOAT) AS INT) * (-1) - (CAST(ISNULL(dit.PRICE, 0) AS FLOAT) - CAST(ISNULL(dit.TAX_AMT, 0) AS FLOAT)) * CAST(CAST(ISNULL(dit.QTY, 0) AS FLOAT) AS INT) * (-1)
          ELSE (CAST(ISNULL(dit.ORIG_PRICE, 0) AS FLOAT) - CAST(ISNULL(dit.ORIG_TAX_AMT, 0) AS FLOAT)) * CAST(CAST(ISNULL(dit.QTY, 0) AS FLOAT) AS INT) - (CAST(ISNULL(dit.PRICE, 0) AS FLOAT) - CAST(ISNULL(dit.TAX_AMT, 0) AS FLOAT)) * CAST(CAST(ISNULL(dit.QTY, 0) AS FLOAT) AS INT)
        END, 2) AS DECIMAL(19,2))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(
        CASE
          WHEN CAST(CAST(dit.ITEM_TYPE AS FLOAT) AS INT) = 2
          THEN CAST(ISNULL(dit.QTY, 0) AS FLOAT) * (-1)
          ELSE CAST(ISNULL(dit.QTY, 0) AS FLOAT)
        END AS INT)), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(dit.DISCOUNT_REASON AS NVARCHAR(300))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(doc.TENDER_NAME AS NVARCHAR(30))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(doc.NOTES AS nvarchar(300))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(doc.CASHIER_FULL_NAME AS NVARCHAR(300))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(doc.EMPLOYEE1_FULL_NAME AS NVARCHAR(300))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(CAST(doc.STATUS AS FLOAT) AS INT)), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(doc.COMMENT1 AS NVARCHAR(300))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(doc.COMMENT2 AS NVARCHAR(300))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(doc.UDF5_STRING AS NVARCHAR(100))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(CAST(doc.DOC_NO AS FLOAT) AS INT)), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(CAST(doc.WORKSTATION_NO AS FLOAT) AS INT)), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(
        CASE
          WHEN CHARINDEX('.', doc.SID) = 0
          THEN doc.SID
          ELSE LEFT(doc.SID, CHARINDEX('.', doc.SID) - 1)
        END AS NVARCHAR(60))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(CAST(doc.DOC_REF_NO AS FLOAT) AS NVARCHAR(60))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(CAST(doc.RECEIPT_TYPE AS FLOAT) AS INT)), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(doc.TRACKING_NO AS NVARCHAR(60))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(dit.NOTE1 AS NVARCHAR(300))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(dit.RETURN_REASON AS NVARCHAR(300))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(CAST(dit.ITEM_TYPE AS FLOAT) AS INT)), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), 1), ''))))) as HashDiff
  , GETDATE() AS ModifiedOn
  , GETDATE() AS CreatedOn
  , CAST(doc.CREATED_DATETIME AS DATE) AS NatInvoicePostingSalesDate
  , CAST(CAST(doc.CREATED_DATETIME AS TIME) AS VARCHAR(5)) AS TimeOfDayCode
  , CAST(sto.GLOBAL_STORE_CODE AS NVARCHAR(20)) AS GSMStoreCode
  , CAST(sto.GLOBAL_STORE_CODE AS NVARCHAR(20)) AS WebTerminalGSMStoreCode
  , gss.PDUCode
  , CAST(cur.ALPHABETIC_CODE AS NVARCHAR(3)) AS CurrencyCode
  , CAST(NULL AS NVARCHAR(300)) AS PromotionName
  , TRY_CAST(right(CONCAT('0000000000000',cast(CAST(dit.SCAN_UPC AS decimal(14,0)) as bigint)), 13 )as nvarchar(13)) AS EANNo
  , CAST(CAST(dit.ITEM_POS AS FLOAT) AS INT) AS ITEM_POS
  , art.StyleNumber_BK
  , art.ArticleNumber_BK
  , art.ArticleSize_BK
  , art.IntBusinessSegmentCode
  , art.ProductDivisionCode
  , art.RBUCode
  , art.RepIntAgeGrpCode
  , art.RepIntGenderCode
  , art.IntBrandCode
  , art.ProdCreationModelCode
  , CAST(ROUND(
        CASE
          WHEN CAST(CAST(dit.ITEM_TYPE AS FLOAT) AS INT) = 2
          THEN ((CAST(CAST(ISNULL(dit.QTY, 0) AS FLOAT) AS INT) * prl.PRICE * 100) / (100 + CAST(ISNULL(dit.TAX_PERC, 0) AS FLOAT))) * (-1)
          ELSE ((CAST(CAST(ISNULL(dit.QTY, 0) AS FLOAT) AS INT) * prl.PRICE * 100) / (100 + CAST(ISNULL(dit.TAX_PERC, 0) AS FLOAT)))
        END, 2) AS DECIMAL(19,2)) AS GrossValueLC
  , CAST(ROUND(
        CASE
          WHEN CAST(CAST(dit.ITEM_TYPE AS FLOAT) AS INT) = 2
          THEN (CAST(ISNULL(dit.ORIG_PRICE, 0) AS FLOAT) - CAST(ISNULL(dit.ORIG_TAX_AMT, 0) AS FLOAT)) * CAST(CAST(ISNULL(dit.QTY, 0) AS FLOAT) AS INT) * (-1)
          ELSE (CAST(ISNULL(dit.ORIG_PRICE, 0) AS FLOAT) - CAST(ISNULL(dit.ORIG_TAX_AMT, 0) AS FLOAT)) * CAST(CAST(ISNULL(dit.QTY, 0) AS FLOAT) AS INT)
        END, 2) AS DECIMAL(19,2)) AS CRPValueLC
  , CAST(ROUND(
        CASE
          WHEN CAST(CAST(dit.ITEM_TYPE AS FLOAT) AS INT) = 2
          THEN (CAST(ISNULL(dit.PRICE, 0) AS FLOAT) - CAST(ISNULL(dit.TAX_AMT, 0) AS FLOAT)) * CAST(CAST(ISNULL(dit.QTY, 0) AS FLOAT) AS INT) * (-1)
          ELSE (CAST(ISNULL(dit.PRICE, 0) AS FLOAT) - CAST(ISNULL(dit.TAX_AMT, 0) AS FLOAT)) * CAST(CAST(ISNULL(dit.QTY, 0) AS FLOAT) AS INT)
        END, 2) AS DECIMAL(19,2)) AS NetValueLC
  , CAST(ROUND(
        CASE
          WHEN CAST(CAST(dit.ITEM_TYPE AS FLOAT) AS INT) = 2
          THEN (CAST(ISNULL(dit.ORIG_PRICE, 0) AS FLOAT) - CAST(ISNULL(dit.ORIG_TAX_AMT, 0) AS FLOAT)) * CAST(CAST(ISNULL(dit.QTY, 0) AS FLOAT) AS INT) * (-1) - (CAST(ISNULL(dit.PRICE, 0) AS FLOAT) - CAST(ISNULL(dit.TAX_AMT, 0) AS FLOAT)) * CAST(CAST(ISNULL(dit.QTY, 0) AS FLOAT) AS INT) * (-1)
          ELSE (CAST(ISNULL(dit.ORIG_PRICE, 0) AS FLOAT) - CAST(ISNULL(dit.ORIG_TAX_AMT, 0) AS FLOAT)) * CAST(CAST(ISNULL(dit.QTY, 0) AS FLOAT) AS INT) - (CAST(ISNULL(dit.PRICE, 0) AS FLOAT) - CAST(ISNULL(dit.TAX_AMT, 0) AS FLOAT)) * CAST(CAST(ISNULL(dit.QTY, 0) AS FLOAT) AS INT)
        END, 2) AS DECIMAL(19,2)) AS LineDiscount
  , CAST(
        CASE
          WHEN CAST(CAST(dit.ITEM_TYPE AS FLOAT) AS INT) = 2
          THEN CAST(ISNULL(dit.QTY, 0) AS FLOAT) * (-1)
          ELSE CAST(ISNULL(dit.QTY, 0) AS FLOAT)
        END AS INT) AS Qty
  , CAST(NULL AS DECIMAL(19,2)) AS NewDiscountAmount
  , CAST(NULL AS DECIMAL(19,2)) AS NewPrice
  , CAST(NULL AS DECIMAL(19,2)) AS PrevPrice
  , CAST(NULL AS DECIMAL(19,2)) AS TenderAmount
  , CAST(dit.DISCOUNT_REASON AS NVARCHAR(300)) AS DiscountReason
  , CAST(doc.TENDER_NAME AS NVARCHAR(30)) AS TenderName
  , CAST(doc.NOTES AS nvarchar(300)) AS Notes
  , CAST(doc.CASHIER_FULL_NAME AS NVARCHAR(300)) AS CashierName
  , CAST(doc.EMPLOYEE1_FULL_NAME AS NVARCHAR(300)) AS Employee1Name
  , CAST(CAST(doc.STATUS AS FLOAT) AS INT) AS OrderStatus
  , CAST(doc.COMMENT1 AS NVARCHAR(300)) AS Comment1
  , CAST(doc.COMMENT2 AS NVARCHAR(300)) AS Comment2
  , CAST(doc.UDF5_STRING AS NVARCHAR(100)) AS EmployeeCardNumber
  , CAST(CAST(doc.DOC_NO AS FLOAT) AS INT) AS TransactionNumber
  , CAST(CAST(doc.WORKSTATION_NO AS FLOAT) AS INT) AS Workstation_No
  , CAST(
        CASE
          WHEN CHARINDEX('.', doc.SID) = 0
          THEN doc.SID
          ELSE LEFT(doc.SID, CHARINDEX('.', doc.SID) - 1)
        END AS NVARCHAR(60)) AS DOC_SID
  , CAST(CAST(doc.DOC_REF_NO AS FLOAT) AS NVARCHAR(60)) AS DOC_REF_NO
  , CAST(CAST(doc.RECEIPT_TYPE AS FLOAT) AS INT) AS ReceiptType
  , CAST(doc.TRACKING_NO AS NVARCHAR(60)) AS TrackingNumber
  , CAST(dit.NOTE1 AS NVARCHAR(300)) AS Note1
  , CAST(dit.RETURN_REASON AS NVARCHAR(300)) AS ReturnReason
  , CAST(CAST(dit.ITEM_TYPE AS FLOAT) AS INT) AS TransactionType
  , CAST(NULL AS NVARCHAR(300)) AS DiscountSource
  , CAST(NULL AS NVARCHAR(300)) AS GiftCardType
  , 1 AS Granularity
FROM stag.Prism_DOCUMENT_ITEM (NOLOCK) AS dit
JOIN stag.Prism_DOCUMENT (NOLOCK) AS doc
  ON dit.DOC_SID = doc.SID
LEFT JOIN ETL.PriceLanding (NOLOCK) AS prl
  ON dit.INVN_SBS_ITEM_SID = prl.INVN_SBS_ITEM_SID
LEFT JOIN ETL.ArticlesLanding (NOLOCK) AS art
  ON TRY_CAST(right(CONCAT('0000000000000',cast(CAST(dit.SCAN_UPC AS decimal(14,0)) as bigint)), 13 )as nvarchar(13)) = art.EANNo
LEFT JOIN (
    SELECT DISTINCT
        DOC_SID
      , CURRENCY_SID
    FROM stag.Prism_TENDER (NOLOCK)
) AS ten
  ON dit.DOC_SID = ten.DOC_SID
LEFT JOIN stag.Prism_CURRENCY (NOLOCK) AS cur
  ON ten.CURRENCY_SID = cur.SID
LEFT JOIN stag.Prism_STORE (NOLOCK) AS sto
  ON doc.STORE_SID = sto.SID
LEFT JOIN ETL.GSMStoresLanding AS gss
  ON CAST(sto.GLOBAL_STORE_CODE AS NVARCHAR(20)) = gss.GSMStoreCode
WHERE CAST(doc.CREATED_DATETIME AS DATE) IS NOT NULL;

----------------------------------------------------------------------------------------------------

INSERT INTO ETL.SalesLanding (
  HashvalueBK, HashDiff, ModifiedOn, CreatedOn, NatInvoicePostingSalesDate, TimeOfDayCode,
  GSMStoreCode, WebTerminalGSMStoreCode, PDUCode, CurrencyCode, PromotionName, EANNo, ITEM_POS,
  StyleNumber_BK, ArticleNumber_BK, ArticleSize_BK, IntBusinessSegmentCode, ProductDivisionCode,
  RBUCode, RepIntAgeGrpCode, RepIntGenderCode, IntBrandCode, ProdCreationModelCode, GrossValueLC,
  CRPValueLC, NetValueLC, LineDiscount, Qty, NewDiscountAmount, NewPrice, PrevPrice, TenderAmount,
  DiscountReason, TenderName, Notes, CashierName, Employee1Name, OrderStatus, Comment1, Comment2,
  EmployeeCardNumber, TransactionNumber, Workstation_No, DOC_SID, DOC_REF_NO, ReceiptType,
  TrackingNumber, Note1, ReturnReason, TransactionType, DiscountSource, GiftCardType, Granularity
)
SELECT
    CONVERT(BINARY(16), HASHBYTES('MD5',
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(doc.CREATED_DATETIME AS DATE)), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(CAST(doc.CREATED_DATETIME AS TIME) AS VARCHAR(5))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(sto.GLOBAL_STORE_CODE AS NVARCHAR(20))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(did.DISC_PROMO_NAME AS NVARCHAR(300))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(right(CONCAT('0000000000000',cast(CAST(dit.SCAN_UPC AS decimal(14,0)) as bigint)), 13 )as nvarchar(13))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(CAST(dit.ITEM_POS AS FLOAT) AS INT)), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(doc.TENDER_NAME AS NVARCHAR(30))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(CAST(doc.DOC_NO AS FLOAT) AS INT)), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), did.SID), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), 2), ''))))) as HashvalueBK
  , CONVERT(BINARY(16), HASHBYTES('MD5',
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(doc.CREATED_DATETIME AS DATE)), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(CAST(doc.CREATED_DATETIME AS TIME) AS VARCHAR(5))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(sto.GLOBAL_STORE_CODE AS NVARCHAR(20))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(sto.GLOBAL_STORE_CODE AS NVARCHAR(20))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), gss.PDUCode), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(cur.ALPHABETIC_CODE AS NVARCHAR(3))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(did.DISC_PROMO_NAME AS NVARCHAR(300))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(right(CONCAT('0000000000000',cast(CAST(dit.SCAN_UPC AS decimal(14,0)) as bigint)), 13 )as nvarchar(13))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(CAST(dit.ITEM_POS AS FLOAT) AS INT)), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), art.StyleNumber_BK), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), art.ArticleNumber_BK), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), art.ArticleSize_BK), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), art.IntBusinessSegmentCode), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), art.ProductDivisionCode), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), art.RBUCode), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), art.RepIntAgeGrpCode), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), art.RepIntGenderCode), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), art.IntBrandCode), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), art.ProdCreationModelCode), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(
        CASE
          WHEN CAST(CAST(dit.ITEM_TYPE AS FLOAT) AS INT) = 2
          THEN CAST(ISNULL(did.NEW_DISC_AMT, 0) AS FLOAT) * (-1)
          ELSE CAST(ISNULL(did.NEW_DISC_AMT, 0) AS FLOAT)
        END AS DECIMAL(19,2))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(
        CASE
          WHEN CAST(CAST(dit.ITEM_TYPE AS FLOAT) AS INT) = 2
          THEN CAST(ISNULL(did.NEW_PRICE, 0) AS FLOAT) * (-1)
          ELSE CAST(ISNULL(did.NEW_PRICE, 0) AS FLOAT)
        END AS DECIMAL(19,2))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(
        CASE
          WHEN CAST(CAST(dit.ITEM_TYPE AS FLOAT) AS INT) = 2
          THEN CAST(ISNULL(did.PREV_PRICE, 0) AS FLOAT) * (-1)
          ELSE CAST(ISNULL(did.PREV_PRICE, 0) AS FLOAT)
        END AS DECIMAL(19,2))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(dit.DISCOUNT_REASON AS NVARCHAR(300))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(doc.TENDER_NAME AS NVARCHAR(30))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(doc.NOTES AS NVARCHAR(300))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(doc.CASHIER_FULL_NAME AS NVARCHAR(300))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(doc.EMPLOYEE1_FULL_NAME AS NVARCHAR(300))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(CAST(doc.STATUS AS FLOAT) AS INT)), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(doc.COMMENT1 AS NVARCHAR(300))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(doc.COMMENT2 AS NVARCHAR(300))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(doc.UDF5_STRING AS NVARCHAR(100))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(CAST(doc.DOC_NO AS FLOAT) AS INT)), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(CAST(doc.WORKSTATION_NO AS FLOAT) AS INT)), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(
          CASE
            WHEN CHARINDEX('.', doc.SID) = 0
            THEN doc.SID
            ELSE LEFT(doc.SID, CHARINDEX('.', doc.SID) - 1)
          END AS NVARCHAR(60))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(CAST(doc.DOC_REF_NO AS FLOAT) AS NVARCHAR(60))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(CAST(doc.RECEIPT_TYPE AS FLOAT) AS INT)), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(doc.TRACKING_NO AS NVARCHAR(60))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(dit.NOTE1 AS NVARCHAR(300))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(dit.RETURN_REASON AS NVARCHAR(300))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(CAST(dit.ITEM_TYPE AS FLOAT) AS INT)), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), did.DISC_SOURCE), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), 2), ''))))) AS HashDiff
  , GETDATE() AS ModifiedOn
  , GETDATE() AS CreatedOn
  , CAST(doc.CREATED_DATETIME AS DATE) AS NatInvoicePostingSalesDate
  , CAST(CAST(doc.CREATED_DATETIME AS TIME) AS VARCHAR(5)) AS TimeOfDayCode
  , CAST(sto.GLOBAL_STORE_CODE AS NVARCHAR(20)) AS GSMStoreCode
  , CAST(sto.GLOBAL_STORE_CODE AS NVARCHAR(20)) AS WebTerminalGSMStoreCode
  , gss.PDUCode
  , CAST(cur.ALPHABETIC_CODE AS NVARCHAR(3)) AS CurrencyCode
  , CAST(did.DISC_PROMO_NAME AS NVARCHAR(300)) AS PromotionName
  , TRY_CAST(right(CONCAT('0000000000000',cast(CAST(dit.SCAN_UPC AS decimal(14,0)) as bigint)), 13 )as nvarchar(13)) AS EANNo
  , CAST(CAST(dit.ITEM_POS AS FLOAT) AS INT) AS ITEM_POS
  , art.StyleNumber_BK
  , art.ArticleNumber_BK
  , art.ArticleSize_BK
  , art.IntBusinessSegmentCode
  , art.ProductDivisionCode
  , art.RBUCode
  , art.RepIntAgeGrpCode
  , art.RepIntGenderCode
  , art.IntBrandCode
  , art.ProdCreationModelCode
  , CAST(NULL AS DECIMAL(19,2)) AS GrossValueLC
  , CAST(NULL AS DECIMAL(19,2)) AS CRPValueLC
  , CAST(NULL AS DECIMAL(19,2)) AS NetValueLC
  , CAST(NULL AS DECIMAL(19,2)) AS LineDiscount
  , CAST(NULL AS INT) AS Qty
  , CAST(
        CASE
          WHEN CAST(CAST(dit.ITEM_TYPE AS FLOAT) AS INT) = 2
          THEN CAST(ISNULL(did.NEW_DISC_AMT, 0) AS FLOAT) * (-1)
          ELSE CAST(ISNULL(did.NEW_DISC_AMT, 0) AS FLOAT)
        END AS DECIMAL(19,2)) AS NewDiscountAmount
  , CAST(
        CASE
          WHEN CAST(CAST(dit.ITEM_TYPE AS FLOAT) AS INT) = 2
          THEN CAST(ISNULL(did.NEW_PRICE, 0) AS FLOAT) * (-1)
          ELSE CAST(ISNULL(did.NEW_PRICE, 0) AS FLOAT)
        END AS DECIMAL(19,2)) AS NewPrice
  , CAST(
        CASE
          WHEN CAST(CAST(dit.ITEM_TYPE AS FLOAT) AS INT) = 2
          THEN CAST(ISNULL(did.PREV_PRICE, 0) AS FLOAT) * (-1)
          ELSE CAST(ISNULL(did.PREV_PRICE, 0) AS FLOAT)
        END AS DECIMAL(19,2)) AS PrevPrice
  , CAST(NULL AS DECIMAL(19,2)) AS TenderAmount
  , CAST(dit.DISCOUNT_REASON AS NVARCHAR(300)) AS DiscountReason
  , CAST(doc.TENDER_NAME AS NVARCHAR(30)) AS TenderName
  , CAST(doc.NOTES AS NVARCHAR(300)) AS Notes
  , CAST(doc.CASHIER_FULL_NAME AS NVARCHAR(300)) AS CashierName
  , CAST(doc.EMPLOYEE1_FULL_NAME AS NVARCHAR(300)) AS Employee1Name
  , CAST(CAST(doc.STATUS AS FLOAT) AS INT) AS OrderStatus
  , CAST(doc.COMMENT1 AS NVARCHAR(300)) AS Comment1
  , CAST(doc.COMMENT2 AS NVARCHAR(300)) AS Comment2
  , CAST(doc.UDF5_STRING AS NVARCHAR(100)) AS EmployeeCardNumber
  , CAST(CAST(doc.DOC_NO AS FLOAT) AS INT) AS TransactionNumber
  , CAST(CAST(doc.WORKSTATION_NO AS FLOAT) AS INT) AS Workstation_No
  , CAST(
          CASE
            WHEN CHARINDEX('.', doc.SID) = 0
            THEN doc.SID
            ELSE LEFT(doc.SID, CHARINDEX('.', doc.SID) - 1)
          END AS NVARCHAR(60)) AS DOC_SID
  , CAST(CAST(doc.DOC_REF_NO AS FLOAT) AS NVARCHAR(60)) AS DOC_REF_NO
  , CAST(CAST(doc.RECEIPT_TYPE AS FLOAT) AS INT) AS ReceiptType
  , CAST(doc.TRACKING_NO AS NVARCHAR(60)) AS TrackingNumber
  , CAST(dit.NOTE1 AS NVARCHAR(300)) AS Note1
  , CAST(dit.RETURN_REASON AS NVARCHAR(300)) AS ReturnReason
  , CAST(CAST(dit.ITEM_TYPE AS FLOAT) AS INT) AS TransactionType
  , did.DISC_SOURCE AS DiscountSource
  , CAST(NULL AS NVARCHAR(300)) AS GiftCardType
  , 2 AS Granularity
FROM stag.Prism_DOCUMENT_ITEM (NOLOCK) AS dit
JOIN stag.Prism_DOCUMENT (NOLOCK) AS doc
  ON dit.DOC_SID = doc.SID
JOIN stag.Prism_DOCUMENT_ITEM_DISC (NOLOCK) AS did
  ON dit.SID = did.DOC_ITEM_SID
LEFT JOIN ETL.ArticlesLanding (NOLOCK) AS art
  ON TRY_CAST(right(CONCAT('0000000000000',cast(CAST(dit.SCAN_UPC AS decimal(14,0)) as bigint)), 13 )as nvarchar(13)) = art.EANNo
LEFT JOIN (
    SELECT DISTINCT
        DOC_SID
      , CURRENCY_SID
    FROM stag.Prism_TENDER (NOLOCK)
) AS ten
  ON dit.DOC_SID = ten.DOC_SID
LEFT JOIN stag.Prism_CURRENCY (NOLOCK) AS cur
  ON ten.CURRENCY_SID = cur.SID
LEFT JOIN stag.Prism_STORE (NOLOCK) AS sto
  ON doc.STORE_SID = sto.SID
LEFT JOIN ETL.GSMStoresLanding (NOLOCK) AS gss
  ON CAST(sto.GLOBAL_STORE_CODE AS NVARCHAR(20)) = gss.GSMStoreCode
WHERE CAST(doc.CREATED_DATETIME AS DATE) IS NOT NULL;

----------------------------------------------------------------------------------------------------

INSERT INTO ETL.SalesLanding (
  HashvalueBK, HashDiff, ModifiedOn, CreatedOn, NatInvoicePostingSalesDate, TimeOfDayCode,
  GSMStoreCode, WebTerminalGSMStoreCode, PDUCode, CurrencyCode, PromotionName, EANNo, ITEM_POS,
  StyleNumber_BK, ArticleNumber_BK, ArticleSize_BK, IntBusinessSegmentCode, ProductDivisionCode,
  RBUCode, RepIntAgeGrpCode, RepIntGenderCode, IntBrandCode, ProdCreationModelCode, GrossValueLC,
  CRPValueLC, NetValueLC, LineDiscount, Qty, NewDiscountAmount, NewPrice, PrevPrice, TenderAmount,
  DiscountReason, TenderName, Notes, CashierName, Employee1Name, OrderStatus, Comment1, Comment2,
  EmployeeCardNumber, TransactionNumber, Workstation_No, DOC_SID, DOC_REF_NO, ReceiptType,
  TrackingNumber, Note1, ReturnReason, TransactionType, DiscountSource, GiftCardType, Granularity
)
SELECT
    CONVERT(BINARY(16), HASHBYTES('MD5',
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(doc.CREATED_DATETIME AS DATE)), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(CAST(doc.CREATED_DATETIME AS TIME) AS VARCHAR(5))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(sto.GLOBAL_STORE_CODE AS NVARCHAR(20))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(ten.TENDER_NAME AS NVARCHAR(30))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(CAST(doc.DOC_NO AS FLOAT) AS INT)), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), ten.SID), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), 3), ''))))) as HashvalueBK
  , CONVERT(BINARY(16), HASHBYTES('MD5',
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(doc.CREATED_DATETIME AS DATE)), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(CAST(doc.CREATED_DATETIME AS TIME) AS VARCHAR(5))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(sto.GLOBAL_STORE_CODE AS NVARCHAR(20))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(sto.GLOBAL_STORE_CODE AS NVARCHAR(20))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), gss.PDUCode), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(cur.ALPHABETIC_CODE AS NVARCHAR(3))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(CAST(ten.AMOUNT AS FLOAT) AS DECIMAL(19,2))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(doc.DISCOUNT_REASON_NAME AS NVARCHAR(300))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(ten.TENDER_NAME AS NVARCHAR(30))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(doc.NOTES AS nvarchar(300))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(doc.CASHIER_FULL_NAME AS NVARCHAR(300))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(doc.EMPLOYEE1_FULL_NAME AS NVARCHAR(300))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(CAST(doc.STATUS AS FLOAT) AS INT)), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(doc.COMMENT1 AS NVARCHAR(300))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(doc.COMMENT2 AS NVARCHAR(300))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(doc.UDF5_STRING AS NVARCHAR(100))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(CAST(doc.DOC_NO AS FLOAT) AS INT)), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(CAST(doc.WORKSTATION_NO AS FLOAT) AS INT)), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(
        CASE
          WHEN CHARINDEX('.', doc.SID) = 0
          THEN doc.SID
          ELSE LEFT(doc.SID, CHARINDEX('.', doc.SID) - 1)
        END AS NVARCHAR(60))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(CAST(doc.DOC_REF_NO AS FLOAT) AS NVARCHAR(60))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(CAST(doc.RECEIPT_TYPE AS FLOAT) AS INT)), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(doc.TRACKING_NO AS NVARCHAR(60))), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CASE TRIM(ten.TENDER_NAME)
                                                 WHEN 'PumaAM' THEN 'Ambassador Card'
                                                 WHEN 'PumaGC' THEN 'Gift Card'
                                                 WHEN 'PumaMR' THEN 'Merchandise Return Card'
                                                 WHEN 'PumaON' THEN 'On behalf of Ambassador Card'
                                                 WHEN 'PumaSE' THEN 'Seeding Card'
                                                 WHEN 'PumaVC' THEN 'VIP Card'
                                               END), ''))) + '_' +
      UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), 3), ''))))) AS HashDiff
  , GETDATE() AS ModifiedOn
  , GETDATE() AS CreatedOn
  , CAST(doc.CREATED_DATETIME AS DATE) AS NatInvoicePostingSalesDate
  , CAST(CAST(doc.CREATED_DATETIME AS TIME) AS VARCHAR(5)) AS TimeOfDayCode
  , CAST(sto.GLOBAL_STORE_CODE AS NVARCHAR(20)) AS GSMStoreCode
  , CAST(sto.GLOBAL_STORE_CODE AS NVARCHAR(20)) AS WebTerminalGSMStoreCode
  , gss.PDUCode
  , CAST(cur.ALPHABETIC_CODE AS NVARCHAR(3)) AS CurrencyCode
  , CAST(NULL AS NVARCHAR(300)) AS PromotionName
  , CAST(NULL AS NVARCHAR(13)) AS EANNo
  , CAST(NULL AS INT) AS ITEM_POS
  , CAST(NULL AS INT) AS StyleNumber_BK
  , CAST(NULL AS NVARCHAR(13)) AS ArticleNumber_BK
  , CAST(NULL AS NVARCHAR(20)) AS ArticleSize_BK
  , CAST(NULL AS INT) AS IntBusinessSegmentCode
  , CAST(NULL AS INT) AS ProductDivisionCode
  , CAST(NULL AS INT) AS RBUCode
  , CAST(NULL AS INT) AS RepIntAgeGrpCode
  , CAST(NULL AS INT) AS RepIntGenderCode
  , CAST(NULL AS NVARCHAR(6)) AS IntBrandCode
  , CAST(NULL AS INT) AS ProdCreationModelCode
  , CAST(NULL AS DECIMAL(19,2)) AS GrossValueLC
  , CAST(NULL AS DECIMAL(19,2)) AS CRPValueLC
  , CAST(NULL AS DECIMAL(19,2)) AS NetValueLC
  , CAST(NULL AS DECIMAL(19,2)) AS LineDiscount
  , CAST(NULL AS INT) AS Qty
  , CAST(NULL AS DECIMAL(19,2)) AS NewDiscountAmount
  , CAST(NULL AS DECIMAL(19,2)) AS NewPrice
  , CAST(NULL AS DECIMAL(19,2)) AS PrevPrice
  , CAST(CAST(ten.AMOUNT AS FLOAT) AS DECIMAL(19,2)) AS TenderAmount
  , CAST(doc.DISCOUNT_REASON_NAME AS NVARCHAR(300)) AS DiscountReason
  , CAST(ten.TENDER_NAME AS NVARCHAR(30)) AS TenderName
  , CAST(doc.NOTES AS nvarchar(300)) AS Notes
  , CAST(doc.CASHIER_FULL_NAME AS NVARCHAR(300)) AS CashierName
  , CAST(doc.EMPLOYEE1_FULL_NAME AS NVARCHAR(300)) AS Employee1Name
  , CAST(CAST(doc.STATUS AS FLOAT) AS INT) AS OrderStatus
  , CAST(doc.COMMENT1 AS NVARCHAR(300)) AS Comment1
  , CAST(doc.COMMENT2 AS NVARCHAR(300)) AS Comment2
  , CAST(doc.UDF5_STRING AS NVARCHAR(100)) AS EmployeeCardNumber
  , CAST(CAST(doc.DOC_NO AS FLOAT) AS INT) AS TransactionNumber
  , CAST(CAST(doc.WORKSTATION_NO AS FLOAT) AS INT) AS Workstation_No
  , CAST(
        CASE
          WHEN CHARINDEX('.', doc.SID) = 0
          THEN doc.SID
          ELSE LEFT(doc.SID, CHARINDEX('.', doc.SID) - 1)
        END AS NVARCHAR(60)) AS DOC_SID
  , CAST(CAST(doc.DOC_REF_NO AS FLOAT) AS NVARCHAR(60)) AS DOC_REF_NO
  , CAST(CAST(doc.RECEIPT_TYPE AS FLOAT) AS INT) AS ReceiptType
  , CAST(doc.TRACKING_NO AS NVARCHAR(60)) AS TrackingNumber
  , CAST(NULL AS NVARCHAR(300)) AS Note1
  , CAST(NULL AS NVARCHAR(300)) AS ReturnReason
  , CAST(NULL AS INT) AS TransactionType
  , CAST(NULL AS NVARCHAR(300)) AS DiscountSource
  , CASE TRIM(ten.TENDER_NAME)
      WHEN 'PumaAM' THEN 'Ambassador Card'
      WHEN 'PumaGC' THEN 'Gift Card'
      WHEN 'PumaMR' THEN 'Merchandise Return Card'
      WHEN 'PumaON' THEN 'On behalf of Ambassador Card'
      WHEN 'PumaSE' THEN 'Seeding Card'
      WHEN 'PumaVC' THEN 'VIP Card'
    END AS GiftCardType
  , 3 AS Granularity
FROM stag.Prism_DOCUMENT (NOLOCK) AS doc
JOIN (
    SELECT DISTINCT
        SID
      , DOC_SID
      , CURRENCY_SID
      , TENDER_NAME
      , AMOUNT
    FROM stag.Prism_TENDER (NOLOCK)
) AS ten
  ON doc.SID = ten.DOC_SID
LEFT JOIN stag.Prism_CURRENCY (NOLOCK) AS cur
  ON ten.CURRENCY_SID = cur.SID
LEFT JOIN stag.Prism_STORE (NOLOCK) AS sto
  ON doc.STORE_SID = sto.SID
LEFT JOIN ETL.GSMStoresLanding (NOLOCK) AS gss
  ON CAST(sto.GLOBAL_STORE_CODE AS NVARCHAR(20)) = gss.GSMStoreCode
WHERE CAST(doc.CREATED_DATETIME AS DATE) IS NOT NULL;

----------------------------------------------------------------------------------------------------

END