﻿CREATE PROCEDURE [dbo].[Prism_spUpdateLandedCost] @isFullMode BIT, @lastUpdated DATETIME2
AS
BEGIN

	IF @isFullMode = 1
	BEGIN

		UPDATE sales
		SET 
			TotalLandedCost = sales.Qty * cost.UnitLandedCost,
			LandedCostCurrencyCode = cost.ArticleCurrencyCode
		FROM [Sales].[RetailSales] AS sales
		JOIN [ref].[PlantMaterialPricesHistory_DL] AS cost
		ON sales.GSMStoreCode = cost.GSMStoreCode
			AND sales.ArticleSize_BK = cost.ArticleSize_BK
			AND sales.NatInvoicePostingSalesDate BETWEEN cost.ValidFrom AND cost.ValidTo
		WHERE sales.Granularity = 1;

	END

	ELSE
	BEGIN

		DECLARE @costModificationDate DATETIME = (SELECT MAX(ModificationDate) FROM [ref].[PlantMaterialPricesHistory_DL]);

		UPDATE sales
		SET 
			TotalLandedCost = sales.Qty * cost.UnitLandedCost,
			LandedCostCurrencyCode = cost.ArticleCurrencyCode
		FROM [Sales].[RetailSales] AS sales
		JOIN [ref].[PlantMaterialPricesHistory_DL] AS cost
		ON sales.GSMStoreCode = cost.GSMStoreCode
			AND sales.ArticleSize_BK = cost.ArticleSize_BK
			AND sales.NatInvoicePostingSalesDate BETWEEN cost.ValidFrom AND cost.ValidTo
		WHERE sales.Granularity = 1 AND (sales.ModifiedOn > @lastUpdated OR cost.ModificationDate = @costModificationDate);
		
	END

END