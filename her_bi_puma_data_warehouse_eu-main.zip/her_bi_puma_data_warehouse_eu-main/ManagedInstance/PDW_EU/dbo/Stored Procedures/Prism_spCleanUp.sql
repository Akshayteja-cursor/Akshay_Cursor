﻿
CREATE   PROCEDURE [dbo].[Prism_spCleanUp]
AS
BEGIN

----------------------------------------------------------------------------------------------------

DELETE PRICE_LEVEL
FROM (
    SELECT ROW_NUMBER() OVER(PARTITION BY PRICE_LVL, PRICE_LVL_NAME ORDER BY MODIFIED_DATETIME DESC) AS RN
    FROM Stag.Prism_PRICE_LEVEL
) AS PRICE_LEVEL
WHERE RN > 1;

----------------------------------------------------------------------------------------------------

DELETE STORE
FROM (
    SELECT ROW_NUMBER() OVER(PARTITION BY SID, GLOBAL_STORE_CODE ORDER BY SID, GLOBAL_STORE_CODE) AS RN
    FROM Stag.Prism_STORE
) AS STORE
WHERE RN > 1;

----------------------------------------------------------------------------------------------------

DELETE SUBSIDIARY
FROM (
    SELECT ROW_NUMBER() OVER(PARTITION BY SBS_NO, SBS_NAME ORDER BY SBS_NO, SBS_NAME) AS RN
    FROM Stag.Prism_SUBSIDIARY
) AS SUBSIDIARY
WHERE RN > 1;

----------------------------------------------------------------------------------------------------

DELETE CURRENCY
FROM (
    SELECT ROW_NUMBER() OVER(PARTITION BY ALPHABETIC_CODE ORDER BY ALPHABETIC_CODE) AS RN
    FROM Stag.Prism_CURRENCY
) AS CURRENCY
WHERE RN > 1;

----------------------------------------------------------------------------------------------------

DELETE TENDER
FROM (
    SELECT ROW_NUMBER() OVER(PARTITION BY SID ORDER BY SID) AS RN
    FROM Stag.Prism_TENDER
) AS TENDER
WHERE RN > 1;

----------------------------------------------------------------------------------------------------

DELETE INVN_SBS_PRICE
FROM (
    SELECT ROW_NUMBER() OVER(PARTITION BY SID ORDER BY CREATED_DATETIME DESC) AS RN
    FROM Stag.Prism_INVN_SBS_PRICE
) AS INVN_SBS_PRICE
WHERE RN > 1;

----------------------------------------------------------------------------------------------------

END