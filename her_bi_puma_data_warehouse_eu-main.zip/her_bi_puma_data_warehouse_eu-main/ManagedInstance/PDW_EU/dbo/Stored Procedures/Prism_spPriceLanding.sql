﻿
CREATE   PROCEDURE [dbo].[Prism_spPriceLanding]
AS
BEGIN

----------------------------------------------------------------------------------------------------

TRUNCATE TABLE ETL.PriceLanding;

----------------------------------------------------------------------------------------------------

INSERT INTO ETL.PriceLanding
SELECT
    a.INVN_SBS_ITEM_SID
  , ISNULL(b.PRICE, a.PRICE) AS PRICE
FROM (
    SELECT
        prc.INVN_SBS_ITEM_SID
      , MAX(CAST(prc.PRICE AS FLOAT)) AS PRICE
    FROM stag.Prism_INVN_SBS_PRICE AS prc
    JOIN stag.Prism_PRICE_LEVEL AS prl
      ON prc.PRICE_LVL_SID = prl.SID
    GROUP BY INVN_SBS_ITEM_SID
) AS a
LEFT JOIN (
    SELECT DISTINCT
        prc.INVN_SBS_ITEM_SID
      , prc.PRICE
    FROM stag.Prism_INVN_SBS_PRICE AS prc
    JOIN stag.Prism_PRICE_LEVEL AS prl
      ON prc.PRICE_LVL_SID = prl.SID
    WHERE prl.PRICE_LVL_NAME = 'RRP'
) AS b
  ON a.INVN_SBS_ITEM_SID = b.INVN_SBS_ITEM_SID;

----------------------------------------------------------------------------------------------------

END