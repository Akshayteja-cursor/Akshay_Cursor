﻿
CREATE   PROCEDURE [dbo].[Prism_spArticlesLanding]
AS
BEGIN

TRUNCATE TABLE ETL.ArticlesLanding;
----------------------------------------------------------------------------------------------------

MERGE
  INTO ETL.ArticlesLanding AS tgt
  USING (
      SELECT
          CAST(asi.EANNo AS NVARCHAR(13)) AS EANNo
        , asi.StyleNumber_BK
        , CAST(asi.ArticleNumber_BK AS NVARCHAR(13)) AS ArticleNumber_BK
        , CAST(CONCAT(asi.ArticleNumber_BK, ' ', asi.SizeNumber) AS NVARCHAR(20)) AS ArticleSize_BK
        , ase.ProductCreationModelCode AS ProdCreationModelCode
        , sse.BusinessSegmentCode AS IntBusinessSegmentCode
        , sse.BrandCode AS IntBrandCode
        , sse.ProductDivisionCode
        , sse.RBUCode
        , sse.ReportingGenderCode AS RepIntGenderCode
        , sse.ReportingAgeGroupCode AS RepIntAgeGrpCode
        , CONVERT(BINARY(16), HASHBYTES('MD5',
            UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), asi.StyleNumber_BK), ''))) + '_' +
            UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(asi.ArticleNumber_BK AS NVARCHAR(13))), ''))) + '_' +
            UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), CAST(CONCAT(asi.ArticleNumber_BK, ' ', asi.SizeNumber) AS NVARCHAR(20))), ''))) + '_' +
            UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), ase.ProductCreationModelCode), ''))) + '_' +
            UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), sse.BusinessSegmentCode), ''))) + '_' +
            UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), sse.BrandCode), ''))) + '_' +
            UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), sse.ProductDivisionCode), ''))) + '_' +
            UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), sse.RBUCode), ''))) + '_' +
            UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), sse.ReportingGenderCode), ''))) + '_' +
            UPPER(TRIM(ISNULL(CONVERT(NVARCHAR(300), sse.ReportingAgeGroupCode), ''))))) AS HashDiff
      FROM ref.ArticleSizes_DL (NOLOCK) AS asi
      JOIN ref.ArticleSeasons_DL (NOLOCK) AS ase
        ON asi.ArticleNumber_BK = ase.ArticleNumber_BK
        --AND ase.SeasonCode_BK = ase.LastSeasonCode
        --AND ase.SourceSystem = 'PID'
        AND CONCAT(ase.SeasonCode_BK, ' ', RIGHT(CONCAT('000000', asi.StyleNumber_BK), 6)) = ase.SeasonCode_StyleNumber_BK
      JOIN (
          SELECT
              ArticleNumber_BK
            , MAX(LastSeasonCode) AS MaxLastSeasonCode
          FROM ref.ArticleSeasons_DL (NOLOCK)
          GROUP BY ArticleNumber_BK
      ) AS lsc
        ON ase.ArticleNumber_BK = lsc.ArticleNumber_BK
        AND ase.LastSeasonCode = lsc.MaxLastSeasonCode
      JOIN ref.StyleSeasons_DL (NOLOCK) AS sse
        ON ase.StyleNumber_BK = sse.StyleNumber_BK
        --AND ase.SeasonCode_BK = sse.SeasonCode_BK
      WHERE TRIM(CONVERT(NVARCHAR(13), asi.EANNo)) <> ''  
  ) AS src
    ON tgt.EANNo = src.EANNo
  
  WHEN MATCHED AND tgt.HashDiff <> src.HashDiff THEN
    UPDATE SET
      tgt.StyleNumber_BK         = src.StyleNumber_BK,
      tgt.ArticleNumber_BK       = src.ArticleNumber_BK,
      tgt.ArticleSize_BK         = src.ArticleSize_BK,
      tgt.ProdCreationModelCode  = src.ProdCreationModelCode,
      tgt.IntBusinessSegmentCode = src.IntBusinessSegmentCode,
      tgt.IntBrandCode           = src.IntBrandCode,
      tgt.ProductDivisionCode    = src.ProductDivisionCode,
      tgt.RBUCode                = src.RBUCode,
      tgt.RepIntGenderCode       = src.RepIntGenderCode,
      tgt.RepIntAgeGrpCode       = src.RepIntAgeGrpCode,
      tgt.HashDiff               = src.HashDiff
  
  WHEN NOT MATCHED THEN
    INSERT (
      EANNo,
      StyleNumber_BK,
      ArticleNumber_BK,
      ArticleSize_BK,
      ProdCreationModelCode,
      IntBusinessSegmentCode,
      IntBrandCode,
      ProductDivisionCode,
      RBUCode,
      RepIntGenderCode,
      RepIntAgeGrpCode,
      HashDiff
    )
    VALUES (
      src.EANNo,
      src.StyleNumber_BK,
      src.ArticleNumber_BK,
      src.ArticleSize_BK,
      src.ProdCreationModelCode,
      src.IntBusinessSegmentCode,
      src.IntBrandCode,
      src.ProductDivisionCode,
      src.RBUCode,
      src.RepIntGenderCode,
      src.RepIntAgeGrpCode,
      src.HashDiff
    );

----------------------------------------------------------------------------------------------------

END