﻿
CREATE   PROCEDURE [dbo].[Prism_spProvSalesLast]
AS
BEGIN

----------------------------------------------------------------------------------------------------

MERGE INTO sales.RetailSales AS sales_old
  USING ETL.SalesLanding AS sales_new
    ON sales_old.HashvalueBK = sales_new.HashvalueBK

  WHEN MATCHED AND sales_old.HashDiff <> sales_new.HashDiff THEN
    UPDATE SET
      sales_old.HashDiff                = sales_new.HashDiff,
      sales_old.ModifiedOn              = GETDATE(),
      sales_old.TimeOfDayCode           = sales_new.TimeOfDayCode,
      sales_old.WebTerminalGSMStoreCode = sales_new.WebTerminalGSMStoreCode,
      sales_old.PDUCode                 = sales_new.PDUCode,
      sales_old.CurrencyCode            = sales_new.CurrencyCode,
      sales_old.StyleNumber_BK          = sales_new.StyleNumber_BK,
      sales_old.ArticleNumber_BK        = sales_new.ArticleNumber_BK,
      sales_old.ArticleSize_BK          = sales_new.ArticleSize_BK,
      sales_old.IntBusinessSegmentCode  = sales_new.IntBusinessSegmentCode,
      sales_old.ProductDivisionCode     = sales_new.ProductDivisionCode,
      sales_old.RBUCode                 = sales_new.RBUCode,
      sales_old.RepIntAgeGrpCode        = sales_new.RepIntAgeGrpCode,
      sales_old.RepIntGenderCode        = sales_new.RepIntGenderCode,
      sales_old.IntBrandCode            = sales_new.IntBrandCode,
      sales_old.ProdCreationModelCode   = sales_new.ProdCreationModelCode,
      sales_old.GrossValueLC            = sales_new.GrossValueLC,
      sales_old.CRPValueLC              = sales_new.CRPValueLC,
      sales_old.NetValueLC              = sales_new.NetValueLC,
      sales_old.LineDiscount            = sales_new.LineDiscount,
      sales_old.Qty                     = sales_new.Qty,
      sales_old.NewDiscountAmount       = sales_new.NewDiscountAmount,
      sales_old.NewPrice                = sales_new.NewPrice,
      sales_old.PrevPrice               = sales_new.PrevPrice,
      sales_old.TenderAmount            = sales_new.TenderAmount,
      sales_old.DiscountReason          = sales_new.DiscountReason,
      sales_old.Notes                   = sales_new.Notes,
      sales_old.CashierName             = sales_new.CashierName,
      sales_old.Employee1Name           = sales_new.Employee1Name,
      sales_old.OrderStatus             = sales_new.OrderStatus,
      sales_old.Comment1                = sales_new.Comment1,
      sales_old.Comment2                = sales_new.Comment2,
      sales_old.EmployeeCardNumber      = sales_new.EmployeeCardNumber,
      sales_old.Workstation_No          = sales_new.Workstation_No,
      sales_old.DOC_SID                 = sales_new.DOC_SID,
      sales_old.DOC_REF_NO              = sales_new.DOC_REF_NO,
      sales_old.ReceiptType             = sales_new.ReceiptType,
      sales_old.TrackingNumber          = sales_new.TrackingNumber,
      sales_old.Note1                   = sales_new.Note1,
      sales_old.ReturnReason            = sales_new.ReturnReason,
      sales_old.TransactionType         = sales_new.TransactionType,
      sales_old.DiscountSource          = sales_new.DiscountSource,
      sales_old.GiftCardType            = sales_new.GiftCardType
  
  WHEN NOT MATCHED BY TARGET THEN
    INSERT (
      HashvalueBK,
      HashDiff,
      ModifiedOn,
      CreatedOn,
      NatInvoicePostingSalesDate,
      TimeOfDayCode,
      GSMStoreCode,
      WebTerminalGSMStoreCode,
      PDUCode,
      CurrencyCode,
      PromotionName,
      EANNo,
      ITEM_POS,
      StyleNumber_BK,
      ArticleNumber_BK,
      ArticleSize_BK,
      IntBusinessSegmentCode,
      ProductDivisionCode,
      RBUCode,
      RepIntAgeGrpCode,
      RepIntGenderCode,
      IntBrandCode,
      ProdCreationModelCode,
      GrossValueLC,
      CRPValueLC,
      NetValueLC,
      LineDiscount,
      Qty,
      NewDiscountAmount,
      NewPrice,
      PrevPrice,
      TenderAmount,
      DiscountReason,
      TenderName,
      Notes,
      CashierName,
      Employee1Name,
      OrderStatus,
      Comment1,
      Comment2,
      EmployeeCardNumber,
      TransactionNumber,
      Workstation_No,
      DOC_SID,
      DOC_REF_NO,
      ReceiptType,
      TrackingNumber,
      Note1,
      ReturnReason,
      TransactionType,
      DiscountSource,
      GiftCardType,
      Granularity
    )
    VALUES (
      sales_new.HashvalueBK,
      sales_new.HashDiff,
      GETDATE(),
      GETDATE(),
      sales_new.NatInvoicePostingSalesDate,
      sales_new.TimeOfDayCode,
      sales_new.GSMStoreCode,
      sales_new.WebTerminalGSMStoreCode,
      sales_new.PDUCode,
      sales_new.CurrencyCode,
      sales_new.PromotionName,
      sales_new.EANNo,
      sales_new.ITEM_POS,
      sales_new.StyleNumber_BK,
      sales_new.ArticleNumber_BK,
      sales_new.ArticleSize_BK,
      sales_new.IntBusinessSegmentCode,
      sales_new.ProductDivisionCode,
      sales_new.RBUCode,
      sales_new.RepIntAgeGrpCode,
      sales_new.RepIntGenderCode,
      sales_new.IntBrandCode,
      sales_new.ProdCreationModelCode,
      sales_new.GrossValueLC,
      sales_new.CRPValueLC,
      sales_new.NetValueLC,
      sales_new.LineDiscount,
      sales_new.Qty,
      sales_new.NewDiscountAmount,
      sales_new.NewPrice,
      sales_new.PrevPrice,
      sales_new.TenderAmount,
      sales_new.DiscountReason,
      sales_new.TenderName,
      sales_new.Notes,
      sales_new.CashierName,
      sales_new.Employee1Name,
      sales_new.OrderStatus,
      sales_new.Comment1,
      sales_new.Comment2,
      sales_new.EmployeeCardNumber,
      sales_new.TransactionNumber,
      sales_new.Workstation_No,
      sales_new.DOC_SID,
      sales_new.DOC_REF_NO,
      sales_new.ReceiptType,
      sales_new.TrackingNumber,
      sales_new.Note1,
      sales_new.ReturnReason,
      sales_new.TransactionType,
      sales_new.DiscountSource,
      sales_new.GiftCardType,
      sales_new.Granularity
    );

----------------------------------------------------------------------------------------------------
INSERT INTO [STAG].[Prism_DOCUMENT_History]
(
 CREATED_DATETIME
,TENDER_NAME
,NOTES
,CASHIER_FULL_NAME
,EMPLOYEE1_FULL_NAME
,[STATUS]
,COMMENT1
,COMMENT2
,UDF5_STRING
,DOC_NO
,WORKSTATION_NO
,[SID]
,DOC_REF_NO
,RECEIPT_TYPE
,TRACKING_NO
,STORE_SID
,DISCOUNT_REASON_NAME
,SBS_NO
,STORE_NO
,STORE_NAME
)
SELECT  
 CREATED_DATETIME
,TENDER_NAME
,NOTES
,CASHIER_FULL_NAME
,EMPLOYEE1_FULL_NAME
,[STATUS]
,COMMENT1
,COMMENT2
,UDF5_STRING
,DOC_NO
,WORKSTATION_NO
,[SID]
,DOC_REF_NO
,RECEIPT_TYPE
,TRACKING_NO
,STORE_SID
,DISCOUNT_REASON_NAME
,SBS_NO
,STORE_NO
,STORE_NAME FROM Stag.Prism_DOCUMENT;
TRUNCATE TABLE Stag.Prism_DOCUMENT;


INSERT INTO [STAG].[Prism_DOCUMENT_ITEM_History]
(
[SID]
,DOC_SID
,SCAN_UPC
,DISCOUNT_REASON
,NOTE1
,ITEM_POS
,RETURN_REASON
,ITEM_TYPE
,ORIG_PRICE
,ORIG_TAX_AMT
,QTY
,PRICE
,TAX_AMT
,INVN_SBS_ITEM_SID
,TAX_PERC
)
SELECT [SID]
,DOC_SID
,SCAN_UPC
,DISCOUNT_REASON
,NOTE1
,ITEM_POS
,RETURN_REASON
,ITEM_TYPE
,ORIG_PRICE
,ORIG_TAX_AMT
,QTY
,PRICE
,TAX_AMT
,INVN_SBS_ITEM_SID
,TAX_PERC
FROM Stag.Prism_DOCUMENT_ITEM;
TRUNCATE TABLE Stag.Prism_DOCUMENT_ITEM;


INSERT INTO [STAG].[Prism_INVN_SBS_ITEM_History]
(
[SID]
,CREATED_BY
,CREATED_DATETIME
,MODIFIED_BY
,MODIFIED_DATETIME
,CONTROLLER_SID
,ORIGIN_APPLICATION
,POST_DATE
,ROW_VERSION
,TENANT_SID
,INVN_ITEM_UID
,SBS_SID
,ALU
,STYLE_SID
,DCS_SID
,VEND_SID
,DESCRIPTION1
,DESCRIPTION2
,DESCRIPTION3
,DESCRIPTION4
,ATTRIBUTE
,COST
,SPIF
,CURRENCY_SID
,LAST_SOLD_DATE
,MARKDOWN_DATE
,DISCONTINUED_DATE
,TAX_CODE_SID
,UDF1_FLOAT
,UDF2_FLOAT
,UDF3_FLOAT
,UDF1_DATE
,UDF2_DATE
,UDF3_DATE
,ITEM_SIZE
,FC_COST
,FIRST_RCVD_DATE
,LAST_RCVD_DATE
,COMM_SID
,DISC_SCHEDULE_SID
,UDF1_STRING
,UDF2_STRING
,UDF3_STRING
,UDF4_STRING
,UDF5_STRING
,SELLABLE_DATE
,ORDERABLE_DATE
,USE_QTY_DECIMALS
,FORCE_ORIG_TAX
,FST_PRICE
,[DESCRIPTION]
,REGIONAL
,ACTIVE
,QTY_PER_CASE
,UPC
,MAX_DISC_PERC1
,MAX_DISC_PERC2
,ITEM_NO
,SERIAL_TYPE
,LOT_TYPE
,KIT_TYPE
,SCALE_SID
,PROMO_QTYDISCWEIGHT
,PROMO_INVENEXCLUDE
,LAST_RCVD_COST
,NON_INVENTORY
,NON_COMMITED
,ORDERABLE
,LTY_PRICE_IN_POINTS
,LTY_POINTS_EARNED
,ITEM_STATE
,PUBLISH_STATUS
,MIN_ORD_QTY
,VENDOR_LIST_COST
,TRADE_DISC_PERC
,LONG_DESCRIPTION
,TEXT1
,TEXT2
,TEXT3
,TEXT4
,TEXT5
,TEXT6
,TEXT7
,TEXT8
,TEXT9
,TEXT10
,HEIGHT
,[LENGTH]
,WIDTH
,SPECIAL_ORDER
,EXTERNAL_TRANSFER_STATUS
,RowNo
,_BatchId
)
SELECT [SID]
,CREATED_BY
,CREATED_DATETIME
,MODIFIED_BY
,MODIFIED_DATETIME
,CONTROLLER_SID
,ORIGIN_APPLICATION
,POST_DATE
,ROW_VERSION
,TENANT_SID
,INVN_ITEM_UID
,SBS_SID
,ALU
,STYLE_SID
,DCS_SID
,VEND_SID
,DESCRIPTION1
,DESCRIPTION2
,DESCRIPTION3
,DESCRIPTION4
,ATTRIBUTE
,COST
,SPIF
,CURRENCY_SID
,LAST_SOLD_DATE
,MARKDOWN_DATE
,DISCONTINUED_DATE
,TAX_CODE_SID
,UDF1_FLOAT
,UDF2_FLOAT
,UDF3_FLOAT
,UDF1_DATE
,UDF2_DATE
,UDF3_DATE
,ITEM_SIZE
,FC_COST
,FIRST_RCVD_DATE
,LAST_RCVD_DATE
,COMM_SID
,DISC_SCHEDULE_SID
,UDF1_STRING
,UDF2_STRING
,UDF3_STRING
,UDF4_STRING
,UDF5_STRING
,SELLABLE_DATE
,ORDERABLE_DATE
,USE_QTY_DECIMALS
,FORCE_ORIG_TAX
,FST_PRICE
,[DESCRIPTION]
,REGIONAL
,ACTIVE
,QTY_PER_CASE
,UPC
,MAX_DISC_PERC1
,MAX_DISC_PERC2
,ITEM_NO
,SERIAL_TYPE
,LOT_TYPE
,KIT_TYPE
,SCALE_SID
,PROMO_QTYDISCWEIGHT
,PROMO_INVENEXCLUDE
,LAST_RCVD_COST
,NON_INVENTORY
,NON_COMMITED
,ORDERABLE
,LTY_PRICE_IN_POINTS
,LTY_POINTS_EARNED
,ITEM_STATE
,PUBLISH_STATUS
,MIN_ORD_QTY
,VENDOR_LIST_COST
,TRADE_DISC_PERC
,LONG_DESCRIPTION
,TEXT1
,TEXT2
,TEXT3
,TEXT4
,TEXT5
,TEXT6
,TEXT7
,TEXT8
,TEXT9
,TEXT10
,HEIGHT
,[LENGTH]
,WIDTH
,SPECIAL_ORDER
,EXTERNAL_TRANSFER_STATUS
,RowNo
,_BatchId
FROM Stag.Prism_INVN_SBS_ITEM;
TRUNCATE TABLE Stag.Prism_INVN_SBS_ITEM;


INSERT INTO [STAG].[Prism_DOCUMENT_ITEM_DISC_History]
(
[SID]
,DOC_ITEM_SID
,DISC_SOURCE
,DISC_PROMO_NAME
,NEW_DISC_AMT
,NEW_PRICE
,PREV_PRICE
)
SELECT [SID]
,DOC_ITEM_SID
,DISC_SOURCE
,DISC_PROMO_NAME
,NEW_DISC_AMT
,NEW_PRICE
,PREV_PRICE
FROM Stag.Prism_DOCUMENT_ITEM_DISC;
TRUNCATE TABLE Stag.Prism_DOCUMENT_ITEM_DISC;

INSERT INTO [STAG].[Prism_INVN_SBS_PRICE_History]
(
[SID]
,CREATED_BY
,CREATED_DATETIME
,MODIFIED_BY
,MODIFIED_DATETIME
,CONTROLLER_SID
,ORIGIN_APPLICATION
,POST_DATE
,ROW_VERSION
,TENANT_SID
,INVN_ITEM_UID
,SBS_SID
,SEASON_SID
,PRICE_LVL_SID
,PRICE
,QTY_REQUIRED
,INVN_SBS_ITEM_SID
,RowNo
,_BatchId
)
SELECT [SID]
,CREATED_BY
,CREATED_DATETIME
,MODIFIED_BY
,MODIFIED_DATETIME
,CONTROLLER_SID
,ORIGIN_APPLICATION
,POST_DATE
,ROW_VERSION
,TENANT_SID
,INVN_ITEM_UID
,SBS_SID
,SEASON_SID
,PRICE_LVL_SID
,PRICE
,QTY_REQUIRED
,INVN_SBS_ITEM_SID
,RowNo
,_BatchId
FROM Stag.Prism_INVN_SBS_PRICE
TRUNCATE TABLE Stag.Prism_INVN_SBS_PRICE;


INSERT INTO [STAG].[Prism_TENDER_History]
(
DOC_SID
,CURRENCY_SID
,[SID]
,AMOUNT
,TENDER_NAME
)
SELECT DOC_SID
,CURRENCY_SID
,[SID]
,AMOUNT
,TENDER_NAME
FROM Stag.Prism_TENDER;
TRUNCATE TABLE Stag.Prism_TENDER;

INSERT INTO [STAG].[Prism_TENDER_GIFT_CARD_History]
(
[SID]
,CREATED_BY
,CREATED_DATETIME
,MODIFIED_BY
,MODIFIED_DATETIME
,CONTROLLER_SID
,ORIGIN_APPLICATION
,POST_DATE
,ROW_VERSION
,TENANT_SID
,TENDER_SID
,CARD_NO
,CARD_EXP_MONTH
,CARD_EXP_YEAR
,IS_PRESENT
,TRACE_NO
,INTERNAL_REF_NO
,BALANCE
,AUTH_CODE
,EFT_TRANSACTION_ID
,AVS_RESPONSE_CODE
,L2_RESULT_CODE
,FAILURE_MESSAGE
,EFTDATA1
,EFTDATA2
,EFTDATA3
,EFTDATA4
,EFTDATA5
,EFTDATA6
,EFTDATA7
,EFTDATA8
,EFTDATA9
,EFTDATA0
,ENTRY_METHOD
,EMV_AI_AID
,EMV_AI_APPLABEL
,EMV_CI_CARDEXPIRYDATE
,EMV_CRYPTO_CRYPTOGRAMTYPE
,EMV_CRYPTO_CRYPTOGRAM
,EMV_PINSTATEMENT
,EFTDATA10
,EFTDATA11
,EFTDATA12
,EFTDATA13
,EFTDATA14
,EFTDATA15
,EFTDATA16
,EFTDATA17
,EFTDATA18
,EFTDATA19
,EFTDATABSMER
,EFTDATABSCUST
,RowNo
,_BatchId
)
SELECT [SID]
,CREATED_BY
,CREATED_DATETIME
,MODIFIED_BY
,MODIFIED_DATETIME
,CONTROLLER_SID
,ORIGIN_APPLICATION
,POST_DATE
,ROW_VERSION
,TENANT_SID
,TENDER_SID
,CARD_NO
,CARD_EXP_MONTH
,CARD_EXP_YEAR
,IS_PRESENT
,TRACE_NO
,INTERNAL_REF_NO
,BALANCE
,AUTH_CODE
,EFT_TRANSACTION_ID
,AVS_RESPONSE_CODE
,L2_RESULT_CODE
,FAILURE_MESSAGE
,EFTDATA1
,EFTDATA2
,EFTDATA3
,EFTDATA4
,EFTDATA5
,EFTDATA6
,EFTDATA7
,EFTDATA8
,EFTDATA9
,EFTDATA0
,ENTRY_METHOD
,EMV_AI_AID
,EMV_AI_APPLABEL
,EMV_CI_CARDEXPIRYDATE
,EMV_CRYPTO_CRYPTOGRAMTYPE
,EMV_CRYPTO_CRYPTOGRAM
,EMV_PINSTATEMENT
,EFTDATA10
,EFTDATA11
,EFTDATA12
,EFTDATA13
,EFTDATA14
,EFTDATA15
,EFTDATA16
,EFTDATA17
,EFTDATA18
,EFTDATA19
,EFTDATABSMER
,EFTDATABSCUST
,RowNo
,_BatchId
FROM Stag.Prism_TENDER_GIFT_CARD;
TRUNCATE TABLE Stag.Prism_TENDER_GIFT_CARD;
--TRUNCATE TABLE Stag.Prism_CURRENCY;
--TRUNCATE TABLE Stag.Prism_PRICE_LEVEL;
--TRUNCATE TABLE Stag.Prism_STORE;
--TRUNCATE TABLE Stag.Prism_SUBSIDIARY;

----------------------------------------------------------------------------------------------------

END