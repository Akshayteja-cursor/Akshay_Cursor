﻿CREATE TABLE [dbo].[Customer] (
    [CustomerName]         NVARCHAR (255) NULL,
    [CustomerNumber]       NVARCHAR (255) NULL,
    [PDUCode]              NVARCHAR (255) NULL,
    [IntPupMaster]         INT            NULL,
    [CustomerOrganisation] INT            NULL,
    [Country]              VARCHAR (150)  NULL,
    [ISOCurrency]          VARCHAR (200)  NULL
);

