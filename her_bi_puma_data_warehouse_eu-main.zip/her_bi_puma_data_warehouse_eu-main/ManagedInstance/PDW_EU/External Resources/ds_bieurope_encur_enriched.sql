﻿CREATE EXTERNAL DATA SOURCE [ds_bieurope_encur_enriched]
    WITH (
    LOCATION = N'adls://enriched@bieuropeprdencur.blob.core.windows.net'
    );

