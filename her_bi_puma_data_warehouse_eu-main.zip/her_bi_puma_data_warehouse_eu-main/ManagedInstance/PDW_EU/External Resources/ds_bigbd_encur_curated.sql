﻿CREATE EXTERNAL DATA SOURCE [ds_bigbd_encur_curated]
    WITH (
    LOCATION = N'adls://curated@bigbdprdencur.blob.core.windows.net'
    );

