﻿CREATE EXTERNAL DATA SOURCE [ds_bieurope_encur_curated]
    WITH (
    LOCATION = N'adls://curated@bieuropeprdencur.blob.core.windows.net'
    );

