use catalog identifier(:catalog);


CREATE OR REPLACE VIEW s3_gold.fact_inventory_reorder_target_stock_peg AS

WITH plant_mat AS (

    SELECT
        MaterialNumber
        ,StoreCode                                                      AS Plant
        ,CompanyCode
        ,ReorderPoint
        ,TargetStock
        ,CONCAT(MaterialNumber, '|', CompanyCode)                       AS NatArticle_BK
        ,REPLACE(LEFT(MaterialNumber, 9), '-', ' ')                     AS ArticleNumber_BK
        ,REPLACE(MaterialNumber, '-', ' ')                              AS ArticleSize_BK
        ,LEFT(MaterialNumber, 6)                                        AS StyleNumber_BK
    FROM (
        SELECT
            MaterialNumber
            ,StoreCode
            ,CompanyCode
            ,ReorderPoint
            ,TargetStock
            ,ROW_NUMBER() OVER (
                PARTITION BY MaterialNumber, StoreCode
                ORDER BY _ldts DESC
            ) AS RN
        FROM eu_erp_dev.s2_silver.plantmaterialmaster
    ) ranked
    WHERE RN = 1
      AND CompanyCode = 'DE11'
      AND (ReorderPoint <> 0 OR TargetStock <> 0)
)

SELECT
    pm.NatArticle_BK
    ,pm.Plant
    ,pm.ArticleNumber_BK
    ,pm.ArticleSize_BK

    ,mat.brand_code                                                     AS BrandCode
    ,mat.business_segment_code                                          AS BusinessSegmentCode
    ,p.gsm_code                                                         AS NatStoreDC_BK
    ,'PLPEGLE'                                                          AS PDUCode
    ,mat.product_division_code                                          AS ProdDivCode
    ,CAST(NULL AS STRING)                                               AS ProductCreationModelCode  -- not in dim_materials
    ,1425                                                               AS PupMasterId
    ,mat.reporting_business_unit_code                                   AS RBUCode
    ,mat.age_grp_code                                                   AS RepAgeGroupCode
    ,mat.gender_code                                                    AS RepGenderCode
    ,pm.StyleNumber_BK
    ,pm.ReorderPoint                                                    AS `Reorder Point`
    ,pm.TargetStock                                                     AS `Target Stock`

FROM plant_mat pm
LEFT JOIN eu_erp_dev.s2_silver.dim_plants p
    ON  p.store_code = pm.Plant
LEFT JOIN eu_erp_dev.s2_silver.dim_materials mat
    ON  mat.material_number = pm.MaterialNumber;
