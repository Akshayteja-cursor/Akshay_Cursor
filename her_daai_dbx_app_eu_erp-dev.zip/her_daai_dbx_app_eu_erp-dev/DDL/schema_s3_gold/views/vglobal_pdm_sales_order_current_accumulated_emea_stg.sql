USE CATALOG IDENTIFIER(:catalog);


create or replace view s3_gold.vglobal_pdm_sales_order_current_accumulated_emea
as
SELECT
    trans.article_type_code              AS ArticleNumber_BK,
    trans.brand_code                     AS BrandCode,
    trans.reporting_business_unit_code   AS RBUCode,
    trans.date_on_which_record_was_created AS SOCreationDate,
    trans.currency_code                  AS CurrencyCode,
    dcust.cust_bus_class_code        AS CustomerBusinessClassCode,
    CASE
        WHEN trans.company_code IN ('IT10', 'ES10', 'PT10')
        THEN REPLACE(trans.nat_sold_to_party, 'PT10', 'ES10')
        ELSE trans.nat_sold_to_party
    END        
 AS NatCustomer_BK,
    CAST(
    CASE 
        WHEN trans.so_status_code = 2
             AND NULLIF(trans.rejection_date, DATE '1900-01-01') IS NOT NULL
        THEN trans.rejection_date
        ELSE trans.delivery_date  
    END
AS TIMESTAMP)AS DeliveryDate,
    trans.gross_value                    AS GrossValueLC,
    trans.invoiced_sales_value           AS InvoicedSalesValueLC,
    trans.off_invoice_sales_value        AS OffInvoiceSalesValueLC,
    trans.pdu_code                       AS PDUCode,
    pr.int_so_price_type_code            AS IntSOPriceTypeCode,
    art.InitialProductCreationModelCode  AS ProductCreationModelCode,
    trans.product_division_code          AS ProdDivCode,
    trans.int_put_pup_master_id          AS IntPupMasterId,
    art.ReportingAgeGroupCode            AS RepAgeGroupCode,
    art.ReportingGenderCode              AS RepGenderCode,
    trans.sales_rep                      AS NatSalesman_BK,
    trans.so_status_code                 AS SOStatusCode,
    st.int_sales_type                      AS IntSalesType,
    trans.sales_unit                     AS Qty,
    CASE
        WHEN trans.company_code IN ('IT10', 'ES10', 'PT10')
             AND length(trans.plant) >= 4
        THEN concat(
                 regexp_replace(substr(trans.plant, 1, length(trans.plant) - 4), '[|]', ''),
                 'EU'
             )
        ELSE trans.plant
    END                                  AS NatStoreDC_BK,
    trans.style_number                 AS StyleNumber_BK

    
    -- EUROPE Extension (Databricks version)
    , trans.is_finance_ooh                    AS IsFinanceOOH
    , canc.int_cancel_reason_code           AS IntCancelReasonCode
    , canc.mapping_desc as IntCancelReasonDesc
    , trans.so_status_desc                 AS SOStatusDesc
    , trans.sales_document_type_text     AS NatSOTypeDesc
    , trans.sales_order                  AS NatSalesOrderNo
    , trans.sales_order_item             AS NatSalesOrderItemNo
    , trans.sales_season                  AS SalesSeason
   -- , trans.invoiced_sales                 AS InvoiceQty
    , CAST(trans.invoiced_sales AS DECIMAL(18,2)) AS InvoiceInvoicedSalesValueLC
    , trans.invoice                      AS InvoiceNo
    , trans.invoice_item_number          AS InvoiceItemNo
    , deliverydate                          AS InvoicePostingDate
    , trans.sales_order_satatus_code_ly AS SalesOrderStatusCodeLY
    , trans.OrderEntrySystem             AS OrderEntrySystem
    , trans.Delivery              AS DeliveryNoteQty
    
FROM s3_gold.fact_otc_model trans
LEFT JOIN mdm_stg.article_info.dim_articles_season_independent art
    ON trans.article_type_code = art.ArticleNumber_BK

left join s3_gold.dim_natcustomers dcust 
    on trans.nat_sold_to_party = dcust.dim_customer_pk

LEFT JOIN s2_silver.s4hana_so_price_types pr
    ON trans.sales_document_type_text = pr.so_type_code
LEFT JOIN s2_silver.s4hana_salestypes st
    ON trans.sales_document_type_text = st.so_type_code
LEFT JOIN s2_silver.s4hana_cancel_reasons canc
    ON trans.rejection_reason = canc.ebp_indicator
WHERE trans.company_code IN ('IT10','ES10','PT10','DE19','AT19','NL19','BE19','CH19','FR10')
;