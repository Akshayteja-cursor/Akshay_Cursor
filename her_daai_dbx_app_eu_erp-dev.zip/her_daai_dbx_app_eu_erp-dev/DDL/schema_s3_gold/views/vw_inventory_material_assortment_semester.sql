-- View: vw_material_assortment_semester
-- Purpose: Provides FirstAssortment and LatestAssortment per material per company
--          sourced from materialsalesattributes joined with s4hana_interfaces
-- Usage:   Power BI joins this view with fact_inventory_snapshot_bridge_eu ON MATERIAL + CompanyCode
-- Source:  Matches Synapse proc S4Hana_spProvNatActiclesLast logic
-- Note:    the join can be made based on MATERIAL + CompanyCode since the relationship between sales org and company code is 1:1
--          the original procedure is filtering based on some hardcoded sales org - we took that filter out
use catalog identifier(:catalog);

CREATE OR REPLACE VIEW s3_gold.vw_inventory_material_assortment_semester AS
SELECT
      X.MATERIAL
    , X.IntPupMasterId
    , X.PDUCode
    , x.CompanyCode
    , MAX(X.FirstAssortment)    AS FirstAssortment
    , MAX(X.LatestAssortment)   AS LatestAssortment
FROM (
    SELECT 
          A.Product MATERIAL
        , A.ProductSalesOrg SalesOrgCode
        , A.ProductDistributionChnl DistChannelCode
        , A.FirstAssortment
        , A.LatestAssortment
        , b.company_code CompanyCode
        , C.int_put_pup_master_id IntPupMasterId
        , C.pdu_code PDUCode
    FROM s2_silver.materialsalesattributes A
    INNER JOIN s2_silver.dim_sales_org_to_company_code B 
            ON A.ProductSalesOrg = B.Code
    INNER JOIN s2_silver.s4hana_interfaces C 
            ON B.company_code = C.company_code
    
    QUALIFY ROW_NUMBER() OVER (
                PARTITION BY A.Product, A.ProductSalesOrg
                ORDER BY CASE WHEN A.ProductDistributionChnl = '40' THEN '00'
                              ELSE A.ProductDistributionChnl END
           ) = 1
) X
GROUP BY
   all
;