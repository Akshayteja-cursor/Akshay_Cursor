use catalog identifier(:catalog);

CREATE OR REPLACE VIEW s3_gold.fact_inventory_free_to_allocate_peg AS 

WITH prov_inventory AS
(
    SELECT
        company_code,
        material,
        plant,
        MIN(storage_location) AS storage_location,
        MAX(stock_segment) AS stock_segment
    FROM s2_silver.fn_agg_fact_material_movements(current_timestamp())
    WHERE company_code = 'DE11'
    GROUP BY
        company_code,
        material,
        plant
)

SELECT
    CONCAT(TRIM(DM.style_number), ' ', TRIM(DM.color_number)) AS ArticleNumber_BK,
    CONCAT(TRIM(DM.style_number),' ',TRIM(DM.color_number),' ',TRIM(COALESCE(DM.size_number, '0'))) AS ArticleSize_BK,
    DM.brand_code                                 AS BrandCode,
    10                                            AS BusinessClassCode,
    DM.business_segment_code                     AS BusinessSegmentCode,
    2                                             AS BusinessTypeCode,
    20                                            AS InventoryStatusCode,
    CONCAT(FAI.material_number, '|DE11')          AS NatArticle_BK,
    CASE
    WHEN TRIM(DP.plant_category_code) = 'A'
        THEN CONCAT(TRIM(FAI.plant), '|EU')

    WHEN COALESCE(TRIM(FAI.stock_segment), '') = ''
        THEN CONCAT(TRIM(FAI.plant), '|EU')

    ELSE CONCAT(
            TRIM(FAI.plant),
            '_',
            TRIM(FAI.stock_segment),
            '|EU'
         )
END AS NatStoreDC_BK,
 

        CONCAT(
    CASE
        WHEN TRIM(DP.plant_category_code) = 'A'
            THEN CONCAT(TRIM(FAI.plant), '|EU')

        WHEN COALESCE(TRIM(FAI.stock_segment), '') = ''
            THEN CONCAT(TRIM(FAI.plant), '|EU')

        ELSE CONCAT(
            TRIM(FAI.plant),
            '_',
            TRIM(FAI.stock_segment),
            '|EU'
        )
    END,
    '|',
    TRIM(COALESCE(SHPIF.storage_location, '')),
    '|',
    TRIM(COALESCE(SHPIF.stock_segment, ''))
) AS NatStoreDC_Location_Segment_BK,

    'PLPEGLE' AS PDUCode,
    CASE
        WHEN DM.retail_dcsdep_code IN ('31','32','33','34')AND DM.product_division_code = '2' THEN 3
        ELSE CAST(DM.product_division_code AS INT) END AS ProdDivCode,
    null                                          as ProductCreationModelCode,  -- Column NA, Need to fix later
    --ART.IntProdCreationModelCode AS ProductCreationModelCode,   -- Column NA, Need to fix later
    SHI.int_put_pup_master_id AS PupMasterId,
    COALESCE(TRY_CAST(DM.reporting_business_unit_code AS INT), 0) AS RBUCode, 
    COALESCE(DM.age_grp_code, 0)                 AS ReportingAgeGroupCode,   
    COALESCE(DM.gender_code, 0)                  AS ReportingGenderCode,  
    NULL                                          AS SalesZoneCode,
    CASE
        WHEN TRY_CAST(DM.style_number AS INT) IS NOT NULL THEN LPAD(CAST(TRY_CAST(DM.style_number AS INT) AS STRING), 6, '0')
        ELSE '000000' END                         AS StyleNumber_BK,

    FAI.available_inventory_id                    AS AvailableInventoryID,
    FAI.plant                                     AS Plant,
    FAI.material_number                           AS MaterialNumber,
    FAI.stock_segment                             AS StockSegment,
    CAST(FAI.valuated_unrestricted_use_stock AS DOUBLE) AS ValuatedUnrestrictedUseStock,
    CAST(FAI.available_quantity AS DOUBLE)       AS AvailableQuantity,
    FAI.unit_of_measure                          AS UnitOfMeasure,
    FAI._ldts                                    AS SnapshotDate

FROM s2_silver.dim_free_available_inventory FAI
LEFT JOIN s2_silver.dim_materials DM
    ON FAI.material_number = DM.material_number
INNER JOIN s2_silver.dim_plants DP
    ON FAI.plant = DP.store_code
INNER JOIN s2_silver.s4hana_interfaces SHI
    ON SHI.company_code = 'DE11'
    AND SHI.interface = 'EBP'
    ---logic from  S4Hana_ProvInventoriesFinal 
LEFT JOIN prov_inventory SHPIF
    ON FAI.material_number = SHPIF.material
    AND FAI.plant = SHPIF.plant
    AND SHPIF.company_code = 'DE11'
WHERE 
FAI.stock_segment <> 'WHS';