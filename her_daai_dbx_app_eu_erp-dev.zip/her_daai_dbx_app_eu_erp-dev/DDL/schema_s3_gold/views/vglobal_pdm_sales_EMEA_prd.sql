USE CATALOG IDENTIFIER(:catalog);

create or replace view s3_gold.vglobal_pdm_sales_EMEA
as
SELECT
  trans.article_number_bk     AS ArticleNumber_BK,
  trans.article_size_bk       AS ArticleSize_BK,
  trans.brand_code            AS BrandCode,
  trans.business_segment_code AS BusinessSegmentCode,
  trans.business_type_code    AS BusinessTypeCode,
  trans.rbu_code              AS RBUCode,
  NULL                        AS CRPSalesAmountLC,
  'n/a'                       AS CreditNoteReasonDesc,
  trans.currency_code         AS CurrencyCode,
  CASE
    WHEN trans.natcustomer_bk = ''
      OR trans.natcustomer_bk LIKE 'IT01|%'
      OR trans.natcustomer_bk LIKE 'ES01|%'
    THEN trans.business_class_code
    ELSE CAST(trans.natcustomer_cust_bus_class_code AS STRING)
  END                         AS CustomerBusinessClassCode,
  trans.natcustomer_bk        AS NatCustomer_BK,
  NULL                        AS DiscountReason,
  trans.doc_type_code         AS DocTypeCode,
  trans.gross_sales_lc        AS GrossValueLC,
  NULL                        AS GSMStoreCode,
  ityp.int_rec_type_code         AS IntRecTypeDesc,
  trans.posting_date          AS InvoicePostingDate,
  trans.cogs_at_landed_cost_lc * -1 AS LandedCostCombLC,
  NULL AS LineDiscountLC,
  trans.net_sales_lc AS NetSalesLC,
  trans.invoiced_sales_lc AS NetValueLC,
  trans.off_invoice_sales AS OffInvoiceSales,
  trans.pdu_code AS PDUCode,
  pr.int_invoice_price_type_code AS PriceTypeCode,
  art.ProductCreationModelCode AS ProductCreationModelCode,
  trans.product_division_code AS ProductDivisionCode, 
  trans.int_pup_master_id AS IntPupMasterId,
  art.ReportingAgeGroupCode AS RepAgeGroupCode,
  art.ReportingGenderCode AS RepGenderCode,
  trans.invoiced_sales_units AS SalesUnits,
  LPAD(CAST(trans.style_number_bk AS STRING), 6, '0') AS StyleNumber_BK,
  '' AS TimeOfDayCode,
  '' AS TransactionNumber,
  '' AS WorkstationNumber,
  'EBP' AS Source,
  trans.currency_code AS ArticleCurrencyCode,
  trans.company_code AS CompanyCode,
  NULL AS ArtLandedCostLC,
  trans.cogs_at_landed_cost_lc * -1 AS LandedCostLC
FROM s3_gold.fact_copa_invoice_sales AS trans
left join mdm_prd.article_info.dim_articles_season_independent art on trans.article_number_bk=art.ArticleNumber_BK
LEFT JOIN s2_silver.s4hana_invoice_price_types  AS pr
  ON trans.natinvoice_type_code = pr.nat_invoice_type_code
LEFT JOIN s2_silver.s4hana_invoice_rec_types AS ityp
  ON trans.natinvoice_type_code = ityp.ebp_indicator
WHERE
  (
    (trans.company_code IN ('DE19', 'AT19', 'NL19', 'BE19', 'CH19') AND trans.creation_date >= DATE '2025-08-01')
    OR
    (trans.company_code = 'FR10' AND (trans.creation_date >= DATE '2024-04-01' OR trans.posting_date >= DATE '2024-04-01'))
    OR
    (trans.company_code IN ('IT10', 'ES10', 'PT10') AND trans.business_class_code <> 50)
  );
