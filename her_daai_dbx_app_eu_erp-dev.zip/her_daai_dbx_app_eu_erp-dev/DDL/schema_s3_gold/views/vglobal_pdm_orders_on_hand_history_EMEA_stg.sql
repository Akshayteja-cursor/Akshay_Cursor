USE CATALOG IDENTIFIER(:catalog);


create or replace view s3_gold.vglobal_pdm_orders_on_hand_history_EMEA
as
SELECT
  currency_code                 AS ArticleCurrencyCode,
  article_type_code             AS ArticleNumber_BK,
  art.SeasonCode_BK             AS AssignedSeasonCode,
  brand_code                    AS BrandCode,
  1                             AS BusinessTypeCode,
  reporting_business_unit_code  AS RBUCode,
  currency_code                 AS CurrencyCode,
  cust_bus_class_code           AS CustomerBusinessClassCode,
  nat_sold_to_party             AS NatCustomer_BK,
  delivery_date                 AS DeliveryDate,
  is_finances_ooh               AS IsFinanceOOH,
  ooh_landed_cost               AS OOHLandedCostValueLC,
  snapshot_date                 AS OOHDate,
  ooh_gross_value               AS OOHGrossValueLC,
  ooh_invoiced_value            AS OOHNetValueLC,
  ooh_net_sales_value           AS OOHOffInvoicedSales,
  ooh_units                     AS OOHUnits,
  'ERP System'                  AS OrderEntrySystem,
  pdu_code                      AS PDUCode,
  0                             AS PriceTypeCode,
  art.ProductCreationModelCode  AS ProductCreationModelCode,
  product_division_code         AS ProdDivCode,
  int_put_pup_master_id         AS IntPupMasterId,
  art.ReportingAgeGroupCode     AS RepAgeGroupCode,
  art.ReportingGenderCode       AS RepGenderCode,
  0                             AS SalesmanCode,
  int_sales_type                AS IntSalesType,
  style_number                  AS StyleNumber_BK,
  0                             AS NatStoreDC_BK,
  art.BusinessSegmentCode       AS BusinessSegmentCode,
  company_code                  AS CompanyCode,
  NULL                          AS CreationDate
FROM s3_gold.fact_ooh_snapshot_by_calendar as ooh
left join mdm_stg.article_info.dim_articles_season_independent art on ooh.article_type_code=art.ArticleNumber_BK
  WHERE   snapshot_date >= '2026-04-17' 
    AND company_code IN ('IT10','ES10','PT10','DE19','AT19','NL19','BE19','CH19','FR10')
    ;
