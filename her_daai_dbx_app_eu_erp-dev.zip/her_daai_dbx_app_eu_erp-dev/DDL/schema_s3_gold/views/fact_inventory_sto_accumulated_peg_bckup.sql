-- use catalog identifier(:catalog);
use catalog eu_erp_dev;

-- s3_gold.fact_inventory_sto_accumulated_peg
-- PEG National Stock Transfer Orders (accumulated) compatibility view.
-- Mimics the old PEG NatStockTransferOrdersCurrent query, remapped to our
-- silver PO / delivery / movement tables. Grain: PO + PO item (schedule lines,
-- delivery items and movements are pre-aggregated to that grain to avoid
-- fan-out). Scoped to STO purchase orders for company DE11 (PEG).
-- Owner: Konka Akshay Teja | JIRA: UDPEBP-318

CREATE OR REPLACE VIEW s3_gold.fact_inventory_sto_accumulated_peg AS

WITH sched_agg AS (
    -- Schedule lines summed up to PO-item grain.
    SELECT
        purchase_order,
        purchase_order_item,
        SUM(goods_received_quantity)  AS rough_goods_receipt_qty,
        SUM(sto_delivery_quantity)    AS sto_delivery_qty,
        MIN(delivery_date)            AS delivery_date,
        MAX(goods_receipt_end_date)   AS goods_receipt_end_date,
        MIN(goods_issue_date)         AS goods_issue_date
    FROM s2_silver.fact_po_schedule_lines
    GROUP BY purchase_order, purchase_order_item
),

deliv_agg AS (
    -- Delivery items (with header for type/dates) aggregated to the PO item
    -- they reference. Clean-key link: delivery_item -> PO via reference doc.
    SELECT
        di.document_number_of_the_reference_document  AS purchase_order,
        di.item_number_of_the_reference_item          AS purchase_order_item,
        SUM(di.actual_quantity_delivered_in_stockkeeping_units) AS del_shipped_qty,
        SUM(di.original_quantity_of_delivery_item)    AS del_outbound_qty,
        MIN(dh.planned_goods_movement_date)           AS del_min_planned_gi_date,
        MAX(dh.planned_goods_movement_date)           AS del_max_planned_gi_date,
        MIN(dh.actual_goods_movement_date)            AS del_min_actual_gi_date,
        MAX(dh.actual_goods_movement_date)            AS del_max_actual_gi_date,
        MIN(dh.delivery_date)                         AS del_min_planned_delivery_date,
        MAX(dh.delivery_date)                         AS del_max_planned_delivery_date,
        CONCAT_WS(',', COLLECT_SET(di.delivery))      AS del_note_numbers
    FROM s2_silver.fact_delivery_item di
    LEFT JOIN s2_silver.fact_delivery_header dh
        ON dh.delivery = di.delivery
    WHERE COALESCE(dh.document_deletion_indicator, '') = ''
      AND di.reference_document_category = 'V'   -- reference is a purchase order
    GROUP BY
        di.document_number_of_the_reference_document,
        di.item_number_of_the_reference_item
),

mvmt_agg AS (
    -- Goods movements aggregated to PO item. Receipts (101/102) minus their
    -- reversals give net received; unrestricted stock only (stock type '06').
    SELECT
        purchase_order,
        purchase_order_item,
        SUM(CASE WHEN goods_movement_type IN ('101') THEN quantity
                 WHEN goods_movement_type IN ('102') THEN -quantity
                 ELSE 0 END)                          AS inv_goods_receipt_qty,
        MIN(CASE WHEN goods_movement_type IN ('101','102') THEN posting_date END) AS inv_min_gr_date,
        MAX(CASE WHEN goods_movement_type IN ('101','102') THEN posting_date END) AS inv_max_gr_date
    FROM s2_silver.fact_material_movements
    WHERE inventory_stock_type = '06'
      AND purchase_order IS NOT NULL
      AND goods_movement_type IN ('101','102')
    GROUP BY purchase_order, purchase_order_item
),

retail_price AS (
    SELECT
        article_number_bk,
        validity_start_date,
        validity_end_date,
        price    AS rrp
    FROM s3_gold.dim_retail_price_901
    WHERE COALESCE(release_status, '')    = ''
      AND COALESCE(processing_status, '') = ''
      AND sales_organisation = '6000'
      AND is_generic_material = true
)

SELECT
    -- PO / item identifiers
    h.purchase_order                          AS PONo,
    i.purchase_order_item                     AS POItemNo,
    h.po_type_code                            AS POTypeCode,
    CAST(CASE
        WHEN COALESCE(h.deletion_code, i.deletion_code) IS NOT NULL
             AND COALESCE(h.deletion_code, i.deletion_code) <> '' THEN 3
        WHEN i.is_completely_delivered = 'X' THEN 1
        ELSE 2 END AS INT)                    AS POStatusCode,
    h.company_code                            AS CompanyCode,
    intf.pdu_code                             AS PDUCode,
    intf.int_put_pup_master_id                AS IntPupMasterId,
    h.currency_code                           AS CurrencyCode,

    -- Store keys (sender = supplying plant, receiver = item site) -> |EU,
    -- DC-type 60 remaps to GSM code, same pattern as the InventoryHistory view.
    CASE WHEN nsd_s.int_dc_type_code = 60 THEN nsd_s.gsm_code
         ELSE CONCAT(h.supplying_plant, '|EU') END          AS NatStoreDCSender_BK,
    CASE WHEN nsd_r.int_dc_type_code = 60 THEN nsd_r.gsm_code
         ELSE CONCAT(i.site_code, '|EU') END                AS NatStoreDCReceiver_BK,

    h.creation_date                           AS CreationDate,
    i.is_completely_delivered                 AS IsCompletelyDelivered,

    -- Article keys / attributes
    CONCAT(i.material_number, '|',
           CASE WHEN h.company_code = 'PT10' THEN 'ES10' ELSE h.company_code END) AS NatArticle_BK,
    i.ean                                     AS EANNo,
    COALESCE(TRY_CAST(mat.style_number AS INT), 0) AS StyleNumber_BK,
    CONCAT(TRIM(mat.style_number), ' ', TRIM(mat.color_number)) AS ArticleNumber_BK,
    mat.brand_code                            AS BrandCode,
    CAST(CASE WHEN mat.retail_dcsdep_code IN ('31','32','33','34')
                   AND mat.product_division_code = '2' THEN '3'
              ELSE mat.product_division_code END AS INT) AS ProductDivisionCode,
    COALESCE(TRY_CAST(mat.reporting_business_unit_code AS INT), 0) AS RBUCode,

    -- Quantities (order at item; schedule / delivery / movement aggregated)
    i.order_quantity                          AS OrderQuantity,
    sa.rough_goods_receipt_qty                AS RoughGoodsReceiptQuantity,
    i.stock_segment                           AS StockSegment,
    i.material_base_unit                      AS UnitOfMeasure,

    sa.delivery_date                          AS DeliveryDate,
    ma.inv_goods_receipt_qty                  AS InvGoodsReceiptQty,
    ma.inv_min_gr_date                        AS InvMinGoodsReceiptDate,
    ma.inv_max_gr_date                        AS InvMaxGoodsReceiptDate,

    da.del_min_planned_delivery_date          AS DelNoteMinPlannedDeliveryDate,
    da.del_max_planned_delivery_date          AS DelNoteMaxPlannedDeliveryDate,
    da.del_min_actual_gi_date                 AS DelNoteMinPostGoodsIssueDate,
    da.del_max_actual_gi_date                 AS DelNoteMaxPostGoodsIssueDate,
    da.del_outbound_qty                       AS DelNoteOutboundQty,
    da.del_shipped_qty                        AS DelNoteShippedQty,
    da.del_note_numbers                       AS DelNoteNumbers,
    da.del_shipped_qty                        AS ShippedUnits,

    -- In-transit = shipped but not yet received (floored at zero)
    GREATEST(COALESCE(da.del_shipped_qty, 0) - COALESCE(ma.inv_goods_receipt_qty, 0), 0) AS InTransit,

    -- Backlog = ordered but not completely delivered (0 once delivered/deleted)
    CAST(CASE
        WHEN i.is_completely_delivered = 'X' THEN 0
        WHEN COALESCE(h.deletion_code, i.deletion_code) <> '' THEN 0
        ELSE GREATEST(COALESCE(i.order_quantity, 0) - COALESCE(da.del_shipped_qty, 0), 0)
    END AS DECIMAL(13,3))                     AS Backlog,

    -- Retail-price measures (German VAT 19% -> excl factor 1/1.19)
    rp.rrp                                                   AS RRP_incl_VAT,
    rp.rrp * 0.840336134                                    AS RRP_excl_VAT,
    rp.rrp * COALESCE(i.order_quantity, 0)                  AS GrossValue,
    rp.rrp * 0.840336134 * COALESCE(i.order_quantity, 0)   AS NetRRP

FROM s2_silver.fact_po_header h
INNER JOIN s2_silver.fact_po_item i
    ON  i.purchase_order = h.purchase_order
LEFT JOIN sched_agg sa
    ON  sa.purchase_order = i.purchase_order
    AND sa.purchase_order_item = i.purchase_order_item
LEFT JOIN deliv_agg da
    ON  da.purchase_order = i.purchase_order
    AND da.purchase_order_item = i.purchase_order_item
LEFT JOIN mvmt_agg ma
    ON  ma.purchase_order = i.purchase_order
    AND ma.purchase_order_item = i.purchase_order_item
LEFT JOIN s2_silver.s4hana_interfaces intf
    ON  intf.company_code = h.company_code
    AND intf.interface = 'EBP'
LEFT JOIN s2_silver.dim_materials mat
    ON  mat.material_number = i.material_number
LEFT JOIN s2_silver.peg_natstoredcs nsd_s
    ON  nsd_s.natstoredc_bk = CONCAT(h.supplying_plant, '|EU')
LEFT JOIN s2_silver.peg_natstoredcs nsd_r
    ON  nsd_r.natstoredc_bk = CONCAT(i.site_code, '|EU')
LEFT JOIN retail_price rp
    ON  rp.article_number_bk = CONCAT(TRIM(mat.style_number), ' ', TRIM(mat.color_number))
    AND h.creation_date BETWEEN rp.validity_start_date AND rp.validity_end_date
WHERE h.po_sub_type = 'T'
  AND h.company_code = 'DE11'
;
