use catalog identifier(:catalog);


CREATE OR REPLACE VIEW s3_gold.fact_inventory_sto_accumulated_peg AS

WITH po_type_desc AS (
    SELECT * FROM VALUES
        ('ZALL','Allocation Order'), ('ZBIN','Binding Date Order'),
        ('ZRPL','Rplsmnt Orders'),   ('ZRSH','Rush Orders'),
        ('ZSTO','Store Transfer Order'), ('ZUDR','Under/Over Shipment'),
        ('ZCSB','Caselot Binding STO'),  ('ZCSL','Caselot Alloc. STO'),
        ('ZCSR','Caselot Rush STO'),     ('ZCLR','Clearance STO'),
        ('ZPRE','Pre-Pack Orders STO'),  ('ZIN1','Intra Company STO')
    AS t(po_type_code, po_type_desc)
),

closed_store_map AS (
    SELECT * FROM VALUES
        ('1158','1280'), ('1160','1278'), ('1162','1282'), ('1174','1246')
    AS t(store_code_old, store_code_new)
),

sched_agg AS (
    SELECT
        purchase_order,
        purchase_order_item,
        SUM(goods_received_quantity)  AS rough_goods_receipt_qty,
        MAX(delivery_date)            AS delivery_date
    FROM s2_silver.fact_po_schedule_lines
    GROUP BY purchase_order, purchase_order_item
),

deliv_agg AS (
    SELECT
        di.document_number_of_the_reference_document  AS purchase_order,
        di.item_number_of_the_reference_item          AS purchase_order_item,
        SUM(CASE WHEN di.goods_movement_status = 'C'
                 THEN di.actual_quantity_delivered_in_stockkeeping_units END) AS del_shipped_qty,
        SUM(CASE WHEN COALESCE(di.process_status, '') <> ''
                 THEN di.actual_quantity_delivered_in_stockkeeping_units END) AS del_picking_qty,
        SUM(di.actual_quantity_delivered_in_stockkeeping_units) AS del_outbound_qty,
        MIN(dh.planned_goods_movement_date)           AS del_min_planned_gi_date,
        MAX(dh.planned_goods_movement_date)           AS del_max_planned_gi_date,
        MIN(dh.actual_goods_movement_date)            AS del_min_actual_gi_date,
        MAX(dh.actual_goods_movement_date)            AS del_max_actual_gi_date,
        CONCAT_WS(', ', COLLECT_SET(di.delivery))     AS del_note_numbers
    FROM s2_silver.fact_delivery_item di
    LEFT JOIN s2_silver.fact_delivery_header dh
        ON dh.delivery = di.delivery
    WHERE COALESCE(dh.document_deletion_indicator, '') = ''
      AND di.reference_document_category = 'V'
      AND dh.delivery_type IN
          ('ZBIN','ZECI','ZINT','ZRPL','ZRSH','ZSTO','ZUDR','ZST1','ZPRE','ZIN1')
    GROUP BY
        di.document_number_of_the_reference_document,
        di.item_number_of_the_reference_item
),

mvmt_agg AS (
    -- Receipts (101/102) and STO issues (641/642/647/648), signed by
    -- debit/credit, unrestricted stock only. 641-specific passthroughs for
    SELECT
        purchase_order,
        purchase_order_item,
        SUM(CASE WHEN goods_movement_type IN ('101','102')
                 THEN goods_receipt_qty_in_order_unit
                      * CASE WHEN debit_credit_code = 'S' THEN -1 ELSE 1 END
            END)                                       AS inv_goods_receipt_qty,
        SUM(CASE WHEN goods_movement_type IN ('641','642','647','648')
                 THEN goods_receipt_qty_in_order_unit
                      * CASE WHEN debit_credit_code = 'S' THEN 1 ELSE -1 END
            END)                                       AS shipped_units,
        MIN(CASE WHEN goods_movement_type IN ('101','102') THEN posting_date END) AS inv_min_gr_date,
        MAX(CASE WHEN goods_movement_type IN ('101','102') THEN posting_date END) AS inv_max_gr_date,
        SUM(CASE WHEN goods_movement_type = '641' AND debit_credit_code = 'S'
                 THEN total_goods_mvt_amt_in_cc_crcy END)                         AS mvmt_641_amount,
        MAX(CASE WHEN goods_movement_type = '641' AND debit_credit_code = 'S'
                 THEN material_document END)                                      AS mvmt_641_material_document,
        MAX(CASE WHEN goods_movement_type = '641' AND debit_credit_code = 'S'
                 THEN reference_document END)                                     AS mvmt_641_reference_document,
        MAX(CASE WHEN goods_movement_type = '641' AND debit_credit_code = 'S'
                 THEN plant END)                                                  AS mvmt_641_plant,
        MAX(CASE WHEN goods_movement_type = '641' AND debit_credit_code = 'S'
                 THEN 1 ELSE 0 END)                                               AS has_641
    FROM s2_silver.fact_material_movements
    WHERE inventory_stock_type = '06'
      AND purchase_order IS NOT NULL
      AND goods_movement_type IN ('101','102','641','642','647','648')
    GROUP BY purchase_order, purchase_order_item
),

retail_price AS (
    SELECT
        article_number_bk,
        validity_start_date,
        validity_end_date,
        price    AS rrp
    FROM s3_gold.dim_retail_price_901
    WHERE COALESCE(release_status, '')    = ''
      AND COALESCE(processing_status, '') = ''
      AND sales_organisation = '6000'
      AND is_generic_material = true
)

SELECT
    h.purchase_order                          AS NatPurchaseOrderNo,
    i.purchase_order_item                     AS NatPurchaseOrderItemNo,
    h.company_code                            AS CompanyCode,
    intf.int_put_pup_master_id                AS IntPupMasterId,
    intf.pdu_code                             AS PDUCode,
    h.po_type_code                            AS NatPOTypeCode,
    ptd.po_type_desc                          AS NatPOTypeDesc,
    CAST(CASE
        WHEN COALESCE(h.deletion_code, i.deletion_code) IS NOT NULL
             AND COALESCE(h.deletion_code, i.deletion_code) <> '' THEN 3
        WHEN i.is_completely_delivered = 'X' THEN 1
        ELSE 2 END AS INT)                    AS POStatusCode,
    h.currency_code                           AS CurrencyCode,
    CASE WHEN TRY_CAST(REPLACE(i.material_number, '-', '') AS BIGINT) IS NOT NULL
         THEN REPLACE(i.material_number, '-', ' ')
         ELSE '000000 00 0' END               AS MatNr,
    COALESCE(cs_s.store_code_new, h.supplying_plant)  AS NatStoreDCSender_BK,
    nsd_s.natstoredc_name                     AS NatStoreDCNameSender,
    COALESCE(cs_r.store_code_new, i.site_code)        AS NatStoreDCReceiver_BK,
    nsd_r.natstoredc_name                     AS NatStoreDCNameReceiver,
    h.creation_date                           AS POCreationDate,
    CAST(CASE WHEN COALESCE(i.is_completely_delivered, '') <> '' THEN 1 ELSE 0 END AS BOOLEAN)
                                              AS IsCompletelyDelivered,
    i.ean                                     AS EAN,
    COALESCE(TRY_CAST(mat.style_number AS INT), 0) AS StyleNumber_BK,
    CONCAT(TRIM(mat.style_number), ' ', TRIM(mat.color_number)) AS ArticleNumber_BK,
    COALESCE(TRY_CAST(mat.reporting_business_unit_code AS INT), 0) AS RBUCode,
    mat.brand_code                            AS BrandCode,
    CAST(CASE WHEN mat.retail_dcsdep_code IN ('31','32','33','34')
                   AND mat.product_division_code = '2' THEN '3'
              ELSE mat.product_division_code END AS INT) AS ProdDivCode,
    i.order_quantity                          AS Qty,
    sa.rough_goods_receipt_qty                AS RoughGoodsReceiptQty,
    sa.delivery_date                          AS DeliveryDate,
    da.del_min_planned_gi_date                AS DelNoteMinPlannedDeliveryDate,
    da.del_max_planned_gi_date                AS DelNoteMaxPlannedDeliveryDate,
    da.del_min_actual_gi_date                 AS DelNoteMinPostGoodsIssueDate,
    da.del_max_actual_gi_date                 AS DelNoteMaxPostGoodsIssueDate,
    da.del_outbound_qty                       AS DelNoteOutboundQty,
    da.del_picking_qty                        AS DelNoteInPickingQty,
    da.del_shipped_qty                        AS DelNoteShippedQty,
    da.del_note_numbers                       AS DelNoteNumbers,
    ma.inv_goods_receipt_qty                  AS InvGoodsReceiptQty,
    ma.inv_min_gr_date                        AS InvMinGoodsReceiptDate,
    ma.inv_max_gr_date                        AS InvMaxGoodsReceiptDate,
    CASE WHEN nsd_s.int_dc_type_code = 60 THEN nsd_s.gsm_code
         ELSE COALESCE(cs_s.store_code_new, h.supplying_plant) END AS StoreDCIdSender,
    CASE WHEN nsd_r.int_dc_type_code = 60 THEN nsd_r.gsm_code
         ELSE COALESCE(cs_r.store_code_new, i.site_code) END       AS StoreDCIdReceiver,
    nsd_s.country_code                        AS CountryCode,
    CAST(CASE WHEN TRY_CAST(COALESCE(cs_s.store_code_new, h.supplying_plant) AS INT) IS NOT NULL
              THEN 1 ELSE 0 END AS INT)       AS StoreDC_Flag,
    COALESCE(da.del_shipped_qty, 0) - COALESCE(ma.inv_goods_receipt_qty, 0) AS `In-Transit`,
    CASE WHEN ma.has_641 = 1 THEN h.purchase_order END             AS PurchaseOrder,
    CASE WHEN ma.has_641 = 1 THEN
        CASE WHEN TRY_CAST(REPLACE(i.material_number, '-', '') AS BIGINT) IS NOT NULL
             THEN REPLACE(i.material_number, '-', ' ')
             ELSE '000000 00 0' END END       AS Material,
    CASE WHEN ma.has_641 = 1 THEN '641' END   AS GoodsMovementType,
    ma.mvmt_641_amount                        AS TotalGoodsMvtAmtInCCCrcy,
    ma.mvmt_641_plant                         AS Plant,
    ma.mvmt_641_material_document             AS MaterialDocument,
    CASE WHEN ma.has_641 = 1 THEN 'S' END     AS DebitCreditCode,
    ma.mvmt_641_reference_document            AS ReferenceDocument,
    rp.rrp                                    AS `RRP incl. VAT`,
    rp.rrp * 0.840336134                      AS `RRP excl. VAT`,
    rp.rrp * COALESCE(i.order_quantity, 0)    AS `Gross Value`,
    rp.rrp * 0.840336134 * COALESCE(i.order_quantity, 0) AS `NET RRP`,
    CONCAT(i.material_number, '|',
           CASE WHEN h.company_code = 'PT10' THEN 'ES10' ELSE h.company_code END) AS NatArticle_BK,
    CAST(CASE
        WHEN COALESCE(i.is_completely_delivered, '') <> '' THEN 0
        WHEN COALESCE(h.deletion_code, i.deletion_code) = 'L' THEN 0
        ELSE GREATEST(COALESCE(i.order_quantity, 0) - COALESCE(da.del_outbound_qty, 0), 0)
    END AS DECIMAL(13,3))                     AS Backlog,
    ma.shipped_units                          AS ShippedUnits

FROM s2_silver.fact_po_header h
INNER JOIN s2_silver.fact_po_item i
    ON  i.purchase_order = h.purchase_order
LEFT JOIN po_type_desc ptd
    ON  ptd.po_type_code = h.po_type_code
LEFT JOIN sched_agg sa
    ON  sa.purchase_order = i.purchase_order
    AND sa.purchase_order_item = i.purchase_order_item
LEFT JOIN deliv_agg da
    ON  da.purchase_order = i.purchase_order
    AND da.purchase_order_item = i.purchase_order_item
LEFT JOIN mvmt_agg ma
    ON  ma.purchase_order = i.purchase_order
    AND ma.purchase_order_item = i.purchase_order_item
LEFT JOIN s2_silver.s4hana_interfaces intf
    ON  intf.company_code = h.company_code
    AND intf.interface = 'EBP'
LEFT JOIN s2_silver.dim_materials mat
    ON  mat.material_number = i.material_number
LEFT JOIN closed_store_map cs_s
    ON  cs_s.store_code_old = h.supplying_plant
LEFT JOIN closed_store_map cs_r
    ON  cs_r.store_code_old = i.site_code
LEFT JOIN s2_silver.peg_natstoredcs nsd_s
    ON  nsd_s.natstoredc_bk = CONCAT(COALESCE(cs_s.store_code_new, h.supplying_plant), '|EU')
LEFT JOIN s2_silver.peg_natstoredcs nsd_r
    ON  nsd_r.natstoredc_bk = CONCAT(COALESCE(cs_r.store_code_new, i.site_code), '|EU')
LEFT JOIN retail_price rp
    ON  rp.article_number_bk = CONCAT(TRIM(mat.style_number), ' ', TRIM(mat.color_number))
    AND h.creation_date BETWEEN rp.validity_start_date AND rp.validity_end_date
WHERE h.po_sub_type = 'T'
  AND h.company_code = 'DE11'
  AND h.creation_date >= DATE'2020-01-01'
  AND COALESCE(h.deletion_code, i.deletion_code, '') <> 'L'
  AND nsd_s.natstoredc_bk IS NOT NULL
;