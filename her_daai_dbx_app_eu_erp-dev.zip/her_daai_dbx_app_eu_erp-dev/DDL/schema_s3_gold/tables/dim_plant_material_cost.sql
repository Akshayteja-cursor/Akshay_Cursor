USE CATALOG IDENTIFIER(:catalog);


CREATE TABLE IF NOT EXISTS s3_gold.dim_plant_material_cost (
  plant                    STRING,
  material                 STRING,
  valuation_type           STRING,
  price_control_indicator  STRING,
  moving_average_price     DECIMAL(38, 6),
  standard_price           DECIMAL(38, 6),
  price_unit               DECIMAL(5, 0),
  price_currency           STRING,
  company_code             STRING,
  valid_from_date          DATE,
  valid_to_date            DATE,
  last_changed_at          TIMESTAMP,
  load_timestamp           TIMESTAMP     COMMENT 'Original registry load_timestamp from the source (or last_changed_at proxy for history rows). Used as watermark, dedup tiebreak, and merge key support.',
  data_source              STRING        COMMENT 'Origin: actual or history',
  etl_load_timestamp       TIMESTAMP     COMMENT 'When this row was written/updated in gold by this pipeline')
USING delta
CLUSTER BY auto
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.enableDeletionVectors' = 'true',
  'delta.enableChangeDataFeed' = 'true',
  'delta.feature.allowColumnDefaults' = 'supported',
  'delta.feature.appendOnly' = 'supported',
  'delta.feature.deletionVectors' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.feature.rowTracking' = 'supported',
  'delta.parquet.compression.codec' = 'zstd');