use catalog identifier(:catalog);
CREATE TABLE if not EXISTS   s3_gold.fact_so_allocation
(
    fact_so_item_pk VARCHAR(64), -- Primary key hash 
    data_source VARCHAR(10), -- Data source identifier
    mandt  VARCHAR(9), -- Client ID 
    vbeln VARCHAR(30), -- Sales document number
    posnr VARCHAR(18), -- Sales document item number
    vbtyp VARCHAR(3), -- Sales document type
    sales_document_type VARCHAR(10) , --Sales Document Type auart
    etenr VARCHAR(12), -- Schedule line number
    vbeln_dlv VARCHAR(30), -- Delivery number
    posnr_dlv VARCHAR(18), -- Delivery item number
    vbeln_bill VARCHAR(48), -- Billing document number
    posnr_bill VARCHAR(48), -- Billing document item
    abgru VARCHAR(6) default '', -- Reason for rejection
    wbsta VARCHAR(3), -- Overall processing status
    cmgst VARCHAR(1), -- Credit management status
    matnr VARCHAR(54), -- Material number 
    werks VARCHAR(12), -- Plant
  
    direct_ship_indicator VARCHAR(1), -- Direct shipment indicator
    closed_indicator VARCHAR(1), -- Closed indicator
    waerk VARCHAR(15), -- Document currency
    kunnr VARCHAR(30), -- Customer number
    bukrs VARCHAR(12), -- Company code
    vkorg VARCHAR(12), -- Sales organization
    vtweg VARCHAR(6), -- Distribution channel
    spart VARCHAR(6), -- Division
  
    posnr_index INT, -- Item index
    etenr_index BIGINT, -- Schedule line index
    dlv_index BIGINT, -- Delivery index
    bill_index BIGINT, -- Billing index
    schedule_index BIGINT, -- Index for repeatead schedule lines
    fsh_season VARCHAR(12), -- Fashion season
    fsh_season_year VARCHAR(12), -- Fashion season year
    fsh_collection VARCHAR(6), -- Fashion collection 
    fsh_theme VARCHAR(12), -- Fashion theme 
    sgt_rcat VARCHAR(48), -- Segmentation category

   
    sign INT, -- Sign indicator (e.g., 1 or -1)
    
    -- DATES START
    
    audat DATE default cast('1900-01-01' as date), -- Order date
    edatu DATE default cast('1900-01-01' as date), -- Requested delivery date
    wadat DATE default cast('1900-01-01' as date), -- Goods issue date
    wadat_ist DATE default cast('1900-01-01' as date), -- Actual goods issue date
    fkdat DATE default cast('1900-01-01' as date), -- Billing date
    actual_date DATE default cast('1900-01-01' as date), -- Actual processing date
    psd DATE default cast('1900-01-01' as date), -- Planned shipping date
    psd_preview DATE default cast('1900-01-01' as date), -- Preview shipping date
    bldat DATE default cast('1900-01-01' as date), -- Document date in document

    load_timestamp_fact_so_item TIMESTAMP, -- Last update timestamp (VBAP)
    load_timestamp_fact_so_header TIMESTAMP, -- Last update timestamp (VBAK)
    load_timestamp_fact_so_sch TIMESTAMP, -- Last update timestamp (VBEP)
    load_timestamp_fact_delivery_item TIMESTAMP, -- Last update timestamp (LIPS)
    load_timestamp_fact_delivery_header TIMESTAMP, -- Last update timestamp (LIKP)

    load_timestamp_call TIMESTAMP, -- Last update timestamp (CALL data)
    load_timestamp_fact_bill_item_so TIMESTAMP, -- Last update timestamp (VBRP - SO)
    load_timestamp_fact_bill_header_so TIMESTAMP, -- Last update timestamp (VBRK - SO)
    load_timestamp_fact_bill_item TIMESTAMP, -- Last update timestamp (VBRP)
    load_timestamp_fact_bill_header TIMESTAMP, -- Last update timestamp (VBRK)
    load_timestamp_arun TIMESTAMP, -- Last update timestamp (ARUN) /
    load_timestamp_po_assigment TIMESTAMP, -- Last update timestamp (ARUNP) / 
    -- DATES END
    
    -- METRICS START
 
    ordered DECIMAL(13, 2) default 0, -- Ordered quantity kwmeng
    returned DECIMAL(13, 2) default 0, -- Returned quantity
    confirmed DECIMAL(13, 2) default 0, -- Confirmed quantity bmeng
    booked DECIMAL(13, 2) default 0, -- Booked quantity
    cancelled DECIMAL(13, 2) default 0, -- Cancelled quantity
    unshipped DECIMAL(13, 2) default 0, -- Quantity not yet shipped
    called_off DECIMAL(13, 2) default 0, -- Called-off quantity
    delivery DECIMAL(13, 2) default 0, -- Delivered quantity
    shipped DECIMAL(13, 2) default 0, -- Shipped quantity
    credit_hold DECIMAL(13, 2) default 0, -- Quantity on credit hold
    billed DECIMAL(13, 2) default 0, -- Billed quantity
    pgi_not_invoiced DECIMAL(13, 2) default 0, -- Post-Goods Issue not invoiced
    unconfrqty DECIMAL(13, 2) default 0, -- Unconfirmed quantity
    non_allocated DECIMAL(13, 2) default 0, -- Non-allocated quantity
   

 
    netpr DOUBLE default 0, -- Net price
    kzwi1 DOUBLE default 0, -- Subtotal 1 (pricing)
    kzwi2 DOUBLE default 0, -- Subtotal 2 (pricing)
    kzwi3 DOUBLE default 0, -- Subtotal 3 (pricing)
    --- METRICS END
    
    --- HASH KEYS START
   fact_so_schedule_lines_pk VARCHAR(64), -- Hash key for VBEP 
    fact_delivery_item_pk VARCHAR(64), -- Hash key for LIPS 
    fact_billing_item_pk VARCHAR(64), -- Hash key for VBRP 

    --- HASH KEYS END
    
    load_timestamp TIMESTAMP -- ETL load timestamp / change name 
)
USING DELTA
CLUSTER BY auto -- can we use auto  ?
TBLPROPERTIES(
'delta.feature.allowColumnDefaults' = 'supported',
'delta.autoOptimize.optimizeWrite' = 'true',
'delta.autoOptimize.autoCompact' = 'true',
'delta.enableChangeDataFeed' = 'true'
);
