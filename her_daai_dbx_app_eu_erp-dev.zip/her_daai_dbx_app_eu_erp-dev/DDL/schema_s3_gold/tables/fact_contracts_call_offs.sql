use catalog identifier(:catalog);
CREATE TABLE if not EXISTS s3_gold.fact_contracts_call_offs (
  contract_line_id STRING,
  call_off_line_id STRING,
  client_id STRING,
  contract_number STRING,
  contract_line STRING,
  call_off_number STRING,
  call_off_line STRING,
  contract_line_rejection_reason_code STRING,
  contract_line_rejection_reason_description STRING,
  call_off_line_rejection_reason_code STRING,
  call_of_line_rejection_reason_description STRING,
  called_off_quantity DECIMAL(26,3),
  order_delivery_quantity DECIMAL(23,3),
  return_quantity_received INT,
  insert_update_timestamp_call TIMESTAMP,
  insert_update_timestamp_lips TIMESTAMP,
  insert_update_timestamp_vbfa TIMESTAMP,
  etl_load_timestamp TIMESTAMP)
USING delta
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.enableDeletionVectors' = 'true',
  'delta.feature.appendOnly' = 'supported',
  'delta.feature.deletionVectors' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.minReaderVersion' = '3',
  'delta.minWriterVersion' = '7',
  'delta.parquet.compression.codec' = 'zstd');

