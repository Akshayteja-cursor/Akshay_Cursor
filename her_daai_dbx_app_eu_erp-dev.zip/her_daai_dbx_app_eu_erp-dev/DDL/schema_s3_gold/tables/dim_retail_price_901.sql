
USE CATALOG IDENTIFIER(:catalog);

CREATE TABLE IF NOT EXISTS s3_gold.dim_retail_price_901 (
  application               STRING,
  condition_type            STRING,
  sales_organisation        STRING,
  material_number           STRING,
  generic_material          STRING,
  is_generic_material        BOOLEAN,
  article_number_bk         STRING,
  release_status            STRING,
  validity_start_date       DATE,
  validity_end_date         DATE,
  processing_status         STRING,
  condition_record_number   STRING,
  sequence_num              STRING,
  price                     DECIMAL(38,6),
  currency                  STRING,
  load_timestamp            TIMESTAMP)
USING delta
CLUSTER BY auto
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.enableDeletionVectors' = 'true',
  'delta.enableChangeDataFeed' = 'true',
  'delta.feature.allowColumnDefaults' = 'supported',
  'delta.feature.appendOnly' = 'supported',
  'delta.feature.deletionVectors' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.feature.rowTracking' = 'supported',
  'delta.parquet.compression.codec' = 'zstd');