USE CATALOG IDENTIFIER(:catalog);



CREATE TABLE IF NOT EXISTS s3_gold.fact_inventory_snapshot_by_postingdate
(
    snapshot_date                   DATE                                    ,
    posting_date                    DATE                                    ,
    data_source                     STRING                                  ,
    company_code                    STRING                                  ,
    plant                           STRING                                  ,
    material                        STRING                                  ,
    storage_location                STRING                                  ,
    stock_segment                   STRING                                  ,
    special_stock_indicator         STRING                                  ,

    unrestricted_use_stock          INTEGER        DEFAULT 0                ,
    stock_in_quality_inspection     INTEGER        DEFAULT 0                ,
    returns                         INTEGER        DEFAULT 0                ,
    stock_transfer_storage_loc      INTEGER        DEFAULT 0                ,
    stock_transfer_plant            INTEGER        DEFAULT 0                ,
    stock_in_transit                INTEGER        DEFAULT 0                ,
    blocked_stock                   INTEGER        DEFAULT 0                ,
    restricted_use_stock            INTEGER        DEFAULT 0                ,
    tied_empties                    INTEGER        DEFAULT 0                ,
    valuated_gr_blocked_stock       INTEGER        DEFAULT 0                ,
    allocated_to_po                 INTEGER        DEFAULT 0                ,
    allocated_to_stock              INTEGER        DEFAULT 0                ,
    allocated_to_delivery           INTEGER        DEFAULT 0                ,
    allocated_on_hold               INTEGER        DEFAULT 0                ,
    sto_not_shipped                 INTEGER        DEFAULT 0                ,
    sto_in_transit                  INTEGER        DEFAULT 0                ,
    available_to_promise            INTEGER        DEFAULT 0                ,
    atp_wb_plant_stock              INTEGER        DEFAULT 0                ,
    atp_la_shipping                 INTEGER        DEFAULT 0                ,
    atp_be_order_items              INTEGER        DEFAULT 0                ,

    batch_id                        STRING                                  ,
    material_base_unit              STRING                                  ,

    cost_currency                   STRING                                  ,
    cost_valid_from_date            DATE                                    ,
    cost_valid_to_date              DATE                                    ,

    amt_unrestricted_use_stock      DECIMAL(38, 6) DEFAULT 0                ,
    amt_stock_in_quality_inspection DECIMAL(38, 6) DEFAULT 0                ,
    amt_returns                     DECIMAL(38, 6) DEFAULT 0                ,
    amt_stock_transfer_storage_loc  DECIMAL(38, 6) DEFAULT 0                ,
    amt_stock_transfer_plant        DECIMAL(38, 6) DEFAULT 0                ,
    amt_stock_in_transit            DECIMAL(38, 6) DEFAULT 0                ,
    amt_blocked_stock               DECIMAL(38, 6) DEFAULT 0                ,
    amt_restricted_use_stock        DECIMAL(38, 6) DEFAULT 0                ,
    amt_tied_empties                DECIMAL(38, 6) DEFAULT 0                ,
    amt_valuated_gr_blocked_stock   DECIMAL(38, 6) DEFAULT 0                ,
    amt_allocated_to_po             DECIMAL(38, 6) DEFAULT 0                ,
    amt_allocated_to_stock          DECIMAL(38, 6) DEFAULT 0                ,
    amt_allocated_to_delivery       DECIMAL(38, 6) DEFAULT 0                ,
    amt_allocated_on_hold           DECIMAL(38, 6) DEFAULT 0                ,
    amt_sto_not_shipped             DECIMAL(38, 6) DEFAULT 0                ,
    amt_sto_in_transit              DECIMAL(38, 6) DEFAULT 0                ,
    amt_available_to_promise        DECIMAL(38, 6) DEFAULT 0                ,
    amt_atp_wb_plant_stock          DECIMAL(38, 6) DEFAULT 0                ,
    amt_atp_la_shipping             DECIMAL(38, 6) DEFAULT 0                ,
    amt_atp_be_order_items          DECIMAL(38, 6) DEFAULT 0                ,


    running_total_unrestricted_use_stock        DECIMAL(38, 6)              ,
    running_total_stock_in_quality_inspection   DECIMAL(38, 6)              ,
    running_total_returns                       DECIMAL(38, 6)              ,
    running_total_stock_transfer_storage_loc    DECIMAL(38, 6)              ,
    running_total_stock_transfer_plant          DECIMAL(38, 6)              ,
    running_total_stock_in_transit              DECIMAL(38, 6)              ,
    running_total_blocked_stock                 DECIMAL(38, 6)              ,
    running_total_restricted_use_stock          DECIMAL(38, 6)              ,
    running_total_tied_empties                  DECIMAL(38, 6)              ,
    running_total_valuated_gr_blocked_stock     DECIMAL(38, 6)              ,
    running_total_total_quantity                DECIMAL(38, 6)              ,


    gross                           DECIMAL(38, 6)                          ,

    total_quantity                  INTEGER        DEFAULT 0                ,
    total_inventory_value           DECIMAL(38, 6) DEFAULT 0                ,

    load_timestamp                  TIMESTAMP
)
USING DELTA
CLUSTER BY AUTO
TBLPROPERTIES (
    'delta.feature.allowColumnDefaults' = 'supported',
    'delta.autoOptimize.optimizeWrite'  = 'true',
    'delta.autoOptimize.autoCompact'    = 'true',
    'delta.enableChangeDataFeed'        = 'true'
);
