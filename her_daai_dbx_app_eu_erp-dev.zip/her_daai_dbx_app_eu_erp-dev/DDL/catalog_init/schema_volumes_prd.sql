USE CATALOG IDENTIFIER(:catalog);

-- This schema will serve as a predeployment script for STAGING and PROD environments, please add the schemas and volumes used for each schema as below


-- Create an schema with managed location
CREATE SCHEMA IF NOT EXISTS s0_control MANAGED LOCATION 'abfss://dp-eu-erp-prd-bronze@dpemeaprdbronze.dfs.core.windows.net/s0_control';
CREATE SCHEMA IF NOT EXISTS s1_bronze_ebp MANAGED LOCATION 'abfss://dp-eu-erp-prd-bronze@dpemeaprdbronze.dfs.core.windows.net/s1_bronze_ebp';
CREATE SCHEMA IF NOT EXISTS s2_silver MANAGED LOCATION 'abfss://dp-eu-erp-prd-silver@dpemeaprdsilver.dfs.core.windows.net/s2_silver';
CREATE SCHEMA IF NOT EXISTS s3_gold MANAGED LOCATION 'abfss://dp-eu-erp-prd-gold@dpemeaprdgold.dfs.core.windows.net/s3_gold';

CREATE SCHEMA IF NOT EXISTS ref MANAGED LOCATION 'abfss://dp-eu-erp-prd-gold@dpemeaprdgold.dfs.core.windows.net/ref';
CREATE SCHEMA IF NOT EXISTS sales MANAGED LOCATION 'abfss://dp-eu-erp-prd-gold@dpemeaprdgold.dfs.core.windows.net/sales';

-- CREATE VOLUME IF NOT EXISTS s1_bronze_ebp.upload;
-- Similarly create schema script and volumes used for each schema 


CREATE EXTERNAL VOLUME IF NOT EXISTS s1_bronze_ebp.loader_checkpoint LOCATION 'abfss://dp-eu-erp-prd-bronze@dpemeaprdbronze.dfs.core.windows.net/loader_checkpoint';

CREATE EXTERNAL VOLUME IF NOT EXISTS s1_bronze_ebp.upload LOCATION 'abfss://dp-eu-erp-prd-bronze@dpemeaprdbronze.dfs.core.windows.net/upload';

CREATE EXTERNAL VOLUME IF NOT EXISTS s0_control.static_load LOCATION 'abfss://dp-eu-erp-prd-workspace@dpemeaprdworkspace.dfs.core.windows.net/static_load';
