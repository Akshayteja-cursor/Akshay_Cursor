USE CATALOG IDENTIFIER(:catalog);

create view if not exists s2_silver.byod_fra_season_by_date 
as
select 
Season,
to_date(CAST(SOCreationDateBegin AS STRING), 'yyyyMMdd') AS SOCreationDateBegin,
to_date(CAST(SOCreationDateEnd AS STRING), 'yyyyMMdd') AS SOCreationDateEnd
from  parquet.`abfss://workspacefrance@bieuropedevwork.dfs.core.windows.net/FRA_MI_stg/BI/source/SeasonByDate/`
;


-- static table loaded via CSV
CREATE OR REPLACE TEMP VIEW temp_national_sales_semester AS
SELECT
CAST(`SellInDate` AS DATE) AS SellInDate,
  `SellIn-SalesSemester` AS SalesSemester,
  `SellIn-SalesSemesterLY` AS SalesSemesterLY,
  CAST(`StartSellInSeasonCreationDate` AS DATE) AS StartSellInSeasonCreationDate,
  CAST(`EndSellInSeasonCreationDate` AS DATE) AS EndSellInSeasonCreationDate,
  CAST(`StartEarlyIntroPickDate` AS DATE) AS StartEarlyIntroPickDate,
  CAST(`EndEarlyIntroPickDate` AS DATE) AS EndEarlyIntroPickDate,
  CAST(`StartRegularDate` AS DATE) AS StartRegularDate,
  CAST(`EndRegularDate` AS DATE) AS EndRegularDate,
  `SellInYear` AS SellInYear,
  `SellInSemester` AS SellInSemester
FROM read_files(
  '/Volumes/eu_erp_stg/s0_control/static_load/NationalSalesSemester.csv',
  format => 'csv',
  header => true
);
