USE CATALOG IDENTIFIER(:catalog);

-- This schema will serve as a predeployment script for STAGING and PROD environments, please add the schemas and volumes used for each schema as below


-- Create an schema with managed location
CREATE SCHEMA IF NOT EXISTS s0_control MANAGED LOCATION 'abfss://dp-eu-erp-stg-bronze@dpemeadevbronze.dfs.core.windows.net/s0_control';
CREATE SCHEMA IF NOT EXISTS s1_bronze_ebp MANAGED LOCATION 'abfss://dp-eu-erp-stg-bronze@dpemeadevbronze.dfs.core.windows.net/s1_bronze_ebp';
CREATE SCHEMA IF NOT EXISTS s2_silver MANAGED LOCATION 'abfss://dp-eu-erp-stg-silver@dpemeadevsilver.dfs.core.windows.net/s2_silver';
CREATE SCHEMA IF NOT EXISTS s3_gold MANAGED LOCATION 'abfss://dp-eu-erp-stg-gold@dpemeadevgold.dfs.core.windows.net/s3_gold';

CREATE SCHEMA IF NOT EXISTS ref MANAGED LOCATION 'abfss://dp-eu-erp-stg-gold@dpemeadevgold.dfs.core.windows.net/ref';
CREATE SCHEMA IF NOT EXISTS sales MANAGED LOCATION 'abfss://dp-eu-erp-stg-gold@dpemeadevgold.dfs.core.windows.net/sales';


CREATE EXTERNAL VOLUME IF NOT EXISTS s1_bronze_ebp.loader_checkpoint LOCATION 'abfss://dp-eu-erp-stg-bronze@dpemeadevbronze.dfs.core.windows.net/loader_checkpoint/';

CREATE EXTERNAL VOLUME IF NOT EXISTS s1_bronze_ebp.upload LOCATION 'abfss://dp-eu-erp-stg-bronze@dpemeadevbronze.dfs.core.windows.net/upload/';

CREATE EXTERNAL VOLUME IF NOT EXISTS s0_control.static_load LOCATION 'abfss://dp-eu-erp-stg-workspace@dpemeadevworkspace.dfs.core.windows.net/static_load/';



