USE CATALOG IDENTIFIER(:catalog);

CREATE TABLE IF NOT EXISTS ref.plantmaterialpricehistory_dl
USING PARQUET
LOCATION 'abfss://curated@bieuropedevencur.dfs.core.windows.net/PDW_PEG_stg/ref/PlantMaterialPricesHistory/';

CREATE TABLE IF NOT EXISTS sales.retailpricemaster_dl
USING PARQUET
LOCATION 'abfss://curated@bieuropedevencur.dfs.core.windows.net/PDW_PEG_stg/sales/retailpricemaster_dl/';

CREATE TABLE IF NOT EXISTS s2_silver.byod_fra_buying_group_mapping 
USING PARQUET
LOCATION 'abfss://workspacefrance@bieuropedevwork.dfs.core.windows.net/FRA_MI_stg/BI/source/BuyingGroupMapping/';

CREATE TABLE IF NOT EXISTS s2_silver.byod_fra_buying_group_mapping_natcustomer 
USING PARQUET
LOCATION 'abfss://workspacefrance@bieuropedevwork.dfs.core.windows.net/FRA_MI_stg/BI/source/BuyingGroupMappingNatCustomer/';

CREATE TABLE IF NOT EXISTS s2_silver.byod_fra_season_by_order 
USING PARQUET
LOCATION 'abfss://workspacefrance@bieuropedevwork.dfs.core.windows.net/FRA_MI_stg/BI/source/SeasonByOrder/';