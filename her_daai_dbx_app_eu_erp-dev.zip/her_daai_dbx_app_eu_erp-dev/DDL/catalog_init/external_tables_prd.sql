USE CATALOG IDENTIFIER(:catalog);

CREATE TABLE IF NOT EXISTS ref.plantmaterialpricehistory_dl
USING PARQUET
LOCATION 'abfss://curated@bieuropeprdencur.dfs.core.windows.net/PDW_PEG/ref/PlantMaterialPricesHistory/';

CREATE TABLE IF NOT EXISTS sales.retailpricemaster_dl
USING PARQUET
LOCATION 'abfss://curated@bieuropeprdencur.dfs.core.windows.net/PDW_PEG/sales/RetailPriceMaster_DL/';


CREATE TABLE IF NOT EXISTS s2_silver.byod_fra_buying_group_mapping 
USING PARQUET
LOCATION 'abfss://workspacefrance@bieuropeprdwork.dfs.core.windows.net/FRA_MI/BI/source/BuyingGroupMapping/';

CREATE TABLE IF NOT EXISTS s2_silver.byod_fra_buying_group_mapping_natcustomer 
USING PARQUET
LOCATION 'abfss://workspacefrance@bieuropeprdwork.dfs.core.windows.net/FRA_MI/BI/source/BuyingGroupMappingNatCustomer/';


CREATE TABLE IF NOT EXISTS s2_silver.byod_fra_season_by_order 
USING PARQUET
LOCATION 'abfss://workspacefrance@bieuropeprdwork.dfs.core.windows.net/FRA_MI/BI/source/SeasonByOrder/';
