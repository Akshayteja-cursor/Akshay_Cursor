use catalog identifier(:catalog);

CREATE TABLE IF NOT EXISTS s0_control.export_interface_mapping (
  export_interface_code STRING NOT NULL,
  export_interface_detail_code STRING NOT NULL,
  source_system STRING,
  source_schema STRING,
  source_table STRING,
  source_column STRING,
  target_schema STRING,
  target_table STRING,
  target_column STRING,
  target_column_datatype STRING,
  field_creation_logic STRING,
  notes STRING,
  is_active BOOLEAN,
  CONSTRAINT pk_export_interface_mapping PRIMARY KEY (export_interface_code, export_interface_detail_code, target_column),
  CONSTRAINT fk_export_interface_code_mapping FOREIGN KEY (export_interface_code) REFERENCES s0_control.export_interfaces(export_interface_code),
  CONSTRAINT fk_export_interface_detail_code_mapping FOREIGN KEY (export_interface_detail_code) REFERENCES s0_control.export_interface_details(export_interface_detail_code))
USING delta;
