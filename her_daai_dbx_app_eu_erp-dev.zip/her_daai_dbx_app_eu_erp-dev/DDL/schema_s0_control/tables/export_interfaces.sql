use catalog identifier(:catalog);

CREATE TABLE IF NOT EXISTS s0_control.export_interfaces (
  export_interface_code STRING NOT NULL,
  export_interface_name STRING,
  catalog STRING,
  export_volume STRING,
  export_root_folder STRING,
  active BOOLEAN,
  CONSTRAINT pk_export_interface_code PRIMARY KEY (export_interface_code))
USING delta;