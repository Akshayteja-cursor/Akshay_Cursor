use catalog identifier(:catalog);

CREATE TABLE IF NOT EXISTS s0_control.export_interface_details (
  export_interface_detail_code STRING NOT NULL,
  export_interface_code STRING NOT NULL,
  source_schema STRING,
  source_object_name STRING,
  source_object_type STRING,
  export_schema STRING,
  export_folder_name STRING,
  export_table_name STRING,
  business_keys STRING,
  date_column STRING,
  z_order_column STRING,
  partition_key STRING,
  filter_column STRING,
  filter_value STRING,
  ldts_delta TIMESTAMP,
  write_mode STRING,
  active BOOLEAN,
  CONSTRAINT pk_export_interface_detail_code PRIMARY KEY (export_interface_detail_code),
  CONSTRAINT fk_export_interface_code FOREIGN KEY (export_interface_code) REFERENCES s0_control.export_interfaces(export_interface_code))
USING delta;