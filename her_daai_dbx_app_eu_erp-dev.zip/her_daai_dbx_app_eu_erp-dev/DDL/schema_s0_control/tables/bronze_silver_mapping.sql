use catalog identifier(:catalog);

CREATE TABLE IF NOT EXISTS s0_control.bronze_silver_mapping (
  source_system STRING,
  bronze_schema STRING,
  bronze_table STRING,
  bronze_column STRING,
  silver_schema STRING,
  silver_table STRING,
  silver_column STRING,
  silver_column_datatype STRING,
  key_type STRING,
  column_comment STRING,
  key_creation_logic STRING,
  scd_type STRING,
  notes STRING,
  is_active STRING)
USING delta;
