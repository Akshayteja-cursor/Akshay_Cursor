-- Databricks notebook source
USE CATALOG IDENTIFIER(:catalog);

CREATE OR REPLACE FUNCTION s2_silver.fn_agg_fact_material_movements
(
    SnapshotDate TIMESTAMP
)

RETURNS TABLE

RETURN

WITH

-- ============================================================
-- Step 1 : Filter and Normalize Material Movements
-- ============================================================

movements_filtered AS
(
    SELECT
        SHMSM.company_code,
        SHMSM.material,
        SHMSM.plant,
        SHMSM.storage_location,
        COALESCE(
            NULLIF(TRIM(SHMSM.stock_segment), ''),
            NULLIF(TRIM(SHMSM.issg_or_rcvg_stock_segment), '')
            ) AS stock_segment,
        SHMSM.stock_identifying_batch,
        SHMSM.inventory_special_stock_type,
        SHMSM.material_base_unit,
        SHMSM.posting_date,
        SHMSM.inventory_stock_type,
        SHMSM.matl_stk_change_qty_in_base_unit

    FROM s2_silver.fact_material_movements SHMSM
    WHERE CAST(posting_date AS DATE) <= CAST(SnapshotDate AS DATE)
),

-- ============================================================
-- Step 2 : Pivot Inventory Stock Types into Columns
-- ============================================================

pivoted_by_posting_date AS
(
    SELECT
        company_code,
        material,
        plant,
        storage_location,
        stock_segment,
        stock_identifying_batch,
        inventory_special_stock_type,
        material_base_unit,
        posting_date,

        CAST(SUM(CASE WHEN inventory_stock_type = '01' THEN matl_stk_change_qty_in_base_unit ELSE 0 END) AS DECIMAL(38,6)) AS unrestricted_stock,
        CAST(SUM(CASE WHEN inventory_stock_type = '02' THEN matl_stk_change_qty_in_base_unit ELSE 0 END) AS DECIMAL(38,6)) AS stock_in_quality_inspection,
        CAST(SUM(CASE WHEN inventory_stock_type = '03' THEN matl_stk_change_qty_in_base_unit ELSE 0 END) AS DECIMAL(38,6)) AS blocked_stock_returns,
        CAST(SUM(CASE WHEN inventory_stock_type = '04' THEN matl_stk_change_qty_in_base_unit ELSE 0 END) AS DECIMAL(38,6)) AS stock_in_transfer_stloc,
        CAST(SUM(CASE WHEN inventory_stock_type = '05' THEN matl_stk_change_qty_in_base_unit ELSE 0 END) AS DECIMAL(38,6)) AS stock_in_transfer_plant,
        CAST(SUM(CASE WHEN inventory_stock_type = '06' THEN matl_stk_change_qty_in_base_unit ELSE 0 END) AS DECIMAL(38,6)) AS stock_in_transit,
        CAST(SUM(CASE WHEN inventory_stock_type = '07' THEN matl_stk_change_qty_in_base_unit ELSE 0 END) AS DECIMAL(38,6)) AS blocked_stock,
        CAST(SUM(CASE WHEN inventory_stock_type = '08' THEN matl_stk_change_qty_in_base_unit ELSE 0 END) AS DECIMAL(38,6)) AS total_stock_restricted_batches,
        CAST(SUM(CASE WHEN inventory_stock_type = '09' THEN matl_stk_change_qty_in_base_unit ELSE 0 END) AS DECIMAL(38,6)) AS tied_empties,
        CAST(SUM(CASE WHEN inventory_stock_type = '10' THEN matl_stk_change_qty_in_base_unit ELSE 0 END) AS DECIMAL(38,6)) AS valuated_goods_receipt_blocked_stock

    FROM movements_filtered
    GROUP BY all
),

-- ============================================================
-- Step 3 : Calculate Inventory Values
-- Pricing priority:
--   1. Current price  : MAP / standard as-of SnapshotDate  (SNAP join)
--   2. Historical price: MAP / standard as-of posting_date (HIST join)
--   3. Zero fallback  : 0.00
-- Both joins treat 0 as "not available" via NULLIF so a stale
-- zero price never silently wipes out a valid historical price.
-- ============================================================

priced_movements AS
(
    SELECT
        PBD.company_code,
        PBD.material,
        PBD.plant,
        PBD.storage_location,
        PBD.stock_segment,
        PBD.stock_identifying_batch,
        PBD.inventory_special_stock_type,
        PBD.material_base_unit,
        PBD.posting_date,

        -- Resolved price (current → historical → 0)
        COALESCE(
            NULLIF(SNAP.moving_average_price, 0),
            NULLIF(SNAP.standard_price,       0),
            NULLIF(HIST.moving_average_price, 0),
            NULLIF(HIST.standard_price,       0),
            0.00
        ) AS price,
        COALESCE(SNAP.price_currency, HIST.price_currency, 'EUR') AS price_currency,

        -- Quantities (unchanged)
        PBD.unrestricted_stock,
        PBD.stock_in_quality_inspection,
        PBD.blocked_stock_returns,
        PBD.stock_in_transfer_stloc,
        PBD.stock_in_transfer_plant,
        PBD.stock_in_transit,
        PBD.blocked_stock,
        PBD.total_stock_restricted_batches,
        PBD.tied_empties,
        PBD.valuated_goods_receipt_blocked_stock,

        -- Values (quantity x resolved price)
        PBD.unrestricted_stock               * COALESCE(NULLIF(SNAP.moving_average_price,0),NULLIF(SNAP.standard_price,0),NULLIF(HIST.moving_average_price,0),NULLIF(HIST.standard_price,0),0.00) AS unrestricted_stock_value,
        PBD.stock_in_quality_inspection      * COALESCE(NULLIF(SNAP.moving_average_price,0),NULLIF(SNAP.standard_price,0),NULLIF(HIST.moving_average_price,0),NULLIF(HIST.standard_price,0),0.00) AS stock_in_quality_inspection_value,
        PBD.blocked_stock_returns            * COALESCE(NULLIF(SNAP.moving_average_price,0),NULLIF(SNAP.standard_price,0),NULLIF(HIST.moving_average_price,0),NULLIF(HIST.standard_price,0),0.00) AS blocked_stock_returns_value,
        PBD.stock_in_transfer_stloc          * COALESCE(NULLIF(SNAP.moving_average_price,0),NULLIF(SNAP.standard_price,0),NULLIF(HIST.moving_average_price,0),NULLIF(HIST.standard_price,0),0.00) AS stock_in_transfer_stloc_value,
        PBD.stock_in_transfer_plant          * COALESCE(NULLIF(SNAP.moving_average_price,0),NULLIF(SNAP.standard_price,0),NULLIF(HIST.moving_average_price,0),NULLIF(HIST.standard_price,0),0.00) AS stock_in_transfer_plant_value,
        PBD.stock_in_transit                 * COALESCE(NULLIF(SNAP.moving_average_price,0),NULLIF(SNAP.standard_price,0),NULLIF(HIST.moving_average_price,0),NULLIF(HIST.standard_price,0),0.00) AS stock_in_transit_value,
        PBD.blocked_stock                    * COALESCE(NULLIF(SNAP.moving_average_price,0),NULLIF(SNAP.standard_price,0),NULLIF(HIST.moving_average_price,0),NULLIF(HIST.standard_price,0),0.00) AS blocked_stock_value,
        PBD.total_stock_restricted_batches   * COALESCE(NULLIF(SNAP.moving_average_price,0),NULLIF(SNAP.standard_price,0),NULLIF(HIST.moving_average_price,0),NULLIF(HIST.standard_price,0),0.00) AS total_stock_restricted_batches_value,
        PBD.tied_empties                     * COALESCE(NULLIF(SNAP.moving_average_price,0),NULLIF(SNAP.standard_price,0),NULLIF(HIST.moving_average_price,0),NULLIF(HIST.standard_price,0),0.00) AS tied_empties_value,
        PBD.valuated_goods_receipt_blocked_stock * COALESCE(NULLIF(SNAP.moving_average_price,0),NULLIF(SNAP.standard_price,0),NULLIF(HIST.moving_average_price,0),NULLIF(HIST.standard_price,0),0.00) AS valuated_goods_receipt_blocked_stock_value

    FROM pivoted_by_posting_date PBD

    -- Current price: cost record valid as-of SnapshotDate
    LEFT JOIN s3_gold.dim_plant_material_cost SNAP
        ON  SNAP.material = PBD.material
        AND SNAP.plant    = PBD.plant
        AND CAST(SnapshotDate AS DATE)
                BETWEEN CAST(SNAP.valid_from_date AS DATE)
                    AND CAST(SNAP.valid_to_date   AS DATE)

    -- Historical price: cost record valid as-of each movement's posting_date
    LEFT JOIN s3_gold.dim_plant_material_cost HIST
        ON  HIST.material = PBD.material
        AND HIST.plant    = PBD.plant
        AND CAST(PBD.posting_date AS DATE)
                BETWEEN CAST(HIST.valid_from_date AS DATE)
                    AND CAST(HIST.valid_to_date   AS DATE)
)

-- ============================================================
-- Final Snapshot Aggregation
-- ============================================================

SELECT
    -----Dimensional columns--------
    PM.company_code,
    PM.material,
    PM.plant,
    PM.storage_location,
    PM.stock_segment,
    PM.stock_identifying_batch AS batch_id,
    PM.inventory_special_stock_type AS special_stock_indicator,
    PM.material_base_unit,
    PM.price_currency,
    CAST(SnapshotDate AS DATE) AS snapshot_date,

    ----Aggregated quantity columns---
    CAST(SUM(PM.unrestricted_stock) AS INT) AS unrestricted_stock,
    CAST(SUM(PM.stock_in_quality_inspection) AS INT) AS stock_in_quality_inspection,
    CAST(SUM(PM.blocked_stock_returns) AS INT) AS blocked_stock_returns,
    CAST(SUM(PM.stock_in_transfer_stloc) AS INT) AS stock_in_transfer_stloc,
    CAST(SUM(PM.stock_in_transfer_plant) AS INT) AS stock_in_transfer_plant,
    CAST(SUM(PM.stock_in_transit) AS INT) AS stock_in_transit,
    CAST(SUM(PM.blocked_stock) AS INT) AS blocked_stock,
    CAST(SUM(PM.total_stock_restricted_batches) AS INT) AS total_stock_restricted_batches,
    CAST(SUM(PM.tied_empties) AS INT) AS tied_empties,
    CAST(SUM(PM.valuated_goods_receipt_blocked_stock) AS INT) AS valuated_goods_receipt_blocked_stock,
   CAST(
      SUM(
            PM.unrestricted_stock
          + PM.stock_in_quality_inspection
          + PM.blocked_stock_returns
          + PM.stock_in_transfer_stloc
          + PM.stock_in_transfer_plant
          + PM.stock_in_transit
          + PM.blocked_stock
          + PM.total_stock_restricted_batches
          + PM.tied_empties
          + PM.valuated_goods_receipt_blocked_stock
      )
AS INT) AS total_stock_quantity,

    -----Aggregated value columns (quantity × price, summed)------
    CAST(SUM(PM.unrestricted_stock_value) AS DECIMAL(38,6)) AS unrestricted_stock_value,
    CAST(SUM(PM.stock_in_quality_inspection_value) AS DECIMAL(38,6)) AS stock_in_quality_inspection_value,
    CAST(SUM(PM.blocked_stock_returns_value) AS DECIMAL(38,6)) AS blocked_stock_returns_value,
    CAST(SUM(PM.stock_in_transfer_stloc_value) AS DECIMAL(38,6)) AS stock_in_transfer_stloc_value,
    CAST(SUM(PM.stock_in_transfer_plant_value) AS DECIMAL(38,6)) AS stock_in_transfer_plant_value,
    CAST(SUM(PM.stock_in_transit_value) AS DECIMAL(38,6)) AS stock_in_transit_value,
    CAST(SUM(PM.blocked_stock_value) AS DECIMAL(38,6)) AS blocked_stock_value,
    CAST(SUM(PM.total_stock_restricted_batches_value) AS DECIMAL(38,6)) AS total_stock_restricted_batches_value,
    CAST(SUM(PM.tied_empties_value) AS DECIMAL(38,6)) AS tied_empties_value,
    CAST(SUM(PM.valuated_goods_receipt_blocked_stock_value) AS DECIMAL(38,6)) AS valuated_goods_receipt_blocked_stock_value,
CAST(
      SUM(
            PM.unrestricted_stock_value
          + PM.stock_in_quality_inspection_value
          + PM.blocked_stock_returns_value
          + PM.stock_in_transfer_stloc_value
          + PM.stock_in_transfer_plant_value
          + PM.stock_in_transit_value
          + PM.blocked_stock_value
          + PM.total_stock_restricted_batches_value
          + PM.tied_empties_value
          + PM.valuated_goods_receipt_blocked_stock_value
      )
AS DECIMAL(38,6)) AS total_stock_value



FROM priced_movements PM

GROUP BY all
;
