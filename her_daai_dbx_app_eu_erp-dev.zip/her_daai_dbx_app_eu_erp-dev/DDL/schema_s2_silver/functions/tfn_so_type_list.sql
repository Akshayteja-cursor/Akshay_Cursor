use catalog identifier(:catalog);

create or replace function s2_silver.tfn_so_type_list(mode string)
returns table (so_type_code string)
return
with creadit_debit as (
    select so_type_code from s2_silver.s4hana_salestypes where so_type_code in ('ZDRR','ZCRR','ZPCR','ZPDR')  
) ,
contracts as (
    select so_type_code from s2_silver.s4hana_salestypes where so_type_code in ( 'ZPTO',  'ZPKP', 'ZCCD', 'ZARC') 
),
filtered as (
    select so_type_code  from s2_silver.s4hana_salestypes WHERE (int_sales_type <> 3 OR so_type_code in ('ZRET','ZCRR','ZPCR','ZRAU'))
),
order_entry as (select 'ZORR' so_type_code
                union all select 'ZORP' 
),
direct_ship as  (select 'ZDIL' so_type_code 
                union all select 'ZDIS'
)
select so_type_code from creadit_debit where upper(mode) = 'CREDITDEBIT'
union all 
select so_type_code from contracts where upper(mode) = 'CONTRACTS'
union all
select so_type_code from filtered where upper(mode) = 'FILTERED'
union all
select so_type_code from order_entry where upper(mode) = 'ORDERENTRY'
union all
select so_type_code from direct_ship where upper(mode) = 'DIRECTSHIP'