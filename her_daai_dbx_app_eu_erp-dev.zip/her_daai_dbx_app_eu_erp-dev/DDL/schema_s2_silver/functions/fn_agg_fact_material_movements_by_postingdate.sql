USE CATALOG IDENTIFIER(:catalog);


CREATE OR REPLACE FUNCTION s2_silver.fn_agg_fact_material_movements_by_postingdate
(
    SnapshotDate TIMESTAMP
)

RETURNS TABLE

RETURN

WITH

-- ============================================================
-- Step 1 : Filter and Normalize Material Movements
-- ============================================================

movements_filtered AS
(
    SELECT
        SHMSM.company_code,
        SHMSM.material,
        SHMSM.plant,
        SHMSM.storage_location,

        CASE
            WHEN COALESCE(SHMSM.stock_segment, '') = ''
                THEN SHMSM.issg_or_rcvg_stock_segment
            ELSE SHMSM.stock_segment
        END AS stock_segment,

        SHMSM.inventory_special_stock_type,
        SHMSM.stock_identifying_batch,
        SHMSM.material_base_unit,
        SHMSM.posting_date,
        SHMSM.inventory_stock_type,
        SHMSM.matl_stk_change_qty_in_base_unit

    FROM s2_silver.fact_material_movements SHMSM
    WHERE CAST(posting_date AS DATE) <= CAST(SnapshotDate AS DATE)
),

-- ============================================================
-- Step 2 : Pivot Inventory Stock Types into Columns (grain includes posting_date)
-- ============================================================

pivoted_by_posting_date AS
(
    SELECT
        company_code,
        material,
        plant,
        storage_location,
        stock_segment,
        stock_identifying_batch,
        inventory_special_stock_type,
        material_base_unit,
        posting_date,

        CAST(SUM(CASE WHEN inventory_stock_type = '01' THEN matl_stk_change_qty_in_base_unit ELSE 0 END) AS DECIMAL(38,6)) AS unrestricted_stock,
        CAST(SUM(CASE WHEN inventory_stock_type = '02' THEN matl_stk_change_qty_in_base_unit ELSE 0 END) AS DECIMAL(38,6)) AS stock_in_quality_inspection,
        CAST(SUM(CASE WHEN inventory_stock_type = '03' THEN matl_stk_change_qty_in_base_unit ELSE 0 END) AS DECIMAL(38,6)) AS blocked_stock_returns,
        CAST(SUM(CASE WHEN inventory_stock_type = '04' THEN matl_stk_change_qty_in_base_unit ELSE 0 END) AS DECIMAL(38,6)) AS stock_in_transfer_stloc,
        CAST(SUM(CASE WHEN inventory_stock_type = '05' THEN matl_stk_change_qty_in_base_unit ELSE 0 END) AS DECIMAL(38,6)) AS stock_in_transfer_plant,
        CAST(SUM(CASE WHEN inventory_stock_type = '06' THEN matl_stk_change_qty_in_base_unit ELSE 0 END) AS DECIMAL(38,6)) AS stock_in_transit,
        CAST(SUM(CASE WHEN inventory_stock_type = '07' THEN matl_stk_change_qty_in_base_unit ELSE 0 END) AS DECIMAL(38,6)) AS blocked_stock,
        CAST(SUM(CASE WHEN inventory_stock_type = '08' THEN matl_stk_change_qty_in_base_unit ELSE 0 END) AS DECIMAL(38,6)) AS total_stock_restricted_batches,
        CAST(SUM(CASE WHEN inventory_stock_type = '09' THEN matl_stk_change_qty_in_base_unit ELSE 0 END) AS DECIMAL(38,6)) AS tied_empties,
        CAST(SUM(CASE WHEN inventory_stock_type = '10' THEN matl_stk_change_qty_in_base_unit ELSE 0 END) AS DECIMAL(38,6)) AS valuated_goods_receipt_blocked_stock

    FROM movements_filtered
    GROUP BY all
),

-- ============================================================
-- Step 3 : Calculate Inventory Values + Cost Validity Window
-- ============================================================

priced_movements AS
(
    SELECT
        PBD.company_code,
        PBD.material,
        PBD.plant,
        PBD.storage_location,
        PBD.stock_segment,
        PBD.stock_identifying_batch,
        PBD.inventory_special_stock_type,
        PBD.material_base_unit,
        PBD.posting_date,

        -- Cost validity window from the cost table
        MP.valid_from_date AS cost_valid_from_date,
        MP.valid_to_date   AS cost_valid_to_date,

        -- Final price logic
        COALESCE( nullif( MP.moving_average_price,0),MP.standard_price, 0.00) AS price,
        COALESCE(MP.price_currency, '') AS price_currency,

        -- Quantities
        PBD.unrestricted_stock,
        PBD.stock_in_quality_inspection,
        PBD.blocked_stock_returns,
        PBD.stock_in_transfer_stloc,
        PBD.stock_in_transfer_plant,
        PBD.stock_in_transit,
        PBD.blocked_stock,
        PBD.total_stock_restricted_batches,
        PBD.tied_empties,
        PBD.valuated_goods_receipt_blocked_stock,

        -- Values (ALL use derived price)
        PBD.unrestricted_stock * COALESCE( nullif( MP.moving_average_price,0),MP.standard_price, 0.00) AS unrestricted_stock_value,
        PBD.stock_in_quality_inspection * COALESCE( nullif( MP.moving_average_price,0),MP.standard_price, 0.00) AS stock_in_quality_inspection_value,
        PBD.blocked_stock_returns * COALESCE( nullif( MP.moving_average_price,0),MP.standard_price, 0.00) AS blocked_stock_returns_value,
        PBD.stock_in_transfer_stloc * COALESCE( nullif( MP.moving_average_price,0),MP.standard_price, 0.00) AS stock_in_transfer_stloc_value,
        PBD.stock_in_transfer_plant * COALESCE( nullif( MP.moving_average_price,0),MP.standard_price, 0.00) AS stock_in_transfer_plant_value,
        PBD.stock_in_transit * COALESCE( nullif( MP.moving_average_price,0),MP.standard_price, 0.00) AS stock_in_transit_value,
        PBD.blocked_stock * COALESCE( nullif( MP.moving_average_price,0),MP.standard_price, 0.00) AS blocked_stock_value,
        PBD.total_stock_restricted_batches * COALESCE( nullif( MP.moving_average_price,0),MP.standard_price, 0.00) AS total_stock_restricted_batches_value,
        PBD.tied_empties * COALESCE( nullif( MP.moving_average_price,0),MP.standard_price, 0.00) AS tied_empties_value,
        PBD.valuated_goods_receipt_blocked_stock * COALESCE( nullif( MP.moving_average_price,0),MP.standard_price, 0.00) AS valuated_goods_receipt_blocked_stock_value

    FROM pivoted_by_posting_date PBD
    LEFT JOIN s3_gold.dim_plant_material_cost MP
        ON MP.material = PBD.material
        AND MP.plant = PBD.plant
        AND CAST(PBD.posting_date AS DATE)
            BETWEEN CAST(MP.valid_from_date AS DATE)
                AND CAST(MP.valid_to_date AS DATE)
),

-- ============================================================
-- Step 4 : Aggregate at (dimensions + posting_date) grain
-- ============================================================

aggregated_by_postingdate AS
(
    SELECT
        -----Dimensional columns--------
        PM.company_code,
        PM.material,
        PM.plant,
        PM.storage_location,
        PM.stock_segment,
        PM.stock_identifying_batch AS batch_id,
        PM.inventory_special_stock_type AS special_stock_indicator,
        PM.material_base_unit,
        PM.posting_date,
        CAST(SnapshotDate AS DATE) AS snapshot_date,

        -----Cost validity window--------
        PM.cost_valid_from_date,
        PM.cost_valid_to_date,

        ----Aggregated quantity columns---
        CAST(SUM(PM.unrestricted_stock) AS INT) AS unrestricted_stock,
        CAST(SUM(PM.stock_in_quality_inspection) AS INT) AS stock_in_quality_inspection,
        CAST(SUM(PM.blocked_stock_returns) AS INT) AS blocked_stock_returns,
        CAST(SUM(PM.stock_in_transfer_stloc) AS INT) AS stock_in_transfer_stloc,
        CAST(SUM(PM.stock_in_transfer_plant) AS INT) AS stock_in_transfer_plant,
        CAST(SUM(PM.stock_in_transit) AS INT) AS stock_in_transit,
        CAST(SUM(PM.blocked_stock) AS INT) AS blocked_stock,
        CAST(SUM(PM.total_stock_restricted_batches) AS INT) AS total_stock_restricted_batches,
        CAST(SUM(PM.tied_empties) AS INT) AS tied_empties,
        CAST(SUM(PM.valuated_goods_receipt_blocked_stock) AS INT) AS valuated_goods_receipt_blocked_stock,
        CAST(
            SUM(
                  PM.unrestricted_stock
                + PM.stock_in_quality_inspection
                + PM.blocked_stock_returns
                + PM.stock_in_transfer_stloc
                + PM.stock_in_transfer_plant
                + PM.stock_in_transit
                + PM.blocked_stock
                + PM.total_stock_restricted_batches
                + PM.tied_empties
                + PM.valuated_goods_receipt_blocked_stock
            )
        AS INT) AS total_stock_quantity,

        -----Aggregated value columns (quantity × price, summed)------
        CAST(SUM(PM.unrestricted_stock_value) AS DECIMAL(38,6)) AS unrestricted_stock_value,
        CAST(SUM(PM.stock_in_quality_inspection_value) AS DECIMAL(38,6)) AS stock_in_quality_inspection_value,
        CAST(SUM(PM.blocked_stock_returns_value) AS DECIMAL(38,6)) AS blocked_stock_returns_value,
        CAST(SUM(PM.stock_in_transfer_stloc_value) AS DECIMAL(38,6)) AS stock_in_transfer_stloc_value,
        CAST(SUM(PM.stock_in_transfer_plant_value) AS DECIMAL(38,6)) AS stock_in_transfer_plant_value,
        CAST(SUM(PM.stock_in_transit_value) AS DECIMAL(38,6)) AS stock_in_transit_value,
        CAST(SUM(PM.blocked_stock_value) AS DECIMAL(38,6)) AS blocked_stock_value,
        CAST(SUM(PM.total_stock_restricted_batches_value) AS DECIMAL(38,6)) AS total_stock_restricted_batches_value,
        CAST(SUM(PM.tied_empties_value) AS DECIMAL(38,6)) AS tied_empties_value,
        CAST(SUM(PM.valuated_goods_receipt_blocked_stock_value) AS DECIMAL(38,6)) AS valuated_goods_receipt_blocked_stock_value,
        CAST(
            SUM(
                  PM.unrestricted_stock_value
                + PM.stock_in_quality_inspection_value
                + PM.blocked_stock_returns_value
                + PM.stock_in_transfer_stloc_value
                + PM.stock_in_transfer_plant_value
                + PM.stock_in_transit_value
                + PM.blocked_stock_value
                + PM.total_stock_restricted_batches_value
                + PM.tied_empties_value
                + PM.valuated_goods_receipt_blocked_stock_value
            )
        AS DECIMAL(38,6)) AS total_stock_value

    FROM priced_movements PM
    GROUP BY all
)

-- ============================================================
-- Step 5 : Running Totals (quantities) + GROSS (day-over-day value delta)
-- ============================================================

SELECT
    ABD.*,

    ----Running totals per quantity field (full dimensional grain, ordered by posting_date)----
    CAST(SUM(ABD.unrestricted_stock) OVER w_full AS INT) AS running_unrestricted_stock,
    CAST(SUM(ABD.stock_in_quality_inspection) OVER w_full AS INT) AS running_stock_in_quality_inspection,
    CAST(SUM(ABD.blocked_stock_returns) OVER w_full AS INT) AS running_blocked_stock_returns,
    CAST(SUM(ABD.stock_in_transfer_stloc) OVER w_full AS INT) AS running_stock_in_transfer_stloc,
    CAST(SUM(ABD.stock_in_transfer_plant) OVER w_full AS INT) AS running_stock_in_transfer_plant,
    CAST(SUM(ABD.stock_in_transit) OVER w_full AS INT) AS running_stock_in_transit,
    CAST(SUM(ABD.blocked_stock) OVER w_full AS INT) AS running_blocked_stock,
    CAST(SUM(ABD.total_stock_restricted_batches) OVER w_full AS INT) AS running_total_stock_restricted_batches,
    CAST(SUM(ABD.tied_empties) OVER w_full AS INT) AS running_tied_empties,
    CAST(SUM(ABD.valuated_goods_receipt_blocked_stock) OVER w_full AS INT) AS running_valuated_goods_receipt_blocked_stock,
    CAST(SUM(ABD.total_stock_quantity) OVER w_full AS INT) AS running_total_stock_quantity,

    ----GROSS: day-over-day delta of total_stock_value, same full-grain partition as running totals----
    ----First posting_date in each series has no prior row, so falls back to the raw value (matches legacy ISNULL behavior)----
    CAST(LAG(ABD.total_stock_value) OVER w_lag AS DECIMAL(38,6)) AS previous_posting_date_stock_value,
    CAST(
        COALESCE(ABD.total_stock_value - LAG(ABD.total_stock_value) OVER w_lag, ABD.total_stock_value)
    AS DECIMAL(38,6)) AS gross

FROM aggregated_by_postingdate ABD

WINDOW
    -- Used for cumulative SUM (running totals) - requires an explicit ROWS frame
    w_full AS (
        PARTITION BY
            ABD.company_code,
            ABD.material,
            ABD.plant,
            ABD.storage_location,
            ABD.stock_segment,
            ABD.batch_id,
            ABD.special_stock_indicator,
            ABD.material_base_unit
        ORDER BY ABD.posting_date
        ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    ),
    -- Used for LAG (GROSS) - Databricks/Spark SQL rejects a frame clause on offset functions
    w_lag AS (
        PARTITION BY
            ABD.company_code,
            ABD.material,
            ABD.plant,
            ABD.storage_location,
            ABD.stock_segment,
            ABD.batch_id,
            ABD.special_stock_indicator,
            ABD.material_base_unit
        ORDER BY ABD.posting_date
    )
;