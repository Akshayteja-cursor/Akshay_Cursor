use catalog identifier(:catalog);

----- Table s4hana_invoice_rec_types
CREATE OR REPLACE TABLE s2_silver.s4hana_invoice_rec_types 
USING DELTA
CLUSTER BY auto -- can we use auto  ?
TBLPROPERTIES(
'delta.feature.allowColumnDefaults' = 'supported',
'delta.autoOptimize.optimizeWrite' = 'true',
'delta.autoOptimize.autoCompact' = 'true',
'delta.enableChangeDataFeed' = 'true'
)
AS 
SELECT * FROM VALUES
  (1, 'Invoice', 'ZRET', 'PUMA Returns'),
  (1, 'Invoice', 'ZPF9', 'PUMA Pro-forma for Prepayment'),
  (1, 'Invoice', 'S1', 'Cancel Invoice'),
  (1, 'Invoice', 'ZOPX', 'PUMA OPEX Debit Memo'),
  (1, 'Invoice', 'ZIDR', 'PUMA IC Debit Memo'),
  (1, 'Invoice', 'ZRIV', 'PUMA Intercomp. Billing Retail'),
  (1, 'Invoice', 'ZS1', 'PUMA E-com Cancel Invoice'),
  (2, 'Credit Note', 'S2', 'Cancel Cred. Memo'),
  (2, 'Credit Note', 'ZS4', 'PUMA Cancel Cred.Memo'),
  (1, 'Invoice', 'ZFIB', 'PUMA FOC Intern. Inv'),
  (1, 'Invoice', 'ZS5', 'PUMA IC Cancel Invoice'),
  (2, 'Credit Note', 'ZCRE', 'PUMA Credit Memo'),
  (1, 'Invoice', 'ZS3', 'PUMA Cancel Invoice'),
  (1, 'Invoice', 'FP', 'Billing POS-Interfce Training Store Sales'),
  (1, 'Invoice', 'ZFSB', 'PUMA FOC Self Bill'),
  (1, 'Invoice', 'ZECI', 'PUMA Invoice for Concessions'),
  (1, 'Invoice', 'ZFED', 'Billing POS-Interfce ECI daily'),
  (1, 'Invoice', 'ZPFP', 'Billing POS-Interfce for PT stores'),
  (2, 'Credit Note', 'ZICR', 'PUMA IC Credit Memo'),
  (1, 'Invoice', 'ZECO', 'ZECO - PUMA ECI Closeout'),
  (1, 'Invoice', 'ZCHR', 'PUMA Charity Billing'),
  (2, 'Credit Note', 'ZG2', 'PUMA Credit Memo Retail'),
  (1, 'Invoice', 'ZDEB', 'PUMA Debit Memo'),
  (1, 'Invoice', 'ZPF8', 'PUMA Pro-forma for Delivery?'),
  (2, 'Credit Note', 'ZS6', 'PUMA IC Cancel Cred.Memo'),
  (1, 'Invoice', 'ZPFE', 'Billing POS-Interfce PT ECI daily'),
  (2, 'Credit Note', 'ZRPX', 'PUMA OPEX Credit Memo'),
  (2, 'Credit Note', 'ZRE', 'PUMA Credit for Returns'),
  (2, 'Credit Note', 'ZS2', 'PUMA E-com Cancel Cred.Memo'),
  (1, 'Invoice', 'ZINT', 'Intercompany Billing'),
  (1, 'Invoice', 'ZF2', 'PUMA Invoice'),
  (1, 'Invoice', 'ZPF5', 'PUMA Pro-forma for Order'),
  (2, 'Credit Note', 'ZRIG', 'PUMA Internal Credit Memo')
AS tab(int_rec_type_code, mapping_desc, ebp_indicator, ebp_desc);

