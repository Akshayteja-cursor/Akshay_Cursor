use catalog identifier(:catalog);

CREATE OR REPLACE TABLE s2_silver.vat_rates
USING DELTA
CLUSTER BY auto
TBLPROPERTIES(
'delta.feature.allowColumnDefaults' = 'supported',
'delta.autoOptimize.optimizeWrite' = 'true',
'delta.autoOptimize.autoCompact' = 'true',
'delta.enableChangeDataFeed' = 'true'
)
AS
SELECT
    country_code,
    CAST(vat AS DECIMAL(6,2)) AS vat,
    CAST(valid_from AS DATE)  AS valid_from,
    CAST(valid_to   AS DATE)  AS valid_to
FROM VALUES
    ('AT', 20.0,  '2020-01-01', '9999-12-31'),
    ('BE', 21.0,  '2020-01-02', '9999-12-31'),
    ('CH', 7.7,   '2020-01-03', '9999-12-31'),
    ('CZ', 21.0,  '2020-01-04', '9999-12-31'),
    ('DE', 19.0,  '2021-01-01', '9999-12-31'),
    ('DE', 16.0,  '2020-07-01', '2020-12-31'),
    ('DK', 25.0,  '2020-01-01', '9999-12-31'),
    ('ES', 21.0,  '2020-01-01', '9999-12-31'),
    ('FR', 20.0,  '2020-01-01', '9999-12-31'),
    ('GB', 20.0,  '2020-01-01', '9999-12-31'),
    ('HU', 27.0,  '2020-01-01', '9999-12-31'),
    ('IE', 21.0,  '2020-09-01', '2021-02-28'),
    ('IE', 23.0,  '2021-03-01', '9999-12-31'),
    ('IT', 22.0,  '2020-01-01', '9999-12-31'),
    ('NL', 21.0,  '2020-01-01', '9999-12-31'),
    ('NO', 25.0,  '2020-01-01', '9999-12-31'),
    ('PL', 23.0,  '2020-01-01', '9999-12-31'),
    ('PT', 23.0,  '2020-01-01', '9999-12-31'),
    ('SE', 25.0,  '2020-01-01', '9999-12-31')
AS tab(country_code, vat, valid_from, valid_to);
