use catalog identifier(:catalog);

---- Table s4hana_copa_active_semantic_tags
CREATE OR REPLACE TABLE s2_silver.s4hana_copa_active_semantic_tags 
USING DELTA
CLUSTER BY auto -- can we use auto  ?
TBLPROPERTIES(
'delta.feature.allowColumnDefaults' = 'supported',
'delta.autoOptimize.optimizeWrite' = 'true',
'delta.autoOptimize.autoCompact' = 'true',
'delta.enableChangeDataFeed' = 'true'
)
AS 
SELECT * FROM VALUES
  (1, 'ZR3017GS3P', 1),
  (2, 'ZR3018GSIC', 1),
  (3, 'ZR3020GSBF', 1),
  (4, 'ZR3024OIDS', 1),
  (5, 'ZR3026OIDI', 1),
  (6, 'ZR3032SMSP', 1),
  (7, 'ZR3033GRSB', 1),
  (8, 'ZR3034DELP', 1),
  (9, 'ZR3035RETM', 1),
  (10, 'ZR3038OIDA', 1),
  (11, 'ZR3040RASL', 1),
  (12, 'ZR3041NSTP', 1),
  (13, 'ZR3042NSIC', 1),
  (14, 'ZR3044NSIF', 1),
  (15, 'ZR3046CFTP', 1),
  (16, 'ZR3052MCTP', 1),
  (17, 'ZR3059ICCM', 1),
  (18, 'ZR3062CFIC', 1),
  (19, 'ZR3064CGIC', 1),
  (20, 'ZR3066CBMP', 0),
  (21, 'ZR3068CBMU', 1),
  (22, 'ZR3069SHRT', 1),
  (23, 'ZR3070COGF', 1),
  (24, 'ZR3071OCOG', 1),
  (25, 'ZR3073CIIR', 1),
  (26, 'ZR3074CGLD', 1),
  (27, 'ZR3077RACG', 1),
  (28, 'ZR3152OSA', 1),
  (29, 'ZR3153OCA', 1),
  (48, 'ZR3050UDTP', 1),
  (54, 'ZR3048FRTP', 1),
  (66, 'ZR3047DUTP', 1),
  (69, 'ZR3097CNCN', 1),
  (87, 'ZR3155OSUB', 1),
  (114, 'ZR3049ISTP', 1),
  (142, 'ZR3201ISWV', 1),
  (190, 'ZR3204FIBS', 1)
AS tab(copa_active_semantic_tag_id, semantic_tag, is_active);
