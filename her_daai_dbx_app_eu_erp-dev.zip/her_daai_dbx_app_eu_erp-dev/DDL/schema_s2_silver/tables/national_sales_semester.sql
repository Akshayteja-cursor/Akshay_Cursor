USE CATALOG IDENTIFIER(:catalog);

CREATE TABLE if NOT EXISTS s2_silver.national_sales_semester (
  SellInDate DATE,
  SalesSemester STRING COLLATE UTF8_BINARY,
  SalesSemesterLY STRING COLLATE UTF8_BINARY,
  StartSellInSeasonCreationDate DATE,
  EndSellInSeasonCreationDate DATE,
  StartEarlyIntroPickDate DATE,
  EndEarlyIntroPickDate DATE,
  StartRegularDate DATE,
  EndRegularDate DATE,
  SellInYear INT,
  SellInSemester STRING COLLATE UTF8_BINARY)
USING delta
CLUSTER BY AUTO
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.checkpointPolicy' = 'v2',
  'delta.enableDeletionVectors' = 'true',
  'delta.enableRowTracking' = 'true',
  'delta.feature.appendOnly' = 'supported',
  'delta.feature.deletionVectors' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.feature.rowTracking' = 'supported',
  'delta.feature.v2Checkpoint' = 'supported',
  'delta.parquet.compression.codec' = 'zstd')
  ;
