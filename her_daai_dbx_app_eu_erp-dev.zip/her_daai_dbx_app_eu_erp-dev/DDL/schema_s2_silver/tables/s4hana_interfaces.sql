use catalog identifier(:catalog);

----- Table s4hana_interfaces
CREATE OR REPLACE TABLE s2_silver.s4hana_interfaces 
USING DELTA
CLUSTER BY auto -- can we use auto  ?
TBLPROPERTIES(
'delta.feature.allowColumnDefaults' = 'supported',
'delta.autoOptimize.optimizeWrite' = 'true',
'delta.autoOptimize.autoCompact' = 'true',
'delta.enableChangeDataFeed' = 'true'
)
AS 
SELECT * FROM VALUES
  (2, 'BII', 'RetailEurope', 1423, 15789, 'PLPEGLE', 'RetailEurope', '', '', '', '', null),
  (4, 'BII', 'Argentina', 652, -1040, 'PLARGLD', 'PUMA Argentina Dom (PC)', '', '', '', '', null),
  (28, 'EBP', 'Italy', 520, -2360, 'PLITALD', 'PUMA Italy Dom (PC)', '1254', 'IT10', 'ITPUI', 'EU', '1010'),
  (37, 'BII', 'Argentina', 1318, 14739, 'PLARGLD', 'PUMA Argentina Dom (PC)', '', '', '', '', null),
  (41, 'BII', 'CHILE', 1200000, 2240, 'PLCHLLD', 'PUMA Chile Dom (PC)', '', '', '', '', null),
  (45, 'BII', 'PERU', 1000000, 1080, 'PLPERLD', 'PUMA Peru Dom (PC)', '', '', '', '', null),
  (47, 'EBP', 'Iberia', 540, -2160, 'PLESPLD', 'PUMA Iberia Spain Dom (PC)', '1255', 'ES10', 'ESPUE', 'EU', '1030'),
  (49, 'EBP', 'RetailEuropeSAP', 1425, 15919, 'PLPEGLE', 'RetailEurope', '1196', 'DE11', 'DERET', 'EU', null),
  (53, 'EBP', 'Iberia', 540, -2160, 'PLPRTLD', 'PUMA Portugal Dom (PC)', '1255', 'PT10', 'ESPUE', 'EU', '1050'),
  (118, 'EBP', 'France', 1001, 1001, 'PLFRALD', 'PUMA France (PC)', '1001', 'FR10', 'FRPUF', 'EU', '2100'),
  (152, 'EBP', 'CEU', 205, 2420, 'PLGERLD', 'PUMA Germany', '', 'DE19', 'DEPUD', 'EU', '2000'),
  (212, 'EBP', 'CEU', 205, 2420, 'PLBEXLN', 'PUMA Benelux NLD (PC)', '', 'NL19', '', 'EU', '1070'),
  (272, 'EBP', 'CEU', 205, 2420, 'PLSWILD', 'PUMA Switzerland Dom (PC)', '', 'CH19', '', 'EU', '1130'),
  (332, 'EBP', 'CEU', 205, 2420, 'PLAUTLD', 'PUMA Switzerland Dom (PC)', '', 'AT19', '', 'EU', '1110'),
  (392, 'EBP', 'CEU', 205, 2420, 'PLBEXLB', 'PUMA Benelux BEL (PC)', '', 'BE19', '', 'EU', '1090')
AS tab(id, interface, country,  int_put_pup_master_id, int_pup_no, pdu_code, pdu_desc, source_system_detail_id, company_code, sourcing_customer_code, region_code, sales_org);
