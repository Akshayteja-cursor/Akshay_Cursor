use catalog identifier(:catalog);

CREATE OR REPLACE TABLE s2_silver.s4hana_invoice_price_types 
USING DELTA
CLUSTER BY auto -- can we use auto  ?
TBLPROPERTIES(
'delta.feature.allowColumnDefaults' = 'supported',
'delta.autoOptimize.optimizeWrite' = 'true',
'delta.autoOptimize.autoCompact' = 'true',
'delta.enableChangeDataFeed' = 'true'
)
AS
SELECT * FROM VALUES
  ('1', 'Regular', 'ZF2', 'PUMA Invoice', '4'),
  ('1', 'Regular', 'ZFED', 'Billing POS-Interface ECI daily', '9'),
  ('1', 'Regular', 'ZG2', 'PUMA Credit Memo Retail', '64'),
  ('1', 'Regular', 'ZCRE', 'PUMA Credit Memo', '124'),
  ('1', 'Regular', 'ZRET', 'PUMA Returns', '184'),
  ('1', 'Regular', 'ZDEB', 'PUMA Debit Memo', '244'),
  ('1', 'Regular', 'ZECI', 'PUMA Invoice for Concessions', '304'),
  ('3', 'Others', 'ZPF5', 'PUMA Pro-forma for Order', '364'),
  ('3', 'Others', 'ZPF8', 'PUMA Pro-forma for Delivery?', '424'),
  ('3', 'Others', 'ZPF9', 'PUMA Pro-forma for Prepayment', '484'),
  ('1', 'Regular', 'ZS1', 'PUMA E-com Cancel Invoice', '544'),
  ('1', 'Regular', 'ZS2', 'PUMA E-com Cancel Cred.Memo', '604'),
  ('1', 'Regular', 'ZS3', 'PUMA Cancel Invoice', '664'),
  ('1', 'Regular', 'ZS4', 'PUMA Cancel Cred.Memo', '724'),
  ('3', 'Others', 'ZFIB', 'PUMA FOC Intern. Inv', '784'),
  ('3', 'Others', 'ZFSB', 'PUMA FOC Self Bill', '844'),
  ('3', 'Others', 'ZOPX', 'PUMA OPEX Debit Memo', '904'),
  ('3', 'Others', 'ZRPX', 'PUMA OPEX Credit Memo', '964'),
  ('3', 'Others', 'ZRIG', 'PUMA Internal Credit Memo', '1024'),
  ('3', 'Others', 'ZRIV', 'PUMA Intercomp. Billing Retail', '1084'),
  ('3', 'Others', 'ZCHR', 'PUMA Charity Billing', '1144'),
  ('2', 'Close Out', 'ZECO', 'ZECO - PUMA ECI Closeout', '1204'),
  ('3', 'Others', 'ZINT', 'Intercompany Billing', '1264'),
  ('3', 'Others', 'ZICR', 'PUMA IC Credit Memo', '1324'),
  ('3', 'Others', 'ZIDR', 'PUMA IC Debit Memo', '1384'),
  ('3', 'Others', 'ZS5', 'PUMA IC Cancel Invoice', '1444'),
  ('3', 'Others', 'ZS6', 'PUMA IC Cancel Cred.Memo', '1504'),
  ('1', 'Regular', 'S1', 'Cancel Invoice', '1564'),
  ('1', 'Regular', 'S2', 'Cancel Cred. Memo', '1624'),
  ('1', 'Regular', 'ZRE', 'PUMA Credit for Returns', '1684'),
  ('1', 'Regular', 'ZPFE', 'Billing POS-Interfce PT ECI daily', '1744'),
  ('1', 'Regular', 'ZPFP', 'Billing POS-Interfce for PT stores', '1804')
AS tab(int_invoice_price_type_code , mapping_desc, nat_invoice_type_code, ebp_des, price_id);