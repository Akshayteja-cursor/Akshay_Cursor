use catalog identifier(:catalog);

----- Table s4hana_so_price_types
CREATE OR REPLACE TABLE s2_silver.s4hana_so_price_types
USING DELTA
CLUSTER BY auto -- can we use auto  ?
TBLPROPERTIES(
'delta.feature.allowColumnDefaults' = 'supported',
'delta.autoOptimize.optimizeWrite' = 'true',
'delta.autoOptimize.autoCompact' = 'true',
'delta.enableChangeDataFeed' = 'true'
)
AS
SELECT * FROM VALUES
  (1, 'Regular', 'ZROC', 'PUMA Reorder Contr', 1),
  (3, 'Others', 'ZCRR', 'PUMA CR Request WR', 2),
  (3, 'Others', 'ZCSC', 'PUMA Consignm. Contr', 3),
  (2, 'Close Out', 'ZCLO', 'PUMA Close out Order', 5),
  (1, 'Regular', 'ZPOC', 'PUMA Preorder Contr', 8),
  (2, 'Close Out', 'ZECO', 'PUMA ECI close out', 9),
  (3, 'Others', 'ZOPX', 'PUMA OPEX Sale', 11),
  (3, 'Others', 'ZICR', 'PUMA IC CR Request', 14),
  (1, 'Regular', 'ZERE', 'PUMA E-com Returns', 17),
  (1, 'Regular', 'ZPTO', 'PUMA Purch. to Order', 18),
  (1, 'Regular', 'ZPKP', 'PUMA Consignm CroDoc', 20),
  (3, 'Others', 'ZFCI', 'PUMA FOC Cross Inv', 22),
  (1, 'Regular', 'ZRUS', 'PUMA Rush Order', 24),
  (3, 'Others', 'ZPDR', 'PUMA Debit Memo Req', 27),
  (1, 'Regular', 'ZIC', 'PUMA InterComp Order', 28),
  (3, 'Others', 'ZMKC', 'PUMA  Marketing Contr', 29),
  (3, 'Others', 'ZDRR', 'PUMA DB Request WR', 31),
  (1, 'Regular', 'ZECM', 'PUMA E-com Order', 32),
  (1, 'Regular', 'ZINT', 'PUMA IC Orders', 34),
  (1, 'Regular', 'ZPKB', 'PUMA Consignm FillUp', 35),
  (3, 'Others', 'ZPCR', 'PUMA Credit Memo Req', 36),
  (1, 'Regular', 'ZRES', 'PUMA Partner Contrac', 37),
  (1, 'Regular', 'ZDIS', 'PUMA Direct Ship', 38),
  (3, 'Others', 'ZCHR', 'PUMA Charity Orders', 40),
  (3, 'Others', 'ZERA', 'PUMA E-com Add. Disc', 41),
  (1, 'Regular', 'ZPKA', 'PUMA Consignm PickUp', 43),
  (1, 'Regular', 'ZRET', 'PUMA Return Order', 46),
  (3, 'Others', 'ZFIB', 'PUMA FOC Intern. Inv', 50),
  (1, 'Regular', 'ZPRE', 'PUMA Preorders', 52),
  (3, 'Others', 'ZRAU', 'PUMA Return Authoriz', 53),
  (1, 'Regular', 'ZPKE', 'PUMA Consignm Issue', 55),
  (1, 'Regular', 'ZREO', 'PUMA Reorders', 57),
  (3, 'Others', 'ZPSB', 'PUMA Photo-Sht Fill ', 60),
  (3, 'Others', 'ZIDR', 'PUMA IC DB Request', 65),
  (2, 'Close Out', 'ZCLS', 'PUMA CI out ResContr', 82),
  (3, 'Others', 'ZFSB', 'PUMA FOC Self Bill.', 88),
  (3, 'Others', 'ZRPX', 'PUMA OPEX Credit Memo ', 91),
  (3, 'Others', 'ZCOC', 'PUMA Concessi. Contr ', 95),
  (1, 'Regular', 'ZPKR', 'PUMA Consignm Return', 103),
  (3, 'Others', 'ZINO', 'PUMA Internal Orders', 115),
  (3, 'Regular', 'ZCR', 'PUMA CR Retail PT', 155),
  (2, 'Close Out', 'ZCCN', 'PUMA Concession Ord. Close Out', 163),
  (1, 'Regular', 'ZMIX', 'PUMA Mixed Order', 56)
AS tab( int_so_price_type_code, mapping_desc, so_type_code, ebp_desc, id);
