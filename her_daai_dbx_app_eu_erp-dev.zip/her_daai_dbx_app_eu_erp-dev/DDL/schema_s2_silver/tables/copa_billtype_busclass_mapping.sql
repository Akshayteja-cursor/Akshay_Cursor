use catalog identifier(:catalog);

----- Table copa_billtype_busclass_mapping
CREATE OR REPLACE TABLE s2_silver.copa_billtype_busclass_mapping 
USING DELTA
CLUSTER BY auto -- can we use auto  ?
TBLPROPERTIES(
'delta.feature.allowColumnDefaults' = 'supported',
'delta.autoOptimize.optimizeWrite' = 'true',
'delta.autoOptimize.autoCompact' = 'true',
'delta.enableChangeDataFeed' = 'true'
)
AS
SELECT * FROM VALUES
  (1, '', 'Not assigned', '10', '3rd', ''),
  (2, 'FP', 'Billing POS-Interfce', '10', '3rd', ''),
  (3, 'ZCRE', 'PUMA Credit Memo', '10', '3rd', ''),
  (4, 'ZDEB', 'PUMA Debit Memo', '10', '3rd', ''),
  (5, 'ZECO', 'ZECO - PUMA ECI Closeout', '10', '3rd', ''),
  (6, 'ZF2', 'PUMA Invoice', '10', '3rd', ''),
  (7, 'ZFED', 'Billing POS-Interfce ECI daily', '10', '3rd', ''),
  (8, 'ZICV', 'Intercompany Billing', '30', 'IC', ''),
  (9, 'ZIGS', 'Cancel ICM', '50', 'BFT', ''),
  (10, 'ZOPX', 'PUMA OPEX Debit Memo', '10', '3rd', ''),
  (11, 'ZPFE', 'Billing POS-Interfce PT ECI daily', '10', '3rd', ''),
  (12, 'ZPFT', 'PUMA Branch FoC Flash Transfer', '50', 'BFT', ''),
  (13, 'ZRET', 'PUMA Returns', '10', '3rd', ''),
  (14, 'ZRIG', 'Internal Credit Memo', '50', 'BFT', ''),
  (15, 'ZRIV', 'Intercompany Billing - Retail', '50', 'BFT', ''),
  (16, 'ZRPX', 'PUMA OPEX Credit Memo', '10', '3rd', ''),
  (17, 'ZS3', 'PUMA Cancel Invoice', '10', '3rd', ''),
  (18, 'ZS4', 'PUMA Cancel Cred.Memo', '10', '3rd', ''),
  (19, 'ZS5', 'PUMA IC Cancel Invoice', '30', 'IC', ''),
  (20, 'ZICC', 'Cancel Intercompany Billing', '30', 'IC', ''),
  (21, 'ZICR', 'PUMA IC Credit Memo', '30', 'IC', ''),
  (22, 'ZIDR', 'PUMA IC Debit Memo', '30', 'IC', ''),
  (23, 'ZINT', 'Intercompany Billing', '30', 'IC', ''),
  (24, 'ZBFT', 'PUMA Branch Flash Transfer', '50', 'BFT', ''),
  (25, 'ZFRT', 'PUMA Branch Flash Transfer Return', '50', 'BFT', ''),
  (26, 'ZGBS', 'PUMA Branch Return Cancellation', '50', 'BFT', ''),
  (27, 'ZVBT', 'PUMA Branch Flash Cancellation', '50', 'BFT', ''),
  (28, 'ZVPT', 'PUMA Branch FoC Flash Tranfer Cancelatio', '50', 'BFT', ''),
  (42, 'ZFP2', 'POS B2B Returns', '10', '3rd', ''),
  (57, 'ZFP1', 'POS B2B Sales', '10', '3rd', '')
AS tab(copa_billtype_busclass_id, billing_doc_type_code, billing_doc_type_desc, business_class_code, business_class_desc, modified_on);

