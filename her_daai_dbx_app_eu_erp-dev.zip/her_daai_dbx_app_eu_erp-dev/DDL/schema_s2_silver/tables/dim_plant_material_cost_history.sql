USE CATALOG IDENTIFIER(:catalog);

CREATE TABLE IF NOT EXISTS s2_silver.dim_plant_material_cost_history
USING DELTA
CLUSTER BY AUTO
AS
SELECT
    __timestamp            AS __timestamp,
    Material               AS material,
    Plant                  AS plant,
    ValuationType          AS valuation_type,
    FiscalYear             AS fiscal_year,
    FiscalMonth            AS fiscal_month,
    FiscalDay              AS fiscal_day,
    PriceControlIndicator  AS price_control_indicator,
    MovingAveragePrice     AS moving_average_price,
    StandardPrice          AS standard_price,
    PriceUnit              AS price_unit,
    PriceCurrency          AS price_currency,
    LastChangedAt          AS last_changed_at,
    VALIDFROMDAT           AS valid_from_dat,
    VALIDTODAT             AS valid_to_dat,
    CompanyCode            AS company_code,
    Country                AS country,
    __operation_type       AS __operation_type,
    _LDTS                  AS _ldts,
    ModifiedOn             AS modified_on,
    _ingestion_timestamp   AS _ingestion_timestamp,
    _source_system         AS _source_system
FROM delta.`/Volumes/{catalog}/s1_bronze_ebp/upload/plant_material_cost_history/`;