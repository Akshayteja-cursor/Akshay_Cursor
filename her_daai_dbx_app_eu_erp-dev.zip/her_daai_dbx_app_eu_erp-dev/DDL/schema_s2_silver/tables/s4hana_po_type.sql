use catalog identifier(:catalog);

CREATE OR REPLACE TABLE s2_silver.s4hana_po_type
USING DELTA
CLUSTER BY auto -- can we use auto  ?
TBLPROPERTIES(
'delta.feature.allowColumnDefaults' = 'supported',
'delta.autoOptimize.optimizeWrite' = 'true',
'delta.autoOptimize.autoCompact' = 'true',
'delta.enableChangeDataFeed' = 'true'
)
AS
SELECT * FROM VALUES
  ('15', '10', 'Standard', 'ZI02', 'InterCo Sample PO'),
  ('49', '40', 'Internal Stock Movements', 'ZCON', 'Intra Comp Con STO'),
  ('75', '10', 'Standard', 'ZI01', 'InterCO Merch PO'),
  ('135', '20', 'Cross Docking', 'ZBDD', 'SCO PO Dedicated B/S'),
  ('195', '10', 'Standard', 'ZSCO', 'SourceCo PO Imp'),
  ('255', '30', 'Direct Shipment', 'ZBDI', 'SCO PO Direct B/S'),
  ('315', '10', 'Standard', 'ZE01', '3rd Party PO'),
  ('375', '20', 'Cross Docking', 'ZIDD', 'SCO PO Dedicated Imp'),
  ('435', '10', 'Standard', 'ZSLO', 'SourceCo L4L'),
  ('495', '30', 'Direct Shipment', 'ZIDI', 'SCO PO Direct Imp'),
  ('555', '10', 'Standard', 'ZSCB', 'SourceCo PO B/S'),
  ('592', '30', 'Direct Shipment', 'ZEDI', 'Teamwear PO Direct'),
  ('613', '10', 'Standard', 'ZSUB', 'Subcontracting')
AS tab(po_type_id, int_po_type_code, mapping_desc, ebp_indicator, ebp_desc);