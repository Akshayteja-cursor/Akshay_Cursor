use catalog identifier(:catalog);

----- Table s4hana_salestypes
-- Create second table (sales types mapping)
CREATE OR REPLACE TABLE s2_silver.s4hana_salestypes  
USING DELTA
CLUSTER BY auto -- can we use auto  ?
TBLPROPERTIES(
'delta.feature.allowColumnDefaults' = 'supported',
'delta.autoOptimize.optimizeWrite' = 'true',
'delta.autoOptimize.autoCompact' = 'true',
'delta.enableChangeDataFeed' = 'true'
)
AS
SELECT * FROM VALUES
  (1, 1, 'Pre Order', 'ZPRE', 'PUMA Preorders', 1, 1, 'Pre Order'),
  (2, 2, 'Re Order', 'ZCCN', 'PUMA Concession Ord. Close Out', 1, 0, 'Other'),
  (3, 16, 'Close-Out', 'ZCLO', 'PUMA Close out Order', 1, 1, 'Clearance'),
  (4, 16, 'Close-Out', 'ZECO', 'PUMA ECI close out', 1, 0, 'Other'),
  (5, 2, 'Re Order', 'ZREO', 'PUMA Reorders', 1, 1, 'Re Order'),
  (6, 3, 'Return Order', 'ZCR', 'PUMA CR Retail PT', 0, 0, 'Other'),
  (7, 3, 'Return Order', 'ZCRR', 'PUMA CR Request WR', 0, 0, 'Other'),
  (8, 3, 'Return Order', 'ZERE', 'PUMA E-com Returns', 0, 0, 'Other'),
  (9, 3, 'Return Order', 'ZPCR', 'PUMA Credit Memo Req', 0, 0, 'Other'),
  (10, 17, 'Pre Order contract', 'ZPOC', 'PUMA Preorder Contr', 1, 0, 'Other'),
  (11, 18, 'Re Order contract', 'ZROC', 'PUMA Reorder Contr', 1, 1, 'Re Order'),
  (12, 9, 'Undefined', 'ZDRR', 'PUMA DB Request WR', 0, 0, 'Other'),
  (13, 9, 'Undefined', 'ZECM', 'PUMA E-com Order', 0, 0, 'Other'),
  (14, 9, 'Undefined', 'ZERA', 'PUMA E-com Add. Disc', 0, 0, 'Other'),
  (15, 9, 'Undefined', 'ZIC', 'PUMA InterComp Order', 0, 0, 'Other'),
  (16, 9, 'Undefined', 'ZINT', 'PUMA IC Orders', 0, 0, 'Intercompany'),
  (17, 9, 'Undefined', 'ZPDR', 'PUMA Debit Memo Req', 0, 0, 'Other'),
  (18, 14, 'Consignment contract', 'ZPKA', 'PUMA Consignm PickUp', 0, 0, 'Other'),
  (19, 14, 'Consignment contract', 'ZPKB', 'PUMA Consignm FillUp', 0, 0, 'Other'),
  (20, 14, 'Consignment contract', 'ZPKE', 'PUMA Consignm Issue', 0, 0, 'Other'),
  (21, 14, 'Consignment contract', 'ZPKP', 'PUMA Consignm CroDoc', 0, 0, 'Other'),
  (22, 14, 'Consignment contract', 'ZPKR', 'PUMA Consignm Return', 0, 0, 'Other'),
  (23, 3, 'Return Order', 'ZRET', 'PUMA Return Order', 0, 0, 'Other'),
  (24, 10, 'Rush Order', 'ZRUS', 'PUMA Rush Order', 1, 1, 'Re Order'),
  (25, 11, 'Delivery Free of Charge', 'ZFCI', 'PUMA FOC Cross Inv', 0, 0, 'Other'),
  (26, 11, 'Delivery Free of Charge', 'ZFIB', 'PUMA FOC Intern. Inv', 0, 0, 'Other'),
  (27, 11, 'Delivery Free of Charge', 'ZFSB', 'PUMA FOC Self Bill.', 0, 0, 'Other'),
  (28, 12, 'Standard contract', 'ZMKC', 'PUMA  Marketing Contr', 0, 0, 'Other'),
  (29, 13, 'Direct shipment/Cross Docking', 'ZDIS', 'PUMA Direct Ship', 1, 1, 'Pre Order'),
  (30, 13, 'Direct shipment/Cross Docking', 'ZPTO', 'PUMA Purch. to Order', 1, 1, 'Pre Order'),
  (31, 14, 'Consignment contract', 'ZCSC', 'PUMA Consignm. Contr', 0, 0, 'Other'),
  (32, 15, 'Concession contract', 'ZCOC', 'PUMA Concessi. Contr ', 0, 0, 'Other'),
  (79, 9, 'Undefined', 'ZCLS', 'PUMA Cl out ResContr', 0, 1, 'Clearance'),
  (139, 9, 'Undefined', 'ZRES', 'PUMA Partner Contrac', 0, 0, 'Other'),
  (141, 1, 'Pre Order', 'ZPTD', 'PUMA Dedicated Call-off', 1, 1, 'Pre Order'),
  (192, 17, 'Pre Order contract', 'ZCCD', 'PUMA Dedicat. Contr.', 1, 1, 'Pre Order'),
  (196, 14, 'Consignment contract', 'ZPKC', 'PUMA Consignm FillUp Cross border', 0, 0, ''),
  (223, 9, 'Undefined', 'ZARC', 'PUMA Auto Rep Contr', 0, 0, 'Other'),
  (225, 13, 'Direct shipment/Cross Docking', 'ZDIL', 'PUMA Direct Ship - Local Vendor', 1, 1, 'Pre Order'),
  (240, 2, 'Re Order', 'ZTWR', 'PUMA Teamwear', 1, 1, 'Re Order'),
  (241, 3, 'Return Order', 'ZRAU', 'PUMA Return Authoriz', 0, 0, 'Other'),
  (245, 9, 'Undefined', 'ZSCP', 'PUMA Scrap Order', 0, 0, 'Other'),
  (256, 14, 'Consignment contract', 'ZPKD', 'PUMA Consignment fill up - Cross dock - Cross border', 0, 0, ''),
  (259, 11, 'Delivery Free of Charge', 'ZINO', 'PUMA Internal Orders', 0, 0, ''),
  (271, 14, 'Consignment contract', 'ZPKF', 'PUMA Consignment pick up - Cross border', 0, 0, ''),
  (275, 11, 'Delivery Free of Charge', 'ZFSD', 'PUMA Sales Deals', 0, 0, 'Other'),
  (300, 2, 'Re Order', 'ZCLB', 'PUMA Clubmaker', 1, 1, 'Re Order'),
  (319, 11, 'Delivery Free of Charge', 'ZCHR', 'PUMA Charity Orders', 0, 0, ''),
  (340, 11, 'Delivery Free of Charge', 'ZPSM', 'PUMA IS Management', 0, 0, ''),
  (386, 1, 'Pre Order', 'ZMIX', 'PUMA Mixed Order', 1, 0, 'Pre Order'),
  (404, 9, 'Undefined', 'ZOPX', 'PUMA OPEX Sale', 0, 0, 'Intercompany'),
  (409, 9, 'Undefined', 'ZRPX', 'PUMA OPEX CreditMemo', 0, 0, 'Other')
AS tab(sales_types_ebp_id,int_sales_type,mapping_desc,so_type_code,ebp_desc,is_finance_ooh,sec_business_perimeter,order_business_type);
