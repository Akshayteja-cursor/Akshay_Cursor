use catalog identifier(:catalog);


----Table dim_so_rejection_dates
CREATE TABLE if not EXISTS s2_silver.dim_so_rejection_dates (
  fact_so_item_pk STRING,
  sales_order STRING,
  sales_order_item STRING,
  rejection_date DATE,
  load_timestamp TIMESTAMP)
USING delta
CLUSTER BY auto -- can we use auto  ?
TBLPROPERTIES (
  'delta.checkpoint.writeStatsAsJson' = 'false',
  'delta.checkpoint.writeStatsAsStruct' = 'true',
  'delta.enableDeletionVectors' = 'true',
  'delta.feature.appendOnly' = 'supported',
  'delta.feature.deletionVectors' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.enableChangeDataFeed' = 'true',
  'delta.minReaderVersion' = '3',
  'delta.minWriterVersion' = '7',
  'delta.parquet.compression.codec' = 'zstd');