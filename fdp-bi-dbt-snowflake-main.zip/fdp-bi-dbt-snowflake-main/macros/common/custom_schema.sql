{% macro generate_schema_name(custom_schema_name, node) -%}
    {%- set default_schema = target.schema -%}
    {%- set default_tg_name = target.name -%}
    {%- if default_tg_name =="Snowflake_BI_DEV" or default_tg_name =="Snowflake_BI_PROD" or default_tg_name =="Snowflake_BI_QA" -%}
        {%- if custom_schema_name is none  -%}
            {{ default_schema }}
        {%- else -%}
            {{ custom_schema_name | trim }}
        {%- endif -%}
    {%- else -%}
        {%- if custom_schema_name is none  -%}
            {{ default_schema }}
        {%- else -%}
           {{ custom_schema_name | trim }}
        {%- endif -%}
    {%- endif -%}
{%- endmacro %}