-- Set the database context to DI_PROD
USE DATABASE DI_PROD;
-- Create the schema if it doesn't exist
CREATE SCHEMA IF NOT EXISTS CICD;

-- Drop the table if it exists
DROP TABLE IF EXISTS CICD.TESTCICD;

-- Create a new table

CREATE TABLE CICD.TESTCICD (
    COL1 VARCHAR(100),
    COL2 VARCHAR(100)
);