create database DI_DEV;
create database DI_QA;