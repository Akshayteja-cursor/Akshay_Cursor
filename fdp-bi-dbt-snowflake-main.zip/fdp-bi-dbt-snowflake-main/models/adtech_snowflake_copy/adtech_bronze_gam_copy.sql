{{config(materialized='view',pre_hook=before_begin(
"
TRUNCATE TABLE IF EXISTS bi_prod.bronze_ads.gam_ad_category;
copy into bi_prod.bronze_ads.gam_ad_category from ( select 
 $1:_row:: bigint
,$1:ad_category_name:: varchar(256)
,$1:ad_unit_name:: varchar(256)
,$1:_fivetran_synced:: timestamp
from @BI_PROD.BRONZE_ADS.STG_ADS
(file_format=>BI_PROD.BRONZE_ADS.FF_ADS_PARQUET,pattern=>'.*/stg_gam_ad_category_custom/.*')t);


TRUNCATE TABLE IF EXISTS bi_prod.bronze_ads.gam_ad_format;
copy into bi_prod.bronze_ads.gam_ad_format from ( select 
 $1:_row:: bigint
,$1:ad_format_name:: varchar(256)
,$1:ad_unit_name:: varchar(256)
,$1:ad_detail_name:: varchar(256)
,$1:_fivetran_synced:: timestamp
from @BI_PROD.BRONZE_ADS.STG_ADS
(file_format=>BI_PROD.BRONZE_ADS.FF_ADS_PARQUET,pattern=>'.*/stg_gam_ad_format_custom/.*')t);


TRUNCATE TABLE IF EXISTS bi_prod.bronze_ads.gam_ad_unit;
copy into bi_prod.bronze_ads.gam_ad_unit from ( select 
 $1:dimension_date:: date
,$1:_fivetran_id:: varchar(256)
,$1:dimension_attribute_ad_unit_code:: varchar(256)
,$1:column_total_line_item_level_impressions:: bigint
,$1:dimension_ad_unit_id:: bigint
,$1:dimension_ad_unit_name:: varchar(256)
,$1:_fivetran_synced:: timestamp
from @BI_PROD.BRONZE_ADS.STG_ADS
(file_format=>BI_PROD.BRONZE_ADS.FF_ADS_PARQUET,pattern=>'.*/stg_gam_ad_unit/.*')t);


TRUNCATE TABLE IF EXISTS bi_prod.bronze_ads.gam_advertiser;
copy into bi_prod.bronze_ads.gam_advertiser from ( select 
 $1:dimension_date:: date
,$1:_fivetran_id:: varchar(256)
,$1:dimension_ad_type_name:: varchar(256)
,$1:dimension_attribute_advertiser_credit_status:: varchar(256)
,$1:dimension_ad_type_id:: bigint
,$1:column_total_line_item_level_impressions:: bigint
,$1:dimension_attribute_advertiser_type:: varchar(256)
,$1:dimension_advertiser_name:: varchar(256)
,$1:dimension_advertiser_id:: bigint
,$1:_fivetran_synced:: timestamp
from @BI_PROD.BRONZE_ADS.STG_ADS
(file_format=>BI_PROD.BRONZE_ADS.FF_ADS_PARQUET,pattern=>'.*/stg_gam_advertiser/.*')t);

TRUNCATE TABLE IF EXISTS bi_prod.bronze_ads.gam_content;
copy into bi_prod.bronze_ads.gam_content from ( select 
 $1:dimension_date:: date
,$1:_fivetran_id:: varchar(256)
,$1:dimension_content_bundle_id:: bigint
,$1:column_total_line_item_level_impressions:: bigint
,$1:dimension_content_bundle_name:: varchar(256)
,$1:dimension_content_name:: varchar(256)
,$1:dimension_content_id:: bigint
,$1:_fivetran_synced:: timestamp
,$1:dimension_attribute_content_cms_video_id:: varchar(256)
,$1:dimension_attribute_content_cms_name:: varchar(256)
,$1:column_total_video_matched_duration:: bigint
,$1:column_total_video_matched_opportunities:: bigint
,$1:column_total_video_duration:: bigint
,$1:column_total_video_capped_opportunities:: bigint
,$1:column_total_video_opportunities:: bigint
,$1:column_video_errors_vast_error_303_count:: bigint
from @BI_PROD.BRONZE_ADS.STG_ADS
(file_format=>BI_PROD.BRONZE_ADS.FF_ADS_PARQUET,pattern=>'.*/stg_gam_content/.*')t);


TRUNCATE TABLE IF EXISTS bi_prod.bronze_ads.gam_creative;
copy into bi_prod.bronze_ads.gam_creative from ( select 
 $1:dimension_date:: date
,$1:_fivetran_id:: varchar(256)
,$1:dimension_creative_size:: varchar(256)
,$1:dimension_creative_name:: varchar(256)
,$1:column_total_line_item_level_impressions:: bigint
,$1:dimension_master_companion_creative_id:: bigint
,$1:dimension_creative_type:: varchar(256)
,$1:dimension_creative_id:: bigint
,$1:dimension_master_companion_creative_name:: varchar(256)
,$1:_fivetran_synced:: timestamp
from @BI_PROD.BRONZE_ADS.STG_ADS
(file_format=>BI_PROD.BRONZE_ADS.FF_ADS_PARQUET,pattern=>'.*/stg_gam_creative/.*')t);


TRUNCATE TABLE IF EXISTS bi_prod.bronze_ads.gam_distributor;
copy into bi_prod.bronze_ads.gam_distributor from ( select 
 $1:_row:: bigint
,$1:distributor:: varchar(256)
,$1:ad_unit_name:: varchar(256)
,$1:_fivetran_synced:: timestamp
from @BI_PROD.BRONZE_ADS.STG_ADS
(file_format=>BI_PROD.BRONZE_ADS.FF_ADS_PARQUET,pattern=>'.*/stg_gam_distributor_custom/.*')t);


TRUNCATE TABLE IF EXISTS bi_prod.bronze_ads.gam_line_item;
copy into bi_prod.bronze_ads.gam_line_item from ( select 
 $1:dimension_date:: date
,$1:_fivetran_id:: varchar(256)
,$1:dimension_attribute_line_item_end_date_time:: varchar(256)
,$1:dimension_attribute_line_item_contracted_quantity:: bigint
,$1:dimension_order_id:: bigint
,$1:dimension_line_item_type:: varchar(256)
,$1:dimension_attribute_line_item_cost_per_unit:: bigint
,$1:dimension_line_item_id:: bigint
,$1:dimension_attribute_line_item_goal_quantity:: varchar(256)
,$1:dimension_attribute_line_item_delivery_pacing:: varchar(256)
,$1:dimension_attribute_line_item_cost_type:: varchar(256)
,$1:dimension_attribute_line_item_priority:: bigint
,$1:dimension_attribute_line_item_start_date_time:: timestamp
,$1:column_total_line_item_level_impressions:: bigint
,$1:dimension_order_name:: varchar(256)
,$1:dimension_line_item_name:: varchar(256)
,$1:dimension_attribute_line_item_delivery_indicator:: varchar(256)
,$1:column_total_line_item_level_all_revenue:: bigint
,$1:_fivetran_synced:: timestamp
from @BI_PROD.BRONZE_ADS.STG_ADS
(file_format=>BI_PROD.BRONZE_ADS.FF_ADS_PARQUET,pattern=>'.*/stg_gam_line_item/.*')t);


TRUNCATE TABLE IF EXISTS bi_prod.bronze_ads.gam_order;
copy into bi_prod.bronze_ads.gam_order from ( select 
 $1:dimension_date:: date
,$1:_fivetran_id:: varchar(256)
,$1:column_total_line_item_level_impressions:: bigint
,$1:dimension_order_name:: varchar(256)
,$1:dimension_attribute_order_end_date_time:: varchar(256)
,$1:dimension_advertiser_id:: bigint
,$1:dimension_attribute_order_start_date_time:: timestamp
,$1:dimension_attribute_order_salesperson:: varchar(256)
,$1:dimension_order_id:: bigint
,$1:_fivetran_synced:: timestamp
from @BI_PROD.BRONZE_ADS.STG_ADS
(file_format=>BI_PROD.BRONZE_ADS.FF_ADS_PARQUET,pattern=>'.*/stg_gam_order/.*')t);


TRUNCATE TABLE IF EXISTS bi_prod.bronze_ads.gam_page_type;
copy into bi_prod.bronze_ads.gam_page_type from ( select 
 $1:_row:: bigint
,$1:page_type_name:: varchar(256)
,$1:ad_unit_name:: varchar(256)
,$1:_fivetran_synced:: timestamp
from @BI_PROD.BRONZE_ADS.STG_ADS
(file_format=>BI_PROD.BRONZE_ADS.FF_ADS_PARQUET,pattern=>'.*/stg_gam_page_type_custom/.*')t);


TRUNCATE TABLE IF EXISTS bi_prod.bronze_ads.gam_platform;
copy into bi_prod.bronze_ads.gam_platform from ( select 
 $1:_row:: bigint
,$1:platform_group:: varchar(256)
,$1:ad_unit_name:: varchar(256)
,$1:platform_name:: varchar(256)
,$1:_fivetran_synced:: timestamp
from @BI_PROD.BRONZE_ADS.STG_ADS
(file_format=>BI_PROD.BRONZE_ADS.FF_ADS_PARQUET,pattern=>'.*/stg_gam_platform_custom/.*')t);


TRUNCATE TABLE IF EXISTS bi_prod.bronze_ads.gam_section;
copy into bi_prod.bronze_ads.gam_section from ( select 
 $1:_row:: bigint
,$1:ad_unit_name:: varchar(256)
,$1:section_name:: varchar(256)
,$1:_fivetran_synced:: timestamp
from @BI_PROD.BRONZE_ADS.STG_ADS
(file_format=>BI_PROD.BRONZE_ADS.FF_ADS_PARQUET,pattern=>'.*/stg_gam_section_custom/.*')t);


TRUNCATE TABLE IF EXISTS bi_prod.bronze_ads.gam_site;
copy into bi_prod.bronze_ads.gam_site from ( select 
 $1:_row:: bigint
,$1:ad_unit_name:: varchar(256)
,$1:site_name:: varchar(256)
,$1:site_name_abbreviation:: varchar(256)
,$1:_fivetran_synced:: timestamp
from @BI_PROD.BRONZE_ADS.STG_ADS
(file_format=>BI_PROD.BRONZE_ADS.FF_ADS_PARQUET,pattern=>'.*/stg_gam_site_custom/.*')t);
);
"
))}}

select getdate() as copy_date ,'adtech bronze gam copy into snowflake' as comment