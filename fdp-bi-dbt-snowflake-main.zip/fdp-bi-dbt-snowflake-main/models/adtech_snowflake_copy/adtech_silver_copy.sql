{{config(materialized='view',pre_hook=before_begin(
"
--Dimensions--

truncate table BI_PROD.silver_ads.dim_advertiser;
copy into BI_PROD.silver_ads.dim_advertiser from (
select
$1:advertiser_id:: bigint as advertiser_id,
$1:advertiser_key:: bigint as advertiser_key,
$1:advertiser_name:: varchar(150) as advertiser_name,
$1:authority_code:: varchar(20) as authority_code,
$1:data_source_cd:: varchar(35) as data_source_cd,
$1:etl_create_date:: bigint as etl_create_date,
$1:etl_modified_date::bigint as etl_modified_date,
$1:natural_key:: varchar(50) as natural_key,
$1:src_processed_timestamp:: timestamp as src_processed_timestamp
from @BI_PROD.SILVER_ADS.STG_ADS
(file_format=>BI_PROD.SILVER_ADS.FF_ADS_PARQUET,pattern=>'.*/adv/.*')t);


truncate table BI_PROD.silver_ads.dim_ad_creative;
COPY INTO BI_PROD.silver_ads.dim_ad_creative
FROM(
SELECT 
$1:authority_code::varchar as authority_code,
$1:creative_id::int as creative_id,
$1:creative_key as creative_key,
$1:creative_name::varchar as creative_name,
$1:etl_create_date as etl_create_date,
$1:creative_pixel_size::varchar as creative_pixel_size,
$1:etl_modified_date as etl_modified_date ,
$1:natural_key::varchar as natural_key,
$1:network_group_id network_group_id 
from @BI_PROD.SILVER_ADS.STG_ADS 
(file_format => BI_PROD.SILVER_ADS.FF_ADS_PARQUET, pattern =>'.*/creative/.*') t)
;

truncate table BI_PROD.silver_ads.dim_ad_unit;
COPY INTO   BI_PROD.silver_ads.dim_ad_unit from (
select
$1:ad_unit_category:: varchar(35) as ad_unit_category,
$1:ad_unit_id:: bigint as ad_unit_id,
$1:ad_unit_key:: bigint as ad_unit_key,
$1:ad_unit_name:: varchar(255) as ad_unit_name,
$1:authority_code:: varchar(20) as authority_code,
$1:business_unit:: varchar(35) as business_unit,
$1:device_type:: varchar(50) as device_type,
$1:device_type_detail:: varchar(35) as device_type_detail,
$1:distributor:: varchar(50) as distributor,
$1:etl_create_date::bigint as etl_create_date,
$1:etl_modified_date:: bigint as etl_modified_date,
$1:natural_key:: varchar(50) as natural_key,
$1:owned_or_distributed:: varchar(35) as owned_or_distributed,
$1:page_type_detail:: varchar(25) as page_type_detail,
$1:site_abbreviated_name:: varchar(20) as site_abbreviated_name,
$1:site_name:: varchar(35) as site_name,
$1:src_processed_timestamp:: timestamp as src_processed_timestamp
from @BI_PROD.SILVER_ADS.STG_ADS
(file_format=>BI_PROD.SILVER_ADS.FF_ADS_PARQUET,pattern=>'.*/adunit/.*')t);


truncate table BI_PROD.silver_ads.dim_campaign;
COPY INTO   BI_PROD.silver_ads.dim_campaign from (
select 
$1:authority_code:: varchar(20) as authority_code,
$1:campaign_id:: bigint as campaign_id,
$1:campaign_key:: bigint as campaign_key,
$1:campaign_name:: varchar(255) as campaign_name,
$1:create_date:: bigint as create_date,
$1:insertion_order_id:: bigint as insertion_order_id,
$1:insertion_order_name:: varchar(255) asinsertion_order_name,
$1:natural_key:: varchar(150) as natural_key,
$1:network_type:: bigint as network_type,
$1:placement_id:: bigint as placement_id,
$1:update_date:: bigint as update_date
from @BI_PROD.SILVER_ADS.STG_ADS
(file_format=>BI_PROD.SILVER_ADS.FF_ADS_PARQUET,pattern=>'.*/campaign/.*')t);

truncate table BI_PROD.silver_ads.dim_content;
COPY INTO   BI_PROD.silver_ads.dim_content from (
select 
$1:authority_code :: varchar(20) as authority_code,
$1:content_cms_id:: varchar(50) as content_cms_id,
$1:content_cms_name:: varchar(255) as content_cms_name,
$1:content_id:: bigint as content_id,
$1:content_key:: bigint as content_key,
$1:content_name:: varchar(255) as content_name,
$1:etl_create_date:: bigint as etl_create_date,
$1:etl_modified_date:: bigint as etl_modified_date,
$1:natural_key:: varchar(150) as natural_key,
$1:src_processed_timestamp:: timestamp as src_processed_timestamp,
$1:total_video_capped_opportunities:: bigint as total_video_capped_opportunities,
$1:total_video_duration:: bigint as total_video_duration,
$1:total_video_matched_duration:: bigint as total_video_matched_duration,
$1:total_video_matched_opportunities:: bigint as total_video_matched_opportunities,
$1:total_video_opportunities:: bigint as total_video_opportunities,
$1:video_error_count:: bigint as video_error_count
from @BI_PROD.silver_ads.STG_ADS
(file_format=>BI_PROD.SILVER_ADS.FF_ADS_PARQUET,pattern=>'.*/content/.*')t);

truncate table BI_PROD.silver_ads.dim_geography;
COPY INTO  BI_PROD.silver_ads.dim_geography from (
select 
$1:authority_code :: varchar(20) as authority_code,
$1:city_id:: bigint as city_id,
$1:city_name:: varchar(100) as city_name,
$1:country_id:: bigint as country_id,
$1:country_name:: varchar(50) as country_name,
$1:etl_create_date:: bigint as etl_create_date,
$1:etl_modified_date:: bigint as etl_modified_date,
$1:geography_id:: bigint as geography_id,
$1:geography_key:: bigint as geography_key,
$1:metro_id:: bigint as metro_id,
$1:metro_name:: varchar(150) as metro_name,
$1:natural_key:: varchar(150) as natural_key,
$1:region_id:: bigint as region_id,
$1:region_name:: varchar(150) as region_name,
$1:zip_code:: varchar(35) as zip_code,
$1:zip_code_id:: bigint as zip_code_id
from @BI_PROD.silver_ads.STG_ADS
(file_format=>BI_PROD.SILVER_ADS.FF_ADS_PARQUET,pattern=>'.*/geo/.*')t);

truncate table BI_PROD.silver_ads.dim_line_item;
COPY INTO   BI_PROD.silver_ads.dim_line_item from (
select 
$1:authority_code:: varchar(20) as authority_code,
$1:etl_create_date:: bigint as etl_create_date,
$1:etl_modified_date:: bigint as etl_modified_date,
$1:line_item_cpm:: float as line_item_cpm,
$1:line_item_end_datetime:: timestamp as line_item_end_datetime,
$1:line_item_id:: bigint as line_item_id,
$1:line_item_impressions:: bigint as line_item_impressions,
$1:line_item_key:: bigint as line_item_key,
$1:line_item_microamount:: float as line_item_microamount,
$1:line_item_microamount_per_unit::bigint as line_item_microamount_per_unit,
$1:line_item_name:: varchar(255) as line_item_name,
$1:line_item_revenue:: bigint as line_item_revenue,
$1:line_item_start_datetime:: timestamp as line_item_start_datetime,
$1:line_item_type:: varchar(50) as line_item_type,
$1:natural_key:: varchar(50) as natural_key,
$1:order_id:: bigint as order_id,
$1:order_name:: varchar(255) as order_name,
$1:src_processed_timestamp:: timestamp as src_processed_timestamp
from @BI_PROD.SILVER_ADS.STG_ADS
(file_format=>BI_PROD.SILVER_ADS.FF_ADS_PARQUET,pattern=>'.*/lineitem/.*')t);

truncate table BI_PROD.silver_ads.dim_network_group;
COPY INTO   BI_PROD.silver_ads.dim_network_group from (
select 
$1:authority_code:: varchar(20) as authority_code,
$1:create_date:: bigint as create_date,
$1:natural_key:: varchar(100) as natural_key,
$1:network_group_id:: bigint as network_group_id,
$1:network_group_key:: bigint as network_group_key,
$1:network_group_name:: varchar(100) as network_group_name,
$1:update_date:: bigint as update_date
from @BI_PROD.SILVER_ADS.STG_ADS
(file_format=>BI_PROD.SILVER_ADS.FF_ADS_PARQUET,pattern=>'.*/networkgroup/.*')t);

truncate table BI_PROD.silver_ads.dim_orders;
COPY INTO   BI_PROD.silver_ads.dim_orders from (
select 
$1:authority_code:: varchar(20) as authority_code,
$1:etl_create_date:: bigint as etl_create_date,
$1:etl_modified_date:: bigint as etl_modified_date,
$1:natural_key:: varchar(150) as natural_key,
$1:order_end_datetime:: timestamp as  order_end_datetime,
$1:order_id:: bigint as order_id,
$1:order_key:: bigint as order_key,
$1:order_name:: varchar(255) as order_name,
$1:order_start_datetime:: timestamp as order_start_datetime,
$1:salesperson_name:: varchar(150) as salesperson_name,
$1:src_processed_timestamp: timestamp as src_processed_timestamp
from @BI_PROD.SILVER_ADS.STG_ADS
(file_format=>BI_PROD.SILVER_ADS.FF_ADS_PARQUET,pattern=>'.*/orders/.*') t);

truncate table BI_PROD.silver_ads.dim_placement;
COPY INTO BI_PROD.silver_ads.dim_placement
    FROM
(
SELECT $1:authority_code::varchar as authority_code,
$1:create_date::bigint as create_date,
$1:natural_key::varchar as natural_key,
$1:network_type::bigint as network_type,
$1:placement_id::bigint as placement_id,
$1:placement_key::bigint as placement_key,
$1:placement_name::varchar as placement_name,
$1:placement_type::varchar as placement_type,
$1:update_date::bigint asupdate_date 
FROM @BI_PROD.SILVER_ADS.STG_ADS 
(file_format => BI_PROD.SILVER_ADS.FF_ADS_PARQUET, pattern =>'.*placement.*') t);

truncate table BI_PROD.silver_ads.dim_video_series;
COPY INTO  BI_PROD.silver_ads.dim_video_series from (
select 
$1:authority_code:: varchar(20) as authority_code,
$1:business_unit:: varchar(35) as business_unit,
$1:create_date:: bigint as create_date,
$1:is_group_or_series_type:: varchar(35) is_group_or_series_type,
$1:natural_key:: varchar(150) as natural_key,
$1:network_group_key:: bigint as network_group_key,
$1:series_id:: bigint as series_id,
$1:series_name:: varchar(255) as series_name,
$1:update_date:: bigint as update_date,
$1:video_series_key:: bigint as video_series_key 
from @BI_PROD.SILVER_ADS.STG_ADS
(file_format=>BI_PROD.SILVER_ADS.FF_ADS_PARQUET,pattern=>'.*/videoseries/.*') t);

truncate table BI_PROD.silver_ads.dim_site_section;
COPY INTO BI_PROD.silver_ads.dim_site_section FROM
(
select 
$1:app :: varchar(25) as app,
$1:authority_code :: varchar(20) as authority_code,
$1:create_date :: bigint as create_date,
$1:device_type :: varchar(35) as device_type,
$1:device_type_detail :: varchar(35)as device_type_detail,
$1:natural_key :: varchar(35) as natural_key,
$1:network :: varchar(50) as network,
$1:network_group_key :: bigint as network_group_key,
$1:owned_or_distributed :: varchar(50) as owned_or_distributed,
$1:site_section_id :: bigint as site_section_id,
$1:site_section_key:: bigint as site_section_key,
$1:site_section_name :: varchar(150) as site_section_name,
$1:stream_type :: varchar(35) as stream_type,
$1:update_date :: bigint as update_date
from @BI_PROD.SILVER_ADS.STG_ADS
(file_format=>BI_PROD.SILVER_ADS.FF_ADS_PARQUET,pattern=>'.*/sitesection/.*')t )
;

truncate table BI_PROD.silver_ads.dim_video_asset;
COPY INTO  BI_PROD.silver_ads.dim_video_asset FROM
(
select 
$1:authority_code:: varchar(20)  as authority_code,
$1:create_date:: bigint as create_date,
$1:natural_key:: varchar(150) as natural_key,
$1:network_group_key :: bigint as network_group_key,
$1:update_date:: bigint as update_date,
$1:video_asset_id:: bigint as video_asset_id,
$1:video_asset_key:: bigint as video_asset_key,
$1:video_asset_name:: varchar(255) video_asset_name
from @BI_PROD.SILVER_ADS.STG_ADS
(file_format=>BI_PROD.SILVER_ADS.FF_ADS_PARQUET,pattern=>'.*/videoasset/.*') t );

copy into bi_prod.silver_ads.dim_ad_request
from (select $1:transaction_id :: varchar
,$1:event_date :: date
,$1:freewheel_network_id :: bigint
,$1:ad_response_type :: varchar
,$1:additional_ad_response_type :: varchar 
,$1:player_profile :: varchar
,$1:custom_site_section_id :: bigint
,$1:video_asset :: varchar
,$1:asset_network_id :: bigint
,$1:site_section_network_id :: bigint
,$1:page_view_random :: varchar
,$1:video_player_random :: varchar
,$1:video_player_capabilities :: varchar
,$1:default_metrics :: bigint
,$1:kvp :: varchar
,$1:asset_fallback_id :: bigint
,$1:site_section_fallback_id :: bigint
,$1:end_user_ip :: varchar
,$1:request_mode :: varchar
,$1:video_asset_duration_type :: varchar
,$1:content_video_duration :: varchar
,$1:video_request_duration :: varchar
,$1:server_side_vendor_indicator :: varchar
,$1:nielsen_app_id :: varchar
,$1:user_agent :: varchar
,$1:http_referer :: varchar
,$1:mvpd_provider :: varchar
,$1:hylda :: varchar
,$1:ccpa_compliance :: varchar
,$1:limited_ad_tracking :: varchar
,$1:device_id :: varchar
,$1:custom_visitor_id :: varchar
,$1:slot_custom_id :: varchar
,$1:slot_time_position :: varchar
,$1:type_of_slot :: varchar
,$1:slot_max_duration :: varchar
,$1:specify_custom_ad_unit :: varchar
,$1:cue_point_position :: varchar
,$1:minimum_duration_of_slot :: varchar
,$1:yospace_transaction_id :: varchar
,$1:all_request_kv :: varchar
from @BI_PROD.SILVER_ADS.STG_ADS
(file_format=>BI_PROD.SILVER_ADS.FF_ADS_PARQUET,pattern=>'.*prod/adtech-dim/ad_req/.*') 
);

--Fact--

DELETE FROM bi_prod.silver_ads.ft_ad_delivery_integration_health_daily
WHERE event_date >= to_date(getdate()) - 3;

copy into bi_prod.silver_ads.ft_ad_delivery_integration_health_daily
from 
(select 
$1:event_date :: date as event_date,
$1:authority_code :: varchar(15) as authority_code,
$1:network_group_key :: bigint as network_group_key,
$1:site_section_or_ad_unit_key :: bigint as site_section_or_ad_unit_key,
$1:video_series_key :: bigint as video_series_key,
$1:video_asset_key :: bigint as video_asset_key,
$1:sales_channel_type :: varchar(256) as sales_channel_type,
$1:selling_partner_id :: bigint as selling_partner_id,
$1:distribution_partner_id :: bigint as distribution_partner_id,
$1:user_identity_status :: varchar(35) as user_identity_status,
$1:advertiser_key :: bigint as advertiser_key,
$1:campaign_or_order_key :: bigint as campaign_or_order_key,
$1:referer_url :: varchar(256) as referer_url,
$1:geography_key :: bigint as geography_key,
$1:placement_or_line_item_key :: bigint as placement_or_line_item_key,
$1:creative_key  :: bigint as creative_key,
$1:total_ad_requests :: bigint as total_ad_requests,
$1:total_ad_responses :: bigint as total_ad_responses,
$1:avg_max_ads :: bigint as avg_max_ads,
$1:avg_max_duration_secs :: bigint as avg_max_duration_secs,
$1:avg_ads_selected :: bigint as avg_ads_selected,
$1:avg_ad_duration_secs :: bigint as avg_ad_duration_secs,
$1:avg_time_filled_secs :: bigint as avg_time_filled_secs,
$1:total_ads_allowed :: bigint as total_ads_allowed,
$1:total_ads_availed :: bigint as total_ads_availed,
$1:total_ad_duration_allowed_secs :: bigint as total_ad_duration_allowed_secs,
$1:total_ad_duration_availed_secs :: bigint as total_ad_duration_availed_secs,
$1:total_ad_time_filled_secs :: bigint as total_ad_time_filled_secs,
$1:total_slate_duration_secs :: bigint as total_slate_duration_secs,
$1:total_ad_impressions :: bigint as total_ad_impressions,
$1:total_slot_impressions :: bigint as total_slot_impressions,
$1:total_unfilled_impressions :: bigint as total_unfilled_impressions,
$1:total_ad_not_filled_slots :: bigint as total_ad_not_filled_slots,
$1:avg_slate_duration_in_sec :: bigint as avg_slate_duration_in_sec, 
$1:avg_slate_percentage :: decimal(38,14) as avg_slate_percentage, 
$1:avg_fill_rate :: decimal(38,14) as avg_fill_rate,
$1:total_breaks_complete_unfilled :: bigint as total_breaks_complete_unfilled,
$1:total_breaks :: bigint as total_breaks,
$1:total_ad_clicks :: bigint as total_ad_clicks,
$1:avg_ad_click_thru_rate :: float as avg_ad_click_thru_rate,
$1:avg_ad_cpm :: float  as avg_ad_cpm,
$1:total_ad_revenue :: float as total_ad_revenue,
$1:avg_ad_cost_per_click :: float as avg_ad_cost_per_click,
$1:total_error_count :: bigint as total_error_count,
$1:total_unmatched_ad_request :: bigint as total_unmatched_ad_request,  
$1:create_date :: bigint AS create_date,
$1:update_date :: bigint AS update_date,
$1:content_duration :: bigint,
$1:etl_create_date_utc,
$1:etl_modified_date_utc
from @BI_PROD.SILVER_ADS.STG_ADS
(file_format=>BI_PROD.SILVER_ADS.FF_ADS_PARQUET,pattern=>'.*prod/adtech-fact/incremental/ft-daily.*'));



DELETE FROM bi_prod.silver_ads.ft_ad_delivery_integration_health_slot_level
WHERE event_date >= to_date(getdate()) - 3;

COPY INTO bi_prod.silver_ads.ft_ad_delivery_integration_health_slot_level FROM (select 
$1:event_date::date as event_date ,
$1:transaction_id::varchar(256) as transaction_id ,
$1:authority_code::varchar(15) as authority_code ,
$1:slot_type::varchar(256) as slot_type ,
$1:slot_index::integer as slot_index ,
$1:network_group_key::bigint as network_group_key ,
$1:site_section_or_ad_unit_key::bigint as site_section_or_ad_unit_key ,
$1:video_series_key::bigint as video_series_key ,
$1:video_asset_key::bigint as video_asset_key ,
$1:sales_channel_type::varchar(256) as sales_channel_type ,
$1:selling_partner_id::bigint as selling_partner_id ,
$1:distribution_partner_id::bigint as distribution_partner_id ,
$1:ad_requests::bigint as ad_requests ,
$1:ad_responses::bigint as ad_responses ,
$1:max_ads::integer as max_ads ,
$1:max_duration::integer as max_duration ,
$1:ads_selected::integer as ads_selected ,
$1:ad_duration::integer as ad_duration ,
$1:time_unfilled::integer as time_unfilled ,
$1:time_filled::integer as time_filled ,
$1:slot_impressions::bigint as slot_impressions ,
$1:ad_impressions::bigint as ad_impressions ,
$1:reseller_ad_not_filled_slots::bigint as reseller_ad_not_filled_slots ,
$1:slate_percentage::numeric(18,7) as slate_percentage ,
$1:fill_rate::numeric(18,7) as fill_rate ,
$1:create_date::bigint as create_date ,
$1:update_date::bigint as update_date ,
$1:advertiser_key::bigint as advertiser_key ,
$1:placement_or_line_item_key::bigint as placement_or_line_item_key ,
$1:impression_id::varchar(35) as impression_id ,
$1:user_identity_status::varchar(35) as user_identity_status ,
$1:creative_key::bigint as creative_key ,
$1:campaign_or_order_key::bigint as campaign_or_order_key ,
$1:referer_url::varchar(256) as referer_url ,
$1:geography_key::bigint as geography_key ,
$1:unfilled_impressions::bigint as unfilled_impressions ,
$1:ad_clicks::bigint as ad_clicks ,
$1:ad_ctr::double as ad_ctr ,
$1:ad_cpm::double as ad_cpm ,
$1:ad_revenue::double as ad_revenue ,
$1:ad_cpc::double as ad_cpc ,
$1:total_error_count::bigint as total_error_count ,
$1:total_unmatched_ad_request::bigint as total_unmatched_ad_request,
$1:content_duration :: bigint,
$1:etl_create_date_utc,
$1:etl_modified_date_utc 
from @BI_PROD.SILVER_ADS.STG_ADS
(file_format=>BI_PROD.SILVER_ADS.FF_ADS_PARQUET,pattern=>'.*prod/adtech-fact/incremental/ft-slotlevel/.*') 
);

DELETE FROM bi_prod.silver_ads.mv_ad_delivery_integration_health_daily
WHERE event_date >= to_date(getdate()) - 3;

copy into bi_prod.silver_ads.mv_ad_delivery_integration_health_daily from(
select 
$1:event_date :: date as event_date,
$1:authority_code :: varchar(15) as authority_code, 
$1:network_group_id :: int as network_group_id,
$1:site_section_or_ad_unit_id  :: bigint as site_section_or_ad_unit_id,
$1:site_section_detail :: varchar(256) as site_section_detail,
$1:advertiser_id :: bigint as advertiser_id,
$1:advertiser_name :: varchar(150) as advertiser_name, 
$1:placement_or_line_item_id :: bigint as placement_or_line_item_id,
$1:insertion_order_id :: bigint as insertion_order_id, 
$1:insertion_order_name :: varchar(100) as insertion_order_name, 
$1:network :: varchar(50) as network, 
$1:stream_type :: varchar(50) as stream_type,
$1:app :: varchar(50) as app, 
$1:distributor :: varchar(50) as distributor, 
$1:owned_or_distributed :: varchar(50) as owned_or_distributed, 
$1:device_type :: varchar(50) as device_type, 
$1:device_type_detail :: varchar(50) as device_type_detail,
$1:series_id :: bigint as series_id,
$1:series_name :: varchar(256) as series_name, 
$1:business_unit :: varchar(200) as business_unit,
$1:is_group_or_series_type :: varchar(10) as is_group_or_series_type, 
$1:video_asset_id :: bigint as video_asset_id,
$1:video_asset_name :: varchar(256) as video_asset_name,
$1:sales_channel_type :: varchar(256) as sales_channel_type, 
$1:distribution_partner_id :: bigint as distribution_partner_id, 
$1:user_identity_status :: varchar(35) as user_identity_status, 
$1:page_type_detail :: varchar(35) as page_type_detail, 
$1:ad_unit_category :: varchar(35) as ad_unit_category, 
$1:ad_unit_format :: varchar(35) as ad_unit_format, 
$1:ad_unit_detail_name :: varchar(35) as ad_unit_detail_name, 
$1:creative_pixel_size :: varchar(15) as creative_pixel_size, 
$1:creative_id :: bigint as creative_id,
$1:creative_name :: varchar(350) as creative_name, 
$1:placement_or_line_item_name :: varchar(256) as placement_or_line_item_name, 
$1:geography_id :: varchar(150) as geography_id, 
$1:campaign_or_order_id :: bigint as campaign_or_order_id,
$1:campaign_or_order_name :: varchar(150) as campaign_or_order_name,
$1:referer_url :: varchar(256) as referer_url, 
$1:country_name :: varchar(100) as country_name, 
$1:region_name :: varchar(100) as region_name,
$1:metro_name :: varchar(100) as metro_name,
$1:city_name :: varchar(100) as city_name,
$1:zip_code :: varchar(25) as zip_code,
$1:total_ad_requests :: bigint as total_ad_requests, 
$1:total_ad_responses :: bigint as total_ad_responses, 
$1:avg_max_ads :: integer as avg_max_ads, 
$1:avg_max_duration_secs :: integer as avg_max_duration_secs, 
$1:avg_ads_selected :: integer as avg_ads_selected,
$1:avg_ad_duration_secs :: integer as avg_ad_duration_secs,
$1:avg_time_filled_secs :: integer as avg_time_filled_secs,
$1:total_ads_allowed :: bigint as total_ads_allowed, 
$1:total_ads_availed :: bigint as total_ads_availed, 
$1:total_ad_duration_allowed_secs :: bigint as total_ad_duration_allowed_secs, 
$1:total_ad_duration_availed_secs :: bigint as total_ad_duration_availed_secs, 
$1:total_ad_time_filled_secs :: bigint as total_ad_time_filled_secs,
$1:total_slate_duration_secs :: bigint as total_slate_duration_secs,
$1:total_ad_impressions :: bigint as total_ad_impressions,
$1:total_slot_impressions :: bigint as total_slot_impressions,
$1:total_unfilled_impressions :: bigint as total_unfilled_impressions, 
$1:total_ad_not_filled_slots :: bigint as total_ad_not_filled_slots, 
$1:avg_slate_duration_in_sec :: bigint as avg_slate_duration_in_sec, 
$1:avg_slate_percentage :: decimal(31,14) as avg_slate_percentage, 
$1:avg_fill_rate :: decimal(31,14) as avg_fill_rate, 
$1:total_breaks_complete_unfilled :: bigint as total_breaks_complete_unfilled, 
$1:total_breaks :: bigint as total_breaks,
$1:percentage_of_ad_breaks_with_full_slate  :: decimal(31,14) as percentage_of_ad_breaks_with_full_slate,
$1:total_ad_clicks :: bigint as total_ad_clicks, 
$1:avg_ad_click_thru_rate :: float as avg_ad_click_thru_rate,
$1:avg_ad_cpm :: float as avg_ad_cpm,
$1:total_ad_revenue :: float as total_ad_revenue, 
$1:avg_ad_cost_per_click :: float as avg_ad_cost_per_click, 
$1:total_error_count :: bigint as total_error_count, 
$1:total_unmatched_ad_request :: bigint as total_unmatched_ad_request,
$1:create_date :: bigint as create_date,
$1:update_date :: bigint as update_date,
$1:etl_create_date_utc,
$1:etl_modified_date_utc
from @BI_PROD.SILVER_ADS.STG_ADS
(file_format=>BI_PROD.SILVER_ADS.FF_ADS_PARQUET,pattern=>'.*prod/adtech-fact/incremental/mv-daily.*'));


DELETE FROM bi_prod.silver_ads.mv_ad_delivery_integration_health_slot_level
WHERE event_date >= to_date(getdate()) - 3;

COPY INTO bi_prod.silver_ads.mv_ad_delivery_integration_health_slot_level
FROM (
select 
$1:event_date :: date as event_date
,$1:transaction_id :: varchar(256) as transaction_id
,$1:authority_code :: varchar(15) as authority_code
,$1:slot_type :: varchar(256) as slot_type
,$1:slot_index :: integer as slot_index
,$1:network_group_id :: integer as network_group_id
,$1:site_section_or_ad_unit_id :: bigint as site_section_or_ad_unit_id
,$1:site_section_detail :: varchar(256) as site_section_detail
,$1:network :: varchar(50) as network
,$1:stream_type :: varchar(50) as stream_type
,$1:app :: varchar(50) as app
,$1:owned_or_distributed :: varchar(50) as owned_or_distributed
,$1:device_type :: varchar(50) as device_type
,$1:device_type_detail :: varchar(50) as device_type_detail
,$1:series_id :: bigint as series_id
,$1:series_name :: varchar(256) as series_name
,$1:business_unit :: varchar(200) as business_unit
,$1:is_group_or_series_type :: varchar(10) as is_group_or_series_type
,$1:video_asset_id :: bigint as video_asset_id
,$1:video_asset_name :: varchar(256) as video_asset_name
,$1:sales_channel_type :: varchar(256) as sales_channel_type
,$1:distribution_partner_id :: bigint as distribution_partner_id
,$1:ad_requests :: bigint as ad_requests
,$1:ad_responses :: bigint as ad_responses
,$1:max_ads :: integer as max_ads
,$1:max_duration :: integer as max_duration
,$1:ads_selected :: integer as ads_selected
,$1:ad_duration :: integer as ad_duration
,$1:time_unfilled :: integer as time_unfilled
,$1:time_filled :: integer as time_filled
,$1:slot_impressions :: bigint as slot_impressions
,$1:ad_impressions :: bigint as ad_impressions
,$1:reseller_ad_not_filled_slots :: bigint as reseller_ad_not_filled_slots
,$1:slate_percentage :: numeric(31,14) as slate_percentage
,$1:fill_rate :: numeric(31,14) as fill_rate
,$1:create_date :: bigint as create_date
,$1:update_date :: bigint as update_date
,$1:advertiser_id :: bigint as advertiser_id
,$1:advertiser_name :: varchar(150) as advertiser_name
,$1:placement_or_line_item_id :: bigint as placement_or_line_item_id
,$1:insertion_order_id :: bigint as insertion_order_id
,$1:insertion_order_name :: varchar(100) as insertion_order_name
,$1:impression_id :: varchar(35) as impression_id
,$1:user_identity_status :: varchar(35) as user_identity_status
,$1:distributor :: varchar(50) as distributor
,$1:unfilled_impressions :: bigint as unfilled_impressions
,$1:ad_clicks :: bigint as ad_clicks
,$1:ad_ctr :: double as ad_ctr
,$1:ad_cpm :: double as ad_cpm
,$1:ad_revenue :: double as ad_revenue
,$1:ad_cpc :: double as ad_cpc
,$1:total_error_count :: bigint as total_error_count
,$1:total_unmatched_ad_request :: bigint as total_unmatched_ad_request
,$1:page_type_detail :: varchar(35) as page_type_detail
,$1:ad_unit_category :: varchar(35) as ad_unit_category
,$1:ad_unit_format :: varchar(35) as ad_unit_format
,$1:ad_unit_detail_name :: varchar(35) as ad_unit_detail_name
,$1:creative_id :: bigint as creative_id
,$1:creative_pixel_size :: varchar(15) as creative_pixel_size
,$1:creative_name :: varchar(350) as creative_name
,$1:placement_or_line_item_name :: varchar(256) as placement_or_line_item_name
,$1:geography_id :: varchar(150) as geography_id
,$1:campaign_or_order_id :: bigint as campaign_or_order_id
,$1:campaign_or_order_name :: varchar(150) as campaign_or_order_name
,$1:referer_url :: varchar(256) as referer_url
,$1:country_name :: varchar(100) as country_name
,$1:region_name :: varchar(100) as region_name
,$1:metro_name :: varchar(100) as metro_name
,$1:city_name :: varchar(100) as city_name
,$1:zip_code :: varchar(25) as zip_code
,$1:etl_create_date_utc
,$1:etl_modified_date_utc
,$1:FREEWHEEL_NETWORK_ID :: bigint
,$1:AD_RESPONSE_TYPE :: varchar
,$1:ADDITIONAL_AD_RESPONSE_TYPE :: varchar
,$1:PLAYER_PROFILE :: varchar
,$1:CUSTOM_SITE_SECTION_ID :: bigint
,$1:VIDEO_ASSET :: varchar
,$1:ASSET_NETWORK_ID :: bigint
,$1:SITE_SECTION_NETWORK_ID :: bigint
,$1:PAGE_VIEW_RANDOM :: varchar
,$1:VIDEO_PLAYER_RANDOM :: varchar
,$1:VIDEO_PLAYER_CAPABILITIES :: varchar
,$1:DEFAULT_METRICS :: bigint
,$1:KVP :: varchar
,$1:ASSET_FALLBACK_ID :: bigint
,$1:SITE_SECTION_FALLBACK_ID :: bigint
,$1:END_USER_IP :: varchar
,$1:REQUEST_MODE :: varchar
,$1:VIDEO_ASSET_DURATION_TYPE :: varchar
,$1:CONTENT_VIDEO_DURATION :: varchar
,$1:VIDEO_REQUEST_DURATION :: varchar
,$1:SERVER_SIDE_VENDOR_INDICATOR :: varchar
,$1:NIELSEN_APP_ID :: varchar
,$1:USER_AGENT :: varchar
,$1:HTTP_REFERER :: varchar
,$1:MVPD_PROVIDER :: varchar
,$1:HYLDA :: varchar
,$1:CCPA_COMPLIANCE :: varchar
,$1:LIMITED_AD_TRACKING :: varchar
,$1:DEVICE_ID :: varchar
,$1:CUSTOM_VISITOR_ID :: varchar
,$1:SLOT_CUSTOM_ID :: varchar
,$1:SLOT_TIME_POSITION :: varchar
,$1:TYPE_OF_SLOT :: varchar
,$1:SLOT_MAX_DURATION :: varchar
,$1:SPECIFY_CUSTOM_AD_UNIT :: varchar
,$1:CUE_POINT_POSITION :: varchar
,$1:MINIMUM_DURATION_OF_SLOT :: varchar
,$1:YOSPACE_TRANSACTION_ID :: varchar
from @BI_PROD.SILVER_ADS.STG_ADS
(file_format=>BI_PROD.SILVER_ADS.FF_ADS_PARQUET,pattern=>'.*prod/adtech-fact/incremental/mv-slotlevel/.*')
);
"
))}}

select getdate() as copy_date ,'adtech silver copy into snowflake' as comment