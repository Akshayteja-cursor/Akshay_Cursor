News Pacing AOS Columns - files to upload into fdp-di-adtech-databricks

Upload mapping:
  dev/ad_operations_news_lifetime_data_load.py
    -> src/dev/data_reporting_and_operational_processing/ad_operations_news_lifetime_data_load.py

  dev/core.py
    -> src/dev/data_reporting_and_operational_processing/core.py

  dev/gam_1P_data_load.py
    -> src/dev/data_reporting_and_operational_processing/gam_1P_data_load.py

  prod/ad_operations_news_lifetime_data_load.py
    -> src/prod/data_reporting_and_operational_processing/ad_operations_news_lifetime_data_load.py

  prod/core.py
    -> src/prod/data_reporting_and_operational_processing/core.py

  prod/gam_1P_data_load.py
    -> src/prod/data_reporting_and_operational_processing/gam_1P_data_load.py

Optional:
  terraform-dev/jobconfig_jc_IAC_data_reporting_and_operational_processing.json
    -> terraform/environments/dev/jobconfig_jc_IAC_data_reporting_and_operational_processing.json

  terraform-prod/jobconfig_jc_IAC_data_reporting_and_operational_processing.json
    -> terraform/environments/prod/jobconfig_jc_IAC_data_reporting_and_operational_processing.json

Minimal DEV validation set: the 3 files under /dev/
