Upload DEV files to .../src/dev/data_reporting_and_operational_processing/
Upload PROD files to .../src/prod/data_reporting_and_operational_processing/
For PG KeyError testing fix: use fdp-di-adtech-databricks-20934-pg-fix.zip (keeps testing %run paths)
